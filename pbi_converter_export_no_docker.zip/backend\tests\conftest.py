from pathlib import Path

import pytest

FIXTURES = Path(__file__).resolve().parents[2] / "fixtures"


@pytest.fixture(scope="session")
def contoso_pbip() -> Path:
    return FIXTURES / "contoso_sales"


@pytest.fixture(scope="session")
def contoso_model_def(contoso_pbip: Path) -> Path:
    return contoso_pbip / "Contoso Sales.SemanticModel" / "definition"


@pytest.fixture(scope="session")
def contoso_report_dir(contoso_pbip: Path) -> Path:
    return contoso_pbip / "Contoso Sales.Report"
