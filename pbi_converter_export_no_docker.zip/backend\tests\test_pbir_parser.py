import json
from pathlib import Path

import pytest

from app.ir.report import FilterScope
from app.parsers.bundle import load_pbip
from app.parsers.pbir import (
    PbirParseError,
    parse_report_definition,
    resolve_dataset_reference,
)


@pytest.fixture(scope="module")
def bundle(contoso_pbip: Path):
    return load_pbip(contoso_pbip)


class TestPbirReport:
    def test_page_parsed(self, bundle):
        assert len(bundle.report.pages) == 1
        page = bundle.report.pages[0]
        assert page.display_name == "Sales Overview"
        assert (page.width, page.height) == (1280, 720)

    def test_page_filter(self, bundle):
        page = bundle.report.pages[0]
        assert len(page.filters) == 1
        f = page.filters[0]
        assert f.scope == FilterScope.PAGE
        assert (f.field_table, f.field_name) == ("Date", "Year")
        assert f.field_is_measure is False

    def test_visuals_parsed(self, bundle):
        page = bundle.report.pages[0]
        types = {v.name: v.visual_type for v in page.visuals}
        assert types == {
            "card0001aaaabbbbcccc": "card",
            "bar00001aaaabbbbcccc": "clusteredBarChart",
            "line0001aaaabbbbcccc": "lineChart",
            "slicer01aaaabbbbcccc": "slicer",
        }

    def test_card_measure_field(self, bundle):
        card = next(v for v in bundle.report.pages[0].visuals if v.visual_type == "card")
        assert card.title == "Total Sales"
        [f] = card.fields
        assert (f.role, f.table, f.name, f.is_measure) == ("Values", "Sales", "Total Sales", True)

    def test_bar_projections_and_sort(self, bundle):
        bar = next(v for v in bundle.report.pages[0].visuals if v.visual_type == "clusteredBarChart")
        roles = {(f.role, f.table, f.name) for f in bar.fields}
        assert ("Category", "Product", "Category") in roles
        assert ("Y", "Sales", "Total Sales") in roles
        assert bar.sort[0]["direction"] == "Descending"
        assert bar.sort[0]["is_measure"] is True

    def test_bar_topn_visual_filter(self, bundle):
        bar = next(v for v in bundle.report.pages[0].visuals if v.visual_type == "clusteredBarChart")
        [f] = bar.filters
        assert f.filter_type == "TopN"
        assert f.scope == FilterScope.VISUAL
        assert f.definition["Where"][0]["Condition"]["TopN"]["ItemCount"] == 5

    def test_line_two_measures(self, bundle):
        line = next(v for v in bundle.report.pages[0].visuals if v.visual_type == "lineChart")
        ys = [f.name for f in line.fields if f.role == "Y"]
        assert ys == ["Total Sales", "Sales LY"]

    def test_slicer_field(self, bundle):
        slicer = next(v for v in bundle.report.pages[0].visuals if v.visual_type == "slicer")
        [f] = slicer.fields
        assert (f.table, f.name) == ("Customer", "Country")

    def test_positions(self, bundle):
        card = next(v for v in bundle.report.pages[0].visuals if v.visual_type == "card")
        assert (card.position.x, card.position.y) == (24, 24)
        assert (card.position.width, card.position.height) == (280, 120)

    def test_theme_captured(self, bundle):
        assert bundle.report.theme["collection"]["baseTheme"]["name"] == "CY24SU06"
        # contoso fixture declares no custom theme
        assert bundle.report.theme["custom"] == {}

    def test_bundle_model_joined(self, bundle):
        # bundle glues report to model: measures referenced by visuals must resolve
        assert bundle.model.find_measure("Total Sales") is not None
        assert bundle.model.find_measure("Sales LY") is not None

    def test_bundle_ir_roundtrip(self, bundle):
        from app.ir.report import ReportBundle

        restored = ReportBundle.model_validate_json(bundle.model_dump_json())
        assert restored == bundle


class TestPbirErrors:
    def test_by_connection_rejected(self, tmp_path):
        report_dir = tmp_path / "X.Report"
        report_dir.mkdir()
        (report_dir / "definition.pbir").write_text(
            json.dumps(
                {
                    "version": "4.0",
                    "datasetReference": {"byConnection": {"connectionString": "Data Source=x"}},
                }
            )
        )
        with pytest.raises(PbirParseError, match="byConnection"):
            resolve_dataset_reference(report_dir)

    def test_legacy_report_json_rejected(self, tmp_path):
        report_dir = tmp_path / "X.Report"
        report_dir.mkdir()
        (report_dir / "report.json").write_text("{}")
        with pytest.raises(PbirParseError, match="PBIR-Legacy"):
            parse_report_definition(report_dir)

    def test_missing_pbip(self, tmp_path):
        with pytest.raises(PbirParseError, match="no .pbip file"):
            load_pbip(tmp_path)

    def test_invalid_json_reported_with_path(self, tmp_path):
        report_dir = tmp_path / "X.Report"
        (report_dir / "definition").mkdir(parents=True)
        (report_dir / "definition" / "report.json").write_text("{not json")
        with pytest.raises(PbirParseError, match="invalid JSON"):
            parse_report_definition(report_dir)
