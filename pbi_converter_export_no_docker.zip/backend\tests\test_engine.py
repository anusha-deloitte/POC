from pathlib import Path

import pytest

from app.binding.resolver import build_binding_map
from app.parsers.bundle import load_pbip
from app.runtime.engine import (
    DimensionRef,
    FilterClause,
    MeasureRefSpec,
    QueryPlanError,
    QuerySpec,
    SemanticEngine,
)

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


@pytest.fixture(scope="module")
def engine():
    bundle = load_pbip(FIXTURE)
    return SemanticEngine(bundle.model, build_binding_map(bundle.model))


class TestJoinPlanning:
    def test_fact_to_dim_path(self, engine):
        path = engine.join_path("MV_MEDICAL_COST_SUMMARY", "DIM_MONTH")
        assert path is not None and len(path) == 1

    def test_unreachable_returns_none(self, engine):
        # REF_TARGET_PMPM does not reach FACT_QUALITY_MEASURE
        assert engine.join_path("REF_TARGET_PMPM", "FACT_QUALITY_MEASURE") is None

    def test_same_table_empty_path(self, engine):
        assert engine.join_path("DIM_LOB", "DIM_LOB") == []


class TestSqlShapes:
    def test_card_single_measure(self, engine):
        sql, warnings = engine.build_sql(
            QuerySpec(measures=[MeasureRefSpec(name="Paid Amount")])
        )
        assert 'SUM("MV_MEDICAL_COST_SUMMARY"."PAID_AMOUNT")' in sql
        assert "GROUP BY" not in sql
        assert warnings == []

    def test_grouped_measure(self, engine):
        sql, _ = engine.build_sql(
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_LOB", column="LOB_NAME")],
                measures=[MeasureRefSpec(name="Allowed Amount")],
            )
        )
        assert 'JOIN' in sql and '"DIM_LOB"' in sql
        assert 'GROUP BY "DIM_LOB"."LOB_NAME"' in sql

    def test_slicer_filter_applied(self, engine):
        sql, _ = engine.build_sql(
            QuerySpec(
                measures=[MeasureRefSpec(name="Paid Amount")],
                filters=[
                    FilterClause(table="DIM_LOB", column="LOB_NAME", values=["Commercial"])
                ],
            )
        )
        assert "IN ('Commercial')" in sql

    def test_dimension_only_slicer_domain(self, engine):
        sql, _ = engine.build_sql(
            QuerySpec(dimensions=[DimensionRef(table="DIM_STATE", column="STATE_NAME")])
        )
        assert sql.startswith("SELECT DISTINCT")
        assert "ORDER BY" in sql

    def test_ratio_measure_null_safe(self, engine):
        sql, _ = engine.build_sql(QuerySpec(measures=[MeasureRefSpec(name="Total PMPM")]))
        assert "IFF(" in sql and "IS NULL" in sql

    def test_sply_dual_date_join(self, engine):
        sql, _ = engine.build_sql(
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_MONTH", column="YEAR_MONTH")],
                measures=[MeasureRefSpec(name="Allowed PY")],
            )
        )
        assert "__d_data" in sql and "__d_cur" in sql
        assert "DATEADD(year, -1," in sql

    def test_mixed_shift_measure_two_groups(self, engine):
        sql, _ = engine.build_sql(
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_MONTH", column="YEAR_MONTH")],
                measures=[MeasureRefSpec(name="Allowed YoY %")],
            )
        )
        assert "FULL OUTER JOIN" in sql  # shifted + unshifted context groups

    def test_ytd_card_anchor(self, engine):
        sql, _ = engine.build_sql(QuerySpec(measures=[MeasureRefSpec(name="Allowed YTD")]))
        assert "SELECT MAX(" in sql  # anchored to latest date

    def test_removefilters_measure_builds(self, engine):
        sql, _ = engine.build_sql(QuerySpec(measures=[MeasureRefSpec(name="Unit Cost Index")]))
        assert "CROSS JOIN" in sql or "FULL OUTER JOIN" in sql  # cleared vs kept context groups

    def test_unreachable_filter_warned_not_failed(self, engine):
        sql, warnings = engine.build_sql(
            QuerySpec(
                measures=[
                    MeasureRefSpec(
                        table="FACT_QUALITY_MEASURE", column="MEASURE_RATE", aggregate="Average"
                    )
                ],
                filters=[
                    FilterClause(table="DIM_SERVICE_LINE", column="SERVICE_LINE", values=["x"])
                ],
            )
        )
        assert any("unreachable" in w for w in warnings)

    def test_implicit_tier0_column(self, engine):
        sql, _ = engine.build_sql(
            QuerySpec(
                measures=[
                    MeasureRefSpec(
                        table="MV_MEDICAL_COST_SUMMARY", column="PAID_AMOUNT", aggregate="Sum"
                    )
                ]
            )
        )
        assert 'SUM("MV_MEDICAL_COST_SUMMARY"."PAID_AMOUNT")' in sql

    def test_sort_and_limit(self, engine):
        sql, _ = engine.build_sql(
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_LOB", column="LOB_NAME")],
                measures=[MeasureRefSpec(name="Allowed Amount")],
                sort=[{"key": "Allowed Amount", "direction": "Descending"}],
                limit=5,
            )
        )
        assert '"Allowed Amount" DESC' in sql
        assert "LIMIT 5" in sql

    def test_empty_query_rejected(self, engine):
        with pytest.raises(QueryPlanError):
            engine.build_sql(QuerySpec())

    def test_tier2_measure_rejected_cleanly(self, engine):
        with pytest.raises(QueryPlanError, match="Measures Above Benchmark"):
            engine.build_sql(
                QuerySpec(measures=[MeasureRefSpec(name="Measures Above Benchmark")])
            )
    def test_sort_by_column_projected_in_dim_subquery(self, engine):
        """MONTH_NAME sorts by CALENDAR_MONTH (≠ join key); the deduped dim
        subquery must project it or MIN("DIM_MONTH"."CALENDAR_MONTH") fails
        with invalid identifier (regression: p2heat PMPM heatmap)."""
        sql, _ = engine.build_sql(
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_MONTH", column="MONTH_NAME")],
                measures=[MeasureRefSpec(name="Total PMPM")],
            )
        )
        assert 'MIN("DIM_MONTH"."CALENDAR_MONTH")' in sql
        # every deduped DIM_MONTH projection must carry the sort column
        for seg in sql.split("SELECT DISTINCT")[1:]:
            head = seg.split("FROM")[0]
            if '"DIM_MONTH"."MONTH_NAME"' in head:
                assert '"DIM_MONTH"."CALENDAR_MONTH"' in head