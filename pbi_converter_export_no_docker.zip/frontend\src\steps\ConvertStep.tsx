import { useQuery } from '@tanstack/react-query'
import { AlertTriangle, ArrowRight, Bot, CheckCircle2, Loader2, TerminalSquare } from 'lucide-react'
import { useEffect, useRef } from 'react'
import { useState } from 'react'
import { readErrorDetail } from '../api/client'
import { useWizard } from '../store/wizard'

interface ConvertEvent {
  ts: number
  stage: string
  message: string
  trace?: string[]
  [k: string]: unknown
}

interface ConvertResult {
  events: ConvertEvent[]
  summary: Record<string, unknown> | null
  tier2_accepted: string[]
  policy_mode?: 'advisory' | 'strict' | 'release_candidate'
  gate_status?: {
    mode: 'advisory' | 'strict' | 'release_candidate'
    passed: boolean
    checks: Array<{ name: string; passed: boolean; detail: string }>
  }
}

const STAGE_STYLE: Record<string, string> = {
  binding: 'bg-brand-blue/10 text-brand-blue',
  migration: 'bg-orange-100 text-orange-700',
  compile: 'bg-purple-100 text-purple-700',
  validate: 'bg-brand-amber/10 text-brand-amber',
  repair: 'bg-brand-red/10 text-brand-red',
  probe: 'bg-teal-100 text-teal-700',
  report: 'bg-brand/10 text-brand-dark',
  semantic_view: 'bg-indigo-100 text-indigo-700',
  parity: 'bg-cyan-100 text-cyan-700',
}

// business-facing names for the pipeline stages (stage codes are API contract)
const STAGE_LABEL: Record<string, string> = {
  binding: 'Discovery',
  migration: 'Data Migration',
  compile: 'Translation',
  validate: 'Validation',
  repair: 'Auto-Repair',
  probe: 'Filter Testing',
  report: 'Summary',
  semantic_view: 'Publishing',
  parity: 'Cross-Check',
}

const PIPELINE_STAGES = ['binding', 'compile', 'validate', 'repair', 'probe', 'report'] as const

function EventLine({ e }: { e: ConvertEvent }) {
  return (
    <li className="flex gap-2">
      <span className="shrink-0 text-surface-400">
        {new Date(e.ts * 1000).toLocaleTimeString(undefined, { hour12: false })}
      </span>
      <span
        className={`shrink-0 rounded px-1.5 font-sans font-semibold ${STAGE_STYLE[e.stage] ?? 'bg-surface-100 text-surface-600'}`}
      >
        {STAGE_LABEL[e.stage] ?? e.stage}
      </span>
      <span className="min-w-0 text-surface-700">
        {e.message}
        {/* LLM reasoning trace for tier-2 attempts */}
        {Array.isArray(e.trace) && e.trace.length > 0 && (
          <span className="mt-0.5 block border-l-2 border-surface-300 pl-2 text-[10px] text-surface-500">
            {e.trace.map((t, i) => (
              <span key={i} className="block">
                ↳ {t}
              </span>
            ))}
          </span>
        )}
      </span>
    </li>
  )
}

function AgentConsole({ events, live }: { events: ConvertEvent[]; live: boolean }) {
  const bottomRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (live) bottomRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' })
  }, [events.length, live])

  return (
    <div className="card p-0">
      <div className="flex items-center justify-between border-b border-surface-200 px-4 py-2.5">
        <span className="flex items-center gap-2 text-xs font-bold tracking-wider text-surface-500 uppercase">
          <TerminalSquare size={14} strokeWidth={1.8} />
          Conversion activity
        </span>
        {live && (
          <span className="flex items-center gap-1.5 text-[10px] font-semibold text-brand-dark">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-brand" />
            </span>
            LIVE
          </span>
        )}
      </div>
      <ul className="max-h-96 space-y-1 overflow-auto p-4 font-mono text-[11px] leading-5">
        {events.length === 0 && (
          <li className="text-surface-400">waiting for the pipeline to start…</li>
        )}
        {events.map((e, i) => (
          <EventLine key={i} e={e} />
        ))}
        <div ref={bottomRef} />
      </ul>
    </div>
  )
}

export function ConvertStep() {
  const conversionId = useWizard((s) => s.conversionId)
  const connectionId = useWizard((s) => s.connectionId)
  const sourceConnectionId = useWizard((s) => s.sourceConnectionId)
  const copyData = useWizard((s) => s.copyData)
  const setStep = useWizard((s) => s.setStep)
  const [policyMode, setPolicyMode] = useState<'advisory' | 'strict' | 'release_candidate'>('advisory')

  // query (not mutation): survives StrictMode remounts, cached per conversion
  const convert = useQuery({
    queryKey: ['convert', conversionId, connectionId],
    queryFn: async (): Promise<ConvertResult> => {
      const res = await fetch(`/api/v1/conversions/${conversionId}/dashboard/convert`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          connection_id: connectionId,
          source_connection_id: sourceConnectionId ?? undefined,
          copy_data: copyData,
          use_llm: true,
          policy_mode: policyMode,
        }),
      })
      // gateway timeout: the pipeline keeps running server-side — poll the
      // persisted artifact until it lands instead of failing the run
      if (res.status === 504 || res.status === 502) {
        for (let i = 0; i < 150; i++) {
          await new Promise((r) => setTimeout(r, 4000))
          const prog = await fetch(
            `/api/v1/conversions/${conversionId}/dashboard/convert/progress`,
          )
          if (prog.ok && (await prog.json()).done) break
        }
        const fid = await fetch(`/api/v1/conversions/${conversionId}/dashboard/fidelity`)
        if (fid.ok) return fid.json()
        throw new Error(
          'Gateway timed out and the conversion result is not available yet — retry in a moment.',
        )
      }
      if (!res.ok) throw new Error(await readErrorDetail(res))
      return res.json()
    },
    enabled: !!conversionId && !!connectionId,
    staleTime: Infinity,
    retry: false,
  })

  // live progress feed while the POST is in flight
  const progress = useQuery({
    queryKey: ['convert-progress', conversionId],
    queryFn: async (): Promise<{ events: ConvertEvent[]; done: boolean }> => {
      const res = await fetch(`/api/v1/conversions/${conversionId}/dashboard/convert/progress`)
      if (!res.ok) return { events: [], done: false }
      return res.json()
    },
    enabled: !!conversionId && convert.isPending,
    refetchInterval: 1200,
  })

  if (!conversionId || !connectionId)
    return <p className="text-surface-500">Upload a report and pick a connection first.</p>

  const events = convert.data?.events ?? progress.data?.events ?? []
  const stagesSeen = [...new Set(events.map((e) => e.stage))]
  const currentStage = stagesSeen[stagesSeen.length - 1] ?? null
  const stageCount = stagesSeen.length
  const runOutcome =
    !convert.data
      ? 'in_progress'
      : convert.data.gate_status && !convert.data.gate_status.passed
        ? 'warning'
        : 'clean'

  return (
    <section>
      <div className="mb-6 overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div className="kicker mb-1">Step 4 · Conversion pipeline</div>
        <h2 className="text-xl font-bold">Converting &amp; validating</h2>
        <p className="mt-1 max-w-2xl text-sm text-surface-600">
          Your report is discovered against Snowflake, translated measure by measure, validated
          number by number, filter-tested, and auto-repaired where possible — nothing ships
          unverified.
        </p>
        {/* stage tracker */}
        <div className="mt-4 rounded-xl border border-black/[0.06] bg-white p-3">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-semibold text-surface-600">Pipeline progress</span>
            <span className="text-xs font-semibold text-surface-600">
              {stageCount}/{PIPELINE_STAGES.length} stages reached
            </span>
          </div>
          <div className="h-2 overflow-hidden rounded-full bg-surface-200">
            <div
              className="h-full bg-gradient-to-r from-brand to-brand-dark transition-all"
              style={{ width: `${Math.min((stageCount / PIPELINE_STAGES.length) * 100, 100)}%` }}
            />
          </div>
          <p className="mt-2 text-xs text-surface-500">
            {convert.isPending
              ? currentStage
                ? `Running ${STAGE_LABEL[currentStage] ?? currentStage}. Safe to keep this tab open while processing completes.`
                : 'Preparing conversion run. Activity appears as each phase starts.'
              : 'Conversion run complete. Review details below and continue to Migration Health.'}
          </p>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          {PIPELINE_STAGES.map((s) => {
            const seen = stagesSeen.includes(s)
            const isLast = stagesSeen[stagesSeen.length - 1] === s && convert.isPending
            return (
              <span
                key={s}
                data-state={isLast ? 'active' : seen ? 'done' : 'todo'}
                className="rounded-full border border-surface-300 px-2.5 py-1 text-[10px] font-semibold text-surface-400 data-[state=active]:border-brand data-[state=active]:bg-brand/10 data-[state=active]:text-brand-dark data-[state=done]:border-brand/40 data-[state=done]:text-brand-dark"
              >
                {STAGE_LABEL[s]}
                {isLast && '…'}
              </span>
            )
          })}
        </div>
        <div className="mt-4 flex items-center gap-2 text-sm">
          <label htmlFor="policyMode" className="font-semibold text-surface-700">Gate policy</label>
          <select
            id="policyMode"
            value={policyMode}
            onChange={(e) => setPolicyMode(e.target.value as 'advisory' | 'strict' | 'release_candidate')}
            className="rounded-lg border border-surface-200 bg-white px-2 py-1 text-sm"
            disabled={convert.isPending}
          >
            <option value="advisory">Advisory (never block)</option>
            <option value="release_candidate">Release candidate (strict parity, small parked tolerance)</option>
            <option value="strict">Strict (block on any gap)</option>
          </select>
        </div>
      </div>

      {convert.isPending && (
        <div className="mb-4 rounded-xl border border-brand-blue/20 bg-brand-blue/5 p-3 text-sm text-surface-700">
          <div className="font-semibold text-brand-blue">Background safe</div>
          <p className="mt-1">
            This run is persisted server-side. You can leave this step and return later to review the completed result.
          </p>
        </div>
      )}

      {convert.isError && (
        <div
          role="alert"
          className="mb-4 rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red"
        >
          <div className="flex items-start gap-2">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.8} />
            <div>
              <div className="font-semibold">Blocking error: conversion could not complete.</div>
              <p className="mt-1">{convert.error.message}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  className="btn-secondary !border-brand-red/30 !text-brand-red hover:!bg-brand-red/10"
                  onClick={() => convert.refetch()}
                >
                  Retry conversion
                </button>
                <button type="button" className="btn-secondary" onClick={() => setStep('connect')}>
                  Edit connection
                </button>
                <button type="button" className="btn-secondary" onClick={() => setStep('review')}>
                  View guidance
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <AgentConsole events={events} live={convert.isPending} />

      {convert.data && (
        <>
          <div className="mt-4 grid gap-3 md:grid-cols-3">
            <div className="rounded-xl border border-black/[0.06] bg-surface-50 p-3">
              <div className="text-[11px] font-bold tracking-wider text-surface-500 uppercase">Run status</div>
              <div className="mt-1 flex items-center gap-2 text-sm font-semibold text-surface-800">
                {runOutcome === 'in_progress' ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin text-brand-dark" /> In progress
                  </>
                ) : runOutcome === 'warning' ? (
                  <>
                    <AlertTriangle className="h-4 w-4 text-brand-amber" /> Completed with warnings
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="h-4 w-4 text-brand-dark" /> Completed cleanly
                  </>
                )}
              </div>
            </div>
            <div className="rounded-xl border border-black/[0.06] bg-surface-50 p-3">
              <div className="text-[11px] font-bold tracking-wider text-surface-500 uppercase">Reached stages</div>
              <div className="mt-1 text-sm font-semibold text-surface-800">{stageCount}</div>
            </div>
            <div className="rounded-xl border border-black/[0.06] bg-surface-50 p-3">
              <div className="text-[11px] font-bold tracking-wider text-surface-500 uppercase">Accepted AI repairs</div>
              <div className="mt-1 text-sm font-semibold text-surface-800">{convert.data.tier2_accepted.length}</div>
            </div>
          </div>

          {convert.data.gate_status && (
            <div className={`mt-4 rounded-xl border p-3 text-sm ${convert.data.gate_status.passed ? 'border-brand/20 bg-brand/5 text-surface-700' : 'border-brand-red/20 bg-brand-red/5 text-brand-red'}`}>
              <div className="font-semibold">
                Gate status: {convert.data.gate_status.mode} · {convert.data.gate_status.passed ? 'passed' : 'failed'}
              </div>
              <div className="mt-1 space-y-1 text-xs">
                {convert.data.gate_status.checks.map((check, idx) => (
                  <div key={`${check.name}-${idx}`}>{check.passed ? '✓' : '✗'} {check.name}: {check.detail}</div>
                ))}
              </div>
              {!convert.data.gate_status.passed && (
                <div className="mt-3 flex flex-wrap gap-2">
                  <button type="button" className="btn-secondary" onClick={() => setStep('review')}>
                    View guidance
                  </button>
                  <button type="button" className="btn-primary" onClick={() => setStep('preview')}>
                    Continue with caveats
                  </button>
                </div>
              )}
            </div>
          )}

          {convert.data.tier2_accepted.length > 0 && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-brand/20 bg-brand/5 p-3 text-xs text-surface-700">
              <Bot className="mt-0.5 h-4 w-4 shrink-0 text-brand-dark" strokeWidth={1.8} />
              <span>
                <strong>AI-assisted measures</strong> (execution-verified before acceptance):{' '}
                {convert.data.tier2_accepted.join(', ')}
              </span>
            </div>
          )}

          <button
            onClick={() => setStep('review')}
            className="btn-primary mt-6 inline-flex items-center gap-2"
          >
            View Migration Health
            <ArrowRight className="h-4 w-4" strokeWidth={2} />
          </button>
        </>
      )}
    </section>
  )
}
