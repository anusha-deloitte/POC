"""Regression tests against the real MedicalCostCommandCenter fixture."""

from pathlib import Path

import pytest

from app.parsers.bundle import load_pbip

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


@pytest.fixture(scope="module")
def bundle():
    return load_pbip(FIXTURE)


def test_model_shape(bundle):
    m = bundle.model
    assert len(m.tables) == 10
    assert sum(len(t.measures) for t in m.tables) == 71
    assert len(m.relationships) == 12
    # measure table pattern: all DAX in _Measures
    measures_table = m.table("_Measures")
    assert measures_table is not None
    assert len(measures_table.measures) == 71


def test_report_shape(bundle):
    r = bundle.report
    assert [p.display_name for p in r.pages] == [
        "1. Executive Summary",
        "2. Utilization & Cost Drivers",
        "3. Provider Network",
        "4. Membership, Risk & Quality",
    ]
    assert sum(len(p.visuals) for p in r.pages) == 63


def test_no_warnings(bundle):
    assert bundle.warnings == []


def test_snowflake_parameters_extracted(bundle):
    exprs = bundle.model.expressions
    assert "myorg-account123.snowflakecomputing.com" in exprs["SnowflakeServer"]
    assert "SNOWFLAKE_FINOPS_DASHBOARD__WH" in exprs["SnowflakeWarehouse"]
    assert "SNOWFLAKE_FINOPS_DASHBOARD__DB" in exprs["SnowflakeDatabase"]
    assert "SNOWFLAKE_FINOPS_DASHBOARD__ROLE" in exprs["SnowflakeRole"]


def test_partition_m_has_schema_and_object(bundle):
    mv = bundle.model.table("MV_MEDICAL_COST_SUMMARY")
    src = mv.partitions[0].expression
    assert 'Name = "PBI_HEALTH_ANALYTICS", Kind = "Schema"' in src
    assert 'Name = "MV_MEDICAL_COST_SUMMARY", Kind = "View"' in src


def test_fenced_multiline_measure(bundle):
    _, m = bundle.model.find_measure("Average Risk Score")
    assert m.expression == "AVERAGE(DT_TOTAL_COST_OF_CARE[AVG_RISK_SCORE])"
    _, avg_members = bundle.model.find_measure("Average Members")
    assert "DISTINCTCOUNT" in avg_members.expression
    assert "DIVIDE" in avg_members.expression


def test_culture_info_tolerated(bundle):
    # cultures/en-US.tmdl contains cultureInfo + linguisticMetadata; must not break
    assert bundle.model.culture == "en-US"


def test_visual_projection_fields_resolve_against_model(bundle):
    """Every measure a visual references must exist in the model."""
    missing = []
    for page in bundle.report.pages:
        for visual in page.visuals:
            for f in visual.fields:
                if f.is_measure and f.name and bundle.model.find_measure(f.name) is None:
                    missing.append((page.name, visual.name, f.name))
    assert missing == []
