import { readErrorDetail } from '../api/client'

const BASE = '/api/v1'

export interface GovernanceComment {
  author: string
  body: string
  created_at: number
}

export interface GovernanceDecision {
  decision: 'open' | 'approved' | 'rejected' | 'promoted' | 'needs_info'
  comment?: string | null
  owner?: string | null
  decided_at: number
}

export interface GovernanceReview {
  id: string
  subject_kind: 'visual' | 'measure' | 'page' | 'model'
  subject_id: string
  title: string
  summary: string
  recommendation: string
  severity: 'high' | 'medium' | 'low'
  confidence: number
  status: 'open' | 'approved' | 'rejected' | 'promoted' | 'needs_info'
  comments: GovernanceComment[]
  decision?: GovernanceDecision | null
  remediation_history?: GovernanceRemediationResult[]
  qa_history?: GovernanceQuestionAnswer[]
  provenance: Record<string, unknown>
  impact: Record<string, unknown>
  created_at: number
  updated_at: number
}

export interface GovernanceQuestionAnswer {
  question: string
  answer: string
  owner?: string | null
  asked_at: number
}

export interface GovernanceSummary {
  model: {
    name: string
    version: string
    data_version?: string | null
    identity_execution_mode: string
    semantic_views: string[]
    tables: number
    relationships: number
    measures: number
    domains: Record<string, number>
    lifecycle: string
  }
  review: {
    total: number
    open: number
    approved: number
    rejected: number
    promoted: number
    needs_info: number
  }
  compare_history: Array<{
    page: string
    display_name?: string | null
    similarity?: number | null
    finding_count: number
    compared_at?: number | null
    filters_applied: { slicer: string; value: string | number }[]
  }>
  promotion_history: Array<Record<string, unknown>>
  model_lifecycle: {
    state: string
    version?: string | null
    data_version?: string | null
    owner?: string | null
    reason?: string | null
    changed_at?: number | null
  }
  gate_status?: {
    mode: 'advisory' | 'strict' | 'release_candidate'
    passed: boolean
    checks: Array<{ name: string; passed: boolean; detail: string }>
    generated_at: number
  } | null
  policy_mode?: 'advisory' | 'strict' | 'release_candidate' | null
}

export interface GovernanceWorkspace {
  summary: GovernanceSummary
  reviews: GovernanceReview[]
  history: Array<Record<string, unknown>>
  model: GovernanceSummary['model']
  compare_history: GovernanceSummary['compare_history']
  model_lifecycle: GovernanceSummary['model_lifecycle']
}

export interface GovernanceRemediationResult {
  review_id: string
  subject_id: string
  instruction: string
  applied_override: Record<string, unknown>
  fixed: boolean
  status: string
  summary: string
  visual_checks: Array<{ name: string; status: string; detail: string }>
  owner?: string | null
  history: Array<Record<string, unknown>>
  executed_at: number
}

export interface SemanticTraceability {
  preview: {
    view_name: string
    spec: Record<string, unknown>
    pbi_model: {
      name: string
      table_count: number
      relationship_count: number
      measure_count: number
      tables: Array<{ name: string; columns: number; measures: number }>
    }
    snowflake_view: {
      name: string
      tables: Array<{
        name: string
        base_table: Record<string, unknown>
        dimension_count: number
        metric_count: number
      }>
    }
    measure_translation?: {
      pbi_measure_total: number
      translated_measure_total: number
      untranslated_measure_total: number
      translation_rate: number
      translated_by_tier: Record<string, number>
      untranslated: Array<{ table?: string; measure: string; reason: string }>
    }
    source_target_mappings?: Array<{
      pbi_table: string
      status: 'mapped' | 'unmapped' | 'skipped' | 'materialization_required'
      snowflake_table?: string
      strategy?: 'view' | 'dynamic_table' | 'table' | string
      reason?: string
    }>
    materializations?: Array<{
      table: string
      strategy: 'view' | 'dynamic_table' | 'table' | string
      detail?: string | null
      sql?: string | null
    }>
    materialization_refresh?: {
      status: 'materialized' | 'semantic_view_only' | 'pending_materialization' | 'pending_deploy' | 'not_deployed'
      owner?: string | null
      last_refreshed_at?: number | null
      materialization_count: number
    }
    binding_summary?: {
      resolved: number
      virtual: number
      materialization_required: number
      materialization_by_strategy?: Record<string, number>
      unresolved: number
    }
    query_execution?: {
      primary_path: string
      fallback_path: string
      notes?: string
    }
    yaml: string
    table_count: number
    relationship_count: number
    metric_count: number
    dimension_count: number
  }
  semantic_view_location?: string | null
  semantic_view_creation_mode?: string
  latest: null | {
    deployed_at: number
    database: string
    schema_name: string
    view_name: string
    fully_qualified_view: string
    dry_run: boolean
    create_or_alter: boolean
    message: string
    yaml: string
    table_count: number
    relationship_count: number
    metric_count: number
    dimension_count: number
    materialization_count?: number
    refresh_owner?: string | null
  }
  deployments: Array<Record<string, unknown>>
}

export interface GovernanceImpact {
  subject: GovernanceReview
  impact: Record<string, unknown>
  provenance: Record<string, unknown>
}

export interface GovernanceProvenance {
  subject: GovernanceReview | Record<string, unknown>
  provenance: {
    nodes: Array<Record<string, unknown>>
    edges: Array<Record<string, unknown>>
    [k: string]: unknown
  }
}

async function readJson<T>(response: Response): Promise<T> {
  if (!response.ok) throw new Error(await readErrorDetail(response))
  return response.json()
}

export async function fetchGovernanceWorkspace(conversionId: string): Promise<GovernanceWorkspace> {
  return readJson(await fetch(`${BASE}/conversions/${conversionId}/governance`))
}

export async function fetchGovernanceHistory(conversionId: string): Promise<GovernanceWorkspace> {
  return readJson(await fetch(`${BASE}/conversions/${conversionId}/governance/history`))
}

export async function fetchGovernanceImpact(
  conversionId: string,
  subjectKind: string,
  subjectId: string,
): Promise<GovernanceImpact> {
  return readJson(
    await fetch(
      `${BASE}/conversions/${conversionId}/governance/impact/${subjectKind}/${encodeURIComponent(subjectId)}`,
    ),
  )
}

export async function fetchGovernanceProvenance(
  conversionId: string,
  subjectKind: string,
  subjectId: string,
): Promise<GovernanceProvenance> {
  return readJson(
    await fetch(
      `${BASE}/conversions/${conversionId}/governance/provenance/${subjectKind}/${encodeURIComponent(subjectId)}`,
    ),
  )
}

export async function decideGovernanceReview(
  conversionId: string,
  reviewId: string,
  decision: 'approved' | 'rejected' | 'promoted' | 'needs_info',
  comment?: string,
  owner?: string,
): Promise<{ review_id: string; decision: GovernanceDecision }> {
  return readJson(
    await fetch(`${BASE}/conversions/${conversionId}/governance/reviews/${reviewId}/decision`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ decision, comment: comment || null, owner: owner || null }),
    }),
  )
}

export async function commentGovernanceReview(
  conversionId: string,
  reviewId: string,
  body: string,
  author = 'reviewer',
): Promise<{ review_id: string; comment: GovernanceComment }> {
  return readJson(
    await fetch(`${BASE}/conversions/${conversionId}/governance/reviews/${reviewId}/comments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ author, body }),
    }),
  )
}

export async function remediateGovernanceReview(
  conversionId: string,
  reviewId: string,
  payload: { connection_id: string; instruction: string; owner?: string },
): Promise<GovernanceRemediationResult> {
  return readJson(
    await fetch(`${BASE}/conversions/${conversionId}/governance/reviews/${reviewId}/remediate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }),
  )
}

export async function askGovernanceReview(
  conversionId: string,
  reviewId: string,
  payload: { question: string; owner?: string },
): Promise<{
  review_id: string
  question: string
  answer: string
  asked_at: number
  history: GovernanceQuestionAnswer[]
}> {
  return readJson(
    await fetch(`${BASE}/conversions/${conversionId}/governance/reviews/${reviewId}/ask`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }),
  )
}

export async function fetchSemanticTraceability(
  conversionId: string,
): Promise<SemanticTraceability> {
  return readJson(await fetch(`${BASE}/conversions/${conversionId}/semantic-traceability`))
}

export async function deploySemanticYaml(
  conversionId: string,
  payload: {
    connection_id: string
    database?: string
    schema_name?: string
    view_name?: string
    yaml_override: string
    dry_run?: boolean
    create_or_alter?: boolean
  },
): Promise<{ success: boolean; partial_success?: boolean; message: string; view_name: string; yaml: string; warnings?: string[]; materializations?: Array<Record<string, unknown>> }> {
  return readJson(
    await fetch(`${BASE}/conversions/${conversionId}/deploy-semantic-view`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }),
  )
}

export async function fetchGovernanceLifecycle(
  conversionId: string,
): Promise<GovernanceSummary['model_lifecycle']> {
  return readJson(await fetch(`${BASE}/conversions/${conversionId}/governance/lifecycle`))
}

export async function updateGovernanceLifecycle(
  conversionId: string,
  action: 'promote' | 'demote' | 'block',
  owner?: string,
  reason?: string,
): Promise<GovernanceSummary['model_lifecycle']> {
  return readJson(
    await fetch(`${BASE}/conversions/${conversionId}/governance/lifecycle`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, owner: owner || null, reason: reason || null }),
    }),
  )
}
