"""prune_spec_to_live_schema: drop spec elements referencing columns that do
not exist in the live Snowflake schema (e.g. unapplied M Table.Group outputs
like DIM_SERVICE_LINE.CARE_FAMILY_COUNT)."""

import copy
from pathlib import Path

from app.binding.resolver import build_binding_map
from app.parsers.bundle import load_pbip
from app.semantic.yaml_compiler import SemanticViewYamlCompiler, prune_spec_to_live_schema

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


class _FakeCursor:
    """INFORMATION_SCHEMA.COLUMNS stub keyed on (schema, table)."""

    def __init__(self, columns: dict[tuple[str, str], list[str]]):
        self._columns = columns
        self._rows: list[tuple[str]] = []

    def execute(self, _sql: str, params: tuple[str, str] | None = None):
        schema, table = params
        self._rows = [(c,) for c in self._columns.get((schema, table), [])]

    def fetchall(self):
        return self._rows


def _spec() -> dict:
    return {
        "name": "MODEL_SV",
        "tables": [
            {
                "name": "DIM_SERVICE_LINE",
                "base_table": {
                    "database": "DB",
                    "schema": "SCH",
                    "table": "DIM_SERVICE_LINE",
                },
                "dimensions": [
                    {"name": "SERVICE_LINE_GROUP", "expr": "DIM_SERVICE_LINE.SERVICE_LINE_GROUP"},
                    {"name": "CARE_FAMILY_COUNT", "expr": "DIM_SERVICE_LINE.CARE_FAMILY_COUNT"},
                ],
                "metrics": [
                    {"name": "Care Families", "expr": "SUM(DIM_SERVICE_LINE.CARE_FAMILY_COUNT)"},
                    {"name": "Groups", "expr": "COUNT(DIM_SERVICE_LINE.SERVICE_LINE_GROUP)"},
                ],
                "primary_key": {"columns": ["SERVICE_LINE_GROUP"]},
            },
            {
                "name": "FACT",
                "base_table": {"database": "DB", "schema": "SCH", "table": "FACT"},
                "dimensions": [{"name": "K", "expr": "FACT.K"}],
            },
        ],
        "relationships": [
            {
                "name": "ok_rel",
                "left_table": "FACT",
                "right_table": "DIM_SERVICE_LINE",
                "relationship_columns": [
                    {"left_column": "K", "right_column": "SERVICE_LINE_GROUP"}
                ],
            },
            {
                "name": "bad_rel",
                "left_table": "FACT",
                "right_table": "DIM_SERVICE_LINE",
                "relationship_columns": [
                    {"left_column": "K", "right_column": "CARE_FAMILY_COUNT"}
                ],
            },
        ],
        "metrics": [
            {"name": "Top Care", "expr": "SUM(DIM_SERVICE_LINE.CARE_FAMILY_COUNT)"},
            {"name": "Top Groups", "expr": "COUNT(FACT.K)"},
        ],
    }


_LIVE = {
    ("SCH", "DIM_SERVICE_LINE"): ["SERVICE_LINE_GROUP", "CARE_SETTING"],
    ("SCH", "FACT"): ["K"],
}


def test_prunes_missing_column_references():
    spec, warnings = prune_spec_to_live_schema(_spec(), _FakeCursor(_LIVE))

    dims = [d["name"] for d in spec["tables"][0]["dimensions"]]
    assert dims == ["SERVICE_LINE_GROUP"]
    metrics = [m["name"] for m in spec["tables"][0]["metrics"]]
    assert metrics == ["Groups"]
    assert [r["name"] for r in spec["relationships"]] == ["ok_rel"]
    assert [m["name"] for m in spec["metrics"]] == ["Top Groups"]
    assert spec["tables"][0]["primary_key"] == {"columns": ["SERVICE_LINE_GROUP"]}
    assert any("CARE_FAMILY_COUNT" in w for w in warnings)


def test_prunes_primary_key_when_missing():
    raw = _spec()
    raw["tables"][0]["primary_key"] = {"columns": ["CARE_FAMILY_COUNT"]}
    spec, warnings = prune_spec_to_live_schema(raw, _FakeCursor(_LIVE))
    assert "primary_key" not in spec["tables"][0]
    assert any("primary_key" in w for w in warnings)


def test_noop_when_all_columns_live():
    full = {
        ("SCH", "DIM_SERVICE_LINE"): [
            "SERVICE_LINE_GROUP",
            "CARE_FAMILY_COUNT",
            "CARE_SETTING",
        ],
        ("SCH", "FACT"): ["K"],
    }
    raw = _spec()
    expected = copy.deepcopy(raw)
    spec, warnings = prune_spec_to_live_schema(raw, _FakeCursor(full))
    assert warnings == []
    assert spec == expected


def test_introspection_failure_skips_pruning_for_table():
    class _BoomCursor(_FakeCursor):
        def execute(self, _sql, params=None):
            if params and params[1] == "DIM_SERVICE_LINE":
                raise RuntimeError("no access")
            super().execute(_sql, params)

    spec, warnings = prune_spec_to_live_schema(_spec(), _BoomCursor(_LIVE))
    # unknown live schema for the table -> nothing pruned from it
    dims = [d["name"] for d in spec["tables"][0]["dimensions"]]
    assert "CARE_FAMILY_COUNT" in dims


def test_relationship_ref_keys_declared_unique():
    """Snowflake requires the referenced side of a relationship to be the PK or
    a declared unique key. DIM_MONTH's PK is MONTH_START_DATE but relationships
    reference YEAR_MONTH_NBR -> compiler must emit unique_keys for it."""
    bundle = load_pbip(FIXTURE)
    compiler = SemanticViewYamlCompiler(bundle.model, build_binding_map(bundle.model))
    spec = compiler.compile()

    tables = {t["name"]: t for t in spec["tables"]}
    dim_month = tables["DIM_MONTH"]
    pk = (dim_month.get("primary_key") or {}).get("columns", [])
    assert pk == ["MONTH_START_DATE"]
    uks = [sorted(uk["columns"]) for uk in dim_month.get("unique_keys", [])]
    assert ["YEAR_MONTH_NBR"] in uks

    # every relationship's referenced columns are the PK or a declared unique key
    for rel in spec.get("relationships", []):
        tspec = tables[rel["right_table"]]
        ref = sorted(p["right_column"].upper() for p in rel["relationship_columns"])
        pk_cols = sorted(
            c.upper() for c in (tspec.get("primary_key") or {}).get("columns", [])
        )
        uk_sets = [
            sorted(c.upper() for c in uk.get("columns", []))
            for uk in tspec.get("unique_keys", [])
        ]
        assert ref == pk_cols or ref in uk_sets, (rel["name"], ref)
