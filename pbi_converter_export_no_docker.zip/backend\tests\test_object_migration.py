"""Smart object mapping: views→views, indexed views→snapshots, procs→procedures."""

from app.services.object_migration import (
    transpile_procedure,
    transpile_view_definition,
)

SCHEMA_MAP = {"PBI": "TGT", "DW": "TGT__DW"}

VIEW_DDL = """
CREATE VIEW PBI.DIM_LOB
WITH SCHEMABINDING
AS
SELECT LOB_CODE, LOB_NAME,
    CAST(MAX(CAST(IS_GOV AS tinyint)) AS BIT) AS IS_GOV,
    COUNT_BIG(*) AS N
FROM DW.DIM_PLAN
GROUP BY LOB_CODE, LOB_NAME;
"""

PROC_DDL = """
CREATE PROCEDURE PBI.usp_Refresh
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;
    DELETE FROM PBI.DT_SUMMARY;
    INSERT INTO PBI.DT_SUMMARY (A, B)
    SELECT LOB_CODE, ISNULL(SUM(X) / NULLIF(SUM(Y), 0), 0)
    FROM DW.FACT GROUP BY LOB_CODE;
    UPDATE STATISTICS PBI.DT_SUMMARY;
END
"""


class TestViewTranspile:
    def test_schemabinding_stripped_and_fully_qualified(self):
        ddl = transpile_view_definition(
            VIEW_DDL, "sqlserver", SCHEMA_MAP, "MYDB", "TGT", "DIM_LOB"
        )
        assert ddl.startswith('CREATE OR REPLACE VIEW "MYDB"."TGT"."DIM_LOB"')
        assert "SCHEMABINDING" not in ddl.upper()
        # base schema remapped and fully qualified with database
        assert '"MYDB"."TGT__DW"' in ddl
        assert "DIM_PLAN" in ddl

    def test_tsql_specifics_translated(self):
        ddl = transpile_view_definition(
            VIEW_DDL, "sqlserver", SCHEMA_MAP, "MYDB", "TGT", "DIM_LOB"
        )
        up = ddl.upper()
        # COUNT_BIG is T-SQL only; tinyint cast survives as a Snowflake-legal cast
        assert "COUNT_BIG" not in up
        assert "COUNT(*)" in up


class TestProcTranspile:
    def test_proc_transpiles_and_qualifies(self):
        out = transpile_procedure(PROC_DDL, "sqlserver", SCHEMA_MAP, "MYDB", "TGT")
        assert out is not None
        name, sql = out
        assert name == "usp_Refresh"
        up = sql.upper()
        assert 'CREATE OR REPLACE PROCEDURE "MYDB"."TGT"."USP_REFRESH"()' in up
        assert "LANGUAGE SQL" in up
        # session settings and UPDATE STATISTICS stripped
        assert "NOCOUNT" not in up
        assert "STATISTICS" not in up
        # ISNULL -> COALESCE (or IFNULL) in snowflake dialect
        assert "ISNULL" not in up
        # schema remap applied inside DML
        assert '"MYDB"."TGT__DW"."FACT"' in sql or '"MYDB"."TGT__DW".FACT' in sql.upper()
