import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  ArrowLeft,
  BookOpen,
  Check,
  LayoutGrid,
  Loader2,
  MapPin,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react'
import { useEffect, useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import {
  acceptReimagineVariant,
  buildReimagineVariant,
  fetchDashboardSpec,
  fetchReimagineBuilt,
  fetchReimagineLatest,
  fetchVisualData,
  generateReimagineRecommendation,
  type MappingEntry,
} from '../dashboard/api'
import { PageCanvas } from '../dashboard/PageCanvas'
import {
  buildVisualQueryFilters,
  emptyInteractionState,
  resolveVisualInteractions,
} from '../dashboard/interactions'
import { ThemeProvider } from '../dashboard/theme'
import type { FilterClause, InteractionState, PageSpec, VisualSpec } from '../dashboard/types'

type Side = 'original' | 'reimagined'

/** Full-viewport before/after studio: flip between the faithful conversion and
 * the reimagined variant with synced page + slicer state, per-visual lineage,
 * and the zero-loss coverage proof gating Accept. */
export function ReimagineStudio() {
  const { conversionId = '', connectionId: routeConnectionId = '' } = useParams()
  // resilient to sidebar links without a connection segment
  const connectionId = routeConnectionId || localStorage.getItem('pbic.connection_id') || ''
  const qc = useQueryClient()
  const [side, setSide] = useState<Side>('reimagined')
  const [pageIdx, setPageIdx] = useState(0)
  const [slicerState, setSlicerState] = useState<Record<string, (string | number)[]>>({})
  const [interactionState, setInteractionState] = useState<InteractionState>(emptyInteractionState())
  const [selectedVisual, setSelectedVisual] = useState<string | null>(null)
  const [showArchitecture, setShowArchitecture] = useState(false)
  const [showBrief, setShowBrief] = useState(false)
  const [error, setError] = useState('')

  const original = useQuery({
    queryKey: ['dash-spec', conversionId],
    queryFn: () => fetchDashboardSpec(conversionId),
  })
  const built = useQuery({
    queryKey: ['reimagine-built', conversionId],
    queryFn: () => fetchReimagineBuilt(conversionId),
    retry: false,
  })
  const recommendation = useQuery({
    queryKey: ['dashboard-recommendation', conversionId],
    queryFn: () => fetchReimagineLatest(conversionId),
    enabled: !!conversionId,
  })

  const build = useMutation({
    // one click does the whole thing: analysis first (if missing), then variant
    mutationFn: async () => {
      const rec = await fetchReimagineLatest(conversionId)
      if (!rec) {
        if (!connectionId) throw new Error('No connection available for analysis.')
        await generateReimagineRecommendation(conversionId, connectionId, 'live')
      }
      return buildReimagineVariant(conversionId)
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['reimagine-built', conversionId] })
      qc.invalidateQueries({ queryKey: ['dashboard-recommendation', conversionId] })
    },
    onError: (e) => setError((e as Error).message),
  })
  const accept = useMutation({
    mutationFn: () => acceptReimagineVariant(conversionId, 'latest', 'accepted in studio'),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['reimagine-built', conversionId] }),
    onError: (e) => setError((e as Error).message),
  })

  const spec = side === 'original' ? original.data : built.data?.spec
  const pages = spec?.pages ?? []
  const page: PageSpec | undefined = pages[pageIdx] ?? pages[0]

  // slicer filters + click cross-filters (interaction graph) -> every visual
  const slicerFilters = useMemo(() => {
    if (!page) return {}
    const clauses = Object.entries(slicerState)
      .map(([name, values]) => {
        const slicer = page.visuals.find((v) => v.name === name)
        if (!slicer?.slicer_target || !values.length) return null
        return { table: slicer.slicer_target.table, column: slicer.slicer_target.column, values }
      })
      .filter(Boolean) as FilterClause[]
    const graph = spec?.interaction_graph ?? { nodes: [], edges: [], sync_groups: {} }
    const byVisual = buildVisualQueryFilters(page, graph, interactionState, clauses)
    // a slicer must never filter its own domain query
    for (const v of page.visuals) {
      if (v.slicer_target && byVisual[v.name]) {
        byVisual[v.name] = byVisual[v.name].filter(
          (c) => !(c.table === v.slicer_target!.table && c.column === v.slicer_target!.column),
        )
      }
    }
    return byVisual
  }, [page, slicerState, interactionState, spec])

  const visualInteractions = useMemo(
    () =>
      page && spec
        ? resolveVisualInteractions(
            page,
            spec.interaction_graph ?? { nodes: [], edges: [], sync_groups: {} },
            interactionState,
          )
        : undefined,
    [page, spec, interactionState],
  )
  const activeSelections = Object.entries(interactionState.selections).filter(
    ([, v]) => v.length,
  )

  const data = useQuery({
    queryKey: ['reimagine-data', conversionId, side, page?.name, slicerFilters],
    queryFn: () =>
      fetchVisualData(
        conversionId,
        connectionId,
        page!.name,
        page!.visuals.filter((v) => v.supported && v.query).map((v) => v.name),
        slicerFilters,
        'live',
        side === 'reimagined' ? 'reimagined' : undefined,
      ),
    enabled: !!page && !!connectionId && !!spec,
    placeholderData: (prev) => prev,
  })

  // keyboard: O / R / space flips
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement) return
      if (e.key === 'o' || e.key === 'O') setSide('original')
      else if (e.key === 'r' || e.key === 'R') setSide('reimagined')
      else if (e.key === ' ') {
        e.preventDefault()
        setSide((s) => (s === 'original' ? 'reimagined' : 'original'))
      } else if (e.key === 'Escape') setSelectedVisual(null)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const mapping = built.data?.mapping.entries ?? []
  const zeroLoss = built.data?.zero_loss
  const architecture = built.data?.mapping.architecture
  const mappingFor = (visual: string): MappingEntry | undefined =>
    mapping.find((m) => m.original.visual === visual)
  const selectedMapping = selectedVisual ? mappingFor(selectedVisual) : undefined

  const notBuilt = built.isError
  if (original.isLoading) return <p className="p-8 text-surface-500">Loading…</p>

  return (
    <div className="flex h-screen flex-col bg-[#0d1a3a]/[.04]">
      {/* top bar: back · page tabs · flip control */}
      <header className="flex items-center gap-3 border-b border-surface-300 bg-white px-4 py-2">
        <Link
          to="/app/convert"
          className="flex items-center gap-1 text-xs font-semibold text-surface-500 hover:text-surface-800"
        >
          <ArrowLeft size={14} /> Review
        </Link>
        <span className="flex items-center gap-1.5 text-sm font-bold">
          <Sparkles size={15} className="text-brand-dark" /> Reimagine studio
        </span>
        <nav className="ml-4 flex gap-1">
          {pages.map((p, i) => (
            <button
              key={p.name}
              onClick={() => setPageIdx(i)}
              data-active={i === pageIdx}
              className="rounded-lg px-2.5 py-1 text-xs text-surface-500 hover:bg-surface-100 data-[active=true]:bg-brand/10 data-[active=true]:font-semibold data-[active=true]:text-brand-dark"
            >
              {p.display_name}
            </button>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          {recommendation.data && (
            <button
              onClick={() => setShowBrief((s) => !s)}
              data-active={showBrief}
              data-testid="brief-button"
              className="flex items-center gap-1 rounded-lg border border-surface-300 px-2.5 py-1 text-xs font-semibold text-surface-500 hover:bg-surface-100 data-[active=true]:bg-brand/10 data-[active=true]:text-brand-dark"
            >
              <BookOpen size={12} /> Brief
            </button>
          )}
          {mapping.length > 0 && (
            <button
              onClick={() => setSelectedVisual((v) => (v ? null : mapping[0].original.visual))}
              data-active={!!selectedVisual}
              className="flex items-center gap-1 rounded-lg border border-surface-300 px-2.5 py-1 text-xs font-semibold text-surface-500 hover:bg-surface-100 data-[active=true]:bg-brand/10 data-[active=true]:text-brand-dark"
            >
              <MapPin size={12} /> Map
            </button>
          )}
          <div className="flex rounded-lg border border-surface-300 p-0.5 text-xs font-semibold">
            {(['original', 'reimagined'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setSide(s)}
                data-active={side === s}
                className="rounded-md px-3 py-1 text-surface-500 data-[active=true]:bg-brand-dark data-[active=true]:text-white"
              >
                {s === 'original' ? 'Original' : 'Reimagined'}
              </button>
            ))}
          </div>
          <span className="hidden text-[10px] text-surface-400 lg:block">O / R / space to flip</span>
        </div>
      </header>

      {/* zero-loss coverage bar */}
      {zeroLoss && (
        <div
          data-testid="coverage-bar"
          className={`flex items-center gap-4 px-4 py-1.5 text-[11px] font-medium ${
            zeroLoss.passed ? 'bg-emerald-50 text-emerald-800' : 'bg-red-50 text-red-700'
          }`}
        >
          <ShieldCheck size={13} />
          {zeroLoss.passed ? 'Zero information loss — proven' : 'Information gaps detected'}
          {Object.entries(zeroLoss.coverage).map(([k, v]) => (
            <span key={k}>
              {k.replace('_', ' ')}: <b>{v}</b> {zeroLoss.passed && '✓'}
            </span>
          ))}
          {!zeroLoss.passed && (
            <span className="truncate">{zeroLoss.gaps.slice(0, 3).join(' · ')}</span>
          )}
          {architecture && (
            <button
              data-testid="architecture-chip"
              onClick={() => setShowArchitecture((s) => !s)}
              className="ml-auto inline-flex items-center gap-1 rounded-full border border-current/30 px-2 py-0.5 font-semibold hover:bg-white/60"
            >
              <LayoutGrid size={11} />
              pages: {architecture.pages_before} → {architecture.pages_after}
              {architecture.merges.length > 0
                ? ` (${architecture.merges.length} merged)`
                : ' kept'}
              {' · why?'}
            </button>
          )}
        </div>
      )}

      {/* page-architecture evidence panel */}
      {showArchitecture && architecture && (
        <div
          data-testid="architecture-panel"
          className="border-b border-surface-300 bg-white px-4 py-2.5 text-[11px]"
        >
          <p className="font-semibold text-surface-800">
            Page architecture — analyzed, not assumed
          </p>
          <p className="mt-0.5 text-surface-600">{architecture.verdict}</p>
          {architecture.conformed_dims.length > 0 && (
            <p className="mt-1 text-surface-500">
              Conformed slicer spine (shared filter context on every page, excluded from the
              overlap signal): {architecture.conformed_dims.join(', ')}
            </p>
          )}
          <div className="mt-1.5 grid gap-1 lg:grid-cols-2">
            {architecture.pairs.map((p) => (
              <div key={p.pages.join('|')} className="rounded-lg bg-surface-100 px-2 py-1">
                <span className="font-semibold">
                  {p.pages[0]} × {p.pages[1]}
                </span>{' '}
                <span
                  className={
                    p.verdict === 'merge' ? 'text-brand-dark' : 'text-surface-500'
                  }
                >
                  · {p.verdict} · measures {Math.round(p.measure_jaccard * 100)}% shared
                </span>
                <p className="text-surface-500">{p.reason}</p>
              </div>
            ))}
          </div>
          {architecture.splits.length > 0 && (
            <p className="mt-1.5 font-medium text-amber-700">
              Split advised: {architecture.splits.map((s) => `${s.page} — ${s.reason}`).join(' · ')}
            </p>
          )}
        </div>
      )}

      {/* canvas */}
      <main className="relative flex-1 overflow-auto p-4">
        {notBuilt ? (
          <div className="mx-auto mt-24 max-w-md rounded-xl border border-surface-300 bg-white p-8 text-center">
            <Sparkles size={28} className="mx-auto text-brand-dark" />
            <h2 className="mt-3 text-base font-bold">Reimagine this report</h2>
            <p className="mt-1 text-xs text-surface-500">
              One click analyzes the report's intent and page architecture, then compiles a
              modern single-viewport redesign — every query byte-identical, proven by the
              zero-loss gate before you can accept.
            </p>
            <button
              onClick={() => build.mutate()}
              disabled={build.isPending}
              className="btn-primary mt-4 inline-flex items-center gap-2"
            >
              {build.isPending && <Loader2 size={14} className="animate-spin" />}
              {build.isPending ? 'Analyzing & building…' : 'Analyze & build redesign'}
            </button>
            {error && <p className="mt-3 text-xs text-red-600">{error}</p>}
          </div>
        ) : spec && page ? (
          <ThemeProvider value={spec.theme}>
            {/* cross-filter status strip */}
            {activeSelections.length > 0 && (
              <div className="mx-auto mb-2 flex max-w-screen-2xl flex-wrap items-center gap-2 text-[11px]">
                <span className="font-semibold text-surface-500">Cross-filters:</span>
                {activeSelections.map(([name, values]) => {
                  const v = page.visuals.find((x) => x.name === name)
                  return (
                    <button
                      key={name}
                      onClick={() =>
                        setInteractionState((s) => {
                          const selections = { ...s.selections }
                          delete selections[name]
                          return { ...s, selections }
                        })
                      }
                      className="inline-flex items-center gap-1 rounded-full border border-brand/30 bg-brand/10 px-2 py-0.5 font-medium text-brand-dark hover:bg-brand/20"
                    >
                      {v?.title ?? name}: {values.join(', ')} <X size={10} />
                    </button>
                  )
                })}
                <button
                  onClick={() => setInteractionState(emptyInteractionState())}
                  className="text-surface-400 underline hover:text-surface-600"
                >
                  clear all
                </button>
              </div>
            )}
            <div className="mx-auto max-w-screen-2xl rounded-xl border border-surface-300 bg-white p-2 shadow-sm">
              <PageCanvas
                page={page}
                results={data.data ?? {}}
                slicerState={slicerState}
                onSlicerChange={(vs: VisualSpec, values) =>
                  setSlicerState((s) => ({ ...s, [vs.name]: values }))
                }
                interactionState={interactionState}
                onInteractionChange={setInteractionState}
                visualInteractions={visualInteractions}
              />
            </div>
            <p className="mx-auto mt-1.5 max-w-screen-2xl text-[10px] text-surface-400">
              Click any bar, slice or row to cross-filter every visual on the page · click again
              to clear · open “Map” for the per-visual before/after account
            </p>
          </ThemeProvider>
        ) : (
          <p className="p-8 text-surface-500">Loading spec…</p>
        )}

        {/* design brief drawer */}
        {showBrief && recommendation.data && (
          <aside
            data-testid="brief-drawer"
            className="fixed right-0 top-[76px] bottom-[52px] z-20 w-[380px] overflow-y-auto border-l border-surface-300 bg-white p-4 shadow-xl"
          >
            <div className="flex items-start justify-between">
              <h3 className="flex items-center gap-1.5 text-sm font-bold">
                <BookOpen size={14} className="text-brand-dark" /> Design brief
              </h3>
              <button onClick={() => setShowBrief(false)} aria-label="Close brief">
                <X size={16} className="text-surface-400 hover:text-surface-700" />
              </button>
            </div>
            <div className="mt-3 space-y-3 text-xs">
              <div>
                <p className="font-semibold text-surface-800">Intent</p>
                <p className="mt-0.5 text-surface-600">
                  {recommendation.data.intent_hypothesis}
                </p>
                <p className="mt-1 text-surface-500">
                  Audience: {recommendation.data.audience}
                </p>
              </div>
              <div>
                <p className="font-semibold text-surface-800">Decision questions</p>
                <ul className="mt-0.5 space-y-1 text-surface-600">
                  {recommendation.data.decision_questions.map((q) => (
                    <li key={q}>• {q}</li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="font-semibold text-surface-800">KPI hierarchy</p>
                <ol className="mt-0.5 list-inside list-decimal space-y-1 text-surface-600">
                  {recommendation.data.kpi_hierarchy.map((k) => (
                    <li key={k}>{k}</li>
                  ))}
                </ol>
              </div>
              {recommendation.data.strategy?.length > 0 && (
                <div>
                  <p className="font-semibold text-surface-800">Strategy</p>
                  <ul className="mt-0.5 space-y-1 text-surface-600">
                    {recommendation.data.strategy.map((sN) => (
                      <li key={sN}>• {sN}</li>
                    ))}
                  </ul>
                </div>
              )}
              {recommendation.data.risks?.length > 0 && (
                <div>
                  <p className="font-semibold text-amber-700">Risks</p>
                  <ul className="mt-0.5 space-y-1 text-surface-600">
                    {recommendation.data.risks.map((r) => (
                      <li key={r}>• {r}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </aside>
        )}

        {/* mapping drawer */}
        {selectedMapping && !showBrief && (
          <aside
            data-testid="mapping-drawer"
            className="fixed right-0 top-[76px] bottom-[52px] z-20 w-[380px] overflow-y-auto border-l border-surface-300 bg-white p-4 shadow-xl"
          >
            <div className="flex items-start justify-between">
              <h3 className="flex items-center gap-1.5 text-sm font-bold">
                <MapPin size={14} className="text-brand-dark" />
                {selectedMapping.original.title ?? selectedMapping.original.visual}
              </h3>
              <button onClick={() => setSelectedVisual(null)} aria-label="Close mapping">
                <X size={16} className="text-surface-400 hover:text-surface-700" />
              </button>
            </div>
            <select
              value={selectedVisual ?? ''}
              onChange={(e) => setSelectedVisual(e.target.value)}
              className="mt-2 w-full rounded-lg border border-surface-300 px-2 py-1 text-xs"
              aria-label="Select visual mapping"
            >
              {mapping
                .filter((m) => page?.visuals.some((v) => v.name === m.original.visual))
                .map((m) => (
                  <option key={m.original.visual} value={m.original.visual}>
                    {m.original.title ?? m.original.visual} · {m.change_kind}
                  </option>
                ))}
            </select>
            <div className="mt-3 space-y-3 text-xs">
              <div className="rounded-lg bg-surface-100 p-2.5">
                <p className="font-semibold text-surface-500">Was (Power BI)</p>
                <p className="mt-0.5">
                  {selectedMapping.original.type} · {selectedMapping.original.region}
                </p>
              </div>
              <div className="rounded-lg bg-brand/5 p-2.5">
                <p className="font-semibold text-brand-dark">Now (Reimagined)</p>
                <p className="mt-0.5">
                  {selectedMapping.reimagined.type} · {selectedMapping.reimagined.region} ·{' '}
                  <span className="rounded bg-brand/10 px-1 font-semibold">
                    {selectedMapping.change_kind}
                  </span>
                </p>
              </div>
              <p className="text-surface-600">{selectedMapping.rationale}</p>
              <div>
                <p className="font-semibold">Information account</p>
                <ul className="mt-1 space-y-0.5">
                  <li className="text-emerald-700">
                    ✓ {selectedMapping.original.measures.length} measures ·{' '}
                    {selectedMapping.original.dims.length} dimensions — all preserved
                  </li>
                  {selectedMapping.information_delta.relocated.map((r) => (
                    <li key={r} className="text-sky-700">
                      ↳ {r}
                    </li>
                  ))}
                  {selectedMapping.information_delta.added.map((a) => (
                    <li key={a} className="text-brand-dark">
                      + {a} (added)
                    </li>
                  ))}
                  {selectedMapping.information_delta.missing.map((m) => (
                    <li key={m} className="font-semibold text-red-600">
                      ✗ missing: {m}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </aside>
        )}
      </main>

      {/* accept bar */}
      {built.data && (
        <footer className="flex items-center gap-3 border-t border-surface-300 bg-white px-4 py-2">
          <span className="text-xs text-surface-500">
            {mapping.length} visuals mapped · every query byte-identical to the original
          </span>
          {error && <span className="truncate text-xs text-red-600">{error}</span>}
          <button
            onClick={() => accept.mutate()}
            disabled={!zeroLoss?.passed || accept.isPending || accept.isSuccess}
            className="btn-primary ml-auto inline-flex items-center gap-2 disabled:opacity-50"
            title={zeroLoss?.passed ? '' : 'Blocked: zero-loss gate failed'}
          >
            {accept.isPending ? (
              <Loader2 size={14} className="animate-spin" />
            ) : (
              <Check size={14} />
            )}
            {accept.isSuccess ? 'Accepted' : 'Accept reimagined design'}
          </button>
        </footer>
      )}
    </div>
  )
}
