from app.ir.model import (
    ExecutionIdentityMode,
    Measure,
    MeasureSemanticBinding,
    SemanticModel,
    SemanticViewLifecycle,
)
from app.runtime.semantic_governance import QueryExecutionTier, cache_key, trace_codes


def test_cache_key_changes_with_scope_and_versions():
    sql = "select 1"
    k1 = cache_key(
        conversion_id="c1",
        mode="live",
        sql=sql,
        tier=QueryExecutionTier.TIER_A_NATIVE,
        row_scope_id="scope-a",
        model_version="m1",
        data_version="d1",
    )
    k2 = cache_key(
        conversion_id="c1",
        mode="live",
        sql=sql,
        tier=QueryExecutionTier.TIER_A_NATIVE,
        row_scope_id="scope-b",
        model_version="m1",
        data_version="d1",
    )
    assert k1 != k2



def test_trace_codes_extract_overlay_codes():
    warnings = [
        "[OVERLAY:UNREACHABLE_FILTER] filter ignored",
        "plain warning",
        "[OVERLAY:TIER2_MEASURE] tier2 used",
    ]
    assert trace_codes(warnings) == ["UNREACHABLE_FILTER", "TIER2_MEASURE"]



def test_semantic_model_has_governance_defaults():
    model = SemanticModel(name="X")
    assert model.identity_execution_mode == ExecutionIdentityMode.SERVICE_ACCOUNT
    assert model.model_version == "v1"
    assert model.semantic_views == []



def test_measure_supports_semantic_binding():
    m = Measure(
        name="Revenue",
        expression="SUM(Sales[Revenue])",
        semantic_binding=MeasureSemanticBinding(
            semantic_view="finance_revenue_sv",
            metric_id="revenue",
            lifecycle=SemanticViewLifecycle.CERTIFIED,
            confidence=0.98,
        ),
    )
    assert m.semantic_binding is not None
    assert m.semantic_binding.semantic_view == "finance_revenue_sv"
    assert m.semantic_binding.lifecycle == SemanticViewLifecycle.CERTIFIED
