import { useMemo, useState } from 'react'
import { formatValue } from '../format'
import { usePalette, useThemeTokens } from '../theme'
import type { VisualResult, VisualSpec } from '../types'

interface LevelNode {
  name: string
  value: number
}

/** Faithful decomposition-tree layout: a root total on the left, then one
 * column of proportional bars per Explain-By level; clicking a bar drills the
 * next level into that member (PBI interaction model). */
export function DecompositionTree({
  spec,
  data,
  onSelect,
}: {
  spec: VisualSpec
  data?: VisualResult
  onSelect?: (values: (string | number)[]) => void
}) {
  const palette = usePalette()
  const theme = useThemeTokens()
  const [drill, setDrill] = useState<string | null>(null)

  const mKey = spec.measure_keys[0]
  const fmt = spec.measure_formats[mKey]
  const d0 = spec.dim_keys[0]
  const d1 = spec.dim_keys[1]

  const model = useMemo(() => {
    if (!data || data.error) return null
    const mi = data.columns.indexOf(mKey)
    const i0 = data.columns.indexOf(d0)
    const i1 = d1 ? data.columns.indexOf(d1) : -1
    if (mi < 0 || i0 < 0) return null

    const level1 = new Map<string, number>()
    const level2 = new Map<string, Map<string, number>>()
    let total = 0
    for (const row of data.rows) {
      const a = String(row[i0] ?? '—')
      const v = Number(row[mi] ?? 0)
      total += v
      level1.set(a, (level1.get(a) ?? 0) + v)
      if (i1 >= 0) {
        const b = String(row[i1] ?? '—')
        const sub = level2.get(a) ?? new Map<string, number>()
        sub.set(b, (sub.get(b) ?? 0) + v)
        level2.set(a, sub)
      }
    }
    const sorted = (m: Map<string, number>): LevelNode[] =>
      [...m.entries()].map(([name, value]) => ({ name, value })).sort((x, y) => y.value - x.value)
    return { total, level1: sorted(level1), level2 }
  }, [data, mKey, d0, d1])

  if (!data) return <div className="p-2 text-xs text-surface-400">…</div>
  if (data.error) return <div className="p-2 text-xs text-brand-red">{data.error}</div>
  if (!model) return <div className="p-2 text-xs text-surface-400">No breakdown data.</div>

  const active = drill && model.level2.has(drill) ? drill : model.level1[0]?.name
  const level2Nodes: LevelNode[] = active
    ? [...(model.level2.get(active) ?? new Map<string, number>()).entries()]
        .map(([name, value]) => ({ name, value }))
        .sort((x, y) => y.value - x.value)
    : []
  const label0 = (d0 ?? '').split('.').pop()
  const label1 = (d1 ?? '').split('.').pop()
  const max1 = model.level1[0]?.value || 1
  const max2 = level2Nodes[0]?.value || 1

  const Bar = ({
    node,
    max,
    color,
    selected,
    onClick,
  }: {
    node: LevelNode
    max: number
    color: string
    selected?: boolean
    onClick?: () => void
  }) => (
    <button
      type="button"
      onClick={onClick}
      className={`group block w-full rounded-sm px-1 py-0.5 text-left transition ${
        selected ? 'bg-brand/10 ring-1 ring-brand/40' : 'hover:bg-surface-100'
      }`}
    >
      <span className="flex items-baseline justify-between gap-1 text-[9px] leading-tight">
        <span className="truncate font-medium" style={{ color: theme.foreground }}>
          {node.name}
        </span>
        <span className="shrink-0 tabular-nums text-surface-500">{formatValue(node.value, fmt)}</span>
      </span>
      <span className="mt-0.5 block h-1.5 w-full rounded-sm bg-surface-200">
        <span
          className="block h-full rounded-sm"
          style={{ width: `${Math.max((node.value / max) * 100, 2)}%`, background: color }}
        />
      </span>
    </button>
  )

  return (
    <div className="flex h-full w-full gap-2 overflow-hidden p-1">
      <div className="flex w-1/4 min-w-[90px] flex-col justify-center rounded-md border border-surface-300 bg-surface-100 p-2">
        <span className="text-[9px] uppercase tracking-wide text-surface-500">{mKey}</span>
        <span className="text-base font-bold" style={{ color: theme.foreground }}>
          {formatValue(model.total, fmt)}
        </span>
      </div>
      <div className="flex w-[37%] flex-col overflow-y-auto">
        <span className="mb-0.5 shrink-0 text-[9px] font-semibold uppercase tracking-wide text-surface-500">
          {label0}
        </span>
        {model.level1.map((node) => (
          <Bar
            key={node.name}
            node={node}
            max={max1}
            color={palette[0]}
            selected={node.name === active}
            onClick={() => {
              setDrill(node.name)
              onSelect?.([node.name])
            }}
          />
        ))}
      </div>
      {d1 && (
        <div className="flex w-[37%] flex-col overflow-y-auto">
          <span className="mb-0.5 shrink-0 truncate text-[9px] font-semibold uppercase tracking-wide text-surface-500">
            {label1} · {active}
          </span>
          {level2Nodes.map((node) => (
            <Bar key={node.name} node={node} max={max2} color={palette[1] ?? palette[0]} />
          ))}
        </div>
      )}
    </div>
  )
}
