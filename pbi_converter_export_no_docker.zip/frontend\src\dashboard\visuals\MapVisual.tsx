import type { EChartsOption } from 'echarts'
import * as echarts from 'echarts'
import { useEffect, useState } from 'react'
import { formatValue } from '../format'
import { usePalette, useThemeTokens } from '../theme'
import type { VisualResult, VisualSpec } from '../types'
import { EChart } from './EChart'

let usMapRegistered = false
async function ensureUsMap(): Promise<void> {
  if (usMapRegistered) return
  const geo = await (await fetch('/us-states.geo.json')).json()
  echarts.registerMap('USA', geo)
  usMapRegistered = true
}

/** filledMap -> ECharts choropleth over public-domain US states GeoJSON.
 *  Clicking a state cross-filters the page (PBI parity); click again clears. */
export function MapVisual({
  spec,
  data,
  selected = [],
  onSelect,
}: {
  spec: VisualSpec
  data?: VisualResult
  selected?: (string | number)[]
  onSelect?: (values: (string | number)[]) => void
}) {
  const palette = usePalette()
  const theme = useThemeTokens()
  const [ready, setReady] = useState(usMapRegistered)
  useEffect(() => {
    ensureUsMap().then(() => setReady(true))
  }, [])

  if (!data || !ready) return <div className="p-2 text-xs text-surface-400">…</div>
  if (data.error) return <div className="p-2 text-xs text-brand-red">{data.error}</div>

  const dimKey = spec.dim_keys[0]
  const mKey = spec.measure_keys[0]
  const di = data.columns.indexOf(dimKey)
  const mi = data.columns.indexOf(mKey)
  const rows = data.rows
    .filter((r) => r[di] !== null)
    .map((r) => ({
      name: String(r[di]),
      value: Number(r[mi] ?? 0),
      selected: selected.includes(String(r[di])),
    }))
  const values = rows.map((r) => r.value)
  const fmt = spec.measure_formats[mKey]
  const hasSelection = selected.length > 0

  const option: EChartsOption = {
    tooltip: {
      formatter: (p) => {
        const item = p as { name: string; value: number }
        return `<b>${item.name}</b><br/>${mKey}: ${
          Number.isFinite(item.value) ? formatValue(item.value, fmt) : '—'
        }`
      },
      backgroundColor: theme.tooltipBackground,
      borderColor: theme.panelBorder,
      textStyle: { color: theme.tooltipText, fontFamily: theme.fontFamily, fontSize: 11 },
    },
    visualMap: {
      min: Math.min(...values),
      max: Math.max(...values),
      inRange: { color: ['#e6eef7', palette[0], palette[1] ?? palette[0]] },
      calculable: false,
      orient: 'horizontal',
      left: 'center',
      bottom: 0,
      itemHeight: 60,
      textStyle: { fontSize: 8 },
      formatter: (v) => formatValue(v as number, fmt),
    },
    series: [
      {
        type: 'map',
        map: 'USA',
        roam: false,
        // continental-US focus
        center: [-96, 38.5],
        zoom: 1.15,
        selectedMode: 'multiple',
        select: {
          label: { show: false },
          itemStyle: { areaColor: '#E66C37', borderColor: '#b45309', borderWidth: 1.5 },
        },
        emphasis: { label: { show: false }, itemStyle: { areaColor: '#E66C37' } },
        itemStyle: {
          borderColor: '#fff',
          areaColor: '#eef2f7',
          opacity: hasSelection ? 0.55 : 1,
        },
        data: rows,
      },
    ],
  }
  return (
    <EChart
      option={option}
      onItemClick={(name) => {
        if (!onSelect) return
        // toggle: click selected state again to clear it
        onSelect(
          selected.includes(name) ? selected.filter((s) => s !== name) : [...selected, name],
        )
      }}
    />
  )
}
