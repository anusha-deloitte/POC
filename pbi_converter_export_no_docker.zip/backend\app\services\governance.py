"""File-backed governance artifacts for review, provenance, and promotion.

The store is intentionally lightweight: it derives a review queue from the
existing fidelity and compare artifacts, then persists human decisions and
comments alongside the conversion bundle.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

from app.ir.report import InteractionGraph, InteractionMode, ReportBundle
from app.runtime.dashboard import DashboardSpec, compile_dashboard
from app.services.ingest import IngestService

ReviewStatus = Literal["open", "approved", "rejected", "promoted", "needs_info"]
SubjectKind = Literal["visual", "measure", "page", "model"]


class GovernanceComment(BaseModel):
    author: str = "system"
    body: str
    created_at: float = Field(default_factory=lambda: time.time())


class GovernanceDecision(BaseModel):
    decision: ReviewStatus
    comment: str | None = None
    owner: str | None = None
    decided_at: float = Field(default_factory=lambda: time.time())


class GovernanceRemediationAttempt(BaseModel):
    instruction: str
    applied_override: dict = Field(default_factory=dict)
    fixed: bool = False
    status: str = "failed"
    summary: str = ""
    visual_checks: list[dict] = Field(default_factory=list)
    owner: str | None = None
    executed_at: float = Field(default_factory=lambda: time.time())


class GovernanceQuestionAnswer(BaseModel):
    question: str
    answer: str
    owner: str | None = None
    asked_at: float = Field(default_factory=lambda: time.time())


class GovernanceReview(BaseModel):
    id: str
    subject_kind: SubjectKind
    subject_id: str
    title: str
    summary: str
    recommendation: str
    severity: Literal["high", "medium", "low"] = "medium"
    confidence: float = 0.5
    status: ReviewStatus = "open"
    comments: list[GovernanceComment] = Field(default_factory=list)
    decision: GovernanceDecision | None = None
    remediation_history: list[GovernanceRemediationAttempt] = Field(default_factory=list)
    qa_history: list[GovernanceQuestionAnswer] = Field(default_factory=list)
    provenance: dict = Field(default_factory=dict)
    impact: dict = Field(default_factory=dict)
    created_at: float = Field(default_factory=lambda: time.time())
    updated_at: float = Field(default_factory=lambda: time.time())


class GovernanceState(BaseModel):
    model: dict = Field(default_factory=dict)
    decisions: dict[str, GovernanceDecision] = Field(default_factory=dict)
    comments: dict[str, list[GovernanceComment]] = Field(default_factory=dict)
    remediation_history: dict[str, list[GovernanceRemediationAttempt]] = Field(default_factory=dict)
    qa_history: dict[str, list[GovernanceQuestionAnswer]] = Field(default_factory=dict)
    promotion_history: list[dict] = Field(default_factory=list)
    model_lifecycle: dict = Field(default_factory=dict)


def governance_path(storage_dir: Path, conversion_id: str) -> Path:
    return storage_dir / str(conversion_id) / "governance.json"


def _read_json(path: Path) -> dict:
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except ValueError:
        return {}


def _write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _bundle_and_spec(svc: IngestService, conversion_id: str) -> tuple[ReportBundle, DashboardSpec]:
    bundle = svc.load_bundle(conversion_id)
    # accepted tier-2 SQL must be applied or resolved measures show as parked
    run_file = svc.conversion_dir(conversion_id) / "conversion_run.json"
    run = _read_json(run_file) if run_file.is_file() else {}
    tier2 = run.get("tier2_accepted") or {}
    spec, _ = compile_dashboard(bundle, tier2_sql=tier2)
    return bundle, spec


def _review_key(subject_kind: SubjectKind, subject_id: str) -> str:
    return f"{subject_kind}:{subject_id}"


def _model_summary(bundle: ReportBundle, lifecycle_override: str | None = None) -> dict:
    model = bundle.model
    contexts: dict[str, int] = {}
    for table in model.tables:
        context = table.bounded_context_id or "unassigned"
        contexts[context] = contexts.get(context, 0) + 1
    return {
        "name": model.name,
        "version": model.model_version,
        "data_version": model.data_version,
        "identity_execution_mode": model.identity_execution_mode.value,
        "semantic_views": list(model.semantic_views),
        "tables": len(model.tables),
        "relationships": len(model.relationships),
        "measures": sum(len(table.measures) for table in model.tables),
        "domains": contexts,
        "lifecycle": lifecycle_override or ("certified" if len(model.semantic_views) > 0 else "draft"),
    }


def _default_model_lifecycle(bundle: ReportBundle) -> dict:
    model = bundle.model
    return {
        "state": "certified" if len(model.semantic_views) > 0 else "draft",
        "version": model.model_version,
        "data_version": model.data_version,
        "owner": None,
        "reason": None,
        "changed_at": None,
    }


def _current_model_lifecycle(bundle: ReportBundle, state: GovernanceState) -> dict:
    current = dict(_default_model_lifecycle(bundle))
    if state.model_lifecycle:
        current.update(state.model_lifecycle)
    return current


def _compare_history(conversion_dir: Path) -> list[dict]:
    out: list[dict] = []
    compare_dir = conversion_dir / "visual_compare"
    if not compare_dir.is_dir():
        return out
    for path in sorted(compare_dir.glob("*.json")):
        if path.name.endswith("_reference.json"):
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except ValueError:
            continue
        if not isinstance(payload, dict) or "page" not in payload:
            continue
        out.append(
            {
                "page": payload.get("page"),
                "display_name": payload.get("display_name"),
                "similarity": payload.get("similarity"),
                "finding_count": len(payload.get("findings") or []),
                "compared_at": payload.get("compared_at"),
                "filters_applied": payload.get("filters_applied") or [],
            }
        )
    out.sort(key=lambda item: item.get("compared_at") or 0, reverse=True)
    return out


def _fidelity_reviews(bundle: ReportBundle, run: dict | None, spec: DashboardSpec) -> list[GovernanceReview]:
    reviews: list[GovernanceReview] = []
    pages_by_name = {page.name: page for page in bundle.report.pages}
    if not run:
        run = {}
    pages = (run.get("fidelity") or {}).get("pages") or []
    for page_payload in pages:
        page_name = page_payload.get("page")
        page = pages_by_name.get(page_name)
        if page is None:
            continue
        for visual_payload in page_payload.get("visuals") or []:
            checks = visual_payload.get("checks") or []
            failed = [check for check in checks if check.get("status") == "failed"]
            if not failed:
                continue
            visual_name = visual_payload.get("visual")
            visual = next((v for v in page.visuals if v.name == visual_name), None)
            if visual is None:
                continue
            subject_id = f"{page.name}::{visual.name}"
            confidence = max(0.1, 1.0 - min(len(failed) / max(len(checks), 1), 0.8))
            recommendation = _recommendation_for_failed_checks(failed)
            reviews.append(
                GovernanceReview(
                    id=_review_key("visual", subject_id),
                    subject_kind="visual",
                    subject_id=subject_id,
                    title=visual.title or visual.name,
                    summary="; ".join((str(check.get("detail") or check.get("name") or "") for check in failed))[:500],
                    recommendation=recommendation,
                    severity="high" if len(failed) >= 2 else "medium",
                    confidence=round(confidence, 2),
                    provenance={},
                    impact=_impact_for_visual(bundle, spec, page.name, visual.name),
                    status="open",
                )
            )
    for page in spec.pages:
        for visual in page.visuals:
            if visual.supported:
                continue
            subject_id = f"{page.name}::{visual.name}"
            reviews.append(
                GovernanceReview(
                    id=_review_key("visual", subject_id),
                    subject_kind="visual",
                    subject_id=subject_id,
                    title=visual.title or visual.name,
                    summary=visual.unsupported_reason or f"visual type '{visual.visual_type}' is not supported",
                    recommendation="Map this asset to a supported catalog component or keep it in a human review queue.",
                    severity="low",
                    confidence=0.25,
                    provenance={},
                    impact=_impact_for_visual(bundle, spec, page.name, visual.name),
                    status="needs_info",
                )
            )
    return reviews


def _measure_gap_reviews(bundle: ReportBundle, run: dict | None, spec: DashboardSpec) -> list[GovernanceReview]:
    reviews: list[GovernanceReview] = []
    tier2_accepted = (run or {}).get("tier2_accepted") or {}
    for measure_name, tier in spec.measure_tiers.items():
        if tier >= 0:
            continue
        found = bundle.model.find_measure(measure_name)
        table_name = found[0].name if found else "unknown"
        subject_id = f"{table_name}::{measure_name}"
        recommendation = (
            "Translate this DAX measure into Snowflake SQL (tier-2) or rewrite it into a supported deterministic tier, "
            "then re-run conversion to include it in the semantic view."
        )
        if measure_name in tier2_accepted:
            recommendation = (
                "Measure has a tier-2 SQL candidate but is still unresolved in validation. "
                "Review SQL correctness and filter behavior, then re-run parity checks."
            )
        reviews.append(
            GovernanceReview(
                id=_review_key("measure", subject_id),
                subject_kind="measure",
                subject_id=subject_id,
                title=measure_name,
                summary="This measure is currently parked and cannot be served from the semantic view with guaranteed parity.",
                recommendation=recommendation,
                severity="high",
                confidence=0.15,
                provenance={
                    "table": table_name,
                    "measure": measure_name,
                    "tier": tier,
                },
                impact={
                    "semantic_view_blocked": True,
                    "query_fallback_required": True,
                },
                status="open",
            )
        )
    return reviews


def _recommendation_for_failed_checks(failed_checks: list[dict]) -> str:
    check_names = {str(item.get("name", "")).lower() for item in failed_checks}
    if "compile" in check_names:
        return "Fix the visual expression or mapping first, then re-run validation to confirm compilation succeeds."
    if "query" in check_names:
        return "Review source-to-target field mappings and bound tables for this visual, then re-run validation."
    if "render" in check_names:
        return "Adjust visual type or field roles to match the original Power BI intent, then re-check visual parity."
    if "data" in check_names:
        return "Verify filters, joins, and aggregation settings, then re-run validation for this visual."
    if check_names:
        joined = ", ".join(sorted(check_names))
        return f"Address failed checks ({joined}), then run a targeted re-check for this visual."
    return "Review this issue and run a targeted re-check after applying a safe visual-level fix."


def _visual_by_name(bundle: ReportBundle, page_name: str, visual_name: str):
    page = bundle.report.page(page_name)
    if page is None:
        return None, None
    visual = next((v for v in page.visuals if v.name == visual_name), None)
    return page, visual


def _visual_field_keys(visual) -> tuple[list[str], list[str]]:
    measure_keys: list[str] = []
    dimension_keys: list[str] = []
    for field in getattr(visual, "fields", []) or []:
        key = field.query_ref or ".".join(part for part in (field.table, field.name) if part)
        if not key:
            continue
        if field.is_measure:
            measure_keys.append(key)
        else:
            dimension_keys.append(key)
    return measure_keys, dimension_keys


def _measure_summary(bundle: ReportBundle, measure_name: str) -> dict:
    found = bundle.model.find_measure(measure_name)
    if not found:
        return {"measure": measure_name, "table": None, "binding": None}
    table, measure = found
    return {
        "measure": measure.name,
        "table": table.name,
        "binding": measure.semantic_binding.model_dump() if measure.semantic_binding else None,
        "tier": measure.execution_tier.value if measure.execution_tier else None,
        "parity_status": measure.parity_status,
        "confidence": measure.confidence,
    }


def _visual_provenance(
    bundle: ReportBundle,
    spec: DashboardSpec,
    page_name: str,
    visual_name: str,
    run: dict | None,
    compare_history: list[dict],
) -> dict:
    page, visual = _visual_by_name(bundle, page_name, visual_name)
    if page is None or visual is None:
        return {"nodes": [], "edges": []}
    measure_keys, dimension_keys = _visual_field_keys(visual)
    measure_nodes = [_measure_summary(bundle, mk) for mk in measure_keys]
    table_names = set()
    for summary in measure_nodes:
        if summary.get("table"):
            table_names.add(summary["table"])
    for dim in dimension_keys:
        table_names.add(dim.split(".")[0])
    nodes = [
        {"kind": "visual", "id": f"{page.name}::{visual.name}", "title": visual.title or visual.name},
        {
            "kind": "query",
            "id": f"query:{page.name}::{visual.name}",
            "title": visual.visual_type,
            "dimensions": dimension_keys,
            "measures": measure_keys,
        },
    ]
    edges = [
        {"from": nodes[0]["id"], "to": nodes[1]["id"], "kind": "renders"},
    ]
    for measure in measure_nodes:
        measure_id = f"measure:{measure.get('table') or 'unknown'}::{measure['measure']}"
        nodes.append({"kind": "measure", "id": measure_id, **measure})
        edges.append({"from": nodes[1]["id"], "to": measure_id, "kind": "uses"})
        if measure.get("binding") and measure["binding"].get("semantic_view"):
            semantic_id = f"semantic_view:{measure['binding']['semantic_view']}"
            nodes.append(
                {
                    "kind": "semantic_view",
                    "id": semantic_id,
                    "title": measure["binding"]["semantic_view"],
                    "domain": measure["binding"].get("domain_id"),
                    "lifecycle": measure["binding"].get("lifecycle"),
                }
            )
            edges.append({"from": measure_id, "to": semantic_id, "kind": "binds"})
    for table_name in sorted(table_names):
        table = bundle.model.table(table_name)
        if table is None:
            continue
        table_id = f"table:{table.name}"
        nodes.append(
            {
                "kind": "table",
                "id": table_id,
                "title": table.name,
                "bounded_context_id": table.bounded_context_id,
                "is_conformed_dimension": table.is_conformed_dimension,
            }
        )
        edges.append({"from": nodes[1]["id"], "to": table_id, "kind": "queries"})
    if run:
        last_run = run.get("summary") or {}
        nodes.append(
            {
                "kind": "validation",
                "id": f"validation:{page.name}::{visual.name}",
                "title": "latest validation",
                "score": last_run.get("overall_score"),
                "visuals_failed": last_run.get("visuals_failed"),
                "visuals_passed": last_run.get("visuals_passed"),
            }
        )
        edges.append({"from": nodes[0]["id"], "to": nodes[-1]["id"], "kind": "validated_by"})
    return {
        "page": page.name,
        "visual": visual.name,
        "title": visual.title or visual.name,
        "nodes": nodes,
        "edges": edges,
        "measure_keys": measure_keys,
        "dimension_keys": dimension_keys,
        "supported": True,
        "unsupported_reason": None,
        "compare_history": [item for item in compare_history if item.get("page") == page.name],
    }


def _impact_for_visual(bundle: ReportBundle, spec: DashboardSpec, page_name: str, visual_name: str) -> dict:
    page, visual = _visual_by_name(bundle, page_name, visual_name)
    if page is None or visual is None:
        return {"direct": [], "downstream": []}
    measure_keys, dimension_keys = _visual_field_keys(visual)
    referenced_tables = {column.split(".")[0] for column in dimension_keys if "." in column}
    referenced_measures = set(measure_keys)
    for mk in measure_keys:
        found = bundle.model.find_measure(mk)
        if found:
            referenced_tables.add(found[0].name)
    direct: list[dict] = []
    downstream: list[dict] = []
    for page_iter in spec.pages:
        for candidate in page_iter.visuals:
            if candidate.name == visual.name and page_iter.name == page.name:
                continue
            hit_reason: list[str] = []
            if any(m in referenced_measures for m in candidate.measure_keys):
                hit_reason.append("shared measure")
            if any(k.split(".")[0] in referenced_tables for k in candidate.dim_keys if "." in k):
                hit_reason.append("shared table")
            if spec.interaction_graph.edges and any(
                e.from_visual == visual.name and e.to_visual == candidate.name for e in spec.interaction_graph.edges
            ):
                hit_reason.append("interaction edge")
            if not hit_reason:
                continue
            payload = {
                "page": page_iter.name,
                "visual": candidate.name,
                "title": candidate.title or candidate.name,
                "reasons": hit_reason,
                "supported": candidate.supported,
                "kind": candidate.visual_type,
            }
            downstream.append(payload)
            if page_iter.name == page.name:
                direct.append(payload)
    return {
        "subject": {"page": page.name, "visual": visual.name, "title": visual.title or visual.name},
        "direct": direct,
        "downstream": downstream,
        "referenced_tables": sorted(referenced_tables),
        "referenced_measures": sorted(referenced_measures),
    }


def _merge_reviews(derived: list[GovernanceReview], state: GovernanceState) -> list[GovernanceReview]:
    merged: list[GovernanceReview] = []
    for review in derived:
        decision = state.decisions.get(review.id)
        if decision is not None:
            review.status = decision.decision
            review.decision = decision
            review.updated_at = decision.decided_at
        comments = state.comments.get(review.id) or []
        if comments:
            review.comments.extend(comments)
            review.updated_at = max(review.updated_at, max(comment.created_at for comment in comments))
        remediation_history = state.remediation_history.get(review.id) or []
        if remediation_history:
            review.remediation_history.extend(remediation_history)
            review.updated_at = max(
                review.updated_at,
                max(attempt.executed_at for attempt in remediation_history),
            )
        qa_history = state.qa_history.get(review.id) or []
        if qa_history:
            review.qa_history.extend(qa_history)
            review.updated_at = max(review.updated_at, max(item.asked_at for item in qa_history))
        merged.append(review)
    return merged


def load_governance(conversion_id: str, svc: IngestService) -> dict:
    bundle, spec = _bundle_and_spec(svc, conversion_id)
    conv_dir = svc.conversion_dir(conversion_id)
    run_file = conv_dir / "conversion_run.json"
    run = _read_json(run_file) if run_file.is_file() else None
    gate_status = (run or {}).get("gate_status") if isinstance(run, dict) else None
    policy_mode = (run or {}).get("policy_mode") if isinstance(run, dict) else None
    state_file = governance_path(svc.storage_dir, conversion_id)
    state = GovernanceState.model_validate(_read_json(state_file) or {})
    compare_history = _compare_history(conv_dir)
    lifecycle = _current_model_lifecycle(bundle, state)
    derived_reviews = _fidelity_reviews(bundle, run, spec) + _measure_gap_reviews(bundle, run, spec)
    reviews = _merge_reviews(derived_reviews, state)
    for review in reviews:
        if review.subject_kind == "visual":
            page_name, visual_name = review.subject_id.split("::", 1)
            review.provenance = _visual_provenance(bundle, spec, page_name, visual_name, run, compare_history)
    return {
        "summary": {
            "model": _model_summary(bundle, lifecycle.get("state")),
            "review": {
                "total": len(reviews),
                "open": sum(1 for review in reviews if review.status == "open"),
                "approved": sum(1 for review in reviews if review.status == "approved"),
                "rejected": sum(1 for review in reviews if review.status == "rejected"),
                "promoted": sum(1 for review in reviews if review.status == "promoted"),
                "needs_info": sum(1 for review in reviews if review.status == "needs_info"),
            },
            "compare_history": compare_history,
            "promotion_history": state.promotion_history,
            "model_lifecycle": lifecycle,
            "gate_status": gate_status,
            "policy_mode": policy_mode,
        },
        "reviews": [review.model_dump() for review in reviews],
        "history": state.promotion_history,
        "model": _model_summary(bundle, lifecycle.get("state")),
        "compare_history": compare_history,
        "model_lifecycle": lifecycle,
    }


def decide_review(
    conversion_id: str,
    svc: IngestService,
    review_id: str,
    decision: GovernanceDecision,
) -> dict:
    state_file = governance_path(svc.storage_dir, conversion_id)
    state = GovernanceState.model_validate(_read_json(state_file) or {})
    state.decisions[review_id] = decision
    if decision.comment:
        state.comments.setdefault(review_id, []).append(
            GovernanceComment(author=decision.owner or "reviewer", body=decision.comment)
        )
    if decision.decision == "promoted":
        state.promotion_history.append(
            {
                "review_id": review_id,
                "decision": decision.decision,
                "owner": decision.owner,
                "comment": decision.comment,
                "decided_at": decision.decided_at,
            }
        )
    _write_json(state_file, state.model_dump())
    return {"review_id": review_id, "decision": decision.model_dump()}


def add_comment(conversion_id: str, svc: IngestService, review_id: str, comment: GovernanceComment) -> dict:
    state_file = governance_path(svc.storage_dir, conversion_id)
    state = GovernanceState.model_validate(_read_json(state_file) or {})
    state.comments.setdefault(review_id, []).append(comment)
    _write_json(state_file, state.model_dump())
    return {"review_id": review_id, "comment": comment.model_dump()}


def add_remediation_attempt(
    conversion_id: str,
    svc: IngestService,
    review_id: str,
    attempt: GovernanceRemediationAttempt,
) -> dict:
    state_file = governance_path(svc.storage_dir, conversion_id)
    state = GovernanceState.model_validate(_read_json(state_file) or {})
    state.remediation_history.setdefault(review_id, []).append(attempt)
    _write_json(state_file, state.model_dump())
    return {"review_id": review_id, "attempt": attempt.model_dump()}


def add_question_answer(
    conversion_id: str,
    svc: IngestService,
    review_id: str,
    item: GovernanceQuestionAnswer,
) -> dict:
    state_file = governance_path(svc.storage_dir, conversion_id)
    state = GovernanceState.model_validate(_read_json(state_file) or {})
    state.qa_history.setdefault(review_id, []).append(item)
    _write_json(state_file, state.model_dump())
    return {"review_id": review_id, "item": item.model_dump()}


def get_model_lifecycle(conversion_id: str, svc: IngestService) -> dict:
    bundle, _ = _bundle_and_spec(svc, conversion_id)
    state_file = governance_path(svc.storage_dir, conversion_id)
    state = GovernanceState.model_validate(_read_json(state_file) or {})
    return _current_model_lifecycle(bundle, state)


def set_model_lifecycle(
    conversion_id: str,
    svc: IngestService,
    action: Literal["promote", "demote", "block"],
    owner: str | None = None,
    reason: str | None = None,
) -> dict:
    bundle, _ = _bundle_and_spec(svc, conversion_id)
    state_file = governance_path(svc.storage_dir, conversion_id)
    state = GovernanceState.model_validate(_read_json(state_file) or {})
    mapping = {"promote": "certified", "demote": "draft", "block": "blocked"}
    current = _current_model_lifecycle(bundle, state)
    current.update(
        {
            "state": mapping[action],
            "owner": owner,
            "reason": reason,
            "changed_at": time.time(),
        }
    )
    state.model_lifecycle = current
    state.promotion_history.append(
        {
            "type": "model_lifecycle",
            "action": action,
            "state": current["state"],
            "owner": owner,
            "reason": reason,
            "changed_at": current["changed_at"],
        }
    )
    _write_json(state_file, state.model_dump())
    return current
