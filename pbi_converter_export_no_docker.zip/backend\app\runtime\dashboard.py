"""Compile a ReportBundle into a renderable DashboardSpec.

The spec is the contract between backend and the spec-driven React renderer:
layout + visual configs + per-visual QuerySpecs. Visual types outside the
registry render as an "unsupported" badge with their type name.
"""

from __future__ import annotations

import re

from pydantic import BaseModel, Field

from app.binding.resolver import BindingMap, build_binding_map
from app.dax.compiler import DaxUnsupported, MeasureCompiler
from app.ir.report import Bookmark, DrillThroughTarget, InteractionGraph, Page, ReportBundle, Visual
from app.runtime.engine import DimensionRef, FilterClause, MeasureRefSpec, QuerySpec
from app.semantic.yaml_compiler import semantic_metric_plan

SUPPORTED_VISUALS = {
    "card",
    "slicer",
    "donutChart",
    "pieChart",
    "clusteredColumnChart",
    "clusteredBarChart",
    "barChart",
    "columnChart",
    "lineChart",
    "areaChart",
    "waterfallChart",
    "pivotTable",
    "tableEx",
    "textbox",
    "scatterChart",
    "lineClusteredColumnComboChart",
    "gauge",
    "filledMap",
    # rendered as drillable treemap (nearest equivalent, same contribution story)
    "decompositionTreeVisual",
}

# roles that carry grouping fields per visual family
_DIM_ROLES = {"Category", "Rows", "Axis", "Legend", "Columns", "Explain By", "Details", "Series"}
_MEASURE_ROLES = {
    "Y",
    "Values",
    "Y2",
    "Tooltips",
    "X",
    "Size",
    "Analyzed",
    "TargetValue",
    "MinValue",
    "MaxValue",
}

# PBIR writes the same logical role under several spellings depending on the
# visual and the Desktop version that authored it (e.g. "ExplainBy" vs "Explain By").
_ROLE_ALIASES = {
    "explainby": "Explain By",
    "analyze": "Analyzed",
    "group": "Category",
    "groups": "Category",
    "axis": "Axis",
    "y2axis": "Y2",
    "secondaryy": "Y2",
    "tooltip": "Tooltips",
    "details": "Details",
    "value": "Values",
    "target": "TargetValue",
    "minimum": "MinValue",
    "maximum": "MaxValue",
}


def _canonical_role(role: str) -> str:
    """Map a PBIR projection role onto the compiler's canonical role vocabulary."""
    if role in _DIM_ROLES or role in _MEASURE_ROLES:
        return role
    return _ROLE_ALIASES.get(role.replace(" ", "").replace("_", "").lower(), role)


class VisualSpec(BaseModel):
    name: str
    visual_type: str
    x: float
    y: float
    width: float
    height: float
    z: int = 0
    title: str | None = None
    supported: bool = True
    unsupported_reason: str | None = None
    # set when the PBI visual has no exact match and a nearest equivalent is used
    substituted_as: str | None = None
    # renderer inputs
    query: QuerySpec | None = None
    dim_keys: list[str] = Field(default_factory=list)
    # dims that came from the PBI "Columns" role (matrix pivot axis)
    column_keys: list[str] = Field(default_factory=list)
    # dims that came from the PBI "Series"/"Legend" role (chart series split)
    series_keys: list[str] = Field(default_factory=list)
    # projections defined in the PBI visual that the compiler did NOT consume
    dropped_fields: list[str] = Field(default_factory=list)
    measure_keys: list[str] = Field(default_factory=list)
    measure_roles: dict[str, str] = Field(default_factory=dict)  # measure key -> role
    measure_formats: dict[str, str] = Field(default_factory=dict)
    slicer_target: dict | None = None  # {table, column}
    static_content: dict = Field(default_factory=dict)  # textbox paragraphs etc.
    sort: list[dict] = Field(default_factory=list)
    # renderer options set by remediations (waterfall_total, show_legend, ...)
    options: dict = Field(default_factory=dict)
    # hierarchy drill metadata for visuals using hierarchy levels
    hierarchy: dict | None = None


class PageSpec(BaseModel):
    name: str
    display_name: str
    width: float
    height: float
    ordinal: int
    visuals: list[VisualSpec] = Field(default_factory=list)


class ThemeSpec(BaseModel):
    data_colors: list[str] = Field(default_factory=list)
    background: str | None = None
    foreground: str | None = None
    table_accent: str | None = None
    good: str | None = None
    bad: str | None = None
    neutral: str | None = None
    font_family: str | None = None
    card_background: str | None = None
    panel_background: str | None = None
    panel_border: str | None = None
    tooltip_background: str | None = None
    tooltip_text: str | None = None
    text_classes: dict[str, dict] = Field(default_factory=dict)


class DashboardSpec(BaseModel):
    report_name: str
    pages: list[PageSpec] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    # measure name -> tier (0/1/2) or -1 for parked
    measure_tiers: dict[str, int] = Field(default_factory=dict)
    theme: ThemeSpec = Field(default_factory=ThemeSpec)
    interaction_graph: InteractionGraph = Field(default_factory=InteractionGraph)
    bookmarks: list[Bookmark] = Field(default_factory=list)
    drill_through: list[DrillThroughTarget] = Field(default_factory=list)
    # detected Power BI What-If parameters from calculated tables
    what_if_parameters: list[dict] = Field(default_factory=list)


_GENERATESERIES_RE = re.compile(
    r"GENERATESERIES\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\)",
    re.IGNORECASE,
)


def _detect_what_if_parameters(bundle: ReportBundle) -> list[dict]:
    """Detect basic What-If parameter tables from calculated table expressions.

    Pattern: calculated table partition with GENERATESERIES(min, max, step).
    """
    out: list[dict] = []
    for t in bundle.model.tables:
        if not t.partitions:
            continue
        part = t.partitions[0]
        if part.source_type != "calculated" or not part.expression:
            continue
        m = _GENERATESERIES_RE.search(part.expression)
        if not m:
            continue
        col_name = t.columns[0].name if t.columns else "Value"
        out.append(
            {
                "table": t.name,
                "column": col_name,
                "min": m.group(1).strip(),
                "max": m.group(2).strip(),
                "step": m.group(3).strip(),
            }
        )
    return out


def _find_what_if_for_measure(bundle: ReportBundle, measure_name: str) -> dict | None:
    """Link a measure to a detected What-If parameter via SELECTEDVALUE refs."""
    found = bundle.model.find_measure(measure_name)
    if not found:
        return None
    _, m = found
    expr = m.expression or ""
    params = _detect_what_if_parameters(bundle)
    for p in params:
        pattern = rf"SELECTEDVALUE\s*\(\s*'?{re.escape(p['table'])}'?\s*\[\s*{re.escape(p['column'])}\s*\]"
        if re.search(pattern, expr, re.IGNORECASE):
            return p
    return None


def _reachable_tables(model: ReportBundle, start: str) -> set[str]:
    seen = {start}
    frontier = [start]
    while frontier:
        cur = frontier.pop()
        for rel in model.model.relationships:
            if getattr(rel, "is_active", True) is False:
                continue
            if rel.from_table == cur and rel.to_table not in seen:
                seen.add(rel.to_table)
                frontier.append(rel.to_table)
    return seen


def compile_theme(raw_theme: dict) -> ThemeSpec:
    custom = raw_theme.get("custom", {}) if isinstance(raw_theme, dict) else {}
    return ThemeSpec(
        data_colors=custom.get("dataColors", []),
        background=custom.get("background"),
        foreground=custom.get("foreground"),
        table_accent=custom.get("tableAccent"),
        good=custom.get("good"),
        bad=custom.get("bad"),
        neutral=custom.get("neutral"),
        font_family=custom.get("fontFamily"),
        card_background=custom.get("cardBackground"),
        panel_background=custom.get("panelBackground"),
        panel_border=custom.get("panelBorder"),
        tooltip_background=custom.get("tooltipBackground"),
        tooltip_text=custom.get("tooltipText"),
        text_classes=custom.get("textClasses", {}),
    )


def _format_for(bundle: ReportBundle, measure_name: str) -> str | None:
    found = bundle.model.find_measure(measure_name)
    return found[1].format_string if found else None


# PBI labelDisplayUnits values with a fixed scale (0 = Auto, 1 = None)
_DISPLAY_UNITS = {1000, 1000000, 1000000000, 1000000000000}


def _fmt_literal(objects: dict, section: str, prop: str):
    """Decode a PBIR formatting literal: 'true'/'false', 9D/0D numbers, 'Right' strings."""
    try:
        raw = objects[section][0]["properties"][prop]["expr"]["Literal"]["Value"]
    except (KeyError, IndexError, TypeError):
        return None
    if not isinstance(raw, str):
        return raw
    if raw in ("true", "false"):
        return raw == "true"
    if raw.startswith("'") and raw.endswith("'"):
        return raw[1:-1]
    if raw.endswith(("D", "L")):
        try:
            return float(raw[:-1])
        except ValueError:
            return None
    return raw


def _fmt_color(objects: dict, section: str, prop: str) -> str | None:
    """Decode a PBIR solid-color literal: objects.<section>[0].properties.<prop>.solid.color."""
    try:
        raw = objects[section][0]["properties"][prop]["solid"]["color"]["expr"]["Literal"]["Value"]
    except (KeyError, IndexError, TypeError):
        return None
    if isinstance(raw, str) and raw.startswith("'") and raw.endswith("'"):
        return raw[1:-1]
    return raw if isinstance(raw, str) else None


# visual families where PBI shows grand totals unless explicitly disabled
_TOTALS_DEFAULT_ON = {"pivotTable", "tableEx"}


def extract_declared_presentation(visual: Visual) -> dict:
    """Read every presentation property this engine understands from the raw
    PBIR payload. Single source of truth shared by the compiler, the
    validation harness, and the presentation repair agent — so a compile gap
    is always caught by validation instead of silently diverging."""
    fmt = visual.formatting or {}
    container = visual.container_objects or {}
    declared: dict = {}

    show_legend = _fmt_literal(fmt, "legend", "show")
    if isinstance(show_legend, bool):
        declared["show_legend"] = show_legend
    position = _fmt_literal(fmt, "legend", "position")
    if isinstance(position, str):
        declared["legend_position"] = position
    legend_font = _fmt_literal(fmt, "legend", "fontSize")
    if isinstance(legend_font, (int, float)):
        declared["legend_font_size"] = int(legend_font)

    show_labels = _fmt_literal(fmt, "labels", "show")
    if isinstance(show_labels, bool):
        declared["show_labels"] = show_labels
    units = _fmt_literal(fmt, "labels", "labelDisplayUnits")
    if isinstance(units, (int, float)) and (units == 0 or int(units) in _DISPLAY_UNITS):
        declared["display_units"] = int(units)
    precision = _fmt_literal(fmt, "labels", "labelPrecision")
    if isinstance(precision, (int, float)):
        declared["label_precision"] = int(precision)
    label_font = _fmt_literal(fmt, "labels", "fontSize")
    if isinstance(label_font, (int, float)):
        declared["label_font_size"] = int(label_font)
    label_color = _fmt_color(fmt, "labels", "color")
    if label_color:
        declared["label_color"] = label_color

    show_cat = _fmt_literal(fmt, "categoryLabels", "show")
    if isinstance(show_cat, bool):
        declared["show_category_labels"] = show_cat

    axis_units = _fmt_literal(fmt, "valueAxis", "labelDisplayUnits")
    if isinstance(axis_units, (int, float)) and (
        axis_units == 0 or int(axis_units) in _DISPLAY_UNITS
    ):
        declared["axis_display_units"] = int(axis_units)
    axis_precision = _fmt_literal(fmt, "valueAxis", "labelPrecision")
    if isinstance(axis_precision, (int, float)):
        declared["axis_precision"] = int(axis_precision)
    axis_title = _fmt_literal(fmt, "valueAxis", "titleText")
    if isinstance(axis_title, str) and _fmt_literal(fmt, "valueAxis", "showAxisTitle") is True:
        declared["axis_title"] = axis_title

    grid_vertical = _fmt_literal(fmt, "grid", "gridVertical")
    if isinstance(grid_vertical, bool):
        declared["grid_vertical"] = grid_vertical
    values_font = _fmt_literal(fmt, "values", "fontSize")
    if isinstance(values_font, (int, float)):
        declared["values_font_size"] = int(values_font)
    headers_bold = _fmt_literal(fmt, "columnHeaders", "bold")
    if isinstance(headers_bold, bool):
        declared["column_headers_bold"] = headers_bold

    if visual.visual_type in _TOTALS_DEFAULT_ON:
        # PBI shows grand totals unless the author explicitly turned them off
        totals_off = _fmt_literal(fmt, "subTotals", "rowSubtotals") is False or (
            _fmt_literal(fmt, "total", "show") is False
        )
        declared["show_totals"] = not totals_off

    bg_color = _fmt_color(container, "background", "color")
    if bg_color:
        transparency = _fmt_literal(container, "background", "transparency")
        declared["container_background"] = {
            "color": bg_color,
            "transparency": float(transparency) if isinstance(transparency, (int, float)) else 0.0,
        }
    border_show = _fmt_literal(container, "border", "show")
    if isinstance(border_show, bool):
        border: dict = {"show": border_show}
        border_color = _fmt_color(container, "border", "color")
        if border_color:
            border["color"] = border_color
        radius = _fmt_literal(container, "border", "radius")
        if isinstance(radius, (int, float)):
            border["radius"] = int(radius)
        declared["container_border"] = border

    return declared


def _default_sort(visual: Visual, dims: list, measures: list) -> list[dict]:
    """PBI applies a deterministic default sort when the author didn't set one:
    group columns ascending (respecting each column's sortByColumn, which the
    engine resolves downstream). Sorting every grouping column keeps row AND
    pivot-column order identical between the original and the conversion, and
    fixes the category→color assignment for charts (colors follow order)."""
    if dims:
        return [{"key": d.key, "direction": "Ascending"} for d in dims]
    return []


def _extract_presentation_options(visual: Visual, vs: VisualSpec) -> None:
    """Lift every declared presentation property from the PBIR payload into
    renderer options at compile time — parity on formatting is enforced up
    front instead of discovered later by the vision compare."""
    vs.options.update(extract_declared_presentation(visual))


def compile_visual(
    visual: Visual,
    bundle: ReportBundle,
    compiler: MeasureCompiler,
    warnings: list[str],
    tier2_sql: dict[str, str] | None = None,
) -> VisualSpec:
    tier2_sql = tier2_sql or {}
    vs = VisualSpec(
        name=visual.name,
        visual_type=visual.visual_type,
        x=visual.position.x,
        y=visual.position.y,
        width=visual.position.width,
        height=visual.position.height,
        z=visual.position.z,
        title=visual.title,
    )
    if visual.visual_type not in SUPPORTED_VISUALS:
        vs.supported = False
        vs.unsupported_reason = f"visual type '{visual.visual_type}' not yet in registry"
        return vs

    if visual.visual_type == "textbox":
        vs.static_content = visual.formatting.get("general", [{}])[0].get("properties", {})
        # banner textboxes carry their fill in visualContainerObjects
        _extract_presentation_options(visual, vs)
        return vs

    if visual.visual_type == "slicer":
        fields = [f for f in visual.fields if not f.is_measure and f.table and f.name]
        if not fields:
            vs.supported = False
            vs.unsupported_reason = "slicer without a field"
            return vs
        f = fields[0]
        vs.slicer_target = {"table": f.table, "column": f.name}
        vs.query = QuerySpec(
            dimensions=[DimensionRef(table=f.table, column=f.name)], limit=500
        )
        vs.dim_keys = [f"{f.table}.{f.name}"]
        _extract_presentation_options(visual, vs)
        return vs

    is_table_visual = visual.visual_type in ("pivotTable", "tableEx")
    dims: list[DimensionRef] = []
    column_keys: list[str] = []
    series_keys: list[str] = []
    measures: list[MeasureRefSpec] = []
    measure_roles: dict[str, str] = {}
    dropped: list[str] = []
    # decomposition tree: nearest equivalent is a 2-level drillable treemap
    max_dims = 2 if visual.visual_type == "decompositionTreeVisual" else None
    for f in visual.fields:
        role = _canonical_role(f.role)
        if role in _DIM_ROLES and not f.is_measure and f.table and f.name:
            if max_dims is not None and len(dims) >= max_dims:
                dropped.append(f"{f.role}: {f.table}.{f.name} (beyond drill depth)")
                continue
            ref = DimensionRef(table=f.table, column=f.name)
            dims.append(ref)
            if f.is_hierarchy_level and f.hierarchy:
                levels = vs.options.setdefault("hierarchy_levels", {})
                levels.setdefault(f.hierarchy, []).append(ref.key)
            if role == "Columns":
                column_keys.append(ref.key)
            elif role == "Series" or (
                role == "Legend" and visual.visual_type not in ("donutChart", "pieChart")
            ):
                series_keys.append(ref.key)
        elif role in _MEASURE_ROLES:
            if f.is_measure and f.name:
                measures.append(MeasureRefSpec(name=f.name, alias=f.name))
                measure_roles[f.name] = role
            elif f.table and f.name:
                # in table visuals a bare, non-aggregated column is a grouping
                # column (PBI "don't summarize"), not an implicit measure
                col = None
                t = bundle.model.table(f.table)
                if t is not None:
                    col = t.column(f.name)
                summarizes = f.aggregate or (
                    col is not None and col.summarize_by.value not in ("none", "default")
                )
                if is_table_visual and not summarizes:
                    dims.append(DimensionRef(table=f.table, column=f.name))
                else:
                    alias = f.display_name or f"{f.table}.{f.name}"
                    measures.append(
                        MeasureRefSpec(
                            table=f.table, column=f.name, aggregate=f.aggregate, alias=alias
                        )
                    )
                    measure_roles[alias] = role
        else:
            # projection in a role the compiler doesn't map -> visible parity gap
            label = f"[{f.name}]" if f.is_measure else f"{f.table}.{f.name}"
            dropped.append(f"{f.role}: {label}")

    if dropped:
        vs.dropped_fields = dropped
        warnings.append(f"{visual.name}: dropped projections {dropped}")

    if not measures and not dims:
        vs.supported = False
        vs.unsupported_reason = "no query fields"
        return vs

    # verify measures compile; tier-2 registry rescues, else park the visual
    non_semantic: list[str] = []
    semantic_homes: set[str] = set()
    for m in measures:
        if m.name:
            try:
                compiler.compile_measure(m.name)
            except DaxUnsupported as e:
                if m.name in tier2_sql:
                    vs.substituted_as = vs.substituted_as or "AI-translated measure"
                    continue
                vs.supported = False
                vs.unsupported_reason = f"measure [{m.name}] needs tier-2: {e}"
                warnings.append(f"{visual.name}: {vs.unsupported_reason}")
                return vs
            # Some tier-1 measures still require the compatibility runtime
            # (for example time-shift/window semantics) and cannot be surfaced
            # as semantic-view metrics yet.
            plan = semantic_metric_plan(bundle.model, compiler, m.name)
            if plan is None:
                non_semantic.append(m.name)
                continue
            if plan.kind == "table" and plan.home:
                semantic_homes.add(plan.home)
            elif plan.kind == "derived":
                semantic_homes.update(home for home, _, _ in plan.helpers)

    sort = [
        {"key": s.get("field") if s.get("is_measure") else f"{s.get('table')}.{s.get('field')}",
         "direction": s.get("direction", "Ascending")}
        for s in visual.sort
        if s.get("field")
    ]
    if not sort:
        sort = _default_sort(visual, dims, measures)

    vs.query = QuerySpec(dimensions=dims, measures=measures, sort=sort)
    vs.dim_keys = [d.key for d in dims]
    vs.column_keys = column_keys
    vs.series_keys = series_keys
    vs.measure_keys = [m.key for m in measures]
    vs.measure_roles = measure_roles
    if visual.visual_type == "decompositionTreeVisual":
        vs.substituted_as = "decomposition tree (top 2 levels)"

    # Phase-7: emit hierarchy drill metadata
    if "hierarchy_levels" in vs.options:
        hmap = vs.options["hierarchy_levels"]
        # pick the first hierarchy used by the visual as default drill track
        hname = next(iter(hmap.keys()))
        levels = hmap[hname]
        vs.hierarchy = {
            "name": hname,
            "levels": levels,
            "current_level": levels[-1] if levels else None,
            "drill_enabled": len(levels) > 1,
        }

    for m in measures:
        if m.name:
            fmt = _format_for(bundle, m.name)
            if fmt:
                vs.measure_formats[m.key] = fmt
            # Phase-7: surface What-If parameter linkage for renderer controls
            what_if = _find_what_if_for_measure(bundle, m.name)
            if what_if is not None:
                vs.options.setdefault("what_if", what_if)
    vs.sort = sort
    _extract_presentation_options(visual, vs)
    if non_semantic:
        vs.options["semantic_force_compatibility"] = True
        vs.options["semantic_force_compatibility_reason"] = (
            "measures not semantic-metric eligible: " + ", ".join(sorted(non_semantic))
        )
    elif semantic_homes and dims:
        # A SEMANTIC_VIEW query resolves every requested metric against every
        # requested dimension, so each dimension must be reachable from EVERY
        # metric home — reachability from just one home is not enough.
        for d in dims:
            unrelated = [
                home
                for home in semantic_homes
                if d.table != home and d.table not in _reachable_tables(bundle, home)
            ]
            if unrelated:
                vs.options["semantic_force_compatibility"] = True
                vs.options["semantic_force_compatibility_reason"] = (
                    f"dimension table {d.table} not connected to semantic metric homes "
                    + ", ".join(sorted(unrelated))
                )
                break
    return vs


def compile_dashboard(
    bundle: ReportBundle, tier2_sql: dict[str, str] | None = None
) -> tuple[DashboardSpec, BindingMap]:
    binding_map = build_binding_map(bundle.model)
    compiler = MeasureCompiler(bundle.model)
    warnings = list(binding_map.warnings)
    tier2_sql = tier2_sql or {}

    tiers: dict[str, int] = {}
    for t in bundle.model.tables:
        for m in t.measures:
            try:
                cm = compiler.compile_measure(m.name)
                tiers[m.name] = cm.tier
            except DaxUnsupported:
                tiers[m.name] = 2 if m.name in tier2_sql else -1

    pages = [
        PageSpec(
            name=p.name,
            display_name=p.display_name,
            width=p.width,
            height=p.height,
            ordinal=p.ordinal,
            visuals=[
                compile_visual(v, bundle, compiler, warnings, tier2_sql) for v in p.visuals
            ],
        )
        for p in bundle.report.pages
    ]
    spec = DashboardSpec(
        report_name=bundle.report.name,
        pages=pages,
        warnings=warnings,
        measure_tiers=tiers,
        theme=compile_theme(bundle.report.theme),
        interaction_graph=bundle.report.interaction_graph,
        bookmarks=bundle.report.bookmarks,
        drill_through=bundle.report.drill_through,
        what_if_parameters=_detect_what_if_parameters(bundle),
    )
    return spec, binding_map


def page_filters_to_clauses(page: Page) -> list[FilterClause]:
    """Convert PBIR page filters with concrete conditions into engine filters."""
    out: list[FilterClause] = []
    for f in page.filters:
        if not (f.field_table and f.field_name):
            continue
        values = _categorical_values(f.definition)
        if values:
            out.append(FilterClause(table=f.field_table, column=f.field_name, values=values))
    return out


def _categorical_values(definition: dict) -> list:
    """Pull literal values out of a PBIR filter definition (Version 2 shape)."""
    values = []
    for where in definition.get("Where", []):
        cond = where.get("Condition", {})
        in_expr = cond.get("In", {})
        for tup in in_expr.get("Values", []):
            for lit in tup:
                v = lit.get("Literal", {}).get("Value")
                if isinstance(v, str):
                    if v.endswith("L"):
                        values.append(int(v[:-1]))
                    elif v.startswith("'") and v.endswith("'"):
                        values.append(v[1:-1])
                    else:
                        try:
                            values.append(float(v) if "." in v else int(v))
                        except ValueError:
                            values.append(v)
    return values
