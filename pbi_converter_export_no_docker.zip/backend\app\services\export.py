"""Export a conversion as a standalone React (Vite + TS) project zip.

Vendors the SAME renderer sources served by the Studio (single code path, no
parity drift), bakes in the dashboard spec, and scaffolds a minimal Vite app
wired to the converter's query API via VITE_PBIC_API.
"""

from __future__ import annotations

import io
import json
import re
import zipfile
import os
from pathlib import Path

from app.runtime.dashboard import DashboardSpec


class ExportError(Exception):
    pass

# repo-relative renderer sources to vendor (paths under frontend/src)
_VENDOR = [
    "dashboard/types.ts",
    "dashboard/format.ts",
    "dashboard/api.ts",
    "dashboard/theme.tsx",
    "dashboard/PageCanvas.tsx",
    "dashboard/DashboardApp.tsx",
    "dashboard/visuals/pivot.ts",
    "dashboard/visuals/EChart.tsx",
    "dashboard/visuals/CardVisual.tsx",
    "dashboard/visuals/SlicerVisual.tsx",
    "dashboard/visuals/TextboxVisual.tsx",
    "dashboard/visuals/TableVisual.tsx",
    "dashboard/visuals/ChartVisual.tsx",
    "dashboard/visuals/ScatterVisual.tsx",
    "dashboard/visuals/ComboVisual.tsx",
    "dashboard/visuals/GaugeVisual.tsx",
    "dashboard/visuals/MapVisual.tsx",
    "dashboard/visuals/BreakdownVisual.tsx",
]

_PUBLIC_ASSETS = ["us-states.geo.json"]


def _frontend_src() -> Path:
    # containerized deployments bundle the renderer sources separately
    env = os.environ.get("PBIC_FRONTEND_SRC")
    if env:
        return Path(env)
    # backend/app/services/export.py -> repo root / frontend / src
    repo = Path(__file__).resolve().parents[3] / "frontend" / "src"
    if repo.is_dir():
        return repo
    return Path("/srv/frontend_src")


def _package_json(name: str) -> str:
    return json.dumps(
        {
            "name": name,
            "private": True,
            "version": "1.0.0",
            "type": "module",
            "license": "MIT",
            "scripts": {"dev": "vite", "build": "tsc -b && vite build", "preview": "vite preview"},
            "dependencies": {
                "@tanstack/react-query": "^5.62.0",
                "echarts": "^5.5.1",
                "react": "^19.0.0",
                "react-dom": "^19.0.0",
            },
            "devDependencies": {
                "@tailwindcss/vite": "^4.0.0",
                "@types/react": "^19.0.0",
                "@types/react-dom": "^19.0.0",
                "@vitejs/plugin-react": "^4.3.4",
                "tailwindcss": "^4.0.0",
                "typescript": "^5.7.0",
                "vite": "^6.0.0",
            },
        },
        indent=2,
    )


_VITE_CONFIG = """import tailwindcss from '@tailwindcss/vite'
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    port: 5180,
    proxy: {
      '/api': process.env.VITE_PBIC_API ?? 'http://localhost:8000',
    },
  },
})
"""

_TSCONFIG = json.dumps(
    {
        "compilerOptions": {
            "target": "ES2022",
            "lib": ["ES2022", "DOM", "DOM.Iterable"],
            "module": "ESNext",
            "moduleResolution": "bundler",
            "jsx": "react-jsx",
            "strict": True,
            "skipLibCheck": True,
            "noEmit": True,
            "isolatedModules": True,
            "resolveJsonModule": True,
        },
        "include": ["src"],
    },
    indent=2,
)

_INDEX_HTML = """<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{title}</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
"""

_MAIN_TSX = """import {{ QueryClient, QueryClientProvider }} from '@tanstack/react-query'
import {{ StrictMode }} from 'react'
import {{ createRoot }} from 'react-dom/client'
import {{ DashboardApp }} from './dashboard/DashboardApp'
import './index.css'

const queryClient = new QueryClient()

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={{queryClient}}>
      <DashboardApp conversionId="{conversion_id}" connectionId="{connection_id}" />
    </QueryClientProvider>
  </StrictMode>,
)
"""

_INDEX_CSS = """@import 'tailwindcss';
@import url('https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600;700;800&display=swap');

@theme {
  --color-brand: #86bc25;
  --color-brand-dark: #046a38;
  --color-brand-blue: #0076a8;
  --color-brand-amber: #ed8b00;
  --color-brand-red: #da291c;
  --color-surface-50: #ffffff;
  --color-surface-100: #f5f5f1;
  --color-surface-200: #eeeee8;
  --color-surface-300: #e5e5df;
  --color-surface-400: #b0b2ab;
  --color-surface-500: #7d807a;
  --color-surface-600: #5c5f58;
  --color-surface-700: #424540;
  --color-surface-800: #2d302b;
  --color-surface-900: #1a1c19;
  --font-sans: 'Open Sans', system-ui, sans-serif;
  --shadow-card: 0 1px 3px rgba(0, 0, 0, 0.06), 0 1px 2px rgba(0, 0, 0, 0.04);
}

body {
  background-color: var(--color-surface-200);
  color: var(--color-surface-900);
  font-family: 'Open Sans', system-ui, sans-serif;
  -webkit-font-smoothing: antialiased;
}
"""

_README = """# {title} — converted React dashboard

Generated by PBI Converter from `{report}.pbip`. The layout, visuals, filters
and measures were compiled from the original Power BI report; every measure
in the bundled spec passed numeric equivalence checks against Snowflake.

## Run

```bash
npm install
VITE_PBIC_API=http://<converter-backend>:8000 npm run dev
```

The dashboard calls the converter backend's query API, which executes the
compiled SQL against your Snowflake account (connection profile
`{connection_id}`). To point at another backend, change `VITE_PBIC_API`.

## What's inside

- `src/dashboard/` — the spec-driven renderer (same code the Studio runs):
  PageCanvas layout engine, visual registry (cards, slicers, bar/column/line/
  area/donut/waterfall, scatter, combo, gauge, choropleth map, drillable
  treemap, pivot tables), Power BI format-string engine.
- `src/spec.json` — the compiled dashboard spec: pages, visual layouts,
  per-visual queries, measure formats. Reference artifact for developers.
- `public/us-states.geo.json` — public-domain GeoJSON for the map visual.

## Documentation

- `docs/ARCHITECTURE.md` — renderer architecture and data flow
- `docs/VISUALS.md` — every visual, its renderer and query grain (generated from the spec)
- `docs/MEASURES.md` — measure catalog with compile tiers and formats
- `docs/QUERY_API.md` — the backend query contract this app consumes

## Notes

- Visual types with no exact web equivalent are rendered as the nearest
  equivalent and badged in the UI (e.g. decomposition tree → drillable
  treemap).
- All dependencies are MIT/Apache-2.0 licensed.
"""


def build_export_zip(
    spec: DashboardSpec, conversion_id: str, connection_id: str
) -> bytes:
    src = _frontend_src()
    slug = re.sub(r"[^a-z0-9-]+", "-", spec.report_name.lower()).strip("-") or "dashboard"

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        root = f"{slug}-dashboard"
        zf.writestr(f"{root}/package.json", _package_json(slug + "-dashboard"))
        zf.writestr(f"{root}/vite.config.ts", _VITE_CONFIG)
        zf.writestr(f"{root}/tsconfig.json", _TSCONFIG)
        zf.writestr(f"{root}/index.html", _INDEX_HTML.format(title=spec.report_name))
        zf.writestr(f"{root}/README.md", _README.format(
            title=spec.report_name, report=spec.report_name, connection_id=connection_id
        ))
        zf.writestr(f"{root}/src/index.css", _INDEX_CSS)
        zf.writestr(
            f"{root}/src/main.tsx",
            _MAIN_TSX.format(conversion_id=conversion_id, connection_id=connection_id),
        )
        zf.writestr(f"{root}/src/spec.json", spec.model_dump_json(indent=2))

        from app.services.code_docs import build_code_docs

        for rel, content in build_code_docs(spec).items():
            zf.writestr(f"{root}/{rel}", content)

        missing = [rel for rel in _VENDOR if not (src / rel).is_file()]
        if missing:
            raise ExportError(
                "renderer sources unavailable for export "
                f"(looked in {src}; missing e.g. {missing[0]}) — "
                "set PBIC_FRONTEND_SRC or bundle frontend/src into the image"
            )
        for rel in _VENDOR:
            zf.writestr(f"{root}/src/{rel}", (src / rel).read_text(encoding="utf-8"))

        public = src.parent / "public"
        for asset in _PUBLIC_ASSETS:
            p = public / asset
            if p.is_file():
                zf.writestr(f"{root}/public/{asset}", p.read_bytes())

    return buf.getvalue()
