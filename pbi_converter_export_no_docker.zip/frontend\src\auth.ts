export interface User {
  id: string
  email: string
  name: string
  is_admin: boolean
}

const TOKEN_KEY = 'pbic.token'
const USER_KEY = 'pbic.user'

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY)
}

export function getUser(): User | null {
  const raw = localStorage.getItem(USER_KEY)
  return raw ? (JSON.parse(raw) as User) : null
}

export function setSession(token: string, user: User): void {
  localStorage.setItem(TOKEN_KEY, token)
  localStorage.setItem(USER_KEY, JSON.stringify(user))
}

export function clearSession(): void {
  localStorage.removeItem(TOKEN_KEY)
  localStorage.removeItem(USER_KEY)
}

export async function login(email: string, password: string): Promise<User> {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  })
  if (!res.ok) throw new Error((await res.json()).detail ?? 'login failed')
  const body = await res.json()
  setSession(body.token, body.user)
  return body.user
}

export async function signup(email: string, password: string, name: string): Promise<User> {
  const res = await fetch('/api/auth/signup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, name }),
  })
  if (!res.ok) throw new Error((await res.json()).detail ?? 'signup failed')
  const body = await res.json()
  setSession(body.token, body.user)
  return body.user
}

export async function validateSession(): Promise<User | null> {
  const token = getToken()
  if (!token) return null
  const res = await fetch('/api/auth/me', { headers: { Authorization: `Bearer ${token}` } })
  if (!res.ok) {
    clearSession()
    return null
  }
  return res.json()
}
