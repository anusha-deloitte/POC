"""Reference lineage + harness arbitration for visual-compare.

Root-cause coverage for the stale-reference incident: comparisons ran against
a superseded reference PDF, producing 'value differs' findings that
contradicted the (passing) numeric harness, with every fix greyed out and no
explanation. These tests pin the two mechanisms that prevent a recurrence:
hash lineage with staleness, and vision-vs-harness arbitration.
"""

import json

import pytest

from app.api.dashboards import (
    _apply_staleness,
    _arbitrate_findings,
    _harness_pass_map,
    _sha256,
)
from app.api import deps
from app.core import config


@pytest.fixture()
def conv(tmp_path, monkeypatch):
    """Point the module-level ingest service at a tmp storage dir.

    The lineage helpers call get_ingest_service() directly (not via FastAPI
    Depends), so the settings/lru caches must be retargeted, not overridden."""
    monkeypatch.setenv("PBIC_STORAGE_DIR", str(tmp_path / "storage"))
    config.get_settings.cache_clear()
    deps.get_ingest_service.cache_clear()
    cid = "11111111-2222-3333-4444-555555555555"
    conv_dir = tmp_path / "storage" / cid
    (conv_dir / "visual_compare").mkdir(parents=True)
    (conv_dir / "meta.json").write_text("{}", encoding="utf-8")
    yield cid, conv_dir
    config.get_settings.cache_clear()
    deps.get_ingest_service.cache_clear()


def _write_run(conv_dir, page="01-exec", visuals=None):
    fid = {
        "pages": [
            {
                "page": page,
                "visuals": visuals
                or [
                    {
                        "visual": "p1k0",
                        "title": "Total Cost of Care",
                        "checks": [
                            {"name": "execute", "status": "passed"},
                            {"name": "sanity", "status": "passed"},
                        ],
                    },
                    {
                        "visual": "p1x",
                        "title": "Broken Visual",
                        "checks": [{"name": "execute", "status": "failed"}],
                    },
                ],
            }
        ]
    }
    (conv_dir / "conversion_run.json").write_text(
        json.dumps({"fidelity": fid}), encoding="utf-8"
    )


class TestHarnessPassMap:
    def test_maps_by_name_and_title(self, conv):
        cid, conv_dir = conv
        _write_run(conv_dir)
        m = _harness_pass_map(cid, "01-exec")
        assert m["total cost of care"] is True
        assert m["p1k0"] is True
        assert m["broken visual"] is False

    def test_missing_run_is_empty(self, conv):
        cid, _ = conv
        assert _harness_pass_map(cid, "01-exec") == {}


class TestArbitration:
    def test_data_finding_on_proven_visual_contradicts(self, conv):
        cid, conv_dir = conv
        _write_run(conv_dir)
        findings = [
            {"region": "Total Cost of Care", "kind": "formatting", "fix": None},
        ]
        suspect = _arbitrate_findings(cid, "01-exec", findings)
        assert findings[0]["contradicts_harness"] is True
        assert "reference side" in findings[0]["harness_note"]
        assert suspect is True  # 1/1 contradictions

    def test_finding_on_failed_visual_not_contradicted(self, conv):
        cid, conv_dir = conv
        _write_run(conv_dir)
        findings = [{"region": "Broken Visual", "kind": "data-shape", "fix": None}]
        suspect = _arbitrate_findings(cid, "01-exec", findings)
        assert "contradicts_harness" not in findings[0]
        assert suspect is False

    def test_fixable_and_structural_findings_ignored(self, conv):
        cid, conv_dir = conv
        _write_run(conv_dir)
        findings = [
            # automatable — not a data contradiction even on a proven visual
            {"region": "Total Cost of Care", "kind": "formatting",
             "fix": {"op": "set_title", "visual": "p1k0"}},
            # structural kind — arbitration does not apply
            {"region": "Total Cost of Care", "kind": "layout", "fix": None},
        ]
        suspect = _arbitrate_findings(cid, "01-exec", findings)
        assert all("contradicts_harness" not in f for f in findings)
        assert suspect is False

    def test_no_run_no_arbitration(self, conv):
        cid, _ = conv
        findings = [{"region": "Total Cost of Care", "kind": "formatting", "fix": None}]
        assert _arbitrate_findings(cid, "01-exec", findings) is False


class TestStaleness:
    def test_matching_sha_not_stale(self, conv):
        _, conv_dir = conv
        out = conv_dir / "visual_compare"
        ref = b"\x89PNG current"
        (out / "01-exec_reference.png").write_bytes(ref)
        payload = {"page": "01-exec", "reference_sha": _sha256(ref), "stale": False}
        assert _apply_staleness(out, payload)["stale"] is False

    def test_replaced_reference_marks_stale(self, conv):
        _, conv_dir = conv
        out = conv_dir / "visual_compare"
        (out / "01-exec_reference.png").write_bytes(b"\x89PNG NEW reference")
        payload = {
            "page": "01-exec",
            "reference_sha": _sha256(b"\x89PNG OLD reference"),
            "stale": False,
        }
        result = _apply_staleness(out, payload)
        assert result["stale"] is True
        assert "replaced" in result["stale_reason"]

    def test_pre_lineage_payload_is_stale(self, conv):
        _, conv_dir = conv
        out = conv_dir / "visual_compare"
        (out / "01-exec_reference.png").write_bytes(b"\x89PNG any")
        payload = {"page": "01-exec"}  # no reference_sha (old format)
        result = _apply_staleness(out, payload)
        assert result["stale"] is True
        assert "predates" in result["stale_reason"]
