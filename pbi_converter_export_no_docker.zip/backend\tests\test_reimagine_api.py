from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app.api.deps import get_connection_store, get_ingest_service
from app.main import app
from app.runtime.dashboard import DashboardSpec, PageSpec, VisualSpec
from app.runtime.engine import QuerySpec
from app.services.connections import ConnectionStore
from app.services.ingest import IngestService


@pytest.fixture()
def client(tmp_path):
    svc = IngestService(tmp_path / "storage")
    store = ConnectionStore(tmp_path / "storage", tmp_path / "storage" / ".key")
    app.dependency_overrides[get_ingest_service] = lambda: svc
    app.dependency_overrides[get_connection_store] = lambda: store
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


def _spec() -> DashboardSpec:
    return DashboardSpec(
        report_name="Demo Report",
        pages=[
            PageSpec(
                name="page_1",
                display_name="Overview",
                width=1200,
                height=800,
                ordinal=0,
                visuals=[
                    VisualSpec(
                        name="kpi_1",
                        visual_type="card",
                        x=0,
                        y=0,
                        width=240,
                        height=120,
                        z=0,
                        title="Revenue",
                        query=QuerySpec(),
                    ),
                    VisualSpec(
                        name="chart_1",
                        visual_type="clusteredColumnChart",
                        x=0,
                        y=140,
                        width=500,
                        height=280,
                        z=1,
                        title="Revenue by Segment",
                        query=QuerySpec(),
                    ),
                ],
            )
        ],
    )


def test_reimagine_generate_snapshot_mockups_and_lifecycle(client, tmp_path, monkeypatch):
    monkeypatch.setattr("app.api.dashboards._load", lambda conversion_id: (_spec(), None, None))
    reimagine_root = tmp_path / "reimagine"
    reimagine_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr("app.api.dashboards._reimagine_dir", lambda conversion_id: reimagine_root)

    def _fake_batch_query(conversion_id, req, store):
        results = []
        for q in req.queries:
            rows = [[1000]] if q.visual == "kpi_1" else [["Retail", 420], ["SMB", 580]]
            cols = ["Revenue"] if q.visual == "kpi_1" else ["Segment", "Revenue"]
            results.append(
                SimpleNamespace(
                    visual=q.visual,
                    columns=cols,
                    rows=rows,
                    warnings=[],
                    execution_path="semantic_view",
                    fallback_reason=None,
                )
            )
        return SimpleNamespace(results=results)

    monkeypatch.setattr("app.api.dashboards.batch_query", _fake_batch_query)

    generate = client.post(
        "/api/v1/conversions/conv-1/dashboard/reimagine",
        json={"connection_id": "conn-1", "mode": "live", "use_llm": False},
    )
    assert generate.status_code == 200, generate.text
    payload = generate.json()
    rec_id = payload["id"]

    assert payload["snapshot"]["id"]
    assert payload["snapshot"]["connection_id"] == "conn-1"
    assert payload["quality"]["evidence_count"] >= 2
    assert payload["quality"]["coverage"] > 0

    latest = client.get("/api/v1/conversions/conv-1/dashboard/reimagine/latest")
    assert latest.status_code == 200
    assert latest.json()["id"] == rec_id

    mockups = client.get(f"/api/v1/conversions/conv-1/dashboard/reimagine/{rec_id}/mockups")
    assert mockups.status_code == 200
    mockups_payload = mockups.json()
    assert mockups_payload["snapshot"]["id"] == payload["snapshot"]["id"]
    assert len(mockups_payload["scenes"]) >= 1
    assert len(mockups_payload["visual_decisions"]) >= 1

    approve = client.post(
        f"/api/v1/conversions/conv-1/dashboard/reimagine/{rec_id}/approve",
        json={"note": "LGTM"},
    )
    assert approve.status_code == 200
    assert approve.json()["status"] == "approved"

    reject = client.post(
        f"/api/v1/conversions/conv-1/dashboard/reimagine/{rec_id}/reject",
        json={"note": "needs revision"},
    )
    assert reject.status_code == 200
    assert reject.json()["status"] == "rejected"

    history = client.get("/api/v1/conversions/conv-1/dashboard/reimagine/history")
    assert history.status_code == 200
    assert history.json()["recommendations"][0]["id"] == rec_id
    assert history.json()["recommendations"][0]["snapshot_id"] == payload["snapshot"]["id"]

def test_reimagine_build_variant_gate_and_accept(client, tmp_path, monkeypatch):
    """Build lifecycle: build -> built -> spec?variant -> accept (gate-guarded)."""
    monkeypatch.setattr("app.api.dashboards._load", lambda conversion_id: (_spec(), None, None))
    reimagine_root = tmp_path / "reimagine2"
    reimagine_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr("app.api.dashboards._reimagine_dir", lambda conversion_id: reimagine_root)

    def _fake_batch_query(conversion_id, req, store, variant=None):
        results = []
        for q in req.queries:
            rows = [[1000]] if q.visual == "kpi_1" else [["Retail", 420], ["SMB", 580]]
            cols = ["Revenue"] if q.visual == "kpi_1" else [["Segment"], ["Revenue"]]
            results.append(
                SimpleNamespace(
                    visual=q.visual, columns=cols, rows=rows, warnings=[],
                    execution_path="semantic_view", fallback_reason=None,
                )
            )
        return SimpleNamespace(results=results)

    monkeypatch.setattr("app.api.dashboards.batch_query", _fake_batch_query)

    gen = client.post(
        "/api/v1/conversions/conv-2/dashboard/reimagine",
        json={"connection_id": "conn-1", "mode": "live", "use_llm": False},
    )
    assert gen.status_code == 200, gen.text
    rec_id = gen.json()["id"]

    # accept before build -> 409
    early = client.post(
        f"/api/v1/conversions/conv-2/dashboard/reimagine/{rec_id}/accept",
        json={"note": "too soon"},
    )
    assert early.status_code == 409

    build = client.post(f"/api/v1/conversions/conv-2/dashboard/reimagine/{rec_id}/build")
    assert build.status_code == 200, build.text
    body = build.json()
    assert body["built"] is True
    assert body["zero_loss"]["passed"] is True
    assert body["mappings"] == 2

    built = client.get(f"/api/v1/conversions/conv-2/dashboard/reimagine/{rec_id}/built")
    assert built.status_code == 200
    assert built.json()["zero_loss"]["passed"] is True
    assert len(built.json()["mapping"]["entries"]) == 2

    # variant spec served with reimagined layout + flags
    spec_variant = client.get(
        "/api/v1/conversions/conv-2/dashboard/spec", params={"variant": "reimagined"}
    )
    assert spec_variant.status_code == 200
    var = spec_variant.json()
    kpi = var["pages"][0]["visuals"][0]
    assert kpi["options"]["style_variant"] == "reimagined"

    # the studio accepts via the 'latest' alias — must resolve, not 404
    accept = client.post(
        "/api/v1/conversions/conv-2/dashboard/reimagine/latest/accept",
        json={"note": "ship it"},
    )
    assert accept.status_code == 200, accept.text
    assert accept.json()["accepted"] is True
    assert (reimagine_root / "variant_accepted.json").is_file()


def test_reimagine_accept_blocked_by_failed_gate(client, tmp_path, monkeypatch):
    import json as _json

    reimagine_root = tmp_path / "reimagine3"
    reimagine_root.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr("app.api.dashboards._reimagine_dir", lambda conversion_id: reimagine_root)
    (reimagine_root / "zero_loss.json").write_text(
        _json.dumps({"passed": False, "coverage": {}, "gaps": ["measure lost: X"]}),
        encoding="utf-8",
    )
    resp = client.post(
        "/api/v1/conversions/conv-3/dashboard/reimagine/latest/accept",
        json={"note": "try"},
    )
    assert resp.status_code == 409
    assert "measure lost" in resp.json()["detail"]
