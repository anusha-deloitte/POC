import type { EChartsOption } from 'echarts'
import * as echarts from 'echarts'
import { useEffect, useRef } from 'react'

export function EChart({
  option,
  onItemClick,
}: {
  option: EChartsOption
  onItemClick?: (name: string) => void
}) {
  const ref = useRef<HTMLDivElement>(null)
  const chart = useRef<echarts.ECharts | null>(null)
  const clickRef = useRef(onItemClick)
  clickRef.current = onItemClick

  useEffect(() => {
    if (!ref.current) return
    chart.current = echarts.init(ref.current)
    chart.current.on('click', (p) => clickRef.current?.(String(p.name)))
    const onResize = () => chart.current?.resize()
    const ro = new ResizeObserver(onResize)
    ro.observe(ref.current)
    return () => {
      ro.disconnect()
      chart.current?.dispose()
      chart.current = null
    }
  }, [])

  useEffect(() => {
    chart.current?.setOption(option, { notMerge: true })
  }, [option])

  return <div ref={ref} className="h-full w-full" data-testid="echart" />
}
