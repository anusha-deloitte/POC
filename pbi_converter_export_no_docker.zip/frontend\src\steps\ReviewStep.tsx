import { useEffect, useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { api } from '../api/client'
import { useWizard } from '../store/wizard'
import { VisualParity } from './VisualParity'

import {
  askGovernanceReview,
  decideGovernanceReview,
  deploySemanticYaml,
  fetchGovernanceLifecycle,
  fetchGovernanceWorkspace,
  fetchSemanticTraceability,
  remediateGovernanceReview,
  type GovernanceWorkspace,
} from '../dashboard/governance'

interface Check {
  name: string
  status: 'passed' | 'failed' | 'skipped'
  detail: string
}
interface VisualScore {
  visual: string
  page: string
  visual_type: string
  title?: string | null
  checks: Check[]
  substituted_as?: string | null
}
interface PageScore {
  page: string
  display_name: string
  visuals: VisualScore[]
}
interface Fidelity {
  summary: {
    overall_score: number
    visuals_total: number
    visuals_passed: number
    visuals_failed: number
    substituted: number
    measures_tier01: number
    measures_parked: number
    pages: Record<string, number>
  } | null
  fidelity: { pages: PageScore[] } | null
}

function visualStatus(v: VisualScore): 'passed' | 'failed' {
  return v.checks.some((c) => c.status === 'failed') ? 'failed' : 'passed'
}

export function ReviewStep() {
  const conversionId = useWizard((s) => s.conversionId)
  const connectionId = useWizard((s) => s.connectionId)
  const setStep = useWizard((s) => s.setStep)
  const setUnsavedChanges = useWizard((s) => s.setUnsavedChanges)
  const queryClient = useQueryClient()
  const [selectedReviewId, setSelectedReviewId] = useState<string | null>(null)
  const [instruction, setInstruction] = useState('')
  const [question, setQuestion] = useState('')
  const [yamlDraft, setYamlDraft] = useState('')
  const [deployViewName, setDeployViewName] = useState('')
  const [yamlEdited, setYamlEdited] = useState(false)
  const [viewNameEdited, setViewNameEdited] = useState(false)
  const [activeTab, setActiveTab] = useState<'fidelity' | 'parity' | 'traceability' | 'governance'>('fidelity')

  const fid = useQuery({
    queryKey: ['fidelity', conversionId],
    queryFn: async (): Promise<Fidelity> => {
      const res = await fetch(`/api/v1/conversions/${conversionId}/dashboard/fidelity`)
      if (!res.ok) throw new Error((await res.json()).detail ?? res.statusText)
      return res.json()
    },
    enabled: !!conversionId,
  })

  const governance = useQuery({
    queryKey: ['governance', conversionId],
    queryFn: async (): Promise<GovernanceWorkspace> => fetchGovernanceWorkspace(conversionId as string),
    enabled: !!conversionId,
  })

  const lifecycle = useQuery({
    queryKey: ['governance-lifecycle', conversionId],
    queryFn: async () => {
      if (!conversionId) return null
      return fetchGovernanceLifecycle(conversionId)
    },
    enabled: !!conversionId,
  })

  const connections = useQuery({
    queryKey: ['connections'],
    queryFn: api.listConnections,
  })

  const selectedReview = useMemo(() => {
    const reviews = governance.data?.reviews ?? []
    if (!reviews.length) return null
    if (!selectedReviewId) return reviews[0]
    return reviews.find((review) => review.id === selectedReviewId) ?? reviews[0]
  }, [governance.data?.reviews, selectedReviewId])

  const semanticTraceability = useQuery({
    queryKey: ['semantic-traceability', conversionId],
    queryFn: async () => fetchSemanticTraceability(conversionId as string),
    enabled: !!conversionId,
  })

  useEffect(() => {
    const preview = semanticTraceability.data?.preview
    const latest = semanticTraceability.data?.latest
    if (!preview) return
    if (!yamlEdited && !yamlDraft) setYamlDraft(preview.yaml)
    if (!viewNameEdited && !deployViewName) setDeployViewName((latest?.view_name || preview.view_name) ?? '')
  }, [semanticTraceability.data, yamlDraft, deployViewName, yamlEdited, viewNameEdited])

  useEffect(() => {
    const dirty =
      question.trim().length > 0 ||
      instruction.trim().length > 0 ||
      yamlEdited ||
      viewNameEdited
    setUnsavedChanges(dirty, dirty ? 'review edits' : null)
    return () => setUnsavedChanges(false, null)
  }, [question, instruction, yamlEdited, viewNameEdited, setUnsavedChanges])

  const remediation = useMutation({
    mutationFn: async () => {
      if (!conversionId || !selectedReview || !connectionId) throw new Error('Missing conversion or connection context')
      return remediateGovernanceReview(conversionId, selectedReview.id, {
        connection_id: connectionId,
        instruction,
      })
    },
    onSuccess: async () => {
      setInstruction('')
      await queryClient.invalidateQueries({ queryKey: ['governance', conversionId] })
      await queryClient.invalidateQueries({ queryKey: ['fidelity', conversionId] })
    },
  })

  const ask = useMutation({
    mutationFn: async () => {
      if (!conversionId || !selectedReview) throw new Error('Missing review context')
      return askGovernanceReview(conversionId, selectedReview.id, {
        question,
      })
    },
    onSuccess: async () => {
      setQuestion('')
      await queryClient.invalidateQueries({ queryKey: ['governance', conversionId] })
    },
  })

  const deployYaml = useMutation({
    mutationFn: async (dryRun: boolean) => {
      if (!conversionId || !connectionId) throw new Error('Missing conversion or connection context')
      const selectedConnection = connections.data?.find((connection) => connection.id === connectionId)
      if (!selectedConnection?.database || !selectedConnection?.schema_name) {
        throw new Error('Selected connection must define default database and schema in Step 2 before semantic deploy')
      }
      return deploySemanticYaml(conversionId, {
        connection_id: connectionId,
        view_name: deployViewName.trim() || undefined,
        yaml_override: yamlDraft,
        dry_run: dryRun,
        create_or_alter: true,
      })
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['semantic-traceability', conversionId] })
    },
  })

  if (!conversionId) return <p className="text-surface-500">No conversion selected.</p>
  if (fid.isLoading) return <p className="text-surface-500">Loading Migration Health…</p>
  if (fid.isError)
    return (
      <div role="alert" className="rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
        {fid.error.message}
      </div>
    )

  const s = fid.data!.summary
  const pages = fid.data!.fidelity?.pages ?? []
  const governanceSummary = governance.data?.summary
  const reviews = governance.data?.reviews ?? []
  const latestAttempt = selectedReview?.remediation_history?.at(-1)
  const latestQa = selectedReview?.qa_history?.at(-1)
  const tracePreview = semanticTraceability.data?.preview
  const measureTranslation = tracePreview?.measure_translation
  const sourceTargetMappings = tracePreview?.source_target_mappings ?? []
  const bindingSummary = tracePreview?.binding_summary
  const materializations = tracePreview?.materializations ?? []
  const materializationRefresh = tracePreview?.materialization_refresh
  const gateStatus = governanceSummary?.gate_status
  const selectedConnection = connections.data?.find((connection) => connection.id === connectionId)
  const deployTarget =
    selectedConnection?.database && selectedConnection?.schema_name
      ? `${selectedConnection.database}.${selectedConnection.schema_name}`
      : 'Set default database/schema in Step 2'

  const handleDecision = async (decision: 'approved' | 'rejected' | 'promoted' | 'needs_info') => {
    if (!conversionId || !selectedReview) return
    await decideGovernanceReview(conversionId, selectedReview.id, decision)
    await queryClient.invalidateQueries({ queryKey: ['governance', conversionId] })
  }

  return (
    <section>
      <div className="mb-6 flex items-end justify-between overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div>
          <div className="kicker mb-1">Step 5 · Validation results</div>
          <h2 className="text-xl font-bold">Migration Health</h2>
          <p className="mt-1 text-sm text-surface-600">
            Every visual validated against live Snowflake before you see it.
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <a
            href={`/api/v1/conversions/${conversionId}/dashboard/report`}
            className="btn-secondary"
          >
            Download report
          </a>
          <button onClick={() => setStep('preview')} className="btn-primary">
            Open dashboard preview →
          </button>
        </div>
      </div>

      <div className="mb-5 inline-flex items-center gap-1 rounded-xl border border-black/[0.06] bg-surface-50 p-1 shadow-card">
        {(
          [
            ['fidelity', 'Migration Health', s ? `${(s.overall_score * 100).toFixed(0)}%` : null],
            ['parity', 'Visual match', null],
            ['traceability', 'Lineage & deploy', null],
            [
              'governance',
              'Sign-off',
              governanceSummary && governanceSummary.review.open > 0
                ? `${governanceSummary.review.open} open`
                : null,
            ],
          ] as const
        ).map(([value, label, badge]) => (
          <button
            key={value}
            type="button"
            onClick={() => setActiveTab(value)}
            data-active={activeTab === value}
            className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold text-surface-600 transition-colors hover:bg-surface-100 data-[active=true]:bg-brand/10 data-[active=true]:text-brand-dark"
          >
            {label}
            {badge && (
              <span className="rounded-full bg-surface-200 px-1.5 py-0.5 text-[10px] font-bold text-surface-700">
                {badge}
              </span>
            )}
          </button>
        ))}
      </div>

      {activeTab === 'fidelity' && s && (
        <div className="mb-4 rounded-xl border border-brand-blue/15 bg-brand-blue/5 p-3 text-sm text-surface-700">
          <div className="font-semibold text-brand-blue">Next recommended action</div>
          <p className="mt-1">
            {s.visuals_failed > 0
              ? 'Review failed visuals under Sign-off before publishing, or continue with caveats if this run is exploratory.'
              : 'No failed visuals found. Check Visual match against your original report, then continue to Preview.'}
          </p>
        </div>
      )}

      {activeTab === 'traceability' && (
        <div className="mb-4 rounded-xl border border-brand-blue/15 bg-brand-blue/5 p-3 text-sm text-surface-700">
          <div className="font-semibold text-brand-blue">Next recommended action</div>
          <p className="mt-1">
            Validate or deploy YAML only after Migration Health and governance outcomes are acceptable for release.
          </p>
        </div>
      )}

      {activeTab === 'fidelity' && s && (
        <div className="mb-6 grid grid-cols-5 gap-3">
          <Stat label="Overall score" value={`${(s.overall_score * 100).toFixed(1)}%`} accent />
          <Stat label="Visuals passing" value={`${s.visuals_passed}/${s.visuals_total}`} />
          <Stat label="Measures translated" value={String(s.measures_tier01)} />
          <Stat label="Awaiting review" value={String(s.measures_parked)} />
          <Stat label="Closest-match visuals" value={String(s.substituted)} />
        </div>
      )}

      {activeTab === 'fidelity' && gateStatus && (
        <div className={`mb-6 rounded-xl border p-4 ${gateStatus.passed ? 'border-brand/20 bg-brand/5' : 'border-brand-red/20 bg-brand-red/5'}`}>
          <div className="kicker">Conversion gate</div>
          <div className="mt-1 text-sm font-semibold">
            Policy: {gateStatus.mode} · {gateStatus.passed ? 'Passed' : 'Failed'}
          </div>
          <div className="mt-2 space-y-1 text-xs text-surface-700">
            {gateStatus.checks.map((check, idx) => (
              <div key={`${check.name}-${idx}`}>{check.passed ? '✓' : '✗'} {check.name}: {check.detail}</div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'fidelity' && s && s.visuals_failed > 0 && (
        <div className="mb-6 rounded-xl border border-brand-amber/20 bg-brand-amber/5 p-4 text-sm text-surface-700">
          <div className="font-semibold text-brand-amber">Partial success: review required</div>
          <p className="mt-1">
            {s.visuals_failed} visual{s.visuals_failed === 1 ? '' : 's'} did not fully pass parity checks. Continue after reviewing recommended remediation.
          </p>
        </div>
      )}

      {activeTab === 'traceability' && <details className="card mb-6 p-4" open={false}>
        <summary className="flex cursor-pointer list-none items-start justify-between gap-3">
          <div>
            <div className="kicker">Semantic view traceability</div>
            <h3 className="text-lg font-bold">Power BI semantic model → Snowflake semantic view</h3>
            <p className="mt-1 text-sm text-surface-500">
              This shows what was found in the Power BI semantic model, how it translated into Snowflake semantic view structures, and the YAML you can edit and execute manually.
            </p>
          </div>
          <span className="mt-1 rounded-full border border-black/[0.08] bg-surface-50 px-2.5 py-1 text-[11px] font-semibold text-surface-600">
            Expand
          </span>
        </summary>
        <div className="mt-3">
          {semanticTraceability.isLoading ? (
            <p className="text-sm text-surface-500">Loading semantic traceability…</p>
          ) : semanticTraceability.isError ? (
            <p className="rounded-lg border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
              {semanticTraceability.error.message}
            </p>
          ) : (
            <>
            <div className="grid gap-4 lg:grid-cols-2">
              <div className="rounded-xl border border-black/[0.06] bg-surface-50 p-3">
                <div className="text-sm font-semibold">Power BI semantic model</div>
                <div className="mt-2 space-y-1 text-sm text-surface-700">
                  <div><strong>Name:</strong> {tracePreview?.pbi_model.name}</div>
                  <div><strong>Tables:</strong> {tracePreview?.pbi_model.table_count}</div>
                  <div><strong>Relationships:</strong> {tracePreview?.pbi_model.relationship_count}</div>
                  <div><strong>Measures in Power BI:</strong> {tracePreview?.pbi_model.measure_count}</div>
                </div>
                {!!measureTranslation && (
                  <div className="mt-3 rounded-lg border border-black/[0.06] bg-white p-3 text-sm text-surface-700">
                    <div className="font-semibold">Measure translation coverage</div>
                    <div className="mt-1 text-xs text-surface-500">
                      {measureTranslation.translated_measure_total}/{measureTranslation.pbi_measure_total} translated ({(measureTranslation.translation_rate * 100).toFixed(1)}%)
                    </div>
                    <div className="mt-1 text-xs text-surface-500">
                      Untranslated measures: {measureTranslation.untranslated_measure_total}
                    </div>
                  </div>
                )}
              </div>

              <div className="rounded-xl border border-black/[0.06] bg-surface-50 p-3">
                <div className="text-sm font-semibold">Snowflake semantic view translation</div>
                <div className="mt-2 space-y-1 text-sm text-surface-700">
                  <div><strong>View name:</strong> {tracePreview?.snowflake_view.name}</div>
                  <div><strong>Tables mapped:</strong> {tracePreview?.table_count}</div>
                  <div><strong>Relationships:</strong> {tracePreview?.relationship_count}</div>
                  <div><strong>Metrics created:</strong> {tracePreview?.metric_count}</div>
                  <div><strong>Dimensions created:</strong> {tracePreview?.dimension_count}</div>
                  <div><strong>Created in Snowflake at:</strong> {semanticTraceability.data?.semantic_view_location ?? 'Not deployed yet'}</div>
                </div>
                <p className="mt-2 text-xs text-surface-500">
                  The semantic view is created only when you run deploy. Validate is a dry run and does not create objects.
                </p>
                {bindingSummary && (
                  <div className="mt-3 rounded-lg border border-black/[0.06] bg-white p-3 text-xs text-surface-600">
                    <div className="font-semibold text-surface-900">Binding summary</div>
                    <div className="mt-1 grid grid-cols-2 gap-2 sm:grid-cols-4">
                      <div>Resolved: {bindingSummary.resolved}</div>
                      <div>Virtual: {bindingSummary.virtual}</div>
                      <div>Needs materialization: {bindingSummary.materialization_required}</div>
                      <div>Unresolved: {bindingSummary.unresolved}</div>
                    </div>
                    {!!bindingSummary.materialization_by_strategy && Object.keys(bindingSummary.materialization_by_strategy).length > 0 && (
                      <div className="mt-2 text-[11px] text-surface-500">
                        Strategies: {Object.entries(bindingSummary.materialization_by_strategy).map(([name, count]) => `${name}=${count}`).join(', ')}
                      </div>
                    )}
                  </div>
                )}
                {!!materializations.length && (
                  <details className="mt-3 rounded-lg border border-black/[0.06] bg-white p-3 text-xs text-surface-600">
                    <summary className="cursor-pointer font-semibold text-surface-900">
                      Derived-table materialization plan ({materializations.length})
                    </summary>
                    <div className="mt-2 space-y-3">
                      {materializations.map((item) => (
                        <div key={item.table} className="rounded-lg border border-surface-200 bg-surface-50 p-2">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="font-semibold text-surface-900">{item.table}</div>
                            <span className="rounded-full bg-brand-blue/10 px-2 py-0.5 font-semibold text-brand-blue">
                              {item.strategy}
                            </span>
                          </div>
                          {item.detail && <div className="mt-1 text-surface-600">{item.detail}</div>}
                          {item.sql && (
                            <pre className="mt-2 max-h-40 overflow-auto rounded-md bg-slate-950 p-2 text-[11px] leading-relaxed text-slate-100">
                              {item.sql}
                            </pre>
                          )}
                        </div>
                      ))}
                    </div>
                  </details>
                )}
                {materializationRefresh && (
                  <div className="mt-3 rounded-lg border border-black/[0.06] bg-white p-3 text-xs text-surface-600">
                    <div className="font-semibold text-surface-900">Refresh status</div>
                    <div className="mt-1 grid grid-cols-2 gap-2 sm:grid-cols-4">
                      <div>Status: {materializationRefresh.status}</div>
                      <div>Owner: {materializationRefresh.owner ?? 'n/a'}</div>
                      <div>Materializations: {materializationRefresh.materialization_count}</div>
                      <div>
                        Last refresh:{' '}
                        {materializationRefresh.last_refreshed_at
                          ? new Date(materializationRefresh.last_refreshed_at * 1000).toLocaleString()
                          : 'n/a'}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="rounded-xl border border-black/[0.06] bg-surface-50 p-3 lg:col-span-2">
                <div className="text-sm font-semibold">Source to target mapping (Power BI → Snowflake)</div>
                {tracePreview?.query_execution?.notes && (
                  <p className="mt-1 text-xs text-surface-500">
                    {tracePreview.query_execution.notes}
                  </p>
                )}
                <div className="mt-3 overflow-x-auto">
                  <table className="min-w-full border border-surface-200 text-xs">
                    <thead className="bg-surface-100 text-left">
                      <tr>
                        <th className="px-3 py-2 font-semibold">Power BI table</th>
                        <th className="px-3 py-2 font-semibold">Status</th>
                        <th className="px-3 py-2 font-semibold">Snowflake target / reason</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sourceTargetMappings.map((mapping, idx) => (
                        <tr key={`${mapping.pbi_table}-${idx}`} className="border-t border-surface-100">
                          <td className="px-3 py-2 text-surface-700">{mapping.pbi_table}</td>
                          <td className="px-3 py-2 text-surface-700 capitalize">
                            {mapping.status}
                            {mapping.status === 'materialization_required' && mapping.strategy && (
                              <span className="ml-1 rounded-full bg-brand-blue/10 px-1.5 py-0.5 text-[10px] font-semibold text-brand-blue">
                                {mapping.strategy}
                              </span>
                            )}
                          </td>
                          <td className="px-3 py-2 text-surface-500 break-all">{mapping.snowflake_table || mapping.reason || '-'}</td>
                        </tr>
                      ))}
                      {!sourceTargetMappings.length && (
                        <tr>
                          <td className="px-3 py-2 text-surface-500" colSpan={3}>No mapping details available.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
                {!!measureTranslation?.untranslated?.length && (
                  <details className="mt-3 rounded-lg border border-black/[0.06] bg-white p-3">
                    <summary className="cursor-pointer text-sm font-semibold">Show untranslated measures</summary>
                    <div className="mt-2 max-h-48 overflow-auto space-y-1 text-xs text-surface-600">
                      {measureTranslation.untranslated.map((item, idx) => (
                        <div key={`${item.table || 'unknown'}-${item.measure}-${idx}`}>{item.table ? `${item.table}.` : ''}{item.measure} ({item.reason})</div>
                      ))}
                    </div>
                  </details>
                )}
              </div>

              <div className="rounded-xl border border-black/[0.06] bg-surface-50 p-3 lg:col-span-2">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold">Editable YAML</div>
                    <div className="mt-1 text-xs text-surface-500">Edit the translated YAML and validate or deploy it directly to Snowflake.</div>
                  </div>
                </div>
                <div className="mt-3 grid gap-2 md:grid-cols-1">
                  <input value={deployViewName} onChange={(e) => {
                    setViewNameEdited(true)
                    setDeployViewName(e.target.value)
                  }} placeholder="View name" className="rounded-lg border border-surface-200 bg-white px-3 py-2 text-sm outline-none focus:border-brand" />
                </div>
                <div className="mt-2 rounded-lg border border-black/[0.06] bg-white px-3 py-2 text-xs text-surface-600">
                  <strong>Deploy target:</strong> {deployTarget}
                </div>
                <textarea
                  value={yamlDraft}
                  onChange={(e) => {
                    setYamlEdited(true)
                    setYamlDraft(e.target.value)
                  }}
                  rows={20}
                  className="mt-3 w-full rounded-lg border border-surface-200 bg-white px-3 py-2 font-mono text-xs outline-none focus:border-brand"
                />
                <div className="mt-3 flex flex-wrap gap-2">
                  <button className="btn-secondary" disabled={deployYaml.isPending || !connectionId || !selectedConnection?.database || !selectedConnection?.schema_name} onClick={() => deployYaml.mutate(true)}>
                    Validate YAML in Snowflake
                  </button>
                  <button className="btn-primary" disabled={deployYaml.isPending || !connectionId || !selectedConnection?.database || !selectedConnection?.schema_name} onClick={() => deployYaml.mutate(false)}>
                    Deploy edited YAML
                  </button>
                </div>
                {deployYaml.isError && <p className="mt-3 rounded-lg border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">{deployYaml.error.message}</p>}
                {deployYaml.data && <p className="mt-3 rounded-lg border border-brand/20 bg-brand/5 p-3 text-sm text-surface-700">{deployYaml.data.message}</p>}
              </div>
            </div>
            </>
          )}
        </div>
      </details>}

      {activeTab === 'fidelity' && pages.map((p) => (
        <details key={p.page} className="card mb-2 overflow-hidden p-0" open={p.visuals.some((v) => visualStatus(v) === 'failed')}>
          <summary className="cursor-pointer px-4 py-2.5 text-sm font-bold hover:bg-surface-100">
            {p.display_name}{' '}
            <span className="font-normal text-surface-500">
              — {p.visuals.filter((v) => visualStatus(v) === 'passed').length}/{p.visuals.length}{' '}
              passing
            </span>
          </summary>
          <table className="w-full border-t border-surface-200 text-xs">
            <thead className="bg-surface-100 text-left">
              <tr>
                <th className="px-4 py-1.5 font-semibold tracking-wider text-surface-500 uppercase">Visual</th>
                <th className="px-2 py-1.5 font-semibold tracking-wider text-surface-500 uppercase">Type</th>
                <th className="px-2 py-1.5 font-semibold tracking-wider text-surface-500 uppercase">Checks</th>
                <th className="px-2 py-1.5 font-semibold tracking-wider text-surface-500 uppercase">Status</th>
              </tr>
            </thead>
            <tbody>
              {p.visuals.map((v) => (
                <tr key={v.visual} className="border-t border-surface-100 hover:bg-surface-100/60">
                  <td className="px-4 py-1.5">{v.title ?? v.visual}</td>
                  <td className="px-2 py-1.5 text-surface-500">
                    {v.visual_type}
                    {v.substituted_as && (
                      <span className="ml-1 rounded-full bg-brand-blue/10 px-1.5 text-[9px] font-semibold text-brand-blue">
                        ≈ {v.substituted_as}
                      </span>
                    )}
                  </td>
                  <td className="px-2 py-1.5 text-surface-500">
                    {v.checks.map((c) => (
                      <span
                        key={c.name}
                        title={c.detail}
                        data-status={c.status}
                        className="mr-1 rounded px-1 data-[status=failed]:bg-brand-red/10 data-[status=failed]:text-brand-red data-[status=passed]:bg-brand/10 data-[status=passed]:text-brand-dark data-[status=skipped]:bg-surface-100 data-[status=skipped]:text-surface-400"
                      >
                        {c.name}
                      </span>
                    ))}
                  </td>
                  <td className="px-2 py-1.5">
                    {visualStatus(v) === 'passed' ? (
                      <span className="font-bold text-brand-dark">✓</span>
                    ) : (
                      <span className="font-bold text-brand-red">✗</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </details>
      ))}

      {activeTab === 'governance' && <div className="grid gap-4 xl:grid-cols-[320px_minmax(0,1fr)]">
        <div className="card min-w-0 p-4">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <div className="kicker">Governance</div>
              <h3 className="text-lg font-bold">Review queue</h3>
            </div>
            {governanceSummary && (
              <span className="rounded-full bg-brand/10 px-2.5 py-1 text-xs font-semibold text-brand-dark">
                {governanceSummary.review.open} open
              </span>
            )}
          </div>

          {lifecycle.data && (
            <div className="mb-3 rounded-xl border border-black/[0.06] bg-surface-50 p-3">
              <div className="text-[10px] font-semibold tracking-wider text-surface-500 uppercase">Model status</div>
              <div className="mt-1 flex items-center justify-between gap-2">
                <div className="text-sm font-semibold capitalize">{lifecycle.data.state}</div>
                <Badge tone={lifecycle.data.state === 'blocked' ? 'high' : lifecycle.data.state === 'certified' ? 'medium' : 'low'}>
                  {lifecycle.data.state}
                </Badge>
              </div>
              <div className="mt-2 text-xs text-surface-500">
                Version {lifecycle.data.version ?? 'n/a'} · Data {lifecycle.data.data_version ?? 'n/a'}
              </div>
            </div>
          )}

          {governance.isLoading && <p className="text-sm text-surface-500">Loading reviews…</p>}
          {governance.isError && (
            <div className="rounded-lg border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
              <div className="font-semibold">Blocking error: governance context unavailable.</div>
              <p className="mt-1">{governance.error.message}</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <button type="button" className="btn-secondary" onClick={() => setActiveTab('traceability')}>
                  View guidance
                </button>
                <button type="button" className="btn-primary" onClick={() => setStep('preview')}>
                  Continue with caveats
                </button>
              </div>
            </div>
          )}

          <div className="space-y-2">
            {reviews.map((review) => (
              <button
                key={review.id}
                type="button"
                onClick={() => setSelectedReviewId(review.id)}
                className={`w-full rounded-xl border p-3 text-left transition ${selectedReview?.id === review.id ? 'border-brand/30 bg-brand/5' : 'border-black/[0.06] bg-white hover:border-brand/20 hover:bg-surface-50'}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold">{review.title}</div>
                    <div className="mt-1 text-xs text-surface-500">{review.summary}</div>
                  </div>
                  <Badge tone={review.severity}>{review.status}</Badge>
                </div>
                <div className="mt-2 text-[11px] text-surface-500">
                  {review.subject_kind} · {review.subject_id}
                </div>
              </button>
            ))}
            {!reviews.length && <p className="text-sm text-surface-500">No governance items were generated.</p>}
          </div>
        </div>

        <div className="card min-w-0 p-4">
          <div className="mb-3 flex items-center justify-between">
            <div>
              <div className="kicker">Guided resolution</div>
              <h3 className="text-lg font-bold">{selectedReview?.title ?? 'Select a review item'}</h3>
            </div>
            {selectedReview && <Badge tone={selectedReview.severity}>{selectedReview.severity}</Badge>}
          </div>
          {selectedReview ? (
            <>
              <div className="rounded-xl border border-black/[0.06] bg-surface-50 p-3">
                <div className="text-sm font-semibold text-surface-900">What happened</div>
                <p className="mt-1 text-sm text-surface-700">{selectedReview.summary}</p>

                <div className="mt-3 text-sm font-semibold text-surface-900">Business impact</div>
                <p className="mt-1 text-sm text-surface-700">
                  This review item failed validation, which means the converted output is not yet trusted to match the original Power BI behavior closely enough.
                </p>

                <div className="mt-3 text-sm font-semibold text-surface-900">Recommended next step</div>
                <p className="mt-1 text-sm text-surface-700">{selectedReview.recommendation}</p>
              </div>

              <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-surface-500">
                <span>
                  Confidence:{' '}
                  <strong className="text-surface-800">{Math.round(selectedReview.confidence * 100)}%</strong>
                </span>
                <span>
                  Status: <strong className="text-surface-800">{selectedReview.status}</strong>
                </span>
                <span className="break-all">
                  {selectedReview.subject_kind} · {selectedReview.subject_id}
                </span>
                <span>Updated {new Date(selectedReview.updated_at * 1000).toLocaleString()}</span>
              </div>

              <div className="mt-4">
                <div className="flex flex-wrap gap-2">
                  <button className="btn-secondary" onClick={() => setInstruction(selectedReview.recommendation)}>
                    Use recommendation
                  </button>
                  <button className="btn-primary" onClick={() => handleDecision('approved')}>
                    Resolve item
                  </button>
                  <button className="btn-secondary" onClick={() => handleDecision('needs_info')}>
                    Keep open for follow-up
                  </button>
                  <button className="btn-secondary" onClick={() => handleDecision('rejected')}>
                    Reject this recommendation
                  </button>
                </div>
              </div>

              <details className="mt-4 rounded-xl border border-black/[0.06] bg-surface-50 p-3" open={!!(latestQa || ask.data)}>
                <summary className="cursor-pointer text-sm font-semibold">Ask a question</summary>
                <textarea
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  rows={3}
                  placeholder="Ask what happened, why this was recommended, or what happens next"
                  className="mt-3 w-full rounded-lg border border-surface-200 bg-white px-3 py-2 text-sm outline-none focus:border-brand"
                />
                <button className="btn-secondary mt-3" disabled={!question.trim() || ask.isPending} onClick={() => ask.mutate()}>
                  {ask.isPending ? 'Preparing answer…' : 'Ask question'}
                </button>
                {ask.isError && <p className="mt-3 rounded-lg border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">{ask.error.message}</p>}
                {(latestQa || ask.data) && (
                  <div className="mt-3 rounded-lg border border-black/[0.06] bg-white p-3 text-sm text-surface-700">
                    <div className="font-semibold text-surface-900">Most recent answer</div>
                    <div className="mt-2 text-xs font-semibold text-surface-500">{(ask.data?.question || latestQa?.question) ?? ''}</div>
                    <div className="mt-1">{(ask.data?.answer || latestQa?.answer) ?? ''}</div>
                  </div>
                )}
              </details>

              <details className="mt-4 rounded-xl border border-black/[0.06] bg-surface-50 p-3" open={!!(latestAttempt || remediation.data || instruction)}>
                <summary className="cursor-pointer text-sm font-semibold">Run fix and re-check</summary>
                <p className="mt-1 text-xs text-surface-500">
                  A safe change is applied, validation re-runs, and the outcome is saved to history.
                </p>
                <textarea
                  value={instruction}
                  onChange={(e) => setInstruction(e.target.value)}
                  rows={5}
                  placeholder="Describe the fix in plain language"
                  className="mt-3 w-full rounded-lg border border-surface-200 bg-white px-3 py-2 text-sm outline-none focus:border-brand"
                />
                <button
                  className="btn-primary mt-3"
                  disabled={!instruction.trim() || remediation.isPending || !connectionId}
                  onClick={() => remediation.mutate()}
                >
                  {remediation.isPending ? 'Running fix and re-check…' : 'Run fix and re-check'}
                </button>
                {remediation.isError && (
                  <div role="alert" className="mt-3 rounded-lg border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
                    {remediation.error.message}
                  </div>
                )}
                {(latestAttempt || remediation.data) && (
                  <div className="mt-3 rounded-lg border border-black/[0.06] bg-white p-3 text-sm text-surface-700">
                    <div className="font-semibold text-surface-900">Most recent result</div>
                    <div className="mt-1">{remediation.data?.summary || latestAttempt?.summary}</div>
                    <div className="mt-2 text-xs text-surface-500">
                      Status: {remediation.data?.status || latestAttempt?.status} · Ran on {new Date(((remediation.data?.executed_at || latestAttempt?.executed_at || 0) * 1000)).toLocaleString()}
                    </div>
                  </div>
                )}
              </details>

              <details className="mt-4 rounded-xl border border-black/[0.06] bg-surface-50 p-3">
                <summary className="cursor-pointer text-sm font-semibold">
                  Activity history (
                  {(selectedReview.remediation_history ?? []).length +
                    (selectedReview.qa_history ?? []).length +
                    selectedReview.comments.length}
                  )
                </summary>
                <div className="mt-2 space-y-2">
                  {(selectedReview.remediation_history ?? []).map((entry, index) => (
                    <div key={`remediation-${entry.executed_at}-${index}`} className="rounded-lg border border-black/[0.06] bg-white p-3 text-sm">
                      <div className="text-xs font-semibold text-surface-500">
                        Fix attempt · {new Date(entry.executed_at * 1000).toLocaleString()}
                      </div>
                      <div className="mt-1 text-surface-700">{entry.instruction}</div>
                      <div className="mt-1 text-xs text-surface-500">{entry.summary}</div>
                    </div>
                  ))}
                  {(selectedReview.qa_history ?? []).map((entry, index) => (
                    <div key={`qa-${entry.asked_at}-${index}`} className="rounded-lg border border-black/[0.06] bg-white p-3 text-sm">
                      <div className="text-xs font-semibold text-surface-500">
                        Q&amp;A · {new Date(entry.asked_at * 1000).toLocaleString()}
                      </div>
                      <div className="mt-1 text-surface-700"><strong>Q:</strong> {entry.question}</div>
                      <div className="mt-1 text-surface-700"><strong>A:</strong> {entry.answer}</div>
                    </div>
                  ))}
                  {selectedReview.comments.map((entry, index) => (
                    <div key={`${entry.created_at}-${index}`} className="rounded-lg border border-black/[0.06] bg-white p-3 text-sm">
                      <div className="text-xs font-semibold text-surface-500">
                        {entry.author} · {new Date(entry.created_at * 1000).toLocaleString()}
                      </div>
                      <div className="mt-1 text-surface-700">{entry.body}</div>
                    </div>
                  ))}
                  {!selectedReview.comments.length && !(selectedReview.remediation_history ?? []).length && !(selectedReview.qa_history ?? []).length && <p className="text-sm text-surface-500">No history yet.</p>}
                </div>
              </details>
            </>
          ) : (
            <p className="text-sm text-surface-500">Nothing to review — all checks passed. You can promote the model or continue to preview.</p>
          )}
        </div>
      </div>}

      {activeTab === 'parity' && (
        <>
          <div className="mb-4 rounded-xl border border-brand-blue/15 bg-brand-blue/5 p-3 text-sm text-surface-700">
            <div className="font-semibold text-brand-blue">Side-by-side visual check</div>
            <p className="mt-1">
              Compare the converted dashboard against your original Power BI pages and apply
              one-click fixes for formatting, legends and labels.
            </p>
          </div>
          <VisualParity conversionId={conversionId} connectionId={connectionId} />
        </>
      )}

      <div className="sticky bottom-3 z-20 mt-6 rounded-xl border border-black/[0.08] bg-white/95 p-3 shadow-card backdrop-blur">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="text-xs text-surface-600">
            {activeTab === 'fidelity'
              ? 'Migration Health: every number validated against Snowflake.'
              : activeTab === 'parity'
                ? 'Visual match: compare against the original and apply one-click fixes.'
                : activeTab === 'traceability'
                  ? 'Lineage & deploy: see the source-to-target mapping and publish the semantic view.'
                  : 'Sign-off: resolve open items or proceed with caveats.'}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {activeTab !== 'fidelity' && (
              <button type="button" className="btn-secondary" onClick={() => setActiveTab('fidelity')}>
                Back to Migration Health
              </button>
            )}
            {activeTab === 'fidelity' && (
              <button type="button" className="btn-secondary" onClick={() => setActiveTab('parity')}>
                Check visual match
              </button>
            )}
            {activeTab === 'parity' && (
              <button type="button" className="btn-secondary" onClick={() => setActiveTab('governance')}>
                Go to sign-off
              </button>
            )}
            <button type="button" className="btn-primary" onClick={() => setStep('preview')}>
              {governanceSummary && governanceSummary.review.open > 0
                ? 'Continue with caveats'
                : 'Continue to preview'}
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div
      className={`rounded-xl border p-3 text-center shadow-card ${accent ? 'border-brand/25 bg-brand/5' : 'border-black/[0.06] bg-surface-50'}`}
    >
      <div className={`text-xl font-bold ${accent ? 'text-brand-dark' : ''}`}>{value}</div>
      <div className="text-[10px] font-semibold tracking-wider text-surface-500 uppercase">{label}</div>
    </div>
  )
}

function Badge({ tone, children }: { tone: string; children: string }) {
  const className =
    tone === 'high'
      ? 'bg-brand-red/10 text-brand-red'
      : tone === 'medium'
        ? 'bg-brand/10 text-brand-dark'
        : 'bg-surface-100 text-surface-600'
  return <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase ${className}`}>{children}</span>
}



