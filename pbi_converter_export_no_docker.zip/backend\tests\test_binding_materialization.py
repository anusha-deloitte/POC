from app.binding.resolver import build_binding_map
from app.ir.model import Partition, SemanticModel, Table


def test_blocking_m_transforms_require_materialization():
    model = SemanticModel(
        name="Demo",
        tables=[
            Table(
                name="DIM_SERVICE_LINE",
                partitions=[
                    Partition(
                        name="p",
                        source_type="m",
                        expression='''
let
    Source = Snowflake.Databases(Server, Warehouse),
    DB = Source{[Name = "DB", Kind = "Database"]}[Data],
    SCH = DB{[Name = "PUBLIC", Kind = "Schema"]}[Data],
    T = SCH{[Name = "DIM_SERVICE_LINE", Kind = "Table"]}[Data],
    G = Table.Group(T, {"SERVICE_LINE_GROUP"}, {{"CARE_FAMILY_COUNT", each Table.RowCount(_), Int64.Type}})
in
    G
''',
                    )
                ],
            )
        ],
    )

    binding_map = build_binding_map(model)
    binding = binding_map.get("DIM_SERVICE_LINE")

    assert binding is not None
    assert binding.status == "materialization_required"
    assert binding.materialization_strategy == "dynamic_table"
    assert binding.materialization_sql is not None
    assert "GROUP BY" in binding.materialization_sql
    assert binding.detail is not None
    assert "Table.Group" in binding.detail or "materialization" in binding.detail
    assert binding_map.materialization_required[0].table == "DIM_SERVICE_LINE"