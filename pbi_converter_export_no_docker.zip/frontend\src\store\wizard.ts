import { create } from 'zustand'

export type WizardStep = 'upload' | 'connect' | 'analyze' | 'convert' | 'review' | 'preview'

export const STEP_ORDER: WizardStep[] = [
  'upload',
  'connect',
  'analyze',
  'convert',
  'review',
  'preview',
]

interface WizardState {
  step: WizardStep
  conversionId: string | null
  connectionId: string | null
  // source database the report reads today (drives base-table migration)
  sourceConnectionId: string | null
  // false = schema-only migration: objects created, data provisioning delegated
  copyData: boolean
  hasUnsavedChanges: boolean
  unsavedContext: string | null
  setStep: (s: WizardStep) => void
  setConversion: (id: string) => void
  setConnection: (id: string) => void
  setSourceConnection: (id: string | null) => void
  setCopyData: (v: boolean) => void
  resume: (conversionId: string | null, step: WizardStep) => void
  setUnsavedChanges: (dirty: boolean, context?: string | null) => void
  confirmDiscardChanges: () => boolean
  reset: () => void
}

const LAST_CONNECTION_KEY = 'pbic.connection_id'
const LAST_SOURCE_CONNECTION_KEY = 'pbic.source_connection_id'
const COPY_DATA_KEY = 'pbic.copy_data'

export const useWizard = create<WizardState>()((set, get) => ({
  step: 'upload',
  conversionId: null,
  connectionId: localStorage.getItem(LAST_CONNECTION_KEY),
  sourceConnectionId: localStorage.getItem(LAST_SOURCE_CONNECTION_KEY),
  copyData: localStorage.getItem(COPY_DATA_KEY) !== 'false',
  hasUnsavedChanges: false,
  unsavedContext: null,
  setStep: (step) =>
    set((state) => {
      if (state.step === step) return state
      if (state.hasUnsavedChanges) {
        const prompt = `You have unsaved ${state.unsavedContext ?? 'changes'}. Leave this step and discard them?`
        if (!window.confirm(prompt)) return state
      }
      return { ...state, step, hasUnsavedChanges: false, unsavedContext: null }
    }),
  setConversion: (conversionId) =>
    set({ conversionId, step: 'connect', hasUnsavedChanges: false, unsavedContext: null }),
  setConnection: (connectionId) => {
    localStorage.setItem(LAST_CONNECTION_KEY, connectionId)
    set({ connectionId, step: 'analyze', hasUnsavedChanges: false, unsavedContext: null })
  },
  setSourceConnection: (sourceConnectionId) => {
    if (sourceConnectionId) localStorage.setItem(LAST_SOURCE_CONNECTION_KEY, sourceConnectionId)
    else localStorage.removeItem(LAST_SOURCE_CONNECTION_KEY)
    set({ sourceConnectionId })
  },
  setCopyData: (copyData) => {
    localStorage.setItem(COPY_DATA_KEY, String(copyData))
    set({ copyData })
  },
  // open an existing job at a given step (connection persists from last use)
  resume: (conversionId, step) =>
    set({ conversionId, step, hasUnsavedChanges: false, unsavedContext: null }),
  setUnsavedChanges: (hasUnsavedChanges, unsavedContext = null) =>
    set({ hasUnsavedChanges, unsavedContext }),
  confirmDiscardChanges: (): boolean => {
    const state = get()
    if (!state.hasUnsavedChanges) return true
    const prompt = `You have unsaved ${state.unsavedContext ?? 'changes'}. Discard and continue?`
    const confirmed = window.confirm(prompt)
    if (confirmed) set({ hasUnsavedChanges: false, unsavedContext: null })
    return confirmed
  },
  reset: () =>
    set({ step: 'upload', conversionId: null, connectionId: null, hasUnsavedChanges: false, unsavedContext: null }),
}))
