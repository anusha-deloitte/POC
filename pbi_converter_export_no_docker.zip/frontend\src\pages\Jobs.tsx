import { useQuery, useQueryClient } from '@tanstack/react-query'
import {
  AlertTriangle,
  CheckCircle2,
  CircleDot,
  FileUp,
  Filter,
  Inbox,
  Loader2,
  Pencil,
  PlusCircle,
  Search,
  RotateCcw,
  ShieldAlert,
  Trash2,
  Zap,
} from 'lucide-react'
import { useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { api } from '../api/client'
import { useWizard } from '../store/wizard'

interface Job {
  id: string
  name: string | null
  report: string
  pages: number
  visuals: number
  measures: number
  status: 'ingested' | 'needs_review' | 'complete'
  fidelity: number | null
  uploaded_at: number
  converted_at: number | null
  accelerated: boolean
}

type JobSort = 'recent' | 'oldest' | 'fidelity_desc' | 'fidelity_asc' | 'status'
const SORT_VALUES: JobSort[] = ['recent', 'oldest', 'fidelity_desc', 'fidelity_asc', 'status']

function StatusBadge({ status }: { status: Job['status'] }) {
  if (status === 'complete')
    return (
      <span className="badge-green inline-flex items-center gap-1">
        <CheckCircle2 size={12} /> Complete
      </span>
    )
  if (status === 'needs_review')
    return (
      <span className="badge-amber inline-flex items-center gap-1">
        <AlertTriangle size={12} /> Needs review
      </span>
    )
  return (
    <span className="badge-blue inline-flex items-center gap-1">
      <FileUp size={12} /> Ingested
    </span>
  )
}

function FidelityBadge({ value }: { value: number | null }) {
  if (value === null) return <span className="text-surface-400">—</span>
  const pct = value * 100
  const cls = pct >= 90 ? 'badge-green' : pct >= 75 ? 'badge-amber' : 'badge-red'
  return <span className={cls}>{pct.toFixed(1)}%</span>
}

function fmtTime(ts: number | null): string {
  if (!ts) return '—'
  return new Date(ts * 1000).toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function Jobs() {
  const nav = useNavigate()
  const [params, setParams] = useSearchParams()
  const qc = useQueryClient()
  const connectionId = useWizard((s) => s.connectionId)
  const resume = useWizard((s) => s.resume)
  const [selected, setSelected] = useState<Set<string>>(new Set())

  const rawStatus = params.get('status')
  const statusFilter: 'all' | Job['status'] =
    rawStatus === 'ingested' || rawStatus === 'needs_review' || rawStatus === 'complete'
      ? rawStatus
      : 'all'
  const search = params.get('q') ?? ''
  const rawSort = params.get('sort')
  const sort = SORT_VALUES.includes(rawSort as JobSort) ? (rawSort as JobSort) : 'recent'

  const setJobsParams = (patch: Partial<{ status: string; q: string; sort: string }>) => {
    const next = new URLSearchParams(params)
    if (patch.status !== undefined) {
      if (patch.status && patch.status !== 'all') next.set('status', patch.status)
      else next.delete('status')
    }
    if (patch.q !== undefined) {
      const q = patch.q.trim()
      if (q) next.set('q', q)
      else next.delete('q')
    }
    if (patch.sort !== undefined) {
      if (patch.sort && patch.sort !== 'recent') next.set('sort', patch.sort)
      else next.delete('sort')
    }
    setParams(next, { replace: true })
  }

  const [deleting, setDeleting] = useState(false)
  const [renaming, setRenaming] = useState<string | null>(null)
  const [renameValue, setRenameValue] = useState('')
  const jobs = useQuery({
    queryKey: ['jobs'],
    queryFn: async (): Promise<Job[]> => {
      const res = await fetch('/api/v1/conversions/jobs')
      if (!res.ok) throw new Error('failed to load jobs')
      return res.json()
    },
    refetchInterval: 15000,
  })

  const toggle = (id: string) =>
    setSelected((s) => {
      const next = new Set(s)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })

  const deleteJobs = async (ids: string[]) => {
    const label = ids.length === 1 ? 'this job' : `${ids.length} jobs`
    if (!window.confirm(`Delete ${label}? This removes the conversion, its dashboard and history permanently.`))
      return
    setDeleting(true)
    try {
      await Promise.all(ids.map((id) => api.deleteConversion(id)))
      setSelected(new Set())
      await qc.invalidateQueries({ queryKey: ['jobs'] })
    } finally {
      setDeleting(false)
    }
  }

  const commitRename = async (id: string) => {
    const name = renameValue.trim()
    setRenaming(null)
    if (!name) return
    await api.renameJob(id, name)
    await qc.invalidateQueries({ queryKey: ['jobs'] })
  }

  const rows = jobs.data ?? []
  const searchTerm = search.trim().toLowerCase()
  const filteredRows = rows.filter((r) => {
    const statusMatch = statusFilter === 'all' || r.status === statusFilter
    if (!statusMatch) return false
    if (!searchTerm) return true
    const haystack = [r.name ?? '', r.report, r.id.slice(0, 8)].join(' ').toLowerCase()
    return haystack.includes(searchTerm)
  })
  const sortedRows = [...filteredRows].sort((a, b) => {
    if (sort === 'oldest') return a.uploaded_at - b.uploaded_at
    if (sort === 'fidelity_desc') return (b.fidelity ?? -1) - (a.fidelity ?? -1)
    if (sort === 'fidelity_asc') return (a.fidelity ?? Number.MAX_SAFE_INTEGER) - (b.fidelity ?? Number.MAX_SAFE_INTEGER)
    if (sort === 'status') {
      const rank: Record<Job['status'], number> = { needs_review: 0, ingested: 1, complete: 2 }
      return rank[a.status] - rank[b.status] || b.uploaded_at - a.uploaded_at
    }
    return b.uploaded_at - a.uploaded_at
  })
  const complete = rows.filter((r) => r.status === 'complete').length
  const review = rows.filter((r) => r.status === 'needs_review').length
  const priorityRows = sortedRows
    .filter((r) => r.status === 'needs_review' || (r.fidelity !== null && r.fidelity < 0.75))
    .slice(0, 3)
  const avgFid =
    rows.filter((r) => r.fidelity !== null).reduce((a, r) => a + (r.fidelity ?? 0), 0) /
    Math.max(rows.filter((r) => r.fidelity !== null).length, 1)

  const openJob = (job: Job) => {
    resume(job.id, job.status === 'ingested' ? 'connect' : 'review')
    nav('/app/convert')
  }

  const replayJob = (job: Job) => {
    // Replay runs conversion for the same uploaded bundle. If no connection is
    // set yet in this browser profile, route through connect first.
    resume(job.id, connectionId ? 'convert' : 'connect')
    nav('/app/convert')
  }

  return (
    <section>
      <div className="mb-6 flex items-end justify-between overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div>
          <div className="kicker mb-1">Workspace</div>
          <h2 className="text-xl font-bold">Conversion jobs</h2>
          <p className="mt-1 text-sm text-surface-600">
            {rows.length} job{rows.length === 1 ? '' : 's'} · {complete} complete
          </p>
        </div>
        <button
          onClick={() => {
            resume(null, 'upload')
            nav('/app/convert')
          }}
          className="btn-primary inline-flex shrink-0 items-center gap-2"
        >
          <PlusCircle size={16} /> New conversion
        </button>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Complete" value={String(complete)} />
        <Stat label="Needs review" value={String(review)} />
        <Stat label="Avg Migration Health" value={rows.length ? `${(avgFid * 100).toFixed(1)}%` : '—'} accent />
        <Stat label="Accelerated" value={String(rows.filter((r) => r.accelerated).length)} />
      </div>

      {priorityRows.length > 0 && (
        <div className="mb-4 rounded-xl border border-brand-amber/20 bg-brand-amber/5 p-3">
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-brand-amber">
            <ShieldAlert className="h-4 w-4" strokeWidth={1.8} />
            Priority jobs to review
          </div>
          <div className="grid gap-2 lg:grid-cols-3">
            {priorityRows.map((r) => (
              <div key={`priority-${r.id}`} className="rounded-xl border border-brand-amber/25 bg-white p-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="truncate text-sm font-semibold">{r.name ?? r.report}</div>
                  <StatusBadge status={r.status} />
                </div>
                <div className="mt-1 text-xs text-surface-500">
                  {r.pages} pages · {r.visuals} visuals · uploaded {fmtTime(r.uploaded_at)}
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <FidelityBadge value={r.fidelity} />
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      className="rounded-md border border-surface-300 px-2 py-1 text-xs font-semibold text-surface-700 hover:bg-surface-100"
                      onClick={() => replayJob(r)}
                    >
                      Replay
                    </button>
                    <button
                      type="button"
                      className="rounded-md bg-brand px-2 py-1 text-xs font-semibold text-white hover:bg-brand-dark"
                      onClick={() => openJob(r)}
                    >
                      Open
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mb-4 rounded-xl border border-black/[0.06] bg-surface-50 p-3 shadow-card">
        <div className="flex flex-wrap items-center gap-2">
          <label className="relative min-w-[260px] flex-1">
            <Search className="pointer-events-none absolute top-2.5 left-3 h-4 w-4 text-surface-400" strokeWidth={2} />
            <input
              value={search}
              onChange={(e) => setJobsParams({ q: e.target.value })}
              placeholder="Search by job name, report, or id"
              className="input !pl-9"
              aria-label="Search jobs"
            />
          </label>
          <div className="inline-flex items-center gap-1 rounded-lg border border-surface-300 bg-white px-2 py-1">
            <Filter className="h-3.5 w-3.5 text-surface-500" strokeWidth={2} />
            {(
              [
                ['all', 'All'],
                ['needs_review', 'Needs review'],
                ['ingested', 'Ingested'],
                ['complete', 'Complete'],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                type="button"
                onClick={() => setJobsParams({ status: value })}
                data-active={statusFilter === value}
                className="rounded-md px-2 py-1 text-xs font-semibold text-surface-600 transition-colors hover:bg-surface-100 data-[active=true]:bg-brand/10 data-[active=true]:text-brand-dark"
              >
                {label}
              </button>
            ))}
          </div>
          <label className="inline-flex items-center gap-2 rounded-lg border border-surface-300 bg-white px-2 py-1 text-xs text-surface-600">
            Sort
            <select
              value={sort}
              onChange={(e) => setJobsParams({ sort: e.target.value })}
              className="rounded-md border border-surface-200 bg-white px-2 py-1 text-xs font-semibold text-surface-700"
              aria-label="Sort jobs"
            >
              <option value="recent">Newest upload</option>
              <option value="oldest">Oldest upload</option>
              <option value="fidelity_desc">Migration Health high to low</option>
              <option value="fidelity_asc">Migration Health low to high</option>
              <option value="status">Status priority</option>
            </select>
          </label>
        </div>
        <p className="mt-2 text-xs text-surface-500">
          Showing {sortedRows.length} of {rows.length} jobs.
        </p>
      </div>

      {jobs.isLoading && <p className="text-surface-500">Loading…</p>}
      {rows.length === 0 && !jobs.isLoading && (
        <div className="card flex flex-col items-center py-16 text-center">
          <Inbox className="mb-3 h-8 w-8 text-surface-400" strokeWidth={1.5} />
          <div className="font-bold">No conversions yet</div>
          <p className="mt-1 mb-4 text-sm text-surface-500">
            Upload a .pbip report to run your first accuracy-gated conversion.
          </p>
          <button
            onClick={() => {
              resume(null, 'upload')
              nav('/app/convert')
            }}
            className="btn-primary"
          >
            Start a conversion
          </button>
        </div>
      )}

      {selected.size > 0 && (
        <div className="mb-3 flex items-center justify-between rounded-xl border border-brand-red/25 bg-brand-red/5 px-4 py-2.5">
          <span className="text-sm text-surface-700">
            <strong>{selected.size}</strong> job{selected.size === 1 ? '' : 's'} selected
          </span>
          <div className="flex items-center gap-2">
            <button className="btn-secondary !py-1.5 !text-xs" onClick={() => setSelected(new Set())}>
              Clear selection
            </button>
            <button
              className="inline-flex items-center gap-1.5 rounded-[10px] bg-brand-red px-3 py-1.5 text-xs font-semibold text-white hover:bg-brand-red/85 disabled:opacity-50"
              disabled={deleting}
              onClick={() => deleteJobs([...selected])}
            >
              {deleting ? <Loader2 size={13} className="animate-spin" /> : <Trash2 size={13} />}
              Delete selected
            </button>
          </div>
        </div>
      )}

      {rows.length > 0 && sortedRows.length === 0 && (
        <div className="card flex flex-col items-center py-14 text-center">
          <CircleDot className="mb-3 h-8 w-8 text-surface-400" strokeWidth={1.5} />
          <div className="font-bold">No matching jobs</div>
          <p className="mt-1 mb-4 text-sm text-surface-500">
            Adjust filters or clear search to see more jobs.
          </p>
          <button
            type="button"
            className="btn-secondary"
            onClick={() => {
              setJobsParams({ q: '', status: 'all', sort: 'recent' })
            }}
          >
            Clear filters
          </button>
        </div>
      )}

      {sortedRows.length > 0 && (
        <div className="card overflow-hidden p-0">
          <table className="w-full text-sm">
            <thead className="bg-surface-100 text-left">
              <tr>
                <th className="w-10 px-4 py-2.5">
                  <input
                    type="checkbox"
                    aria-label="Select all jobs"
                    className="accent-brand-dark"
                    checked={sortedRows.every((r) => selected.has(r.id)) && sortedRows.length > 0}
                    onChange={(e) =>
                      setSelected((current) => {
                        const next = new Set(current)
                        if (e.target.checked) {
                          sortedRows.forEach((r) => next.add(r.id))
                        } else {
                          sortedRows.forEach((r) => next.delete(r.id))
                        }
                        return next
                      })
                    }
                  />
                </th>
                {['Status', 'Job', 'Scope', 'Migration Health', 'Uploaded', 'Converted', ''].map((h) => (
                  <th
                    key={h}
                    className="px-4 py-2.5 text-[10px] font-bold tracking-wider text-surface-500 uppercase"
                  >
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sortedRows.map((r) => (
                <tr
                  key={r.id}
                  onClick={() => openJob(r)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault()
                      openJob(r)
                    }
                  }}
                  tabIndex={0}
                  role="button"
                  aria-label={`Open job ${r.name ?? r.report}`}
                  data-selected={selected.has(r.id)}
                  className="cursor-pointer border-t border-surface-200 hover:bg-surface-100/70 focus-visible:bg-brand/8 focus-visible:outline-2 focus-visible:outline-brand focus-visible:outline-offset-[-2px] data-[selected=true]:bg-brand/5"
                >
                  <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                    <input
                      type="checkbox"
                      aria-label={`Select ${r.name ?? r.report}`}
                      className="accent-brand-dark"
                      checked={selected.has(r.id)}
                      onChange={() => toggle(r.id)}
                    />
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={r.status} />
                  </td>
                  <td className="px-4 py-3" onClick={(e) => renaming === r.id && e.stopPropagation()}>
                    {renaming === r.id ? (
                      <input
                        autoFocus
                        className="input !w-56 !py-1 text-sm"
                        value={renameValue}
                        maxLength={120}
                        onChange={(e) => setRenameValue(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') commitRename(r.id)
                          if (e.key === 'Escape') setRenaming(null)
                        }}
                        onBlur={() => commitRename(r.id)}
                      />
                    ) : (
                      <>
                        <div className="flex items-center gap-1.5 font-semibold">
                          {r.name ?? r.report}
                          <button
                            aria-label="Rename job"
                            className="text-surface-400 hover:text-brand-dark"
                            onClick={(e) => {
                              e.stopPropagation()
                              setRenaming(r.id)
                              setRenameValue(r.name ?? r.report)
                            }}
                          >
                            <Pencil size={12} strokeWidth={1.8} />
                          </button>
                        </div>
                        <div className="text-[11px] text-surface-500">
                          {r.name ? `${r.report} · ` : ''}
                          {r.id.slice(0, 8)}
                        </div>
                      </>
                    )}
                  </td>
                  <td className="px-4 py-3 text-surface-600">
                    {r.pages} pages · {r.visuals} visuals · {r.measures} measures
                  </td>
                  <td className="px-4 py-3">
                    <FidelityBadge value={r.fidelity} />
                  </td>
                  <td className="px-4 py-3 text-surface-600 tabular-nums">{fmtTime(r.uploaded_at)}</td>
                  <td className="px-4 py-3 text-surface-600 tabular-nums">
                    {fmtTime(r.converted_at)}
                    {r.accelerated && (
                      <Zap size={12} className="ml-1 inline text-brand-dark" aria-label="accelerated" />
                    )}
                  </td>
                  <td className="px-4 py-3 text-right whitespace-nowrap">
                    <button
                      aria-label={`Replay conversion for ${r.name ?? r.report}`}
                      className="mr-3 inline-flex items-center gap-1 rounded-md border border-surface-300 px-2 py-1 align-middle text-xs font-semibold text-surface-700 hover:bg-surface-100"
                      onClick={(e) => {
                        e.stopPropagation()
                        replayJob(r)
                      }}
                    >
                      <RotateCcw size={13} strokeWidth={1.8} />
                      Replay
                    </button>
                    <button
                      aria-label={`Delete ${r.name ?? r.report}`}
                      className="mr-3 align-middle text-surface-400 hover:text-brand-red disabled:opacity-40"
                      disabled={deleting}
                      onClick={(e) => {
                        e.stopPropagation()
                        deleteJobs([r.id])
                      }}
                    >
                      <Trash2 size={15} strokeWidth={1.8} />
                    </button>
                    <span className="text-xs font-semibold text-brand-dark">Open →</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  )
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div
      className={`rounded-xl border p-4 shadow-card ${accent ? 'border-brand/25 bg-brand/5' : 'border-black/[0.06] bg-surface-50'}`}
    >
      <div className="text-[10px] font-bold tracking-wider text-surface-500 uppercase">{label}</div>
      <div className={`mt-1 text-2xl font-bold ${accent ? 'text-brand-dark' : ''}`}>{value}</div>
    </div>
  )
}
