"""Live golden equivalence gate: engine SQL vs hand-written SQL on real Snowflake.

Run with: pytest -m live  (skipped automatically when the connection profile
or connector is unavailable). This is the M1 exit criterion.
"""

from pathlib import Path

import pytest

from app.binding.resolver import build_binding_map
from app.parsers.bundle import load_pbip
from app.runtime.engine import (
    DimensionRef,
    FilterClause,
    MeasureRefSpec,
    QuerySpec,
    SemanticEngine,
)

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"

pytestmark = pytest.mark.live

REL_TOL = 1e-9


def _connect():
    try:
        import snowflake.connector

        from app.core.config import get_settings
        from app.services.connections import ConnectionStore

        settings = get_settings()
        store = ConnectionStore(settings.storage_dir, settings.secrets_key_file)
        profile = next((p for p in store.list() if p.name == "finops-snowflake"), None)
        if profile is None:
            pytest.skip("finops-snowflake profile not registered")
        return snowflake.connector.connect(
            **store.connector_kwargs(profile.id, query_tag="pbic:golden-gate"),
            login_timeout=20,
        )
    except ModuleNotFoundError:
        pytest.skip("snowflake-connector-python not installed")


@pytest.fixture(scope="module")
def conn():
    c = _connect()
    yield c
    c.close()


@pytest.fixture(scope="module")
def engine():
    bundle = load_pbip(FIXTURE)
    return SemanticEngine(bundle.model, build_binding_map(bundle.model))


def run_engine(conn, engine, spec: QuerySpec):
    sql, warnings = engine.build_sql(spec)
    cur = conn.cursor()
    cur.execute(sql)
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, row, strict=True)) for row in cur.fetchall()], sql, warnings


def run_raw(conn, sql: str):
    cur = conn.cursor()
    cur.execute(sql)
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, row, strict=True)) for row in cur.fetchall()]


def assert_close(a, b, label=""):
    if a is None and b is None:
        return
    assert a is not None and b is not None, f"{label}: {a} vs {b}"
    fa, fb = float(a), float(b)
    if fb == 0:
        assert abs(fa) < 1e-6, f"{label}: {fa} vs 0"
    else:
        assert abs(fa - fb) / abs(fb) < REL_TOL, f"{label}: {fa} vs {fb}"


SCHEMA = '"SNOWFLAKE_FINOPS_DASHBOARD__DB"."PBI_HEALTH_ANALYTICS"'


class TestCardGoldens:
    def test_paid_amount_total(self, conn, engine):
        rows, sql, _ = run_engine(
            conn, engine, QuerySpec(measures=[MeasureRefSpec(name="Paid Amount")])
        )
        [golden] = run_raw(
            conn, f'select sum(PAID_AMOUNT) as g from {SCHEMA}."MV_MEDICAL_COST_SUMMARY"'
        )
        assert_close(rows[0]["Paid Amount"], golden["G"], "Paid Amount")

    def test_member_months(self, conn, engine):
        rows, _, _ = run_engine(
            conn, engine, QuerySpec(measures=[MeasureRefSpec(name="Member Months")])
        )
        [golden] = run_raw(
            conn, f'select sum(MEMBER_MONTHS) as g from {SCHEMA}."DT_TOTAL_COST_OF_CARE"'
        )
        assert_close(rows[0]["Member Months"], golden["G"], "Member Months")

    def test_total_pmpm_ratio(self, conn, engine):
        rows, _, _ = run_engine(
            conn, engine, QuerySpec(measures=[MeasureRefSpec(name="Total PMPM")])
        )
        [golden] = run_raw(
            conn,
            f"select sum(TOTAL_COST_OF_CARE) / sum(MEMBER_MONTHS) as g "
            f'from {SCHEMA}."DT_TOTAL_COST_OF_CARE"',
        )
        assert_close(rows[0]["Total PMPM"], golden["G"], "Total PMPM")

    def test_medical_loss_ratio(self, conn, engine):
        rows, _, _ = run_engine(
            conn, engine, QuerySpec(measures=[MeasureRefSpec(name="Medical Loss Ratio")])
        )
        [golden] = run_raw(
            conn,
            f"select sum(NET_COST_OF_CARE) / sum(PREMIUM_REVENUE) as g "
            f'from {SCHEMA}."DT_TOTAL_COST_OF_CARE"',
        )
        assert_close(rows[0]["Medical Loss Ratio"], golden["G"], "MLR")

    def test_target_pmpm_weighted(self, conn, engine):
        rows, _, _ = run_engine(
            conn, engine, QuerySpec(measures=[MeasureRefSpec(name="Target PMPM")])
        )
        [golden] = run_raw(
            conn,
            f"select sum(TARGET_PMPM * BUDGETED_MEMBER_MONTHS) / sum(BUDGETED_MEMBER_MONTHS) "
            f'as g from {SCHEMA}."REF_TARGET_PMPM"',
        )
        assert_close(rows[0]["Target PMPM"], golden["G"], "Target PMPM")


class TestGroupedGoldens:
    def test_allowed_by_lob(self, conn, engine):
        rows, sql, _ = run_engine(
            conn,
            engine,
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_LOB", column="LOB_NAME")],
                measures=[MeasureRefSpec(name="Allowed Amount")],
            ),
        )
        golden = run_raw(
            conn,
            f"select l.LOB_NAME as k, sum(f.ALLOWED_AMOUNT) as g "
            f'from {SCHEMA}."MV_MEDICAL_COST_SUMMARY" f '
            f'join {SCHEMA}."DIM_LOB" l on f.LOB_CODE = l.LOB_CODE '
            f"group by 1 order by 1",
        )
        assert len(rows) == len(golden) == 4
        for r, g in zip(rows, golden, strict=True):
            assert r["DIM_LOB.LOB_NAME"] == g["K"]
            assert_close(r["Allowed Amount"], g["G"], f"Allowed[{g['K']}]")

    def test_slicer_filtered_paid(self, conn, engine):
        rows, _, _ = run_engine(
            conn,
            engine,
            QuerySpec(
                measures=[MeasureRefSpec(name="Paid Amount")],
                filters=[
                    FilterClause(
                        table="DIM_LOB", column="LOB_NAME", values=["Medicare Advantage"]
                    )
                ],
            ),
        )
        [golden] = run_raw(
            conn,
            f"select sum(f.PAID_AMOUNT) as g "
            f'from {SCHEMA}."MV_MEDICAL_COST_SUMMARY" f '
            f'join {SCHEMA}."DIM_LOB" l on f.LOB_CODE = l.LOB_CODE '
            f"where l.LOB_NAME = 'Medicare Advantage'",
        )
        assert_close(rows[0]["Paid Amount"], golden["G"], "Paid[MA]")

    def test_net_cost_by_month(self, conn, engine):
        rows, _, _ = run_engine(
            conn,
            engine,
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_MONTH", column="YEAR_MONTH")],
                measures=[MeasureRefSpec(name="Net Cost of Care")],
            ),
        )
        golden = run_raw(
            conn,
            f"select m.YEAR_MONTH as k, sum(f.NET_COST_OF_CARE) as g "
            f'from {SCHEMA}."DT_TOTAL_COST_OF_CARE" f '
            f'join {SCHEMA}."DIM_MONTH" m on f.YEAR_MONTH_NBR = m.YEAR_MONTH_NBR '
            f"group by 1 order by 1",
        )
        assert len(rows) == len(golden)
        for r, g in zip(rows, golden, strict=True):
            assert_close(r["Net Cost of Care"], g["G"], f"NCC[{g['K']}]")


class TestTimeShiftGoldens:
    def test_allowed_py_by_month(self, conn, engine):
        """SPLY: each month's PY value must equal the raw value 12 months earlier."""
        rows, sql, _ = run_engine(
            conn,
            engine,
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_MONTH", column="YEAR_MONTH")],
                measures=[MeasureRefSpec(name="Allowed PY")],
            ),
        )
        golden = run_raw(
            conn,
            f"""
            with base as (
              select m.YEAR_MONTH_NBR, m.MONTH_START_DATE, m.YEAR_MONTH,
                     sum(f.ALLOWED_AMOUNT) as allowed
              from {SCHEMA}."MV_MEDICAL_COST_SUMMARY" f
              join {SCHEMA}."DIM_MONTH" m on f.YEAR_MONTH_NBR = m.YEAR_MONTH_NBR
              group by 1, 2, 3
            )
            select cur.YEAR_MONTH as k, prior.allowed as g
            from base cur
            left join base prior
              on prior.MONTH_START_DATE = dateadd(year, -1, cur.MONTH_START_DATE)
            order by 1
            """,
        )
        gmap = {g["K"]: g["G"] for g in golden}
        checked = 0
        for r in rows:
            k = r["DIM_MONTH.YEAR_MONTH"]
            if gmap.get(k) is not None:
                assert_close(r["Allowed PY"], gmap[k], f"AllowedPY[{k}]")
                checked += 1
        assert checked >= 12, "expected at least a year of SPLY overlap"

    def test_allowed_ytd_by_month(self, conn, engine):
        rows, _, _ = run_engine(
            conn,
            engine,
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_MONTH", column="YEAR_MONTH")],
                measures=[MeasureRefSpec(name="Allowed YTD")],
            ),
        )
        golden = run_raw(
            conn,
            f"""
            with base as (
              select m.YEAR_MONTH, m.MONTH_START_DATE,
                     sum(f.ALLOWED_AMOUNT) as allowed
              from {SCHEMA}."MV_MEDICAL_COST_SUMMARY" f
              join {SCHEMA}."DIM_MONTH" m on f.YEAR_MONTH_NBR = m.YEAR_MONTH_NBR
              group by 1, 2
            )
            select YEAR_MONTH as k,
                   sum(allowed) over (
                     partition by year(MONTH_START_DATE)
                     order by MONTH_START_DATE
                     rows unbounded preceding
                   ) as g
            from base order by 1
            """,
        )
        gmap = {g["K"]: g["G"] for g in golden}
        for r in rows:
            k = r["DIM_MONTH.YEAR_MONTH"]
            assert_close(r["Allowed YTD"], gmap[k], f"YTD[{k}]")

    def test_rolling_3m_window_average(self, conn, engine):
        """Windowed AVERAGEX = mean of the measure's monthly values (avg-of-ratios)."""
        rows, _, _ = run_engine(
            conn,
            engine,
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_MONTH", column="YEAR_MONTH")],
                measures=[
                    MeasureRefSpec(name="Total PMPM"),
                    MeasureRefSpec(name="PMPM 3M Moving Average"),
                ],
            ),
        )
        monthly = [float(r["Total PMPM"]) for r in rows]
        for i, r in enumerate(rows):
            window = monthly[max(0, i - 2) : i + 1]
            expected = sum(window) / len(window)
            assert_close(r["PMPM 3M Moving Average"], expected, f"MA[{r['DIM_MONTH.YEAR_MONTH']}]")

    def test_yoy_pct_mixed_context(self, conn, engine):
        """Allowed YoY % mixes shifted and unshifted leaves in one expression."""
        rows, _, _ = run_engine(
            conn,
            engine,
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_MONTH", column="YEAR_MONTH")],
                measures=[MeasureRefSpec(name="Allowed YoY %")],
            ),
        )
        golden = run_raw(
            conn,
            f"""
            with base as (
              select m.MONTH_START_DATE, m.YEAR_MONTH, sum(f.ALLOWED_AMOUNT) as allowed
              from {SCHEMA}."MV_MEDICAL_COST_SUMMARY" f
              join {SCHEMA}."DIM_MONTH" m on f.YEAR_MONTH_NBR = m.YEAR_MONTH_NBR
              group by 1, 2
            )
            select cur.YEAR_MONTH as k,
                   case when prior.allowed = 0 or prior.allowed is null then null
                        else (cur.allowed - prior.allowed) / prior.allowed end as g
            from base cur
            left join base prior
              on prior.MONTH_START_DATE = dateadd(year, -1, cur.MONTH_START_DATE)
            order by 1
            """,
        )
        gmap = {g["K"]: g["G"] for g in golden}
        checked = 0
        for r in rows:
            k = r["DIM_MONTH.YEAR_MONTH"]
            if gmap.get(k) is not None and r["Allowed YoY %"] is not None:
                assert_close(r["Allowed YoY %"], gmap[k], f"YoY[{k}]")
                checked += 1
        assert checked >= 12
