from __future__ import annotations

import json
import re
import time
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.api.deps import get_connection_store, get_ingest_service, require_token
from app.binding.resolver import BindingMap
from app.runtime.dashboard import DashboardSpec, compile_dashboard
from app.runtime.engine import SemanticEngine
from app.services.connections import ConnectionStore
from app.services.governance import (
    GovernanceComment,
    GovernanceDecision,
    GovernanceQuestionAnswer,
    GovernanceRemediationAttempt,
    add_comment,
    add_question_answer,
    add_remediation_attempt,
    decide_review,
    get_model_lifecycle,
    load_governance,
    set_model_lifecycle,
)
from app.services.overrides import add_override, apply_overrides, load_overrides, validate_override
from app.validation.harness import run_validation
from app.services.ingest import IngestError, IngestService

router = APIRouter(
    prefix="/api/v1/conversions/{conversion_id}/governance",
    tags=["governance"],
    dependencies=[Depends(require_token)],
)


class DecisionRequest(BaseModel):
    decision: Literal["approved", "rejected", "promoted", "needs_info"]
    comment: str | None = None
    owner: str | None = None


class CommentRequest(BaseModel):
    author: str = "reviewer"
    body: str = Field(min_length=1, max_length=2000)


class LifecycleRequest(BaseModel):
    action: Literal["promote", "demote", "block"]
    owner: str | None = None
    reason: str | None = None


class RemediationRequest(BaseModel):
    connection_id: str
    instruction: str = Field(min_length=5, max_length=2000)
    owner: str | None = None


class RemediationResult(BaseModel):
    review_id: str
    subject_id: str
    instruction: str
    applied_override: dict
    fixed: bool
    status: str
    summary: str
    visual_checks: list[dict] = Field(default_factory=list)
    history: list[dict] = Field(default_factory=list)
    executed_at: float = Field(default_factory=time.time)


class AskRequest(BaseModel):
    question: str = Field(min_length=5, max_length=2000)
    owner: str | None = None


class AskResult(BaseModel):
    review_id: str
    question: str
    answer: str
    asked_at: float = Field(default_factory=time.time)
    history: list[dict] = Field(default_factory=list)


def _load(conversion_id: str, svc: IngestService) -> dict:
    try:
        return load_governance(conversion_id, svc)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e


def _tier2_sql(conversion_id: str, svc: IngestService) -> dict[str, str]:
    try:
        path = svc.conversion_dir(conversion_id) / "conversion_run.json"
    except ValueError:
        return {}
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("tier2_accepted", {})
    except (OSError, ValueError):
        return {}


def _compiled_spec(
    conversion_id: str,
    svc: IngestService,
) -> tuple[DashboardSpec, BindingMap, SemanticEngine]:
    bundle = svc.load_bundle(conversion_id)
    tier2_sql = _tier2_sql(conversion_id, svc)
    spec, binding_map = compile_dashboard(bundle, tier2_sql=tier2_sql)
    overrides = load_overrides(svc.conversion_dir(conversion_id))
    if overrides:
        spec.warnings.extend(apply_overrides(spec, overrides))
    return spec, binding_map, SemanticEngine(bundle.model, binding_map, tier2_sql=tier2_sql)


def _connect(store: ConnectionStore, connection_id: str, conversion_id: str):
    import snowflake.connector

    try:
        kwargs = store.connector_kwargs(connection_id, query_tag=f"pbic:governance:{conversion_id}")
    except (KeyError, ValueError) as e:
        raise HTTPException(422, f"invalid connection configuration: {e}") from e
    return snowflake.connector.connect(**kwargs, login_timeout=20)


_JSON_RE = re.compile(r"\{.*\}", re.DOTALL)


def _extract_json(text: str) -> dict | None:
    match = _JSON_RE.search(text)
    if not match:
        return None
    try:
        return json.loads(match.group(0))
    except json.JSONDecodeError:
        return None


def _fallback_override(visual_ctx: dict, instruction: str) -> dict:
    text = instruction.lower()
    page = visual_ctx["page"]
    visual = visual_ctx["visual"]

    if "hide" in text or "remove" in text:
        return {"op": "hide_visual", "page": page, "visual": visual}

    visual_type_map = {
        "bar": "barChart",
        "line": "lineChart",
        "area": "areaChart",
        "table": "tableEx",
        "card": "card",
        "pie": "pieChart",
    }
    for needle, mapped in visual_type_map.items():
        if needle in text:
            return {
                "op": "set_visual_type",
                "page": page,
                "visual": visual,
                "value": mapped,
            }

    title_match = re.search(r"title\s+(?:to|as)\s+[\"']?([^\"'\n]+)", instruction, flags=re.IGNORECASE)
    if title_match:
        return {
            "op": "set_title",
            "page": page,
            "visual": visual,
            "value": title_match.group(1).strip(),
        }

    # Safe default: append a review marker to the title so users can verify the run loop works.
    fallback_title = (visual_ctx.get("title") or visual_ctx["visual"]).strip() + " (reviewed)"
    return {
        "op": "set_title",
        "page": page,
        "visual": visual,
        "value": fallback_title,
    }


def _fallback_answer(review: dict, question: str) -> str:
    rec = review.get("recommendation") or "Run a focused remediation and re-check this visual."
    status = review.get("status") or "open"
    summary = review.get("summary") or "No summary available."
    attempts = review.get("remediation_history") or []
    attempts_text = "No previous fix attempts were recorded yet."
    if attempts:
        latest = attempts[-1]
        attempts_text = (
            f"Latest fix attempt status was '{latest.get('status', 'unknown')}' "
            f"with summary: {latest.get('summary', 'n/a')}"
        )
    return (
        "OpenAI-assisted Q&A is unavailable right now, so this is a deterministic explanation from review context. "
        f"Current review status is '{status}'. "
        f"What happened: {summary} "
        f"Recommended next step: {rec} "
        f"History: {attempts_text} "
        f"Question received: {question}"
    )


def _conversion_gate_status(conversion_id: str, svc: IngestService) -> dict | None:
    try:
        run_path = svc.conversion_dir(conversion_id) / "conversion_run.json"
    except ValueError:
        return None
    if not run_path.is_file():
        return None
    try:
        payload = json.loads(run_path.read_text(encoding="utf-8"))
    except ValueError:
        return None
    gate = payload.get("gate_status")
    return gate if isinstance(gate, dict) else None


def _enforce_promotion_gate(conversion_id: str, svc: IngestService) -> None:
    gate = _conversion_gate_status(conversion_id, svc)
    if not gate:
        return
    mode = str(gate.get("mode") or "advisory")
    passed = bool(gate.get("passed", True))
    if mode in {"strict", "release_candidate"} and not passed:
        raise HTTPException(
            422,
            {
                "message": "Promotion blocked by conversion gate policy",
                "gate_status": gate,
            },
        )


def _visual_context(spec: DashboardSpec, subject_id: str) -> dict:
    page_name, visual_name = subject_id.split("::", 1)
    page = next((p for p in spec.pages if p.name == page_name), None)
    if page is None:
        raise ValueError("review page not found")
    visual = next((v for v in page.visuals if v.name == visual_name), None)
    if visual is None:
        raise ValueError("review visual not found")
    return {
        "page": page.name,
        "page_display_name": page.display_name,
        "visual": visual.name,
        "title": visual.title,
        "visual_type": visual.visual_type,
        "measure_keys": list(visual.measure_keys),
        "dim_keys": list(visual.dim_keys),
        "series_keys": list(visual.series_keys),
        "sort": getattr(visual, "sort", []),
        "options": getattr(visual, "options", {}),
    }


def _propose_override(review: dict, visual_ctx: dict, instruction: str) -> dict:
    from app.core.config import get_settings

    try:
        from openai import OpenAI
    except ModuleNotFoundError:
        return _fallback_override(visual_ctx, instruction)

    key = get_settings().openai_api_key
    if not key:
        return _fallback_override(visual_ctx, instruction)

    system = (
        "You translate human remediation requests into a single JSON override for a Power BI migration UI. "
        "Return only JSON with keys: op, page, visual, and the op params. "
        "Allowed ops: set_title(value), set_visual_type(value), set_measure_format(measure,value), "
        "set_sort(key,direction), set_limit(value), move_resize(x,y,width,height), hide_visual, "
        "swap_series_role(column), drop_measure(measure), drop_dimension(column), set_option(key,value). "
        "Do not invent fields outside this vocabulary."
    )
    user = {
        "review": {
            "id": review["id"],
            "title": review["title"],
            "summary": review["summary"],
            "recommendation": review["recommendation"],
        },
        "visual": visual_ctx,
        "instruction": instruction,
    }
    client = OpenAI(api_key=key)
    resp = client.chat.completions.create(
        model="gpt-4o",
        temperature=0,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": json.dumps(user)},
        ],
    )
    text = resp.choices[0].message.content or ""
    payload = _extract_json(text)
    if payload is None:
        return _fallback_override(visual_ctx, instruction)
    payload.setdefault("page", visual_ctx["page"])
    payload.setdefault("visual", visual_ctx["visual"])
    return payload


def _answer_review_question(review: dict, question: str) -> str:
    from app.core.config import get_settings

    try:
        from openai import OpenAI
    except ModuleNotFoundError:
        return _fallback_answer(review, question)

    key = get_settings().openai_api_key
    if not key:
        return _fallback_answer(review, question)

    client = OpenAI(api_key=key)
    system = (
        "You explain a Power BI migration issue in plain English for a reviewer. "
        "Be concrete, concise, and action-oriented. Answer using only the provided context."
    )
    prompt = {
        "review": {
            "title": review.get("title"),
            "summary": review.get("summary"),
            "recommendation": review.get("recommendation"),
            "status": review.get("status"),
            "remediation_history": review.get("remediation_history") or [],
        },
        "question": question,
    }
    resp = client.chat.completions.create(
        model="gpt-4o",
        temperature=0,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": json.dumps(prompt)},
        ],
    )
    answer = (resp.choices[0].message.content or "").strip()
    return answer or _fallback_answer(review, question)


@router.get("")
def governance_summary(
    conversion_id: str,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    return _load(conversion_id, svc)


@router.get("/reviews")
def governance_reviews(
    conversion_id: str,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    payload = _load(conversion_id, svc)
    return {"reviews": payload["reviews"], "summary": payload["summary"]}


@router.get("/history")
def governance_history(
    conversion_id: str,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    payload = _load(conversion_id, svc)
    return {"compare_history": payload["compare_history"], "promotion_history": payload["history"]}


@router.get("/lifecycle")
def governance_lifecycle(
    conversion_id: str,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    try:
        return get_model_lifecycle(conversion_id, svc)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e


@router.post("/lifecycle")
def governance_lifecycle_update(
    conversion_id: str,
    req: LifecycleRequest,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    try:
        if req.action == "promote":
            _enforce_promotion_gate(conversion_id, svc)
        return set_model_lifecycle(conversion_id, svc, req.action, req.owner, req.reason)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e


@router.get("/impact/{subject_kind}/{subject_id:path}")
def governance_impact(
    conversion_id: str,
    subject_kind: str,
    subject_id: str,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    payload = _load(conversion_id, svc)
    if subject_kind not in {"visual", "measure", "page", "model"}:
        raise HTTPException(422, "unsupported subject kind")
    for review in payload["reviews"]:
        if review["subject_kind"] == subject_kind and review["subject_id"] == subject_id:
            return {"subject": review, "impact": review.get("impact") or {}, "provenance": review.get("provenance") or {}}
    raise HTTPException(404, "subject not found")


@router.get("/provenance/{subject_kind}/{subject_id:path}")
def governance_provenance(
    conversion_id: str,
    subject_kind: str,
    subject_id: str,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    payload = _load(conversion_id, svc)
    if subject_kind not in {"visual", "measure", "page", "model"}:
        raise HTTPException(422, "unsupported subject kind")
    for review in payload["reviews"]:
        if review["subject_kind"] == subject_kind and review["subject_id"] == subject_id:
            return {"subject": review, "provenance": review.get("provenance") or {}}
    if subject_kind == "model":
        return {"subject": payload["model"], "provenance": {"nodes": [], "edges": []}}
    raise HTTPException(404, "subject not found")


@router.post("/reviews/{review_id}/decision")
def governance_decision(
    conversion_id: str,
    review_id: str,
    req: DecisionRequest,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    try:
        if req.decision == "promoted":
            _enforce_promotion_gate(conversion_id, svc)
        return decide_review(
            conversion_id,
            svc,
            review_id,
            GovernanceDecision(decision=req.decision, comment=req.comment, owner=req.owner),
        )
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e


@router.post("/reviews/{review_id}/comments")
def governance_comment(
    conversion_id: str,
    review_id: str,
    req: CommentRequest,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    try:
        return add_comment(
            conversion_id,
            svc,
            review_id,
            GovernanceComment(author=req.author, body=req.body),
        )
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e


@router.post("/reviews/{review_id}/remediate", response_model=RemediationResult)
def governance_remediate(
    conversion_id: str,
    review_id: str,
    req: RemediationRequest,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> RemediationResult:
    payload = _load(conversion_id, svc)
    review = next((item for item in payload["reviews"] if item["id"] == review_id), None)
    if review is None:
        raise HTTPException(404, "review not found")
    if review["subject_kind"] != "visual":
        raise HTTPException(422, "natural-language remediation currently supports visual reviews only")

    spec, binding_map, engine = _compiled_spec(conversion_id, svc)
    try:
        visual_ctx = _visual_context(spec, review["subject_id"])
    except ValueError as e:
        raise HTTPException(404, str(e)) from e

    override = _propose_override(review, visual_ctx, req.instruction)
    error = validate_override(spec, override)
    if error:
        raise HTTPException(422, f"agent proposed invalid remediation: {error}")

    conv_dir = svc.conversion_dir(conversion_id)
    add_override(conv_dir, override, finding_id=review_id)

    spec, binding_map, engine = _compiled_spec(conversion_id, svc)
    conn = _connect(store, req.connection_id, conversion_id)
    try:
        cursor = conn.cursor()
        report = run_validation(spec, engine, cursor)
    finally:
        conn.close()

    page_name, visual_name = review["subject_id"].split("::", 1)
    visual_score = next(
        (
            visual
            for page in report.pages
            if page.page == page_name
            for visual in page.visuals
            if visual.visual == visual_name
        ),
        None,
    )
    if visual_score is None:
        raise HTTPException(500, "revalidation could not locate the remediated visual")

    fixed = visual_score.status.value == "passed"
    summary = (
        "Revalidation passed for this visual after applying the suggested remediation."
        if fixed
        else "Revalidation still failed for this visual after applying the suggested remediation."
    )
    attempt = GovernanceRemediationAttempt(
        instruction=req.instruction,
        applied_override=override,
        fixed=fixed,
        status=visual_score.status.value,
        summary=summary,
        visual_checks=[check.model_dump() for check in visual_score.checks],
        owner=req.owner,
    )
    add_remediation_attempt(conversion_id, svc, review_id, attempt)
    decision = GovernanceDecision(
        decision="promoted" if fixed else "needs_info",
        comment=f"Natural-language remediation run by {req.owner or 'reviewer'}: {req.instruction}",
        owner=req.owner,
    )
    if fixed:
        try:
            _enforce_promotion_gate(conversion_id, svc)
        except HTTPException:
            decision = GovernanceDecision(
                decision="needs_info",
                comment=(
                    f"Fix succeeded but promotion is blocked by conversion gate policy. "
                    f"Run strict gate checks before promoting. Instruction: {req.instruction}"
                ),
                owner=req.owner,
            )
    decide_review(conversion_id, svc, review_id, decision)

    refreshed = _load(conversion_id, svc)
    refreshed_review = next((item for item in refreshed["reviews"] if item["id"] == review_id), None)

    return RemediationResult(
        review_id=review_id,
        subject_id=review["subject_id"],
        instruction=req.instruction,
        applied_override=override,
        fixed=fixed,
        status=visual_score.status.value,
        summary=summary,
        visual_checks=attempt.visual_checks,
        history=(refreshed_review or {}).get("remediation_history", []),
        executed_at=attempt.executed_at,
    )


@router.post("/reviews/{review_id}/ask", response_model=AskResult)
def governance_ask(
    conversion_id: str,
    review_id: str,
    req: AskRequest,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> AskResult:
    payload = _load(conversion_id, svc)
    review = next((item for item in payload["reviews"] if item["id"] == review_id), None)
    if review is None:
        raise HTTPException(404, "review not found")

    answer = _answer_review_question(review, req.question)
    item = GovernanceQuestionAnswer(question=req.question, answer=answer, owner=req.owner)
    add_question_answer(conversion_id, svc, review_id, item)
    refreshed = _load(conversion_id, svc)
    refreshed_review = next((candidate for candidate in refreshed["reviews"] if candidate["id"] == review_id), None)
    return AskResult(
      review_id=review_id,
      question=req.question,
      answer=answer,
      asked_at=item.asked_at,
      history=(refreshed_review or {}).get("qa_history", []),
    )
