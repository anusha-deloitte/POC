export interface SourceDatabaseInfo {
  kind: 'snowflake' | 'sqlserver' | 'postgres' | 'mysql' | 'oracle'
  needs_migration: boolean
  tables: { table: string; kind: string; schema: string | null; object: string | null; database: string | null }[]
}

export interface ConversionSummary {
  id: string
  report: string
  model: {
    tables: number
    relationships: number
    measures: number
    roles: number
  }
  pages: { name: string; display_name: string; visuals: number }[]
  visual_types: Record<string, number>
  source_database?: SourceDatabaseInfo
  warnings: string[]
}

export type SourceKind = 'sqlserver' | 'postgres' | 'mysql' | 'oracle'

export interface SourceConnectionProfile {
  id: string
  name: string
  kind: SourceKind
  host: string
  port: number | null
  database: string
  user: string
}

export interface NewSourceConnection {
  name: string
  kind: SourceKind
  host: string
  port?: number | null
  database: string
  user: string
  password: string
}

export type AuthMethod = 'password' | 'key_pair' | 'oauth_client_credentials' | 'pat'

export interface ConnectionProfile {
  id: string
  name: string
  account: string
  user: string
  auth_method: AuthMethod
  role?: string | null
  warehouse?: string | null
  database?: string | null
  schema_name?: string | null
}

export interface ConnectionTestResult {
  ok: boolean
  latency_ms?: number
  version?: string
  role?: string
  warehouse?: string
  database?: string
  error?: string
}

export interface NewConnection {
  name: string
  account: string
  user: string
  auth_method: AuthMethod
  database: string
  schema: string
  role?: string
  warehouse?: string
  password?: string
  private_key_pem?: string
  private_key_passphrase?: string
  oauth_client_id?: string
  oauth_client_secret?: string
  oauth_token_url?: string
  pat_token?: string
}
