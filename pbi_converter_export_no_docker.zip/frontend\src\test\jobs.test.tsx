import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { MemoryRouter, Route, Routes, useLocation } from 'react-router-dom'
import { Jobs } from '../pages/Jobs'
import { useWizard } from '../store/wizard'

function LocationProbe() {
  const location = useLocation()
  return <div data-testid="location-search">{location.search}</div>
}

function renderJobs(initialEntry = '/app/jobs') {
  const client = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
    },
  })

  return render(
    <QueryClientProvider client={client}>
      <MemoryRouter initialEntries={[initialEntry]}>
        <Routes>
          <Route
            path="/app/jobs"
            element={
              <>
                <LocationProbe />
                <Jobs />
              </>
            }
          />
          <Route path="/app/convert" element={<div>Convert route</div>} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>,
  )
}

describe('Jobs desktop filters', () => {
  beforeEach(() => {
    useWizard.setState({
      step: 'upload',
      conversionId: null,
      connectionId: 'conn-1',
    })

    global.fetch = vi.fn(async (input: RequestInfo | URL) => {
      const url = String(input)
      if (url.endsWith('/api/v1/conversions/jobs')) {
        return new Response(
          JSON.stringify([
            {
              id: 'aaa11111-1111-1111-1111-111111111111',
              name: 'Alpha migration',
              report: 'Alpha Report',
              pages: 2,
              visuals: 8,
              measures: 10,
              status: 'complete',
              fidelity: 0.95,
              uploaded_at: 1700000100,
              converted_at: 1700000200,
              accelerated: true,
            },
            {
              id: 'bbb22222-2222-2222-2222-222222222222',
              name: 'Beta remediation',
              report: 'Beta Report',
              pages: 1,
              visuals: 4,
              measures: 6,
              status: 'needs_review',
              fidelity: 0.72,
              uploaded_at: 1700000300,
              converted_at: 1700000400,
              accelerated: false,
            },
            {
              id: 'ccc33333-3333-3333-3333-333333333333',
              name: 'Gamma ingest',
              report: 'Gamma Report',
              pages: 3,
              visuals: 12,
              measures: 15,
              status: 'ingested',
              fidelity: null,
              uploaded_at: 1700000000,
              converted_at: null,
              accelerated: false,
            },
          ]),
          { status: 200 },
        )
      }
      return new Response(JSON.stringify({ detail: `unexpected url: ${url}` }), { status: 404 })
    }) as typeof fetch
  })

  it('hydrates filters from URL query params', async () => {
    renderJobs('/app/jobs?status=complete&q=alpha&sort=oldest')

    expect(await screen.findByText('Showing 1 of 3 jobs.')).toBeInTheDocument()
    expect(screen.getByText('Alpha migration')).toBeInTheDocument()
    expect(screen.queryByText('Beta remediation')).not.toBeInTheDocument()

    expect(screen.getByLabelText('Search jobs')).toHaveValue('alpha')
    expect(screen.getByLabelText('Sort jobs')).toHaveValue('oldest')
  })

  it('updates URL params when filters change', async () => {
    const user = userEvent.setup()
    renderJobs('/app/jobs')

    await screen.findByText('Showing 3 of 3 jobs.')

    await user.click(screen.getByRole('button', { name: 'Needs review' }))
    await waitFor(() => {
      expect(screen.getByTestId('location-search').textContent).toContain('status=needs_review')
      expect(screen.getByText('Showing 1 of 3 jobs.')).toBeInTheDocument()
    })

    await user.clear(screen.getByLabelText('Search jobs'))
    await user.type(screen.getByLabelText('Search jobs'), 'beta')
    await waitFor(() => {
      expect(screen.getByTestId('location-search').textContent).toContain('q=beta')
    })

    await user.selectOptions(screen.getByLabelText('Sort jobs'), 'fidelity_asc')
    await waitFor(() => {
      expect(screen.getByTestId('location-search').textContent).toContain('sort=fidelity_asc')
    })
  })

  it('opens a job with keyboard on table row', async () => {
    const user = userEvent.setup()
    renderJobs('/app/jobs')

    const rowButton = await screen.findByRole('button', { name: /Open job Alpha migration/i })
    rowButton.focus()
    await user.keyboard('{Enter}')

    await waitFor(() => {
      expect(screen.getByText('Convert route')).toBeInTheDocument()
    })
  })
})
