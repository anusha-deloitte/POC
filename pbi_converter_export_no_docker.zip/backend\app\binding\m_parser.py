"""Extract physical Snowflake objects from Power Query (M) partition sources.

Handles the navigation patterns Power BI Desktop emits for Snowflake:

    Source = Snowflake.Databases(Server, Warehouse, [Role = R]),
    Db  = Source{[Name = "DB" | Param, Kind = "Database"]}[Data],
    Sch = Db{[Name = "SCHEMA", Kind = "Schema"]}[Data],
    Obj = Sch{[Name = "TABLE", Kind = "Table" | "View"]}[Data]

plus Value.NativeQuery(...) passthrough SQL. Name values may be string
literals or references to shared expressions (parameters), which are
resolved via the model's expression map. Trailing transform steps
(Table.RemoveColumns etc.) are captured for the view-compiler to inspect.

Phase-5 extension: Table.SelectRows and Table.RenameColumns predicates are
parsed and stored in MBinding so the resolver can inject WHERE clauses and
column aliases into the physical binding.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

_STEP_RE = re.compile(
    r"\{\[\s*Name\s*=\s*(?P<name>\"[^\"]*\"|[\w.]+)\s*"
    r"(?:,\s*Kind\s*=\s*\"(?P<kind>[^\"]+)\")?\s*\]\}",
)
_NATIVE_RE = re.compile(r"Value\.NativeQuery\s*\(", re.IGNORECASE)
_SNOWFLAKE_SRC_RE = re.compile(r"Snowflake\.Databases\s*\(", re.IGNORECASE)
# foreign sources the migration mover can lift into Snowflake
_FOREIGN_SRC_RES: list[tuple[str, "re.Pattern[str]"]] = [
    # lookbehind: bare Sql.* must not match inside PostgreSQL.*/MySQL.*
    ("sqlserver", re.compile(r"(?<![A-Za-z])Sql\.Databases?\s*\(", re.IGNORECASE)),
    ("postgres", re.compile(r"PostgreSQL\.Database\s*\(", re.IGNORECASE)),
    ("mysql", re.compile(r"MySQL\.Database\s*\(", re.IGNORECASE)),
    ("oracle", re.compile(r"Oracle\.Database\s*\(", re.IGNORECASE)),
]
# SQL Server / PostgreSQL navigation: Source{[Schema="dbo", Item="FactSales"]}[Data]
_SCHEMA_ITEM_RE = re.compile(
    r"\{\[\s*Schema\s*=\s*(?P<schema>\"[^\"]*\"|[\w.]+)\s*,\s*"
    r"Item\s*=\s*(?P<item>\"[^\"]*\"|[\w.]+)\s*\]\}",
)
# steps beyond pure navigation, e.g. Table.RemoveColumns(...), Table.SelectRows(...)
_TRANSFORM_RE = re.compile(r"\b(Table\.[A-Za-z]+)\s*\(")
_PARAM_STRIP_RE = re.compile(r"\s+meta\s+\[.*$", re.DOTALL)

# Table.SelectRows(src, each [col] = "value") -- simple equality filter
_SELECT_ROWS_EQ_RE = re.compile(
    r'Table\.SelectRows\s*\([^,]+,\s*each\s+\[(?P<col>[^\]]+)\]\s*=\s*"(?P<val>[^"]+)"',
    re.IGNORECASE,
)
# Table.RenameColumns(src, {{"OldName", "NewName"}, ...})
_RENAME_PAIR_RE = re.compile(r'\{"([^"]+)",\s*"([^"]+)"\}')

# Table.Group(src, {"A"}, {{"B", each List.Count(List.Distinct([C])), Int64.Type}})
_GROUP_RE = re.compile(
    r"Table\.Group\s*\(\s*(?P<src>[A-Za-z_][A-Za-z0-9_]*)\s*,\s*"
    r"\{(?P<group_cols>.*?)\}\s*,\s*\{(?P<aggs>.*?)\}\s*\)",
    re.IGNORECASE | re.DOTALL,
)
_GROUP_AGG_RE = re.compile(
    r'\{"([^"]+)",\s*each\s*(.+?),\s*(?:type\s+)?[A-Za-z0-9_.]+\}',
    re.IGNORECASE | re.DOTALL,
)


@dataclass
class MBinding:
    """Physical object a model table is bound to."""

    database: str | None = None
    schema: str | None = None
    object_name: str | None = None
    object_kind: str | None = None  # Table | View
    is_snowflake: bool = False
    # non-Snowflake connector detected in the M source (sqlserver | postgres)
    foreign_source: str | None = None
    native_query: str | None = None
    transform_steps: list[str] = field(default_factory=list)
    unresolved_params: list[str] = field(default_factory=list)
    # Phase-5: extracted WHERE predicates from Table.SelectRows
    where_predicates: list[str] = field(default_factory=list)  # SQL fragments
    # Phase-5: column renames from Table.RenameColumns {old → new}
    column_renames: dict[str, str] = field(default_factory=dict)
    # Table.Group metadata for best-effort materialization plans
    group_source: str | None = None
    group_by_columns: list[str] = field(default_factory=list)
    group_aggregations: list[tuple[str, str, str]] = field(default_factory=list)

    @property
    def is_resolved(self) -> bool:
        return bool(
            self.is_snowflake
            and self.schema
            and self.object_name
            and not self.unresolved_params
        ) or bool(self.native_query)

    @property
    def is_foreign_resolved(self) -> bool:
        """Foreign source with full coordinates — migratable to Snowflake."""
        return bool(
            self.foreign_source
            and self.schema
            and self.object_name
            and not self.unresolved_params
        )


def resolve_parameter(value: str, expressions: dict[str, str]) -> str | None:
    """Shared expressions look like: `"LITERAL" meta [IsParameterQuery=true...]`."""
    raw = expressions.get(value)
    if raw is None:
        return None
    stripped = _PARAM_STRIP_RE.sub("", raw).strip()
    if stripped.startswith('"') and stripped.endswith('"'):
        return stripped[1:-1]
    return stripped or None


def parse_m_binding(m_source: str, expressions: dict[str, str] | None = None) -> MBinding:
    expressions = expressions or {}
    b = MBinding(is_snowflake=bool(_SNOWFLAKE_SRC_RE.search(m_source)))
    if not b.is_snowflake:
        for kind, pattern in _FOREIGN_SRC_RES:
            if pattern.search(m_source):
                b.foreign_source = kind
                break
        if b.foreign_source:
            # Connector.Database("server","db") — second literal is the database
            m_db = re.search(
                r'(?:Sql|PostgreSQL|MySQL|Oracle)\.Databases?\s*\(\s*"[^"]*"\s*,\s*"(?P<db>[^"]+)"',
                m_source,
                re.IGNORECASE,
            )
            if m_db:
                b.database = m_db.group("db")

    if _NATIVE_RE.search(m_source):
        # capture the first string literal argument as the SQL text
        m = re.search(r'Value\.NativeQuery\s*\([^,]+,\s*"((?:[^"\\]|\\.)*)"', m_source, re.DOTALL)
        if m:
            b.native_query = m.group(1).replace('\\"', '"').replace("#(lf)", "\n")
        return b

    # foreign navigation: {[Schema="dbo", Item="FactSales"]}[Data]
    for nav in _SCHEMA_ITEM_RE.finditer(m_source):
        for group_name, attr in (("schema", "schema"), ("item", "object_name")):
            raw = nav.group(group_name)
            if raw.startswith('"'):
                setattr(b, attr, raw.strip('"'))
            else:
                resolved = resolve_parameter(raw, expressions)
                if resolved is None:
                    b.unresolved_params.append(raw)
                else:
                    setattr(b, attr, resolved)
        if b.object_name:
            b.object_kind = "Table"

    for step in _STEP_RE.finditer(m_source):
        raw_name, kind = step.group("name"), step.group("kind")
        if raw_name.startswith('"'):
            name = raw_name.strip('"')
        else:
            resolved = resolve_parameter(raw_name, expressions)
            if resolved is None:
                b.unresolved_params.append(raw_name)
                continue
            name = resolved
        match (kind or "").lower():
            case "database":
                b.database = name
            case "schema":
                b.schema = name
            case "table" | "view":
                b.object_name = name
                b.object_kind = kind
            case _:
                # legacy pattern without Kind: DB{[Name=...]}[Data] order is db->schema->object
                if b.database is None:
                    b.database = name
                elif b.schema is None:
                    b.schema = name
                else:
                    b.object_name = name

    for t in _TRANSFORM_RE.finditer(m_source):
        b.transform_steps.append(t.group(1))

    # Phase-5: extract simple SelectRows predicates → WHERE clauses
    for m_eq in _SELECT_ROWS_EQ_RE.finditer(m_source):
        col = m_eq.group("col").strip()
        val = m_eq.group("val").replace("'", "''")
        # Use safe identifier pattern (letters, digits, spaces, underscore)
        if re.match(r"^[A-Za-z0-9_$. -]+$", col) and '"' not in col:
            b.where_predicates.append(f'"{col}" = \'{val}\'')

    # Phase-5: extract RenameColumns mappings
    for rename_block_m in re.finditer(r"Table\.RenameColumns\s*\([^,]+,\s*\{(.+?)\}\s*\)", m_source, re.DOTALL):
        block = rename_block_m.group(1)
        for old, new in _RENAME_PAIR_RE.findall(block):
            b.column_renames[old] = new

    # Best-effort extraction of common Table.Group materialization shapes.
    group_match = _GROUP_RE.search(m_source)
    if group_match:
        b.group_source = group_match.group("src").strip()
        b.group_by_columns = [c for c in re.findall(r'"([^"]+)"', group_match.group("group_cols"))]
        for out_name, expr in _GROUP_AGG_RE.findall(group_match.group("aggs")):
            expr_norm = " ".join(expr.split())
            src_col_m = re.search(r"\[([A-Za-z0-9_$. -]+)\]", expr_norm)
            src_col = src_col_m.group(1).strip() if src_col_m else out_name
            agg_kind = "passthrough"
            if re.search(r"List\.Count\s*\(\s*List\.Distinct\s*\(", expr_norm, re.IGNORECASE):
                agg_kind = "count_distinct"
            elif re.search(r"List\.First\s*\(\s*List\.Sort\s*\(\s*List\.Distinct\s*\(", expr_norm, re.IGNORECASE):
                agg_kind = "min"
            elif re.search(r"List\.Count\s*\(", expr_norm, re.IGNORECASE):
                agg_kind = "count"
            b.group_aggregations.append((out_name, agg_kind, src_col))

    return b
