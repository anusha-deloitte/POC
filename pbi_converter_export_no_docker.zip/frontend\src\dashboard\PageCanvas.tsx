import { useLayoutEffect, useRef, useState } from 'react'
import type {
  FilterClause,
  InteractionState,
  PageSpec,
  VisualResult,
  VisualSpec,
} from './types'
import { isVisualActive, toggleSelection, type VisualInteractionState } from './interactions'
import { DecompositionTree } from './visuals/DecompositionTree'
import { BulletChart } from './visuals/BulletChart'
import { CardVisual } from './visuals/CardVisual'
import { ChartVisual } from './visuals/ChartVisual'
import { ComboVisual } from './visuals/ComboVisual'
import { GaugeVisual } from './visuals/GaugeVisual'
import { HeatmapMatrix } from './visuals/HeatmapMatrix'
import { MapVisual } from './visuals/MapVisual'
import { ScatterVisual } from './visuals/ScatterVisual'
import { SlicerVisual } from './visuals/SlicerVisual'
import { TableVisual } from './visuals/TableVisual'
import { TextboxVisual } from './visuals/TextboxVisual'

const CHART_TYPES = new Set([
  'donutChart',
  'pieChart',
  'barChart',
  'clusteredBarChart',
  'columnChart',
  'clusteredColumnChart',
  'lineChart',
  'areaChart',
  'waterfallChart',
])

function VisualBody({
  spec,
  data,
  slicerState,
  interactionState,
  onSlicerChange,
  onSelect,
}: {
  spec: VisualSpec
  data?: VisualResult
  slicerState: Record<string, (string | number)[]>
  interactionState: InteractionState
  onSlicerChange: (spec: VisualSpec, values: (string | number)[]) => void
  onSelect: (spec: VisualSpec, values: (string | number)[]) => void
}) {
  if (!spec.supported)
    return (
      <div className="flex h-full items-center justify-center p-2 text-center">
        <span className="rounded bg-amber-50 px-2 py-1 text-[10px] text-amber-700">
          Unsupported: {spec.unsupported_reason}
        </span>
      </div>
    )
  if (spec.visual_type === 'textbox') return <TextboxVisual spec={spec} />
  if (spec.visual_type === 'card') return <CardVisual spec={spec} data={data} />
  if (spec.visual_type === 'slicer')
    return (
      <SlicerVisual
        spec={spec}
        data={data}
        selected={slicerState[spec.name] ?? []}
        onChange={(values) => onSlicerChange(spec, values)}
      />
    )
  if (spec.visual_type === 'pivotTable' || spec.visual_type === 'tableEx')
    return <TableVisual spec={spec} data={data} onSelect={(values) => onSelect(spec, values)} />
  if (spec.visual_type === 'scatterChart')
    return <ScatterVisual spec={spec} data={data} onSelect={(values) => onSelect(spec, values)} />
  if (spec.visual_type === 'lineClusteredColumnComboChart')
    return <ComboVisual spec={spec} data={data} />
  if (spec.visual_type === 'gauge') return <GaugeVisual spec={spec} data={data} />
  if (spec.visual_type === 'bulletChart') return <BulletChart spec={spec} data={data} />
  if (spec.visual_type === 'heatmapMatrix')
    return <HeatmapMatrix spec={spec} data={data} onSelect={(values) => onSelect(spec, values)} />
  if (spec.visual_type === 'filledMap')
    return (
      <MapVisual
        spec={spec}
        data={data}
        selected={interactionState.selections[spec.name] ?? []}
        onSelect={(values) => onSelect(spec, values)}
      />
    )
  if (spec.visual_type === 'decompositionTreeVisual')
    return <DecompositionTree spec={spec} data={data} onSelect={(values) => onSelect(spec, values)} />
  if (CHART_TYPES.has(spec.visual_type))
    return <ChartVisual spec={spec} data={data} onSelect={(values) => onSelect(spec, values)} />
  return <div className="p-2 text-xs text-surface-400">{spec.visual_type}</div>
}

export function PageCanvas({
  page,
  results,
  slicerState,
  onSlicerChange,
  interactionState,
  onInteractionChange,
  visualInteractions,
  annotations = true,
}: {
  page: PageSpec
  results: Record<string, VisualResult>
  slicerState: Record<string, (string | number)[]>
  onSlicerChange: (spec: VisualSpec, values: (string | number)[]) => void
  interactionState?: InteractionState
  onInteractionChange?: (next: InteractionState) => void
  visualInteractions?: Record<string, VisualInteractionState>
  /** false during pixel-true capture: hides Studio-only badges (≈ / fallback) */
  annotations?: boolean
}) {
  const outer = useRef<HTMLDivElement>(null)
  const [scale, setScale] = useState(1)
  const currentInteraction = interactionState ?? {
    selections: {},
    hoveredVisual: null,
    activeBookmark: null,
  }

  const emitSelect = (spec: VisualSpec, values: (string | number)[]) => {
    if (!onInteractionChange) return
    onInteractionChange(toggleSelection(currentInteraction, spec, values))
  }

  useLayoutEffect(() => {
    const el = outer.current
    if (!el) return
    const ro = new ResizeObserver(() => {
      setScale(Math.min(el.clientWidth / page.width, 1.25))
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [page.width])

  return (
    <div ref={outer} className="w-full overflow-hidden">
      <div
        data-testid="page-canvas"
        className="relative origin-top-left bg-[#0d1a3a]/[.03]"
        style={{
          width: page.width,
          height: page.height,
          transform: `scale(${scale})`,
          marginBottom: page.height * (scale - 1),
        }}
      >
        {[...page.visuals]
          .sort((a, b) => a.z - b.z)
          .map((v) => {
            const view = visualInteractions?.[v.name]
            const isActive = view?.active ?? isVisualActive(v, currentInteraction)
            const isFiltered = view?.filtered ?? false
            const isHighlighted = view?.highlighted ?? false
            // container styling declared in PBIR wins over the default chrome
            const bg = v.options?.container_background as
              | { color?: string; transparency?: number }
              | undefined
            const border = v.options?.container_border as
              | { show?: boolean; color?: string; radius?: number }
              | undefined
            const containerStyle: React.CSSProperties = {
              left: v.x,
              top: v.y,
              width: v.width,
              height: v.height,
              zIndex: v.z,
            }
            if (bg?.color) {
              const alpha = 1 - (bg.transparency ?? 0) / 100
              containerStyle.backgroundColor =
                alpha >= 1
                  ? bg.color
                  : `${bg.color}${Math.round(alpha * 255)
                      .toString(16)
                      .padStart(2, '0')}`
            }
            if (border?.color) containerStyle.borderColor = border.color
            if (border?.radius !== undefined) containerStyle.borderRadius = border.radius
            if (border?.show === false) containerStyle.border = 'none'
            return (
            <div
              key={v.name}
              data-testid={`visual-${v.name}`}
              className={
                v.visual_type === 'textbox'
                  ? 'absolute'
                  : `absolute rounded-md border bg-white shadow-sm transition ${
                      isActive
                        ? 'border-brand ring-2 ring-brand/30'
                        : isFiltered
                          ? 'border-sky-400 ring-1 ring-sky-300/70'
                          : isHighlighted
                            ? 'border-brand-blue/50 ring-1 ring-brand-blue/20'
                            : 'border-surface-300'
                    }`
              }
              style={containerStyle}
            >
              {v.title && v.visual_type !== 'card' && v.visual_type !== 'slicer' && (
                <div className="flex items-center gap-1 truncate px-2 pt-1 text-[11px] font-semibold text-surface-600">
                  <span className="truncate">{v.title}</span>
                  {annotations && v.substituted_as && (
                    <span
                      title={`Rendered as ${v.substituted_as} (nearest equivalent)`}
                      className="shrink-0 rounded bg-brand-blue/10 px-1 text-[8px] font-normal text-brand-blue"
                    >
                      ≈ {v.substituted_as}
                    </span>
                  )}
                  {annotations && results[v.name]?.execution_path === 'compatibility' && (
                    <span
                      title={results[v.name]?.fallback_reason ?? 'compatibility fallback'}
                      className="shrink-0 rounded bg-amber-50 px-1 text-[8px] font-normal text-amber-700"
                    >
                      fallback
                    </span>
                  )}
                </div>
              )}
              <div
                style={{
                  height:
                    v.title && v.visual_type !== 'card' && v.visual_type !== 'slicer'
                      ? 'calc(100% - 20px)'
                      : '100%',
                }}
              >
                <VisualBody
                  spec={v}
                  data={results[v.name]}
                  slicerState={slicerState}
                  interactionState={currentInteraction}
                  onSlicerChange={onSlicerChange}
                  onSelect={emitSelect}
                />
              </div>
            </div>
            )
          })}
      </div>
    </div>
  )
}

export function slicersToFilters(
  page: PageSpec,
  slicerState: Record<string, (string | number)[]>,
): FilterClause[] {
  const filters: FilterClause[] = []
  for (const v of page.visuals) {
    const sel = slicerState[v.name]
    if (!sel || !sel.length) continue
    if (v.visual_type === 'slicer' && v.slicer_target) {
      filters.push({ table: v.slicer_target.table, column: v.slicer_target.column, values: sel })
    } else if (v.visual_type === 'filledMap' && v.dim_keys.length) {
      // map state click cross-filters on its category dimension (PBI parity)
      const [table, column] = v.dim_keys[0].split('.')
      filters.push({ table, column, values: sel })
    }
  }
  return filters
}
