"""Semantic runtime: QuerySpec -> Snowflake SQL.

Reproduces Power BI's evaluation shape for tier-0/1 measures:

1. Compile each measure to leaves (aggregate expression + Context).
2. Group leaves by Context; each group is one subquery: fact table joined
   along active many->one relationship paths, WHERE from visual/slicer
   filters plus CALCULATE predicates (minus cleared tables), GROUP BY the
   visual's dimension keys.
3. Time shifts join the date dimension twice:
     fact -> d_data (relationship join: rows feeding the aggregate)
     d_cur (rows carrying the visual's date grain/filters), connected by
       sply:    d_data.date = DATEADD(year, -1, d_cur.date)
       ytd:     YEAR(d_data.date) = YEAR(d_cur.date) AND d_data.date <= d_cur.date
       rolling: d_data.date >  DATEADD(unit, -n, d_cur.date) AND <= d_cur.date
   With no date column in the grain, ytd/rolling anchor to a scalar
   (SELECT MAX(date) ... under the context's date filters) instead.
4. Subqueries FULL OUTER JOIN on grain keys; combiners compute final values.

Filters on tables unreachable from a leaf's fact are dropped for that leaf
(single-direction cross-filter semantics) and surfaced as warnings.
"""

from __future__ import annotations

import re
from collections import deque
from dataclasses import dataclass, field
from heapq import heappop, heappush

from pydantic import BaseModel, Field

from app.binding.resolver import BindingMap
from app.dax.compiler import (
    CompiledMeasure,
    Context,
    DaxUnsupported,
    MeasureCompiler,
    qcol,
)
from app.ir.model import SemanticModel

_D_CUR = "__d_cur"
_D_DATA = "__d_data"


class DimensionRef(BaseModel):
    table: str
    column: str
    alias: str | None = None

    @property
    def key(self) -> str:
        return self.alias or f"{self.table}.{self.column}"


class FilterClause(BaseModel):
    table: str
    column: str
    values: list[str | int | float | bool | None] = Field(default_factory=list)
    op: str = "in"  # in | not_in | eq | gte | lte | gt | lt


class MeasureRefSpec(BaseModel):
    name: str | None = None  # model measure
    table: str | None = None  # or implicit column aggregate
    column: str | None = None
    aggregate: str | None = None
    alias: str | None = None

    @property
    def key(self) -> str:
        return self.alias or self.name or f"{self.aggregate or 'agg'}({self.table}.{self.column})"


class QuerySpec(BaseModel):
    dimensions: list[DimensionRef] = Field(default_factory=list)
    measures: list[MeasureRefSpec] = Field(default_factory=list)
    filters: list[FilterClause] = Field(default_factory=list)
    sort: list[dict] = Field(default_factory=list)
    limit: int | None = None


class QueryPlanError(Exception):
    pass


@dataclass
class _Join:
    from_table: str
    from_column: str
    to_table: str
    to_column: str
    relationship_name: str = ""
    # true when this edge is the synthetic reverse traversal for bothDirections rels
    reverse_edge: bool = False
    # true when relationship cardinality is many-to-many
    many_to_many: bool = False


@dataclass
class _Group:
    ctx: Context
    fact: str
    alias: str = ""
    leaves: dict[str, str] = field(default_factory=dict)  # global alias -> aggregate sql
    reachable: list[DimensionRef] = field(default_factory=list)


def _lit(v) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return repr(v)
    return "'" + str(v).replace("'", "''") + "'"


def _overlay_warning(code: str, message: str) -> str:
    return f"[OVERLAY:{code}] {message}"


class SemanticEngine:
    def __init__(
        self,
        model: SemanticModel,
        binding_map: BindingMap,
        tier2_sql: dict[str, str] | None = None,
    ):
        self.model = model
        self.bindings = binding_map
        self.compiler = MeasureCompiler(model)
        # execution-validated LLM SQL for measures outside the tier-1 surface
        self.tier2_sql = tier2_sql or {}
        self._edges: dict[str, list[_Join]] = {}
        self._inactive: dict[tuple[str, str], _Join] = {}
        for r in model.relationships:
            j = _Join(
                r.from_table,
                r.from_column,
                r.to_table,
                r.to_column,
                relationship_name=r.name,
                many_to_many=(r.from_cardinality == "many" and r.to_cardinality == "many"),
            )
            if not r.is_active:
                self._inactive[
                    (f"{r.from_table}.{r.from_column}", f"{r.to_table}.{r.to_column}")
                ] = j
                continue
            self._edges.setdefault(r.from_table, []).append(j)
            if r.cross_filtering_behavior == "bothDirections":
                # reverse traversal: dimension filters can flow back to the fact
                self._edges.setdefault(r.to_table, []).append(
                    _Join(
                        r.to_table,
                        r.to_column,
                        r.from_table,
                        r.from_column,
                        relationship_name=r.name,
                        reverse_edge=True,
                        many_to_many=(
                            r.from_cardinality == "many" and r.to_cardinality == "many"
                        ),
                    )
                )

    # ---------------- planning ----------------

    def expanded_table(self, table: str) -> set[str]:
        """DAX expanded table: the table plus every table reachable via active
        many->one relationships. REMOVEFILTERS/ALL over a table clears filters
        on the whole expanded table, not just the base table."""
        seen = {table}
        frontier = [table]
        while frontier:
            cur = frontier.pop()
            for j in self._edges.get(cur, []):
                if not j.reverse_edge and j.to_table not in seen:
                    seen.add(j.to_table)
                    frontier.append(j.to_table)
        return seen

    def _effective_clears(self, ctx) -> set[str]:
        out: set[str] = set()
        for t in ctx.clears:
            if t == "*":
                return {"*"}
            out |= self.expanded_table(t)
        return out

    def join_path(
        self,
        fact: str,
        target: str,
        use_relationships: tuple[tuple[str, str], ...] = (),
    ) -> list[_Join] | None:
        if fact == target:
            return []
        edges = self._edges
        if use_relationships:
            # activate the named inactive relationships for this context only
            edges = {k: list(v) for k, v in self._edges.items()}
            for pair in use_relationships:
                j = self._inactive.get(pair) or self._inactive.get((pair[1], pair[0]))
                if j is not None:
                    edges.setdefault(j.from_table, []).append(j)
        # Phase-7: weighted traversal that prefers non-reverse edges first.
        # This preserves stable one-direction semantics and only uses reverse
        # propagation when necessary.
        pq: list[tuple[int, int, str, list[_Join]]] = []
        best_cost: dict[str, tuple[int, int]] = {fact: (0, 0)}
        heappush(pq, (0, 0, fact, []))
        while pq:
            reverse_cost, hops, node, path = heappop(pq)
            if node == target:
                return path
            for edge in edges.get(node, []):
                new_reverse = reverse_cost + (1 if edge.reverse_edge else 0)
                new_hops = hops + 1
                cur = best_cost.get(edge.to_table)
                if cur is not None and cur <= (new_reverse, new_hops):
                    continue
                best_cost[edge.to_table] = (new_reverse, new_hops)
                heappush(pq, (new_reverse, new_hops, edge.to_table, path + [edge]))
        return None

    def _physical(self, table: str) -> str:
        b = self.bindings.get(table)
        if b is None or b.status != "resolved":
            raise QueryPlanError(f"table {table} has no physical binding")
        if b.native_query:
            return f"({b.native_query})"
        qname = b.qualified_name
        # Phase-5: if the binding has a WHERE clause (from Table.SelectRows),
        # wrap as a subquery so the filter is always applied
        if b.where_clause:
            return f'(SELECT * FROM {qname} WHERE {b.where_clause})'
        return qname

    def _pick_fact(self, leaf_tables: set[str], dims: list[DimensionRef]) -> str:
        # prefer the leaf table that reaches the most dims (PBI: unreachable dims repeat)
        best, best_n = None, -1
        for t in sorted(leaf_tables):
            n = sum(1 for d in dims if self.join_path(t, d.table) is not None)
            if n > best_n:
                best, best_n = t, n
        if best is None:
            raise QueryPlanError(f"no usable leaf table among {sorted(leaf_tables)}")
        return best

    def _sort_column(self, table: str, column: str) -> str | None:
        t = self.model.table(table)
        col = t.column(column) if t else None
        return col.sort_by_column if col else None

    # ---------------- public ----------------

    def build_sql(self, spec: QuerySpec) -> tuple[str, list[str]]:
        warnings: list[str] = []
        if not spec.measures and not spec.dimensions:
            raise QueryPlanError("empty query")

        compiled: dict[str, CompiledMeasure] = {}
        for m in spec.measures:
            try:
                compiled[m.key] = (
                    self.compiler.compile_measure(m.name)
                    if m.name
                    else self.compiler.compile_implicit(m.table, m.column, m.aggregate)
                )
            except DaxUnsupported as e:
                if m.name and m.name in self.tier2_sql:
                    # zero-leaf scalar-subquery measure; whole-model value
                    compiled[m.key] = CompiledMeasure(
                        name=m.name,
                        expr=f"(\n{self.tier2_sql[m.name]}\n)",
                        tier=2,
                    )
                    warnings.append(
                        _overlay_warning(
                            "TIER2_MEASURE",
                            f"measure '{m.name}' is AI-translated (tier-2): whole-model "
                            "value, does not respond to slicers/filters",
                        )
                    )
                else:
                    raise QueryPlanError(f"measure {m.key}: {e}") from e

        if not compiled:
            return self._dimension_only_sql(spec, warnings), warnings

        # windowed rolling averages evaluate via their own date-grain CTE
        windowed = {k: cm for k, cm in compiled.items() if cm.window_avg is not None}
        compiled = {k: cm for k, cm in compiled.items() if cm.window_avg is None}

        if windowed and not compiled:
            raise QueryPlanError(
                "windowed measure needs a companion measure in the same visual"
            )

        # all remaining measures tier-2 (zero leaves): plain scalar select
        if compiled and all(not cm.leaves for cm in compiled.values()) and not windowed:
            selects = ", ".join(f'{cm.expr} AS "{k}"' for k, cm in compiled.items())
            return f"SELECT {selects}", warnings

        groups: dict[tuple, _Group] = {}
        leaf_to_group: dict[tuple[str, str], tuple[str, str]] = {}
        for mkey, cm in compiled.items():
            for local_alias, leaf in cm.leaves.items():
                fact = self._pick_fact(leaf.tables, spec.dimensions)
                gkey = (leaf.ctx, fact)
                grp = groups.setdefault(gkey, _Group(ctx=leaf.ctx, fact=fact))
                galias = None
                for existing_alias, existing_sql in grp.leaves.items():
                    if existing_sql == leaf.sql:
                        galias = existing_alias
                        break
                if galias is None:
                    galias = f"v{len(grp.leaves)}"
                    grp.leaves[galias] = leaf.sql
                leaf_to_group[(mkey, local_alias)] = (gkey, galias)

        for i, grp in enumerate(groups.values()):
            grp.alias = f"q{i}"
            # dims on a cleared expanded table leave this leaf's grain entirely:
            # the value is computed without them and repeated via the frame
            clears = self._effective_clears(grp.ctx)
            grp.reachable = [
                d
                for d in spec.dimensions
                if "*" not in clears
                and d.table not in clears
                and self.join_path(grp.fact, d.table, grp.ctx.use_relationships) is not None
            ]

        # a frame is needed when any group cannot reach every dim (PBI repeat semantics)
        needs_frame = any(
            len(grp.reachable) < len(spec.dimensions) for grp in groups.values()
        )
        sub_sql = {grp.alias: self._group_sql(grp, spec, warnings) for grp in groups.values()}
        frame_sql = self._frame_sql(spec, warnings) if needs_frame else None
        window_ctes = {
            k: self._window_avg_sql(cm, spec, warnings) for k, cm in windowed.items()
        }
        sql = self._combine(
            spec, compiled, groups, leaf_to_group, sub_sql, frame_sql, window_ctes
        )
        return sql, warnings

    def _window_avg_sql(self, cm: CompiledMeasure, spec: QuerySpec, warnings) -> tuple[str, str]:
        """(join_key_sql, cte_body) evaluating AVG of the inner measure over a
        trailing window at date grain. Grain must include a column of the date
        table (the standard trend-visual shape)."""
        wa = cm.window_avg
        date_dims = [d for d in spec.dimensions if d.table == wa.date_table]
        if not date_dims:
            raise QueryPlanError(
                f"windowed measure '{cm.name}' needs a {wa.date_table} column in the grain"
            )
        grain_dim = date_dims[0]
        inner_spec = QuerySpec(
            dimensions=[DimensionRef(table=wa.date_table, column=wa.date_column, alias="__d")],
            measures=[MeasureRefSpec(name=wa.measure, alias="__v")],
            filters=[f for f in spec.filters if f.table != wa.date_table],
        )
        inner_sql, inner_warnings = self.build_sql(inner_spec)
        warnings.extend(inner_warnings)
        # inner CTE names (q0, q1, __frame) collide with the outer query's scope
        inner_sql = inner_sql.replace('"q', '"wiq').replace('"__frame"', '"__wiframe"')
        # map window date grain back to the visual's grain column
        # (identifiers validated by qcol/safe_ident)
        label = (
            f'SELECT {qcol(wa.date_table, grain_dim.column)} AS "k", '  # noqa: S608
            f'{qcol(wa.date_table, wa.date_column)} AS "d" '
            f'FROM {self._physical(wa.date_table)} AS "{wa.date_table}"'
        )
        body = (
            f"SELECT lbl.\"k\", AVG(win.\"__v\") OVER ("
            f"ORDER BY win.\"__d\" ROWS BETWEEN {max(wa.n - 1, 0)} PRECEDING AND CURRENT ROW"
            f') AS "__v"\nFROM (\n{inner_sql}\n) AS win\n'
            f'JOIN (\n{label}\n) AS lbl ON win."__d" = lbl."d"'
        )
        return grain_dim.key, body

    # ---------------- pieces ----------------

    def _dimension_only_sql(self, spec: QuerySpec, warnings: list[str]) -> str:
        d = spec.dimensions[0]
        parts = []
        for f in spec.filters:
            if f.table != d.table:
                warnings.append(
                    _overlay_warning(
                        "UNREACHABLE_FILTER",
                        f"filter on {f.table} ignored for slicer domain {d.table}",
                    )
                )
                continue
            parts.append(self._filter_sql(f, d.table))
        sort_col = self._sort_column(d.table, d.column)
        select = f'{qcol(d.table, d.column)} AS "{d.key}"'
        order = f'"{d.key}"'
        if sort_col:
            select += f', MIN({qcol(d.table, sort_col)}) AS "__sort"'
            sql = f'SELECT {select}\nFROM {self._physical(d.table)} AS "{d.table}"'
            if parts:
                sql += "\nWHERE " + " AND ".join(parts)
            sql += f'\nGROUP BY {qcol(d.table, d.column)}\nORDER BY "__sort"'
        else:
            sql = f'SELECT DISTINCT {select}\nFROM {self._physical(d.table)} AS "{d.table}"'
            if parts:
                sql += "\nWHERE " + " AND ".join(parts)
            sql += f"\nORDER BY {order}"
        if spec.limit:
            sql += f"\nLIMIT {int(spec.limit)}"
        return sql

    def _frame_sql(self, spec: QuerySpec, warnings: list[str]) -> str:
        """Cell-grid CTE body: cross-join of per-table DISTINCT axes."""
        by_table: dict[str, list[DimensionRef]] = {}
        for d in spec.dimensions:
            by_table.setdefault(d.table, []).append(d)
        parts: list[str] = []
        outer_cols: list[str] = []
        for i, (table, dims) in enumerate(by_table.items()):
            cols = []
            for d in dims:
                cols.append(f'{qcol(table, d.column)} AS "{d.key}"')
                outer_cols.append(f'"ax{i}"."{d.key}"')
                sc = self._sort_column(table, d.column)
                if sc:
                    cols.append(f'{qcol(table, sc)} AS "__sort_{d.key}"')
                    outer_cols.append(f'"ax{i}"."__sort_{d.key}"')
            flt = [self._filter_sql(f, table) for f in spec.filters if f.table == table]
            inner = f'SELECT DISTINCT {", ".join(cols)}'
            inner += f'\nFROM {self._physical(table)} AS "{table}"'
            if flt:
                inner += "\nWHERE " + " AND ".join(flt)
            parts.append(f'(\n{inner}\n) AS "ax{i}"')
        body = "SELECT " + ", ".join(outer_cols) + "\nFROM " + "\nCROSS JOIN ".join(parts)
        return body

    def _filter_sql(self, f: FilterClause, alias: str) -> str:
        col = qcol(alias, f.column)
        match f.op:
            case "in" | "not_in":
                vals = ", ".join(_lit(v) for v in f.values)
                return f"{col} {'NOT ' if f.op == 'not_in' else ''}IN ({vals})"
            case "eq":
                return f"{col} = {_lit(f.values[0])}"
            case "gte" | "lte" | "gt" | "lt":
                op = {"gte": ">=", "lte": "<=", "gt": ">", "lt": "<"}[f.op]
                return f"{col} {op} {_lit(f.values[0])}"
        raise QueryPlanError(f"unknown filter op {f.op}")

    def _semi_join_sql(self, fact: str, path: list, f: FilterClause) -> str:
        """Filter via IN-subquery along the relationship path (no row duplication).

        Mirrors PBI filter-context semantics: a filter on a dimension restricts
        fact rows without multiplying them, even if the dim's join key repeats.
        """
        first = path[0]
        inner_from = self._physical(first.to_table) + f' AS "{first.to_table}"'
        inner_joins = ""
        for e in path[1:]:
            inner_joins += (
                f'\n  JOIN {self._physical(e.to_table)} AS "{e.to_table}" ON '
                f"{qcol(e.from_table, e.from_column)} = {qcol(e.to_table, e.to_column)}"
            )
        pred = self._filter_sql(f, f.table)
        # identifiers validated by safe_ident in _physical/qcol
        return (
            f"{qcol(fact, first.from_column)} IN "  # noqa: S608
            f"(SELECT {qcol(first.to_table, first.to_column)} FROM {inner_from}"
            f"{inner_joins} WHERE {pred})"
        )

    def _group_sql(self, grp: _Group, spec: QuerySpec, warnings: list[str]) -> str:
        ctx, fact = grp.ctx, grp.fact
        shift = ctx.time_shift
        date_table = shift.date_table if shift else None

        joins: list[str] = []
        joined: dict[str, str] = {fact: fact}

        # columns referenced per table: join keys + grain dims + filters +
        # CALCULATE predicate columns; used to project deduped dim subqueries
        needed: dict[str, set[str]] = {}
        for d in grp.reachable:
            needed.setdefault(d.table, set()).add(d.column)
            # sortByColumn is MIN-aggregated later; the deduped subquery must project it
            sc = self._sort_column(d.table, d.column)
            if sc:
                needed[d.table].add(sc)
        for f in spec.filters:
            needed.setdefault(f.table, set()).add(f.column)
        for p in ctx.filters:
            for col in re.findall(rf'"{re.escape(p.table)}"\."([A-Za-z0-9_ ]+)"', p.sql):
                needed.setdefault(p.table, set()).add(col)

        def _dim_source(table: str, join_col: str, next_out_col: str | None) -> str:
            """Dim joined as a DISTINCT projection — one row per key set, so a
            non-unique join key on the one-side cannot fan out fact rows
            (mirrors PBI's unique-one-side relationship semantics)."""
            cols = {join_col} | needed.get(table, set())
            if next_out_col:
                cols.add(next_out_col)
            proj = ", ".join(qcol(table, c) for c in sorted(cols))
            # identifiers validated by safe_ident in _physical/qcol
            return (
                f'(SELECT DISTINCT {proj} FROM {self._physical(table)} AS "{table}")'  # noqa: S608
            )

        def ensure(table: str) -> str | None:
            """Join `table` reachable from fact; date table maps to d_cur under shift."""
            if shift and table == date_table:
                return _D_CUR if _D_CUR in joined.values() else None
            if table in joined:
                return joined[table]
            path = self.join_path(fact, table, ctx.use_relationships)
            if path is None:
                return None
            if any(e.many_to_many for e in path):
                warnings.append(
                    _overlay_warning(
                        "M2M_PATH",
                        f"path {fact}->{table} crosses many-to-many relationship; "
                        "verify totals for potential fanout",
                    )
                )
            hop = fact
            for i, e in enumerate(path):
                if e.to_table not in joined:
                    nxt = path[i + 1].from_column if i + 1 < len(path) else None
                    joins.append(
                        f'JOIN {_dim_source(e.to_table, e.to_column, nxt)} AS "{e.to_table}" ON '
                        f"{qcol(joined[hop], e.from_column)} = {qcol(e.to_table, e.to_column)}"
                    )
                    joined[e.to_table] = e.to_table
                hop = e.to_table
            return joined[table]

        date_in_grain = any(shift and d.table == date_table for d in spec.dimensions)
        date_filters = [f for f in spec.filters if shift and f.table == date_table]
        anchor_sql = None

        if shift:
            path = self.join_path(fact, date_table, ctx.use_relationships)
            if path is None or len(path) != 1:
                raise QueryPlanError(f"time shift needs single-hop fact->{date_table}")
            edge = path[0]
            joins.append(
                f'JOIN {self._physical(date_table)} AS "{_D_DATA}" ON '
                f"{qcol(fact, edge.from_column)} = {qcol(_D_DATA, edge.to_column)}"
            )
            joined[_D_DATA] = _D_DATA
            dcol_data = qcol(_D_DATA, shift.date_column)

            if shift.kind == "sply" or date_in_grain:
                cond = {
                    "sply": f"{dcol_data} = DATEADD(year, -1, {qcol(_D_CUR, shift.date_column)})",
                    "ytd": (
                        f"YEAR({dcol_data}) = YEAR({qcol(_D_CUR, shift.date_column)}) "
                        f"AND {dcol_data} <= {qcol(_D_CUR, shift.date_column)}"
                    ),
                    "rolling": (
                        f"{dcol_data} > DATEADD({shift.unit}, -{shift.n}, "
                        f"{qcol(_D_CUR, shift.date_column)}) "
                        f"AND {dcol_data} <= {qcol(_D_CUR, shift.date_column)}"
                    ),
                }[shift.kind]
                joins.append(f'JOIN {self._physical(date_table)} AS "{_D_CUR}" ON {cond}')
                joined[_D_CUR] = _D_CUR
            else:
                # ytd/rolling on a card: anchor at MAX(date) under the context's date filters
                anchor_filters = " AND ".join(
                    self._filter_sql(f, "a") for f in date_filters
                )
                # identifiers validated by safe_ident in _physical/qcol
                anchor_sql = (
                    f"(SELECT MAX({qcol('a', shift.date_column)}) "  # noqa: S608
                    f'FROM {self._physical(date_table)} AS "a"'
                    + (f" WHERE {anchor_filters}" if anchor_filters else "")
                    + ")"
                )

        # grain: only dims reachable from this group's fact (others repeat via frame)
        select_dims, group_by = [], []
        for d in grp.reachable:
            alias = ensure(d.table)
            if alias is None:
                raise QueryPlanError(f"dimension {d.table} unreachable from {fact}")
            select_dims.append(f'{qcol(alias, d.column)} AS "{d.key}"')
            group_by.append(qcol(alias, d.column))

        # filters
        where: list[str] = []
        effective_clears = self._effective_clears(ctx)
        for f in spec.filters:
            if f.table in effective_clears or "*" in effective_clears:
                continue
            if shift and f.table == date_table:
                if date_in_grain or shift.kind == "sply":
                    where.append(self._filter_sql(f, _D_CUR))
                # else consumed by the anchor subquery
                continue
            if f.table not in joined:
                # filter-only dim: semi-join (IN subquery) instead of JOIN —
                # immune to fan-out when the dim's join key is non-unique
                path = self.join_path(fact, f.table, ctx.use_relationships)
                if path is not None:
                    if any(e.many_to_many for e in path):
                        warnings.append(
                            _overlay_warning(
                                "M2M_FILTER_PATH",
                                f"filter path {fact}->{f.table} crosses many-to-many relationship",
                            )
                        )
                    where.append(self._semi_join_sql(fact, path, f))
                    continue
            alias = ensure(f.table)
            if alias is None:
                warnings.append(
                    _overlay_warning(
                        "UNREACHABLE_FILTER",
                        f"filter on {f.table} unreachable from {fact}; ignored",
                    )
                )
                continue
            where.append(self._filter_sql(f, alias))

        if anchor_sql:
            dcol_data = qcol(_D_DATA, shift.date_column)
            if shift.kind == "ytd":
                where.append(
                    f"YEAR({dcol_data}) = YEAR({anchor_sql}) AND {dcol_data} <= {anchor_sql}"
                )
            else:
                where.append(
                    f"{dcol_data} > DATEADD({shift.unit}, -{shift.n}, {anchor_sql}) "
                    f"AND {dcol_data} <= {anchor_sql}"
                )

        for p in ctx.filters:
            if shift and p.table == date_table and date_in_grain:
                target = _D_CUR
            else:
                target = ensure(p.table)
            if target is None:
                warnings.append(
                    _overlay_warning(
                        "UNREACHABLE_CALCULATE_FILTER",
                        f"CALCULATE filter on unreachable {p.table}; ignored",
                    )
                )
                continue
            # predicate SQL is emitted against the model-table alias name
            if target == p.table:
                where.append(p.sql)
            else:
                where.append(p.sql.replace(f'"{p.table}"', f'"{target}"'))

        # Phase-5: include sort_by_column as MIN-aggregated hidden columns
        sort_selects: list[str] = []
        for d in grp.reachable:
            sc = self._sort_column(d.table, d.column)
            if sc:
                tbl_alias = ensure(d.table)
                if tbl_alias:
                    sort_selects.append(
                        f'MIN({qcol(tbl_alias, sc)}) AS "__sort_{d.key}"'
                    )
        select_leaves = [f'{expr} AS "{alias}"' for alias, expr in grp.leaves.items()]
        sql = "SELECT " + ", ".join(select_dims + select_leaves + sort_selects)
        sql += f'\nFROM {self._physical(fact)} AS "{fact}"'
        for j in joins:
            sql += f"\n{j}"
        if where:
            sql += "\nWHERE " + " AND ".join(f"({w})" for w in where)
        if group_by:
            sql += "\nGROUP BY " + ", ".join(group_by)
        return sql

    def _combine(
        self, spec, compiled, groups, leaf_to_group, sub_sql, frame_sql, window_ctes=None
    ) -> str:
        window_ctes = window_ctes or {}
        grp_list = list(groups.values())
        aliases = [g.alias for g in grp_list]
        dim_keys = [d.key for d in spec.dimensions]

        window_aliases: dict[str, tuple[str, str]] = {}  # measure key -> (cte alias, join key)
        for i, (mkey, (join_key, _body)) in enumerate(window_ctes.items()):
            window_aliases[mkey] = (f"w{i}", join_key)

        select_measures = []
        for m in spec.measures:
            if m.key in window_aliases:
                walias, _ = window_aliases[m.key]
                select_measures.append(f'"{walias}"."__v" AS "{m.key}"')
                continue
            cm = compiled[m.key]
            expr = cm.expr
            # longest-first so __m10 is replaced before __m1
            for local_alias in sorted(cm.leaves, key=len, reverse=True):
                gkey, galias = leaf_to_group[(m.key, local_alias)]
                sq_alias = groups[gkey].alias
                expr = expr.replace(local_alias, f'"{sq_alias}"."{galias}"')
            select_measures.append(f'{expr} AS "{m.key}"')

        sql = "WITH " + ",\n".join(f'"{a}" AS (\n{sub_sql[a]}\n)' for a in aliases)
        for mkey, (walias, _jk) in window_aliases.items():
            sql += f',\n"{walias}" AS (\n{window_ctes[mkey][1]}\n)'

        # sortByColumn ordering: honored when the frame carries __sort_ cols
        sort_orders: list[str] = []

        # sortByColumn expressions per dim key, usable by explicit sorts too
        sort_expr_by_key: dict[str, str] = {}

        if frame_sql is not None:
            # frame = full cell grid; each group LEFT JOINs on its reachable keys
            sql += f',\n"__frame" AS (\n{frame_sql}\n)'
            select_dims = [f'"__frame"."{k}" AS "{k}"' for k in dim_keys]
            sql += "\nSELECT " + ", ".join(select_dims + select_measures)
            sql += '\nFROM "__frame"'
            for grp in grp_list:
                keys = [d.key for d in grp.reachable]
                if keys:
                    cond = " AND ".join(
                        f'"__frame"."{k}" = "{grp.alias}"."{k}"' for k in keys
                    )
                    sql += f'\nLEFT JOIN "{grp.alias}" ON {cond}'
                else:
                    sql += f'\nCROSS JOIN "{grp.alias}"'
            for _mkey, (walias, jk) in window_aliases.items():
                sql += f'\nLEFT JOIN "{walias}" ON "__frame"."{jk}" = "{walias}"."k"'
            for d in spec.dimensions:
                if self._sort_column(d.table, d.column):
                    sort_expr_by_key[d.key] = f'"__frame"."__sort_{d.key}"'
                    sort_orders.append(sort_expr_by_key[d.key])
        else:
            base = aliases[0]
            if len(aliases) == 1:
                select_dims = [f'"{base}"."{k}" AS "{k}"' for k in dim_keys]
            else:
                select_dims = [
                    "COALESCE(" + ", ".join(f'"{a}"."{k}"' for a in aliases) + f') AS "{k}"'
                    for k in dim_keys
                ]
            sql += "\nSELECT " + ", ".join(select_dims + select_measures)
            sql += f'\nFROM "{base}"'
            for a in aliases[1:]:
                if dim_keys:
                    cond = " AND ".join(
                        f'("{base}"."{k}" = "{a}"."{k}" '
                        f'OR ("{base}"."{k}" IS NULL AND "{a}"."{k}" IS NULL))'
                        for k in dim_keys
                    )
                    sql += f'\nFULL OUTER JOIN "{a}" ON {cond}'
                else:
                    sql += f'\nCROSS JOIN "{a}"'
            for _mkey, (walias, jk) in window_aliases.items():
                sql += f'\nLEFT JOIN "{walias}" ON "{base}"."{jk}" = "{walias}"."k"'
            # Phase-5: sort-by-column for non-frame single-group case
            for d in spec.dimensions:
                sc = self._sort_column(d.table, d.column)
                if sc:
                    sort_expr_by_key[d.key] = f'"{base}"."__sort_{d.key}"'
                    sort_orders.append(sort_expr_by_key[d.key])

        if spec.sort:
            # a dim with sortByColumn sorts by that column even when the sort
            # is explicit (PBI: month names order Jan..Dec, not alphabetically)
            orders = [
                sort_expr_by_key.get(s["key"], f'"{s["key"]}"')
                + (" DESC" if str(s.get("direction", "")).lower().startswith("desc") else " ASC")
                for s in spec.sort
            ]
            sql += "\nORDER BY " + ", ".join(orders)
        elif sort_orders:
            sql += "\nORDER BY " + ", ".join(sort_orders)
        elif dim_keys:
            sql += "\nORDER BY " + ", ".join(f'"{k}"' for k in dim_keys)
        if spec.limit:
            sql += f"\nLIMIT {int(spec.limit)}"
        return sql
