"""PBI-IR: canonical report-layer representation (pages, visuals, filters)."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field

from app.ir.model import SemanticModel


class FilterScope(StrEnum):
    REPORT = "report"
    PAGE = "page"
    VISUAL = "visual"


class InteractionMode(StrEnum):
    FILTER = "filter"
    HIGHLIGHT = "highlight"
    NONE = "none"


class AskDataPolicy(StrEnum):
    COVERED_ONLY = "covered_only"
    STITCH_ALLOWED = "stitch_allowed"
    REFUSE_ON_LOW_CONFIDENCE = "refuse_on_low_confidence"


class Filter(BaseModel):
    name: str | None = None
    scope: FilterScope
    field_table: str | None = None
    field_name: str | None = None
    field_is_measure: bool = False
    filter_type: str = "Categorical"  # Categorical | Advanced | TopN | RelativeDate | Range
    # raw PBIR filter object; interpreted by the query engine
    definition: dict = Field(default_factory=dict)
    is_hidden: bool = False


class VisualField(BaseModel):
    """One projection in a visual query role (e.g. Category, Y, Values)."""

    role: str
    table: str | None = None
    name: str | None = None
    is_measure: bool = False
    is_hierarchy_level: bool = False
    hierarchy: str | None = None
    display_name: str | None = None
    # native/implicit aggregate applied in the visual (Sum, Count, ...)
    aggregate: str | None = None
    query_ref: str | None = None


class VisualPosition(BaseModel):
    x: float = 0
    y: float = 0
    width: float = 0
    height: float = 0
    z: int = 0
    tab_order: int | None = None


class Visual(BaseModel):
    name: str
    visual_type: str
    position: VisualPosition = Field(default_factory=VisualPosition)
    title: str | None = None
    fields: list[VisualField] = Field(default_factory=list)
    filters: list[Filter] = Field(default_factory=list)
    sort: list[dict] = Field(default_factory=list)
    # raw `objects`/formatting payload for the theme compiler
    formatting: dict = Field(default_factory=dict)
    # raw `visualContainerObjects` payload (background/border/title styling)
    container_objects: dict = Field(default_factory=dict)
    is_hidden: bool = False
    # populated when visual_type is unsupported by the renderer
    unsupported_reason: str | None = None


class InteractionEdge(BaseModel):
    from_visual: str
    to_visual: str
    mode: InteractionMode = InteractionMode.FILTER


class InteractionGraph(BaseModel):
    nodes: list[str] = Field(default_factory=list)
    edges: list[InteractionEdge] = Field(default_factory=list)
    sync_groups: dict[str, list[str]] = Field(default_factory=dict)


class Bookmark(BaseModel):
    name: str
    state: dict = Field(default_factory=dict)


class DrillThroughTarget(BaseModel):
    page: str
    fields: list[str] = Field(default_factory=list)


class AskDataCoverage(BaseModel):
    question_class: str
    domain_view: str | None = None
    policy: AskDataPolicy = AskDataPolicy.REFUSE_ON_LOW_CONFIDENCE
    fallback_allowed: bool = False


class Page(BaseModel):
    name: str
    display_name: str
    ordinal: int = 0
    width: float = 1280
    height: float = 720
    visuals: list[Visual] = Field(default_factory=list)
    filters: list[Filter] = Field(default_factory=list)
    is_hidden: bool = False
    background: dict = Field(default_factory=dict)


class Report(BaseModel):
    name: str = "Report"
    pages: list[Page] = Field(default_factory=list)
    filters: list[Filter] = Field(default_factory=list)
    theme: dict = Field(default_factory=dict)
    # report-level measures (from reportExtensions.json) keyed by table
    extension_measures: dict[str, list[str]] = Field(default_factory=dict)
    interaction_graph: InteractionGraph = Field(default_factory=InteractionGraph)
    bookmarks: list[Bookmark] = Field(default_factory=list)
    drill_through: list[DrillThroughTarget] = Field(default_factory=list)
    ask_data_coverage: list[AskDataCoverage] = Field(default_factory=list)

    def page(self, name: str) -> Page | None:
        return next((p for p in self.pages if p.name == name), None)


class ReportBundle(BaseModel):
    """Complete parsed .pbip: semantic model + report + provenance."""

    source_path: str
    model: SemanticModel
    report: Report
    warnings: list[str] = Field(default_factory=list)
