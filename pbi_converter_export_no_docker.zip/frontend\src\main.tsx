import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { createHashRouter, Navigate, RouterProvider } from 'react-router-dom'
import App from './App'
import { AppShell } from './AppShell'
import { AuthGate } from './AuthGate'
import { DashboardApp } from './dashboard/DashboardApp'
import './index.css'
import { Jobs } from './pages/Jobs'
import { Landing } from './pages/Landing'
import { Login } from './pages/Login'
import { ReimagineStudio } from './pages/ReimagineStudio'
import { useParams } from 'react-router-dom'

const queryClient = new QueryClient()

function StandaloneDashboard() {
  const { conversionId, connectionId } = useParams()
  if (!conversionId || !connectionId) return <Navigate to="/app/jobs" replace />
  return <DashboardApp conversionId={conversionId} connectionId={connectionId} />
}

// hash router keeps deep links working without server-side rewrites
const router = createHashRouter([
  { path: '/', element: <Landing /> },
  { path: '/login', element: <Login /> },
  {
    element: <AuthGate />,
    children: [
      {
        path: '/app',
        element: <AppShell />,
        children: [
          { index: true, element: <Navigate to="/app/jobs" replace /> },
          { path: 'jobs', element: <Jobs /> },
          { path: 'convert', element: <App /> },
        ],
      },
      { path: '/dashboard/:conversionId/:connectionId', element: <StandaloneDashboard /> },
      { path: '/reimagine/:conversionId/:connectionId?', element: <ReimagineStudio /> },
    ],
  },
  { path: '*', element: <Navigate to="/" replace /> },
])

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  </StrictMode>,
)
