# PBI Converter

Agentic asset that converts Power BI reports (`.pbip` — PBIR + TMDL formats) into React
dashboards backed by live Snowflake data, then validates conversion accuracy against
golden results and iteratively repairs failures.

## Architecture

```
.pbip upload ──> S1 Ingest ──> S2 PBI-IR ──> S3 Snowflake binding ──> S4 DAX compiler (tiered)
                                                                            │
Studio wizard <── S8 Agent loop <── S7 Accuracy harness <── S6 Renderer <── S5 Query engine
```

- **PBI-IR** ([backend/app/ir](backend/app/ir)) — canonical Pydantic models; every parser emits it, every compiler consumes it.
- **TMDL parser** ([backend/app/parsers/tmdl.py](backend/app/parsers/tmdl.py)) — pure-Python semantic model parser (tables, measures, relationships, roles, M partitions).
- **PBIR parser** ([backend/app/parsers/pbir.py](backend/app/parsers/pbir.py)) — report layer: pages, visuals, filters, projections, sort, theme.
- **Connection profiles** ([backend/app/services/connections.py](backend/app/services/connections.py)) — Snowflake multi-auth (key-pair/JWT, password, OAuth client-credentials, PAT); secrets Fernet-encrypted at rest; one profile feeds both the agent plane (Snowflake MCP server) and serving plane (native connector).
- **Ingest** ([backend/app/services/ingest.py](backend/app/services/ingest.py)) — zip-slip/zip-bomb-safe extraction and bundle storage.

## Quickstart

```bash
# Backend (Python 3.12 + uv)
cd backend
uv venv && uv pip install -e . --group dev
uv run pytest                      # 52 tests, coverage gate >= 80%
uv run uvicorn app.main:app --reload   # http://localhost:8000/docs

# Frontend (Node 20)
cd frontend
npm install
npm test
npm run dev                        # http://localhost:5173

# Full stack
docker compose up --build          # web on :8080, api on :8000
```

## Environment variables

| Variable | Purpose | Default |
|---|---|---|
| `PBIC_STORAGE_DIR` | Uploaded conversions + encrypted connection store | `/tmp/pbic-storage` |
| `PBIC_SECRETS_KEY_FILE` | Fernet key location (chmod 600, generated on first run) | `<storage>/.secrets.key` |
| `PBIC_API_TOKEN` | Bearer token for all API routes (empty = auth off, dev only) | empty |
| `PBIC_OPENAI_API_KEY` | OpenAI key for agent tiers (M2+); compose also accepts `OPENAI_API_KEY` as an alias | empty |
| `PBIC_DATABASE_URL` | Postgres (metadata + LangGraph checkpoints, M2+) | local |
| `PBIC_MAX_UPLOAD_BYTES` | Upload cap | 300 MB |

## Testing

- `backend`: `uv run pytest --cov=app` — parser round-trips against the fixture corpus in [fixtures/contoso_sales](fixtures/contoso_sales), API + security tests (zip-slip, auth, secret encryption).
- `frontend`: `npm run test:coverage` — wizard shell + store.
- CI ([.github/workflows/ci.yml](.github/workflows/ci.yml)): lint (ruff), SAST (bandit), coverage gate ≥80%, and a **license gate** (pip-licenses / license-checker) that fails the build on any non-permissive dependency.

## Fixture corpus

[fixtures/contoso_sales](fixtures/contoso_sales) is a complete hand-authored `.pbip`
(4-table star schema on Snowflake, 6 DAX measures incl. time intelligence, 4 visuals,
page/visual/TopN filters, hierarchy, sortByColumn, inactive + bidirectional relationship).
It is both the regression suite and the demo seed. Add more reports as
`fixtures/<name>/` and they are picked up by tests.

## Feature status

Delivered (all verified against a real 71-measure healthcare payer report on live Snowflake):

- **Parsing** — PBIP/PBIR + TMDL (pure-Python, preview-drift tolerant), M-partition binding
  with parameter resolution, custom theme extraction.
- **DAX compiler** — tiered: implicit aggregates → deterministic Metric Algebra
  (CALCULATE, VAR, time intelligence, iterators, windowed rolling averages via
  `AVG OVER`) → execution-validated OpenAI fallback. 71/71 measures on the hero report.
- **Semantic runtime** — join-path planning, PBI filter propagation, dimension frames for
  multi-fact visuals, SPLY/YTD dual-date joins, `USERELATIONSHIP` + bidirectional
  cross-filter, sortByColumn ordering.
- **Renderer** — spec-driven PageCanvas: cards, slicers, bar/column/line/area/donut/
  waterfall, scatter, dual-axis combo, gauge, US choropleth, drillable treemap
  (decomposition-tree substitute), matrix pivot tables; PBI format strings; report theme
  (dataColors, good/bad semantics); variance conditional formatting.
- **Accuracy** — per-visual compile/execute/sanity/totals checks → Fidelity Scorecard;
  live golden-equivalence pytest suite (`-m live`); agent pipeline with bounded monotonic
  repair and a persisted event log.
- **Modes** — Live (every interaction hits Snowflake) and **Accelerated** (DuckDB extract
  hydrated from Snowflake via Arrow; 5–90× faster interactions, numerically equivalent).
- **Delivery** — standalone full-tab dashboard route; one-click export of a runnable
  Vite + React project (vendored renderer + spec, builds clean).

Backlog: RLS → Snowflake row access policies, Entra External OAuth, OTel tracing,
per-visual typed endpoints, offline demo kit, PBIX adapter.
