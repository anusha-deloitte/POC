"""Source-database → Snowflake migration mover.

Lifts the base tables a PBI report reads from its source database (PostgreSQL
or SQL Server) into the target Snowflake schema: introspects source column
types, creates the tables, streams rows in batches through parameterized
INSERTs, and verifies row counts. After migration the binding map is rewritten
so every table resolves against Snowflake — downstream (SQL emitter, semantic
view, validation, reimagine) never knows the report was born elsewhere.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field

from app.binding.resolver import BindingMap

_IDENT_OK = re.compile(r"^[A-Za-z_][A-Za-z0-9_$ ]*$")
# source-side identifiers come from parsed M text — validate before interpolation
_SRC_IDENT_OK = re.compile(r"^[A-Za-z_][A-Za-z0-9_$. -]*$")


def _src_ident(name: str) -> str:
    if not _SRC_IDENT_OK.match(name) or any(ch in name for ch in '"[];'):
        raise ValueError(f"unsafe source identifier: {name!r}")
    return name

# source type name (lowered, params stripped) -> Snowflake type
_PG_TYPES = {
    "smallint": "NUMBER(5,0)",
    "integer": "NUMBER(10,0)",
    "bigint": "NUMBER(19,0)",
    "numeric": "NUMBER",
    "decimal": "NUMBER",
    "real": "FLOAT",
    "double precision": "FLOAT",
    "money": "NUMBER(19,4)",
    "boolean": "BOOLEAN",
    "character varying": "VARCHAR",
    "varchar": "VARCHAR",
    "character": "VARCHAR",
    "char": "VARCHAR",
    "text": "VARCHAR",
    "uuid": "VARCHAR(36)",
    "date": "DATE",
    "timestamp without time zone": "TIMESTAMP_NTZ",
    "timestamp with time zone": "TIMESTAMP_TZ",
    "time without time zone": "TIME",
    "json": "VARIANT",
    "jsonb": "VARIANT",
}
_MSSQL_TYPES = {
    "tinyint": "NUMBER(3,0)",
    "smallint": "NUMBER(5,0)",
    "int": "NUMBER(10,0)",
    "bigint": "NUMBER(19,0)",
    "numeric": "NUMBER",
    "decimal": "NUMBER",
    "money": "NUMBER(19,4)",
    "smallmoney": "NUMBER(10,4)",
    "float": "FLOAT",
    "real": "FLOAT",
    "bit": "BOOLEAN",
    "varchar": "VARCHAR",
    "nvarchar": "VARCHAR",
    "char": "VARCHAR",
    "nchar": "VARCHAR",
    "text": "VARCHAR",
    "ntext": "VARCHAR",
    "uniqueidentifier": "VARCHAR(36)",
    "date": "DATE",
    "datetime": "TIMESTAMP_NTZ",
    "datetime2": "TIMESTAMP_NTZ",
    "smalldatetime": "TIMESTAMP_NTZ",
    "datetimeoffset": "TIMESTAMP_TZ",
    "time": "TIME",
}


_MYSQL_TYPES = {
    "tinyint": "NUMBER(3,0)",
    "smallint": "NUMBER(5,0)",
    "mediumint": "NUMBER(7,0)",
    "int": "NUMBER(10,0)",
    "bigint": "NUMBER(19,0)",
    "decimal": "NUMBER",
    "float": "FLOAT",
    "double": "FLOAT",
    "bit": "BOOLEAN",
    "varchar": "VARCHAR",
    "char": "VARCHAR",
    "text": "VARCHAR",
    "longtext": "VARCHAR",
    "date": "DATE",
    "datetime": "TIMESTAMP_NTZ",
    "timestamp": "TIMESTAMP_NTZ",
    "time": "TIME",
    "json": "VARIANT",
}
_ORACLE_TYPES = {
    "number": "NUMBER",
    "float": "FLOAT",
    "binary_float": "FLOAT",
    "binary_double": "FLOAT",
    "varchar2": "VARCHAR",
    "nvarchar2": "VARCHAR",
    "char": "VARCHAR",
    "nchar": "VARCHAR",
    "clob": "VARCHAR",
    "nclob": "VARCHAR",
    "date": "TIMESTAMP_NTZ",
    "timestamp": "TIMESTAMP_NTZ",
}
_TYPE_TABLES = {
    "postgres": _PG_TYPES,
    "sqlserver": _MSSQL_TYPES,
    "mysql": _MYSQL_TYPES,
    "oracle": _ORACLE_TYPES,
}


def _sf_type(source_kind: str, data_type: str, char_len: int | None, num_prec: int | None, num_scale: int | None) -> str:
    t = data_type.lower().strip()
    # oracle reports TIMESTAMP(6); normalize parameterized names
    t = re.sub(r"\(\d+\)", "", t).strip()
    table = _TYPE_TABLES.get(source_kind, _MSSQL_TYPES)
    sf = table.get(t)
    if sf is None:
        return "VARCHAR"  # safe fallback: Snowflake VARCHAR holds anything textual
    if sf == "VARCHAR" and char_len and char_len > 0:
        return f"VARCHAR({char_len})"
    if sf == "NUMBER" and num_prec:
        return f"NUMBER({num_prec},{num_scale or 0})"
    return sf


def _qident(name: str) -> str:
    if not _IDENT_OK.match(name) or '"' in name:
        raise ValueError(f"unsafe identifier: {name!r}")
    return f'"{name.upper()}"'


@dataclass
class TableMigration:
    model_table: str
    source_schema: str
    source_object: str
    target_schema: str
    target_object: str
    columns: list[tuple[str, str]] = field(default_factory=list)  # (name, sf_type)
    rows_copied: int = 0
    source_rows: int = 0
    verified: bool = False
    elapsed_s: float = 0.0
    error: str | None = None
    copy_skipped: bool = False  # schema-only run (copy_data=False)
    ddl_action: str = ""  # created | reconciled | reused


@dataclass
class MigrationResult:
    tables: list[TableMigration] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return bool(self.tables) and all(
            t.error is None and (t.verified or t.copy_skipped) for t in self.tables
        )

    def summary(self) -> dict:
        return {
            "ok": self.ok,
            "tables": [
                {
                    "model_table": t.model_table,
                    "source": f"{t.source_schema}.{t.source_object}",
                    "target": f"{t.target_schema}.{t.target_object}",
                    "rows_copied": t.rows_copied,
                    "source_rows": t.source_rows,
                    "verified": t.verified,
                    "copy_skipped": t.copy_skipped,
                    "ddl_action": t.ddl_action,
                    "elapsed_s": round(t.elapsed_s, 2),
                    "error": t.error,
                }
                for t in self.tables
            ],
        }


_INFO_SCHEMA_SQL = (
    "SELECT column_name, data_type, character_maximum_length, "
    "numeric_precision, numeric_scale "
    "FROM information_schema.columns "
    "WHERE table_schema = {p} AND table_name = {p} ORDER BY ordinal_position"
)
_ORACLE_COLS_SQL = (
    "SELECT column_name, data_type, char_length, data_precision, data_scale "
    "FROM all_tab_columns WHERE owner = :1 AND table_name = :2 ORDER BY column_id"
)


def _introspect_columns(src_cursor, source_kind: str, schema: str, obj: str) -> list[tuple[str, str]]:
    if source_kind == "oracle":
        src_cursor.execute(_ORACLE_COLS_SQL, (schema.upper(), obj.upper()))
    else:
        placeholder = "?" if source_kind == "sqlserver" else "%s"
        src_cursor.execute(_INFO_SCHEMA_SQL.format(p=placeholder), (schema, obj))
    cols = []
    for name, dtype, char_len, prec, scale in src_cursor.fetchall():
        cols.append((name, _sf_type(source_kind, dtype, char_len, prec, scale)))
    return cols


def _locate_table(src_cursor, source_kind: str, schema: str, obj: str) -> tuple[str, str] | None:
    """Case-insensitive catalog-wide lookup: the M-declared schema may not match
    the user's actual source (e.g. report says dbo, their copy uses public)."""
    if source_kind == "oracle":
        src_cursor.execute(
            "SELECT owner, table_name FROM all_tab_columns "
            "WHERE UPPER(table_name) = :1 GROUP BY owner, table_name",
            (obj.upper(),),
        )
    else:
        placeholder = "?" if source_kind == "sqlserver" else "%s"
        src_cursor.execute(
            "SELECT table_schema, table_name FROM information_schema.tables "
            f"WHERE UPPER(table_name) = UPPER({placeholder})",
            (obj,),
        )
    rows = src_cursor.fetchall()
    if not rows:
        return None
    # prefer a schema match (case-insensitive), else the single/first hit
    for s, t in rows:
        if s.upper() == schema.upper():
            return s, t
    return rows[0][0], rows[0][1]


def _quote_src(source_kind: str, name: str) -> str:
    name = _src_ident(name)
    if source_kind == "sqlserver":
        return f"[{name}]"
    if source_kind == "mysql":
        return f"`{name}`"
    return f'"{name}"'  # postgres, oracle


def _existing_columns(sf_cursor, fq: str) -> dict[str, str] | None:
    """UPPER(name) -> declared type for an existing table, None when absent."""
    try:
        sf_cursor.execute(f"DESCRIBE TABLE {fq}")
        rows = sf_cursor.fetchall()
    except Exception:  # noqa: BLE001 - table does not exist
        return None
    cols = {str(r[0]).upper(): str(r[1]).upper() for r in rows if r and r[0]}
    return cols or None


_VARCHAR_LEN = re.compile(r"^VARCHAR\((\d+)\)$")
_NUMBER_ARGS = re.compile(r"^NUMBER\((\d+),(\d+)\)$")


def _reconcile_table_ddl(
    sf_cursor, fq: str, desired: list[tuple[str, str]], existing: dict[str, str], emit, label: str
) -> None:
    """Evolve a pre-existing table in place — additive and widening only.

    Missing columns are ADDed; VARCHAR/NUMBER are widened when the desired
    type is strictly wider. Existing columns and data are NEVER dropped or
    replaced; incompatible drift is surfaced as a warning, not an action."""
    for name, want in desired:
        have = existing.get(name.upper())
        if have is None:
            sf_cursor.execute(f"ALTER TABLE {fq} ADD COLUMN {_qident(name)} {want}")
            emit(label, f"added missing column {name} {want}")
            continue
        want_u = want.upper()
        if have == want_u:
            continue
        wv, hv = _VARCHAR_LEN.match(want_u), _VARCHAR_LEN.match(have)
        if wv and hv and int(wv.group(1)) > int(hv.group(1)):
            sf_cursor.execute(
                f"ALTER TABLE {fq} ALTER COLUMN {_qident(name)} SET DATA TYPE {want_u}"
            )
            emit(label, f"widened {name}: {have} -> {want_u}")
            continue
        wn, hn = _NUMBER_ARGS.match(want_u), _NUMBER_ARGS.match(have)
        if wn and hn and wn.group(2) == hn.group(2) and int(wn.group(1)) > int(hn.group(1)):
            sf_cursor.execute(
                f"ALTER TABLE {fq} ALTER COLUMN {_qident(name)} SET DATA TYPE {want_u}"
            )
            emit(label, f"widened {name}: {have} -> {want_u}")
            continue
        emit(label, f"column {name}: keeping existing type {have} (source wants {want_u})")


def migrate_tables(
    binding_map: BindingMap,
    source_conn,
    source_kind: str,
    sf_cursor,
    target_database: str,
    target_schema: str,
    batch_size: int = 10_000,
    copy_data: bool = True,
    on_progress=None,
) -> MigrationResult:
    """Migrate every needs_migration table into Snowflake and rebind it.

    copy_data=False -> schema-only: objects are created/reconciled and bindings
    repointed, but no rows move (data provisioning owned by the customer's
    pipeline). Pre-existing tables are never dropped: empty ones are
    reconciled in place; populated ones are reloaded via a staged swap so a
    mid-copy failure can never destroy served data."""
    result = MigrationResult()
    emit = on_progress or (lambda *_: None)

    sf_cursor.execute(
        f"CREATE SCHEMA IF NOT EXISTS {_qident(target_database)}.{_qident(target_schema)}"
    )

    for binding in binding_map.needs_migration:
        tm = TableMigration(
            model_table=binding.table,
            source_schema=binding.source_schema or "",
            source_object=binding.source_object or "",
            target_schema=target_schema,
            target_object=(binding.source_object or binding.table).upper(),
        )
        result.tables.append(tm)
        start = time.time()
        try:
            src_cur = source_conn.cursor()
            tm.columns = _introspect_columns(
                src_cur, source_kind, tm.source_schema, tm.source_object
            )
            if not tm.columns:
                located = _locate_table(src_cur, source_kind, tm.source_schema, tm.source_object)
                if located:
                    emit(
                        tm.model_table,
                        f"declared {tm.source_schema}.{tm.source_object} not found; "
                        f"using {located[0]}.{located[1]} from the source catalog",
                    )
                    tm.source_schema, tm.source_object = located
                    tm.columns = _introspect_columns(
                        src_cur, source_kind, tm.source_schema, tm.source_object
                    )
            if not tm.columns:
                raise ValueError(
                    f"source table {tm.source_schema}.{tm.source_object} not found "
                    "or has no columns"
                )

            fq = f"{_qident(target_database)}.{_qident(target_schema)}.{_qident(tm.target_object)}"
            src_ident = (
                f"{_quote_src(source_kind, tm.source_schema)}."
                f"{_quote_src(source_kind, tm.source_object)}"
            )
            src_cur.execute(f"SELECT COUNT(*) FROM {src_ident}")  # noqa: S608
            tm.source_rows = int(src_cur.fetchone()[0])

            existing_cols = _existing_columns(sf_cursor, fq)
            existing = -1
            if existing_cols is not None:
                sf_cursor.execute(f"SELECT COUNT(*) FROM {fq}")  # noqa: S608
                existing = int(sf_cursor.fetchone()[0])

            def _rebind(detail: str) -> None:
                binding.status = "resolved"
                binding.database = target_database
                binding.schema_name = target_schema
                binding.object_name = tm.target_object
                binding.object_kind = "Table"
                binding.detail = detail

            # ---- DDL: create new, or reconcile pre-existing without loss ----
            cols_ddl = ", ".join(f"{_qident(c)} {t}" for c, t in tm.columns)
            if existing_cols is None:
                sf_cursor.execute(f"CREATE TABLE {fq} ({cols_ddl})")  # noqa: S608
                tm.ddl_action = "created"
                emit(tm.model_table, f"created {fq} ({len(tm.columns)} columns)")
            else:
                _reconcile_table_ddl(
                    sf_cursor, fq, tm.columns, existing_cols, emit, tm.model_table
                )
                tm.ddl_action = "reconciled" if existing > 0 else "reused"
                emit(
                    tm.model_table,
                    f"table pre-exists ({existing:,} rows) — DDL reconciled in place, no data dropped",
                )

            # ---- schema-only mode: rebind and stop before any data moves ----
            if not copy_data:
                tm.copy_skipped = True
                tm.rows_copied = max(existing, 0)
                tm.verified = existing == tm.source_rows and tm.source_rows > 0
                _rebind(
                    f"schema-only migration ({tm.ddl_action}); data provisioning "
                    f"delegated — target has {max(existing, 0):,} rows, "
                    f"source has {tm.source_rows:,}"
                )
                emit(
                    tm.model_table,
                    f"schema-only: {tm.ddl_action}, copy skipped "
                    f"(target {max(existing, 0):,} / source {tm.source_rows:,} rows)",
                )
                continue

            # idempotent re-run: target already complete -> skip the copy
            if existing == tm.source_rows and tm.source_rows > 0:
                tm.rows_copied = existing
                tm.verified = True
                _rebind(f"already migrated ({existing:,} rows verified)")
                emit(tm.model_table, f"already migrated — {existing:,} rows verified, skipping copy")
                continue

            # ---- load: direct into empty tables, staged swap over live data ----
            load_fq = fq
            staged = existing > 0
            if staged:
                load_fq = (
                    f"{_qident(target_database)}.{_qident(target_schema)}."
                    f"{_qident(tm.target_object + '__PBIC_STAGE')}"
                )
                sf_cursor.execute(f"CREATE OR REPLACE TABLE {load_fq} ({cols_ddl})")  # noqa: S608
                emit(
                    tm.model_table,
                    f"target holds {existing:,} rows — loading into a staging table, "
                    "swap happens only after row counts verify",
                )

            col_list = ", ".join(_qident(c) for c, _ in tm.columns)
            placeholders = ", ".join(["%s"] * len(tm.columns))
            insert_sql = f"INSERT INTO {load_fq} ({col_list}) VALUES ({placeholders})"  # noqa: S608

            load_object = tm.target_object + "__PBIC_STAGE" if staged else tm.target_object
            src_cur.execute(f"SELECT {col_list_src(tm.columns, source_kind)} FROM {src_ident}")  # noqa: S608
            writer = _make_batch_writer(
                sf_cursor, insert_sql, tm, target_database, target_schema, load_object
            )
            while True:
                rows = src_cur.fetchmany(batch_size)
                if not rows:
                    break
                writer(rows)
                tm.rows_copied += len(rows)
                emit(
                    tm.model_table,
                    f"copied {tm.rows_copied:,}/{tm.source_rows:,} rows",
                )

            sf_cursor.execute(f"SELECT COUNT(*) FROM {load_fq}")  # noqa: S608
            target_rows = int(sf_cursor.fetchone()[0])
            tm.verified = target_rows == tm.source_rows
            if not tm.verified:
                if staged:
                    sf_cursor.execute(f"DROP TABLE IF EXISTS {load_fq}")
                    emit(tm.model_table, "staging discarded — existing data untouched")
                tm.error = f"row count mismatch: source={tm.source_rows}, target={target_rows}"
            else:
                if staged:
                    sf_cursor.execute(f"ALTER TABLE {load_fq} SWAP WITH {fq}")
                    sf_cursor.execute(f"DROP TABLE IF EXISTS {load_fq}")
                    emit(tm.model_table, "verified staging swapped in atomically")
                _rebind(
                    f"migrated from {source_kind} {tm.source_schema}.{tm.source_object} "
                    f"({tm.source_rows:,} rows, verified)"
                )
                emit(tm.model_table, f"verified {target_rows:,} rows — rebound to Snowflake")
        except Exception as e:  # noqa: BLE001 - per-table isolation; surfaced in result
            tm.error = str(e)
            emit(tm.model_table, f"FAILED: {e}")
        finally:
            tm.elapsed_s = time.time() - start
    return result


def col_list_src(columns: list[tuple[str, str]], source_kind: str) -> str:
    return ", ".join(_quote_src(source_kind, c) for c, _ in columns)


def _make_batch_writer(
    sf_cursor,
    insert_sql: str,
    tm: TableMigration,
    database: str,
    schema: str,
    load_object: str | None = None,
):
    """Prefer write_pandas (PUT + COPY, ~100x faster); fall back to executemany.
    `load_object` overrides the destination (staged-swap loads)."""
    target_object = load_object or tm.target_object
    try:
        import pandas as pd
        from snowflake.connector.pandas_tools import write_pandas

        conn = sf_cursor.connection
        col_names = [c.upper() for c, _ in tm.columns]

        def write(rows):
            # pyodbc.Row and other DB-API row types must become plain tuples,
            # otherwise pandas treats the batch as a single object column
            df = pd.DataFrame([tuple(r) for r in rows], columns=col_names)
            write_pandas(
                conn,
                df,
                table_name=target_object,
                database=database.upper(),
                schema=schema.upper(),
                auto_create_table=False,
                overwrite=False,
            )

        return write
    except ImportError:  # pragma: no cover - pandas ships with snowflake extra

        def write(rows):
            sf_cursor.executemany(insert_sql, [tuple(r) for r in rows])

        return write


_SNOWFLAKE_M_TEMPLATE = '''let
    Source = Snowflake.Databases("{account}", "{warehouse}"),
    DB = Source{{[Name="{database}", Kind="Database"]}}[Data],
    SCH = DB{{[Name="{schema}", Kind="Schema"]}}[Data],
    OBJ = SCH{{[Name="{object_name}", Kind="{kind}"]}}[Data]
in
    OBJ'''


def rewrite_bundle_to_snowflake(
    bundle,
    migrations: list[TableMigration],
    account: str,
    warehouse: str,
    database: str,
    extra_bindings: dict[str, tuple[str, str, str]] | None = None,
) -> int:
    """Repoint migrated tables' M partitions at Snowflake so every future
    binding-map build resolves natively — the report is permanently migrated.
    `extra_bindings`: model table -> (schema, object, kind) for objects the
    smart mover recreated as views rather than table copies."""
    by_table: dict[str, tuple[str, str, str]] = {
        t.model_table: (t.target_schema, t.target_object, "Table")
        for t in migrations
        if t.verified and not t.error
    }
    by_table.update(extra_bindings or {})
    rewritten = 0
    for table in bundle.model.tables:
        tm = by_table.get(table.name)
        if tm is None or not table.partitions:
            continue
        schema, object_name, kind = tm
        table.partitions[0].expression = _SNOWFLAKE_M_TEMPLATE.format(
            account=account,
            warehouse=warehouse or "COMPUTE_WH",
            database=database.upper(),
            schema=schema.upper(),
            object_name=object_name.upper(),
            kind=kind,
        )
        table.partitions[0].source_type = "m"
        rewritten += 1
    return rewritten
