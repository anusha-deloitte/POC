from pathlib import Path

import duckdb
import pytest

from app.binding.resolver import build_binding_map
from app.parsers.bundle import load_pbip
from app.runtime.accelerate import (
    AccelerationError,
    DuckDBExecutor,
    extract_path,
    is_hydrated,
    meta_path,
    to_duckdb_sql,
)
from app.runtime.engine import DimensionRef, MeasureRefSpec, QuerySpec, SemanticEngine

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


@pytest.fixture(scope="module")
def binding_map():
    return build_binding_map(load_pbip(FIXTURE).model)


@pytest.fixture(scope="module")
def engine(binding_map):
    return SemanticEngine(load_pbip(FIXTURE).model, binding_map)


class TestTranspile:
    def test_physical_names_mapped_to_extract(self, engine, binding_map):
        sql, _ = engine.build_sql(QuerySpec(measures=[MeasureRefSpec(name="Paid Amount")]))
        local = to_duckdb_sql(sql, binding_map)
        assert '"x_mv_medical_cost_summary"' in local
        assert "SNOWFLAKE_FINOPS_DASHBOARD__DB" not in local

    def test_iff_transpiles(self, engine, binding_map):
        sql, _ = engine.build_sql(QuerySpec(measures=[MeasureRefSpec(name="Total PMPM")]))
        local = to_duckdb_sql(sql, binding_map)
        assert "IFF(" not in local.upper() or "CASE" in local.upper() or "IF(" in local.upper()

    def test_dateadd_transpiles(self, engine, binding_map):
        sql, _ = engine.build_sql(
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_MONTH", column="YEAR_MONTH")],
                measures=[MeasureRefSpec(name="Allowed PY")],
            )
        )
        local = to_duckdb_sql(sql, binding_map)
        assert "x_dim_month" in local


class TestExecutorAgainstSyntheticExtract:
    @pytest.fixture()
    def hydrated_dir(self, tmp_path, binding_map):
        con = duckdb.connect(str(extract_path(tmp_path)))
        con.execute(
            "CREATE TABLE x_dt_total_cost_of_care AS "
            "SELECT * FROM (VALUES (202301, 100.0, 10), (202302, 200.0, 20)) "
            "AS t(YEAR_MONTH_NBR, TOTAL_COST_OF_CARE, MEMBER_MONTHS)"
        )
        con.close()
        meta_path(tmp_path).write_text('{"hydrated_at": 0, "tables": {}}')
        return tmp_path

    def test_executor_runs_transpiled_sql(self, hydrated_dir, binding_map):
        ex = DuckDBExecutor(hydrated_dir, binding_map)
        ex.execute(
            'SELECT SUM("DT_TOTAL_COST_OF_CARE"."TOTAL_COST_OF_CARE") AS "t" FROM '
            '"SNOWFLAKE_FINOPS_DASHBOARD__DB"."PBI_HEALTH_ANALYTICS"."DT_TOTAL_COST_OF_CARE" '
            'AS "DT_TOTAL_COST_OF_CARE"'
        )
        assert ex.fetchone()[0] == 300.0
        ex.close()

    def test_unhydrated_raises(self, tmp_path, binding_map):
        with pytest.raises(AccelerationError, match="not hydrated"):
            DuckDBExecutor(tmp_path, binding_map)

    def test_is_hydrated(self, hydrated_dir):
        assert is_hydrated(hydrated_dir)
