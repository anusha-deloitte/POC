import { describe, expect, it } from 'vitest'
import { handle, readErrorDetail } from '../api/client'

describe('api client error parsing', () => {
  it('reads plain text error bodies without throwing json parse errors', async () => {
    const res = new Response('Internal Server Error', {
      status: 500,
      statusText: 'Internal Server Error',
      headers: { 'Content-Type': 'text/plain' },
    })

    await expect(readErrorDetail(res)).resolves.toBe('Internal Server Error')
  })

  it('handle surfaces plain text errors as Error messages', async () => {
    const res = new Response('Internal Server Error', {
      status: 500,
      statusText: 'Internal Server Error',
      headers: { 'Content-Type': 'text/plain' },
    })

    await expect(handle(res)).rejects.toThrow('Internal Server Error')
  })
})
