from pathlib import Path

import pytest

from app.binding.m_parser import parse_m_binding, resolve_parameter
from app.binding.resolver import build_binding_map
from app.parsers.bundle import load_pbip

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


@pytest.fixture(scope="module")
def bundle():
    return load_pbip(FIXTURE)


class TestMParser:
    def test_literal_navigation(self):
        m = '''
        let
            Source = Snowflake.Databases("acct.snowflakecomputing.com", "WH"),
            DB = Source{[Name="MYDB", Kind="Database"]}[Data],
            S = DB{[Name="MYSCHEMA", Kind="Schema"]}[Data],
            T = S{[Name="MYTABLE", Kind="Table"]}[Data]
        in T
        '''
        b = parse_m_binding(m)
        assert (b.database, b.schema, b.object_name, b.object_kind) == (
            "MYDB", "MYSCHEMA", "MYTABLE", "Table",
        )
        assert b.is_resolved

    def test_parameterized_navigation(self):
        m = '''
        let
            Source = Snowflake.Databases(SnowflakeServer, SnowflakeWarehouse, [Role = SnowflakeRole]),
            Db = Source{[Name = SnowflakeDatabase, Kind = "Database"]}[Data],
            Sch = Db{[Name = "PBI_HEALTH_ANALYTICS", Kind = "Schema"]}[Data],
            Src = Sch{[Name = "DIM_LOB", Kind = "View"]}[Data]
        in Src
        '''
        exprs = {"SnowflakeDatabase": '"REALDB" meta [IsParameterQuery=true, Type="Text"]'}
        b = parse_m_binding(m, exprs)
        assert b.database == "REALDB"
        assert b.object_name == "DIM_LOB"
        assert b.object_kind == "View"

    def test_unresolved_parameter_flagged(self):
        m = 'x = Source{[Name = MysteryParam, Kind = "Database"]}[Data]'
        b = parse_m_binding("Snowflake.Databases(a,b)," + m, {})
        assert "MysteryParam" in b.unresolved_params
        assert not b.is_resolved

    def test_native_query(self):
        m = 'Value.NativeQuery(Source, "select 1 as x", null, [EnableFolding=true])'
        b = parse_m_binding(m)
        assert b.native_query == "select 1 as x"
        assert b.is_resolved

    def test_transform_steps_recorded(self):
        m = '''
        S = Db{[Name="A", Kind="Schema"]}[Data],
        T = S{[Name="B", Kind="Table"]}[Data],
        Out = Table.RemoveColumns(T, {"C1"})
        '''
        b = parse_m_binding("Snowflake.Databases(x,y)," + m)
        assert "Table.RemoveColumns" in b.transform_steps

    def test_resolve_parameter_strips_meta(self):
        exprs = {"P": '"hello world" meta [IsParameterQuery = true, Type = "Text"]'}
        assert resolve_parameter("P", exprs) == "hello world"


class TestBindingMap:
    def test_real_report_bindings(self, bundle):
        bm = build_binding_map(bundle.model)
        resolved = {n: b for n, b in bm.bindings.items() if b.status == "resolved"}
        assert len(resolved) == 8
        assert len(bm.materialization_required) == 1
        assert bm.materialization_required[0].table == "DIM_SERVICE_LINE"
        mv = bm.get("MV_MEDICAL_COST_SUMMARY")
        assert mv.schema_name == "PBI_HEALTH_ANALYTICS"
        assert mv.database == "SNOWFLAKE_FINOPS_DASHBOARD__DB"
        assert mv.qualified_name == (
            '"SNOWFLAKE_FINOPS_DASHBOARD__DB"."PBI_HEALTH_ANALYTICS"."MV_MEDICAL_COST_SUMMARY"'
        )

    def test_measure_table_virtual(self, bundle):
        bm = build_binding_map(bundle.model)
        assert bm.get("_Measures").status == "virtual"

    def test_transform_warning_surfaced(self, bundle):
        bm = build_binding_map(bundle.model)
        assert any("Table.RemoveColumns" in w for w in bm.warnings)
