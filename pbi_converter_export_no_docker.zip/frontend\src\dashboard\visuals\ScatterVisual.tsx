import type { EChartsOption } from 'echarts'
import { formatValue } from '../format'
import { usePalette, useThemeTokens } from '../theme'
import type { VisualResult, VisualSpec } from '../types'
import { EChart } from './EChart'

export function ScatterVisual({
  spec,
  data,
  onSelect,
}: {
  spec: VisualSpec
  data?: VisualResult
  onSelect?: (values: (string | number)[]) => void
}) {
  const palette = usePalette()
  const theme = useThemeTokens()
  if (!data) return <div className="p-2 text-xs text-surface-400">…</div>
  if (data.error) return <div className="p-2 text-xs text-brand-red">{data.error}</div>

  const roleOf = (role: string) =>
    spec.measure_keys.find((k) => spec.measure_roles[k] === role)
  const xKey = roleOf('X') ?? spec.measure_keys[0]
  const yKey = roleOf('Y') ?? spec.measure_keys[1]
  const sizeKey = roleOf('Size')
  const dimKey = spec.dim_keys[0]

  const idx = (k?: string) => (k ? data.columns.indexOf(k) : -1)
  const xi = idx(xKey)
  const yi = idx(yKey)
  const si = idx(sizeKey)
  const di = idx(dimKey)

  const sizes = si >= 0 ? data.rows.map((r) => Number(r[si] ?? 0)) : []
  const maxSize = sizes.length ? Math.max(...sizes) : 1

  const points = data.rows.map((r) => ({
    name: di >= 0 ? String(r[di] ?? '') : '',
    value: [Number(r[xi] ?? 0), Number(r[yi] ?? 0), si >= 0 ? Number(r[si] ?? 0) : 1],
  }))

  // quadrant analysis: mean reference lines split the field into 4 segments
  const quadrant = spec.options?.quadrant === true && points.length > 1
  const meanX = points.reduce((a, p) => a + p.value[0], 0) / (points.length || 1)
  const meanY = points.reduce((a, p) => a + p.value[1], 0) / (points.length || 1)

  const option: EChartsOption = {
    grid: { left: 8, right: 16, top: 12, bottom: 4, containLabel: true },
    tooltip: {
      formatter: (p) => {
        const v = (p as { value: number[]; name: string })
        return (
          `<b>${v.name}</b><br/>` +
          `${xKey}: ${formatValue(v.value[0], spec.measure_formats[xKey!])}<br/>` +
          `${yKey}: ${formatValue(v.value[1], spec.measure_formats[yKey!])}` +
          (sizeKey ? `<br/>${sizeKey}: ${formatValue(v.value[2], spec.measure_formats[sizeKey])}` : '')
        )
      },
      backgroundColor: theme.tooltipBackground,
      borderColor: theme.panelBorder,
      textStyle: { color: theme.tooltipText, fontFamily: theme.fontFamily, fontSize: 11 },
    },
    xAxis: {
      type: 'value',
      name: xKey,
      nameTextStyle: { fontSize: 9 },
      axisLabel: { fontSize: 9, formatter: (v: number) => formatValue(v, spec.measure_formats[xKey!]) },
      scale: true,
    },
    yAxis: {
      type: 'value',
      name: yKey,
      nameTextStyle: { fontSize: 9 },
      axisLabel: { fontSize: 9, formatter: (v: number) => formatValue(v, spec.measure_formats[yKey!]) },
      scale: true,
    },
    series: [
      {
        type: 'scatter',
        data: points,
        symbolSize: (val: number[]) =>
          sizeKey ? 8 + 30 * Math.sqrt(val[2] / maxSize) : 12,
        itemStyle: { color: palette[0], opacity: 0.75 },
        label: {
          // PBI scatter shows category labels only when the author enabled them
          show:
            (spec.options?.show_category_labels === true || quadrant) && points.length <= 15,
          formatter: (p) => (p as { name: string }).name,
          position: 'top',
          fontSize: 8,
          color: '#475569',
        },
        ...(quadrant
          ? {
              markLine: {
                silent: true,
                symbol: 'none',
                lineStyle: { type: 'dashed', color: '#94A3B8', width: 1 },
                label: { show: false },
                data: [{ xAxis: meanX }, { yAxis: meanY }],
              },
            }
          : {}),
      },
    ],
  }
  return <EChart option={option} onItemClick={(name) => onSelect?.([name])} />
}
