import { readErrorDetail } from '../api/client'
import type { DashboardRecommendation, DashboardSpec, FilterClause, VisualResult } from './types'

const BASE = '/api/v1'

export async function fetchDashboardSpec(
  conversionId: string,
  variant?: 'reimagined',
): Promise<DashboardSpec> {
  const qs = variant ? `?variant=${variant}` : ''
  const res = await fetch(`${BASE}/conversions/${conversionId}/dashboard/spec${qs}`)
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function fetchVisualData(
  conversionId: string,
  connectionId: string,
  page: string,
  visuals: string[],
  filtersByVisual: Record<string, FilterClause[]>,
  mode: 'live' | 'accelerated' = 'live',
  variant?: 'reimagined',
): Promise<Record<string, VisualResult>> {
  const qs = variant ? `?variant=${variant}` : ''
  const res = await fetch(`${BASE}/conversions/${conversionId}/dashboard/query${qs}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      connection_id: connectionId,
      mode,
      queries: visuals.map((v) => ({ page, visual: v, filters: filtersByVisual[v] ?? [] })),
    }),
  })
  if (!res.ok) throw new Error(await readErrorDetail(res))
  const body = await res.json()
  const out: Record<string, VisualResult> = {}
  for (const r of body.results as VisualResult[]) out[r.visual] = r
  return out
}

export interface MappingEntry {
  original: {
    page: string
    visual: string
    type: string
    title: string | null
    dims: string[]
    measures: string[]
    slicer_target: { table: string; column: string } | null
    region: string
  }
  reimagined: {
    visual: string
    type: string
    title: string | null
    dims: string[]
    measures: string[]
    region: string
  }
  change_kind: 'restyle' | 're-encode' | 'relocate' | 'dedupe'
  rationale: string
  information_delta: { missing: string[]; relocated: string[]; added: string[] }
}

export interface ZeroLoss {
  passed: boolean
  coverage: Record<string, string>
  gaps: string[]
}

export interface PageArchitecture {
  profiles: {
    name: string
    display_name: string
    data_visuals: number
    measures: string[]
    dims: string[]
    exclusive_dims: string[]
  }[]
  conformed_dims: string[]
  pairs: {
    pages: string[]
    measure_jaccard: number
    shared_measures: string[]
    exclusive_dim_jaccard: number
    combined_data_visuals: number
    verdict: string
    reason: string
  }[]
  merges: { into: string; absorbed: string; reason: string }[]
  splits: { page: string; reason: string }[]
  pages_before: number
  pages_after: number
  verdict: string
}

export interface ReimagineBuilt {
  spec: DashboardSpec
  mapping: {
    conversion_id: string
    pages: string[]
    entries: MappingEntry[]
    page_map?: Record<string, string>
    architecture?: PageArchitecture
  }
  zero_loss: ZeroLoss
}

export async function buildReimagineVariant(
  conversionId: string,
  recommendationId = 'latest',
): Promise<{ built: boolean; zero_loss: ZeroLoss; mappings: number }> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/build`,
    { method: 'POST' },
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function fetchReimagineBuilt(
  conversionId: string,
  recommendationId = 'latest',
): Promise<ReimagineBuilt> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/built`,
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function acceptReimagineVariant(
  conversionId: string,
  recommendationId = 'latest',
  note = '',
): Promise<{ accepted: boolean }> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/accept`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note }),
    },
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function hydrateExtract(
  conversionId: string,
  connectionId: string,
): Promise<{ total_rows: number; elapsed_s: number }> {
  const res = await fetch(`${BASE}/conversions/${conversionId}/dashboard/accelerate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ connection_id: connectionId }),
  })
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function accelerationStatus(conversionId: string): Promise<{ hydrated: boolean }> {
  const res = await fetch(`${BASE}/conversions/${conversionId}/dashboard/accelerate`)
  if (!res.ok) return { hydrated: false }
  return res.json()
}

export async function generateReimagineRecommendation(
  conversionId: string,
  connectionId: string,
  mode: 'live' | 'accelerated' = 'live',
  useLlm = false,
): Promise<DashboardRecommendation> {
  const res = await fetch(`${BASE}/conversions/${conversionId}/dashboard/reimagine`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ connection_id: connectionId, mode, use_llm: useLlm }),
  })
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function fetchReimagineLatest(
  conversionId: string,
): Promise<DashboardRecommendation | null> {
  const res = await fetch(`${BASE}/conversions/${conversionId}/dashboard/reimagine/latest`)
  if (res.status === 404) return null
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function fetchReimagineHistory(
  conversionId: string,
): Promise<{ recommendations: { id: string; created_at: number; status: string; summary: string; page_count: number }[] }> {
  const res = await fetch(`${BASE}/conversions/${conversionId}/dashboard/reimagine/history`)
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function fetchReimagineMockups(
  conversionId: string,
  recommendationId: string,
): Promise<{
  id: string
  snapshot: DashboardRecommendation['snapshot']
  quality: DashboardRecommendation['quality']
  scenes: DashboardRecommendation['mockup_scenes']
  pages: DashboardRecommendation['pages']
  visual_decisions: DashboardRecommendation['visual_decisions']
}> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/mockups`,
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function approveReimagineRecommendation(
  conversionId: string,
  recommendationId: string,
  note = '',
): Promise<DashboardRecommendation> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/approve`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note }),
    },
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function rejectReimagineRecommendation(
  conversionId: string,
  recommendationId: string,
  note = '',
): Promise<DashboardRecommendation> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/reject`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note }),
    },
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}
