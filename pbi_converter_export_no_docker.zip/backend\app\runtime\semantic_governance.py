"""Semantic runtime governance helpers.

These utilities are intentionally lightweight so they can be validated in
unit tests without importing the full dashboard runtime dependency graph.
"""

from __future__ import annotations

import hashlib
from enum import StrEnum


class QueryExecutionTier(StrEnum):
    TIER_A_NATIVE = "tier_a_native"
    TIER_B_COMPATIBILITY = "tier_b_compatibility"
    TIER_C_EXCEPTION = "tier_c_exception"


def cache_key(
    conversion_id: str,
    mode: str,
    sql: str,
    tier: QueryExecutionTier,
    row_scope_id: str | None,
    model_version: str | None,
    data_version: str | None,
) -> str:
    digest = hashlib.sha256(sql.encode("utf-8")).hexdigest()[:16]
    return ":".join(
        [
            conversion_id,
            mode,
            tier.value,
            row_scope_id or "__noscope__",
            model_version or "__nomodel__",
            data_version or "__nodata__",
            digest,
        ]
    )


def trace_codes(warnings: list[str]) -> list[str]:
    codes: list[str] = []
    for w in warnings:
        if w.startswith("[OVERLAY:") and "]" in w:
            codes.append(w[9 : w.index("]")])
    return codes
