"""Accelerated mode: hydrate bound tables from Snowflake into a local DuckDB
extract, then serve visual queries from it (the import-mode analogue).

Snowflake stays the source of truth; the extract records its hydration time.
Engine SQL (Snowflake dialect) is transpiled to DuckDB with sqlglot; the
fully-qualified physical names are mapped to local extract tables.
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path

import duckdb
import sqlglot

from app.binding.resolver import BindingMap

_MAX_ROWS_PER_TABLE = 5_000_000


class AccelerationError(Exception):
    pass


def extract_path(conversion_dir: Path) -> Path:
    return conversion_dir / "accelerated.duckdb"


def meta_path(conversion_dir: Path) -> Path:
    return conversion_dir / "accelerated.json"


def _local_name(binding) -> str:
    return f"x_{binding.table.lower()}"


def hydrate(binding_map: BindingMap, sf_cursor, conversion_dir: Path) -> dict:
    """Copy every resolved physical table into the local DuckDB extract.

    Uses Snowflake's Arrow path -> DuckDB Arrow ingestion: correct types from
    the Arrow schema and bulk speed (no row-by-row inserts).
    """
    db_file = extract_path(conversion_dir)
    if db_file.exists():
        db_file.unlink()
    con = duckdb.connect(str(db_file))
    stats: dict[str, int] = {}
    started = time.time()
    try:
        for b in binding_map.bindings.values():
            if b.status != "resolved" or not b.qualified_name:
                continue
            # qualified_name is safe_ident-validated
            sf_cursor.execute(
                f"SELECT * FROM {b.qualified_name} LIMIT {_MAX_ROWS_PER_TABLE}"  # noqa: S608
            )
            arrow_table = sf_cursor.fetch_arrow_all()
            local = _local_name(b)
            if arrow_table is None or arrow_table.num_rows == 0:
                cols = ", ".join(f'"{d[0]}" VARCHAR' for d in sf_cursor.description)
                con.execute(f'CREATE TABLE "{local}" ({cols})')  # noqa: S608
                stats[b.table] = 0
                continue
            con.register("_incoming", arrow_table)
            con.execute(f'CREATE TABLE "{local}" AS SELECT * FROM _incoming')  # noqa: S608
            con.unregister("_incoming")
            stats[b.table] = arrow_table.num_rows
        meta = {
            "hydrated_at": round(started, 3),
            "elapsed_s": round(time.time() - started, 2),
            "tables": stats,
            "total_rows": sum(stats.values()),
        }
        meta_path(conversion_dir).write_text(json.dumps(meta, indent=2), encoding="utf-8")
        return meta
    finally:
        con.close()


def is_hydrated(conversion_dir: Path) -> bool:
    return extract_path(conversion_dir).exists() and meta_path(conversion_dir).exists()


def hydration_meta(conversion_dir: Path) -> dict | None:
    if not is_hydrated(conversion_dir):
        return None
    return json.loads(meta_path(conversion_dir).read_text(encoding="utf-8"))


_IFF_RE = re.compile(r"\bIFF\s*\(", re.IGNORECASE)


def to_duckdb_sql(snowflake_sql: str, binding_map: BindingMap) -> str:
    """Rewrite physical names to extract tables, then transpile the dialect."""
    sql = snowflake_sql
    for b in binding_map.bindings.values():
        if b.status == "resolved" and b.qualified_name:
            sql = sql.replace(b.qualified_name, f'"{_local_name(b)}"')
    # IFF -> IF is handled by sqlglot; keep explicit for clarity of intent
    transpiled = sqlglot.transpile(sql, read="snowflake", write="duckdb", pretty=False)
    if not transpiled:
        raise AccelerationError("empty transpilation result")
    return transpiled[0]


class DuckDBExecutor:
    """Cursor-compatible facade over the extract for the query endpoint."""

    def __init__(self, conversion_dir: Path, binding_map: BindingMap):
        if not is_hydrated(conversion_dir):
            raise AccelerationError("extract not hydrated; POST /accelerate first")
        self._con = duckdb.connect(str(extract_path(conversion_dir)), read_only=True)
        self._bindings = binding_map
        self.description: list[tuple] = []
        self._rows: list[tuple] = []

    def execute(self, snowflake_sql: str):
        local_sql = to_duckdb_sql(snowflake_sql, self._bindings)
        res = self._con.execute(local_sql)
        self.description = [(d[0],) for d in res.description]
        self._rows = res.fetchall()
        return self

    def fetchall(self):
        return self._rows

    def fetchone(self):
        return self._rows[0] if self._rows else None

    def close(self):
        self._con.close()
