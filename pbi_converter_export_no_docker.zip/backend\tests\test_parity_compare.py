from app.validation.parity_compare import compare_result_grids


def test_compare_result_grids_passes_for_equal_values_and_tolerant_numbers():
    ok, detail, deltas = compare_result_grids(
        expected_columns=["A", "B"],
        expected_rows=[[1.0, "x"], [2.0, "y"]],
        actual_columns=["A", "B"],
        actual_rows=[[1.0000001, "x"], [2.0, "y"]],
        rel_tol=1e-5,
    )
    assert ok is True
    assert "passed" in detail
    assert deltas == []


def test_compare_result_grids_fails_on_schema_mismatch():
    ok, detail, deltas = compare_result_grids(
        expected_columns=["A", "B"],
        expected_rows=[[1, 2]],
        actual_columns=["A", "C"],
        actual_rows=[[1, 2]],
    )
    assert ok is False
    assert detail == "schema mismatch"
    assert deltas[0].column == "__schema__"


def test_compare_result_grids_fails_on_cell_mismatch():
    ok, detail, deltas = compare_result_grids(
        expected_columns=["A", "B"],
        expected_rows=[[1, "x"]],
        actual_columns=["A", "B"],
        actual_rows=[[1, "z"]],
    )
    assert ok is False
    assert "cell mismatches" in detail
    assert deltas[0].column == "B"
    assert deltas[0].detail == "value mismatch"


def test_semantic_view_coverage_errors_are_not_parity_failures():
    """Snowflake rejecting an unrelated-entity SEMANTIC_VIEW query is a coverage
    gap, not a numeric mismatch, so it must not be reported as a failure."""
    from app.validation.harness import _is_semantic_view_coverage_error

    unrelated = Exception(
        "010959 (42601): SQL compilation error:\n"
        "The entities 'DIM_PROVIDER_TIER' and 'DT_TOTAL_COST_OF_CARE' are not related."
    )
    assert _is_semantic_view_coverage_error(unrelated) is True
    assert _is_semantic_view_coverage_error(Exception("division by zero")) is False
