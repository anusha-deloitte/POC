from functools import lru_cache
from typing import Annotated

from fastapi import Depends, Header, HTTPException

from app.core.config import Settings, get_settings
from app.services.connections import ConnectionStore
from app.services.ingest import IngestService
from app.services.source_connections import SourceConnectionStore


@lru_cache
def get_ingest_service() -> IngestService:
    return IngestService(get_settings().storage_dir)


@lru_cache
def get_connection_store() -> ConnectionStore:
    s = get_settings()
    return ConnectionStore(s.storage_dir, s.secrets_key_file)


@lru_cache
def get_source_connection_store() -> SourceConnectionStore:
    s = get_settings()
    return SourceConnectionStore(s.storage_dir, s.secrets_key_file)


def require_token(
    settings: Annotated[Settings, Depends(get_settings)],
    authorization: Annotated[str | None, Header()] = None,
) -> None:
    if not settings.api_token:
        return  # auth disabled in local dev
    if authorization != f"Bearer {settings.api_token}":
        raise HTTPException(status_code=401, detail="invalid or missing token")
