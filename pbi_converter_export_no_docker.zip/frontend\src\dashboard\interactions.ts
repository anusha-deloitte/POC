import type {
  FilterClause,
  InteractionGraph,
  InteractionState,
  PageSpec,
  VisualSpec,
} from './types'

export interface VisualInteractionState {
  active: boolean
  highlighted: boolean
  filtered: boolean
  filters: FilterClause[]
}

export function emptyInteractionState(): InteractionState {
  return {
    selections: {},
    hoveredVisual: null,
    activeBookmark: null,
  }
}

export function toggleSelection(
  state: InteractionState,
  visual: VisualSpec,
  values: (string | number)[],
): InteractionState {
  const current = state.selections[visual.name] ?? []
  const nextValues =
    current.length === values.length && current.every((value, index) => value === values[index])
      ? []
      : values
  const selections = { ...state.selections }
  if (nextValues.length) selections[visual.name] = nextValues
  else delete selections[visual.name]
  return { ...state, selections }
}

export function clearSelection(state: InteractionState, visualName: string): InteractionState {
  if (!(visualName in state.selections)) return state
  const selections = { ...state.selections }
  delete selections[visualName]
  return { ...state, selections }
}

export function visualSelectionValues(
  visual: VisualSpec,
  current: InteractionState,
): (string | number)[] {
  return current.selections[visual.name] ?? []
}

export function isVisualActive(visual: VisualSpec, state: InteractionState): boolean {
  return Boolean(state.selections[visual.name]?.length)
}

export function isPageFiltered(state: InteractionState): boolean {
  return Object.values(state.selections).some((values) => values.length > 0)
}

function selectionToFilterClause(visual: VisualSpec, values: (string | number)[]): FilterClause | null {
  if (!values.length) return null
  if (visual.visual_type === 'slicer' && visual.slicer_target) {
    return { table: visual.slicer_target.table, column: visual.slicer_target.column, values }
  }
  if (visual.dim_keys.length) {
    const [table, column] = visual.dim_keys[0].split('.')
    if (table && column) return { table, column, values }
  }
  return null
}

function visualByName(page: PageSpec): Map<string, VisualSpec> {
  return new Map(page.visuals.map((visual) => [visual.name, visual]))
}

export function resolveVisualInteractions(
  page: PageSpec,
  graph: InteractionGraph,
  state: InteractionState,
): Record<string, VisualInteractionState> {
  const views: Record<string, VisualInteractionState> = Object.fromEntries(
    page.visuals.map((visual) => [
      visual.name,
      { active: false, highlighted: false, filtered: false, filters: [] as FilterClause[] },
    ]),
  )
  const byName = visualByName(page)

  for (const [sourceName, values] of Object.entries(state.selections)) {
    const source = byName.get(sourceName)
    if (!source || !values.length) continue
    const sourceFilter = selectionToFilterClause(source, values)
    if (!sourceFilter) continue
    const sourceView = views[sourceName]
    if (sourceView) sourceView.active = true

    for (const edge of graph.edges) {
      if (edge.from_visual !== sourceName) continue
      const target = views[edge.to_visual]
      if (!target) continue
      if (edge.mode === 'filter') {
        target.filtered = true
        target.highlighted = true
        target.filters.push(sourceFilter)
      } else if (edge.mode === 'highlight') {
        target.highlighted = true
      }
    }
  }

  return views
}

export function buildVisualQueryFilters(
  page: PageSpec,
  graph: InteractionGraph,
  state: InteractionState,
  slicerFilters: FilterClause[],
): Record<string, FilterClause[]> {
  const interactionViews = resolveVisualInteractions(page, graph, state)
  const byName: Record<string, FilterClause[]> = {}
  for (const visual of page.visuals) {
    byName[visual.name] = [...slicerFilters, ...interactionViews[visual.name].filters]
  }
  return byName
}
