"""Harness unit tests with a fake cursor; live goldens cover the real path."""

from pathlib import Path

import pytest

from app.parsers.bundle import load_pbip
from app.runtime.dashboard import compile_dashboard
from app.runtime.engine import SemanticEngine
from app.validation.harness import (
    CheckStatus,
    run_filter_probes,
    run_validation,
)

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


class FakeCursor:
    """Returns deterministic shapes: grouped rows for dim queries, scalars otherwise."""

    def __init__(self, fail_on: str | None = None, fanout: bool = False):
        self.fail_on = fail_on
        self.fanout = fanout
        self.description = []
        self._rows = []
        self.executed: list[str] = []

    def execute(self, sql: str):
        self.executed.append(sql)
        if self.fail_on and self.fail_on in sql:
            raise RuntimeError(f"fake failure on {self.fail_on}")
        import re

        # parse output columns from the final SELECT
        m = re.search(r"\nSELECT (.+)\nFROM", sql) or re.search(r"^SELECT (.+)\nFROM", sql)
        select = m.group(1) if m else ""
        cols = re.findall(r'AS "([^"]+)"', select)
        if not cols:
            cols = ["RESULT"]
        self.description = [(c,) for c in cols]
        dim_cols = [c for c in cols if "." in c and not c.startswith("__")]
        if dim_cols:
            rows = []
            for i in range(3):
                row = []
                for c in cols:
                    if c in dim_cols:
                        row.append("A" if (self.fanout and i > 0) else f"cat{i}")
                    else:
                        row.append(100.0)
                rows.append(tuple(row))
            self._rows = rows
        else:
            self._rows = [tuple(300.0 for _ in cols)]

    def fetchall(self):
        return self._rows

    def fetchone(self):
        return self._rows[0] if self._rows else None


@pytest.fixture(scope="module")
def spec_engine():
    bundle = load_pbip(FIXTURE)
    spec, bm = compile_dashboard(bundle)
    return spec, SemanticEngine(bundle.model, bm)


class TestHarness:
    def test_full_run_produces_scores(self, spec_engine):
        spec, engine = spec_engine
        report = run_validation(spec, engine, FakeCursor())
        assert len(report.pages) == 4
        assert report.summary()["visuals_total"] == 63
        assert 0 <= report.score <= 1

    def test_totals_reconcile_with_consistent_cursor(self, spec_engine):
        spec, engine = spec_engine
        # grouped rows: 3 x 100 = 300 = scalar total -> totals check passes
        report = run_validation(spec, engine, FakeCursor(), pages=["01-executive-summary"])
        donut = next(
            v for p in report.pages for v in p.visuals if v.visual == "p1donut"
        )
        totals = next(c for c in donut.checks if c.name == "totals")
        assert totals.status == CheckStatus.PASSED

    def test_execution_failure_scored(self, spec_engine):
        spec, engine = spec_engine
        report = run_validation(
            spec, engine, FakeCursor(fail_on="MV_MEDICAL_COST_SUMMARY"),
            pages=["01-executive-summary"],
        )
        failed = [v for p in report.pages for v in p.visuals if v.status == CheckStatus.FAILED]
        assert failed
        assert report.score < 1

    def test_duplicate_grain_detected(self, spec_engine):
        spec, engine = spec_engine
        report = run_validation(
            spec, engine, FakeCursor(fanout=True), pages=["01-executive-summary"]
        )
        donut = next(v for p in report.pages for v in p.visuals if v.visual == "p1donut")
        sanity = next(c for c in donut.checks if c.name == "sanity")
        assert sanity.status == CheckStatus.FAILED
        assert "duplicate grain" in sanity.detail

    def test_parity_check_flags_dropped_projections(self, spec_engine):
        spec, engine = spec_engine
        report = run_validation(spec, engine, FakeCursor(), pages=["03-provider-network"])
        tier_chart = next(v for p in report.pages for v in p.visuals if v.visual == "p3ctr")
        parity = next(c for c in tier_chart.checks if c.name == "parity")
        assert parity.status == CheckStatus.PASSED  # Series now consumed
        # substituted treemap reports its depth-trimmed fields without failing
        report2 = run_validation(spec, engine, FakeCursor(), pages=["02-cost-drivers"])
        tree = next(
            v
            for p in report2.pages
            for v in p.visuals
            if v.visual_type == "decompositionTreeVisual"
        )
        tree_parity = next(c for c in tree.checks if c.name == "parity")
        assert tree_parity.status == CheckStatus.SKIPPED
        assert "beyond drill depth" in tree_parity.detail

    def test_static_visuals_pass_trivially(self, spec_engine):
        spec, engine = spec_engine
        report = run_validation(spec, engine, FakeCursor(), pages=["01-executive-summary"])
        hdr = next(v for p in report.pages for v in p.visuals if v.visual == "p1hdr")
        assert hdr.status == CheckStatus.PASSED
        assert hdr.checks[0].detail == "static visual"

    def test_summary_shape(self, spec_engine):
        spec, engine = spec_engine
        report = run_validation(spec, engine, FakeCursor(), pages=["01-executive-summary"])
        s = report.summary()
        assert set(s) >= {
            "overall_score", "visuals_total", "visuals_passed", "visuals_failed",
            "substituted", "measures_tier01", "measures_parked", "pages",
        }
        assert s["measures_parked"] == 1  # Measures Above Benchmark

    def test_on_page_callback_fires_per_page(self, spec_engine):
        spec, engine = spec_engine
        seen: list[str] = []
        run_validation(spec, engine, FakeCursor(), on_page=lambda ps: seen.append(ps.page))
        assert seen == [p.name for p in spec.pages]


class TestFilterProbes:
    def test_probes_generated_and_reconcile(self, spec_engine):
        """FakeCursor returns consistent shapes (3x100 grouped = 300 scalar),
        so the partition property holds and probes pass."""
        spec, engine = spec_engine
        seen: list[str] = []
        probes = run_filter_probes(
            spec, engine, FakeCursor(), on_probe=lambda p: seen.append(p.page)
        )
        assert probes, "expected filter probes for pages with slicers + additive measures"
        # every probe passes or is explicitly skipped (dim unrelated to the fact)
        assert all(
            p.status in (CheckStatus.PASSED, CheckStatus.SKIPPED) for p in probes
        ), [(p.page, p.detail) for p in probes if p.status == CheckStatus.FAILED]
        assert any(p.status == CheckStatus.PASSED for p in probes)
        skipped = [p for p in probes if p.status == CheckStatus.SKIPPED]
        assert all("no relationship path" in p.detail for p in skipped)
        # every probe carries a concrete filter combination
        assert all(p.filters for p in probes)
        # pairwise combos exist (pages have >= 2 slicers)
        assert any(len(p.filters) >= 2 for p in probes)
        assert seen == [p.page for p in probes]

    def test_probe_failure_detected(self, spec_engine):
        """A cursor whose grouped rows do not sum to the scalar total must fail."""
        spec, engine = spec_engine

        class SkewedCursor(FakeCursor):
            def execute(self, sql: str):
                super().execute(sql)
                # skew scalar totals so slices no longer reconcile
                if self._rows and len(self._rows) == 1:
                    self._rows = [tuple(v * 7 if isinstance(v, float) else v for v in self._rows[0])]

        probes = run_filter_probes(spec, engine, SkewedCursor())
        assert probes
        assert any(p.status == CheckStatus.FAILED for p in probes)

    def test_probes_in_summary(self, spec_engine):
        spec, engine = spec_engine
        report = run_validation(spec, engine, FakeCursor(), pages=["01-executive-summary"])
        report.filter_probes = run_filter_probes(spec, engine, FakeCursor())
        s = report.summary()
        tested = [p for p in report.filter_probes if p.status != CheckStatus.SKIPPED]
        assert s["filter_probes_total"] == len(tested)
        assert s["filter_probes_passed"] <= s["filter_probes_total"]
        assert s["filter_probes_skipped"] == len(report.filter_probes) - len(tested)
