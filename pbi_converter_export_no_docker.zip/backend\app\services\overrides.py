"""Spec overrides: whitelisted, persisted patches applied on top of the
compiled DashboardSpec.

Remediations proposed for visual-parity findings are expressed in this
vocabulary; anything outside it is not automatable and the UI greys the
action out. Overrides never touch measure SQL or query semantics beyond
sort/limit — data correctness stays owned by the validation harness.
"""

from __future__ import annotations

import json
import time
from pathlib import Path

# op -> required params; the full automatable vocabulary
ALLOWED_OPS: dict[str, set[str]] = {
    "set_title": {"value"},
    "set_visual_type": {"value"},  # within the supported registry
    "set_measure_format": {"measure", "value"},
    "set_sort": {"key", "direction"},
    "set_limit": {"value"},
    "move_resize": set(),  # any of x/y/width/height
    "hide_visual": set(),
    "swap_series_role": {"column"},  # promote a dim to the series split
    "drop_measure": {"measure"},
    "drop_dimension": {"column"},
    "set_option": {"key", "value"},  # renderer options (whitelisted keys)
}

# renderer option keys settable via set_option -> allowed value type(s)
_OPTION_KEYS: dict[str, tuple[type, ...]] = {
    "waterfall_total": (bool,),
    "show_legend": (bool,),
    "show_labels": (bool,),
    "show_category_labels": (bool,),
    "show_totals": (bool,),
    "grid_vertical": (bool,),
    "column_headers_bold": (bool,),
    "legend_position": (str,),
    "axis_title": (str,),
    "label_color": (str,),
    "display_units": (int,),
    "axis_display_units": (int,),
    "label_precision": (int,),
    "axis_precision": (int,),
    "label_font_size": (int,),
    "legend_font_size": (int,),
    "values_font_size": (int,),
    "container_background": (dict,),
    "container_border": (dict,),
}

_SWITCHABLE_TYPES = {
    "barChart",
    "clusteredBarChart",
    "columnChart",
    "clusteredColumnChart",
    "lineChart",
    "areaChart",
    "donutChart",
    "pieChart",
    "waterfallChart",
}


class OverrideError(Exception):
    pass


def _file(conv_dir: Path) -> Path:
    return conv_dir / "spec_overrides.json"


def load_overrides(conv_dir: Path) -> list[dict]:
    f = _file(conv_dir)
    if not f.is_file():
        return []
    try:
        return json.loads(f.read_text(encoding="utf-8"))
    except ValueError:
        return []


def save_overrides(conv_dir: Path, overrides: list[dict]) -> None:
    _file(conv_dir).write_text(json.dumps(overrides, indent=2), encoding="utf-8")


def overrides_mtime(conv_dir: Path) -> float:
    f = _file(conv_dir)
    return f.stat().st_mtime if f.is_file() else 0.0


def validate_override(spec, override: dict) -> str | None:
    """Return an error string if the override is malformed/unsafe, else None."""
    op = override.get("op")
    if op not in ALLOWED_OPS:
        return f"op '{op}' not in the automatable vocabulary"
    missing = ALLOWED_OPS[op] - set(override)
    if missing:
        return f"missing params: {sorted(missing)}"
    page = next((p for p in spec.pages if p.name == override.get("page")), None)
    if page is None:
        return f"unknown page '{override.get('page')}'"
    vs = next((v for v in page.visuals if v.name == override.get("visual")), None)
    if vs is None:
        return f"unknown visual '{override.get('visual')}'"

    if op == "set_visual_type":
        if override["value"] not in _SWITCHABLE_TYPES:
            return f"cannot switch to '{override['value']}' (not a chart-family type)"
        if vs.visual_type not in _SWITCHABLE_TYPES:
            return f"cannot switch a '{vs.visual_type}' visual"
    if op == "set_measure_format" and override["measure"] not in vs.measure_keys:
        return f"measure '{override['measure']}' not on this visual"
    if op == "drop_measure":
        if override["measure"] not in vs.measure_keys:
            return f"measure '{override['measure']}' not on this visual"
        if len(vs.measure_keys) <= 1:
            return "cannot drop the only measure"
    if op in ("drop_dimension", "swap_series_role") and override.get("column") not in vs.dim_keys:
        return f"column '{override.get('column')}' not on this visual"
    if op == "set_sort" and override["key"] not in (vs.dim_keys + vs.measure_keys):
        return f"sort key '{override['key']}' not on this visual"
    if op == "set_limit" and not (
        isinstance(override["value"], int) and 1 <= override["value"] <= 10000
    ):
        return "limit must be an integer 1..10000"
    if op == "move_resize":
        if not any(k in override for k in ("x", "y", "width", "height")):
            return "move_resize needs at least one of x/y/width/height"
        # degenerate geometry destroys the visual (vision models sometimes emit zeros)
        for k in ("width", "height"):
            if k in override and (
                not isinstance(override[k], (int, float)) or override[k] < 16
            ):
                return f"move_resize {k} must be a number >= 16px"
        for k in ("x", "y"):
            if k in override and (
                not isinstance(override[k], (int, float))
                or override[k] < 0
                or override[k] > 10000
            ):
                return f"move_resize {k} must be within the page (0..10000)"
        # all-zero geometry = hallucinated no-op that would zero the visual
        provided = [k for k in ("x", "y", "width", "height") if k in override]
        if provided and all(not override[k] for k in provided):
            return "move_resize with all-zero geometry rejected"
    if op == "set_option":
        if override["key"] not in _OPTION_KEYS:
            return f"option '{override['key']}' not in {sorted(_OPTION_KEYS)}"
        expected = _OPTION_KEYS[override["key"]]
        value = override["value"]
        # bool is an int subclass; require exact type family
        if bool in expected:
            if not isinstance(value, bool):
                return f"option '{override['key']}' value must be a boolean"
        elif int in expected:
            if isinstance(value, bool) or not isinstance(value, int):
                return f"option '{override['key']}' value must be an integer"
        elif not isinstance(value, expected):
            return f"option '{override['key']}' value must be {expected[0].__name__}"
    return None


def apply_overrides(spec, overrides: list[dict]) -> list[str]:
    """Mutate the compiled spec in place; returns warnings for skipped items."""
    warnings: list[str] = []
    for o in overrides:
        err = validate_override(spec, o)
        if err:
            warnings.append(f"{o.get('op')}@{o.get('visual')}: {err}")
            continue
        page = next(p for p in spec.pages if p.name == o["page"])
        vs = next(v for v in page.visuals if v.name == o["visual"])
        op = o["op"]
        if op == "set_title":
            vs.title = str(o["value"])[:200]
        elif op == "set_visual_type":
            vs.visual_type = o["value"]
        elif op == "set_measure_format":
            vs.measure_formats[o["measure"]] = str(o["value"])[:80]
        elif op == "set_sort":
            vs.sort = [{"key": o["key"], "direction": o.get("direction", "Ascending")}]
            if vs.query is not None:
                vs.query.sort = vs.sort
        elif op == "set_limit":
            if vs.query is not None:
                vs.query.limit = o["value"]
        elif op == "move_resize":
            for k in ("x", "y", "width", "height"):
                if k in o and isinstance(o[k], (int, float)):
                    setattr(vs, k, float(o[k]))
        elif op == "hide_visual":
            vs.supported = False
            vs.unsupported_reason = "hidden by reviewer remediation"
        elif op == "swap_series_role":
            vs.series_keys = [o["column"]]
        elif op == "drop_measure":
            vs.measure_keys = [m for m in vs.measure_keys if m != o["measure"]]
            if vs.query is not None:
                vs.query.measures = [
                    m for m in vs.query.measures if (m.alias or m.name) != o["measure"]
                ]
        elif op == "drop_dimension":
            vs.dim_keys = [d for d in vs.dim_keys if d != o["column"]]
            vs.series_keys = [d for d in vs.series_keys if d != o["column"]]
            if vs.query is not None:
                vs.query.dimensions = [
                    d for d in vs.query.dimensions if f"{d.table}.{d.column}" != o["column"]
                ]
        elif op == "set_option":
            vs.options[o["key"]] = o["value"]
    return warnings


def add_override(conv_dir: Path, override: dict, finding_id: str | None = None) -> list[dict]:
    overrides = load_overrides(conv_dir)
    override = dict(override)
    override["applied_at"] = time.time()
    if finding_id:
        override["finding_id"] = finding_id
        # re-applying a fix for the same finding replaces the previous patch
        overrides = [o for o in overrides if o.get("finding_id") != finding_id]
    overrides.append(override)
    save_overrides(conv_dir, overrides)
    return overrides
