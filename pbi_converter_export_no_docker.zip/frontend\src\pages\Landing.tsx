import {
  ArrowRight,
  BadgeCheck,
  Bot,
  Code2,
  Gauge,
  LayoutDashboard,
  ShieldCheck,
} from 'lucide-react'
import { Link } from 'react-router-dom'
import { getToken } from '../auth'

const FEATURES = [
  {
    Icon: LayoutDashboard,
    title: 'Faithful conversion',
    body: 'Pages, visuals, DAX measures, filters and your report theme — compiled from .pbip into a spec-driven React dashboard.',
  },
  {
    Icon: BadgeCheck,
    title: 'Accuracy-gated',
    body: 'Every measure is executed against Snowflake and reconciled before delivery. A Migration Health report proves it.',
  },
  {
    Icon: Bot,
    title: 'Automatic repair',
    body: 'DAX outside the deterministic tier is translated by AI, execution-verified, and accepted only if the score never regresses.',
  },
  {
    Icon: Code2,
    title: 'Yours to keep',
    body: 'Download the generated React project — permissively licensed, builds standalone, runs on your infrastructure.',
  },
]

const STEPS = [
  { n: 1, t: 'Upload', d: 'Drop your .pbip project. The engine parses the semantic model, report layout and theme.' },
  { n: 2, t: 'Convert & validate', d: 'Your tables are matched to Snowflake, measures translated to SQL, and every visual verified numerically.' },
  { n: 3, t: 'Ship', d: 'Preview live, share the full-tab dashboard, download the code and the conversion report.' },
]

export function Landing() {
  const authed = !!getToken()
  return (
    <div className="aurora-bg grid-pattern relative min-h-screen overflow-hidden bg-surface-200">
      {/* aurora washes */}
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        <div className="absolute -top-32 -left-32 h-96 w-96 rounded-full bg-brand/15 blur-[100px]" />
        <div className="absolute top-40 right-0 h-80 w-80 rounded-full bg-brand-blue/10 blur-[100px]" />
        <div className="absolute bottom-0 left-1/3 h-72 w-72 rounded-full bg-brand-dark/10 blur-[100px]" />
      </div>

      <header className="relative flex items-center justify-between px-8 py-6">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand to-brand-dark text-sm font-extrabold text-white">
            P
          </div>
          <span className="text-lg font-bold">PBI Converter</span>
        </div>
        <nav className="flex items-center gap-3">
          {authed ? (
            <Link to="/app" className="btn-primary">
              Open app
            </Link>
          ) : (
            <>
              <Link to="/login" className="btn-secondary">
                Sign in
              </Link>
              <Link to="/login?mode=signup" className="btn-primary">
                Get started
              </Link>
            </>
          )}
        </nav>
      </header>

      <section className="relative mx-auto max-w-5xl px-8 pt-16 pb-20 text-center">
        <div className="kicker mb-4">Power BI → React · Verified against your warehouse</div>
        <h1 className="mb-6 text-5xl font-bold tracking-tight md:text-6xl">
          Your Power BI reports,
          <br />
          <span className="text-gradient">reborn as React</span> — provably correct.
        </h1>
        <p className="mx-auto mb-10 max-w-2xl text-lg text-surface-600">
          Upload a .pbip, connect your data warehouse, and get a production React dashboard whose
          every number is validated against source — with the audit report to prove it.
        </p>
        <div className="flex items-center justify-center gap-4">
          <Link to={authed ? '/app' : '/login?mode=signup'} className="btn-primary inline-flex items-center gap-2 px-6 py-3 text-base">
            Start a conversion
            <ArrowRight className="h-4 w-4" strokeWidth={2} />
          </Link>
          <a href="#how" className="btn-secondary px-6 py-3 text-base">
            How it works
          </a>
        </div>
        <div className="mt-10 flex items-center justify-center gap-6 text-xs text-surface-500">
          <span className="inline-flex items-center gap-1.5">
            <ShieldCheck className="h-4 w-4 text-brand-dark" strokeWidth={1.8} /> Numeric equivalence gate
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Gauge className="h-4 w-4 text-brand-dark" strokeWidth={1.8} /> Live &amp; accelerated modes
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Code2 className="h-4 w-4 text-brand-dark" strokeWidth={1.8} /> Full code hand-off
          </span>
        </div>
      </section>

      <section className="relative mx-auto grid max-w-6xl gap-5 px-8 pb-20 md:grid-cols-4">
        {FEATURES.map((f) => (
          <div key={f.title} className="card">
            <f.Icon className="mb-3 h-[22px] w-[22px] text-brand-dark" strokeWidth={1.8} />
            <div className="mb-1.5 font-bold">{f.title}</div>
            <div className="text-sm text-surface-600">{f.body}</div>
          </div>
        ))}
      </section>

      <section id="how" className="relative mx-auto max-w-6xl px-8 pb-24">
        <h2 className="mb-6 text-center text-2xl font-bold">How it works</h2>
        <div className="grid gap-5 md:grid-cols-3">
          {STEPS.map((s) => (
            <div key={s.n} className="card">
              <div className="mb-3 flex h-8 w-8 items-center justify-center rounded-full bg-brand font-bold text-white">
                {s.n}
              </div>
              <div className="mb-1 font-bold">{s.t}</div>
              <div className="text-sm text-surface-600">{s.d}</div>
            </div>
          ))}
        </div>
      </section>

      <footer className="relative border-t border-black/[0.06] px-8 py-6 text-center text-xs text-surface-500">
        PBI Converter · accuracy-gated Power BI modernization
      </footer>
    </div>
  )
}
