import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { act, render, screen } from '@testing-library/react'
import { beforeEach, describe, expect, it } from 'vitest'
import App from '../App'
import { useWizard } from '../store/wizard'

function renderApp() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <App />
    </QueryClientProvider>,
  )
}

describe('App wizard shell', () => {
  beforeEach(() => useWizard.getState().reset())

  it('starts on the upload step', () => {
    renderApp()
    expect(screen.getByText(/Upload your Power BI project/)).toBeInTheDocument()
  })

  it('moves to connect step after conversion is set', () => {
    renderApp()
    act(() => useWizard.getState().setConversion('abc-123'))
    expect(screen.getByText(/Where does the data live/)).toBeInTheDocument()
  })

  it('moves to analyze step after connection is set', () => {
    renderApp()
    act(() => {
      useWizard.getState().setConversion('abc-123')
      useWizard.getState().setConnection('conn-1')
    })
    expect(useWizard.getState().step).toBe('analyze')
  })
})

describe('wizard store', () => {
  beforeEach(() => useWizard.getState().reset())

  it('reset clears ids and returns to upload', () => {
    useWizard.getState().setConversion('x')
    useWizard.getState().setConnection('y')
    useWizard.getState().reset()
    const s = useWizard.getState()
    expect(s.step).toBe('upload')
    expect(s.conversionId).toBeNull()
    expect(s.connectionId).toBeNull()
  })
})
