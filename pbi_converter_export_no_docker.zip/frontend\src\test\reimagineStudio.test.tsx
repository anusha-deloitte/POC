import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { ReimagineStudio } from '../pages/ReimagineStudio'

const spec = {
  report_name: 'Demo',
  pages: [
    {
      name: 'p1',
      display_name: 'Overview',
      width: 1280,
      height: 400,
      ordinal: 0,
      visuals: [
        {
          name: 'kpi_1',
          visual_type: 'card',
          x: 4, y: 4, width: 200, height: 100, z: 0,
          title: 'Revenue',
          supported: true,
          query: { dimensions: [], measures: [], filters: [], sort: [] },
          dim_keys: [], column_keys: [], series_keys: [], dropped_fields: [],
          measure_keys: ['Revenue'], measure_roles: {}, measure_formats: {},
          slicer_target: null, static_content: {}, sort: [],
          options: { style_variant: 'reimagined' }, hierarchy: null,
        },
      ],
    },
  ],
  warnings: [],
  measure_tiers: {},
  theme: { data_colors: [] },
  interaction_graph: { nodes: [], edges: [], sync_groups: {} },
  bookmarks: [],
  drill_through: [],
  what_if_parameters: [],
}

const built = {
  spec,
  mapping: {
    conversion_id: 'c1',
    pages: ['p1'],
    entries: [
      {
        original: {
          page: 'p1', visual: 'kpi_1', type: 'card', title: 'Revenue',
          dims: [], measures: ['Revenue'], slicer_target: null, region: 'top-left',
        },
        reimagined: {
          visual: 'kpi_1', type: 'card', title: 'Revenue',
          dims: [], measures: ['Revenue'], region: 'top-left',
        },
        change_kind: 'restyle',
        rationale: 'KPI card restyled',
        information_delta: { missing: [], relocated: [], added: [] },
      },
    ],
  },
  zero_loss: {
    passed: true,
    coverage: { measures: '1/1', dimensions: '0/0', slicers: '0/0', filters: '0/0', visuals_mapped: '1' },
    gaps: [],
  },
}

beforeEach(() => {
  class ResizeObserverMock {
    observe() {}
    unobserve() {}
    disconnect() {}
  }
  vi.stubGlobal('ResizeObserver', ResizeObserverMock)
  vi.stubGlobal(
    'fetch',
    vi.fn(async (url: string) => {
      const u = String(url)
      if (u.includes('/reimagine/latest/built')) {
        return new Response(JSON.stringify(built), { status: 200 })
      }
      if (u.includes('/reimagine/latest')) {
        return new Response(
          JSON.stringify({
            id: 'rec1',
            status: 'proposed',
            intent_hypothesis: 'Used for revenue monitoring.',
            audience: 'executives',
            decision_questions: ['What changed in revenue?'],
            kpi_hierarchy: ['Revenue'],
            strategy: ['Lead with the outcome'],
            risks: [],
          }),
          { status: 200 },
        )
      }
      if (u.includes('/dashboard/spec')) {
        return new Response(JSON.stringify(spec), { status: 200 })
      }
      if (u.includes('/dashboard/query')) {
        return new Response(
          JSON.stringify({ results: [{ visual: 'kpi_1', columns: ['Revenue'], rows: [[42]], warnings: [], elapsed_ms: 1, cached: false }] }),
          { status: 200 },
        )
      }
      return new Response('{}', { status: 200 })
    }),
  )
})

function renderStudio() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <MemoryRouter initialEntries={['/reimagine/c1/conn1']}>
        <Routes>
          <Route path="/reimagine/:conversionId/:connectionId" element={<ReimagineStudio />} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>,
  )
}

describe('ReimagineStudio', () => {
  it('shows the zero-loss coverage bar and enables Accept when the gate passed', async () => {
    renderStudio()
    await waitFor(() => expect(screen.getByTestId('coverage-bar')).toBeInTheDocument())
    expect(screen.getByText(/Zero information loss/)).toBeInTheDocument()
    expect(screen.getByText('1/1')).toBeInTheDocument()
    const accept = await screen.findByRole('button', { name: /Accept reimagined design/ })
    await waitFor(() => expect(accept).toBeEnabled())
  })

  it('offers Original/Reimagined flip control and page tabs', async () => {
    renderStudio()
    expect(await screen.findByRole('button', { name: 'Original' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Reimagined' })).toBeInTheDocument()
    expect(await screen.findByRole('button', { name: 'Overview' })).toBeInTheDocument()
  })

  it('opens the design brief drawer with intent and KPI hierarchy', async () => {
    const user = userEvent.setup()
    renderStudio()
    const briefBtn = await screen.findByTestId('brief-button')
    await user.click(briefBtn)
    const drawer = await screen.findByTestId('brief-drawer')
    expect(drawer).toHaveTextContent('Used for revenue monitoring.')
    expect(drawer).toHaveTextContent('What changed in revenue?')
    expect(drawer).toHaveTextContent('Revenue')
  })
})
