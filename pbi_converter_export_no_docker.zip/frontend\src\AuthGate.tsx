import { useEffect, useState } from 'react'
import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { getToken, validateSession } from './auth'

export function AuthGate() {
  const location = useLocation()
  const [checked, setChecked] = useState(false)
  const [valid, setValid] = useState(false)

  useEffect(() => {
    let cancelled = false
    validateSession().then((user) => {
      if (!cancelled) {
        setValid(user !== null)
        setChecked(true)
      }
    })
    return () => {
      cancelled = true
    }
  }, [])

  if (!getToken()) return <Navigate to={`/login?next=${location.pathname}`} replace />
  if (!checked)
    return (
      <div className="flex min-h-screen items-center justify-center bg-surface-200 text-sm text-surface-500">
        Checking session…
      </div>
    )
  if (!valid) return <Navigate to={`/login?next=${location.pathname}`} replace />
  return <Outlet />
}
