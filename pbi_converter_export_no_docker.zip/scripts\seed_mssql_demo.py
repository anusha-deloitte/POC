#!/usr/bin/env python3
"""Seed the demo SQL Server (ClaimsDW) with the real report data from Snowflake.

Run inside the api container:
    docker exec pbi_converter-api-1 python /scripts/seed_mssql_demo.py

Pulls the 9 objects the medical report reads and writes them as dbo tables —
so the demo migration moves genuine data back into Snowflake's demo schema.
"""

from __future__ import annotations

import os
import sys

import pyodbc
import snowflake.connector

from app.core.config import get_settings
from app.services.connections import ConnectionStore

SNOWFLAKE_CONN_ID = "b26d1f23-864b-4c9c-bff1-de731efb956f"
SF_DB, SF_SCHEMA = "SNOWFLAKE_FINOPS_DASHBOARD__DB", "PBI_HEALTH_ANALYTICS"
MSSQL_DSN = (
    "DRIVER={ODBC Driver 18 for SQL Server};SERVER=mssql,1433;"
    f"UID=sa;PWD={os.environ['MSSQL_SA_PASSWORD']};TrustServerCertificate=yes;"
)
OBJECTS = [
    "DIM_LOB",
    "DIM_MONTH",
    "DIM_PROVIDER_TIER",
    "DIM_SERVICE_LINE_GROUP",
    "DIM_STATE",
    "DT_TOTAL_COST_OF_CARE",
    "FACT_QUALITY_MEASURE",
    "MV_MEDICAL_COST_SUMMARY",
    "REF_TARGET_PMPM",
]

# Snowflake type -> SQL Server DDL type
def mssql_type(sf_type: str, precision, scale) -> str:
    t = sf_type.upper()
    if t.startswith("NUMBER") or t in ("FIXED", "DECIMAL"):
        p = int(precision or 38)
        s = int(scale or 0)
        if p > 38:
            p = 38
        return f"DECIMAL({p},{s})"
    if t in ("FLOAT", "REAL", "DOUBLE"):
        return "FLOAT"
    if t.startswith("TIMESTAMP"):
        return "DATETIME2"
    if t == "DATE":
        return "DATE"
    if t == "TIME":
        return "TIME"
    if t == "BOOLEAN":
        return "BIT"
    return "NVARCHAR(1000)"


def main() -> int:
    s = get_settings()
    store = ConnectionStore(s.storage_dir, s.secrets_key_file)
    sf = snowflake.connector.connect(**store.connector_kwargs(SNOWFLAKE_CONN_ID))
    sf_cur = sf.cursor()

    ms = pyodbc.connect(MSSQL_DSN, autocommit=True)
    ms_cur = ms.cursor()
    ms_cur.execute("IF DB_ID('ClaimsDW') IS NULL CREATE DATABASE ClaimsDW")
    ms_cur.execute("USE ClaimsDW")

    for obj in OBJECTS:
        sf_cur.execute(f'DESCRIBE TABLE "{SF_DB}"."{SF_SCHEMA}"."{obj}"')
        cols = []
        for row in sf_cur.fetchall():
            name, sf_type = row[0], row[1]
            # DESCRIBE type looks like NUMBER(10,0) / VARCHAR(50) / DATE
            precision = scale = None
            m_num = None
            import re as _re

            m_num = _re.match(r"NUMBER\((\d+),(\d+)\)", sf_type)
            if m_num:
                precision, scale = m_num.group(1), m_num.group(2)
            cols.append((name, mssql_type(sf_type, precision, scale)))

        ms_cur.execute(f"IF OBJECT_ID('dbo.{obj}') IS NOT NULL DROP TABLE dbo.{obj}")
        ddl_cols = ", ".join(f"[{c}] {t}" for c, t in cols)
        ms_cur.execute(f"CREATE TABLE dbo.{obj} ({ddl_cols})")

        sf_cur.execute(f'SELECT * FROM "{SF_DB}"."{SF_SCHEMA}"."{obj}"')
        placeholders = ", ".join(["?"] * len(cols))
        insert = f"INSERT INTO dbo.{obj} VALUES ({placeholders})"
        ms_cur.fast_executemany = True
        total = 0
        while True:
            rows = sf_cur.fetchmany(20_000)
            if not rows:
                break
            ms_cur.executemany(insert, [tuple(r) for r in rows])
            total += len(rows)
            print(f"{obj}: {total:,} rows", flush=True)
        print(f"{obj}: DONE {total:,} rows", flush=True)

    ms_cur.execute(
        "SELECT t.name, SUM(p.rows) FROM sys.tables t "
        "JOIN sys.partitions p ON t.object_id=p.object_id AND p.index_id IN (0,1) "
        "GROUP BY t.name ORDER BY t.name"
    )
    print("\nClaimsDW final state:")
    for name, n in ms_cur.fetchall():
        print(f"  dbo.{name}: {n:,}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
