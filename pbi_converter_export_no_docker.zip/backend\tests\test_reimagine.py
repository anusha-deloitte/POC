from app.agents.reimagine import (
    build_recommendation,
    latest_recommendation,
    load_snapshot,
    list_recommendations,
    save_snapshot,
    save_recommendation,
    update_recommendation_status,
)
from decimal import Decimal
from app.runtime.dashboard import DashboardSpec, PageSpec, VisualSpec


def _spec() -> DashboardSpec:
    return DashboardSpec(
        report_name='Demo Report',
        pages=[
            PageSpec(
                name='page_1',
                display_name='Overview',
                width=1200,
                height=800,
                ordinal=0,
                visuals=[
                    VisualSpec(
                        name='kpi_1',
                        visual_type='card',
                        x=0,
                        y=0,
                        width=240,
                        height=120,
                        z=0,
                        title='Revenue',
                    ),
                    VisualSpec(
                        name='chart_1',
                        visual_type='clusteredColumnChart',
                        x=0,
                        y=140,
                        width=500,
                        height=280,
                        z=1,
                        title='Revenue by Segment',
                    ),
                    VisualSpec(
                        name='table_1',
                        visual_type='tableEx',
                        x=520,
                        y=140,
                        width=600,
                        height=280,
                        z=2,
                        title='Top Accounts',
                    ),
                ],
            )
        ],
    )


def test_build_recommendation_creates_page_concepts(tmp_path):
    recommendation = build_recommendation(_spec(), 'conv-1')

    assert recommendation.status == 'draft'
    assert recommendation.build_message == 'Build Coming Soon'
    assert recommendation.pages[0].template == 'executive-summary'
    assert recommendation.pages[0].blocks
    assert recommendation.web_story_modules
    assert recommendation.web_story_modules[0].layout_pattern

    saved = save_recommendation(tmp_path, recommendation)
    assert latest_recommendation(tmp_path).id == saved.id
    assert len(list_recommendations(tmp_path)) == 1


def test_recommendation_status_updates_are_persisted(tmp_path):
    recommendation = save_recommendation(tmp_path, build_recommendation(_spec(), 'conv-2'))
    updated = update_recommendation_status(tmp_path, recommendation.id, 'approved', 'looks good')

    assert updated is not None
    assert updated.status == 'approved'
    assert updated.decisions[-1]['note'] == 'looks good'
    assert latest_recommendation(tmp_path).status == 'approved'


def test_snapshot_persistence_and_quality_metadata(tmp_path):
    snapshot_meta = save_snapshot(
        tmp_path,
        {
            'connection_id': 'conn-1',
            'mode': 'live',
            'results': [
                {
                    'page': 'page_1',
                    'visual': 'kpi_1',
                    'columns': ['Revenue'],
                    'rows': [[1250]],
                }
            ],
        },
    )
    saved_snapshot = load_snapshot(tmp_path, snapshot_meta.id)
    assert saved_snapshot is not None
    assert saved_snapshot['meta']['connection_id'] == 'conn-1'

    recommendation = build_recommendation(
        _spec(),
        'conv-3',
        snapshot=saved_snapshot,
        snapshot_meta=snapshot_meta,
    )
    assert recommendation.snapshot is not None
    assert recommendation.snapshot.id == snapshot_meta.id
    assert recommendation.quality.evidence_count >= 1
    assert recommendation.quality.coverage >= 0


def test_quality_gate_marks_unsupported_intents_when_snapshot_missing():
    recommendation = build_recommendation(_spec(), 'conv-4', snapshot={'results': []})

    assert recommendation.quality.unsupported_intents > 0
    assert 'unsupported_intents_present' in recommendation.quality.failures
    assert recommendation.quality.ready is False


def test_snapshot_serializes_decimal_values(tmp_path):
    snapshot_meta = save_snapshot(
        tmp_path,
        {
            'connection_id': 'conn-1',
            'mode': 'live',
            'results': [
                {
                    'page': 'page_1',
                    'visual': 'kpi_1',
                    'columns': ['Revenue'],
                    'rows': [[Decimal('1234.56')]],
                }
            ],
        },
    )

    payload = load_snapshot(tmp_path, snapshot_meta.id)
    assert payload is not None
    assert payload['results'][0]['rows'][0][0] == 1234.56
