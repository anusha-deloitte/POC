"""Compile DAX AST -> Metric Algebra (Tier 0/1).

A measure compiles to LEAF AGGREGATES + a scalar COMBINER:

    Volume Effect =
        VAR PriorUnitCost = CALCULATE(DIVIDE([Allowed], [Lines]), SPLY(...))
        VAR CurLines  = [Lines]
        VAR PriorLines = CALCULATE([Lines], SPLY(...))
        RETURN (CurLines - PriorLines) * PriorUnitCost

    leaves:  __m0 = SUM(ALLOWED)  ctx={shift: sply}
             __m1 = COUNT(LINES)  ctx={shift: sply}
             __m2 = COUNT(LINES)  ctx={}
    expr:    ((__m2) - (__m1)) * (IFF(__m1=0 OR __m1 IS NULL, NULL, __m0/__m1))

Each leaf is evaluated by the semantic runtime as its own aggregate over its
own filter/time context (same GROUP BY keys), then combined — the only way
measures mixing shifted and unshifted terms produce correct numbers.

Fidelity: DIVIDE -> IFF(den=0 OR NULL, alt, num/den); BLANK() -> NULL.
Anything outside the tier-1 surface raises DaxUnsupported (-> tier 2 queue).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.dax.parser import (
    BinOp,
    Blank,
    Bool,
    ColumnRef,
    DaxParseError,
    FuncCall,
    MeasureRef,
    Num,
    Str,
    TableRef,
    UnaryOp,
    VarExpr,
    VarRef,
    parse_dax,
)
from app.ir.model import SemanticModel, SummarizeBy


class DaxUnsupported(Exception):
    """Measure needs Tier 2 (LLM) or human authoring."""


@dataclass(frozen=True)
class FilterPredicate:
    table: str
    sql: str


@dataclass(frozen=True)
class TimeShift:
    kind: str  # sply | rolling | ytd
    date_table: str
    date_column: str
    n: int = 0
    unit: str = "month"


@dataclass(frozen=True)
class WindowAvg:
    """AVERAGEX(DATESINPERIOD(...), [M]): average of the measure evaluated
    per period — avg-of-ratios, not ratio-of-sums."""

    measure: str
    date_table: str
    date_column: str
    n: int
    unit: str = "month"


@dataclass(frozen=True)
class Context:
    """Filter context a leaf aggregate is evaluated under."""

    filters: tuple[FilterPredicate, ...] = ()
    clears: frozenset = frozenset()
    time_shift: TimeShift | None = None
    # (from_table.from_col, to_table.to_col) pairs activated by USERELATIONSHIP
    use_relationships: tuple[tuple[str, str], ...] = ()

    def with_filter(self, p: FilterPredicate) -> Context:
        return Context(self.filters + (p,), self.clears, self.time_shift, self.use_relationships)

    def with_clear(self, table: str) -> Context:
        return Context(self.filters, self.clears | {table}, self.time_shift, self.use_relationships)

    def with_shift(self, s: TimeShift) -> Context:
        if self.time_shift is not None and self.time_shift != s:
            raise DaxUnsupported("nested conflicting time shifts")
        return Context(self.filters, self.clears, s, self.use_relationships)

    def with_relationship(self, pair: tuple[str, str]) -> Context:
        return Context(
            self.filters, self.clears, self.time_shift, self.use_relationships + (pair,)
        )


@dataclass
class Leaf:
    sql: str  # aggregate expression, e.g. SUM("T"."C")
    tables: set[str]
    ctx: Context


@dataclass
class CompiledMeasure:
    name: str
    expr: str  # scalar SQL combining leaf aliases (__m0, __m1, ...)
    leaves: dict[str, Leaf] = field(default_factory=dict)
    window_avg: WindowAvg | None = None  # set => engine evaluates via window fn
    tier: int = 1

    @property
    def tables(self) -> set[str]:
        out: set[str] = set()
        for leaf in self.leaves.values():
            out |= leaf.tables
        return out


_SIMPLE_AGGS = {
    "SUM": "SUM({})",
    "MIN": "MIN({})",
    "MAX": "MAX({})",
    "AVERAGE": "AVG({})",
    "COUNTA": "COUNT({})",
    "COUNT": "COUNT({})",
    "DISTINCTCOUNT": "COUNT(DISTINCT {})",
}

_TIME_UNITS = ("day", "month", "quarter", "year")


_IDENT_OK_RE = re.compile(r"^[A-Za-z0-9_$. -]+$")


def qcol(table: str, column: str) -> str:
    for part in (table, column):
        if not _IDENT_OK_RE.match(part) or '"' in part:
            raise DaxUnsupported(f"unsafe identifier: {part!r}")
    return f'"{table}"."{column}"'


def _num_value(node) -> int | None:
    if isinstance(node, Num):
        return int(node.value)
    if isinstance(node, UnaryOp) and node.op == "-" and isinstance(node.operand, Num):
        return -int(node.operand.value)
    return None


def _unit_value(node) -> str | None:
    name = getattr(node, "name", None)
    name = name.lower() if isinstance(name, str) else None
    return name if name in _TIME_UNITS else None


class MeasureCompiler:
    def __init__(self, model: SemanticModel):
        self.model = model
        self._table_names = {t.name for t in model.tables}

    # -- public ---------------------------------------------------------

    def compile_measure(self, name: str) -> CompiledMeasure:
        out = CompiledMeasure(name=name, expr="")
        out.expr = self._measure_body(name, Context(), out, stack=())
        return out

    def compile_implicit(self, table: str, column: str, aggregate: str | None) -> CompiledMeasure:
        """Tier 0: bare column + summarization in a visual."""
        col = self.model.table(table).column(column) if self.model.table(table) else None
        agg = (aggregate or "").upper()
        if not agg and col is not None:
            agg = {
                SummarizeBy.SUM: "SUM",
                SummarizeBy.MIN: "MIN",
                SummarizeBy.MAX: "MAX",
                SummarizeBy.AVERAGE: "AVERAGE",
                SummarizeBy.COUNT: "COUNT",
                SummarizeBy.DISTINCT_COUNT: "DISTINCTCOUNT",
            }.get(col.summarize_by, "")
        tpl = _SIMPLE_AGGS.get({"AVG": "AVERAGE", "COUNTNONNULL": "COUNT"}.get(agg, agg))
        if tpl is None:
            raise DaxUnsupported(f"no implicit aggregate for {table}[{column}] ({agg or 'none'})")
        out = CompiledMeasure(name=f"{table}.{column}", expr="", tier=0)
        out.expr = self._add_leaf(out, tpl.format(qcol(table, column)), {table}, Context())
        return out

    # -- internals ------------------------------------------------------

    def _measure_body(self, name: str, ctx: Context, out: CompiledMeasure, stack) -> str:
        if name in stack:
            raise DaxUnsupported(f"measure cycle: {' -> '.join(stack)} -> {name}")
        found = self.model.find_measure(name)
        if found is None:
            raise DaxUnsupported(f"unknown measure [{name}]")
        _, measure = found
        try:
            ast = parse_dax(measure.expression)
        except DaxParseError as e:
            raise DaxUnsupported(str(e)) from e
        return self._scalar(ast, ctx, out, stack + (name,), {})

    def _add_leaf(self, out: CompiledMeasure, sql: str, tables: set[str], ctx: Context) -> str:
        for alias, leaf in out.leaves.items():  # dedup identical leaves
            if leaf.sql == sql and leaf.ctx == ctx:
                leaf.tables |= tables
                return alias
        alias = f"__m{len(out.leaves)}"
        out.leaves[alias] = Leaf(sql=sql, tables=set(tables), ctx=ctx)
        return alias

    def _as_table(self, node):
        if isinstance(node, TableRef):
            return node
        if isinstance(node, VarRef) and node.name in self._table_names:
            return TableRef(node.name)
        return None

    # scalar position: combiner expression referencing leaf aliases
    def _scalar(self, node, ctx: Context, out: CompiledMeasure, stack, scope) -> str:
        match node:
            case Num(value=v):
                return str(int(v)) if v == int(v) else repr(v)
            case Str(value=s):
                return "'" + s.replace("'", "''") + "'"
            case Bool(value=b):
                return "TRUE" if b else "FALSE"
            case Blank():
                return "NULL"
            case MeasureRef(name=n):
                return f"({self._measure_body(n, ctx, out, stack)})"
            case VarRef(name=n):
                if n in scope:
                    return scope[n]
                raise DaxUnsupported(f"unknown identifier {n}")
            case VarExpr(bindings=bindings, body=body):
                local = dict(scope)
                for var_name, var_ast in bindings:
                    local[var_name] = f"({self._scalar(var_ast, ctx, out, stack, local)})"
                return self._scalar(body, ctx, out, stack, local)
            case UnaryOp(op="-", operand=o):
                return f"(-{self._scalar(o, ctx, out, stack, scope)})"
            case UnaryOp(op="NOT", operand=o):
                return f"(NOT {self._scalar(o, ctx, out, stack, scope)})"
            case BinOp(op=op, left=left, right=right):
                ls = self._scalar(left, ctx, out, stack, scope)
                rs = self._scalar(right, ctx, out, stack, scope)
                sql_op = {"=": "=", "<>": "<>", "&&": "AND", "||": "OR", "&": "||"}.get(op, op)
                return f"({ls} {sql_op} {rs})"
            case ColumnRef(table=t, column=c):
                raise DaxUnsupported(f"bare column {t}[{c}] in scalar context (needs row context)")
            case FuncCall():
                return self._scalar_func(node, ctx, out, stack, scope)
        raise DaxUnsupported(f"unsupported node {node!r}")

    def _scalar_func(self, node: FuncCall, ctx, out, stack, scope) -> str:
        fname, args = node.name, node.args

        if fname in _SIMPLE_AGGS:
            if len(args) != 1 or not isinstance(args[0], ColumnRef):
                raise DaxUnsupported(f"{fname} expects a single column reference")
            sql = _SIMPLE_AGGS[fname].format(qcol(args[0].table, args[0].column))
            return self._add_leaf(out, sql, {args[0].table}, ctx)

        match fname:
            case "COUNTROWS":
                tref = self._as_table(args[0]) if len(args) == 1 else None
                if tref is None:
                    raise DaxUnsupported("COUNTROWS expects a table reference")
                return self._add_leaf(out, "COUNT(*)", {tref.name}, ctx)

            case "SUMX" | "AVERAGEX" | "MINX" | "MAXX":
                return self._iterator(fname, args, ctx, out, stack, scope)

            case "DIVIDE":
                if len(args) not in (2, 3):
                    raise DaxUnsupported("DIVIDE expects 2 or 3 arguments")
                num = self._scalar(args[0], ctx, out, stack, scope)
                den = self._scalar(args[1], ctx, out, stack, scope)
                alt = self._scalar(args[2], ctx, out, stack, scope) if len(args) == 3 else "NULL"
                return f"IFF(({den}) = 0 OR ({den}) IS NULL, {alt}, ({num}) / ({den}))"

            case "IF":
                if len(args) not in (2, 3):
                    raise DaxUnsupported("IF expects 2 or 3 arguments")
                cond = self._scalar(args[0], ctx, out, stack, scope)
                then = self._scalar(args[1], ctx, out, stack, scope)
                alt = self._scalar(args[2], ctx, out, stack, scope) if len(args) == 3 else "NULL"
                return f"IFF({cond}, {then}, {alt})"

            case "ISBLANK":
                return f"(({self._scalar(args[0], ctx, out, stack, scope)}) IS NULL)"

            case "COALESCE":
                parts = ", ".join(self._scalar(a, ctx, out, stack, scope) for a in args)
                return f"COALESCE({parts})"

            case "ABS" | "SQRT" | "EXP" | "LN" | "FLOOR":
                return f"{fname}({self._scalar(args[0], ctx, out, stack, scope)})"
            case "CEILING":
                return f"CEIL({self._scalar(args[0], ctx, out, stack, scope)})"
            case "ROUND":
                inner = self._scalar(args[0], ctx, out, stack, scope)
                digits = self._scalar(args[1], ctx, out, stack, scope) if len(args) > 1 else "0"
                return f"ROUND({inner}, {digits})"

            case "SWITCH":
                return self._switch(args, ctx, out, stack, scope)

            case "SELECTEDVALUE":
                # SELECTEDVALUE(col [, default]) -> IFF(COUNT(DISTINCT col)=1, MAX(col), default)
                if not args or not isinstance(args[0], ColumnRef):
                    raise DaxUnsupported("SELECTEDVALUE expects a column reference")
                col_sql = qcol(args[0].table, args[0].column)
                default_sql = self._scalar(args[1], ctx, out, stack, scope) if len(args) > 1 else "NULL"
                count_alias = self._add_leaf(out, f"COUNT(DISTINCT {col_sql})", {args[0].table}, ctx)
                max_alias = self._add_leaf(out, f"MAX({col_sql})", {args[0].table}, ctx)
                return f"IFF(({count_alias}) = 1, ({max_alias}), {default_sql})"

            case "HASONEVALUE":
                if not args or not isinstance(args[0], ColumnRef):
                    raise DaxUnsupported("HASONEVALUE expects a column reference")
                col_sql = qcol(args[0].table, args[0].column)
                count_alias = self._add_leaf(out, f"COUNT(DISTINCT {col_sql})", {args[0].table}, ctx)
                return f"(({count_alias}) = 1)"

            case "VALUES":
                # VALUES(table[col]) in scalar context → MAX of that column
                if not args or not isinstance(args[0], ColumnRef):
                    raise DaxUnsupported("VALUES in scalar context requires a column ref")
                col_sql = qcol(args[0].table, args[0].column)
                return self._add_leaf(out, f"MAX({col_sql})", {args[0].table}, ctx)

            case "ALLSELECTED":
                # ALLSELECTED in scalar context: compile inner measure without the clear
                if args:
                    return self._scalar(args[0], ctx.with_clear("*"), out, stack, scope)
                raise DaxUnsupported("ALLSELECTED() with no args not supported in tier-1")

            case "RANKX":
                return self._rankx(args, ctx, out, stack, scope)

            case "CONCATENATEX":
                raise DaxUnsupported("CONCATENATEX not in tier-1 (use tier-2)")

            case "FORMAT":
                # FORMAT(value, format_string) -> TO_VARCHAR in simple cases
                if len(args) >= 1:
                    return f"TO_VARCHAR({self._scalar(args[0], ctx, out, stack, scope)})"
                raise DaxUnsupported("FORMAT with no args")

            case "YEAR" | "MONTH" | "DAY" | "HOUR" | "MINUTE" | "SECOND":
                if not args:
                    raise DaxUnsupported(f"{fname} needs an argument")
                return f"{fname}({self._scalar(args[0], ctx, out, stack, scope)})"

            case "QUARTER":
                if not args:
                    raise DaxUnsupported("QUARTER needs an argument")
                return f"QUARTER({self._scalar(args[0], ctx, out, stack, scope)})"

            case "WEEKDAY":
                if not args:
                    raise DaxUnsupported("WEEKDAY needs an argument")
                return f"DAYOFWEEK({self._scalar(args[0], ctx, out, stack, scope)})"

            case "WEEKNUM":
                if not args:
                    raise DaxUnsupported("WEEKNUM needs an argument")
                return f"WEEKOFYEAR({self._scalar(args[0], ctx, out, stack, scope)})"

            case "LEFT":
                s = self._scalar(args[0], ctx, out, stack, scope)
                n = self._scalar(args[1], ctx, out, stack, scope) if len(args) > 1 else "1"
                return f"LEFT({s}, {n})"

            case "RIGHT":
                s = self._scalar(args[0], ctx, out, stack, scope)
                n = self._scalar(args[1], ctx, out, stack, scope) if len(args) > 1 else "1"
                return f"RIGHT({s}, {n})"

            case "MID":
                s = self._scalar(args[0], ctx, out, stack, scope)
                start = self._scalar(args[1], ctx, out, stack, scope)
                length = self._scalar(args[2], ctx, out, stack, scope) if len(args) > 2 else "NULL"
                return f"SUBSTR({s}, {start}, {length})"

            case "LEN":
                return f"LENGTH({self._scalar(args[0], ctx, out, stack, scope)})"

            case "UPPER":
                return f"UPPER({self._scalar(args[0], ctx, out, stack, scope)})"

            case "LOWER":
                return f"LOWER({self._scalar(args[0], ctx, out, stack, scope)})"

            case "TRIM":
                return f"TRIM({self._scalar(args[0], ctx, out, stack, scope)})"

            case "CONCATENATE":
                if len(args) != 2:
                    raise DaxUnsupported("CONCATENATE expects 2 args")
                left = self._scalar(args[0], ctx, out, stack, scope)
                right = self._scalar(args[1], ctx, out, stack, scope)
                return f"({left} || {right})"

            case "SUBSTITUTE":
                s = self._scalar(args[0], ctx, out, stack, scope)
                old = self._scalar(args[1], ctx, out, stack, scope)
                new = self._scalar(args[2], ctx, out, stack, scope)
                return f"REPLACE({s}, {old}, {new})"

            case "VALUE":
                return f"TRY_CAST({self._scalar(args[0], ctx, out, stack, scope)} AS NUMBER)"

            case "TEXT":
                return f"TO_VARCHAR({self._scalar(args[0], ctx, out, stack, scope)})"

            case "DATE":
                y = self._scalar(args[0], ctx, out, stack, scope)
                m = self._scalar(args[1], ctx, out, stack, scope)
                d = self._scalar(args[2], ctx, out, stack, scope)
                return f"DATE_FROM_PARTS({y}, {m}, {d})"

            case "TODAY":
                return "CURRENT_DATE()"

            case "NOW":
                return "CURRENT_TIMESTAMP()"

            case "EOMONTH":
                dt = self._scalar(args[0], ctx, out, stack, scope)
                n = self._scalar(args[1], ctx, out, stack, scope) if len(args) > 1 else "0"
                return f"LAST_DAY(DATEADD(month, {n}, {dt}))"

            case "MAX" if len(args) == 2:
                # MAX(a, b) scalar form → GREATEST
                a = self._scalar(args[0], ctx, out, stack, scope)
                b = self._scalar(args[1], ctx, out, stack, scope)
                return f"GREATEST({a}, {b})"

            case "MIN" if len(args) == 2:
                # MIN(a, b) scalar form → LEAST
                a = self._scalar(args[0], ctx, out, stack, scope)
                b = self._scalar(args[1], ctx, out, stack, scope)
                return f"LEAST({a}, {b})"

            case "TOTALYTD":
                if len(args) != 2 or not isinstance(args[1], ColumnRef):
                    raise DaxUnsupported("TOTALYTD(expr, date_col) only")
                shift = TimeShift("ytd", args[1].table, args[1].column)
                return self._scalar(args[0], ctx.with_shift(shift), out, stack, scope)

            case "CALCULATE":
                return self._calculate(args, ctx, out, stack, scope)

            case _:
                raise DaxUnsupported(f"function {fname} not in tier-1 set")

    def _iterator(self, fname, args, ctx, out, stack, scope) -> str:
        if len(args) != 2:
            raise DaxUnsupported(f"{fname} expects 2 arguments")
        # AVERAGEX(DATESINPERIOD(date, MAX(date), -n, unit), [M]) = rolling mean
        if (
            fname == "AVERAGEX"
            and isinstance(args[0], FuncCall)
            and args[0].name == "DATESINPERIOD"
            and isinstance(args[1], MeasureRef)
        ):
            if ctx != Context() or out.leaves or out.window_avg:
                raise DaxUnsupported("windowed AVERAGEX must be the whole measure")
            shift = self._parse_datesinperiod(args[0].args)
            out.window_avg = WindowAvg(
                measure=args[1].name,
                date_table=shift.date_table,
                date_column=shift.date_column,
                n=shift.n,
                unit=shift.unit,
            )
            return "__WINDOW__"  # placeholder; engine replaces the whole measure
        tref = self._as_table(args[0])
        if tref is None:
            raise DaxUnsupported(f"{fname} supported only over a base table")
        body = self._row_expr(args[1], tref.name)
        agg = {"SUMX": "SUM", "AVERAGEX": "AVG", "MINX": "MIN", "MAXX": "MAX"}[fname]
        return self._add_leaf(out, f"{agg}({body})", {tref.name}, ctx)

    def _row_expr(self, node, base_table: str) -> str:
        """Row-context expression inside an iterator/filter: columns only."""
        match node:
            case Num(value=v):
                return str(int(v)) if v == int(v) else repr(v)
            case Str(value=s):
                return "'" + s.replace("'", "''") + "'"
            case Blank():
                return "NULL"
            case Bool(value=b):
                return "TRUE" if b else "FALSE"
            case ColumnRef(table=t, column=c):
                return qcol(t, c)
            case UnaryOp(op="-", operand=o):
                return f"(-{self._row_expr(o, base_table)})"
            case UnaryOp(op="NOT", operand=o):
                return f"(NOT {self._row_expr(o, base_table)})"
            case BinOp(op=op, left=left, right=right):
                sql_op = {"=": "=", "<>": "<>", "&&": "AND", "||": "OR", "&": "||"}.get(op, op)
                lhs = self._row_expr(left, base_table)
                rhs = self._row_expr(right, base_table)
                return f"({lhs} {sql_op} {rhs})"
            case FuncCall(name="DIVIDE", args=(a, b)):
                num, den = self._row_expr(a, base_table), self._row_expr(b, base_table)
                return f"IFF(({den}) = 0 OR ({den}) IS NULL, NULL, ({num}) / ({den}))"
            case FuncCall(name="IF", args=fargs) if len(fargs) in (2, 3):
                cond = self._row_expr(fargs[0], base_table)
                then = self._row_expr(fargs[1], base_table)
                alt = self._row_expr(fargs[2], base_table) if len(fargs) == 3 else "NULL"
                return f"IFF({cond}, {then}, {alt})"
            case FuncCall(name=fname, args=fargs) if fname in (
                "YEAR", "MONTH", "DAY", "HOUR", "MINUTE", "SECOND", "QUARTER"
            ):
                return f"{fname}({self._row_expr(fargs[0], base_table)})"
            case FuncCall(name="UPPER" | "LOWER" | "TRIM" | "LEN" | "LEFT" | "RIGHT", args=fargs):
                fn_map = {"LEN": "LENGTH", "LEFT": "LEFT", "RIGHT": "RIGHT"}
                sf_name = fn_map.get(node.name, node.name)
                inner_args = ", ".join(self._row_expr(a, base_table) for a in fargs)
                return f"{sf_name}({inner_args})"
            case FuncCall(name="FORMAT" | "TEXT", args=fargs):
                return f"TO_VARCHAR({self._row_expr(fargs[0], base_table)})"
            case FuncCall(name="SWITCH", args=fargs):
                # SWITCH(TRUE(), cond, val, ...) in row context
                if fargs and isinstance(fargs[0], Bool) and fargs[0].value:
                    rest = list(fargs[1:])
                    default = "NULL"
                    if len(rest) % 2 == 1:
                        default = self._row_expr(rest.pop(), base_table)
                    cases = " ".join(
                        f"WHEN {self._row_expr(rest[i], base_table)} "
                        f"THEN {self._row_expr(rest[i+1], base_table)}"
                        for i in range(0, len(rest), 2)
                    )
                    return f"(CASE {cases} ELSE {default} END)"
                subj = self._row_expr(fargs[0], base_table)
                rest = list(fargs[1:])
                default = "NULL"
                if len(rest) % 2 == 1:
                    default = self._row_expr(rest.pop(), base_table)
                cases = " ".join(
                    f"WHEN {self._row_expr(rest[i], base_table)} "
                    f"THEN {self._row_expr(rest[i+1], base_table)}"
                    for i in range(0, len(rest), 2)
                )
                return f"(CASE {subj} {cases} ELSE {default} END)"
        raise DaxUnsupported(f"row expression not in tier-1 set: {node!r}")

    def _parse_datesinperiod(self, dip) -> TimeShift:
        if len(dip) != 4 or not isinstance(dip[0], ColumnRef):
            raise DaxUnsupported("DATESINPERIOD pattern not recognized")
        n, unit = _num_value(dip[2]), _unit_value(dip[3])
        if n is None or unit is None:
            raise DaxUnsupported("DATESINPERIOD pattern not recognized")
        return TimeShift("rolling", dip[0].table, dip[0].column, n=abs(n), unit=unit)

    def _calculate(self, args, ctx: Context, out, stack, scope) -> str:
        if not args:
            raise DaxUnsupported("empty CALCULATE")
        new_ctx = ctx
        for farg in args[1:]:
            match farg:
                case BinOp() as pred:
                    new_ctx = new_ctx.with_filter(self._predicate(pred))
                case FuncCall(name="KEEPFILTERS", args=(BinOp() as pred,)):
                    new_ctx = new_ctx.with_filter(self._predicate(pred))
                case FuncCall(name="FILTER", args=(tbl, pred)) if self._as_table(tbl):
                    new_ctx = new_ctx.with_filter(
                        self._predicate(pred, default_table=self._as_table(tbl).name)
                    )
                case FuncCall(name="ALL" | "REMOVEFILTERS", args=fargs):
                    if not fargs:
                        new_ctx = new_ctx.with_clear("*")
                    for fa in fargs:
                        if (t := self._as_table(fa)) is not None:
                            new_ctx = new_ctx.with_clear(t.name)
                        elif isinstance(fa, ColumnRef):
                            new_ctx = new_ctx.with_clear(fa.table)
                        else:
                            raise DaxUnsupported("ALL() over expressions unsupported")
                case FuncCall(name="SAMEPERIODLASTYEAR", args=(ColumnRef() as dcol,)):
                    new_ctx = new_ctx.with_shift(TimeShift("sply", dcol.table, dcol.column))
                case FuncCall(name="DATEADD", args=(ColumnRef() as dcol, n_node, unit_node)):
                    n, unit = _num_value(n_node), _unit_value(unit_node)
                    if (n, unit) in ((-12, "month"), (-1, "year")):
                        new_ctx = new_ctx.with_shift(TimeShift("sply", dcol.table, dcol.column))
                    else:
                        raise DaxUnsupported(f"DATEADD({n},{unit}) not in tier-1 set")
                case FuncCall(name="DATESINPERIOD", args=dip):
                    new_ctx = new_ctx.with_shift(self._parse_datesinperiod(dip))
                case FuncCall(
                    name="USERELATIONSHIP", args=(ColumnRef() as c1, ColumnRef() as c2)
                ):
                    new_ctx = new_ctx.with_relationship(
                        (f"{c1.table}.{c1.column}", f"{c2.table}.{c2.column}")
                    )
                case _:
                    raise DaxUnsupported(
                        f"CALCULATE modifier not in tier-1 set: {getattr(farg, 'name', farg)}"
                    )
        return self._scalar(args[0], new_ctx, out, stack, scope)

    def _predicate(self, pred, default_table: str | None = None) -> FilterPredicate:
        tables: set[str] = set()

        def walk(n):
            match n:
                case ColumnRef(table=t):
                    tables.add(t)
                case BinOp(left=left, right=right):
                    walk(left)
                    walk(right)
                case UnaryOp(operand=o):
                    walk(o)
                case FuncCall(args=fargs):
                    for a in fargs:
                        walk(a)
                case _:
                    pass

        walk(pred)
        if not tables and default_table:
            tables = {default_table}
        if len(tables) != 1:
            raise DaxUnsupported("filter predicate must reference exactly one table")
        table = next(iter(tables))
        return FilterPredicate(table=table, sql=self._row_expr(pred, table))

    def _switch(self, args, ctx, out, stack, scope) -> str:
        if len(args) < 3:
            raise DaxUnsupported("SWITCH expects at least 3 arguments")
        subject_node = args[0]
        rest = list(args[1:])
        default = "NULL"
        if len(rest) % 2 == 1:
            default = self._scalar(rest.pop(), ctx, out, stack, scope)
        # SWITCH(TRUE(), cond, val, ...) -> CASE WHEN cond THEN val ...
        if isinstance(subject_node, Bool) and subject_node.value:
            cases = " ".join(
                f"WHEN {self._scalar(rest[i], ctx, out, stack, scope)} "
                f"THEN {self._scalar(rest[i + 1], ctx, out, stack, scope)}"
                for i in range(0, len(rest), 2)
            )
            return f"(CASE {cases} ELSE {default} END)"
        # Standard SWITCH(expr, match, val, ...) -> CASE expr WHEN match THEN val ...
        subject = self._scalar(subject_node, ctx, out, stack, scope)
        cases = " ".join(
            f"WHEN {self._scalar(rest[i], ctx, out, stack, scope)} "
            f"THEN {self._scalar(rest[i + 1], ctx, out, stack, scope)}"
            for i in range(0, len(rest), 2)
        )
        return f"(CASE {subject} {cases} ELSE {default} END)"

    def _rankx(self, args, ctx, out, stack, scope) -> str:
        """RANKX(table, expr [, value, order, ties]) → RANK() OVER (ORDER BY expr).

        Supported patterns:
          RANKX(ALL(Table), [Measure])       → dense rank over all values
          RANKX(VALUES(Table[col]), [Measure]) → rank within current filter
        The result is a window function leaf.
        """
        if len(args) < 2:
            raise DaxUnsupported("RANKX expects at least 2 arguments")
        table_arg = args[0]
        expr_arg = args[1]
        order = "DESC"  # PBI default: rank 1 = largest
        if len(args) >= 4:
            order_node = args[3]
            if isinstance(order_node, Num) and order_node.value == 2:
                order = "ASC"
            elif isinstance(order_node, Str) and order_node.value.upper() == "ASC":
                order = "ASC"

        # Resolve the expression to an aggregate leaf
        inner = self._scalar(expr_arg, ctx, out, stack, scope)

        # Determine the table scope
        tref = None
        if isinstance(table_arg, FuncCall) and table_arg.name in ("ALL", "ALLSELECTED"):
            tref = self._as_table(table_arg.args[0]) if table_arg.args else None
        elif isinstance(table_arg, FuncCall) and table_arg.name == "VALUES":
            tref = (
                TableRef(table_arg.args[0].table)
                if table_arg.args and isinstance(table_arg.args[0], ColumnRef)
                else None
            )
        else:
            tref = self._as_table(table_arg)

        if tref is None:
            raise DaxUnsupported("RANKX table argument not recognized")

        # Emit as a window function: RANK() OVER (ORDER BY <inner_agg>)
        # We can't actually express this as a simple aggregate leaf; emit as a
        # tier-1.5 window expression. The engine handles it as a scalar combiner.
        window_sql = f"RANK() OVER (ORDER BY {inner} {order})"
        return self._add_leaf(out, window_sql, {tref.name}, ctx)
