import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { ReviewStep } from '../steps/ReviewStep'
import { useWizard } from '../store/wizard'

vi.mock('../steps/VisualParity', () => ({
  VisualParity: () => <div data-testid="visual-parity" />,
}))

const conversionId = '11111111-1111-1111-1111-111111111111'

function renderReviewStep() {
  const client = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
    },
  })
  return render(
    <QueryClientProvider client={client}>
      <ReviewStep />
    </QueryClientProvider>,
  )
}

beforeEach(() => {
  useWizard.setState({
    step: 'review',
    conversionId,
    connectionId: 'conn-1',
  })
  global.fetch = vi.fn(async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = String(input)
    if (url.includes('/dashboard/fidelity')) {
      return new Response(
        JSON.stringify({
          summary: {
            overall_score: 0.5,
            visuals_total: 1,
            visuals_passed: 0,
            visuals_failed: 1,
            substituted: 0,
            measures_tier01: 1,
            measures_parked: 0,
            pages: { page_1: 1 },
          },
          fidelity: {
            pages: [
              {
                page: 'page_1',
                display_name: 'Page 1',
                visuals: [
                  {
                    visual: 'visual_1',
                    page: 'page_1',
                    visual_type: 'card',
                    title: 'Revenue',
                    checks: [{ name: 'render', status: 'failed', detail: 'synthetic parity failure' }],
                    substituted_as: null,
                  },
                ],
              },
            ],
          },
        }),
        { status: 200 },
      )
    }
    if (url.endsWith(`/governance`)) {
      return new Response(
        JSON.stringify({
          summary: {
            model: {
              name: 'Model',
              version: 'v1',
              data_version: null,
              identity_execution_mode: 'service_account',
              semantic_views: ['sales'],
              tables: 1,
              relationships: 0,
              measures: 1,
              domains: { unassigned: 1 },
              lifecycle: 'certified',
            },
            review: { total: 1, open: 1, approved: 0, rejected: 0, promoted: 0, needs_info: 0 },
            compare_history: [],
            promotion_history: [],
            model_lifecycle: { state: 'certified', version: 'v1', data_version: null },
          },
          reviews: [
            {
              id: 'visual:page_1::visual_1',
              subject_kind: 'visual',
              subject_id: 'page_1::visual_1',
              title: 'Revenue',
              summary: 'synthetic parity failure',
              recommendation: 'Review the failing parity checks and decide whether the generated fix should be promoted.',
              severity: 'medium',
              confidence: 0.5,
              status: 'open',
              comments: [],
              provenance: {},
              impact: {},
              created_at: Date.now(),
              updated_at: Date.now(),
            },
          ],
          history: [],
          model: {
            name: 'Model',
            version: 'v1',
            data_version: null,
            identity_execution_mode: 'service_account',
            semantic_views: ['sales'],
            tables: 1,
            relationships: 0,
            measures: 1,
            domains: { unassigned: 1 },
            lifecycle: 'certified',
          },
          compare_history: [],
          model_lifecycle: { state: 'certified', version: 'v1', data_version: null },
        }),
        { status: 200 },
      )
    }
    if (url.endsWith('/semantic-traceability')) {
      return new Response(
        JSON.stringify({
          preview: {
            view_name: 'FINOPS_ANALYTICS_SV',
            spec: { name: 'FINOPS_ANALYTICS_SV' },
            pbi_model: {
              name: 'Model',
              table_count: 1,
              relationship_count: 0,
              measure_count: 1,
              tables: [{ name: 'Sales', columns: 3, measures: 1 }],
            },
            snowflake_view: {
              name: 'FINOPS_ANALYTICS_SV',
              tables: [
                {
                  name: 'Sales',
                  base_table: { database: 'ANALYTICS', schema: 'PUBLIC', table: 'SALES' },
                  dimension_count: 3,
                  metric_count: 1,
                },
              ],
            },
            yaml: 'name: FINOPS_ANALYTICS_SV',
            table_count: 3,
            relationship_count: 2,
            metric_count: 5,
            dimension_count: 8,
          },
          latest: {
            deployed_at: Date.now() / 1000,
            database: 'ANALYTICS',
            schema_name: 'PUBLIC',
            view_name: 'FINOPS_ANALYTICS_SV',
            fully_qualified_view: 'ANALYTICS.PUBLIC.FINOPS_ANALYTICS_SV',
            dry_run: false,
            create_or_alter: true,
            message: 'created successfully',
            yaml: 'name: FINOPS_ANALYTICS_SV',
            table_count: 3,
            relationship_count: 2,
            metric_count: 5,
            dimension_count: 8,
          },
          deployments: [],
        }),
        { status: 200 },
      )
    }
    if (url.endsWith('/connections')) {
      return new Response(
        JSON.stringify([
          {
            id: 'conn-1',
            name: 'demo',
            account: 'acct',
            user: 'user',
            auth_method: 'password',
            warehouse: 'ANALYTICS_WH',
            database: 'ANALYTICS',
            schema_name: 'PUBLIC',
          },
        ]),
        { status: 200 },
      )
    }
    if (url.includes('/governance/lifecycle') && (!init || init.method === 'GET')) {
      return new Response(JSON.stringify({ state: 'certified', version: 'v1', data_version: null }), { status: 200 })
    }
    if (url.includes('/governance/lifecycle') && init?.method === 'POST') {
      return new Response(JSON.stringify({ state: 'draft', version: 'v1', data_version: null }), { status: 200 })
    }
    if (url.includes('/decision')) {
      return new Response(JSON.stringify({ review_id: 'visual:page_1::visual_1', decision: { decision: 'approved' } }), { status: 200 })
    }
    if (url.includes('/remediate')) {
      return new Response(
        JSON.stringify({
          review_id: 'visual:page_1::visual_1',
          subject_id: 'page_1::visual_1',
          instruction: 'change this to a bar chart',
          applied_override: { op: 'set_visual_type', page: 'page_1', visual: 'visual_1', value: 'barChart' },
          fixed: true,
          status: 'passed',
          summary: 'Revalidation passed for this visual after applying the suggested remediation.',
          visual_checks: [{ name: 'compile', status: 'passed', detail: '' }],
          history: [
            {
              instruction: 'change this to a bar chart',
              summary: 'Revalidation passed for this visual after applying the suggested remediation.',
              status: 'passed',
              executed_at: Date.now() / 1000,
              owner: 'reviewer',
            },
          ],
          executed_at: Date.now() / 1000,
        }),
        { status: 200 },
      )
    }
    if (url.includes('/ask')) {
      return new Response(
        JSON.stringify({
          review_id: 'visual:page_1::visual_1',
          question: 'why did this fail?',
          answer: 'The render parity check failed, so the converted visual is not yet trusted.',
          asked_at: Date.now() / 1000,
          history: [
            {
              question: 'why did this fail?',
              answer: 'The render parity check failed, so the converted visual is not yet trusted.',
              asked_at: Date.now() / 1000,
              owner: 'reviewer',
            },
          ],
        }),
        { status: 200 },
      )
    }
    if (url.includes('/comments')) {
      return new Response(JSON.stringify({ review_id: 'visual:page_1::visual_1', comment: { author: 'reviewer', body: 'ok', created_at: Date.now() } }), { status: 200 })
    }
    return new Response(JSON.stringify({ detail: 'unexpected fetch: ' + url }), { status: 404 })
  }) as typeof fetch
})

describe('ReviewStep', () => {
  it('renders governance status and issues approval actions', async () => {
    const user = userEvent.setup()
    renderReviewStep()

    // Reimagine lives outside Review — no tab for it here
    expect(screen.queryByRole('button', { name: /Reimagine/ })).not.toBeInTheDocument()

    await user.click(await screen.findByRole('button', { name: /Sign-off/ }))
    expect(await screen.findByText('Review queue')).toBeInTheDocument()
    expect(screen.getByText('Model status')).toBeInTheDocument()
    expect(screen.getByText('What happened')).toBeInTheDocument()
    expect(screen.getByText('Business impact')).toBeInTheDocument()
    expect(screen.getByText('Recommended next step')).toBeInTheDocument()
    expect(await screen.findByText('Ask a question')).toBeInTheDocument()
    expect((await screen.findAllByText('Run fix and re-check')).length).toBeGreaterThan(0)

    await user.click(screen.getByRole('button', { name: /Lineage & deploy/ }))
    expect(screen.getByText('Power BI semantic model → Snowflake semantic view')).toBeInTheDocument()
    expect(await screen.findByText('Editable YAML')).toBeInTheDocument()
    expect(await screen.findByText(/View name:/)).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: /Sign-off/ }))
    await user.click(await screen.findByText('Resolve item'))

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/governance/reviews/visual:page_1::visual_1/decision'),
        expect.objectContaining({ method: 'POST' }),
      )
    })
  })
})
