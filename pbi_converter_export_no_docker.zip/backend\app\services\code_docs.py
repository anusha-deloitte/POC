"""Generated developer documentation for the exported React project.

Built from the actual DashboardSpec, so the docs always describe the code and
data contracts that ship in the zip: architecture, per-page visual inventory,
measure catalog with tiers/formats, and the query API contract.
"""

from __future__ import annotations

from app.runtime.dashboard import DashboardSpec

_ARCHITECTURE = """# Architecture

```
src/
├── main.tsx                 entry: mounts <DashboardApp> with the baked-in ids
├── spec.json                compiled dashboard spec (single source of truth)
└── dashboard/
    ├── DashboardApp.tsx     top chrome: page nav, live/accelerated toggle
    ├── PageCanvas.tsx       1280x720 absolute layout engine, scale-to-fit,
    │                        cross-filter state (slicers + map selections)
    ├── api.ts               query API client (spec fetch, batched visual data)
    ├── theme.tsx            report theme provider (palette, good/bad colors)
    ├── format.ts            Power BI format-string engine ($#,0.0,,"M" etc.)
    └── visuals/             one renderer per visual family
        ├── EChart.tsx       shared ECharts wrapper (resize, click events)
        ├── CardVisual.tsx   KPI cards with variance coloring
        ├── ChartVisual.tsx  bar/column/line/area/donut/pie/waterfall
        │                    (Series role -> one ECharts series per legend value)
        ├── TableVisual.tsx  tables + matrix pivot (see pivot.ts)
        ├── SlicerVisual.tsx dropdown slicers -> page filter state
        ├── MapVisual.tsx    choropleth; click a state to cross-filter the page
        ├── ScatterVisual.tsx / ComboVisual.tsx / GaugeVisual.tsx
        ├── BreakdownVisual.tsx  drillable treemap (decomposition-tree substitute)
        └── TextboxVisual.tsx    static rich text from the report
```

## How rendering works

1. `DashboardApp` loads `spec.json` (or `GET /dashboard/spec`) — pages, visual
   layouts, per-visual queries, formats, theme.
2. For the active page it batches one `POST /dashboard/query` with every
   supported visual + the current filter state (slicer selections and map
   clicks become `FilterClause`s).
3. `PageCanvas` places each visual at its original Power BI coordinates and
   scales the 1280x720 canvas to the container.
4. Each renderer receives its `VisualSpec` (what to draw) and `VisualResult`
   (columns + rows) and renders with ECharts or plain React.

## Data contract

Every visual's data arrives as `{ columns: string[], rows: unknown[][] }`
where measure columns are keyed by measure name and dimension columns by
`Table.Column`. The renderer never computes numbers — all aggregation happens
in the warehouse via the compiled SQL, so what you see is what was verified.
"""


def _query_api_md() -> str:
    return """# Query API contract

The dashboard is serving-plane only: it renders data returned by the
converter backend. Point `VITE_PBIC_API` at the backend.

## GET /api/v1/conversions/{conversionId}/dashboard/spec
Returns the compiled `DashboardSpec` (same shape as `src/spec.json`).

## POST /api/v1/conversions/{conversionId}/dashboard/query
```jsonc
{
  "connection_id": "<profile id>",
  "mode": "live",            // or "accelerated" (in-memory DuckDB extract)
  "queries": [
    {
      "page": "<page name>",
      "visual": "<visual name>",
      "filters": [            // active slicer/map selections
        { "table": "DIM_MONTH", "column": "CALENDAR_YEAR", "values": [2024] }
      ]
    }
  ]
}
```
Response: `{ "results": [{ "visual", "columns", "rows", "elapsed_ms", "cached" }] }`

Filters compose with each visual's own query (dimensions, measures, sort) at
SQL-generation time; the browser never sees raw SQL or credentials.

## Modes

- `live` — every query executes on the warehouse (always-fresh).
- `accelerated` — queries run against a DuckDB extract hydrated from the
  warehouse (5-90x faster, numerically equivalent; hydrate via
  `POST /dashboard/accelerate`).
"""


def build_code_docs(spec: DashboardSpec) -> dict[str, str]:
    """Return {relative_path: markdown} docs generated from the spec."""
    docs: dict[str, str] = {
        "docs/ARCHITECTURE.md": _ARCHITECTURE,
        "docs/QUERY_API.md": _query_api_md(),
    }

    # ---- per-page visual reference (from the real spec) ----
    lines = [
        "# Visual reference",
        "",
        "Every visual on every page, its renderer, and its query grain.",
        "Generated from the compiled spec — matches `src/spec.json` exactly.",
        "",
    ]
    for page in spec.pages:
        lines.append(f"## {page.display_name} (`{page.name}`)")
        lines.append("")
        lines.append("| Visual | Type | Renderer | Dimensions | Measures | Notes |")
        lines.append("|---|---|---|---|---|---|")
        for v in page.visuals:
            renderer = {
                "card": "CardVisual",
                "slicer": "SlicerVisual",
                "textbox": "TextboxVisual",
                "pivotTable": "TableVisual",
                "tableEx": "TableVisual",
                "scatterChart": "ScatterVisual",
                "lineClusteredColumnComboChart": "ComboVisual",
                "gauge": "GaugeVisual",
                "filledMap": "MapVisual",
                "decompositionTreeVisual": "BreakdownVisual",
            }.get(v.visual_type, "ChartVisual")
            notes = []
            if v.substituted_as:
                notes.append(f"rendered as {v.substituted_as}")
            if v.series_keys:
                notes.append(f"series split by {', '.join(v.series_keys)}")
            if v.column_keys:
                notes.append(f"pivot columns: {', '.join(v.column_keys)}")
            if not v.supported:
                notes.append(f"UNSUPPORTED: {v.unsupported_reason}")
            dims = ", ".join(v.dim_keys) or "—"
            measures = ", ".join(v.measure_keys) or "—"
            title = (v.title or v.name).replace("|", "\\|")
            lines.append(
                f"| {title} | `{v.visual_type}` | `{renderer}` | {dims} | "
                f"{measures} | {'; '.join(notes) or '—'} |"
            )
        lines.append("")
    docs["docs/VISUALS.md"] = "\n".join(lines)

    # ---- measure catalog ----
    mlines = [
        "# Measure catalog",
        "",
        "| Measure | Tier | Format | Used by |",
        "|---|---|---|---|",
    ]
    usage: dict[str, list[str]] = {}
    formats: dict[str, str] = {}
    for page in spec.pages:
        for v in page.visuals:
            for mk in v.measure_keys:
                usage.setdefault(mk, []).append(v.title or v.name)
            formats.update(v.measure_formats)
    tier_label = {0: "0 (native)", 1: "1 (deterministic DAX)", 2: "2 (AI, verified)", -1: "parked"}
    for name, tier in sorted(spec.measure_tiers.items()):
        used = usage.get(name, [])
        used_str = ", ".join(used[:3]) + (f" +{len(used) - 3} more" if len(used) > 3 else "")
        fmt = formats.get(name, "—").replace("|", "\\|")
        mlines.append(
            f"| {name} | {tier_label.get(tier, tier)} | `{fmt}` | {used_str or '—'} |"
        )
    mlines += [
        "",
        "Tiers: **0** = direct column aggregate · **1** = compiled deterministically from DAX "
        "(Metric Algebra) · **2** = AI-translated SQL, execution-verified before acceptance · "
        "**parked** = excluded pending human review.",
    ]
    docs["docs/MEASURES.md"] = "\n".join(mlines)
    return docs
