import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { AppShell } from '../AppShell'
import { useWizard } from '../store/wizard'

function renderShell(path = '/app/convert') {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <Routes>
        <Route path="/app" element={<AppShell />}>
          <Route path="convert" element={<div>Wizard content</div>} />
          <Route path="jobs" element={<div>Jobs content</div>} />
        </Route>
      </Routes>
    </MemoryRouter>,
  )
}

describe('AppShell navigation guards', () => {
  beforeEach(() => {
    useWizard.setState({
      step: 'review',
      conversionId: 'conv-1',
      connectionId: 'conn-1',
      hasUnsavedChanges: true,
      unsavedContext: 'review edits',
    })
    localStorage.setItem(
      'pbic.user',
      JSON.stringify({ id: 'u1', email: 'a@b.com', name: 'Tester', is_admin: false }),
    )
  })

  it('blocks step navigation when user cancels unsaved confirmation', async () => {
    const user = userEvent.setup()
    const confirmSpy = vi.spyOn(window, 'confirm').mockReturnValue(false)

    renderShell('/app/convert')
    await user.click(screen.getByRole('button', { name: /Upload/i }))

    expect(confirmSpy).toHaveBeenCalled()
    expect(useWizard.getState().step).toBe('review')
    confirmSpy.mockRestore()
  })

  it('allows step navigation when user confirms unsaved discard', async () => {
    const user = userEvent.setup()
    const confirmSpy = vi.spyOn(window, 'confirm').mockReturnValue(true)

    renderShell('/app/convert')
    await user.click(screen.getByRole('button', { name: /Upload/i }))

    expect(confirmSpy).toHaveBeenCalled()
    expect(useWizard.getState().step).toBe('upload')
    confirmSpy.mockRestore()
  })
})
