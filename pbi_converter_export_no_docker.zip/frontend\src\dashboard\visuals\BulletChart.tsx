import type { EChartsOption } from 'echarts'
import { formatValue } from '../format'
import { useGoodBad, useThemeTokens } from '../theme'
import type { VisualResult, VisualSpec } from '../types'
import { EChart } from './EChart'

/** Bullet chart (Few): linear value bar vs target marker over qualitative
 * bands — the enterprise replacement for gauges. Same query: Y measure is the
 * value, TargetValue measure is the marker. */
export function BulletChart({ spec, data }: { spec: VisualSpec; data?: VisualResult }) {
  const { good, accent } = useGoodBad()
  const theme = useThemeTokens()
  if (!data) return <div className="p-2 text-xs text-surface-400">…</div>
  if (data.error) return <div className="p-2 text-xs text-brand-red">{data.error}</div>

  const roleOf = (role: string) =>
    spec.measure_keys.find((k) => spec.measure_roles[k] === role)
  const valKey = roleOf('Y') ?? spec.measure_keys[0]
  const tgtKey = roleOf('TargetValue')
  const vi = data.columns.indexOf(valKey!)
  const ti = tgtKey ? data.columns.indexOf(tgtKey) : -1

  const value = Number(data.rows[0]?.[vi] ?? 0)
  const target = ti >= 0 ? Number(data.rows[0]?.[ti] ?? 0) : null
  const fmt = spec.measure_formats[valKey!]
  const isPct = (fmt ?? '').includes('%') || (value <= 1 && (target ?? 1) <= 1)
  const max = isPct ? 1 : Math.max(value, target ?? 0) * 1.25
  const met = target === null || value >= target

  const option: EChartsOption = {
    grid: { left: 8, right: 24, top: 26, bottom: 8, containLabel: true },
    xAxis: {
      type: 'value',
      min: 0,
      max,
      axisLabel: { fontSize: 8, formatter: (v: number) => formatValue(v, fmt) },
      splitLine: { show: false },
    },
    yAxis: { type: 'category', data: [''], axisLine: { show: false }, axisTick: { show: false } },
    series: [
      // qualitative background bands at 60/80/100% of range
      {
        type: 'bar',
        barGap: '-100%',
        barWidth: 26,
        silent: true,
        data: [max],
        itemStyle: { color: '#EEF2F7', borderRadius: 4 },
        z: 1,
      },
      {
        type: 'bar',
        barGap: '-100%',
        barWidth: 26,
        silent: true,
        data: [max * 0.8],
        itemStyle: { color: '#E2E9F1', borderRadius: 4 },
        z: 2,
      },
      {
        type: 'bar',
        barGap: '-100%',
        barWidth: 26,
        silent: true,
        data: [max * 0.6],
        itemStyle: { color: '#D6DFEA', borderRadius: 4 },
        z: 3,
      },
      // the measure bar
      {
        type: 'bar',
        barGap: '-100%',
        barWidth: 10,
        data: [value],
        itemStyle: { color: met ? good : accent, borderRadius: 3 },
        label: {
          show: true,
          position: 'insideRight',
          formatter: () => formatValue(value, fmt),
          fontSize: 11,
          fontWeight: 'bold',
          color: '#fff',
        },
        z: 4,
        ...(target !== null
          ? {
              markLine: {
                symbol: 'none',
                lineStyle: { color: '#1e293b', width: 2, type: 'solid' },
                label: {
                  show: true,
                  position: 'end',
                  formatter: () => formatValue(target, spec.measure_formats[tgtKey!] ?? fmt),
                  fontSize: 8,
                  color: theme.foreground,
                },
                data: [{ xAxis: target }],
              },
            }
          : {}),
      },
    ],
  }
  return <EChart option={option} />
}
