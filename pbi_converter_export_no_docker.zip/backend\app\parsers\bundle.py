"""Load a complete .pbip folder into a ReportBundle (model + report)."""

from __future__ import annotations

import json
from pathlib import Path

from app.ir.report import ReportBundle
from app.parsers.pbir import PbirParseError, parse_report_definition, resolve_dataset_reference
from app.parsers.tmdl import parse_tmdl_folder


def find_pbip(root: Path) -> Path:
    candidates = sorted(root.rglob("*.pbip"))
    if not candidates:
        raise PbirParseError(f"no .pbip file under {root}")
    return candidates[0]


def load_pbip(root: Path) -> ReportBundle:
    """`root` is a folder containing X.pbip + X.Report/ + X.SemanticModel/."""
    pbip_file = find_pbip(root)
    pbip = json.loads(pbip_file.read_text(encoding="utf-8"))

    report_rel = None
    for artifact in pbip.get("artifacts", []):
        if "report" in artifact:
            report_rel = artifact["report"].get("path")
            break
    if not report_rel:
        raise PbirParseError(f"{pbip_file}: no report artifact declared")

    report_dir = (pbip_file.parent / report_rel).resolve()
    if not report_dir.is_dir():
        raise PbirParseError(f"report folder not found: {report_dir}")

    model_dir = resolve_dataset_reference(report_dir)
    definition = model_dir / "definition"
    if not definition.is_dir():
        if (model_dir / "model.bim").is_file():
            raise PbirParseError(
                "semantic model uses TMSL (model.bim); re-save with the TMDL "
                "preview feature enabled in Power BI Desktop"
            )
        raise PbirParseError(f"no TMDL definition/ folder in {model_dir}")

    model = parse_tmdl_folder(definition)
    report, warnings = parse_report_definition(report_dir)
    return ReportBundle(
        source_path=str(root),
        model=model,
        report=report,
        warnings=warnings,
    )
