"""Client-facing Conversion Report: a single self-contained HTML document
summarizing what was converted and how it was verified."""

from __future__ import annotations

import html
import time

_CSS = """
:root { --brand:#86BC25; --brand-dark:#046A38; --blue:#0076A8; --red:#DA291C;
        --amber:#ED8B00; --bg:#EEEEE8; --card:#FFFFFF; --text:#1A1C19; --muted:#5C5F58; }
* { box-sizing: border-box; margin: 0; }
body { font-family: 'Segoe UI', 'Open Sans', system-ui, sans-serif; background: var(--bg);
       color: var(--text); padding: 40px; max-width: 960px; margin: 0 auto; }
header { background: #000; color: #fff; border-radius: 16px; padding: 28px 32px; margin-bottom: 24px; }
header .kicker { color: var(--brand); font-size: 11px; font-weight: 700;
                 letter-spacing: .14em; text-transform: uppercase; }
header h1 { font-size: 26px; margin-top: 4px; }
header p { color: rgba(255,255,255,.55); font-size: 13px; margin-top: 6px; }
.grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px;
        margin-bottom: 24px; }
.stat { background: var(--card); border: 1px solid rgba(0,0,0,.06); border-radius: 12px;
        padding: 16px; text-align: center; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
.stat .v { font-size: 26px; font-weight: 800; }
.stat .l { font-size: 10px; font-weight: 700; letter-spacing: .1em; text-transform: uppercase;
           color: var(--muted); margin-top: 2px; }
.stat.accent { border-color: rgba(134,188,37,.4); background: rgba(134,188,37,.07); }
.stat.accent .v { color: var(--brand-dark); }
section { background: var(--card); border: 1px solid rgba(0,0,0,.06); border-radius: 12px;
          padding: 20px 24px; margin-bottom: 16px; box-shadow: 0 1px 3px rgba(0,0,0,.06); }
h2 { font-size: 15px; margin-bottom: 12px; }
table { width: 100%; border-collapse: collapse; font-size: 12px; }
th { text-align: left; font-size: 10px; text-transform: uppercase; letter-spacing: .08em;
     color: var(--muted); padding: 6px 8px; border-bottom: 1px solid rgba(0,0,0,.1); }
td { padding: 6px 8px; border-bottom: 1px solid rgba(0,0,0,.05); }
.ok { color: var(--brand-dark); font-weight: 700; }
.fail { color: var(--red); font-weight: 700; }
.chip { display: inline-block; border-radius: 999px; padding: 1px 8px; font-size: 10px;
        font-weight: 600; }
.chip.g { background: rgba(134,188,37,.12); color: var(--brand-dark); }
.chip.b { background: rgba(0,118,168,.12); color: var(--blue); }
.chip.a { background: rgba(237,139,0,.12); color: var(--amber); }
footer { text-align: center; color: var(--muted); font-size: 11px; margin-top: 24px; }
.logline { font-family: ui-monospace, monospace; font-size: 11px; color: var(--muted);
           padding: 2px 0; }
.logline b { color: var(--text); font-family: inherit; }
"""


def _filter_probe_section(probes: list[dict]) -> str:
    """Slice-invariance proof table: filtered slices re-aggregate to totals."""
    if not probes:
        return ""
    rows = []
    for p in probes:
        filters = " & ".join(
            f"{html.escape(str(f.get('column', '')))} = {html.escape(str(f.get('value', '')))}"
            for f in p.get("filters", [])
        )
        status = p.get("status")
        mark, cls = {"passed": ("✓", "ok"), "skipped": ("⊘", "")}.get(status, ("✗", "fail"))
        rows.append(
            f"<tr><td>{html.escape(p.get('display_name', ''))}</td>"
            f"<td>{filters}</td>"
            f"<td>[{html.escape(p.get('measure', ''))}]</td>"
            f"<td title='{html.escape(p.get('detail', ''))}' "
            f"class='{cls}'>{mark}</td></tr>"
        )
    return (
        "<section><h2>Filter-combination proof (slice invariance)</h2>"
        "<p style='font-size:11px;color:var(--muted);margin-bottom:8px'>"
        "For each page an additive measure is evaluated under real slicer values: the sum of "
        "the measure across a filter's slices must equal the unfiltered total (partition "
        "property). This proves filters propagate through the generated SQL without fan-out "
        "or loss — the same guarantee Power BI's filter context provides.</p>"
        "<table><thead><tr><th>Page</th><th>Filter combination</th><th>Measure</th><th></th>"
        "</tr></thead><tbody>" + "".join(rows) + "</tbody></table></section>"
    )


def build_conversion_report_html(run_data: dict, spec_data: dict) -> str:
    summary = run_data.get("summary") or {}
    fidelity = run_data.get("fidelity") or {}
    events = run_data.get("events") or []
    tier2 = run_data.get("tier2_accepted") or {}
    tier2_names = list(tier2) if isinstance(tier2, dict) else list(tier2)

    report_name = html.escape(str(summary.get("report", spec_data.get("report_name", "Report"))))
    score = float(summary.get("overall_score", 0)) * 100

    stats = [
        (f"{score:.1f}%", "Fidelity score", True),
        (f"{summary.get('visuals_passed', 0)}/{summary.get('visuals_total', 0)}", "Visuals passing", False),
        (str(summary.get("measures_tier01", 0)), "Measures auto-compiled", False),
        (str(len(tier2_names)), "AI-assisted (verified)", False),
        (str(summary.get("substituted", 0)), "Nearest-equivalent", False),
    ]
    probes = fidelity.get("filter_probes", []) or []
    if probes:
        p_pass = sum(1 for p in probes if p.get("status") == "passed")
        stats.append((f"{p_pass}/{len(probes)}", "Filter combos verified", False))
    stat_html = "".join(
        f'<div class="stat{" accent" if acc else ""}"><div class="v">{html.escape(v)}</div>'
        f'<div class="l">{html.escape(label)}</div></div>'
        for v, label, acc in stats
    )

    page_rows = []
    for page in fidelity.get("pages", []):
        visuals = page.get("visuals", [])
        passed = sum(
            1 for v in visuals if not any(c["status"] == "failed" for c in v.get("checks", []))
        )
        page_rows.append(
            f"<tr><td>{html.escape(page.get('display_name', ''))}</td>"
            f"<td>{len(visuals)}</td>"
            f'<td class="{"ok" if passed == len(visuals) else "fail"}">{passed}/{len(visuals)}</td></tr>'
        )

    visual_rows = []
    for page in fidelity.get("pages", []):
        for v in page.get("visuals", []):
            checks = v.get("checks", [])
            failed = [c for c in checks if c["status"] == "failed"]
            chips = " ".join(
                f'<span class="chip {"a" if c["status"] == "skipped" else ("g" if c["status"] == "passed" else "b")}"'
                f' title="{html.escape(c.get("detail", ""))}">{html.escape(c["name"])}</span>'
                for c in checks
            )
            sub = (
                f' <span class="chip b">&asymp; {html.escape(v["substituted_as"])}</span>'
                if v.get("substituted_as")
                else ""
            )
            visual_rows.append(
                f"<tr><td>{html.escape(v.get('title') or v.get('visual', ''))}{sub}</td>"
                f"<td>{html.escape(v.get('visual_type', ''))}</td>"
                f"<td>{chips}</td>"
                f'<td class="{"fail" if failed else "ok"}">{"✗" if failed else "✓"}</td></tr>'
            )

    log_html = "".join(
        f'<div class="logline"><b>[{html.escape(e.get("stage", ""))}]</b> '
        f"{html.escape(e.get('message', ''))}</div>"
        for e in events
    )

    tier2_html = (
        "<section><h2>AI-assisted measures (execution-verified)</h2><p style='font-size:12px;color:var(--muted)'>"
        "These measures fell outside the deterministic compiler and were translated by the AI agent. "
        "Every translation was executed against Snowflake and validated before acceptance.</p><ul style='font-size:12px;margin:8px 0 0 18px'>"
        + "".join(f"<li>{html.escape(n)}</li>" for n in tier2_names)
        + "</ul></section>"
        if tier2_names
        else ""
    )

    generated = time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime())
    return f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>Conversion Report — {report_name}</title>
<style>{_CSS}</style></head><body>
<header>
  <div class="kicker">Power BI → React · Conversion Report</div>
  <h1>{report_name}</h1>
  <p>Converted, compiled and numerically validated against live Snowflake · generated {generated}</p>
</header>
<div class="grid">{stat_html}</div>
<section><h2>Pages</h2><table><thead><tr><th>Page</th><th>Visuals</th><th>Passing</th></tr></thead>
<tbody>{''.join(page_rows)}</tbody></table></section>
<section><h2>Per-visual validation</h2>
<p style="font-size:11px;color:var(--muted);margin-bottom:8px">
Checks: <b>compile</b> (measures in supported tiers) · <b>execute</b> (SQL runs on Snowflake) ·
<b>sanity</b> (result-shape invariants) · <b>totals</b> (grouped values reconcile to totals — catches join fan-out).</p>
<table><thead><tr><th>Visual</th><th>Type</th><th>Checks</th><th></th></tr></thead>
<tbody>{''.join(visual_rows)}</tbody></table></section>
{tier2_html}
{_filter_probe_section(probes)}
<section><h2>Conversion event log</h2>{log_html}</section>
<footer>PBI Converter · accuracy-gated conversion · every number verified before delivery</footer>
</body></html>"""
