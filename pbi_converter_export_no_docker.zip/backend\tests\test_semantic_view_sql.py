from types import SimpleNamespace

from app.ir.model import Measure, MeasureSemanticBinding, SemanticModel, Table
from app.runtime.semantic_view import SemanticViewAdapter, SemanticViewRequest


def _model() -> SemanticModel:
    return SemanticModel(
        name="Model",
        semantic_views=["ANALYTICS.PUBLIC.FINANCE_SV"],
        tables=[
            Table(
                name="Sales",
                measures=[
                    Measure(
                        name="Revenue",
                        expression="SUM(Sales[Revenue])",
                        semantic_binding=MeasureSemanticBinding(
                            semantic_view="ANALYTICS.PUBLIC.FINANCE_SV", metric_id="revenue"
                        ),
                    )
                ],
            )
        ],
    )



def test_semantic_view_sql_builds_for_measure_and_dims():
    adapter = SemanticViewAdapter(_model())
    req = SemanticViewRequest(
        query=SimpleNamespace(
            dimensions=[SimpleNamespace(table="Date", column="YearMonth", key="Date.YearMonth")],
            measures=[
                SimpleNamespace(name="Revenue", key="Revenue", table=None, column=None, aggregate=None)
            ],
            filters=[SimpleNamespace(table="Date", column="YearMonth", values=["2026-01"], op="in")],
            sort=[{"key": "Date.YearMonth", "direction": "Ascending"}],
            limit=100,
        )
    )
    plan = adapter.build_sql(req)
    sql = plan.sql
    # SEMANTIC_VIEW construct: metrics/dimensions/where INSIDE the parens
    assert 'FROM SEMANTIC_VIEW("ANALYTICS"."PUBLIC"."FINANCE_SV"' in sql
    assert 'METRICS "revenue" AS "__M0"' in sql
    assert 'DIMENSIONS "Date"."YearMonth" AS "__D0"' in sql
    assert 'WHERE "Date"."YearMonth" IN (\'2026-01\')' in sql
    # outer select maps construct aliases back to spec keys
    assert '"__D0" AS "Date.YearMonth"' in sql
    assert '"__M0" AS "Revenue"' in sql
    assert "GROUP BY" not in sql  # grouping is implicit in the construct
    assert "LIMIT 100" in sql
    assert "/* model_version=v1 */" in sql
    assert "SV_NATIVE" in plan.trace_codes
    assert "SV_MODEL_VERSION" in plan.trace_codes



def test_semantic_view_sql_rejects_cross_view_mix():
    model = SemanticModel(
        name="Model",
        tables=[
            Table(
                name="A",
                measures=[
                    Measure(
                        name="M1",
                        expression="1",
                        semantic_binding=MeasureSemanticBinding(semantic_view="DB.SCH.SV1"),
                    )
                ],
            ),
            Table(
                name="B",
                measures=[
                    Measure(
                        name="M2",
                        expression="1",
                        semantic_binding=MeasureSemanticBinding(semantic_view="DB.SCH.SV2"),
                    )
                ],
            ),
        ],
    )
    adapter = SemanticViewAdapter(model)
    req = SemanticViewRequest(
        query=SimpleNamespace(measures=[SimpleNamespace(name="M1"), SimpleNamespace(name="M2")])
    )
    try:
        adapter.build_sql(req)
        assert False, "expected cross-view failure"
    except Exception as e:
        assert "cross-view joins are not allowed" in str(e)


def test_semantic_view_prefers_explicit_domain_view_when_unbound():
    model = SemanticModel(name="Model", semantic_views=["DB.SCH.DEFAULT_SV"], tables=[])
    adapter = SemanticViewAdapter(model)
    req = SemanticViewRequest(
        query=SimpleNamespace(
            measures=[
                SimpleNamespace(
                    name=None, table="Sales", column="Revenue", aggregate="SUM", key="Rev"
                )
            ]
        ),
        preferred_view="DB.SCH.COVERED_SV",
    )
    plan = adapter.build_sql(req)
    assert 'SEMANTIC_VIEW("DB"."SCH"."COVERED_SV"' in plan.sql
    assert 'METRICS SUM("Sales"."Revenue") AS "__M0"' in plan.sql
    assert "SV_PREFERRED_VIEW" in plan.trace_codes


def test_semantic_view_metric_ident_fallback_for_unbound_measure():
    """A tier-1 measure without an explicit semantic binding resolves to
    <home_table>.<METRIC_IDENT> inside the METRICS clause."""
    from pathlib import Path

    from app.parsers.bundle import load_pbip

    fixture = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"
    bundle = load_pbip(fixture)
    adapter = SemanticViewAdapter(bundle.model)
    req = SemanticViewRequest(
        query=SimpleNamespace(
            dimensions=[
                SimpleNamespace(table="DIM_LOB", column="LOB_NAME", key="DIM_LOB.LOB_NAME")
            ],
            measures=[
                SimpleNamespace(
                    name="Allowed Amount", key="Allowed Amount", table=None, column=None, aggregate=None
                )
            ],
            filters=[],
            sort=[],
            limit=None,
        ),
        preferred_view="DB.SCH.MODEL_SV",
    )
    plan = adapter.build_sql(req)
    # M_ prefix keeps metric names from shadowing physical columns
    assert 'METRICS "MV_MEDICAL_COST_SUMMARY"."M_ALLOWED_AMOUNT" AS "__M0"' in plan.sql
    assert 'AS "Allowed Amount"' in plan.sql
