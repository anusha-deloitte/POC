import type { EChartsOption } from 'echarts'
import { formatValue } from '../format'
import { useThemeTokens } from '../theme'
import type { VisualResult, VisualSpec } from '../types'
import { EChart } from './EChart'

/** Single-measure matrix re-encoded as an ECharts heatmap: rows × pivot
 * columns with a sequential color scale. Same long-format query as the
 * pivotTable it replaces. */
export function HeatmapMatrix({
  spec,
  data,
  onSelect,
}: {
  spec: VisualSpec
  data?: VisualResult
  onSelect?: (values: (string | number)[]) => void
}) {
  const theme = useThemeTokens()
  if (!data) return <div className="p-2 text-xs text-surface-400">…</div>
  if (data.error) return <div className="p-2 text-xs text-brand-red">{data.error}</div>

  const rowKey = spec.dim_keys.find((k) => !spec.column_keys.includes(k))
  const colKey = spec.column_keys[0] ?? spec.dim_keys[1]
  const mKey = spec.measure_keys[0]
  const ri = rowKey ? data.columns.indexOf(rowKey) : -1
  const ci = colKey ? data.columns.indexOf(colKey) : -1
  const mi = data.columns.indexOf(mKey)
  if (ri < 0 || ci < 0 || mi < 0)
    return <div className="p-2 text-xs text-surface-400">No matrix data.</div>

  const rowCats: string[] = []
  const colCats: string[] = []
  const seenR = new Set<string>()
  const seenC = new Set<string>()
  for (const r of data.rows) {
    const rv = String(r[ri] ?? '')
    const cv = String(r[ci] ?? '')
    if (!seenR.has(rv)) {
      seenR.add(rv)
      rowCats.push(rv)
    }
    if (!seenC.has(cv)) {
      seenC.add(cv)
      colCats.push(cv)
    }
  }
  const fmt = spec.measure_formats[mKey]
  let vmin = Infinity
  let vmax = -Infinity
  const points: [number, number, number][] = []
  for (const r of data.rows) {
    const v = Number(r[mi] ?? 0)
    vmin = Math.min(vmin, v)
    vmax = Math.max(vmax, v)
    points.push([colCats.indexOf(String(r[ci] ?? '')), rowCats.indexOf(String(r[ri] ?? '')), v])
  }

  const option: EChartsOption = {
    grid: { left: 8, right: 8, top: 8, bottom: 30, containLabel: true },
    tooltip: {
      formatter: (p) => {
        const v = (p as unknown as { value: [number, number, number] }).value
        return `<b>${rowCats[v[1]]}</b> · ${colCats[v[0]]}<br/>${formatValue(v[2], fmt)}`
      },
      backgroundColor: theme.tooltipBackground,
      borderColor: theme.panelBorder,
      textStyle: { color: theme.tooltipText, fontSize: 11 },
    },
    xAxis: {
      type: 'category',
      data: colCats,
      axisLabel: { fontSize: 8, interval: 0, rotate: colCats.length > 8 ? 45 : 0 },
      splitArea: { show: true },
    },
    yAxis: {
      type: 'category',
      data: rowCats,
      inverse: true,
      axisLabel: { fontSize: 8, overflow: 'truncate', width: 110 },
      splitArea: { show: true },
    },
    visualMap: {
      min: vmin,
      max: vmax,
      calculable: false,
      orient: 'horizontal',
      left: 'center',
      bottom: 0,
      itemHeight: 220,
      textStyle: { fontSize: 8 },
      inRange: { color: ['#EAF1F8', '#7FB3D5', '#1F4E79'] },
      formatter: (v) => formatValue(Number(v), fmt),
    },
    series: [
      {
        type: 'heatmap',
        data: points,
        label: {
          show: colCats.length * rowCats.length <= 180,
          fontSize: 7,
          formatter: (p) =>
            formatValue((p as unknown as { value: [number, number, number] }).value[2], fmt),
        },
        emphasis: { itemStyle: { shadowBlur: 6, shadowColor: 'rgba(0,0,0,0.3)' } },
      },
    ],
  }
  return (
    <EChart option={option} onItemClick={(name) => onSelect?.([name])} />
  )
}
