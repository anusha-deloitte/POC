"""Reimagine build: compiler invariants, mapping manifest, zero-loss gate."""

from pathlib import Path

import pytest

from app.agents.reimagine_build import build_reimagined
from app.parsers.bundle import load_pbip
from app.runtime.dashboard import compile_dashboard
from app.validation.reimagine_gate import run_zero_loss_gate

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_care_analytics"


@pytest.fixture(scope="module")
def spec():
    s, _ = compile_dashboard(load_pbip(FIXTURE))
    return s


@pytest.fixture(scope="module")
def built(spec):
    return build_reimagined(spec, "test-cid", snapshot=None)


class TestCompilerInvariants:
    def test_queries_byte_identical(self, spec, built):
        variant, _ = built
        v_index = {(p.name, v.name): v for p in variant.pages for v in p.visuals}
        for page in spec.pages:
            for vs in page.visuals:
                twin = v_index[(page.name, vs.name)]
                if vs.query is None:
                    assert twin.query is None
                else:
                    assert twin.query.model_dump() == vs.query.model_dump(), vs.name

    def test_reflow_never_remove(self, spec, built):
        variant, _ = built
        orig = {(p.name, v.name) for p in spec.pages for v in p.visuals}
        new = {(p.name, v.name) for p in variant.pages for v in p.visuals}
        assert orig == new

    def test_no_overlapping_rects(self, built):
        variant, _ = built
        for page in variant.pages:
            rects = [
                (v.x, v.y, v.width, v.height)
                for v in page.visuals
            ]
            for i, a in enumerate(rects):
                for b in rects[i + 1 :]:
                    overlap_x = a[0] < b[0] + b[2] and b[0] < a[0] + a[2]
                    overlap_y = a[1] < b[1] + b[3] and b[1] < a[1] + a[3]
                    assert not (overlap_x and overlap_y), f"{page.name}: {a} overlaps {b}"

    def test_all_visuals_within_page(self, built):
        variant, _ = built
        for page in variant.pages:
            for v in page.visuals:
                assert v.x >= 0 and v.y >= 0
                assert v.x + v.width <= page.width + 1
                assert v.y + v.height <= page.height + 1

    def test_style_variant_flag_set(self, built):
        variant, _ = built
        for page in variant.pages:
            for v in page.visuals:
                assert v.options.get("style_variant") == "reimagined"

    def test_time_series_column_reencoded(self, spec, built):
        variant, manifest = built
        # p4risk-like time charts keep type (combo not in re-encode set),
        # but any >12-point time column chart must become areaChart when
        # snapshot rows say so — with no snapshot rows, type is preserved
        entry = next(e for e in manifest.entries if e.original["visual"] == "p1donut")
        assert entry.reimagined["type"] == "donutChart"
        assert entry.change_kind in ("restyle", "relocate")

    def test_mapping_covers_every_data_visual(self, spec, built):
        _, manifest = built
        data_visuals = {
            v.name
            for p in spec.pages
            for v in p.visuals
            if v.visual_type not in ("slicer", "textbox")
        }
        mapped = {e.original["visual"] for e in manifest.entries}
        assert mapped == data_visuals

    def test_snapshot_triggers_reencode(self, spec):
        # simulate a 36-row snapshot for a monthly column chart if one exists;
        # use p4risk (combo) page's YEAR_MONTH area chart as the time carrier
        target = None
        for p in spec.pages:
            for v in p.visuals:
                if v.visual_type in ("columnChart", "clusteredColumnChart") and any(
                    "MONTH" in k.upper() for k in v.dim_keys
                ):
                    target = (p.name, v.name)
        if target is None:
            pytest.skip("fixture has no monthly column chart")
        snapshot = {
            "results": [
                {"page": target[0], "visual": target[1], "rows": [[i] for i in range(36)]}
            ]
        }
        variant, manifest = build_reimagined(spec, "cid", snapshot)
        entry = next(e for e in manifest.entries if e.original["visual"] == target[1])
        assert entry.reimagined["type"] == "areaChart"
        assert entry.change_kind == "re-encode"


class TestZeroLossGate:
    def test_gate_passes_on_faithful_build(self, spec, built):
        variant, manifest = built
        result = run_zero_loss_gate(spec, variant, manifest)
        assert result.passed, result.gaps
        assert result.gaps == []
        # coverage strings show full coverage e.g. "21/21"
        for key in ("measures", "dimensions", "slicers"):
            got, total = result.coverage[key].split("/")
            assert got == total

    def test_gate_fails_when_measure_stripped(self, spec, built):
        variant, manifest = built
        broken = variant.model_copy(deep=True)
        for page in broken.pages:
            for v in page.visuals:
                if v.name == "p1mtx":
                    v.measure_keys = [m for m in v.measure_keys if m != "Medical Loss Ratio"]
                    if v.query:
                        v.query.measures = [
                            m for m in v.query.measures if (m.alias or m.name) != "Medical Loss Ratio"
                        ]
        result = run_zero_loss_gate(spec, broken, manifest)
        assert not result.passed
        assert any("query changed" in g or "measure lost" in g for g in result.gaps)

    def test_gate_fails_when_visual_dropped(self, spec, built):
        variant, manifest = built
        broken = variant.model_copy(deep=True)
        for page in broken.pages:
            page.visuals = [v for v in page.visuals if v.name != "p1donut"]
        result = run_zero_loss_gate(spec, broken, manifest)
        assert not result.passed
        assert any("visual lost" in g for g in result.gaps)

    def test_gate_fails_on_declared_missing(self, spec, built):
        variant, manifest = built
        poisoned = manifest.model_copy(deep=True)
        poisoned.entries[0].information_delta["missing"] = ["legend series X"]
        result = run_zero_loss_gate(spec, variant, poisoned)
        assert not result.passed


class TestBiExpertReencodings:
    """The redesign must be a real re-encoding pass, not a restyle: gauges become
    bullets, crowded donuts become ranked bars, numeric matrices become heatmaps,
    clustered series become stacked composition — all with identical queries."""

    def test_gauge_becomes_bullet_chart(self, spec, built):
        variant, manifest = built
        gauges = [
            (p.name, v.name)
            for p in spec.pages
            for v in p.visuals
            if v.visual_type == "gauge"
        ]
        assert gauges, "fixture must contain a gauge"
        v_index = {(p.name, v.name): v for p in variant.pages for v in p.visuals}
        for key in gauges:
            assert v_index[key].visual_type == "bulletChart"
        entry = next(e for e in manifest.entries if e.original["type"] == "gauge")
        assert entry.change_kind == "re-encode"
        assert "bullet" in entry.rationale.lower()

    def test_single_measure_matrix_becomes_heatmap(self, spec, built):
        variant, _ = built
        candidates = [
            (p.name, v.name)
            for p in spec.pages
            for v in p.visuals
            if v.visual_type == "pivotTable" and v.column_keys and len(v.measure_keys) == 1
        ]
        assert candidates, "fixture must contain a single-measure matrix"
        v_index = {(p.name, v.name): v for p in variant.pages for v in p.visuals}
        for key in candidates:
            assert v_index[key].visual_type == "heatmapMatrix"

    def test_clustered_series_becomes_stacked(self, spec, built):
        variant, _ = built
        v_index = {(p.name, v.name): v for p in variant.pages for v in p.visuals}
        for p in spec.pages:
            for v in p.visuals:
                if v.visual_type in ("barChart", "clusteredBarChart") and v.series_keys:
                    assert v_index[(p.name, v.name)].options.get("stacked") is True

    def test_crowded_donut_becomes_ranked_bars(self, spec):
        # snapshot reporting 8 distinct categories on a donut -> ranked bars
        donut = next(
            (p.name, v.name)
            for p in spec.pages
            for v in p.visuals
            if v.visual_type == "donutChart"
        )
        page_name, visual_name = donut
        vs = next(
            v for p in spec.pages for v in p.visuals if (p.name, v.name) == donut
        )
        dim = vs.dim_keys[0]
        snapshot = {
            "results": [
                {
                    "page": page_name,
                    "visual": visual_name,
                    "columns": [dim, vs.measure_keys[0]],
                    "rows": [[f"cat{i}", i * 10] for i in range(8)],
                }
            ]
        }
        variant, manifest = build_reimagined(spec, "t", snapshot=snapshot)
        twin = next(
            v for p in variant.pages for v in p.visuals if (p.name, v.name) == donut
        )
        assert twin.visual_type == "barChart"
        assert twin.options.get("client_sort") == "value_desc"
        entry = next(e for e in manifest.entries if e.original["visual"] == visual_name)
        assert "donut" in entry.rationale.lower()

    def test_gate_still_passes_after_reencoding(self, spec, built):
        variant, manifest = built
        result = run_zero_loss_gate(spec, variant, manifest)
        assert result.passed, result.gaps


def _mk_visual(name, vtype, measures, dims, page_slicer=None):
    from app.runtime.engine import DimensionRef, MeasureRefSpec, QuerySpec
    from app.runtime.dashboard import VisualSpec

    if vtype == "slicer":
        t, c = page_slicer.split(".")
        return VisualSpec(
            name=name, visual_type="slicer", x=0, y=0, width=100, height=40,
            slicer_target={"table": t, "column": c},
            query=QuerySpec(dimensions=[DimensionRef(table=t, column=c)]),
            dim_keys=[page_slicer],
        )
    return VisualSpec(
        name=name, visual_type=vtype, x=0, y=0, width=300, height=200,
        query=QuerySpec(
            dimensions=[DimensionRef(table=d.split(".")[0], column=d.split(".")[1]) for d in dims],
            measures=[MeasureRefSpec(name=m) for m in measures],
        ),
        dim_keys=list(dims),
        measure_keys=list(measures),
    )


def _mk_twin_page_spec():
    """Two pages with near-identical measure sets (same question split over two
    pages) + a shared slicer — the merge case a real IA review would flag."""
    from app.runtime.dashboard import DashboardSpec, PageSpec

    shared = ["Revenue", "Cost", "Margin", "Margin %"]
    p1 = PageSpec(
        name="sales-a", display_name="Sales A", width=1280, height=720, ordinal=0,
        visuals=[
            _mk_visual("a-sl", "slicer", [], [], page_slicer="DIM.REGION"),
            _mk_visual("a1", "barChart", shared[:3], ["DIM.REGION"]),
            _mk_visual("a2", "lineChart", shared[2:], ["DIM.MONTH"]),
        ],
    )
    p2 = PageSpec(
        name="sales-b", display_name="Sales B", width=1280, height=720, ordinal=1,
        visuals=[
            _mk_visual("b-sl", "slicer", [], [], page_slicer="DIM.REGION"),
            _mk_visual("b1", "columnChart", shared[:3], ["DIM.PRODUCT"]),
            _mk_visual("b2", "tableEx", shared, ["DIM.PRODUCT"]),
        ],
    )
    return DashboardSpec(report_name="twin", pages=[p1, p2])


class TestPageArchitecture:
    def test_real_fixture_keeps_all_pages_with_evidence(self, spec, built):
        _, manifest = built
        arch = manifest.architecture
        assert arch["pages_before"] == 4 and arch["pages_after"] == 4
        assert not arch["merges"]
        assert "distinct analytical question" in arch["verdict"]
        # the slicer spine must be recognized, not counted as content overlap
        assert "DIM_LOB.LOB_NAME" in arch["conformed_dims"]
        assert all(p["verdict"] == "keep-separate" for p in arch["pairs"])
        assert all(p["reason"] for p in arch["pairs"])
        # identity page_map when nothing merges
        assert manifest.page_map == {p.name: p.name for p in spec.pages}

    def test_duplicate_domain_pages_merge(self):
        twin = _mk_twin_page_spec()
        variant, manifest = build_reimagined(twin, "t")
        arch = manifest.architecture
        assert len(arch["merges"]) == 1
        assert arch["pages_after"] == 1
        assert len(variant.pages) == 1
        survivor = variant.pages[0]
        # all four data visuals survive on the merged page
        names = {v.name for v in survivor.visuals}
        assert {"a1", "a2", "b1", "b2"} <= names
        # duplicate slicer deduped, recorded in the manifest
        slicers = [v for v in survivor.visuals if v.visual_type == "slicer"]
        assert len(slicers) == 1
        dedupes = [e for e in manifest.entries if e.change_kind == "dedupe"]
        assert len(dedupes) == 1 and dedupes[0].original["visual"] == "b-sl"
        assert manifest.page_map["sales-b"] == "sales-a"

    def test_gate_passes_after_merge(self):
        twin = _mk_twin_page_spec()
        variant, manifest = build_reimagined(twin, "t")
        result = run_zero_loss_gate(twin, variant, manifest)
        assert result.passed, result.gaps

    def test_gate_fails_if_merged_visual_dropped(self):
        twin = _mk_twin_page_spec()
        variant, manifest = build_reimagined(twin, "t")
        variant.pages[0].visuals = [
            v for v in variant.pages[0].visuals if v.name != "b2"
        ]
        result = run_zero_loss_gate(twin, variant, manifest)
        assert not result.passed
        assert any("b2" in g for g in result.gaps)

    def test_merge_blocked_by_density(self):
        from app.agents.page_architecture import analyze_page_architecture
        from app.runtime.dashboard import DashboardSpec, PageSpec

        shared = ["M1", "M2", "M3"]
        def big_page(name, n):
            return PageSpec(
                name=name, display_name=name, width=1280, height=720, ordinal=0,
                visuals=[
                    _mk_visual(f"{name}-{i}", "barChart", shared, ["DIM.X"])
                    for i in range(n)
                ],
            )
        spec2 = DashboardSpec(report_name="dense", pages=[big_page("p1", 10), big_page("p2", 10)])
        rep = analyze_page_architecture(spec2)
        assert not rep.merges
        assert any("density" in p.reason for p in rep.pairs)

    def test_oversize_page_gets_split_advice(self):
        from app.agents.page_architecture import analyze_page_architecture
        from app.runtime.dashboard import DashboardSpec, PageSpec

        page = PageSpec(
            name="mega", display_name="Mega", width=1280, height=720, ordinal=0,
            visuals=[
                _mk_visual(f"v{i}", "barChart", [f"M{i}"], ["DIM.X"])
                for i in range(24)
            ],
        )
        rep = analyze_page_architecture(DashboardSpec(report_name="mega", pages=[page]))
        assert rep.splits and rep.splits[0]["page"] == "mega"
        assert "advisory" in rep.splits[0]["reason"]
