import type {
  ConnectionProfile,
  ConnectionTestResult,
  ConversionSummary,
  NewConnection,
  NewSourceConnection,
  SourceConnectionProfile,
} from './types'

const BASE = '/api/v1'

export async function readErrorDetail(res: Response): Promise<string> {
  let detail = res.statusText
  const contentType = res.headers.get('content-type') ?? ''

  try {
    if (contentType.includes('application/json')) {
      const body = await res.json()
      return typeof body.detail === 'string' ? body.detail : JSON.stringify(body.detail)
    }

    const text = (await res.text()).trim()
    // proxy/gateway error pages are HTML — show a readable message instead
    if (/<html|<head|<body/i.test(text)) {
      if (res.status === 504)
        return 'The request timed out at the gateway (504). The operation may still be running server-side — check progress or retry shortly.'
      return `${res.status} ${res.statusText || 'gateway error'}`
    }
    if (text) return text
  } catch {
    /* fall back to statusText */
  }

  return detail
}

export async function handle<T>(res: Response): Promise<T> {
  if (!res.ok) {
    throw new Error(await readErrorDetail(res))
  }
  if (res.status === 204) return undefined as T
  return res.json() as Promise<T>
}

export const api = {
  uploadPbip(file: File, name?: string): Promise<ConversionSummary> {
    const form = new FormData()
    form.append('file', file)
    if (name?.trim()) form.append('name', name.trim())
    return fetch(`${BASE}/conversions`, { method: 'POST', body: form }).then((r) =>
      handle<ConversionSummary>(r),
    )
  },
  deleteConversion(id: string): Promise<void> {
    return fetch(`${BASE}/conversions/${id}`, { method: 'DELETE' }).then((r) => handle<void>(r))
  },
  renameJob(id: string, name: string): Promise<{ id: string; name: string }> {
    return fetch(`${BASE}/conversions/${id}/name`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    }).then((r) => handle<{ id: string; name: string }>(r))
  },
  listConversions(): Promise<ConversionSummary[]> {
    return fetch(`${BASE}/conversions`).then((r) => handle<ConversionSummary[]>(r))
  },
  getConversion(id: string): Promise<ConversionSummary> {
    return fetch(`${BASE}/conversions/${id}`).then((r) => handle<ConversionSummary>(r))
  },
  createConnection(spec: NewConnection): Promise<ConnectionProfile> {
    return fetch(`${BASE}/connections`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(spec),
    }).then((r) => handle<ConnectionProfile>(r))
  },
  listConnections(): Promise<ConnectionProfile[]> {
    return fetch(`${BASE}/connections`).then((r) => handle<ConnectionProfile[]>(r))
  },
  deleteConnection(id: string): Promise<void> {
    return fetch(`${BASE}/connections/${id}`, { method: 'DELETE' }).then((r) => handle<void>(r))
  },
  testConnection(id: string): Promise<ConnectionTestResult> {
    return fetch(`${BASE}/connections/${id}/test`, { method: 'POST' }).then((r) =>
      handle<ConnectionTestResult>(r),
    )
  },
  listSourceKinds(): Promise<{ id: string; label: string; available: boolean }[]> {
    return fetch(`${BASE}/source-connections/kinds`).then((r) =>
      handle<{ id: string; label: string; available: boolean }[]>(r),
    )
  },
  createSourceConnection(spec: NewSourceConnection): Promise<SourceConnectionProfile> {
    return fetch(`${BASE}/source-connections`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(spec),
    }).then((r) => handle<SourceConnectionProfile>(r))
  },
  listSourceConnections(): Promise<SourceConnectionProfile[]> {
    return fetch(`${BASE}/source-connections`).then((r) =>
      handle<SourceConnectionProfile[]>(r),
    )
  },
  deleteSourceConnection(id: string): Promise<void> {
    return fetch(`${BASE}/source-connections/${id}`, { method: 'DELETE' }).then((r) =>
      handle<void>(r),
    )
  },
  testSourceConnection(id: string): Promise<{ ok: boolean }> {
    return fetch(`${BASE}/source-connections/${id}/test`, { method: 'POST' }).then((r) =>
      handle<{ ok: boolean }>(r),
    )
  },
  getMigrationResult(conversionId: string): Promise<{ ran: boolean; ok?: boolean; tables?: unknown[] }> {
    return fetch(`${BASE}/conversions/${conversionId}/migration`).then((r) =>
      handle<{ ran: boolean; ok?: boolean; tables?: unknown[] }>(r),
    )
  },
}
