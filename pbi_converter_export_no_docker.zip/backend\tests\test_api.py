import json
import io
import zipfile
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from app.api.deps import get_connection_store, get_ingest_service
from app.api.dashboards import _apply_deployed_materializations
from app.binding.resolver import BindingMap, TableBinding
from app.main import app
from app.runtime.semantic_view import SemanticViewPlan, SemanticViewPlanError
from app.services.connections import ConnectionStore
from app.services.ingest import IngestService
from app.validation.harness import Check, CheckStatus, FidelityReport, PageScore, VisualScore


@pytest.fixture()
def client(tmp_path, monkeypatch):
    svc = IngestService(tmp_path / "storage")
    store = ConnectionStore(tmp_path / "storage", tmp_path / "storage" / ".key")
    app.dependency_overrides[get_ingest_service] = lambda: svc
    app.dependency_overrides[get_connection_store] = lambda: store
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


def zip_folder(folder: Path) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, f.relative_to(folder))
    return buf.getvalue()


class TestConversions:
    def test_upload_and_summary(self, client, contoso_pbip):
        data = zip_folder(contoso_pbip)
        r = client.post(
            "/api/v1/conversions",
            files={"file": ("contoso.zip", data, "application/zip")},
        )
        assert r.status_code == 201, r.text
        body = r.json()
        assert body["report"] == "Contoso Sales"
        assert body["model"]["tables"] == 4
        assert body["model"]["measures"] == 6
        assert body["visual_types"] == {
            "card": 1,
            "clusteredBarChart": 1,
            "lineChart": 1,
            "slicer": 1,
        }

        # bundle retrievable
        cid = body["id"]
        r2 = client.get(f"/api/v1/conversions/{cid}/bundle")
        assert r2.status_code == 200
        assert r2.json()["model"]["tables"][0]["name"]

        # listed
        assert any(c["id"] == cid for c in client.get("/api/v1/conversions").json())

        # deletable
        assert client.delete(f"/api/v1/conversions/{cid}").status_code == 204
        assert client.get(f"/api/v1/conversions/{cid}").status_code == 404

    def test_upload_with_job_name_and_rename(self, client, contoso_pbip):
        data = zip_folder(contoso_pbip)
        r = client.post(
            "/api/v1/conversions",
            files={"file": ("contoso.zip", data, "application/zip")},
            data={"name": "Q3 Contoso migration"},
        )
        assert r.status_code == 201
        cid = r.json()["id"]

        jobs = client.get("/api/v1/conversions/jobs").json()
        job = next(j for j in jobs if j["id"] == cid)
        assert job["name"] == "Q3 Contoso migration"

        # rename
        r2 = client.patch(f"/api/v1/conversions/{cid}/name", json={"name": "Renamed"})
        assert r2.status_code == 200
        jobs = client.get("/api/v1/conversions/jobs").json()
        assert next(j for j in jobs if j["id"] == cid)["name"] == "Renamed"

        # empty name rejected
        assert (
            client.patch(f"/api/v1/conversions/{cid}/name", json={"name": "  "}).status_code
            == 422
        )
        client.delete(f"/api/v1/conversions/{cid}")

    def test_rejects_non_zip(self, client):
        r = client.post(
            "/api/v1/conversions", files={"file": ("x.pbix", b"123", "application/octet-stream")}
        )
        assert r.status_code == 422

    def test_rejects_zip_without_pbip(self, client):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("readme.txt", "hi")
        r = client.post(
            "/api/v1/conversions", files={"file": ("x.zip", buf.getvalue(), "application/zip")}
        )
        assert r.status_code == 422
        assert "no .pbip" in r.json()["detail"]

    def test_zip_slip_blocked(self, client):
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("../../evil.txt", "pwned")
        r = client.post(
            "/api/v1/conversions", files={"file": ("x.zip", buf.getvalue(), "application/zip")}
        )
        assert r.status_code == 422
        assert "unsafe path" in r.json()["detail"]

    def test_unknown_conversion_404(self, client):
        assert client.get("/api/v1/conversions/not-a-uuid").status_code == 404


class TestConnections:
    def test_create_password_profile_hides_secret(self, client):
        r = client.post(
            "/api/v1/connections",
            json={
                "name": "demo",
                "account": "acme-xy12345",
                "user": "PBIC",
                "auth_method": "password",
                "password": "hunter2",
                "warehouse": "DEMO_WH",
            },
        )
        assert r.status_code == 201, r.text
        body = r.json()
        assert "password" not in body
        assert body["auth_method"] == "password"

        listed = client.get("/api/v1/connections").json()
        assert len(listed) == 1
        assert "password" not in listed[0]

    def test_missing_secret_rejected(self, client):
        r = client.post(
            "/api/v1/connections",
            json={
                "name": "bad",
                "account": "a",
                "user": "u",
                "auth_method": "key_pair",
            },
        )
        assert r.status_code == 422
        assert "private_key_pem" in r.json()["detail"]

    def test_oauth_requires_endpoint_fields(self, client):
        r = client.post(
            "/api/v1/connections",
            json={
                "name": "bad",
                "account": "a",
                "user": "u",
                "auth_method": "oauth_client_credentials",
                "oauth_client_secret": "s",
            },
        )
        assert r.status_code == 422

    def test_delete(self, client):
        r = client.post(
            "/api/v1/connections",
            json={
                "name": "demo",
                "account": "a",
                "user": "u",
                "auth_method": "pat",
                "pat_token": "tok",
            },
        )
        pid = r.json()["id"]
        assert client.delete(f"/api/v1/connections/{pid}").status_code == 204
        assert client.get(f"/api/v1/connections/{pid}").status_code == 404

    def test_test_endpoint_graceful_without_connector(self, client):
        r = client.post(
            "/api/v1/connections",
            json={
                "name": "demo",
                "account": "a",
                "user": "u",
                "auth_method": "password",
                "password": "x",
            },
        )
        pid = r.json()["id"]
        resp = client.post(f"/api/v1/connections/{pid}/test")
        # connector not installed in test env -> 501; installed -> network error dict
        assert resp.status_code in (200, 501)


class TestAuthToken:
    def test_token_enforced_when_configured(self, client, monkeypatch):
        from app.core.config import get_settings

        get_settings.cache_clear()
        monkeypatch.setenv("PBIC_API_TOKEN", "sekret")
        try:
            assert client.get("/api/v1/conversions").status_code == 401
            ok = client.get(
                "/api/v1/conversions", headers={"Authorization": "Bearer sekret"}
            )
            assert ok.status_code == 200
        finally:
            get_settings.cache_clear()


class TestConnectionStoreUnit:
    def test_connector_kwargs_password(self, tmp_path):
        from app.services.connections import AuthMethod, SnowflakeProfileIn

        store = ConnectionStore(tmp_path, tmp_path / ".key")
        p = store.create(
            SnowflakeProfileIn(
                name="n",
                account="acct",
                user="u",
                auth_method=AuthMethod.PASSWORD,
                password="pw",
                role="R1",
                warehouse="WH",
                database="DB",
                schema="SC",
            )
        )
        kwargs = store.connector_kwargs(p.id, query_tag="pbic:test")
        assert kwargs["password"] == "pw"
        assert kwargs["schema"] == "SC"
        assert kwargs["session_parameters"]["QUERY_TAG"] == "pbic:test"

    def test_connector_kwargs_key_pair_ignores_passphrase_for_unencrypted_key(self, tmp_path):
        from app.services.connections import AuthMethod, SnowflakeProfileIn

        private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode()

        store = ConnectionStore(tmp_path, tmp_path / ".key")
        profile = store.create(
            SnowflakeProfileIn(
                name="n",
                account="acct",
                user="u",
                auth_method=AuthMethod.KEY_PAIR,
                private_key_pem=pem,
                private_key_passphrase="unused-passphrase",
            )
        )

        kwargs = store.connector_kwargs(profile.id, query_tag="pbic:test")
        assert isinstance(kwargs["private_key"], bytes)
        assert kwargs["session_parameters"]["QUERY_TAG"] == "pbic:test"

    def test_connector_kwargs_key_pair_rejects_invalid_pem_with_value_error(self, tmp_path):
        from app.services.connections import AuthMethod, SnowflakeProfileIn

        store = ConnectionStore(tmp_path, tmp_path / ".key")
        profile = store.create(
            SnowflakeProfileIn(
                name="n",
                account="acct",
                user="u",
                auth_method=AuthMethod.KEY_PAIR,
                private_key_pem="not-a-pem",
            )
        )

        with pytest.raises(ValueError):
            store.connector_kwargs(profile.id, query_tag="pbic:test")

    def test_secrets_encrypted_on_disk(self, tmp_path):
        from app.services.connections import AuthMethod, SnowflakeProfileIn

        store = ConnectionStore(tmp_path, tmp_path / ".key")
        store.create(
            SnowflakeProfileIn(
                name="n", account="a", user="u", auth_method=AuthMethod.PASSWORD, password="pw"
            )
        )
        raw = next((tmp_path / "connections").glob("*.json")).read_text()
        assert '"password": "pw"' not in raw

    def test_mcp_env_password(self, tmp_path):
        from app.services.connections import AuthMethod, SnowflakeProfileIn

        store = ConnectionStore(tmp_path, tmp_path / ".key")
        p = store.create(
            SnowflakeProfileIn(
                name="n",
                account="acct",
                user="u",
                auth_method=AuthMethod.PASSWORD,
                password="pw",
                warehouse="WH",
            )
        )
        env = store.mcp_env(p.id)
        assert env["SNOWFLAKE_ACCOUNT"] == "acct"
        assert env["SNOWFLAKE_PASSWORD"] == "pw"
        assert env["SNOWFLAKE_WAREHOUSE"] == "WH"


class TestDualRunParityApi:
    def test_dual_run_parity_persists_and_reads_back(self, client, contoso_pbip, monkeypatch):
        import re

        data = zip_folder(contoso_pbip)
        upload = client.post(
            "/api/v1/conversions",
            files={"file": ("contoso.zip", data, "application/zip")},
        )
        assert upload.status_code == 201, upload.text
        cid = upload.json()["id"]

        profile = client.post(
            "/api/v1/connections",
            json={
                "name": "demo",
                "account": "acct",
                "user": "user",
                "auth_method": "password",
                "password": "pw",
            },
        )
        assert profile.status_code == 201, profile.text
        conn_id = profile.json()["id"]

        class FakeCursor:
            def __init__(self):
                self.description = []
                self._rows = []

            def execute(self, sql: str):
                cols = re.findall(r'AS "([^"]+)"', sql)
                if not cols:
                    cols = ["RESULT"]
                self.description = [(c,) for c in cols]
                rows = []
                for i in range(2):
                    row = []
                    for c in cols:
                        if "." in c:
                            row.append(f"v{i}")
                        else:
                            row.append(float(100 + i))
                    rows.append(tuple(row))
                self._rows = rows

            def fetchall(self):
                return self._rows

        class FakeConn:
            def cursor(self):
                return FakeCursor()

            def close(self):
                return None

        monkeypatch.setattr(
            "app.api.dashboards.get_ingest_service",
            app.dependency_overrides[get_ingest_service],
        )
        monkeypatch.setattr("app.api.dashboards._connect", lambda *_args, **_kwargs: FakeConn())

        run = client.post(
            f"/api/v1/conversions/{cid}/dashboard/parity/dual-run",
            json={"connection_id": conn_id},
        )
        assert run.status_code == 200, run.text
        payload = run.json()
        assert "summary" in payload
        assert payload["summary"]["visuals_total"] > 0

        fetched = client.get(f"/api/v1/conversions/{cid}/dashboard/parity/dual-run")
        assert fetched.status_code == 200, fetched.text
        fetched_payload = fetched.json()
        assert fetched_payload["summary"] == payload["summary"]


    class TestGovernanceApi:
        def test_review_queue_and_decision_persist(self, client, contoso_pbip):
            data = zip_folder(contoso_pbip)
            upload = client.post(
                "/api/v1/conversions",
                files={"file": ("contoso.zip", data, "application/zip")},
            )
            assert upload.status_code == 201, upload.text
            cid = upload.json()["id"]

            svc = app.dependency_overrides[get_ingest_service]()
            bundle = svc.load_bundle(cid)
            page = bundle.report.pages[0]
            visual = page.visuals[0]
            conv_dir = svc.conversion_dir(cid)
            run_file = conv_dir / "conversion_run.json"
            run_file.write_text(
                json.dumps(
                    {
                        "summary": {"overall_score": 0.42, "visuals_failed": 1, "visuals_passed": 0},
                        "fidelity": {
                            "pages": [
                                {
                                    "page": page.name,
                                    "display_name": page.display_name or page.name,
                                    "visuals": [
                                        {
                                            "visual": visual.name,
                                            "title": visual.title,
                                            "visual_type": visual.visual_type,
                                            "checks": [
                                                {
                                                    "name": "render",
                                                    "status": "failed",
                                                    "detail": "synthetic parity failure",
                                                }
                                            ],
                                        }
                                    ],
                                }
                            ]
                        },
                    }
                )
            )

            workspace = client.get(f"/api/v1/conversions/{cid}/governance")
            assert workspace.status_code == 200, workspace.text
            payload = workspace.json()
            assert payload["summary"]["review"]["total"] >= 1
            review = payload["reviews"][0]

            decision = client.post(
                f"/api/v1/conversions/{cid}/governance/reviews/{review['id']}/decision",
                json={"decision": "approved", "comment": "looks good", "owner": "qa"},
            )
            assert decision.status_code == 200, decision.text

            refreshed = client.get(f"/api/v1/conversions/{cid}/governance")
            assert refreshed.status_code == 200
            refreshed_review = next(r for r in refreshed.json()["reviews"] if r["id"] == review["id"])
            assert refreshed_review["status"] == "approved"
            assert refreshed_review["decision"]["decision"] == "approved"

            impact = client.get(
                f"/api/v1/conversions/{cid}/governance/impact/{review['subject_kind']}/{review['subject_id']}"
            )
            assert impact.status_code == 200, impact.text
            assert impact.json()["subject"]["id"] == review["id"]
            assert impact.json()["impact"]

            provenance = client.get(
                f"/api/v1/conversions/{cid}/governance/provenance/{review['subject_kind']}/{review['subject_id']}"
            )
            assert provenance.status_code == 200, provenance.text
            assert provenance.json()["provenance"]["nodes"]

            lifecycle = client.get(f"/api/v1/conversions/{cid}/governance/lifecycle")
            assert lifecycle.status_code == 200, lifecycle.text
            assert lifecycle.json()["state"] in {"draft", "certified"}

            updated = client.post(
                f"/api/v1/conversions/{cid}/governance/lifecycle",
                json={"action": "demote", "owner": "qa", "reason": "test"},
            )
            assert updated.status_code == 200, updated.text
            assert updated.json()["state"] == "draft"

            history = client.get(f"/api/v1/conversions/{cid}/governance/history")
            assert history.status_code == 200
            assert history.json()["promotion_history"]

        def test_review_remediation_applies_override_and_revalidates(self, client, contoso_pbip, monkeypatch):
            data = zip_folder(contoso_pbip)
            upload = client.post(
                "/api/v1/conversions",
                files={"file": ("contoso.zip", data, "application/zip")},
            )
            assert upload.status_code == 201, upload.text
            cid = upload.json()["id"]

            profile = client.post(
                "/api/v1/connections",
                json={
                    "name": "demo",
                    "account": "acct",
                    "user": "user",
                    "database": "ANALYTICS",
                    "schema": "PUBLIC",
                    "warehouse": "ANALYTICS_WH",
                    "auth_method": "password",
                    "password": "pw",
                },
            )
            assert profile.status_code == 201, profile.text
            conn_id = profile.json()["id"]

            svc = app.dependency_overrides[get_ingest_service]()
            bundle = svc.load_bundle(cid)
            page = bundle.report.pages[0]
            visual = page.visuals[0]
            conv_dir = svc.conversion_dir(cid)
            (conv_dir / "conversion_run.json").write_text(
                json.dumps(
                    {
                        "fidelity": {
                            "pages": [
                                {
                                    "page": page.name,
                                    "display_name": page.display_name or page.name,
                                    "visuals": [
                                        {
                                            "visual": visual.name,
                                            "title": visual.title,
                                            "visual_type": visual.visual_type,
                                            "checks": [
                                                {
                                                    "name": "render",
                                                    "status": "failed",
                                                    "detail": "synthetic parity failure",
                                                }
                                            ],
                                        }
                                    ],
                                }
                            ]
                        }
                    }
                )
            )

            monkeypatch.setattr(
                "app.api.governance._propose_override",
                lambda *_args, **_kwargs: {
                    "op": "set_title",
                    "page": page.name,
                    "visual": visual.name,
                    "value": "Fixed Title",
                },
            )

            class FakeCursor:
                pass

            class FakeConn:
                def cursor(self):
                    return FakeCursor()

                def close(self):
                    return None

            monkeypatch.setattr("app.api.governance._connect", lambda *_args, **_kwargs: FakeConn())
            monkeypatch.setattr(
                "app.api.governance.run_validation",
                lambda *_args, **_kwargs: FidelityReport(
                    report_name="R",
                    pages=[
                        PageScore(
                            page=page.name,
                            display_name=page.display_name or page.name,
                            visuals=[
                                VisualScore(
                                    visual=visual.name,
                                    page=page.name,
                                    visual_type=visual.visual_type,
                                    checks=[Check(name="compile", status=CheckStatus.PASSED, detail="")],
                                )
                            ],
                        )
                    ],
                ),
            )

            workspace = client.get(f"/api/v1/conversions/{cid}/governance")
            review_id = workspace.json()["reviews"][0]["id"]
            resp = client.post(
                f"/api/v1/conversions/{cid}/governance/reviews/{review_id}/remediate",
                json={
                    "connection_id": conn_id,
                    "instruction": "Rename the visual title to Fixed Title",
                    "owner": "qa",
                },
            )
            assert resp.status_code == 200, resp.text
            payload = resp.json()
            assert payload["fixed"] is True
            assert payload["applied_override"]["op"] == "set_title"
            assert payload["history"]
            overrides = json.loads((conv_dir / "spec_overrides.json").read_text())
            assert overrides[-1]["value"] == "Fixed Title"

            refreshed = client.get(f"/api/v1/conversions/{cid}/governance")
            review = refreshed.json()["reviews"][0]
            assert review["remediation_history"]

        def test_review_question_persists_history(self, client, contoso_pbip, monkeypatch):
            data = zip_folder(contoso_pbip)
            upload = client.post(
                "/api/v1/conversions",
                files={"file": ("contoso.zip", data, "application/zip")},
            )
            assert upload.status_code == 201, upload.text
            cid = upload.json()["id"]

            svc = app.dependency_overrides[get_ingest_service]()
            bundle = svc.load_bundle(cid)
            page = bundle.report.pages[0]
            visual = page.visuals[0]
            conv_dir = svc.conversion_dir(cid)
            (conv_dir / "conversion_run.json").write_text(
                json.dumps(
                    {
                        "fidelity": {
                            "pages": [
                                {
                                    "page": page.name,
                                    "display_name": page.display_name or page.name,
                                    "visuals": [
                                        {
                                            "visual": visual.name,
                                            "title": visual.title,
                                            "visual_type": visual.visual_type,
                                            "checks": [
                                                {
                                                    "name": "render",
                                                    "status": "failed",
                                                    "detail": "synthetic parity failure",
                                                }
                                            ],
                                        }
                                    ],
                                }
                            ]
                        }
                    }
                )
            )

            monkeypatch.setattr(
                "app.api.governance._answer_review_question",
                lambda *_args, **_kwargs: "The issue failed the render parity validation.",
            )

            workspace = client.get(f"/api/v1/conversions/{cid}/governance")
            review_id = workspace.json()["reviews"][0]["id"]
            resp = client.post(
                f"/api/v1/conversions/{cid}/governance/reviews/{review_id}/ask",
                json={"question": "Why did this fail?", "owner": "qa"},
            )
            assert resp.status_code == 200, resp.text
            payload = resp.json()
            assert payload["answer"] == "The issue failed the render parity validation."
            assert payload["history"]

        def test_semantic_traceability_returns_deploy_history(self, client, contoso_pbip, monkeypatch):
            fixture = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"
            data = zip_folder(fixture)
            upload = client.post(
                "/api/v1/conversions",
                files={"file": ("medical.zip", data, "application/zip")},
            )
            assert upload.status_code == 201, upload.text
            cid = upload.json()["id"]

            profile = client.post(
                "/api/v1/connections",
                json={
                    "name": "demo",
                    "account": "acct",
                    "user": "user",
                    "database": "ANALYTICS",
                    "schema": "PUBLIC",
                    "warehouse": "ANALYTICS_WH",
                    "auth_method": "password",
                    "password": "pw",
                },
            )
            conn_id = profile.json()["id"]

            class FakeDeployCursor:
                def close(self):
                    return None

            monkeypatch.setattr(
                "app.api.semantic_deploy._open_cursor",
                lambda *_args, **_kwargs: FakeDeployCursor(),
            )
            monkeypatch.setattr(
                "app.api.semantic_deploy._call_create_sv",
                lambda *_args, **_kwargs: "created successfully",
            )

            class FakeDeployCursor:
                def __init__(self):
                    self.executed: list[str] = []

                def execute(self, sql):
                    self.executed.append(sql)

                def close(self):
                    return None

            cursor = FakeDeployCursor()
            monkeypatch.setattr(
                "app.api.semantic_deploy._open_cursor",
                lambda *_args, **_kwargs: cursor,
            )

            deploy = client.post(
                f"/api/v1/conversions/{cid}/deploy-semantic-view",
                json={
                    "connection_id": conn_id,
                    "dry_run": False,
                    "create_or_alter": True,
                },
            )
            assert deploy.status_code == 200, deploy.text
            deploy_body = deploy.json()
            assert deploy_body["partial_success"] is True
            assert deploy_body["materializations"]
            assert deploy_body["materializations"][0]["table"] == "DIM_SERVICE_LINE"
            assert deploy_body["materializations"][0]["lifecycle"] == "dynamic_table"
            assert deploy_body["materializations"][0]["target_object"].startswith("ANALYTICS.PUBLIC.")
            assert deploy_body["materialization_refresh"]["status"] == "materialized"
            assert deploy_body["materialization_refresh"]["owner"] == "demo"
            assert cursor.executed
            assert cursor.executed[0].startswith('CREATE OR REPLACE DYNAMIC TABLE "ANALYTICS"."PUBLIC".')
            assert " AS SELECT " in cursor.executed[0]

            trace = client.get(f"/api/v1/conversions/{cid}/semantic-traceability")
            assert trace.status_code == 200, trace.text
            payload = trace.json()
            assert payload["preview"]["view_name"]
            assert payload["preview"]["pbi_model"]["tables"]
            assert payload["preview"]["snowflake_view"]["tables"]
            assert "DIM_SERVICE_LINE" in payload["preview"]["materializations"][0]["target_object"]
            assert payload["preview"]["materializations"][0]["lifecycle"] == "dynamic_table"
            assert payload["preview"]["materialization_refresh"]["status"] == "materialized"
            assert payload["preview"]["materialization_refresh"]["owner"] == "demo"
            assert payload["latest"]["fully_qualified_view"].startswith("ANALYTICS.PUBLIC.")
            assert payload["latest"]["materializations"][0]["target_object"] == deploy_body["materializations"][0]["target_object"]

class TestSemanticTierQueryApi:
    def _setup_conversion_and_connection(self, client, contoso_pbip):
        data = zip_folder(contoso_pbip)
        upload = client.post(
            "/api/v1/conversions",
            files={"file": ("contoso.zip", data, "application/zip")},
        )
        assert upload.status_code == 201, upload.text
        cid = upload.json()["id"]

        profile = client.post(
            "/api/v1/connections",
            json={
                "name": "demo",
                "account": "acct",
                "user": "user",
                "warehouse": "ANALYTICS_WH",
                "auth_method": "password",
                "password": "pw",
            },
        )
        assert profile.status_code == 201, profile.text
        conn_id = profile.json()["id"]
        return cid, conn_id

    def _pick_query_target(self, client, cid: str, monkeypatch):
        monkeypatch.setattr(
            "app.api.dashboards.get_ingest_service",
            app.dependency_overrides[get_ingest_service],
        )
        spec = client.get(f"/api/v1/conversions/{cid}/dashboard/spec")
        assert spec.status_code == 200, spec.text
        body = spec.json()
        for p in body["pages"]:
            for v in p["visuals"]:
                if v.get("query") is not None and v.get("supported", True):
                    return p["name"], v["name"]
        raise AssertionError("no queryable visual found")

    def test_tier_a_query_uses_semantic_traces(self, client, contoso_pbip, monkeypatch):
        cid, conn_id = self._setup_conversion_and_connection(client, contoso_pbip)
        page, visual = self._pick_query_target(client, cid, monkeypatch)

        class FakeCursor:
            def __init__(self):
                self.description = []
                self._rows = []

            def execute(self, _sql: str):
                self.description = [("Value",)]
                self._rows = [(123.0,)]

            def fetchall(self):
                return self._rows

        class FakeConn:
            def cursor(self):
                return FakeCursor()

            def close(self):
                return None

        monkeypatch.setattr(
            "app.api.dashboards.get_ingest_service",
            app.dependency_overrides[get_ingest_service],
        )
        monkeypatch.setattr("app.api.dashboards._connect", lambda *_args, **_kwargs: FakeConn())

        def _fake_build_sql(self, req):  # noqa: ARG001
            return SemanticViewPlan(sql='SELECT 123 AS "Value"', trace_codes=["SV_NATIVE", "SV_MODEL_VERSION"])

        monkeypatch.setattr("app.api.dashboards.SemanticViewAdapter.build_sql", _fake_build_sql)

        resp = client.post(
            f"/api/v1/conversions/{cid}/dashboard/query",
            json={
                "connection_id": conn_id,
                "queries": [{"page": page, "visual": visual, "filters": []}],
                "execution_tier": "tier_a_native",
                "allow_tier_a_fallback": False,
            },
        )
        assert resp.status_code == 200, resp.text
        payload = resp.json()["results"][0]
        assert payload["error"] is None
        assert payload["execution_tier"] == "tier_a_native"
        assert "SV_NATIVE" in payload["trace_codes"]

    def test_tier_a_query_no_fallback_returns_visual_error(self, client, contoso_pbip, monkeypatch):
        cid, conn_id = self._setup_conversion_and_connection(client, contoso_pbip)
        page, visual = self._pick_query_target(client, cid, monkeypatch)

        monkeypatch.setattr(
            "app.api.dashboards.get_ingest_service",
            app.dependency_overrides[get_ingest_service],
        )

        def _raise_plan_error(self, _req):
            raise SemanticViewPlanError("semantic plan unavailable")

        monkeypatch.setattr("app.api.dashboards.SemanticViewAdapter.build_sql", _raise_plan_error)

        resp = client.post(
            f"/api/v1/conversions/{cid}/dashboard/query",
            json={
                "connection_id": conn_id,
                "queries": [{"page": page, "visual": visual, "filters": []}],
                "execution_tier": "tier_a_native",
                "allow_tier_a_fallback": False,
            },
        )
        assert resp.status_code == 200, resp.text
        payload = resp.json()["results"][0]
        assert payload["error"] is not None
        assert "semantic plan unavailable" in payload["error"]

    def test_tier_a_query_fallback_records_execution_path(self, client, contoso_pbip, monkeypatch):
        cid, conn_id = self._setup_conversion_and_connection(client, contoso_pbip)
        page, visual = self._pick_query_target(client, cid, monkeypatch)

        class FakeCursor:
            def __init__(self):
                self.description = []
                self._rows = []

            def execute(self, _sql: str):
                self.description = [("Value",)]
                self._rows = [(55.0,)]

            def fetchall(self):
                return self._rows

        class FakeConn:
            def cursor(self):
                return FakeCursor()

            def close(self):
                return None

        monkeypatch.setattr(
            "app.api.dashboards.get_ingest_service",
            app.dependency_overrides[get_ingest_service],
        )
        monkeypatch.setattr("app.api.dashboards._connect", lambda *_args, **_kwargs: FakeConn())

        def _raise_plan_error(self, _req):
            raise SemanticViewPlanError("semantic coverage missing")

        monkeypatch.setattr("app.api.dashboards.SemanticViewAdapter.build_sql", _raise_plan_error)
        monkeypatch.setattr(
            "app.api.dashboards.SemanticEngine.build_sql",
            lambda self, query: ('SELECT 55 AS "Value"', []),
        )

        resp = client.post(
            f"/api/v1/conversions/{cid}/dashboard/query",
            json={
                "connection_id": conn_id,
                "queries": [{"page": page, "visual": visual, "filters": []}],
                "execution_tier": "tier_a_native",
                "allow_tier_a_fallback": True,
            },
        )
        assert resp.status_code == 200, resp.text
        payload = resp.json()["results"][0]
        assert payload["execution_path"] == "compatibility"
        assert payload["fallback_reason"] == "semantic-view coverage missing"

    def test_semantic_view_execution_error_falls_back_to_compatibility(
        self, client, contoso_pbip, monkeypatch
    ):
        """Snowflake can reject a plannable semantic-view query at execution time
        (e.g. unrelated entities); the visual must still render via compat SQL."""
        cid, conn_id = self._setup_conversion_and_connection(client, contoso_pbip)
        page, visual = self._pick_query_target(client, cid, monkeypatch)

        class FakeCursor:
            def __init__(self):
                self.description = []
                self._rows = []

            def execute(self, sql: str):
                if "SEMANTIC_VIEW" in sql:
                    raise RuntimeError(
                        "010959 (42601): The entities 'A' and 'B' are not related."
                    )
                self.description = [("Value",)]
                self._rows = [(77.0,)]

            def fetchall(self):
                return self._rows

        class FakeConn:
            def cursor(self):
                return FakeCursor()

            def close(self):
                return None

        monkeypatch.setattr(
            "app.api.dashboards.get_ingest_service",
            app.dependency_overrides[get_ingest_service],
        )
        monkeypatch.setattr("app.api.dashboards._connect", lambda *_a, **_k: FakeConn())
        monkeypatch.setattr(
            "app.api.dashboards.SemanticViewAdapter.build_sql",
            lambda self, _req: SimpleNamespace(
                sql='SELECT * FROM SEMANTIC_VIEW(v METRICS m)', warnings=[], trace_codes=[]
            ),
        )
        monkeypatch.setattr(
            "app.api.dashboards.SemanticEngine.build_sql",
            lambda self, query: ('SELECT 77 AS "Value"', []),
        )

        resp = client.post(
            f"/api/v1/conversions/{cid}/dashboard/query",
            json={
                "connection_id": conn_id,
                "queries": [{"page": page, "visual": visual, "filters": []}],
                "execution_tier": "tier_a_native",
                "allow_tier_a_fallback": True,
            },
        )
        assert resp.status_code == 200, resp.text
        payload = resp.json()["results"][0]
        assert payload["error"] is None
        assert payload["rows"] == [[77.0]]
        assert payload["execution_path"] == "compatibility"
        assert "not related" in payload["fallback_reason"]

    def test_static_textbox_is_not_reported_as_an_error(self, client, monkeypatch):
        """Textboxes carry no query; asking for their data must not surface an
        'unsupported visual' error in the dashboard."""
        fixture = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"
        upload = client.post(
            "/api/v1/conversions",
            files={"file": ("medical.zip", zip_folder(fixture), "application/zip")},
        )
        assert upload.status_code == 201, upload.text
        cid = upload.json()["id"]
        monkeypatch.setattr(
            "app.api.dashboards.get_ingest_service",
            app.dependency_overrides[get_ingest_service],
        )
        spec = client.get(f"/api/v1/conversions/{cid}/dashboard/spec").json()
        page, visual = next(
            (p["name"], v["name"])
            for p in spec["pages"]
            for v in p["visuals"]
            if v["visual_type"] == "textbox"
        )

        resp = client.post(
            f"/api/v1/conversions/{cid}/dashboard/query",
            json={"connection_id": "unused", "queries": [{"page": page, "visual": visual}]},
        )
        assert resp.status_code == 200, resp.text
        payload = resp.json()["results"][0]
        assert payload["error"] is None
        assert payload["execution_path"] == "static"


class TestMaterializationBindingHydration:
    def test_materialization_required_binding_is_resolved_from_deployment(self):
        bm = BindingMap(
            bindings={
                "DIM_SERVICE_LINE": TableBinding(
                    table="DIM_SERVICE_LINE",
                    status="materialization_required",
                    database="SRC_DB",
                    schema_name="SRC_SCHEMA",
                    object_name="DIM_SERVICE_LINE",
                    materialization_strategy="dynamic_table",
                    materialization_sql="SELECT 1",
                )
            }
        )

        deployment = {
            "database": "TGT_DB",
            "schema_name": "TGT_SCHEMA",
            "materializations": [
                {
                    "table": "DIM_SERVICE_LINE",
                    "target_object": "TGT_DB.TGT_SCHEMA.MODEL_SV__DT__DIM_SERVICE_LINE",
                    "lifecycle": "dynamic_table",
                }
            ],
        }

        updated = _apply_deployed_materializations(bm, deployment)
        bound = updated.get("DIM_SERVICE_LINE")
        assert bound is not None
        assert bound.status == "resolved"
        assert bound.database == "TGT_DB"
        assert bound.schema_name == "TGT_SCHEMA"
        assert bound.object_name == "MODEL_SV__DT__DIM_SERVICE_LINE"
        assert bound.object_kind == "dynamic_table"

    def test_non_materialization_binding_is_not_overwritten(self):
        bm = BindingMap(
            bindings={
                "FACT_CLAIMS": TableBinding(
                    table="FACT_CLAIMS",
                    status="resolved",
                    database="SRC_DB",
                    schema_name="SRC_SCHEMA",
                    object_name="FACT_CLAIMS",
                )
            }
        )

        deployment = {
            "database": "TGT_DB",
            "schema_name": "TGT_SCHEMA",
            "materializations": [
                {
                    "table": "FACT_CLAIMS",
                    "target_object": "TGT_DB.TGT_SCHEMA.MODEL_SV__DT__FACT_CLAIMS",
                    "lifecycle": "dynamic_table",
                }
            ],
        }

        updated = _apply_deployed_materializations(bm, deployment)
        bound = updated.get("FACT_CLAIMS")
        assert bound is not None
        assert bound.status == "resolved"
        assert bound.database == "SRC_DB"
        assert bound.schema_name == "SRC_SCHEMA"
        assert bound.object_name == "FACT_CLAIMS"


class TestAskDataApi:
    def test_ask_data_refuses_low_confidence_by_policy(self, client, contoso_pbip, monkeypatch):
        data = zip_folder(contoso_pbip)
        upload = client.post(
            "/api/v1/conversions",
            files={"file": ("contoso.zip", data, "application/zip")},
        )
        assert upload.status_code == 201, upload.text
        cid = upload.json()["id"]

        profile = client.post(
            "/api/v1/connections",
            json={
                "name": "demo",
                "account": "acct",
                "user": "user",
                "auth_method": "password",
                "password": "pw",
            },
        )
        assert profile.status_code == 201, profile.text
        conn_id = profile.json()["id"]

        monkeypatch.setattr(
            "app.api.dashboards.get_ingest_service",
            app.dependency_overrides[get_ingest_service],
        )

        resp = client.post(
            f"/api/v1/conversions/{cid}/dashboard/ask",
            json={
                "connection_id": conn_id,
                "question": "low confidence prompt",
                "question_class": "unknown",
                "confidence": 0.4,
                "measures": [{"column": "Revenue", "aggregate": "SUM"}],
            },
        )
        assert resp.status_code == 422
        assert "low confidence" in resp.json()["detail"]

    def test_ask_data_can_fallback_when_allowed(self, client, contoso_pbip, monkeypatch):
        data = zip_folder(contoso_pbip)
        upload = client.post(
            "/api/v1/conversions",
            files={"file": ("contoso.zip", data, "application/zip")},
        )
        assert upload.status_code == 201, upload.text
        cid = upload.json()["id"]

        profile = client.post(
            "/api/v1/connections",
            json={
                "name": "demo",
                "account": "acct",
                "user": "user",
                "auth_method": "password",
                "password": "pw",
            },
        )
        assert profile.status_code == 201, profile.text
        conn_id = profile.json()["id"]

        class FakeCursor:
            def __init__(self):
                self.description = []
                self._rows = []

            def execute(self, _sql: str):
                self.description = [("Value",)]
                self._rows = [(55.0,)]

            def fetchall(self):
                return self._rows

        class FakeConn:
            def cursor(self):
                return FakeCursor()

            def close(self):
                return None

        monkeypatch.setattr(
            "app.api.dashboards.get_ingest_service",
            app.dependency_overrides[get_ingest_service],
        )
        monkeypatch.setattr("app.api.dashboards._connect", lambda *_args, **_kwargs: FakeConn())

        def _raise_plan_error(self, _req):
            raise SemanticViewPlanError("no semantic coverage")

        monkeypatch.setattr("app.api.dashboards.SemanticViewAdapter.build_sql", _raise_plan_error)
        monkeypatch.setattr(
            "app.api.dashboards.SemanticEngine.build_sql",
            lambda self, query: ('SELECT 55 AS "Value"', []),
        )

        resp = client.post(
            f"/api/v1/conversions/{cid}/dashboard/ask",
            json={
                "connection_id": conn_id,
                "question": "fallback prompt",
                "question_class": "general",
                "confidence": 0.95,
                "allow_fallback": True,
                "measures": [{"name": "AnyMeasure"}],
            },
        )
        assert resp.status_code == 200, resp.text
        payload = resp.json()
        assert payload["fallback_used"] is True
        assert payload["fallback_allowed"] is True
        assert payload["execution_path"] == "compatibility"
        assert payload["fallback_reason"] == "semantic-view coverage missing"
        assert "ASKDATA_FALLBACK" in payload["trace_codes"]

    def test_semantic_traceability_reports_materialization_plan(self, client):
        fixture = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"
        data = zip_folder(fixture)
        upload = client.post(
            "/api/v1/conversions",
            files={"file": ("medical.zip", data, "application/zip")},
        )
        assert upload.status_code == 201, upload.text
        cid = upload.json()["id"]

        trace = client.get(f"/api/v1/conversions/{cid}/semantic-traceability")
        assert trace.status_code == 200, trace.text
        payload = trace.json()["preview"]
        assert payload["binding_summary"]["materialization_required"] == 1
        assert payload["materializations"]
        assert payload["materializations"][0]["table"] == "DIM_SERVICE_LINE"
        assert "GROUP BY" in payload["materializations"][0]["sql"]
