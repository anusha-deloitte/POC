"""TMDL (Tabular Model Definition Language) parser -> PBI-IR SemanticModel.

Line-oriented recursive descent over an indentation stack. TMDL expression
bodies (DAX/M) are verbatim text, which token grammars handle poorly; this
mirrors how the format is specified: declarations, `key: value` properties,
`= expr` defaults (single- or multi-line), /// descriptions, ``` fences.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from app.ir.model import (
    Column,
    DataType,
    Hierarchy,
    HierarchyLevel,
    Measure,
    Partition,
    PartitionMode,
    Relationship,
    Role,
    SemanticModel,
    SummarizeBy,
    Table,
)

_AUTO_DATE_RE = re.compile(r"^(LocalDateTable_|DateTableTemplate_)")


class TmdlParseError(Exception):
    def __init__(self, message: str, file: str | None = None, line: int | None = None):
        loc = f"{file or '<str>'}:{line}" if line else file or "<str>"
        super().__init__(f"{loc}: {message}")
        self.file = file
        self.line = line


@dataclass
class _Line:
    indent: int
    text: str  # stripped content
    raw: str
    no: int


@dataclass
class _Node:
    """Generic parsed TMDL object before IR mapping."""

    kind: str
    name: str
    default_value: str = ""  # text after `=` on the declaration line or multi-line body
    properties: dict[str, str] = field(default_factory=dict)
    expression_props: dict[str, str] = field(default_factory=dict)  # `prop =` bodies
    children: list[_Node] = field(default_factory=list)
    description: str = ""
    bool_props: set[str] = field(default_factory=set)


def _indent_of(raw: str) -> int:
    """One level per tab; 4 spaces count as one level."""
    n = 0
    i = 0
    spaces = 0
    while i < len(raw):
        ch = raw[i]
        if ch == "\t":
            n += 1 + spaces // 4
            spaces = 0
        elif ch == " ":
            spaces += 1
            if spaces == 4:
                n += 1
                spaces = 0
        else:
            break
        i += 1
    return n


def _logical_lines(text: str) -> list[_Line]:
    out: list[_Line] = []
    for no, raw in enumerate(text.splitlines(), start=1):
        stripped = raw.strip()
        if not stripped:
            continue
        out.append(_Line(_indent_of(raw), stripped, raw, no))
    return out


_DECL_KINDS = {
    "database",
    "model",
    "table",
    "column",
    "measure",
    "partition",
    "hierarchy",
    "level",
    "relationship",
    "role",
    "tablePermission",
    "expression",
    "annotation",
    "perspective",
    "culture",
    "cultureInfo",
    "dataAccessOptions",
    "extendedProperty",
    "variation",
    "calculationGroup",
    "calculationItem",
    "function",
    "ref",
}

_IDENT_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")


def _read_name(rest: str) -> tuple[str, str]:
    """Consume an optionally-quoted object name; return (name, remainder)."""
    rest = rest.lstrip()
    if rest.startswith("'"):
        i = 1
        buf: list[str] = []
        while i < len(rest):
            if rest[i] == "'":
                if i + 1 < len(rest) and rest[i + 1] == "'":
                    buf.append("'")
                    i += 2
                    continue
                i += 1
                break
            buf.append(rest[i])
            i += 1
        return "".join(buf), rest[i:].strip()
    # unquoted names cannot contain dots (spec requires quoting), so stop there
    m = re.match(r"[^\s=:.]+", rest)
    if not m:
        return "", rest
    return m.group(0), rest[m.end() :].strip()


class _Parser:
    def __init__(self, lines: list[_Line], file: str | None = None):
        self.lines = lines
        self.pos = 0
        self.file = file

    def peek(self) -> _Line | None:
        return self.lines[self.pos] if self.pos < len(self.lines) else None

    def parse_block(self, indent: int) -> list[_Node]:
        """Parse consecutive object declarations at exactly `indent`."""
        nodes: list[_Node] = []
        pending_desc: list[str] = []
        while (ln := self.peek()) is not None:
            if ln.indent < indent:
                break
            if ln.indent > indent:
                raise TmdlParseError(
                    f"unexpected indent {ln.indent} (expected {indent}): {ln.text!r}",
                    self.file,
                    ln.no,
                )
            if ln.text.startswith("///"):
                pending_desc.append(ln.text[3:].strip())
                self.pos += 1
                continue
            node = self.parse_object(indent)
            node.description = " ".join(pending_desc)
            pending_desc = []
            nodes.append(node)
        return nodes

    def parse_object(self, indent: int) -> _Node:
        ln = self.peek()
        assert ln is not None
        first, _rest = ln.text.split(None, 1) if " " in ln.text else (ln.text, "")
        kind = first
        if kind not in _DECL_KINDS:
            # preview formats drift: tolerate unknown-but-wellformed declarations
            if not _IDENT_RE.match(kind):
                raise TmdlParseError(f"unknown declaration {kind!r}", self.file, ln.no)
        self.pos += 1

        rest = ln.text[len(kind) :].strip()
        if kind == "ref":
            # `ref table X` ordering hint — capture and move on
            return _Node(kind="ref", name=rest)

        name, remainder = _read_name(rest)
        node = _Node(kind=kind, name=name)

        if remainder.startswith("="):
            value = remainder[1:].strip()
            if value == "```" or value == "":
                node.default_value = self._read_expression_body(indent, fenced=value == "```")
            else:
                node.default_value = value
        elif remainder.startswith(":"):
            # e.g. `annotation X : y` — normalize to default value
            node.default_value = remainder[1:].strip()

        self._parse_members(node, indent + 1)
        return node

    def _parse_members(self, node: _Node, indent: int) -> None:
        while (ln := self.peek()) is not None:
            if ln.indent < indent:
                return
            if ln.indent > indent:
                # continuation of a single-line default into deeper indent (multi-line default)
                body = self._read_expression_body(indent - 1, fenced=False)
                node.default_value = (node.default_value + "\n" + body).strip()
                continue
            if ln.text.startswith("///"):
                self.pos += 1
                continue
            first = ln.text.split(None, 1)[0] if " " in ln.text else ln.text
            key_candidate = first.rstrip(":")
            if first in _DECL_KINDS:
                node.children.extend(self.parse_block(indent))
                continue
            # property line
            self.pos += 1
            if ":" in ln.text:
                key, _, val = ln.text.partition(":")
                v = val.strip()
                # only paired outer quotes are delimiters; a lone trailing quote
                # is part of the value (e.g. formatString: \$#,0.0,,"M")
                if len(v) >= 2 and v[0] == '"' and v[-1] == '"':
                    v = v[1:-1]
                node.properties[key.strip()] = v
            elif "=" in ln.text:
                key, _, val = ln.text.partition("=")
                key = key.strip()
                val = val.strip()
                if val == "" or val == "```":
                    node.expression_props[key] = self._read_expression_body(
                        indent, fenced=val == "```"
                    )
                else:
                    node.expression_props[key] = val
            else:
                node.bool_props.add(key_candidate)

    def _read_expression_body(self, decl_indent: int, fenced: bool) -> str:
        """Collect verbatim lines deeper than decl_indent+1 (or until closing fence)."""
        collected: list[str] = []
        while (ln := self.peek()) is not None:
            if fenced:
                if ln.text == "```":
                    self.pos += 1
                    break
                collected.append(ln.raw)
                self.pos += 1
                continue
            if ln.indent <= decl_indent + 1:
                break
            collected.append(ln.raw)
            self.pos += 1
        if not collected:
            return ""
        # dedent by common leading whitespace
        prefix_len = min(len(r) - len(r.lstrip()) for r in collected if r.strip())
        return "\n".join(r[prefix_len:] if r.strip() else "" for r in collected).strip("\n")


# ---------- IR mapping ----------


def _to_data_type(v: str | None) -> DataType:
    if not v:
        return DataType.UNKNOWN
    try:
        return DataType(v[0].lower() + v[1:]) if v[0].isupper() else DataType(v)
    except ValueError:
        return DataType.UNKNOWN


def _to_summarize(v: str | None) -> SummarizeBy:
    if not v:
        return SummarizeBy.DEFAULT
    try:
        return SummarizeBy(v)
    except ValueError:
        return SummarizeBy.DEFAULT


def _map_column(n: _Node) -> Column:
    return Column(
        name=n.name,
        data_type=_to_data_type(n.properties.get("dataType")),
        source_column=n.properties.get("sourceColumn"),
        format_string=n.properties.get("formatString"),
        summarize_by=_to_summarize(n.properties.get("summarizeBy")),
        sort_by_column=n.properties.get("sortByColumn"),
        is_hidden="isHidden" in n.bool_props or n.properties.get("isHidden") == "true",
        is_key="isKey" in n.bool_props or n.properties.get("isKey") == "true",
        description=n.description or None,
        expression=n.default_value or None,
        lineage_tag=n.properties.get("lineageTag"),
        annotations={c.name: c.default_value for c in n.children if c.kind == "annotation"},
    )


def _map_measure(n: _Node) -> Measure:
    return Measure(
        name=n.name,
        expression=n.default_value,
        format_string=n.properties.get("formatString"),
        display_folder=n.properties.get("displayFolder"),
        is_hidden="isHidden" in n.bool_props,
        description=n.description or None,
        lineage_tag=n.properties.get("lineageTag"),
        annotations={c.name: c.default_value for c in n.children if c.kind == "annotation"},
    )


def _map_partition(n: _Node) -> Partition:
    mode = n.properties.get("mode", "unknown")
    try:
        pmode = PartitionMode(mode)
    except ValueError:
        pmode = PartitionMode.UNKNOWN
    return Partition(
        name=n.name,
        mode=pmode,
        source_type=n.default_value or "m",
        expression=n.expression_props.get("source", ""),
    )


def _map_hierarchy(n: _Node) -> Hierarchy:
    levels = [
        HierarchyLevel(
            name=c.name,
            column=_read_name(c.properties.get("column", c.name))[0],
            ordinal=int(c.properties.get("ordinal", "0")),
        )
        for c in n.children
        if c.kind == "level"
    ]
    return Hierarchy(
        name=n.name,
        levels=sorted(levels, key=lambda x: x.ordinal),
        is_hidden="isHidden" in n.bool_props,
        lineage_tag=n.properties.get("lineageTag"),
    )


def _map_table(n: _Node) -> Table:
    return Table(
        name=n.name,
        columns=[_map_column(c) for c in n.children if c.kind == "column"],
        measures=[_map_measure(c) for c in n.children if c.kind == "measure"],
        hierarchies=[_map_hierarchy(c) for c in n.children if c.kind == "hierarchy"],
        partitions=[_map_partition(c) for c in n.children if c.kind == "partition"],
        is_hidden="isHidden" in n.bool_props,
        description=n.description or None,
        lineage_tag=n.properties.get("lineageTag"),
        is_auto_date_table=bool(_AUTO_DATE_RE.match(n.name)),
        annotations={c.name: c.default_value for c in n.children if c.kind == "annotation"},
    )


def _split_column_ref(ref: str) -> tuple[str, str]:
    """`Sales.ProductKey` or `'Table 1'.'Col 1'` -> (table, column)."""
    table, rest = _read_name(ref)
    if rest.startswith("."):
        col, _ = _read_name(rest[1:])
        return table, col
    return table, rest.lstrip(".")


def _map_relationship(n: _Node) -> Relationship:
    ft, fc = _split_column_ref(n.properties.get("fromColumn", ""))
    tt, tc = _split_column_ref(n.properties.get("toColumn", ""))
    return Relationship(
        name=n.name,
        from_table=ft,
        from_column=fc,
        to_table=tt,
        to_column=tc,
        from_cardinality=n.properties.get("fromCardinality", "many"),
        to_cardinality=n.properties.get("toCardinality", "one"),
        cross_filtering_behavior=n.properties.get("crossFilteringBehavior", "singleDirection"),
        is_active=n.properties.get("isActive", "true") != "false",
        security_filtering_behavior=n.properties.get("securityFilteringBehavior"),
    )


def _map_role(n: _Node) -> Role:
    perms: dict[str, str] = {}
    for c in n.children:
        if c.kind == "tablePermission":
            perms[c.name] = c.default_value
    return Role(
        name=n.name,
        model_permission=n.properties.get("modelPermission", "read"),
        table_permissions=perms,
    )


def parse_tmdl_source(text: str, file: str | None = None) -> list[_Node]:
    return _Parser(_logical_lines(text), file).parse_block(0)


def parse_tmdl_folder(definition_dir: Path) -> SemanticModel:
    """Parse a semantic-model `definition/` folder into the IR."""
    if not definition_dir.is_dir():
        raise TmdlParseError(f"not a directory: {definition_dir}")

    model = SemanticModel()
    nodes: list[_Node] = []
    for path in sorted(definition_dir.rglob("*.tmdl")):
        nodes.extend(parse_tmdl_source(path.read_text(encoding="utf-8"), str(path)))

    for n in nodes:
        match n.kind:
            case "model":
                model.name = n.name or "Model"
                model.culture = n.properties.get("culture")
                for c in n.children:
                    if c.kind == "annotation":
                        model.annotations[c.name] = c.default_value
            case "table":
                model.tables.append(_map_table(n))
            case "relationship":
                model.relationships.append(_map_relationship(n))
            case "role":
                model.roles.append(_map_role(n))
            case "expression":
                model.expressions[n.name] = n.default_value
            case "annotation":
                model.annotations[n.name] = n.default_value
            case "database" | "ref" | "culture" | "perspective" | "function":
                pass
    return model
