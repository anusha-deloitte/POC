import { useWizard } from './store/wizard'
import { AnalyzeStep } from './steps/AnalyzeStep'
import { ConnectStep } from './steps/ConnectStep'
import { ConvertStep } from './steps/ConvertStep'
import { PreviewStep } from './steps/PreviewStep'
import { ReviewStep } from './steps/ReviewStep'
import { UploadStep } from './steps/UploadStep'

/** Wizard body rendered inside the AppShell outlet at /app/convert. */
export default function App() {
  const step = useWizard((s) => s.step)
  return (
    <>
      {step === 'upload' && <UploadStep />}
      {step === 'connect' && <ConnectStep />}
      {step === 'analyze' && <AnalyzeStep />}
      {step === 'convert' && <ConvertStep />}
      {step === 'review' && <ReviewStep />}
      {step === 'preview' && <PreviewStep />}
    </>
  )
}
