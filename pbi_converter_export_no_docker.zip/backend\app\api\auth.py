from functools import lru_cache
from typing import Annotated

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel

from app.core.config import get_settings
from app.services.auth import AuthError, UserStore

router = APIRouter(prefix="/api/auth", tags=["auth"])


@lru_cache
def get_user_store() -> UserStore:
    return UserStore(get_settings().storage_dir)


class Credentials(BaseModel):
    email: str
    password: str
    name: str = ""


@router.post("/signup")
def signup(body: Credentials, store: Annotated[UserStore, Depends(get_user_store)]) -> dict:
    try:
        return store.signup(body.email, body.password, body.name)
    except AuthError as e:
        raise HTTPException(400, str(e)) from e


@router.post("/login")
def login(body: Credentials, store: Annotated[UserStore, Depends(get_user_store)]) -> dict:
    try:
        return store.login(body.email, body.password)
    except AuthError as e:
        raise HTTPException(401, str(e)) from e


@router.get("/me")
def me(
    store: Annotated[UserStore, Depends(get_user_store)],
    authorization: Annotated[str | None, Header()] = None,
) -> dict:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "missing token")
    try:
        return store.verify(authorization.removeprefix("Bearer ").strip())
    except AuthError as e:
        raise HTTPException(401, str(e)) from e
