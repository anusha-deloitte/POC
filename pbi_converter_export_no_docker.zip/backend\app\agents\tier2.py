"""Tier-2 measure fallback: OpenAI proposes Snowflake SQL for DAX the
deterministic compiler cannot handle; every proposal is executed and
validated before acceptance (LLM never ships unverified artifacts).

The accepted artifact is a SQL SELECT returning one scalar column, evaluated
over the physically-bound star schema. It is stored per conversion and the
engine treats it as an opaque native-query leaf.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass

from app.binding.resolver import BindingMap
from app.ir.model import SemanticModel

_MAX_ATTEMPTS = 3

_SYSTEM = """You translate Power BI DAX measures into Snowflake SQL.
Rules:
- Output ONLY a JSON object: {"sql": "..."} with a single SELECT returning
  exactly one numeric column aliased RESULT.
- Use only the physical tables provided (fully qualified names given).
- DIVIDE(a,b) must be IFF(b=0 OR b IS NULL, NULL, a/b).
- BLANK() is NULL. No DDL, no DML, no comments, no CTE names beyond t0..t9.
- If the measure is truly impossible with the given schema, return
  {"error": "reason"}."""


@dataclass
class Tier2Result:
    measure: str
    sql: str | None
    accepted: bool
    attempts: int
    trace: list[str]


def _model_context(model: SemanticModel, bindings: BindingMap, measure_name: str) -> str:
    found = model.find_measure(measure_name)
    _, measure = found
    lines = [f"DAX measure [{measure_name}]:", measure.expression, "", "Physical tables:"]
    for t in model.tables:
        b = bindings.get(t.name)
        if b is None or b.status != "resolved":
            continue
        cols = ", ".join(c.source_column or c.name for c in t.columns if not c.is_calculated)
        lines.append(f"- {t.name} -> {b.qualified_name} ({cols})")
    lines.append("")
    lines.append("Other measures it references (already-compiled SQL you may inline):")
    return "\n".join(lines)


def _extract_json(text: str) -> dict | None:
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        return None


_FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|DROP|ALTER|GRANT|TRUNCATE|CALL)\b", re.IGNORECASE
)


def propose_and_validate(
    model: SemanticModel,
    bindings: BindingMap,
    measure_name: str,
    cursor,
    client=None,
) -> Tier2Result:
    """Ask OpenAI for SQL, execute to validate, retry with the error, bounded."""
    trace: list[str] = []
    if client is None:
        try:
            from openai import OpenAI

            from app.core.config import get_settings

            key = get_settings().openai_api_key
            if not key:
                return Tier2Result(measure_name, None, False, 0, ["no OPENAI key configured"])
            client = OpenAI(api_key=key)
        except ModuleNotFoundError:
            return Tier2Result(measure_name, None, False, 0, ["openai package not installed"])

    context = _model_context(model, bindings, measure_name)
    messages = [
        {"role": "system", "content": _SYSTEM},
        {"role": "user", "content": context},
    ]

    for attempt in range(1, _MAX_ATTEMPTS + 1):
        resp = client.chat.completions.create(
            model="gpt-4o",
            temperature=0,
            messages=messages,
        )
        text = resp.choices[0].message.content or ""
        payload = _extract_json(text)
        if payload is None or ("sql" not in payload and "error" not in payload):
            trace.append(f"attempt {attempt}: unparseable response")
            messages.append({"role": "assistant", "content": text})
            messages.append(
                {"role": "user", "content": 'Respond with only {"sql": "..."} JSON.'}
            )
            continue
        if "error" in payload:
            trace.append(f"attempt {attempt}: model declared impossible: {payload['error']}")
            return Tier2Result(measure_name, None, False, attempt, trace)

        sql = payload["sql"].strip().rstrip(";")
        if _FORBIDDEN.search(sql) or not sql.upper().startswith(("SELECT", "WITH")):
            trace.append(f"attempt {attempt}: rejected non-SELECT statement")
            messages.append({"role": "assistant", "content": text})
            messages.append({"role": "user", "content": "Only a single SELECT is allowed."})
            continue

        try:
            cursor.execute(sql)
            row = cursor.fetchone()
            if row is None or len(row) != 1:
                raise ValueError(f"expected 1 scalar, got {row!r}")
            float(row[0]) if row[0] is not None else None
            trace.append(f"attempt {attempt}: executed OK, result={row[0]}")
            return Tier2Result(measure_name, sql, True, attempt, trace)
        except Exception as e:
            trace.append(f"attempt {attempt}: execution failed: {str(e)[:200]}")
            messages.append({"role": "assistant", "content": text})
            messages.append(
                {"role": "user", "content": f"That SQL failed: {str(e)[:300]}. Fix it."}
            )

    return Tier2Result(measure_name, None, False, _MAX_ATTEMPTS, trace)
