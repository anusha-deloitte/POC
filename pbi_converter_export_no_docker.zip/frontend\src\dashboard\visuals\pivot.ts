import type { VisualResult, VisualSpec } from '../types'

export interface PivotedTable {
  headers: string[]
  rows: (string | number | null)[][]
  measureCols: Set<number>
  formatFor: (colIdx: number) => string | undefined
}

/** Pivot long-format rows into a matrix when the visual has Columns-role dims.
 *  Row dims stay as leading columns; each (columnValue x measure) becomes a
 *  header. Single-measure pivots use just the column value as the header. */
export function pivotResult(spec: VisualSpec, data: VisualResult): PivotedTable {
  const cols = data.columns
  const rowDims = spec.dim_keys.filter((k) => !spec.column_keys.includes(k))
  const colDims = spec.column_keys

  if (!colDims.length) {
    const measureCols = new Set(
      cols.map((c, i) => (spec.measure_keys.includes(c) ? i : -1)).filter((i) => i >= 0),
    )
    return {
      headers: cols,
      rows: data.rows,
      measureCols,
      formatFor: (i) => spec.measure_formats[cols[i]],
    }
  }

  const rowIdx = rowDims.map((k) => cols.indexOf(k))
  const colIdx = colDims.map((k) => cols.indexOf(k))
  const measIdx = spec.measure_keys.map((k) => cols.indexOf(k))

  const colValues: string[] = []
  const seen = new Set<string>()
  for (const r of data.rows) {
    const cv = colIdx.map((i) => String(r[i] ?? '')).join(' / ')
    if (!seen.has(cv)) {
      seen.add(cv)
      colValues.push(cv)
    }
  }

  const single = spec.measure_keys.length === 1
  const headers = [
    ...rowDims,
    ...colValues.flatMap((cv) =>
      single ? [cv] : spec.measure_keys.map((mk) => `${cv} · ${mk}`),
    ),
  ]

  const byRow = new Map<string, (string | number | null)[]>()
  const rowOrder: string[] = []
  for (const r of data.rows) {
    const rk = rowIdx.map((i) => String(r[i] ?? '')).join('\u0000')
    if (!byRow.has(rk)) {
      byRow.set(rk, [
        ...rowIdx.map((i) => r[i]),
        ...new Array<null>(colValues.length * measIdx.length).fill(null),
      ])
      rowOrder.push(rk)
    }
    const out = byRow.get(rk)!
    const cv = colIdx.map((i) => String(r[i] ?? '')).join(' / ')
    const base = rowDims.length + colValues.indexOf(cv) * measIdx.length
    measIdx.forEach((mi, j) => {
      out[base + j] = r[mi]
    })
  }

  const measureCols = new Set(
    headers.map((_, i) => i).filter((i) => i >= rowDims.length),
  )
  const formatFor = (i: number) => {
    if (i < rowDims.length) return undefined
    const mk = spec.measure_keys[(i - rowDims.length) % spec.measure_keys.length]
    return spec.measure_formats[mk]
  }
  return { headers, rows: rowOrder.map((rk) => byRow.get(rk)!), measureCols, formatFor }
}
