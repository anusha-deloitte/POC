import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  AlertTriangle,
  ArrowDown,
  ArrowRight,
  CheckCircle2,
  Database,
  Snowflake,
  Trash2,
} from 'lucide-react'
import { useEffect } from 'react'
import { useState } from 'react'
import { api } from '../api/client'
import type {
  AuthMethod,
  ConnectionProfile,
  ConnectionTestResult,
  ConversionSummary,
  NewConnection,
  NewSourceConnection,
} from '../api/types'
import { useWizard } from '../store/wizard'

const AUTH_LABELS: Record<AuthMethod, string> = {
  key_pair: 'Key pair (JWT) — recommended',
  password: 'Username & password',
  oauth_client_credentials: 'OAuth client credentials',
  pat: 'Programmatic access token',
}

interface SourceType {
  id: string
  label: string
  available: boolean
}

export function ConnectStep() {
  const setConnection = useWizard((s) => s.setConnection)
  const lastConnectionId = useWizard((s) => s.connectionId)
  const conversionId = useWizard((s) => s.conversionId)
  const sourceConnectionId = useWizard((s) => s.sourceConnectionId)
  const [selected, setSelected] = useState<string | null>(lastConnectionId)

  const conversion = useQuery({
    queryKey: ['conversion', conversionId],
    queryFn: () => api.getConversion(conversionId!),
    enabled: !!conversionId,
  })
  const sources = useQuery({
    queryKey: ['source-connections'],
    queryFn: api.listSourceConnections,
  })
  const sourceDb = conversion.data?.source_database
  const needsMigration = !!sourceDb?.needs_migration
  const detectedLabel = sourceDb && sourceDb.kind !== 'snowflake'
    ? (SOURCE_KIND_LABELS[sourceDb.kind] ?? sourceDb.kind)
    : null
  const sourceReady = !needsMigration || !!sourceConnectionId
  const selectedSource = (sources.data ?? []).find((s) => s.id === sourceConnectionId)

  return (
    <section>
      <div className="mb-6 overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div className="kicker mb-1">Step 2 · Connections</div>
        <h2 className="text-xl font-bold">Where does the data live — and where should it go?</h2>
        <p className="mt-1 max-w-2xl text-sm text-surface-600">
          {needsMigration ? (
            <>
              This report reads <b>{detectedLabel}</b> — connect it, pick the target Snowflake,
              and the conversion migrates everything automatically.
            </>
          ) : (
            <>Pick the target Snowflake this report runs on.</>
          )}{' '}
          Credentials are encrypted at rest.
        </p>
      </div>

      {/* two equal panels: SOURCE -> TARGET */}
      <div className="grid items-stretch gap-4 lg:grid-cols-[1fr_auto_1fr]">
        <SourcePanel sourceDb={sourceDb} />

        <div className="flex items-center justify-center lg:flex-col">
          <span className="flex h-11 w-11 items-center justify-center rounded-full border border-black/[0.08] bg-white shadow-card">
            <ArrowRight className="hidden h-5 w-5 text-brand-dark lg:block" strokeWidth={2} />
            <ArrowDown className="h-5 w-5 text-brand-dark lg:hidden" strokeWidth={2} />
          </span>
          <span className="mt-2 hidden text-center text-[10px] font-bold tracking-wider text-surface-400 uppercase lg:block">
            schema
            <br />+ data
            <br />+ semantics
          </span>
        </div>

        <TargetPanel selected={selected} onSelect={setSelected} />
      </div>

      {/* migration plan summary + continue */}
      <div className="mt-6 rounded-2xl border border-black/[0.08] bg-white p-4 shadow-card">
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
          <span className="font-bold text-surface-800">Plan</span>
          <span className="flex items-center gap-1.5">
            {sourceReady ? (
              <CheckCircle2 className="h-4 w-4 text-brand-dark" strokeWidth={2} />
            ) : (
              <AlertTriangle className="h-4 w-4 text-brand-amber" strokeWidth={2} />
            )}
            <span className="text-surface-600">
              {needsMigration
                ? selectedSource
                  ? `Migrate ${sourceDb!.tables.length} tables from ${selectedSource.name}`
                  : `Source connection needed (${detectedLabel} detected)`
                : selectedSource
                  ? `Source on standby: ${selectedSource.name}`
                  : 'No source migration — report already reads Snowflake'}
            </span>
          </span>
          <span className="flex items-center gap-1.5">
            {selected ? (
              <CheckCircle2 className="h-4 w-4 text-brand-dark" strokeWidth={2} />
            ) : (
              <AlertTriangle className="h-4 w-4 text-brand-amber" strokeWidth={2} />
            )}
            <span className="text-surface-600">
              {selected ? 'Target Snowflake selected' : 'Pick the target Snowflake connection'}
            </span>
          </span>
          <button
            onClick={() => selected && setConnection(selected)}
            disabled={!selected || !sourceReady}
            title={
              !selected
                ? 'Select the target Snowflake connection'
                : !sourceReady
                  ? 'Connect the source database this report reads'
                  : ''
            }
            className="btn-primary ml-auto"
          >
            Continue →
          </button>
        </div>
      </div>
    </section>
  )
}

/* ------------------------------------------------------------------ */
/* SOURCE panel: the database the report reads today                    */
/* ------------------------------------------------------------------ */

function SourcePanel({ sourceDb }: { sourceDb?: ConversionSummary['source_database'] }) {
  const queryClient = useQueryClient()
  const sourceConnectionId = useWizard((s) => s.sourceConnectionId)
  const setSourceConnection = useWizard((s) => s.setSourceConnection)
  const copyData = useWizard((s) => s.copyData)
  const setCopyData = useWizard((s) => s.setCopyData)
  const detected = sourceDb?.needs_migration ? sourceDb : undefined
  const detectedDb = detected?.tables.find((t) => t.database)?.database
  const [showForm, setShowForm] = useState(false)
  const [testMsg, setTestMsg] = useState('')

  const kindsQuery = useQuery({ queryKey: ['source-kinds'], queryFn: api.listSourceKinds })
  const sources = useQuery({
    queryKey: ['source-connections'],
    queryFn: api.listSourceConnections,
  })
  const kinds = kindsQuery.data ?? []
  const saved = sources.data ?? []

  const [form, setForm] = useState<NewSourceConnection>({
    name: '',
    kind: 'sqlserver',
    host: '',
    port: SOURCE_DEFAULT_PORTS.sqlserver,
    database: '',
    user: '',
    password: '',
  })

  // detection resolves after mount — prefill untouched fields only
  useEffect(() => {
    if (!detected) return
    setForm((f) => ({
      ...f,
      kind: f.host ? f.kind : (detected.kind as NewSourceConnection['kind']),
      port: f.host ? f.port : (SOURCE_DEFAULT_PORTS[detected.kind] ?? null),
      database: f.database || (detectedDb ?? ''),
    }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [detected?.kind, detectedDb])

  const create = useMutation({
    mutationFn: () =>
      api.createSourceConnection({
        ...form,
        name: form.name || `${SOURCE_KIND_LABELS[form.kind] ?? form.kind} · ${form.database}`,
      }),
    onSuccess: async (profile) => {
      setSourceConnection(profile.id)
      setShowForm(false)
      await queryClient.invalidateQueries({ queryKey: ['source-connections'] })
    },
  })
  const remove = useMutation({
    mutationFn: (id: string) => api.deleteSourceConnection(id),
    onSuccess: async (_d, id) => {
      if (sourceConnectionId === id) setSourceConnection(null)
      await queryClient.invalidateQueries({ queryKey: ['source-connections'] })
    },
  })
  const test = useMutation({
    mutationFn: (id: string) => api.testSourceConnection(id),
    onSuccess: () => setTestMsg('Connection OK — source reachable.'),
    onError: (e) => setTestMsg((e as Error).message),
  })

  // a report bound to one database kind only ever migrates from that kind
  const visible = detected ? saved.filter((s) => s.kind === detected.kind) : saved
  const showFormNow = showForm || visible.length === 0

  return (
    <div
      data-testid="source-migration-panel"
      className="flex flex-col rounded-2xl border border-black/[0.08] bg-white shadow-card"
    >
      <div className="flex items-center gap-3 rounded-t-2xl border-b border-black/[0.06] bg-gradient-to-r from-brand-amber/10 to-transparent px-5 py-4">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-amber/15">
          <Database className="h-5 w-5 text-brand-amber" strokeWidth={1.8} />
        </span>
        <div className="min-w-0">
          <div className="text-[10px] font-bold tracking-wider text-brand-amber uppercase">
            Source
          </div>
          <h3 className="truncate font-bold">Where the report reads data today</h3>
        </div>
      </div>

      <div className="flex-1 p-5">
        {detected ? (
          <div className="mb-4 flex items-center gap-3 rounded-xl border border-brand-amber/25 bg-brand-amber/5 px-3 py-2.5 text-sm">
            <span className="text-surface-600">Detected:</span>
            <span className="badge-blue !text-sm">
              {SOURCE_KIND_LABELS[detected.kind] ?? detected.kind}
            </span>
            {detectedDb && <span className="font-semibold text-surface-800">{detectedDb}</span>}
            <span className="ml-auto text-xs text-surface-500">Connect to it below</span>
          </div>
        ) : (
          <p className="mb-4 rounded-xl bg-surface-100 p-3 text-sm text-surface-600">
            Reads Snowflake — no source needed.
          </p>
        )}

        {visible.length > 0 && !showFormNow && (
          <div className="space-y-2">
            {visible.map((s) => (
              <label
                key={s.id}
                className="flex cursor-pointer items-center gap-3 rounded-xl border border-black/[0.08] p-3 text-sm transition-colors has-[:checked]:border-brand-amber has-[:checked]:bg-brand-amber/5"
              >
                <input
                  type="radio"
                  name="source-connection"
                  checked={sourceConnectionId === s.id}
                  onChange={() => setSourceConnection(s.id)}
                />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2">
                    <span className="truncate font-semibold">{s.name}</span>
                    <span className="badge-blue shrink-0">
                      {SOURCE_KIND_LABELS[s.kind] ?? s.kind}
                    </span>
                  </span>
                  <span className="block truncate text-xs text-surface-500">
                    {s.host} · {s.database}
                  </span>
                </span>
                <button
                  type="button"
                  className="btn-secondary !px-2.5 !py-1 !text-xs"
                  disabled={test.isPending}
                  onClick={(e) => {
                    e.preventDefault()
                    setTestMsg('')
                    test.mutate(s.id)
                  }}
                >
                  Test
                </button>
                <button
                  type="button"
                  aria-label={`Delete ${s.name}`}
                  className="rounded-lg p-1.5 text-surface-400 hover:bg-brand-red/10 hover:text-brand-red"
                  onClick={(e) => {
                    e.preventDefault()
                    remove.mutate(s.id)
                  }}
                >
                  <Trash2 className="h-3.5 w-3.5" strokeWidth={2} />
                </button>
              </label>
            ))}
            {testMsg && <p className="text-xs text-surface-600">{testMsg}</p>}
            <div className="flex items-center gap-4 pt-1">
              <button
                type="button"
                onClick={() => setShowForm(true)}
                className="text-xs font-semibold text-brand-dark underline"
              >
                + New source connection
              </button>
              {sourceConnectionId && !detected && (
                <button
                  type="button"
                  onClick={() => setSourceConnection(null)}
                  className="text-xs text-surface-500 underline"
                >
                  Clear selection
                </button>
              )}
            </div>
          </div>
        )}

        {showFormNow && (
          <form
            className="grid gap-3 sm:grid-cols-2"
            onSubmit={(e) => {
              e.preventDefault()
              create.mutate()
            }}
          >
            {detected ? (
              // detected kind is definitive — no picker needed
              <input type="hidden" value={form.kind} />
            ) : (
              <Field label="Database type" wide>
                <select
                  className="input"
                  value={form.kind}
                  onChange={(e) => {
                    const kind = e.target.value as NewSourceConnection['kind']
                    setForm({ ...form, kind, port: SOURCE_DEFAULT_PORTS[kind] ?? null })
                  }}
                >
                  {(kinds.length
                    ? kinds
                    : Object.entries(SOURCE_KIND_LABELS).map(([id, label]) => ({
                        id,
                        label,
                        available: true,
                      }))
                  ).map((k) => (
                    <option key={k.id} value={k.id} disabled={!k.available}>
                      {k.label}
                      {!k.available ? ' (driver not installed)' : ''}
                    </option>
                  ))}
                </select>
              </Field>
            )}
            <Field label="Host">
              <input
                required
                className="input"
                placeholder="db-host.corp.local"
                value={form.host}
                onChange={(e) => setForm({ ...form, host: e.target.value })}
              />
            </Field>
            <Field label="Port">
              <input
                type="number"
                className="input"
                value={form.port ?? ''}
                onChange={(e) =>
                  setForm({ ...form, port: e.target.value ? Number(e.target.value) : null })
                }
              />
            </Field>
            <Field label="Database">
              <input
                required
                className="input"
                value={form.database}
                onChange={(e) => setForm({ ...form, database: e.target.value })}
              />
            </Field>
            <Field label="User">
              <input
                required
                className="input"
                value={form.user}
                onChange={(e) => setForm({ ...form, user: e.target.value })}
              />
            </Field>
            <Field label="Password" wide>
              <input
                required
                type="password"
                className="input"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
            </Field>
            <div className="col-span-2 flex items-center gap-3">
              <button type="submit" className="btn-primary" disabled={create.isPending}>
                Save source connection
              </button>
              {saved.length > 0 && (
                <button type="button" className="btn-secondary" onClick={() => setShowForm(false)}>
                  Cancel
                </button>
              )}
              {create.isError && (
                <span className="text-xs text-brand-red">{create.error.message}</span>
              )}
            </div>
          </form>
        )}

        {sourceConnectionId && !showFormNow && (
          <>
            <p className="mt-3 flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
              <CheckCircle2 className="h-3.5 w-3.5" /> Source ready
              {detected ? ' — objects migrate during conversion.' : ' (on standby).'}
            </p>
            <label
              className="mt-2 flex cursor-pointer items-start gap-2 rounded-lg border border-surface-300 bg-surface-50 px-3 py-2"
              data-testid="copy-data-toggle"
            >
              <input
                type="checkbox"
                className="mt-0.5"
                checked={copyData}
                onChange={(e) => setCopyData(e.target.checked)}
              />
              <span className="text-xs text-surface-700">
                <strong>Copy data during migration</strong>
                <span className="mt-0.5 block text-surface-500">
                  Off = schema-only: tables, views &amp; procedures are created and the report
                  is rebound, but rows are provisioned by your own pipeline. Validation of
                  numbers waits until data lands.
                </span>
              </span>
            </label>
          </>
        )}
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ */
/* TARGET panel: the Snowflake the converted report runs on            */
/* ------------------------------------------------------------------ */

function TargetPanel({
  selected,
  onSelect,
}: {
  selected: string | null
  onSelect: (id: string) => void
}) {
  const queryClient = useQueryClient()
  const [showNew, setShowNew] = useState(false)

  const existing = useQuery({ queryKey: ['connections'], queryFn: api.listConnections })
  const remove = useMutation({
    mutationFn: (id: string) => api.deleteConnection(id),
    onSuccess: async (_d, id) => {
      if (selected === id) onSelect('')
      await queryClient.invalidateQueries({ queryKey: ['connections'] })
    },
  })
  const noConnections = existing.data !== undefined && existing.data.length === 0
  const showFormNow = showNew || noConnections

  return (
    <div
      data-testid="target-panel"
      className="flex flex-col rounded-2xl border border-black/[0.08] bg-white shadow-card"
    >
      <div className="flex items-center gap-3 rounded-t-2xl border-b border-black/[0.06] bg-gradient-to-r from-brand-blue/10 to-transparent px-5 py-4">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-blue/10">
          <Snowflake className="h-5 w-5 text-brand-blue" strokeWidth={1.8} />
        </span>
        <div className="min-w-0">
          <div className="text-[10px] font-bold tracking-wider text-brand-blue uppercase">
            Target
          </div>
          <h3 className="truncate font-bold">Where the converted report will run</h3>
        </div>
      </div>

      <div className="flex-1 p-5">
        {existing.isLoading && <p className="text-sm text-surface-500">Loading connections…</p>}

        {existing.data && existing.data.length > 0 && !showFormNow && (
          <div className="space-y-2">
            {existing.data.map((c) => (
              <TargetConnectionRow
                key={c.id}
                c={c}
                checked={selected === c.id}
                onPick={() => onSelect(c.id)}
                onDelete={() => remove.mutate(c.id)}
                deleting={remove.isPending}
              />
            ))}
            <div className="pt-1">
              <button
                type="button"
                onClick={() => setShowNew(true)}
                className="text-xs font-semibold text-brand-dark underline"
              >
                + New Snowflake connection
              </button>
            </div>
            {remove.isError && (
              <p role="alert" className="text-xs text-brand-red">
                {remove.error.message}
              </p>
            )}
          </div>
        )}

        {showFormNow && (
          <NewConnectionForm
            onBack={noConnections ? undefined : () => setShowNew(false)}
            onDone={(id) => {
              onSelect(id)
              setShowNew(false)
            }}
          />
        )}

        {selected && !showFormNow && (
          <p className="mt-3 flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
            <CheckCircle2 className="h-3.5 w-3.5" /> Target ready — migrated tables and the
            semantic model land here.
          </p>
        )}
      </div>
    </div>
  )
}

function TargetConnectionRow({
  c,
  checked,
  onPick,
  onDelete,
  deleting,
}: {
  c: ConnectionProfile
  checked: boolean
  onPick: () => void
  onDelete: () => void
  deleting: boolean
}) {
  return (
    <label className="flex cursor-pointer items-center gap-3 rounded-xl border border-black/[0.08] p-3 text-sm transition-colors has-[:checked]:border-brand has-[:checked]:bg-brand/5">
      <input type="radio" name="target-connection" checked={checked} onChange={onPick} />
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2">
          <span className="truncate font-semibold">{c.name}</span>
          <span className="badge-blue shrink-0">Snowflake</span>
        </span>
        <span className="block truncate text-xs text-surface-500">
          {c.account}
          {c.database ? ` · ${c.database}` : ''}
          {c.schema_name ? ` · ${c.schema_name}` : ''}
        </span>
      </span>
      <button
        type="button"
        aria-label={`Delete ${c.name}`}
        className="rounded-lg p-1.5 text-surface-400 hover:bg-brand-red/10 hover:text-brand-red"
        disabled={deleting}
        onClick={(e) => {
          e.preventDefault()
          onDelete()
        }}
      >
        <Trash2 className="h-3.5 w-3.5" strokeWidth={2} />
      </button>
    </label>
  )
}

function NewConnectionForm({
  onBack,
  onDone,
}: {
  onBack?: () => void
  onDone: (id: string) => void
}) {
  const queryClient = useQueryClient()
  const setUnsavedChanges = useWizard((s) => s.setUnsavedChanges)
  const [sourceType, setSourceType] = useState('snowflake')
  const [form, setForm] = useState<NewConnection>({
    name: '',
    account: '',
    user: '',
    auth_method: 'key_pair',
    database: '',
    schema: '',
  })
  const [testResult, setTestResult] = useState<ConnectionTestResult | null>(null)
  const [createdId, setCreatedId] = useState<string | null>(null)

  const sourceTypes = useQuery({
    queryKey: ['source-types'],
    queryFn: async (): Promise<SourceType[]> => {
      const res = await fetch('/api/v1/connections/source-types')
      if (!res.ok) return [{ id: 'snowflake', label: 'Snowflake', available: true }]
      return res.json()
    },
  })

  const create = useMutation({
    mutationFn: (spec: NewConnection) => api.createConnection(spec),
    onSuccess: (profile) => {
      setCreatedId(profile.id)
      void queryClient.invalidateQueries({ queryKey: ['connections'] })
      test.mutate(profile.id)
    },
  })
  const test = useMutation({
    mutationFn: (id: string) => api.testConnection(id),
    onSuccess: setTestResult,
  })

  const set = (patch: Partial<NewConnection>) => setForm((f) => ({ ...f, ...patch }))
  const chosen = sourceTypes.data?.find((s) => s.id === sourceType)
  const unavailable = chosen ? !chosen.available : false

  useEffect(() => {
    const hasManualInput =
      !!form.name ||
      !!form.account ||
      !!form.user ||
      !!form.database ||
      !!form.schema ||
      !!form.role ||
      !!form.warehouse ||
      !!form.password ||
      !!form.private_key_pem ||
      !!form.private_key_passphrase ||
      !!form.oauth_client_id ||
      !!form.oauth_client_secret ||
      !!form.oauth_token_url ||
      !!form.pat_token
    setUnsavedChanges(hasManualInput, hasManualInput ? 'connection form edits' : null)
    return () => setUnsavedChanges(false, null)
  }, [form, setUnsavedChanges])

  return (
    <div className="card p-6">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-sm font-bold">
          <Database className="h-4 w-4 text-brand-dark" strokeWidth={1.8} />
          New connection
        </h3>
        {onBack && (
          <button onClick={onBack} className="text-xs font-semibold text-surface-500 hover:text-surface-800">
            ← Back to existing connections
          </button>
        )}
      </div>

      <form
        className="grid grid-cols-2 gap-4"
        onSubmit={(e) => {
          e.preventDefault()
          create.mutate(form)
        }}
      >
        <Field label="Data source" wide>
          <select
            value={sourceType}
            onChange={(e) => setSourceType(e.target.value)}
            className="input"
          >
            {(sourceTypes.data ?? []).map((s) => (
              <option key={s.id} value={s.id}>
                {s.label}
                {s.available ? '' : ' — coming soon'}
              </option>
            ))}
          </select>
        </Field>

        {unavailable && (
          <div className="col-span-2 rounded-xl border border-brand-amber/25 bg-brand-amber/5 p-3 text-sm text-surface-700">
            <strong className="text-brand-amber">{chosen?.label}</strong> support is on the
            roadmap — the connector framework is source-agnostic. For this workspace, use
            Snowflake.
          </div>
        )}

        {!unavailable && (
          <>
            <Field label="Connection name">
              <input required value={form.name} onChange={(e) => set({ name: e.target.value })} className="input" />
            </Field>
            <Field label="Account identifier">
              <input
                required
                placeholder="orgname-account"
                value={form.account}
                onChange={(e) => set({ account: e.target.value })}
                className="input"
              />
            </Field>
            <Field label="User">
              <input required value={form.user} onChange={(e) => set({ user: e.target.value })} className="input" />
            </Field>
            <Field label="Default database">
              <input
                required
                value={form.database}
                onChange={(e) => set({ database: e.target.value })}
                className="input"
              />
            </Field>
            <Field label="Default schema">
              <input
                required
                value={form.schema}
                onChange={(e) => set({ schema: e.target.value })}
                className="input"
              />
            </Field>
            <Field label="Authentication">
              <select
                value={form.auth_method}
                onChange={(e) => set({ auth_method: e.target.value as AuthMethod })}
                className="input"
              >
                {Object.entries(AUTH_LABELS).map(([v, label]) => (
                  <option key={v} value={v}>
                    {label}
                  </option>
                ))}
              </select>
            </Field>

            {form.auth_method === 'password' && (
              <Field label="Password">
                <input
                  required
                  type="password"
                  value={form.password ?? ''}
                  onChange={(e) => set({ password: e.target.value })}
                  className="input"
                />
              </Field>
            )}
            {form.auth_method === 'key_pair' && (
              <>
                <Field label="Private key (PEM)" wide>
                  <textarea
                    required
                    rows={4}
                    value={form.private_key_pem ?? ''}
                    onChange={(e) => set({ private_key_pem: e.target.value })}
                    className="input font-mono text-xs"
                  />
                </Field>
                <Field label="Key passphrase (optional)">
                  <input
                    type="password"
                    value={form.private_key_passphrase ?? ''}
                    onChange={(e) => set({ private_key_passphrase: e.target.value })}
                    className="input"
                  />
                </Field>
              </>
            )}
            {form.auth_method === 'oauth_client_credentials' && (
              <>
                <Field label="Client ID">
                  <input
                    required
                    value={form.oauth_client_id ?? ''}
                    onChange={(e) => set({ oauth_client_id: e.target.value })}
                    className="input"
                  />
                </Field>
                <Field label="Client secret">
                  <input
                    required
                    type="password"
                    value={form.oauth_client_secret ?? ''}
                    onChange={(e) => set({ oauth_client_secret: e.target.value })}
                    className="input"
                  />
                </Field>
                <Field label="Token URL" wide>
                  <input
                    required
                    value={form.oauth_token_url ?? ''}
                    onChange={(e) => set({ oauth_token_url: e.target.value })}
                    className="input"
                  />
                </Field>
              </>
            )}
            {form.auth_method === 'pat' && (
              <Field label="Access token">
                <input
                  required
                  type="password"
                  value={form.pat_token ?? ''}
                  onChange={(e) => set({ pat_token: e.target.value })}
                  className="input"
                />
              </Field>
            )}

            <Field label="Role (optional)">
              <input value={form.role ?? ''} onChange={(e) => set({ role: e.target.value })} className="input" />
            </Field>
            <Field label="Warehouse (optional)">
              <input
                value={form.warehouse ?? ''}
                onChange={(e) => set({ warehouse: e.target.value })}
                className="input"
              />
            </Field>

            <div className="col-span-2 flex items-center gap-3">
              <button type="submit" disabled={create.isPending || test.isPending} className="btn-primary">
                {create.isPending || test.isPending ? 'Testing…' : 'Save & test connection'}
              </button>
              {createdId && testResult && (
                <span
                  role="status"
                  className={`text-sm font-medium ${testResult.ok ? 'text-brand-dark' : 'text-brand-amber'}`}
                >
                  {testResult.ok
                    ? `Connected in ${testResult.latency_ms} ms (${testResult.warehouse ?? 'no warehouse'})`
                    : `Warning: saved, but probe failed: ${testResult.error}`}
                </span>
              )}
              {createdId && test.isError && (
                <span role="status" className="text-sm text-brand-amber">
                  Warning: saved, but probe failed: {test.error.message}
                </span>
              )}
            </div>
            {create.isError && (
              <div
                role="alert"
                className="col-span-2 rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red"
              >
                <div className="flex items-start gap-2">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.8} />
                  <div>
                    <div className="font-semibold">Blocking error: connection was not saved.</div>
                    <p className="mt-1">{create.error.message}</p>
                    <p className="mt-1 text-xs text-surface-600">
                      Review account, auth method, and required credentials, then retry.
                    </p>
                  </div>
                </div>
              </div>
            )}
            {createdId && (
              <button type="button" onClick={() => onDone(createdId)} className="btn-secondary col-span-2">
                Continue with this connection →
              </button>
            )}
          </>
        )}
      </form>
    </div>
  )
}

function Field({
  label,
  children,
  wide,
}: {
  label: string
  children: React.ReactNode
  wide?: boolean
}) {
  return (
    <label className={`flex flex-col gap-1 text-sm ${wide ? 'col-span-2' : ''}`}>
      <span className="font-semibold text-surface-700">{label}</span>
      {children}
    </label>
  )
}

const SOURCE_KIND_LABELS: Record<string, string> = {
  sqlserver: 'SQL Server',
  postgres: 'PostgreSQL',
  mysql: 'MySQL',
  oracle: 'Oracle',
}

const SOURCE_DEFAULT_PORTS: Record<string, number> = {
  sqlserver: 1433,
  postgres: 5432,
  mysql: 3306,
  oracle: 1521,
}

