"""DAX expression parser (Lark) -> typed AST.

Covers the Tier-0/1 surface: literals, column/measure refs, arithmetic,
comparison, function calls, VAR/RETURN, table refs. Anything outside the
grammar raises DaxParseError -> caller routes the measure to Tier 2 (LLM)
or the human queue; we never guess.
"""

from __future__ import annotations

from dataclasses import dataclass

from lark import Lark, Token, Transformer, v_args
from lark.exceptions import LarkError

_GRAMMAR = r"""
?start: expr

?expr: var_expr | or_expr

var_expr: (VAR NAME "=" or_expr)+ RETURN or_expr

?or_expr: and_expr (OR_OP and_expr)*
?and_expr: not_expr (AND_OP not_expr)*
?not_expr: NOT_OP not_expr -> not_op
         | comparison

?comparison: concat (CMP_OP concat)?
?concat: additive (CONCAT_OP additive)*
?additive: multiplicative ((ADD_OP | SUB_OP) multiplicative)*
?multiplicative: unary ((MUL_OP | DIV_OP) unary)*
?unary: SUB_OP unary -> neg
      | atom

?atom: NUMBER                     -> number
     | STRING                     -> string
     | TRUE_LIT                   -> true_lit
     | FALSE_LIT                  -> false_lit
     | BLANK_CALL                 -> blank
     | func_call
     | column_ref
     | measure_ref
     | table_ref
     | var_ref
     | "(" expr ")"

func_call: FUNC_NAME "(" [expr ("," expr)*] ")"

column_ref: TABLE_IDENT "[" COL_NAME "]"
measure_ref: "[" COL_NAME "]"
table_ref: TABLE_IDENT
var_ref: NAME

TABLE_IDENT: /'[^']+'/ | /(?!(?:VAR|RETURN|NOT|TRUE|FALSE)\b)[A-Za-z_][A-Za-z0-9_.]*(?=\s*\[)/
FUNC_NAME: /(?!(?:VAR|RETURN|NOT|TRUE|FALSE)\b)[A-Za-z_][A-Za-z0-9_.]*(?=\s*\()/
NAME: /(?!(?:VAR|RETURN|NOT|TRUE|FALSE)\b)[A-Za-z_][A-Za-z0-9_]*/
COL_NAME: /[^\]]+/
NUMBER: /\d+(\.\d+)?([eE][+-]?\d+)?/
STRING: /"[^"]*"/
VAR: "VAR"i
RETURN: "RETURN"i
NOT_OP: "NOT"i
TRUE_LIT: "TRUE"i "()" | "TRUE"i
FALSE_LIT: "FALSE"i "()" | "FALSE"i
BLANK_CALL: "BLANK"i "()"
OR_OP: "||"
AND_OP: "&&"
CONCAT_OP: /&(?!&)/
CMP_OP: "<=" | ">=" | "<>" | "=" | "<" | ">"
ADD_OP: "+"
SUB_OP: "-"
MUL_OP: "*"
DIV_OP: "/"

%import common.WS
%ignore WS
%ignore /\/\/[^\n]*/
%ignore /--[^\n]*/
"""


class DaxParseError(Exception):
    pass


# ---------- AST ----------


@dataclass(frozen=True)
class Num:
    value: float


@dataclass(frozen=True)
class Str:
    value: str


@dataclass(frozen=True)
class Bool:
    value: bool


@dataclass(frozen=True)
class Blank:
    pass


@dataclass(frozen=True)
class ColumnRef:
    table: str
    column: str


@dataclass(frozen=True)
class MeasureRef:
    name: str


@dataclass(frozen=True)
class TableRef:
    name: str


@dataclass(frozen=True)
class VarRef:
    name: str


@dataclass(frozen=True)
class FuncCall:
    name: str  # uppercased
    args: tuple


@dataclass(frozen=True)
class BinOp:
    op: str
    left: object
    right: object


@dataclass(frozen=True)
class UnaryOp:
    op: str
    operand: object


@dataclass(frozen=True)
class VarExpr:
    bindings: tuple[tuple[str, object], ...]
    body: object


def _unquote_table(name: str) -> str:
    return name[1:-1] if name.startswith("'") else name


@v_args(inline=True)
class _ToAst(Transformer):
    def number(self, tok: Token):
        return Num(float(tok))

    def string(self, tok: Token):
        return Str(str(tok)[1:-1])

    def true_lit(self, _tok):
        return Bool(True)

    def false_lit(self, _tok):
        return Bool(False)

    def blank(self, _tok):
        return Blank()

    def column_ref(self, table: Token, col: Token):
        return ColumnRef(_unquote_table(str(table)), str(col).strip())

    def measure_ref(self, col: Token):
        return MeasureRef(str(col).strip())

    def table_ref(self, tok: Token):
        return TableRef(_unquote_table(str(tok)))

    def var_ref(self, tok: Token):
        return VarRef(str(tok))

    def func_call(self, name: Token, *args):
        return FuncCall(str(name).upper(), tuple(a for a in args if a is not None))

    def not_op(self, _op, operand):
        return UnaryOp("NOT", operand)

    def neg(self, _op, operand):
        return UnaryOp("-", operand)

    def comparison(self, left, op=None, right=None):
        return left if op is None else BinOp(str(op), left, right)

    def additive(self, first, *rest):
        node = first
        for i in range(0, len(rest), 2):
            node = BinOp(str(rest[i]), node, rest[i + 1])
        return node

    def concat(self, first, *rest):
        node = first
        for i in range(0, len(rest), 2):
            node = BinOp("&", node, rest[i + 1])
        return node

    def multiplicative(self, first, *rest):
        node = first
        for i in range(0, len(rest), 2):
            node = BinOp(str(rest[i]), node, rest[i + 1])
        return node

    def or_expr(self, first, *rest):
        node = first
        for i in range(0, len(rest), 2):
            node = BinOp("||", node, rest[i + 1])
        return node

    def and_expr(self, first, *rest):
        node = first
        for i in range(0, len(rest), 2):
            node = BinOp("&&", node, rest[i + 1])
        return node

    def var_expr(self, *items):
        bindings = []
        i = 0
        while i < len(items):
            tok = items[i]
            if isinstance(tok, Token) and tok.type == "VAR":
                bindings.append((str(items[i + 1]), items[i + 2]))
                i += 3
            elif isinstance(tok, Token) and tok.type == "RETURN":
                return VarExpr(tuple(bindings), items[i + 1])
            else:
                i += 1
        raise DaxParseError("VAR expression without RETURN")


_parser = Lark(_GRAMMAR, parser="earley", maybe_placeholders=False)
_transformer = _ToAst()


def parse_dax(expression: str):
    try:
        return _transformer.transform(_parser.parse(expression.strip()))
    except LarkError as e:
        raise DaxParseError(f"cannot parse DAX: {e}") from e
