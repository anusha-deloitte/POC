import { useMutation } from '@tanstack/react-query'
import { AlertTriangle, FileArchive, ShieldCheck, Sparkles, UploadCloud } from 'lucide-react'
import { useEffect } from 'react'
import { useCallback, useState } from 'react'
import { api } from '../api/client'
import { useWizard } from '../store/wizard'

export function UploadStep() {
  const setConversion = useWizard((s) => s.setConversion)
  const setUnsavedChanges = useWizard((s) => s.setUnsavedChanges)
  const [dragOver, setDragOver] = useState(false)
  const [jobName, setJobName] = useState('')

  useEffect(() => {
    const dirty = jobName.trim().length > 0
    setUnsavedChanges(dirty, dirty ? 'upload naming' : null)
    return () => setUnsavedChanges(false, null)
  }, [jobName, setUnsavedChanges])

  const upload = useMutation({
    mutationFn: ({ file, name }: { file: File; name: string }) => api.uploadPbip(file, name),
    onSuccess: (summary) => setConversion(summary.id),
  })

  const onFile = useCallback(
    (file: File | undefined) => {
      if (file) upload.mutate({ file, name: jobName })
    },
    [upload, jobName],
  )

  return (
    <section>
      <div className="mb-6 overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div className="kicker mb-1">Step 1 · Ingest</div>
        <h2 className="text-xl font-bold">Upload your Power BI project</h2>
        <p className="mt-1 max-w-2xl text-sm text-surface-600">
          Zip the folder containing your <code className="rounded bg-surface-100 px-1 font-mono text-[12px]">.pbip</code>{' '}
          (saved with the PBIR + TMDL formats in Power BI Desktop). The engine parses the semantic
          model, measures, visuals and theme — nothing is executed from the archive.
        </p>
      </div>

      <label className="mb-4 block max-w-md">
        <span className="text-sm font-semibold text-surface-700">Job name (optional)</span>
        <input
          className="input mt-1.5"
          placeholder="e.g. Medical Cost Q3 migration"
          value={jobName}
          maxLength={120}
          onChange={(e) => setJobName(e.target.value)}
        />
      </label>

      <label
        data-drag={dragOver}
        onDragOver={(e) => {
          e.preventDefault()
          setDragOver(true)
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault()
          setDragOver(false)
          onFile(e.dataTransfer.files[0])
        }}
        className="flex h-56 cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-surface-400 bg-surface-50/80 transition-all data-[drag=true]:border-brand data-[drag=true]:bg-brand/5 data-[drag=true]:shadow-glow"
      >
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand/10">
          {upload.isPending ? (
            <Sparkles className="h-6 w-6 animate-pulse text-brand-dark" strokeWidth={1.8} />
          ) : (
            <UploadCloud className="h-6 w-6 text-brand-dark" strokeWidth={1.8} />
          )}
        </span>
        <span className="text-sm font-semibold text-surface-800">
          {upload.isPending ? 'Parsing your report…' : 'Drop .zip here or click to browse'}
        </span>
        <span className="text-xs text-surface-500">
          Up to 300 MB · zip-slip &amp; zip-bomb protected
        </span>
        <input
          type="file"
          accept=".zip"
          className="hidden"
          onChange={(e) => onFile(e.target.files?.[0])}
        />
      </label>

      {upload.isError && (
        <div role="alert" className="mt-4 rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
          <div className="flex items-start gap-2">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.8} />
            <div>
              <div className="font-semibold">Blocking error: upload failed.</div>
              <p className="mt-1">{upload.error.message}</p>
              <p className="mt-1 text-xs text-surface-600">
                Retry with a valid .zip containing a .pbip project folder.
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="card flex items-start gap-3">
          <FileArchive className="mt-0.5 h-5 w-5 text-brand-dark" strokeWidth={1.8} />
          <div>
            <div className="text-sm font-bold">What we read</div>
            <p className="text-xs text-surface-600">
              TMDL semantic model (tables, relationships, DAX measures), PBIR pages &amp; visuals,
              M partitions, custom theme.
            </p>
          </div>
        </div>
        <div className="card flex items-start gap-3">
          <ShieldCheck className="mt-0.5 h-5 w-5 text-brand-dark" strokeWidth={1.8} />
          <div>
            <div className="text-sm font-bold">Accuracy-gated</div>
            <p className="text-xs text-surface-600">
              Every measure is compiled and numerically validated against your Snowflake data
              before the dashboard ships.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
