"""KPI-aware dashboard reimagination engine.

Builds recommendation artifacts from real dashboard query snapshots, produces
story-first redesign guidance with metric evidence, and emits renderable mockup
scene specs that the frontend can display as realistic dashboard previews.
"""

from __future__ import annotations

import json
import statistics
import time
import uuid
from decimal import Decimal
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

from app.runtime.dashboard import DashboardSpec


class MetricEvidence(BaseModel):
    metric_key: str
    visual: str
    page: str
    sample_value: str
    rationale: str


class VisualDecision(BaseModel):
    page: str
    visual: str
    from_type: str
    to_type: str
    title: str
    kpi_intent: str
    expected_gain: str
    confidence: float = Field(default=0.8, ge=0.0, le=1.0)
    evidence: list[MetricEvidence] = Field(default_factory=list)


class MockupVisual(BaseModel):
    visual: str
    title: str
    visual_type: str
    x: float
    y: float
    width: float
    height: float


class MockupScene(BaseModel):
    page: str
    display_name: str
    story_headline: str
    visuals: list[MockupVisual] = Field(default_factory=list)
    data: dict[str, dict] = Field(default_factory=dict)


class WebStoryModule(BaseModel):
    slug: str
    title: str
    objective: str
    narrative: str
    layout_pattern: str
    visual_refs: list[str] = Field(default_factory=list)
    best_practices: list[str] = Field(default_factory=list)


class ReimagineQuality(BaseModel):
    coverage: float = Field(default=0.0, ge=0.0, le=1.0)
    evidence_count: int = 0
    unsupported_intents: int = 0
    narrative_quality: float = Field(default=0.0, ge=0.0, le=1.0)
    visual_justification_quality: float = Field(default=0.0, ge=0.0, le=1.0)
    mockup_realism: float = Field(default=0.0, ge=0.0, le=1.0)
    generic_penalty: float = Field(default=0.0, ge=0.0, le=1.0)
    ready: bool = False
    failures: list[str] = Field(default_factory=list)


class ReimagineSnapshotMeta(BaseModel):
    id: str
    generated_at: float
    visual_count: int
    connection_id: str
    mode: Literal["live", "accelerated"] = "live"


class MockupBlock(BaseModel):
    kind: Literal["metric", "chart", "table", "callout", "section"]
    title: str
    detail: str
    tone: Literal["brand", "neutral", "positive", "warning"] = "neutral"


class PageRecommendation(BaseModel):
    page: str
    display_name: str
    template: str
    summary: str
    rationale: str
    changes: list[str] = Field(default_factory=list)
    blocks: list[MockupBlock] = Field(default_factory=list)


class DashboardRecommendation(BaseModel):
    id: str
    conversion_id: str
    created_at: float
    status: Literal["draft", "approved", "rejected"] = "draft"
    summary: str
    strategy: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    pages: list[PageRecommendation] = Field(default_factory=list)
    build_message: str = "Build Coming Soon"
    decisions: list[dict] = Field(default_factory=list)
    intent_hypothesis: str = ""
    audience: str = "business stakeholder"
    decision_questions: list[str] = Field(default_factory=list)
    kpi_hierarchy: list[str] = Field(default_factory=list)
    visual_decisions: list[VisualDecision] = Field(default_factory=list)
    mockup_scenes: list[MockupScene] = Field(default_factory=list)
    web_story_modules: list[WebStoryModule] = Field(default_factory=list)
    snapshot: ReimagineSnapshotMeta | None = None
    quality: ReimagineQuality = Field(default_factory=ReimagineQuality)


def _recommendations_dir(root: Path) -> Path:
    out = root / "recommendations"
    out.mkdir(exist_ok=True)
    return out


def _index_path(root: Path) -> Path:
    return _recommendations_dir(root) / "index.json"


def _recommendation_path(root: Path, recommendation_id: str) -> Path:
    return _recommendations_dir(root) / f"{recommendation_id}.json"


def _snapshot_path(root: Path, snapshot_id: str) -> Path:
    return _recommendations_dir(root) / f"snapshot_{snapshot_id}.json"


def _normalize_visual_type(visual_type: str) -> str:
    mapping = {
        "clusteredColumnChart": "bar",
        "columnChart": "bar",
        "clusteredBarChart": "bar",
        "barChart": "bar",
        "lineChart": "line",
        "areaChart": "line",
        "donutChart": "pie",
        "pieChart": "pie",
        "waterfallChart": "bar",
        "tableEx": "table",
        "pivotTable": "table",
        "card": "metric",
        "slicer": "callout",
    }
    return mapping.get(visual_type, "chart")


def _story_order_rank(to_type: str) -> int:
    # Storytelling order for BI: headline KPI -> trend -> contributors -> detail table -> filters/callouts.
    if to_type == "metric":
        return 0
    if to_type == "line":
        return 1
    if to_type == "bar":
        return 2
    if to_type == "table":
        return 3
    if to_type == "callout":
        return 4
    return 5


def _story_scene_layout(page, visual_specs: list, to_type_by_visual: dict[str, str]) -> list[MockupVisual]:
    if not visual_specs:
        return []

    width = float(page.width or 1200)
    margin = max(24.0, width * 0.02)
    content_w = max(320.0, width - (margin * 2))
    card_h = 130.0
    chart_h = 290.0
    lower_h = 250.0

    ordered = sorted(
        visual_specs,
        key=lambda v: (_story_order_rank(to_type_by_visual.get(v.name, _normalize_visual_type(v.visual_type))), -(v.width * v.height)),
    )

    layout: list[MockupVisual] = []
    cards = [v for v in ordered if to_type_by_visual.get(v.name, "") == "metric"][:3]
    non_cards = [v for v in ordered if v not in cards]

    if cards:
        card_w = (content_w - (margin * (len(cards) - 1))) / len(cards)
        for idx, v in enumerate(cards):
            layout.append(
                MockupVisual(
                    visual=v.name,
                    title=v.title or v.name,
                    visual_type="card",
                    x=margin + (idx * (card_w + margin)),
                    y=margin,
                    width=card_w,
                    height=card_h,
                )
            )

    y_cursor = margin + card_h + margin if cards else margin
    if non_cards:
        primary = non_cards[0]
        primary_type = to_type_by_visual.get(primary.name, _normalize_visual_type(primary.visual_type))
        layout.append(
            MockupVisual(
                visual=primary.name,
                title=primary.title or primary.name,
                visual_type=("line" if primary_type in {"line", "bar"} else primary_type),
                x=margin,
                y=y_cursor,
                width=content_w,
                height=chart_h,
            )
        )
        y_cursor += chart_h + margin

    secondary = non_cards[1:3]
    if secondary:
        col_w = (content_w - margin) / 2
        for idx, v in enumerate(secondary):
            to_type = to_type_by_visual.get(v.name, _normalize_visual_type(v.visual_type))
            layout.append(
                MockupVisual(
                    visual=v.name,
                    title=v.title or v.name,
                    visual_type=("bar" if idx == 0 and to_type == "line" else to_type),
                    x=margin + (idx * (col_w + margin)),
                    y=y_cursor,
                    width=col_w,
                    height=lower_h,
                )
            )
        y_cursor += lower_h + margin

    for v in non_cards[3:]:
        to_type = to_type_by_visual.get(v.name, _normalize_visual_type(v.visual_type))
        layout.append(
            MockupVisual(
                visual=v.name,
                title=v.title or v.name,
                visual_type=to_type,
                x=margin,
                y=y_cursor,
                width=content_w,
                height=220.0,
            )
        )
        y_cursor += 220.0 + margin

    return layout


def _format_sample(rows: list[list], columns: list[str]) -> str:
    if not rows:
        return "n/a"
    first = rows[0]
    if len(columns) == 1:
        return str(first[0])
    return ", ".join(f"{columns[i]}={first[i]}" for i in range(min(2, len(columns), len(first))))


def _visual_story(vs, data: dict) -> tuple[str, str, str, list[MetricEvidence]]:
    columns = data.get("columns") or []
    rows = data.get("rows") or []
    sample = _format_sample(rows, columns)
    title = vs.title or vs.name
    row_count = len(rows)
    dim_count = len(vs.dim_keys)
    has_series = bool(vs.series_keys)
    base_type = _normalize_visual_type(vs.visual_type)
    to_type = base_type
    if vs.visual_type in {"clusteredColumnChart", "clusteredBarChart", "barChart", "columnChart"} and row_count > 12:
        to_type = "line"
    elif vs.visual_type == "lineChart" and dim_count > 1:
        to_type = "bar"
    elif vs.visual_type in {"tableEx", "pivotTable"} and row_count <= 8 and dim_count <= 1:
        to_type = "callout"
    elif vs.visual_type == "card" and has_series:
        to_type = "bar"

    intent = (
        "establish what changed"
        if to_type == "metric"
        else "explain why it changed"
        if to_type in {"line", "bar"}
        else "validate where action is needed"
        if to_type in {"table", "callout"}
        else "support drill-down decisions"
    )
    gain = {
        "metric": "Highlights the headline KPI first, reducing time-to-insight for executives.",
        "line": "Improves trend readability across time so momentum and inflection points are obvious.",
        "bar": "Improves category comparison and rank-ordering to quickly identify top drivers.",
        "table": "Preserves audit detail for validation after the high-level narrative is understood.",
        "callout": "Summarizes decision-critical facts without forcing full-table scanning.",
        "chart": "Improves visual contrast and grouping so outliers are easier to spot.",
    }.get(to_type, "Improves signal-to-noise ratio for business decisioning.")
    evidence = [
        MetricEvidence(
            metric_key=(vs.measure_keys[0] if vs.measure_keys else title),
            visual=vs.name,
            page="",
            sample_value=sample,
            rationale=f"Derived from snapshot output for '{title}' and mapped to a storytelling role ({intent}).",
        )
    ]
    return intent, to_type, gain, evidence


def _derive_kpi_hierarchy(decisions: list[VisualDecision]) -> list[str]:
    if not decisions:
        return []
    top = sorted(decisions, key=lambda d: d.confidence, reverse=True)[:5]
    return [f"{d.title} ({d.kpi_intent})" for d in top]


def _build_web_story_modules(decisions: list[VisualDecision], report_name: str) -> list[WebStoryModule]:
    ordered = sorted(decisions, key=lambda d: d.confidence, reverse=True)
    hero = [d for d in ordered if d.to_type == "metric"][:3]
    drivers = [d for d in ordered if d.to_type in {"line", "bar", "pie"}][:4]
    diagnostics = [d for d in ordered if d.to_type in {"table", "callout", "chart"}][:4]

    top_kpi = hero[0].title if hero else (ordered[0].title if ordered else "Primary KPI")
    top_driver = drivers[0].title if drivers else "Key Driver"

    modules: list[WebStoryModule] = [
        WebStoryModule(
            slug="hero",
            title="Executive Hero",
            objective="State what changed in plain business terms within 5 seconds.",
            narrative=(
                f"Open with {top_kpi} as the headline outcome for {report_name}, then show a concise delta and confidence cue."
            ),
            layout_pattern="full-width hero band with 2-3 KPI cards and one compact trend sparkline",
            visual_refs=[d.visual for d in hero] or [d.visual for d in ordered[:1]],
            best_practices=[
                "One message per viewport; avoid competing KPI headlines.",
                "Use direct labels and period-over-period deltas near each KPI.",
                "Reserve saturated color for exception states only.",
            ],
        ),
        WebStoryModule(
            slug="drivers",
            title="Driver Lens",
            objective="Explain why the KPI moved and which segments contributed the most.",
            narrative=(
                f"Decompose {top_kpi} through {top_driver} and peer contributors, prioritizing ranked comparisons over dense detail."
            ),
            layout_pattern="2-column insight grid: trend at left, ranked contributors at right",
            visual_refs=[d.visual for d in drivers] or [d.visual for d in ordered[1:3]],
            best_practices=[
                "Use line charts for time trends and bar charts for rank comparisons.",
                "Keep category count focused; aggregate long-tail categories.",
                "Annotate inflection points with business events, not chart jargon.",
            ],
        ),
        WebStoryModule(
            slug="actions",
            title="Action Board",
            objective="Convert insight into next actions, owners, and watchouts.",
            narrative="Close with diagnostics and action callouts so users leave with a prioritized response plan.",
            layout_pattern="decision rail with exception table + action callout cards",
            visual_refs=[d.visual for d in diagnostics] or [d.visual for d in ordered[3:6]],
            best_practices=[
                "Place detail tables after summary insights, not before.",
                "Highlight only business-significant thresholds and exceptions.",
                "Attach action owner and timeline to every red/amber signal.",
            ],
        ),
    ]
    return modules


def _page_template(page) -> str:
    chart_count = sum(1 for v in page.visuals if v.visual_type.endswith("Chart"))
    card_count = sum(1 for v in page.visuals if v.visual_type == "card")
    if card_count >= 1 and chart_count >= 1:
        return "executive-summary"
    if chart_count >= 2:
        return "trend-command-center"
    return "decision-workbench"


def _page_blocks(page, scene: MockupScene) -> list[MockupBlock]:
    blocks: list[MockupBlock] = [
        MockupBlock(
            kind="section",
            title="Narrative",
            detail=scene.story_headline,
            tone="brand",
        )
    ]
    for visual in scene.visuals[:5]:
        role = (
            "headline KPI" if visual.visual_type == "card" else
            "trend/driver analysis" if visual.visual_type in {"line", "bar"} else
            "diagnostic detail" if visual.visual_type == "table" else
            "decision callout"
        )
        blocks.append(
            MockupBlock(
                kind="chart" if visual.visual_type in {"line", "bar", "chart", "pie"} else "metric",
                title=visual.title,
                detail=f"Assigned as {role} to support narrative flow from what changed to why and what to do next ({visual.visual_type}).",
                tone="neutral",
            )
        )
    return blocks


def _evaluate_quality(recommendation: DashboardRecommendation) -> ReimagineQuality:
    failures: list[str] = []
    has_evidence = sum(len(v.evidence) for v in recommendation.visual_decisions)
    total_decisions = max(1, len(recommendation.visual_decisions))
    evidence_coverage = min(1.0, has_evidence / total_decisions)
    unsupported_intents = sum(1 for d in recommendation.visual_decisions if d.confidence < 0.65)
    distinct_targets = len({d.to_type for d in recommendation.visual_decisions})
    diversity = distinct_targets / max(1, len(recommendation.visual_decisions))
    narrative = 0.9 if recommendation.intent_hypothesis and recommendation.decision_questions else 0.4
    justification = evidence_coverage
    realism = 0.85 if recommendation.mockup_scenes and recommendation.snapshot else 0.3

    generic_terms = ["cleaner", "better", "improve", "optimize"]
    text_pool = " ".join(
        [recommendation.summary]
        + recommendation.strategy
        + [d.expected_gain for d in recommendation.visual_decisions]
    ).lower()
    generic_hits = sum(1 for t in generic_terms if t in text_pool)
    penalty = min(0.5, generic_hits * 0.08)

    if narrative < 0.7:
        failures.append("narrative_quality_below_threshold")
    if justification < 0.7:
        failures.append("visual_justification_below_threshold")
    if realism < 0.75:
        failures.append("mockup_realism_below_threshold")
    if unsupported_intents > 0:
        failures.append("unsupported_intents_present")
    if diversity < 0.25:
        failures.append("visual_diversity_too_low")

    ready = not failures and penalty < 0.25
    if penalty >= 0.25:
        failures.append("generic_language_penalty_too_high")

    return ReimagineQuality(
        coverage=evidence_coverage,
        evidence_count=has_evidence,
        unsupported_intents=unsupported_intents,
        narrative_quality=max(0.0, narrative - penalty),
        visual_justification_quality=max(0.0, justification - (penalty / 2)),
        mockup_realism=max(0.0, realism - (penalty / 3)),
        generic_penalty=penalty,
        ready=ready,
        failures=failures,
    )


def build_recommendation(
    spec: DashboardSpec,
    conversion_id: str,
    snapshot: dict | None = None,
    snapshot_meta: ReimagineSnapshotMeta | None = None,
) -> DashboardRecommendation:
    snapshot = snapshot or {"results": []}
    snapshot_meta = snapshot_meta or ReimagineSnapshotMeta(
        id=f"legacy-{uuid.uuid4().hex[:8]}",
        generated_at=time.time(),
        visual_count=0,
        connection_id="unknown",
        mode="live",
    )

    by_page_visual: dict[tuple[str, str], dict] = {}
    for item in snapshot.get("results", []):
        page = item.get("page")
        visual = item.get("visual")
        if page and visual:
            by_page_visual[(str(page), str(visual))] = item

    pages: list[PageRecommendation] = []
    visual_decisions: list[VisualDecision] = []
    scenes: list[MockupScene] = []

    for page in spec.pages:
        supported = [v for v in page.visuals if v.supported and v.visual_type != "textbox"]
        to_type_by_visual: dict[str, str] = {}

        for v in supported:
            data = by_page_visual.get((page.name, v.name), {})
            intent, to_type, gain, evidence = _visual_story(v, data)
            to_type_by_visual[v.name] = to_type
            for ev in evidence:
                ev.page = page.name
            confidence = 0.82 if (data.get("rows") or []) else 0.58
            visual_decisions.append(
                VisualDecision(
                    page=page.name,
                    visual=v.name,
                    from_type=v.visual_type,
                    to_type=to_type,
                    title=v.title or v.name,
                    kpi_intent=intent,
                    expected_gain=gain,
                    confidence=confidence,
                    evidence=evidence,
                )
            )

        scene_visuals = _story_scene_layout(page, supported, to_type_by_visual)
        scene_data: dict[str, dict] = {}
        for sv in scene_visuals:
            payload = by_page_visual.get((page.name, sv.visual), {})
            scene_data[sv.visual] = {
                "columns": payload.get("columns", []),
                "rows": payload.get("rows", [])[:20],
            }

        story_headline = (
            f"{page.display_name}: start with KPI signal, move to trend and driver decomposition, "
            "then finish with actionable diagnostics."
        )
        scene = MockupScene(
            page=page.name,
            display_name=page.display_name,
            story_headline=story_headline,
            visuals=scene_visuals,
            data=scene_data,
        )
        scenes.append(scene)

        template = _page_template(page)
        blocks = _page_blocks(page, scene)
        pages.append(
            PageRecommendation(
                page=page.name,
                display_name=page.display_name,
                template=template,
                summary=f"Reimagined {page.display_name} as {template.replace('-', ' ')} using snapshot-backed KPI evidence.",
                rationale="Story arc is derived from real page values, preserving context while improving scanability.",
                changes=[
                    "Reordered page into story sequence: KPI headline, trend, driver breakdown, then diagnostic detail.",
                    "Converted visuals to best-fit encodings (line for trend, bar for comparison, table/callout for decisions).",
                    "Reduced cognitive load using progressive disclosure: summary first, detail on demand.",
                ],
                blocks=blocks,
            )
        )

    kpi_hierarchy = _derive_kpi_hierarchy(visual_decisions)
    top_conf = statistics.mean([d.confidence for d in visual_decisions]) if visual_decisions else 0.0
    top_titles = [d.title for d in sorted(visual_decisions, key=lambda d: d.confidence, reverse=True)[:2]]
    focus_label = " and ".join(top_titles) if top_titles else "our primary KPI"
    decision_questions = [
        f"What changed in {focus_label} versus plan and prior period?",
        "Which segments, geographies, or channels are driving the variance?",
        "What immediate action should owners take this week based on these signals?",
    ]

    recommendation = DashboardRecommendation(
        id=str(uuid.uuid4()),
        conversion_id=conversion_id,
        created_at=time.time(),
        summary=(
            f"Generated snapshot-backed reimagination for {spec.report_name} across {len(spec.pages)} page(s) "
            f"with {len(visual_decisions)} evidence-linked visual decisions."
        ),
        strategy=[
            "Apply BI storytelling arc: what changed, why it changed, what to do next.",
            "Use chart-design best practices: lines for trend, bars for rank comparison, details after summary.",
            "Keep every redesign decision evidence-linked to snapshot values to avoid invented narratives.",
        ],
        risks=[
            "Snapshot may age if source data changes; regenerate to refresh recommendations.",
            "Unsupported visual families are kept in-place with reduced confidence annotations.",
        ],
        pages=pages,
        intent_hypothesis=f"{spec.report_name} is used for operational and executive KPI monitoring.",
        audience="business operators and executive stakeholders",
        decision_questions=decision_questions,
        kpi_hierarchy=kpi_hierarchy,
        visual_decisions=visual_decisions,
        mockup_scenes=scenes,
        web_story_modules=_build_web_story_modules(visual_decisions, spec.report_name),
        snapshot=snapshot_meta,
    )

    quality = _evaluate_quality(recommendation)
    # Slightly reward dense evidence for non-generic narratives.
    if top_conf > 0.75 and quality.ready:
        quality.narrative_quality = min(1.0, quality.narrative_quality + 0.03)
    recommendation.quality = quality
    return recommendation


def _metadata(payload: DashboardRecommendation) -> dict:
    return {
        "id": payload.id,
        "created_at": payload.created_at,
        "status": payload.status,
        "summary": payload.summary,
        "page_count": len(payload.pages),
        "conversion_id": payload.conversion_id,
        "snapshot_id": payload.snapshot.id if payload.snapshot else None,
        "quality": payload.quality.model_dump(mode="json"),
    }


def _read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, payload: dict) -> None:
    def _json_default(value):
        if isinstance(value, Decimal):
            # Query results may carry Decimal values from warehouse drivers.
            return float(value)
        raise TypeError(f"Object of type {value.__class__.__name__} is not JSON serializable")

    path.write_text(json.dumps(payload, indent=2, default=_json_default), encoding="utf-8")


def save_snapshot(root: Path, payload: dict) -> ReimagineSnapshotMeta:
    snapshot_id = str(uuid.uuid4())
    meta = ReimagineSnapshotMeta(
        id=snapshot_id,
        generated_at=time.time(),
        visual_count=len(payload.get("results", [])),
        connection_id=str(payload.get("connection_id", "")),
        mode=str(payload.get("mode", "live")) if payload.get("mode") in {"live", "accelerated"} else "live",
    )
    payload_with_meta = {
        "meta": meta.model_dump(mode="json"),
        "results": payload.get("results", []),
    }
    _write_json(_snapshot_path(root, snapshot_id), payload_with_meta)
    return meta


def load_snapshot(root: Path, snapshot_id: str) -> dict | None:
    path = _snapshot_path(root, snapshot_id)
    if not path.is_file():
        return None
    return _read_json(path)


def save_recommendation(root: Path, recommendation: DashboardRecommendation) -> DashboardRecommendation:
    _write_json(_recommendation_path(root, recommendation.id), recommendation.model_dump(mode="json"))
    index = list_recommendations(root)
    index = [item for item in index if item["id"] != recommendation.id]
    index.insert(0, _metadata(recommendation))
    _write_json(_index_path(root), {"recommendations": index})
    return recommendation


def load_recommendation(root: Path, recommendation_id: str) -> DashboardRecommendation | None:
    path = _recommendation_path(root, recommendation_id)
    if not path.is_file():
        return None
    return DashboardRecommendation.model_validate(_read_json(path))


def list_recommendations(root: Path) -> list[dict]:
    path = _index_path(root)
    if not path.is_file():
        return []
    try:
        payload = _read_json(path)
    except ValueError:
        return []
    items = payload.get("recommendations")
    if not isinstance(items, list):
        return []
    return [item for item in items if isinstance(item, dict) and item.get("id")]


def latest_recommendation(root: Path) -> DashboardRecommendation | None:
    items = list_recommendations(root)
    if not items:
        return None
    latest = max(items, key=lambda item: float(item.get("created_at") or 0.0))
    return load_recommendation(root, str(latest["id"]))


def update_recommendation_status(
    root: Path,
    recommendation_id: str,
    status: Literal["approved", "rejected"],
    note: str | None = None,
) -> DashboardRecommendation | None:
    payload = load_recommendation(root, recommendation_id)
    if payload is None:
        return None
    payload.status = status
    payload.decisions.append(
        {
            "status": status,
            "note": note or "",
            "decided_at": time.time(),
            "build_message": payload.build_message,
            "quality": payload.quality.model_dump(mode="json"),
        }
    )
    save_recommendation(root, payload)
    return payload
