"""Semantic View deployment API.

Endpoints:
  GET  /api/v1/conversions/{id}/semantic-yaml        – preview the YAML spec
  POST /api/v1/conversions/{id}/deploy-semantic-view – deploy to Snowflake
  POST /api/v1/conversions/{id}/sync-semantic-view   – incremental sync (CREATE OR ALTER)
"""

from __future__ import annotations

import json
import time
import re

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
import yaml

from app.api.deps import get_connection_store, get_ingest_service, require_token
from app.semantic.yaml_compiler import SemanticViewYamlCompiler, prune_spec_to_live_schema
from app.services.connections import ConnectionStore
from app.services.ingest import IngestService
from app.validation.drift import detect_schema_drift

router = APIRouter(
    prefix="/api/v1/conversions/{conversion_id}",
    tags=["semantic-view"],
    dependencies=[Depends(require_token)],
)


def _load_compiler(
    conversion_id: str,
    svc: IngestService,
    tier2_sql: dict[str, str],
    view_name: str | None,
) -> SemanticViewYamlCompiler:
    from app.runtime.dashboard import compile_dashboard

    bundle = svc.load_bundle(conversion_id)
    _, binding_map = compile_dashboard(bundle, tier2_sql=tier2_sql)
    return SemanticViewYamlCompiler(bundle.model, binding_map, tier2_sql, view_name)


def _tier2_sql(conversion_id: str, svc: IngestService) -> dict[str, str]:
    try:
        path = svc.conversion_dir(conversion_id) / "conversion_run.json"
    except ValueError:
        return {}
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("tier2_accepted", {})
    except (OSError, ValueError):
        return {}


# ---------------------------------------------------------------------------
# Preview YAML
# ---------------------------------------------------------------------------

@router.get("/semantic-yaml")
def get_semantic_yaml(
    conversion_id: str,
    view_name: str | None = None,
    svc: IngestService = Depends(get_ingest_service),
) -> dict:
    """Return the Snowflake Semantic View YAML spec (preview without deploying)."""
    try:
        compiler = _load_compiler(
            conversion_id, svc, _tier2_sql(conversion_id, svc), view_name
        )
    except Exception as e:
        raise HTTPException(404, f"conversion not found: {e}") from e

    spec = compiler.compile()
    yaml_text = compiler.compile_yaml()
    return {
        "view_name": compiler.view_name,
        "spec": spec,
        "yaml": yaml_text,
        "table_count": len(spec.get("tables", [])),
        "relationship_count": len(spec.get("relationships", [])),
        "metric_count": sum(
            len(t.get("metrics", []))
            for t in spec.get("tables", [])
        ) + len(spec.get("metrics", [])),
        "dimension_count": sum(
            len(t.get("dimensions", []))
            for t in spec.get("tables", [])
        ),
    }


# ---------------------------------------------------------------------------
# Deploy
# ---------------------------------------------------------------------------

class DeployRequest(BaseModel):
    database: str | None = Field(None, description="Deprecated override for target Snowflake database")
    schema_name: str | None = Field(None, description="Deprecated override for target Snowflake schema")
    view_name: str | None = Field(None, description="Override view name")
    yaml_override: str | None = Field(None, description="Optional edited YAML to deploy instead of compiled output")
    dry_run: bool = Field(False, description="If true, validate without creating")
    connection_id: str = Field(..., description="Connection ID with Snowflake credentials")
    create_or_alter: bool = Field(
        True, description="Use CREATE OR ALTER to preserve materializations"
    )


class DeployResult(BaseModel):
    success: bool
    partial_success: bool = False
    view_name: str
    message: str
    yaml: str
    warnings: list[str] = Field(default_factory=list)
    materializations: list[dict] = Field(default_factory=list)
    materialization_refresh: dict = Field(default_factory=dict)


class DriftRequest(BaseModel):
    connection_id: str = Field(..., description="Connection ID with Snowflake credentials")
    database: str = Field(..., description="Database to inspect INFORMATION_SCHEMA")


def _traceability_path(svc: IngestService, conversion_id: str):
    return svc.conversion_dir(conversion_id) / "semantic_traceability.json"


def _spec_counts(spec: dict) -> dict:
    return {
        "table_count": len(spec.get("tables", [])),
        "relationship_count": len(spec.get("relationships", [])),
        "metric_count": sum(len(t.get("metrics", [])) for t in spec.get("tables", []))
        + len(spec.get("metrics", [])),
        "dimension_count": sum(len(t.get("dimensions", [])) for t in spec.get("tables", [])),
    }


def _materialization_refresh_state(history: list[dict], materializations: list[dict]) -> dict:
    latest = history[-1] if history else None
    latest_materialized = None
    for entry in reversed(history):
        if int(entry.get("materialization_count") or 0) > 0:
            latest_materialized = entry
            break

    if latest_materialized is not None:
        return {
            "status": "materialized",
            "owner": latest_materialized.get("refresh_owner"),
            "last_refreshed_at": latest_materialized.get("deployed_at"),
            "materialization_count": int(latest_materialized.get("materialization_count") or 0),
        }

    if latest is not None:
        return {
            "status": "semantic_view_only" if not materializations else "pending_materialization",
            "owner": latest.get("refresh_owner"),
            "last_refreshed_at": latest.get("deployed_at"),
            "materialization_count": int(latest.get("materialization_count") or 0),
        }

    return {
        "status": "pending_deploy" if materializations else "not_deployed",
        "owner": None,
        "last_refreshed_at": None,
        "materialization_count": len(materializations),
    }


def _resolve_deploy_target(req: DeployRequest, profile) -> tuple[str, str]:
    if not profile.database or not profile.schema_name:
        raise HTTPException(
            422,
            "selected connection must define default database and schema before semantic deploy",
        )
    if req.database is not None and req.database != profile.database:
        raise HTTPException(
            422,
            "database override is disabled; use the connection default database",
        )
    if req.schema_name is not None and req.schema_name != profile.schema_name:
        raise HTTPException(
            422,
            "schema override is disabled; use the connection default schema",
        )
    return profile.database, profile.schema_name


def _slug_materialization_name(view_name: str, table_name: str, lifecycle: str) -> str:
    suffix = "DT" if lifecycle == "dynamic_table" else "TB"
    raw = f"{view_name}__{suffix}__{table_name}"
    return re.sub(r"[^A-Za-z0-9_]+", "_", raw).strip("_") or "PBI_MATERIALIZATION"


def _materialization_target(view_name: str, table_name: str, database: str, schema_name: str, lifecycle: str) -> dict:
    return {
        "database": database,
        "schema": schema_name,
        "table": _slug_materialization_name(view_name, table_name, lifecycle),
    }


def _materialization_target_object(view_name: str, table_name: str, lifecycle: str) -> str:
    return _slug_materialization_name(view_name, table_name, lifecycle)


def _materialization_lifecycle(warehouse: str | None) -> str:
    return "dynamic_table" if warehouse else "table"


def _qident(value: str) -> str:
    return '"' + value.replace('"', '""') + '"'


def _materialization_ddl(
    target: dict,
    sql: str,
    lifecycle: str,
    warehouse: str | None,
) -> str:
    target_fq = f'{_qident(target["database"])}.{_qident(target["schema"])}.{_qident(target["table"])}'
    if lifecycle == "dynamic_table":
        if not warehouse:
            raise HTTPException(422, "dynamic table materializations require a Snowflake warehouse")
        return (
            f"CREATE OR REPLACE DYNAMIC TABLE {target_fq} "
            f"TARGET_LAG = '1 hour' WAREHOUSE = {_qident(warehouse)} AS {sql}"
        )
    return f"CREATE OR REPLACE TABLE {target_fq} AS {sql}"


def _apply_materialization_targets(spec: dict, materializations: list[dict], database: str, schema_name: str, view_name: str) -> dict:
    if not materializations:
        return spec
    target_by_table = {
        item["table"]: _materialization_target(view_name, item["table"], database, schema_name, item.get("lifecycle", "table"))
        for item in materializations
    }
    for table in spec.get("tables", []):
        target = target_by_table.get(table.get("name"))
        if target is None:
            continue
        table["base_table"] = target
    return spec


def _deploy_materializations(
    cursor,
    materializations: list[dict],
    database: str,
    schema_name: str,
    view_name: str,
    warehouse: str | None,
) -> list[dict]:
    deployed: list[dict] = []
    for item in materializations:
        lifecycle = _materialization_lifecycle(warehouse)
        target = _materialization_target(view_name, item["table"], database, schema_name, lifecycle)
        cursor.execute(_materialization_ddl(target, item["sql"], lifecycle, warehouse))
        deployed.append({
            **item,
            "target_object": f"{target['database']}.{target['schema']}.{target['table']}",
            "lifecycle": lifecycle,
        })
    return deployed


def _table_mappings(binding_map, bundle) -> list[dict]:
    """Build source-target mapping from the actual BindingMap used by the query engine."""
    mappings: list[dict] = []
    for table in bundle.model.tables:
        if table.is_auto_date_table:
            mappings.append(
                {"pbi_table": table.name, "status": "skipped", "reason": "auto date table"}
            )
            continue
        binding = binding_map.get(table.name)
        if binding is None:
            mappings.append(
                {"pbi_table": table.name, "status": "unmapped", "reason": "no physical binding found"}
            )
            continue
        if binding.is_virtual:
            mappings.append(
                {"pbi_table": table.name, "status": "skipped", "reason": "virtual table (calculated/parameter)"}
            )
            continue
        if binding.status == "materialization_required":
            mappings.append(
                {
                    "pbi_table": table.name,
                    "status": "materialization_required",
                    "strategy": binding.materialization_strategy or "view",
                    "reason": binding.detail or "M transforms require physical materialization before semantic-view binding",
                }
            )
            continue
        if binding.status != "resolved":
            mappings.append(
                {"pbi_table": table.name, "status": "unmapped", "reason": f"binding {binding.status}"}
            )
            continue
        fq = ".".join(
            part
            for part in (binding.database, binding.schema_name, binding.object_name)
            if part
        )
        mappings.append(
            {"pbi_table": table.name, "status": "mapped", "snowflake_table": fq}
        )
    return mappings


def _measure_execution_summary(dashboard_spec, tier2_sql: dict[str, str]) -> dict:
    """Measure coverage based on the actual query engine tiers (what the dashboard uses),
    not the semantic view YAML compiler."""
    translated: list[dict] = []
    untranslated: list[dict] = []
    by_tier: dict[str, int] = {}

    for name, tier in dashboard_spec.measure_tiers.items():
        if tier >= 0:
            tier_label = {0: "tier0_deterministic", 1: "tier1_deterministic"}.get(tier, f"tier{tier}")
            if name in tier2_sql:
                tier_label = "tier2_ai_translated"
            translated.append({"measure": name, "tier": tier_label})
            by_tier[tier_label] = by_tier.get(tier_label, 0) + 1
        else:
            untranslated.append({"measure": name, "reason": "DAX outside supported tiers; needs AI translation or manual SQL"})

    total = len(translated) + len(untranslated)
    return {
        "pbi_measure_total": total,
        "translated_measure_total": len(translated),
        "untranslated_measure_total": len(untranslated),
        "translation_rate": round(len(translated) / total, 4) if total else 1.0,
        "translated_by_tier": by_tier,
        "untranslated": untranslated,
    }


def _preview_payload(conversion_id: str, svc: IngestService, view_name: str | None = None) -> dict:
    compiler = _load_compiler(conversion_id, svc, _tier2_sql(conversion_id, svc), view_name)
    spec = compiler.compile()
    lifecycle = "dynamic_table"
    materializations = [
        {
            **item,
            "target_object": _materialization_target_object(compiler.view_name, item["table"], lifecycle),
            "lifecycle": lifecycle,
        }
        for item in compiler.materialization_plan()
    ]
    from app.runtime.dashboard import compile_dashboard

    bundle = svc.load_bundle(conversion_id)
    dashboard_spec, binding_map = compile_dashboard(bundle, tier2_sql=_tier2_sql(conversion_id, svc))
    measure_summary = _measure_execution_summary(dashboard_spec, _tier2_sql(conversion_id, svc))
    mappings = _table_mappings(binding_map, bundle)
    trace_path = _traceability_path(svc, conversion_id)
    history: list[dict] = []
    if trace_path.is_file():
        try:
            history = json.loads(trace_path.read_text(encoding="utf-8")).get("deployments", [])
        except ValueError:
            history = []

    return {
        "view_name": compiler.view_name,
        "spec": spec,
        "pbi_model": {
            "name": bundle.model.name,
            "table_count": len(bundle.model.tables),
            "relationship_count": len(bundle.model.relationships),
            "measure_count": sum(len(table.measures) for table in bundle.model.tables),
            "tables": [
                {
                    "name": table.name,
                    "columns": len(table.columns),
                    "measures": len(table.measures),
                }
                for table in bundle.model.tables
                if not table.is_auto_date_table
            ],
        },
        "snowflake_view": {
            "name": compiler.view_name,
            "tables": [
                {
                    "name": table.get("name"),
                    "base_table": table.get("base_table"),
                    "dimension_count": len(table.get("dimensions", [])),
                    "metric_count": len(table.get("metrics", [])),
                }
                for table in spec.get("tables", [])
            ],
        },
        "measure_translation": measure_summary,
        "source_target_mappings": mappings,
        "materializations": materializations,
        "materialization_refresh": _materialization_refresh_state(history, materializations),
        "binding_summary": {
            "resolved": sum(1 for b in binding_map.bindings.values() if b.status == "resolved"),
            "virtual": sum(1 for b in binding_map.bindings.values() if b.status == "virtual"),
            "materialization_required": sum(
                1 for b in binding_map.bindings.values() if b.status == "materialization_required"
            ),
            "materialization_by_strategy": {
                strategy: sum(
                    1
                    for b in binding_map.bindings.values()
                    if b.status == "materialization_required" and b.materialization_strategy == strategy
                )
                for strategy in sorted(
                    {
                        b.materialization_strategy
                        for b in binding_map.bindings.values()
                        if b.status == "materialization_required" and b.materialization_strategy
                    }
                )
            },
            "unresolved": sum(1 for b in binding_map.bindings.values() if b.status == "unresolved"),
        },
        "query_execution": {
            "primary_path": "semantic_view",
            "fallback_path": "semantic_engine",
            "notes": "Dashboard queries should run via semantic view first, then fall back to direct SQL for unsupported measures.",
        },
        "yaml": compiler.compile_yaml(),
        **_spec_counts(spec),
    }


@router.get("/semantic-traceability")
def get_semantic_traceability(
    conversion_id: str,
    svc: IngestService = Depends(get_ingest_service),
) -> dict:
    """Return planned semantic-view metadata plus deployment history."""
    try:
        preview = _preview_payload(conversion_id, svc)
    except Exception as e:
        raise HTTPException(404, f"conversion not found: {e}") from e

    path = _traceability_path(svc, conversion_id)
    history: list[dict] = []
    if path.is_file():
        try:
            history = json.loads(path.read_text(encoding="utf-8")).get("deployments", [])
        except ValueError:
            history = []
    return {
        "preview": preview,
        "latest": history[-1] if history else None,
        "semantic_view_location": (history[-1] or {}).get("fully_qualified_view") if history else None,
        "semantic_view_creation_mode": "created_on_deploy_only",
        "deployments": history,
    }


@router.post("/deploy-semantic-view", response_model=DeployResult)
def deploy_semantic_view(
    conversion_id: str,
    req: DeployRequest,
    svc: IngestService = Depends(get_ingest_service),
    conn_store: ConnectionStore = Depends(get_connection_store),
) -> DeployResult:
    """Compile PBI model to Snowflake Semantic View YAML and deploy via
    SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML."""
    t2 = _tier2_sql(conversion_id, svc)
    try:
        compiler = _load_compiler(conversion_id, svc, t2, req.view_name)
    except Exception as e:
        raise HTTPException(404, f"conversion not found: {e}") from e

    spec = compiler.compile()
    materializations = compiler.materialization_plan()
    yaml_text = req.yaml_override or compiler.compile_yaml()
    if req.yaml_override:
        try:
            parsed = yaml.safe_load(req.yaml_override) or {}
            if isinstance(parsed, dict):
                spec = parsed
        except yaml.YAMLError as e:
            raise HTTPException(422, f"invalid YAML override: {e}") from e
    warnings: list[str] = []
    try:
        profile = conn_store.get(req.connection_id)
        target_database, target_schema = _resolve_deploy_target(req, profile)
        schema_fq = f"{target_database}.{target_schema}"
        cursor = _open_cursor(conn_store, req.connection_id, conversion_id)
        if materializations and not req.dry_run and not req.yaml_override:
            materializations = _deploy_materializations(
                cursor,
                materializations,
                target_database,
                target_schema,
                compiler.view_name,
                profile.warehouse,
            )
        if not req.yaml_override:
            if not req.dry_run:
                spec = _apply_materialization_targets(
                    spec,
                    materializations,
                    target_database,
                    target_schema,
                    compiler.view_name,
                )
            # model columns from unapplied M transforms may not exist physically
            spec, prune_warnings = prune_spec_to_live_schema(spec, cursor)
            warnings.extend(prune_warnings)
            yaml_text = yaml.dump(
                spec, default_flow_style=False, allow_unicode=True, sort_keys=False
            )
        msg = _call_create_sv(
            cursor,
            schema_fq,
            yaml_text,
            dry_run=req.dry_run,
            create_or_alter=req.create_or_alter,
        )
        cursor.close()
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Snowflake deployment failed: {e}") from e

    trace_path = _traceability_path(svc, conversion_id)
    try:
        existing = json.loads(trace_path.read_text(encoding="utf-8")) if trace_path.is_file() else {}
    except ValueError:
        existing = {}
    deployments = list(existing.get("deployments", []))
    deployments.append(
        {
            "deployed_at": time.time(),
            "database": target_database,
            "schema_name": target_schema,
            "view_name": compiler.view_name,
            "fully_qualified_view": f"{target_database}.{target_schema}.{compiler.view_name}",
            "dry_run": req.dry_run,
            "create_or_alter": req.create_or_alter,
            "message": msg,
            "yaml": yaml_text,
            **_spec_counts(spec),
            "materialization_count": len(materializations),
            "materializations": materializations,
            "refresh_owner": profile.name,
        }
    )
    trace_path.write_text(json.dumps({"deployments": deployments}, indent=2), encoding="utf-8")

    refresh_state = _materialization_refresh_state(deployments, materializations)

    return DeployResult(
        success=True,
        partial_success=bool(materializations),
        view_name=compiler.view_name,
        message=(msg + (f"; {len(materializations)} derived table(s) require materialization" if materializations else "")),
        yaml=yaml_text,
        warnings=warnings,
        materializations=materializations,
        materialization_refresh=refresh_state,
    )


# ---------------------------------------------------------------------------
# Incremental sync
# ---------------------------------------------------------------------------

@router.post("/sync-semantic-view", response_model=DeployResult)
def sync_semantic_view(
    conversion_id: str,
    req: DeployRequest,
    svc: IngestService = Depends(get_ingest_service),
    conn_store: ConnectionStore = Depends(get_connection_store),
) -> DeployResult:
    """Same as deploy but always uses CREATE OR ALTER semantics to preserve
    existing materializations."""
    req.create_or_alter = True
    return deploy_semantic_view(conversion_id, req, svc, conn_store)


@router.post("/semantic-drift")
def semantic_drift(
    conversion_id: str,
    req: DriftRequest,
    svc: IngestService = Depends(get_ingest_service),
    conn_store: ConnectionStore = Depends(get_connection_store),
) -> dict:
    """Detect schema drift between current bindings and live INFORMATION_SCHEMA."""
    from app.runtime.dashboard import compile_dashboard

    try:
        bundle = svc.load_bundle(conversion_id)
    except Exception as e:
        raise HTTPException(404, f"conversion not found: {e}") from e

    tier2 = _tier2_sql(conversion_id, svc)
    _, binding_map = compile_dashboard(bundle, tier2_sql=tier2)
    cursor = None
    try:
        cursor = _open_cursor(conn_store, req.connection_id, conversion_id)
        report = detect_schema_drift(binding_map, cursor, req.database)
    finally:
        if cursor is not None:
            try:
                cursor.close()
            except Exception:
                pass
    return report.model_dump()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _open_cursor(conn_store: ConnectionStore, connection_id: str, conversion_id: str):
    """Open a cursor from a ConnectionStore entry (Snowflake only)."""
    import snowflake.connector  # type: ignore[import]

    cfg = conn_store.connector_kwargs(connection_id, query_tag=f"pbi_converter:{conversion_id}")
    conn = snowflake.connector.connect(**cfg)
    return conn.cursor()


def _call_create_sv(
    cursor,
    schema_fq: str,
    yaml_text: str,
    *,
    dry_run: bool,
    create_or_alter: bool,
) -> str:
    verify_flag = "TRUE" if dry_run else "FALSE"
    alter_flag = "TRUE" if create_or_alter else "FALSE"
    sql = (
        f"CALL SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML("
        f"'{schema_fq}', $${yaml_text}$$, {verify_flag}, {alter_flag})"
    )
    cursor.execute(sql)
    row = cursor.fetchone()
    return str(row[0]) if row else "Done"
