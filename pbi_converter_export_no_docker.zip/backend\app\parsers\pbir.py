"""PBIR (enhanced report format) parser -> PBI-IR Report.

Reads the `definition/` folder of a *.Report: report.json, pages/, visuals/.
Unknown properties are tolerated (PBIR is a preview format); anything we
cannot interpret lands in `warnings` rather than failing the conversion.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from app.ir.report import (
    Filter,
    FilterScope,
    Page,
    Report,
    Visual,
    VisualField,
    VisualPosition,
)


class PbirParseError(Exception):
    pass


def _load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise PbirParseError(f"{path}: invalid JSON: {e}") from e


def _field_ref(field: dict) -> tuple[str | None, str | None, bool, dict]:
    """Extract (table, name, is_measure, extras) from a PBIR field expression."""
    if "Measure" in field:
        m = field["Measure"]
        return (
            m.get("Expression", {}).get("SourceRef", {}).get("Entity"),
            m.get("Property"),
            True,
            {},
        )
    if "Column" in field:
        c = field["Column"]
        return (
            c.get("Expression", {}).get("SourceRef", {}).get("Entity"),
            c.get("Property"),
            False,
            {},
        )
    if "Aggregation" in field:
        agg = field["Aggregation"]
        inner_table, inner_name, _, _ = _field_ref(agg.get("Expression", {}))
        func = _AGG_FUNCTIONS.get(agg.get("Function", -1))
        return inner_table, inner_name, False, {"aggregate": func}
    if "HierarchyLevel" in field:
        hl = field["HierarchyLevel"]
        hierarchy = hl.get("Expression", {}).get("Hierarchy", {})
        table = hierarchy.get("Expression", {}).get("SourceRef", {}).get("Entity")
        return table, hl.get("Level"), False, {
            "is_hierarchy_level": True,
            "hierarchy": hierarchy.get("Hierarchy"),
        }
    return None, None, False, {}


# PBI Aggregation.Function enum
_AGG_FUNCTIONS = {
    0: "Sum",
    1: "Avg",
    2: "Count",
    3: "Min",
    4: "Max",
    5: "CountNonNull",
    6: "Median",
    7: "StandardDeviation",
    8: "Variance",
}


def _parse_filter(obj: dict, scope: FilterScope) -> Filter:
    table, name, is_measure, _ = _field_ref(obj.get("field", {}))
    return Filter(
        name=obj.get("name"),
        scope=scope,
        field_table=table,
        field_name=name,
        field_is_measure=is_measure,
        filter_type=obj.get("type", "Categorical"),
        definition=obj.get("filter", {}),
        is_hidden=obj.get("isHiddenInViewMode", False),
    )


def _parse_filter_config(config: dict | None, scope: FilterScope) -> list[Filter]:
    if not config:
        return []
    return [_parse_filter(f, scope) for f in config.get("filters", [])]


def _literal_text(objects: dict, section: str, prop: str) -> str | None:
    """Pull a `Literal` string out of `objects.<section>[0].properties.<prop>`."""
    try:
        raw = objects[section][0]["properties"][prop]["expr"]["Literal"]["Value"]
    except (KeyError, IndexError, TypeError):
        return None
    return raw.strip("'") if isinstance(raw, str) else None


def _parse_visual(vdir: Path, warnings: list[str]) -> Visual | None:
    vjson = vdir / "visual.json"
    if not vjson.is_file():
        warnings.append(f"visual folder without visual.json: {vdir.name}")
        return None
    data = _load_json(vjson)
    visual_conf: dict[str, Any] = data.get("visual", {})
    pos = data.get("position", {})

    fields: list[VisualField] = []
    query_state = visual_conf.get("query", {}).get("queryState", {})
    for role, role_conf in query_state.items():
        for proj in role_conf.get("projections", []):
            table, name, is_measure, extras = _field_ref(proj.get("field", {}))
            fields.append(
                VisualField(
                    role=role,
                    table=table,
                    name=name,
                    is_measure=is_measure,
                    display_name=proj.get("displayName") or proj.get("nativeQueryRef"),
                    query_ref=proj.get("queryRef"),
                    aggregate=extras.get("aggregate"),
                    is_hierarchy_level=extras.get("is_hierarchy_level", False),
                    hierarchy=extras.get("hierarchy"),
                )
            )

    sort_defs: list[dict] = []
    for s in visual_conf.get("query", {}).get("sortDefinition", {}).get("sort", []):
        table, name, is_measure, _ = _field_ref(s.get("field", {}))
        sort_defs.append(
            {
                "table": table,
                "field": name,
                "is_measure": is_measure,
                "direction": s.get("direction", "Ascending"),
            }
        )

    return Visual(
        name=data.get("name", vdir.name),
        visual_type=visual_conf.get("visualType", "unknown"),
        position=VisualPosition(
            x=pos.get("x", 0),
            y=pos.get("y", 0),
            width=pos.get("width", 0),
            height=pos.get("height", 0),
            z=pos.get("z", 0),
            tab_order=pos.get("tabOrder"),
        ),
        title=_literal_text(visual_conf.get("visualContainerObjects", {}), "title", "text"),
        fields=fields,
        filters=_parse_filter_config(visual_conf.get("filterConfig"), FilterScope.VISUAL)
        + _parse_filter_config(data.get("filterConfig"), FilterScope.VISUAL),
        sort=sort_defs,
        formatting=visual_conf.get("objects", {}),
        container_objects=visual_conf.get("visualContainerObjects", {}),
        is_hidden=data.get("isHidden", False),
    )


def _parse_page(pdir: Path, ordinal: int, warnings: list[str]) -> Page:
    pj = _load_json(pdir / "page.json")
    visuals: list[Visual] = []
    visuals_dir = pdir / "visuals"
    if visuals_dir.is_dir():
        for vdir in sorted(visuals_dir.iterdir()):
            if vdir.is_dir():
                v = _parse_visual(vdir, warnings)
                if v is not None:
                    visuals.append(v)
    return Page(
        name=pj.get("name", pdir.name),
        display_name=pj.get("displayName", pdir.name),
        ordinal=ordinal,
        width=pj.get("width", 1280),
        height=pj.get("height", 720),
        visuals=visuals,
        filters=_parse_filter_config(pj.get("filterConfig"), FilterScope.PAGE),
        is_hidden=pj.get("visibility", "AlwaysVisible") == "HiddenInViewMode",
        background=pj.get("objects", {}).get("background", [{}])[0] if pj.get("objects") else {},
    )


def _load_custom_theme(report_dir: Path, theme_collection: dict) -> dict:
    """Resolve the customTheme name against StaticResources/RegisteredResources."""
    name = theme_collection.get("customTheme", {}).get("name")
    if not name:
        return {}
    for candidate in (
        report_dir / "StaticResources" / "RegisteredResources" / f"{name}.json",
        report_dir / "StaticResources" / "RegisteredResources" / name,
    ):
        if candidate.is_file():
            try:
                return json.loads(candidate.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                return {}
    return {}


def parse_report_definition(report_dir: Path) -> tuple[Report, list[str]]:
    """Parse `<X>.Report/` (with `definition/` inside) into IR Report + warnings."""
    warnings: list[str] = []
    definition = report_dir / "definition"
    if not definition.is_dir():
        if (report_dir / "report.json").is_file():
            raise PbirParseError(
                "report uses PBIR-Legacy (report.json); re-save with the PBIR "
                "preview feature enabled in Power BI Desktop"
            )
        raise PbirParseError(f"no definition/ folder in {report_dir}")

    rj = _load_json(definition / "report.json") if (definition / "report.json").is_file() else {}

    pages_dir = definition / "pages"
    page_order: list[str] = []
    if (pages_dir / "pages.json").is_file():
        page_order = _load_json(pages_dir / "pages.json").get("pageOrder", [])

    page_dirs = {p.name: p for p in pages_dir.iterdir() if p.is_dir()} if pages_dir.is_dir() else {}
    ordered = [page_dirs[n] for n in page_order if n in page_dirs]
    ordered += [p for n, p in sorted(page_dirs.items()) if n not in set(page_order)]

    pages = [_parse_page(pdir, i, warnings) for i, pdir in enumerate(ordered)]

    # report-level measures (reportExtensions.json), fed into the same DAX path later
    extension_measures: dict[str, list[str]] = {}
    ext_file = definition / "reportExtensions.json"
    if ext_file.is_file():
        ext = _load_json(ext_file)
        for entity in ext.get("entities", []):
            names = [m.get("name", "") for m in entity.get("measures", [])]
            extension_measures[entity.get("name", "")] = [n for n in names if n]

    theme_collection = rj.get("themeCollection", {})
    custom_theme = _load_custom_theme(report_dir, theme_collection)
    report = Report(
        name=report_dir.name.removesuffix(".Report"),
        pages=pages,
        filters=_parse_filter_config(rj.get("filterConfig"), FilterScope.REPORT),
        theme={"collection": theme_collection, "custom": custom_theme},
        extension_measures=extension_measures,
    )
    return report, warnings


def resolve_dataset_reference(report_dir: Path) -> Path:
    """Follow definition.pbir's datasetReference; byConnection is rejected."""
    pbir = report_dir / "definition.pbir"
    if not pbir.is_file():
        raise PbirParseError(f"missing definition.pbir in {report_dir}")
    data = _load_json(pbir)
    ref = data.get("datasetReference", {})
    if "byConnection" in ref:
        raise PbirParseError(
            "this report references a remote semantic model (byConnection); "
            "open it in Power BI Desktop and save with a local model (byPath) first"
        )
    by_path = ref.get("byPath", {}).get("path")
    if not by_path:
        raise PbirParseError("definition.pbir has no datasetReference.byPath.path")
    resolved = (report_dir / by_path).resolve()
    if not resolved.is_dir():
        raise PbirParseError(f"semantic model folder not found: {resolved}")
    return resolved
