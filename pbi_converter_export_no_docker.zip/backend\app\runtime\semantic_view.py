"""Semantic View query adapter.

Builds deterministic Snowflake ``SEMANTIC_VIEW`` SQL plans from dashboard
query specs, including request-scoped execution metadata for observability.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from app.ir.model import SemanticModel

class SemanticViewPlanError(Exception):
    pass


_SIMPLE_AGG_MAP = {
    "SUM": "SUM",
    "COUNT": "COUNT",
    "AVG": "AVG",
    "AVERAGE": "AVG",
    "MIN": "MIN",
    "MAX": "MAX",
}


class SemanticViewRequest(BaseModel):
    # QuerySpec-like object from runtime.engine (kept loose to avoid heavy import coupling)
    query: object
    model_version: str = "v1"
    data_version: str | None = None
    row_scope_id: str | None = None
    preferred_view: str | None = None


class SemanticViewPlan(BaseModel):
    sql: str
    warnings: list[str] = Field(default_factory=list)
    trace_codes: list[str] = Field(default_factory=list)


class SemanticViewAdapter:
    """Semantic-view SQL planner used by tier-A native execution."""

    def __init__(self, model: SemanticModel):
        self.model = model

    def _qident(self, name: str) -> str:
        return '"' + name.replace('"', '""') + '"'

    def _qobj(self, name: str) -> str:
        parts = [p.strip() for p in name.split(".") if p.strip()]
        if not parts:
            raise SemanticViewPlanError("invalid semantic view name")
        return ".".join(self._qident(p) for p in parts)

    def _lit(self, value) -> str:
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, (int, float)):
            return repr(value)
        return "'" + str(value).replace("'", "''") + "'"

    def _resolve_view_name(self, req: SemanticViewRequest) -> str:
        query = req.query
        bound_views: set[str] = set()
        for m in getattr(query, "measures", []):
            mname = getattr(m, "name", None)
            if not mname:
                continue
            found = self.model.find_measure(mname)
            if found is None:
                continue
            _, measure = found
            if measure.semantic_binding and measure.semantic_binding.semantic_view:
                bound_views.add(measure.semantic_binding.semantic_view)

        if len(bound_views) > 1:
            raise SemanticViewPlanError(
                "query spans multiple semantic views; cross-view joins are not allowed"
            )
        if len(bound_views) == 1:
            return next(iter(bound_views))

        if req.preferred_view:
            return req.preferred_view

        if self.model.semantic_views:
            return self.model.semantic_views[0]
        raise SemanticViewPlanError(
            "no semantic view binding found; set measure semantic bindings or model.semantic_views"
        )

    def _filter_sql(self, filt) -> str:
        col = self._qident(getattr(filt, "column"))
        op = getattr(filt, "op", "in")
        values = getattr(filt, "values", []) or []

        if op in ("in", "not_in"):
            if not values:
                return "1=1" if op == "in" else "1=0"
            items = ", ".join(self._lit(v) for v in values)
            return f"{col} {'NOT IN' if op == 'not_in' else 'IN'} ({items})"

        if op in ("eq", "gte", "lte", "gt", "lt"):
            if not values:
                raise SemanticViewPlanError(f"filter op '{op}' requires at least one value")
            cmp_map = {"eq": "=", "gte": ">=", "lte": "<=", "gt": ">", "lt": "<"}
            return f"{col} {cmp_map[op]} {self._lit(values[0])}"

        raise SemanticViewPlanError(
            f"unsupported filter operator '{op}' for semantic view execution"
        )

    def _metric_ref(self, m) -> tuple[str, list[str]]:
        """SEMANTIC_VIEW METRICS entry for a query measure + its home tables."""
        from app.semantic.yaml_compiler import semantic_metric_plan

        mname = getattr(m, "name", None)
        if mname:
            found = self.model.find_measure(mname)
            if found is None:
                raise SemanticViewPlanError(f"unknown measure '{mname}'")
            _, measure = found
            if measure.semantic_binding and measure.semantic_binding.metric_id:
                return self._qident(measure.semantic_binding.metric_id), []
            from app.dax.compiler import MeasureCompiler

            plan = semantic_metric_plan(self.model, MeasureCompiler(self.model), mname)
            if plan is None:
                raise SemanticViewPlanError(
                    f"measure '{mname}' has no semantic-view metric equivalent"
                )
            if plan.kind == "table":
                return f"{self._qident(plan.home)}.{self._qident(plan.ident)}", [plan.home]
            # derived metrics are view-scoped: referenced unqualified
            return self._qident(plan.ident), [h for h, _, _ in plan.helpers]

        col = getattr(m, "column", None)
        table = getattr(m, "table", None)
        agg = (getattr(m, "aggregate", None) or "SUM").upper()
        if not col or not table:
            raise SemanticViewPlanError(
                "semantic view query has implicit measure with no table/column"
            )
        if agg == "DISTINCTCOUNT":
            return f"COUNT(DISTINCT {self._qident(table)}.{self._qident(col)})", [table]
        if agg not in _SIMPLE_AGG_MAP:
            raise SemanticViewPlanError(
                f"unsupported aggregate '{agg}' in semantic view execution"
            )
        return f"{_SIMPLE_AGG_MAP[agg]}({self._qident(table)}.{self._qident(col)})", [table]

    def _reachable(self, start: str) -> set[str]:
        """Tables reachable from `start` following many→one relationship edges."""
        seen = {start}
        frontier = [start]
        while frontier:
            cur = frontier.pop()
            for r in self.model.relationships:
                if getattr(r, "is_active", True) is False:
                    continue
                if r.from_table == cur and r.to_table not in seen:
                    seen.add(r.to_table)
                    frontier.append(r.to_table)
        return seen

    def build_sql(self, req: SemanticViewRequest) -> SemanticViewPlan:
        query = req.query
        measures = list(getattr(query, "measures", []))
        dimensions = list(getattr(query, "dimensions", []))
        filters = list(getattr(query, "filters", []))
        sorts = list(getattr(query, "sort", []))
        limit = getattr(query, "limit", None)

        if not measures and not dimensions:
            raise SemanticViewPlanError("empty query")

        view_name = self._resolve_view_name(req)
        traces = ["SV_NATIVE"]

        # SEMANTIC_VIEW output columns use the (unqualified) alias names;
        # aliases inside the construct keep the dashboard's spec keys stable.
        outer_cols: list[str] = []
        dim_entries: list[str] = []
        metric_entries: list[str] = []

        for i, d in enumerate(dimensions):
            alias = getattr(d, "key", None) or f"{getattr(d, 'table', 'T')}.{getattr(d, 'column')}"
            local = f"__D{i}"
            dim_entries.append(
                f"{self._qident(getattr(d, 'table'))}.{self._qident(getattr(d, 'column'))}"
                f" AS {self._qident(local)}"
            )
            outer_cols.append(f"{self._qident(local)} AS {self._qident(alias)}")

        metric_homes: set[str] = set()
        for i, m in enumerate(measures):
            alias = getattr(m, "key", None) or getattr(m, "name", None) or "value"
            local = f"__M{i}"
            ref, homes = self._metric_ref(m)
            metric_homes.update(homes)
            metric_entries.append(f"{ref} AS {self._qident(local)}")
            outer_cols.append(f"{self._qident(local)} AS {self._qident(alias)}")

        # Guard obviously disconnected dimensions, but avoid over-restricting
        # mixed-home visuals: a dimension only needs to be reachable from at
        # least one metric home in the query.
        if metric_homes and dimensions:
            reach_by_home = {home: self._reachable(home) for home in metric_homes}
            for d in dimensions:
                dtable = getattr(d, "table")
                covered = any(dtable == home or dtable in reach for home, reach in reach_by_home.items())
                if not covered:
                    home_list = ", ".join(sorted(metric_homes))
                    raise SemanticViewPlanError(
                        f"dimension table '{dtable}' unreachable from metric homes "
                        f"[{home_list}] in semantic view"
                    )

        where_parts = []
        for f in filters:
            table = getattr(f, "table", None)
            pred = self._filter_sql(f)
            if table:
                # qualify inside the construct: dimension refs are table.column
                col = self._qident(getattr(f, "column"))
                pred = pred.replace(col, f"{self._qident(table)}.{col}", 1)
            where_parts.append(pred)

        inner = self._qobj(view_name)
        if metric_entries:
            inner += "\n  METRICS " + ", ".join(metric_entries)
        if dim_entries:
            inner += "\n  DIMENSIONS " + ", ".join(dim_entries)
        if where_parts:
            inner += "\n  WHERE " + " AND ".join(where_parts)

        sql = "SELECT " + ", ".join(outer_cols)
        sql += f"\nFROM SEMANTIC_VIEW({inner}\n)"
        traces.append("SV_VIEW_BOUND")

        if sorts:
            parts = []
            for s in sorts:
                key = s.get("key")
                if not key:
                    continue
                direction = str(s.get("direction", "Ascending")).upper()
                direction = "DESC" if direction.startswith("DESC") else "ASC"
                parts.append(f"{self._qident(str(key))} {direction}")
            if parts:
                sql += "\nORDER BY " + ", ".join(parts)

        if limit is not None:
            sql += f"\nLIMIT {int(limit)}"

        # Annotate execution metadata as SQL comments for troubleshooting.
        if req.model_version:
            sql += f"\n/* model_version={req.model_version} */"
            traces.append("SV_MODEL_VERSION")
        if req.data_version:
            sql += f"\n/* data_version={req.data_version} */"
            traces.append("SV_DATA_VERSION")
        if req.row_scope_id:
            sql += f"\n/* row_scope_id={req.row_scope_id} */"
            traces.append("SV_ROW_SCOPE")
        if req.preferred_view:
            traces.append("SV_PREFERRED_VIEW")

        return SemanticViewPlan(sql=sql, trace_codes=traces)
