import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { accelerationStatus, hydrateExtract } from './api'

export type QueryMode = 'live' | 'accelerated'

export function ModeToggle({
  conversionId,
  connectionId,
  mode,
  onChange,
  dark = false,
}: {
  conversionId: string
  connectionId: string
  mode: QueryMode
  onChange: (m: QueryMode) => void
  dark?: boolean
}) {
  const qc = useQueryClient()
  const status = useQuery({
    queryKey: ['accel-status', conversionId],
    queryFn: () => accelerationStatus(conversionId),
  })
  const hydrate = useMutation({
    mutationFn: () => hydrateExtract(conversionId, connectionId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['accel-status', conversionId] })
      onChange('accelerated')
    },
  })

  const hydrated = status.data?.hydrated ?? false

  return (
    <div
      data-chrome={dark}
      className="flex items-center gap-1 rounded-lg border border-surface-300 bg-white p-0.5 text-[11px] data-[chrome=true]:border-white/10 data-[chrome=true]:bg-white/5"
    >
      <button
        onClick={() => onChange('live')}
        data-active={mode === 'live'}
        data-chrome={dark}
        className="rounded px-2 py-1 font-medium text-surface-600 data-[active=true]:bg-brand data-[active=true]:text-white data-[chrome=true]:text-gray-400 data-[chrome=true]:data-[active=true]:text-white"
        title="Every interaction queries Snowflake directly"
      >
        Live
      </button>
      {hydrated ? (
        <button
          onClick={() => onChange('accelerated')}
          data-active={mode === 'accelerated'}
          data-chrome={dark}
          className="rounded px-2 py-1 font-medium text-surface-600 data-[active=true]:bg-brand-dark data-[active=true]:text-white data-[chrome=true]:text-gray-400 data-[chrome=true]:data-[active=true]:text-white"
          title="Queries served from a local extract hydrated from Snowflake"
        >
          Accelerated
        </button>
      ) : (
        <button
          onClick={() => hydrate.mutate()}
          disabled={hydrate.isPending}
          data-chrome={dark}
          className="rounded px-2 py-1 font-medium text-brand-dark hover:bg-brand/10 disabled:opacity-50 data-[chrome=true]:text-brand"
          title="Copy bound tables into a local DuckDB extract for sub-100ms interactions"
        >
          {hydrate.isPending ? 'Hydrating…' : 'Enable Accelerated'}
        </button>
      )}
    </div>
  )
}
