"""Cell-grain parity comparison helpers for dual-run validation."""

from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass(slots=True)
class ParityDelta:
    row: int
    column: str
    expected: object
    actual: object
    detail: str


def _is_number(v: object) -> bool:
    if v is None:
        return False
    try:
        float(v)
        return True
    except (TypeError, ValueError):
        return False


def _close(a: float, b: float, rel_tol: float) -> bool:
    if b == 0:
        return abs(a) < rel_tol
    return math.isclose(a, b, rel_tol=rel_tol)


def compare_result_grids(
    expected_columns: list[str],
    expected_rows: list[list] | list[tuple],
    actual_columns: list[str],
    actual_rows: list[list] | list[tuple],
    rel_tol: float = 1e-6,
    max_deltas: int = 25,
) -> tuple[bool, str, list[ParityDelta]]:
    """Compare two result grids for exact schema + cell-grain parity.

    Numeric values are compared with relative tolerance; non-numeric values
    require exact equality.
    """
    if expected_columns != actual_columns:
        return (
            False,
            "schema mismatch",
            [
                ParityDelta(
                    row=-1,
                    column="__schema__",
                    expected=expected_columns,
                    actual=actual_columns,
                    detail="column sets differ",
                )
            ],
        )

    if len(expected_rows) != len(actual_rows):
        return (
            False,
            f"row-count mismatch: expected {len(expected_rows)} got {len(actual_rows)}",
            [
                ParityDelta(
                    row=-1,
                    column="__rowcount__",
                    expected=len(expected_rows),
                    actual=len(actual_rows),
                    detail="result row counts differ",
                )
            ],
        )

    deltas: list[ParityDelta] = []
    for r_idx, (exp_row, act_row) in enumerate(zip(expected_rows, actual_rows, strict=True)):
        if len(exp_row) != len(actual_columns) or len(act_row) != len(actual_columns):
            deltas.append(
                ParityDelta(
                    row=r_idx,
                    column="__rowshape__",
                    expected=len(exp_row),
                    actual=len(act_row),
                    detail="row width mismatch",
                )
            )
            if len(deltas) >= max_deltas:
                break
            continue
        for c_idx, col in enumerate(actual_columns):
            exp_v = exp_row[c_idx]
            act_v = act_row[c_idx]
            if _is_number(exp_v) and _is_number(act_v):
                exp_f, act_f = float(exp_v), float(act_v)
                if _close(exp_f, act_f, rel_tol):
                    continue
                deltas.append(
                    ParityDelta(
                        row=r_idx,
                        column=col,
                        expected=exp_v,
                        actual=act_v,
                        detail="numeric mismatch",
                    )
                )
            elif exp_v != act_v:
                deltas.append(
                    ParityDelta(
                        row=r_idx,
                        column=col,
                        expected=exp_v,
                        actual=act_v,
                        detail="value mismatch",
                    )
                )
            if len(deltas) >= max_deltas:
                break
        if len(deltas) >= max_deltas:
            break

    if deltas:
        return False, f"{len(deltas)} cell mismatches", deltas
    return True, "cell-grain parity passed", []
