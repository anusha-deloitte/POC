"""Page information-architecture analyzer.

Decides — with evidence, not assumption — whether the original report's page
structure should be kept, merged or split in the reimagined variant.

Signals (all deterministic, computed from compiled QuerySpecs):
- measure overlap (Jaccard) between page pairs: pages answering the same
  question share measures; pages answering different questions do not.
- conformed dimensions (dims present on nearly every page — the shared slicer
  spine) are EXCLUDED from the overlap signal: they indicate a common filter
  context, not duplicate content.
- merged density: total data visuals a merged page would carry; a merge that
  cannot fit the single-viewport canvas is rejected regardless of overlap.

Verdicts: merge (applied by the build), keep-separate, split-advised
(advisory only — splitting is a navigation change with editorial choices the
user must confirm, so it is surfaced, never auto-applied).
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from app.runtime.dashboard import DashboardSpec, PageSpec

# dims on >= this fraction of pages are the conformed slicer spine
_CONFORMED_PAGE_FRACTION = 0.75
# measure overlap at/above this suggests the pages answer the same question
_MERGE_MEASURE_JACCARD = 0.5
# a merged page must fit the single-viewport mosaic
_MERGE_DENSITY_CAP = 16
# pages beyond this density are candidates for splitting
_SPLIT_DENSITY = 20


class PageProfile(BaseModel):
    name: str
    display_name: str
    data_visuals: int
    measures: list[str] = Field(default_factory=list)
    dims: list[str] = Field(default_factory=list)
    exclusive_dims: list[str] = Field(default_factory=list)


class PagePairEvaluation(BaseModel):
    pages: list[str]
    measure_jaccard: float
    shared_measures: list[str] = Field(default_factory=list)
    exclusive_dim_jaccard: float
    combined_data_visuals: int
    verdict: str  # merge | keep-separate
    reason: str


class PageArchitectureReport(BaseModel):
    profiles: list[PageProfile] = Field(default_factory=list)
    conformed_dims: list[str] = Field(default_factory=list)
    pairs: list[PagePairEvaluation] = Field(default_factory=list)
    merges: list[dict] = Field(default_factory=list)  # {into, absorbed, reason}
    splits: list[dict] = Field(default_factory=list)  # advisory {page, reason}
    pages_before: int = 0
    pages_after: int = 0
    verdict: str = ""


def _page_signature(page: PageSpec) -> tuple[set[str], set[str], int, set[str]]:
    measures: set[str] = set()
    dims: set[str] = set()
    slicer_targets: set[str] = set()
    count = 0
    for vs in page.visuals:
        if vs.slicer_target:
            slicer_targets.add(f"{vs.slicer_target['table']}.{vs.slicer_target['column']}")
        if vs.visual_type in ("slicer", "textbox") or vs.query is None:
            continue
        count += 1
        for m in vs.query.measures:
            measures.add(m.name)
        for d in vs.query.dimensions:
            dims.add(f"{d.table}.{d.column}")
    return measures, dims, count, slicer_targets


def _jaccard(a: set[str], b: set[str]) -> float:
    union = a | b
    return len(a & b) / len(union) if union else 0.0


def analyze_page_architecture(spec: DashboardSpec) -> PageArchitectureReport:
    report = PageArchitectureReport(pages_before=len(spec.pages))
    sigs: dict[str, tuple[set[str], set[str], int, set[str]]] = {}
    for page in spec.pages:
        sigs[page.name] = _page_signature(page)

    n_pages = len(spec.pages)
    # the conformed spine = dims (from charts OR slicer targets) present on
    # nearly every page: the shared filter context, not duplicate content
    dim_page_counts: dict[str, int] = {}
    for _, dims, _, targets in sigs.values():
        for d in dims | targets:
            dim_page_counts[d] = dim_page_counts.get(d, 0) + 1
    conformed = {
        d
        for d, c in dim_page_counts.items()
        if n_pages > 1 and c / n_pages >= _CONFORMED_PAGE_FRACTION
    }
    report.conformed_dims = sorted(conformed)

    for page in spec.pages:
        measures, dims, count, _ = sigs[page.name]
        report.profiles.append(
            PageProfile(
                name=page.name,
                display_name=page.display_name,
                data_visuals=count,
                measures=sorted(measures),
                dims=sorted(dims),
                exclusive_dims=sorted(dims - conformed),
            )
        )
        if count > _SPLIT_DENSITY:
            report.splits.append(
                {
                    "page": page.name,
                    "reason": (
                        f"{count} data visuals exceed the {_SPLIT_DENSITY}-visual "
                        "single-viewport budget; consider splitting by theme "
                        "(advisory — splitting is an editorial decision)"
                    ),
                }
            )

    merged_into: dict[str, str] = {}  # absorbed -> surviving
    merged_load: dict[str, int] = {p.name: sigs[p.name][2] for p in spec.pages}

    pairs: list[tuple[float, PageSpec, PageSpec]] = []
    for i in range(n_pages):
        for j in range(i + 1, n_pages):
            a, b = spec.pages[i], spec.pages[j]
            mj = _jaccard(sigs[a.name][0], sigs[b.name][0])
            pairs.append((mj, a, b))
    pairs.sort(key=lambda t: -t[0])

    for mj, a, b in pairs:
        m_a, d_a, c_a, _ = sigs[a.name]
        m_b, d_b, c_b, _ = sigs[b.name]
        shared = sorted(m_a & m_b)
        ex_dj = _jaccard(d_a - conformed, d_b - conformed)
        combined = merged_load.get(merged_into.get(a.name, a.name), c_a) + c_b

        if a.name in merged_into or b.name in merged_into:
            verdict, reason = "keep-separate", "already part of an applied merge"
        elif mj >= _MERGE_MEASURE_JACCARD and combined <= _MERGE_DENSITY_CAP:
            verdict = "merge"
            reason = (
                f"measure overlap {mj:.0%} ({len(shared)} shared: "
                f"{', '.join(shared[:6])}) — the pages answer the same question; "
                f"merged density {combined} fits the {_MERGE_DENSITY_CAP}-visual "
                "single-viewport budget"
            )
            survivor = merged_into.get(a.name, a.name)
            merged_into[b.name] = survivor
            merged_load[survivor] = combined
            report.merges.append({"into": survivor, "absorbed": b.name, "reason": reason})
        elif mj >= _MERGE_MEASURE_JACCARD:
            verdict = "keep-separate"
            reason = (
                f"measure overlap {mj:.0%} is high but merged density {combined} "
                f"exceeds the {_MERGE_DENSITY_CAP}-visual single-viewport budget — "
                "merging would force scrolling or shrink visuals below legibility"
            )
        else:
            verdict = "keep-separate"
            reason = (
                f"measure overlap {mj:.0%} ({len(shared)} shared"
                + (f": {', '.join(shared[:4])}" if shared else "")
                + f"), exclusive-dim overlap {ex_dj:.0%} — distinct analytical "
                "questions; shared dims are the conformed slicer spine, not "
                "duplicate content"
            )
        report.pairs.append(
            PagePairEvaluation(
                pages=[a.name, b.name],
                measure_jaccard=round(mj, 3),
                shared_measures=shared,
                exclusive_dim_jaccard=round(ex_dj, 3),
                combined_data_visuals=combined,
                verdict=verdict,
                reason=reason,
            )
        )

    report.pages_after = report.pages_before - len(report.merges)
    if report.merges:
        merged_desc = "; ".join(f"{m['absorbed']} → {m['into']}" for m in report.merges)
        report.verdict = (
            f"{report.pages_before} pages → {report.pages_after}: merged {merged_desc} "
            "(same analytical question, fits one viewport)"
        )
    else:
        max_mj = max((p.measure_jaccard for p in report.pairs), default=0.0)
        density_blocked = any(
            p.measure_jaccard >= _MERGE_MEASURE_JACCARD for p in report.pairs
        )
        detail = (
            "high-overlap pairs exist but merging would exceed the "
            "single-viewport density budget"
            if density_blocked
            else (
                f"max pairwise measure overlap {max_mj:.0%} — each page answers "
                "a distinct analytical question; shared dimensions are the "
                "conformed slicer spine, not duplicate content"
            )
        )
        report.verdict = f"all {report.pages_before} pages kept: {detail}"
    if report.splits:
        report.verdict += f" · split advised for {len(report.splits)} page(s)"
    return report
