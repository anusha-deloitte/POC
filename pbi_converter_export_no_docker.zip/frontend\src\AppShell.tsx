import {
  BadgeCheck,
  Briefcase,
  CheckCircle2,
  ChevronsLeft,
  ChevronsRight,
  Database,
  Eye,
  FileUp,
  LogOut,
  Menu,
  ScanSearch,
  Sparkles,
  Workflow,
  X,
} from 'lucide-react'
import { useEffect, useState } from 'react'
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { clearSession, getUser } from './auth'
import { STEP_ORDER, useWizard, type WizardStep } from './store/wizard'

const STEPS: { id: WizardStep; label: string; desc: string; icon: typeof FileUp }[] = [
  { id: 'upload', label: 'Upload', desc: 'Power BI project (.pbip)', icon: FileUp },
  { id: 'connect', label: 'Connect', desc: 'Data warehouse', icon: Database },
  { id: 'analyze', label: 'Analyze', desc: 'Coverage preview', icon: ScanSearch },
  { id: 'convert', label: 'Convert', desc: 'Translate + validate', icon: Workflow },
  { id: 'review', label: 'Review', desc: 'Migration Health', icon: BadgeCheck },
  { id: 'preview', label: 'Preview', desc: 'Live dashboard', icon: Eye },
]

const SIDEBAR_KEY = 'pbic.sidebar_collapsed'

export function AppShell() {
  const step = useWizard((s) => s.step)
  const setStep = useWizard((s) => s.setStep)
  const conversionId = useWizard((s) => s.conversionId)
  const connectionId = useWizard((s) => s.connectionId)
  const reset = useWizard((s) => s.reset)
  const hasUnsavedChanges = useWizard((s) => s.hasUnsavedChanges)
  const confirmDiscardChanges = useWizard((s) => s.confirmDiscardChanges)
  const nav = useNavigate()
  const location = useLocation()
  const user = getUser()
  const inWizard = location.pathname.startsWith('/app/convert')
  const activeIdx = STEP_ORDER.indexOf(step)

  // collapsible sidebar (persisted) + mobile drawer
  const [collapsed, setCollapsed] = useState(() => localStorage.getItem(SIDEBAR_KEY) === '1')
  const [mobileOpen, setMobileOpen] = useState(false)
  useEffect(() => {
    localStorage.setItem(SIDEBAR_KEY, collapsed ? '1' : '0')
  }, [collapsed])
  useEffect(() => {
    setMobileOpen(false)
  }, [location.pathname, step])

  const headerTitle = inWizard
    ? STEPS[activeIdx]?.label
    : location.pathname.includes('jobs')
      ? 'Jobs'
      : 'Workspace'
  const headerKicker = inWizard
    ? STEPS[activeIdx]?.desc
    : location.pathname.includes('jobs')
      ? 'Conversion history'
      : ''

  const runSafeAction = (action: () => void) => {
    if (!confirmDiscardChanges()) return
    action()
  }

  // fluid on preview; wide on data-dense steps; comfortable elsewhere
  const contentWidth =
    inWizard && step === 'preview'
      ? 'max-w-none'
      : inWizard && (step === 'review' || step === 'convert' || step === 'connect')
        ? 'max-w-screen-2xl'
        : 'max-w-7xl'

  const sidebarNav = (
    <nav className="flex-1 space-y-1 overflow-x-hidden overflow-y-auto px-3 py-4">
      {!collapsed && (
        <div className="px-3 pb-2 text-[11px] font-bold tracking-wide text-gray-500 uppercase">
          Workspace
        </div>
      )}
      <NavLink
        to="/app/jobs"
        title="Jobs"
        className={({ isActive }) =>
          `group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
            isActive ? 'bg-brand/20 text-brand' : 'text-gray-400 hover:bg-white/10 hover:text-white'
          } ${collapsed ? 'justify-center px-0' : ''}`
        }
      >
        <Briefcase className="h-[18px] w-[18px] shrink-0" strokeWidth={1.8} />
        {!collapsed && 'Jobs'}
      </NavLink>

      {inWizard ? (
        <>
          {!collapsed ? (
            <div className="px-3 pt-4 pb-2 text-[11px] font-bold tracking-wide text-gray-500 uppercase">
              Active conversion
            </div>
          ) : (
            <div className="mx-3 my-3 border-t border-white/10" />
          )}
          {STEPS.map((s, i) => {
            const state = i < activeIdx ? 'done' : i === activeIdx ? 'active' : 'todo'
            const Icon = s.icon
            const clickable = i <= activeIdx && conversionId !== null
            const lockedReason =
              conversionId === null
                ? 'Start a conversion to unlock pipeline steps.'
                : 'Finish the current step to unlock this stage.'
            return (
              <button
                key={s.id}
                onClick={() => clickable && runSafeAction(() => setStep(s.id))}
                aria-disabled={!clickable}
                title={clickable ? `Open ${s.label}` : lockedReason}
                data-state={state}
                className={`group relative flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium text-gray-400 transition-colors hover:bg-white/10 hover:text-white data-[state=active]:bg-brand/20 data-[state=active]:text-brand data-[state=done]:text-gray-300 ${
                  collapsed ? 'justify-center px-0' : ''
                }`}
              >
                {state === 'active' && (
                  <span className="absolute top-1 bottom-1 left-0 w-[3px] rounded-full bg-gradient-to-b from-brand to-brand-dark" />
                )}
                {state === 'done' ? (
                  <CheckCircle2
                    className="h-[18px] w-[18px] shrink-0 text-brand"
                    strokeWidth={1.8}
                  />
                ) : (
                  <Icon className="h-[18px] w-[18px] shrink-0" strokeWidth={1.8} />
                )}
                {!collapsed && (
                  <span className="min-w-0 flex-1">
                    <span className="block truncate">{s.label}</span>
                    <span className="block truncate text-[10px] font-normal text-gray-500 group-data-[state=active]:text-brand/70">
                      {clickable ? s.desc : `${s.desc} · locked`}
                    </span>
                  </span>
                )}
              </button>
            )
          })}
          {conversionId !== null && (
            <>
              {!collapsed ? (
                <div className="px-3 pt-4 pb-2 text-[11px] font-bold tracking-wide text-gray-500 uppercase">
                  Beyond migration
                </div>
              ) : (
                <div className="mx-3 my-3 border-t border-white/10" />
              )}
              <a
                href={`#/reimagine/${conversionId}/${connectionId ?? ''}`}
                title="Reimagine studio — modern redesign with zero-loss proof"
                className={`group relative flex w-full items-center gap-3 rounded-lg border border-brand/25 bg-gradient-to-r from-brand/10 to-transparent px-3 py-2.5 text-left text-sm font-medium text-gray-300 transition-colors hover:border-brand/60 hover:bg-white/10 hover:text-white ${
                  collapsed ? 'justify-center border-0 bg-transparent px-0' : ''
                }`}
              >
                <Sparkles className="h-[18px] w-[18px] shrink-0 text-brand" strokeWidth={1.8} />
                {!collapsed && (
                  <span className="min-w-0 flex-1">
                    <span className="block truncate">Reimagine studio</span>
                    <span className="block truncate text-[10px] font-normal text-gray-500">
                      Modern redesign · zero-loss proof
                    </span>
                  </span>
                )}
              </a>
            </>
          )}
          {conversionId === null && !collapsed && (
            <div className="mt-2 rounded-lg border border-white/15 bg-white/5 px-3 py-2 text-[11px] text-gray-300">
              Complete upload first to unlock downstream steps.
            </div>
          )}
          {hasUnsavedChanges && !collapsed && (
            <div className="mt-2 rounded-lg border border-brand-amber/25 bg-brand-amber/10 px-3 py-2 text-[11px] text-brand-amber">
              You have unsaved edits in this step.
            </div>
          )}
        </>
      ) : (
        <button
          onClick={() => {
            runSafeAction(() => {
              reset()
              nav('/app/convert')
            })
          }}
          title="New conversion"
          className={`mt-4 flex w-full items-center gap-3 rounded-lg border border-dashed border-white/20 px-3 py-2.5 text-left text-sm font-medium text-gray-400 transition-colors hover:border-brand/60 hover:bg-white/10 hover:text-white ${
            collapsed ? 'justify-center px-0' : ''
          }`}
        >
          <Workflow className="h-[18px] w-[18px] shrink-0" strokeWidth={1.8} />
          {!collapsed && (
            <span className="flex-1">
              <span className="block">New conversion</span>
              <span className="block text-[10px] font-normal text-gray-500">
                Upload a .pbip to start
              </span>
            </span>
          )}
        </button>
      )}
    </nav>
  )

  const sidebarFooter = (
    <div
      className={`flex items-center border-t border-white/10 py-3 ${
        collapsed ? 'justify-center px-0' : 'gap-2 px-4'
      }`}
    >
      <span className="h-1.5 w-1.5 shrink-0 animate-pulse rounded-full bg-brand" />
      {!collapsed && (
        <span className="truncate text-[10px] text-gray-500">
          Live on Snowflake · accuracy-gated
        </span>
      )}
    </div>
  )

  return (
    <div className="flex h-dvh overflow-hidden">
      {/* desktop sidebar: collapsible, persists preference (inline width —
          Tailwind class swap is unreliable mid-transition) */}
      <aside
        data-collapsed={collapsed}
        style={{ width: collapsed ? 60 : 256 }}
        className="hidden flex-shrink-0 flex-col overflow-hidden border-r border-white/[0.08] bg-black transition-[width] duration-200 ease-out md:flex"
      >
        <div
          className={`flex h-16 shrink-0 items-center border-b border-white/10 ${
            collapsed ? 'justify-center px-0' : 'gap-3 px-4'
          }`}
        >
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-brand to-brand-dark text-sm font-extrabold text-white">
            P
          </div>
          {!collapsed && (
            <div className="min-w-0">
              <div className="truncate text-base font-bold text-white">PBI Converter</div>
              <div className="text-gradient truncate text-[11px] font-semibold">
                Power BI → React · Verified
              </div>
            </div>
          )}
        </div>
        {sidebarNav}
        <button
          onClick={() => setCollapsed((c) => !c)}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          className="flex items-center justify-center border-t border-white/10 py-2 text-gray-500 transition-colors hover:bg-white/5 hover:text-white"
        >
          {collapsed ? (
            <ChevronsRight className="h-4 w-4" strokeWidth={1.8} />
          ) : (
            <ChevronsLeft className="h-4 w-4" strokeWidth={1.8} />
          )}
        </button>
        {sidebarFooter}
      </aside>

      {/* mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden" role="dialog" aria-modal="true">
          <button
            aria-label="Close menu"
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setMobileOpen(false)}
          />
          <aside className="absolute inset-y-0 left-0 flex w-72 max-w-[85vw] flex-col border-r border-white/[0.08] bg-black shadow-2xl">
            <div className="flex h-16 shrink-0 items-center justify-between border-b border-white/10 px-4">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand to-brand-dark text-sm font-extrabold text-white">
                  P
                </div>
                <div className="text-base font-bold text-white">PBI Converter</div>
              </div>
              <button
                onClick={() => setMobileOpen(false)}
                aria-label="Close menu"
                className="flex h-8 w-8 items-center justify-center rounded-lg text-gray-400 hover:bg-white/10 hover:text-white"
              >
                <X className="h-4 w-4" strokeWidth={1.8} />
              </button>
            </div>
            {sidebarNav}
            {sidebarFooter}
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
        <header className="flex h-16 flex-shrink-0 items-center justify-between gap-3 border-b border-white/[0.08] bg-black px-4 sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <button
              onClick={() => setMobileOpen(true)}
              aria-label="Open menu"
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-gray-400 hover:bg-white/10 hover:text-white md:hidden"
            >
              <Menu className="h-5 w-5" strokeWidth={1.8} />
            </button>
            <div className="min-w-0">
              <div className="truncate text-[10px] font-semibold tracking-[0.12em] text-brand uppercase">
                {headerKicker}
              </div>
              <h1 className="truncate text-sm font-semibold text-white">{headerTitle}</h1>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-3">
            {user && (
              <span className="hidden items-center gap-2 rounded-2xl bg-gradient-to-br from-brand/10 to-brand-dark/10 px-3 py-1.5 text-xs text-gray-300 sm:flex">
                <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-gradient-to-br from-brand to-brand-dark text-[10px] font-bold text-white">
                  {user.name.slice(0, 1).toUpperCase()}
                </span>
                {user.name}
              </span>
            )}
            <button
              onClick={() => {
                runSafeAction(() => {
                  clearSession()
                  nav('/login')
                })
              }}
              title="Sign out"
              className="flex h-8 w-8 items-center justify-center rounded-lg text-gray-400 hover:bg-white/10 hover:text-white"
            >
              <LogOut className="h-4 w-4" strokeWidth={1.8} />
            </button>
          </div>
        </header>

        <main className="min-w-0 flex-1 overflow-x-hidden overflow-y-auto bg-surface-200">
          <div className={`mx-auto w-full px-4 py-6 sm:px-6 lg:px-8 lg:py-8 ${contentWidth}`}>
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  )
}
