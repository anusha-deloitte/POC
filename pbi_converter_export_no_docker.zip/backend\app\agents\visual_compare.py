"""Visual parity agent: GPT-4o vision compares a Power BI page screenshot
against the converted React render and reports structured differences.

This complements the numeric harness: numbers can reconcile while the visual
is still wrong (lost Series split, wrong chart type, missing conditional
formatting, layout drift). The model receives both images side by side plus
the compiled spec inventory so it can name visuals precisely.

Findings are persisted per page under the conversion directory so the
Conversion Report and the Review UI share one source of truth.
"""

from __future__ import annotations

import base64
import json
import re
from dataclasses import dataclass, field

_SEVERITIES = ("high", "medium", "low")
_KINDS = (
    "chart-type",
    "series",
    "layout",
    "color",
    "formatting",
    "data-shape",
    "missing",
    "extra",
    "interaction",
    "text",
    "filter-state",
)

_SYSTEM = """You are a meticulous BI migration reviewer. Image 1 is the ORIGINAL
Power BI report page. Image 2 is the CONVERTED React dashboard render of the
same page. Compare them visual by visual.

Report every meaningful difference a business user would notice:
- chart-type: different visual family (e.g. clustered columns became a single series)
- series: legend/series split lost or changed, stacking differences
- data-shape: different number of categories/bars/points, different ordering
- color: palette or conditional-formatting differences
- formatting: number formats, axis labels, data labels, titles
- layout: position/size drift, overlapping or missing chrome
- missing / extra: visuals absent from one side
- text: changed captions or values in cards/KPIs

Ignore: font rendering differences, minor anti-aliasing, scroll bars,
watermarks, and sub-5-pixel offsets.

Weigh CONTENT over chrome: compare chart titles, KPI captions and their
displayed values, axis/legend entries and category names explicitly.

Title check (mandatory, do this FIRST for every visual): read the title text
of each visual in Image 1 and find the visual at the same position in Image 2.
If the title text differs in ANY way (renamed, reworded, missing), report a
"text" finding quoting BOTH titles and propose a set_title fix.

FIX DIRECTION (critical): fixes are applied to the CONVERTED dashboard
(Image 2) to make it match the ORIGINAL (Image 1). Every fix value must
therefore be taken from Image 1 — e.g. set_title value = the title as it
appears in the ORIGINAL, never the converted one. The same rule applies to
formats, sorts and chart types: Image 1 is always the target state.

Filter awareness: FIRST read the slicer/filter widgets on both images. If the
two pages clearly have DIFFERENT active filter selections (e.g. Year=2024 vs
Year=All), do NOT report the resulting data differences finding-by-finding.
Instead emit ONE high-severity finding with kind "filter-state" naming both
selections, and score similarity on structure only (visual types, titles,
layout), ignoring the value drift the filter causes.

Similarity rubric (be strict):
- 95-100: same visuals, same content, only cosmetic differences
- 80-94: same visuals with minor content/formatting drift (a label, a format)
- 60-79: one or more visuals materially wrong (lost series, wrong chart type)
- 30-59: several visuals wrong or missing
- 0-29: different titles/KPIs/visuals — this is NOT the same report page;
  in that case report ONE high-severity 'missing' finding saying the pages
  do not correspond instead of listing per-visual position noise.
Never report position/layout findings when the two images show different
report pages; position findings are only meaningful between matching pages.

For each finding, ALSO propose a machine-executable fix when (and only when)
the difference can be corrected by one of these spec operations on the
CONVERTED dashboard:
- set_title {"visual", "value"} — wrong/missing title text
- set_visual_type {"visual", "value"} — wrong chart family (bar/column/line/
  area/donut/pie/waterfall variants only)
- set_measure_format {"visual", "measure", "value"} — wrong number format
  (value = a Power BI format string such as "0.0%" or "$#,0")
- set_sort {"visual", "key", "direction"} — wrong category/series ordering
  (direction = Ascending|Descending)
- set_limit {"visual", "value"} — too many categories shown
- move_resize {"visual", "x", "y", "width", "height"} — layout drift (px)
- swap_series_role {"visual", "column"} — series/legend split on wrong column
- drop_measure {"visual", "measure"} — extra column/series not in the original
  (use for extra TABLE COLUMNS too: dropping the measure removes the column)
- drop_dimension {"visual", "column"} — extra grouping not in the original
- hide_visual {"visual"} — visual not present in the original
- set_option {"visual", "key", "value"} — renderer toggles (boolean):
  key="waterfall_total" value=false — removes the extra 'Total' bar from a
  waterfall chart; key="show_legend"/"show_labels" — legend/data-label toggles
Use the visual NAME from the inventory (in parentheses), not the title.
If no operation can fix it (data differences, filter-state, colors, missing
visuals that need building), set "fix": null.

Output ONLY JSON:
{"similarity": 0-100, "findings": [{"region": "<visual title or location>",
"severity": "high|medium|low", "kind": "<one of the categories above>",
"difference": "<what differs, one sentence>",
"recommendation": "<concrete fix, one sentence>",
"fix": {"op": "<operation>", "visual": "<visual name>"} | null}]}
The fix object carries the op's params inline (value/measure/key/etc.).
An empty findings list with high similarity means the pages match."""


@dataclass
class CompareResult:
    similarity: int
    findings: list[dict]
    raw: str = ""
    error: str | None = None
    trace: list[str] = field(default_factory=list)


def _extract_json(text: str) -> dict | None:
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        return None


def _validate(payload: dict) -> tuple[int, list[dict]] | None:
    sim = payload.get("similarity")
    findings = payload.get("findings")
    if not isinstance(sim, (int, float)) or not isinstance(findings, list):
        return None
    clean: list[dict] = []
    for f in findings:
        if not isinstance(f, dict) or "difference" not in f:
            continue
        sev = str(f.get("severity", "medium")).lower()
        kind = str(f.get("kind", "layout")).lower()
        fix = f.get("fix")
        if not isinstance(fix, dict) or not fix.get("op") or not fix.get("visual"):
            fix = None
        clean.append(
            {
                "region": str(f.get("region", "page"))[:120],
                "severity": sev if sev in _SEVERITIES else "medium",
                "kind": kind if kind in _KINDS else "layout",
                "difference": str(f["difference"])[:500],
                "recommendation": str(f.get("recommendation", ""))[:500],
                "fix": fix,
            }
        )
    return max(0, min(100, int(sim))), clean


def _image_part(png_bytes: bytes) -> dict:
    b64 = base64.b64encode(png_bytes).decode()
    return {
        "type": "image_url",
        "image_url": {"url": f"data:image/png;base64,{b64}", "detail": "high"},
    }


_SLICER_SYSTEM = """You read Power BI report screenshots. You get ONE image and
the list of slicers that exist on this page with their possible values.
For each slicer, read its CURRENTLY SELECTED value from the image (dropdown
caption text, highlighted list item, or chip). If a slicer shows no selection,
'All', '(All)' or is blank, treat it as unfiltered and OMIT it.

Output ONLY JSON: {"selections": [{"slicer": "<slicer title>",
"value": "<selected value exactly as shown>"}]}
An empty selections list means no filters are active."""


@dataclass
class SlicerStateResult:
    selections: list[dict]  # [{slicer, value}]
    raw: str = ""
    error: str | None = None


def detect_slicer_state(
    reference_png: bytes,
    slicers: list[dict],
    client=None,
) -> SlicerStateResult:
    """Read active slicer selections off the reference screenshot.

    `slicers` = [{"title", "options": [...]}] from the compiled spec + domain
    queries; options let the model snap to canonical values.
    """
    if client is None:
        client = _default_client()
        if isinstance(client, str):
            return SlicerStateResult([], error=client)

    lines = []
    for s in slicers:
        opts = ", ".join(str(o) for o in s.get("options", [])[:40])
        lines.append(f"- {s['title']}" + (f" (possible values: {opts})" if opts else ""))
    messages = [
        {"role": "system", "content": _SLICER_SYSTEM},
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "Slicers on this page:\n" + "\n".join(lines)},
                _image_part(reference_png),
            ],
        },
    ]
    for _attempt in (1, 2):
        resp = client.chat.completions.create(model="gpt-4o", temperature=0, messages=messages)
        text = resp.choices[0].message.content or ""
        payload = _extract_json(text)
        if payload is not None and isinstance(payload.get("selections"), list):
            clean = [
                {"slicer": str(s["slicer"])[:80], "value": str(s["value"])[:120]}
                for s in payload["selections"]
                if isinstance(s, dict) and "slicer" in s and "value" in s
            ]
            return SlicerStateResult(clean, raw=text)
        messages.append({"role": "assistant", "content": text})
        messages.append({"role": "user", "content": "Respond with only the JSON object."})
    return SlicerStateResult([], error="slicer detection returned unparseable output")


def _default_client():
    try:
        from openai import OpenAI

        from app.core.config import get_settings

        key = get_settings().openai_api_key
        if not key:
            return "no OPENAI key configured"
        return OpenAI(api_key=key)
    except ModuleNotFoundError:
        return "openai package not installed"


def compare_page_images(
    reference_png: bytes,
    rendered_png: bytes,
    visual_inventory: list[dict],
    client=None,
    filter_context: str | None = None,
) -> CompareResult:
    """One vision round-trip; retry once on unparseable output."""
    trace: list[str] = []
    if client is None:
        client = _default_client()
        if isinstance(client, str):
            return CompareResult(0, [], error=client)

    def _inv_line(v: dict) -> str:
        line = f"- {v['title'] or v['name']} (name: {v['name']}, type: {v['visual_type']})"
        if v.get("dim_keys"):
            line += f" dims: {', '.join(v['dim_keys'])}"
        if v.get("measure_keys"):
            line += f" measures: {', '.join(v['measure_keys'])}"
        return line

    inventory = "\n".join(_inv_line(v) for v in visual_inventory)
    context_text = "Visuals expected on this page:\n" + inventory + "\n\n"
    if filter_context:
        context_text += filter_context + "\n\n"
    context_text += "Image 1 = original Power BI. Image 2 = converted React."
    messages = [
        {"role": "system", "content": _SYSTEM},
        {
            "role": "user",
            "content": [
                {"type": "text", "text": context_text},
                _image_part(reference_png),
                _image_part(rendered_png),
            ],
        },
    ]

    for attempt in (1, 2):
        resp = client.chat.completions.create(model="gpt-4o", temperature=0, messages=messages)
        text = resp.choices[0].message.content or ""
        payload = _extract_json(text)
        validated = _validate(payload) if payload else None
        if validated is not None:
            sim, findings = validated
            trace.append(f"attempt {attempt}: {len(findings)} findings, similarity {sim}")
            return CompareResult(sim, findings, raw=text, trace=trace)
        trace.append(f"attempt {attempt}: unparseable response")
        messages.append({"role": "assistant", "content": text})
        messages.append({"role": "user", "content": "Respond with only the JSON object."})

    return CompareResult(0, [], error="vision model returned unparseable output", trace=trace)
