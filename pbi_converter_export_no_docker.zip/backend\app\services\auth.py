"""Lightweight user store + JWT session for the Studio.

Users persist as bcrypt-hashed records in a JSON file under storage; the
first account registered becomes admin. HS256 JWT, 7-day TTL.
"""

from __future__ import annotations

import json
import secrets
import time
import uuid
from pathlib import Path

import bcrypt
import jwt

_TTL_SECONDS = 7 * 24 * 3600


class AuthError(Exception):
    pass


class UserStore:
    def __init__(self, storage_dir: Path):
        self.file = storage_dir / "users.json"
        self.file.parent.mkdir(parents=True, exist_ok=True)
        key_file = storage_dir / ".jwt.key"
        if not key_file.exists():
            key_file.write_text(secrets.token_hex(32))
            key_file.chmod(0o600)
        self._secret = key_file.read_text().strip()

    def _load(self) -> dict:
        if not self.file.is_file():
            return {}
        return json.loads(self.file.read_text(encoding="utf-8"))

    def _save(self, users: dict) -> None:
        self.file.write_text(json.dumps(users, indent=2), encoding="utf-8")

    def signup(self, email: str, password: str, name: str = "") -> dict:
        email = email.strip().lower()
        if not email or "@" not in email:
            raise AuthError("valid email required")
        if len(password) < 8:
            raise AuthError("password must be at least 8 characters")
        users = self._load()
        if email in users:
            raise AuthError("account already exists")
        users[email] = {
            "id": str(uuid.uuid4()),
            "email": email,
            "name": name.strip() or email.split("@")[0],
            "hash": bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode(),
            "is_admin": len(users) == 0,  # first user is admin
            "created_at": time.time(),
        }
        self._save(users)
        return self.login(email, password)

    def login(self, email: str, password: str) -> dict:
        users = self._load()
        record = users.get(email.strip().lower())
        if record is None or not bcrypt.checkpw(password.encode(), record["hash"].encode()):
            raise AuthError("invalid email or password")
        token = jwt.encode(
            {
                "sub": record["id"],
                "email": record["email"],
                "name": record["name"],
                "adm": record["is_admin"],
                "exp": int(time.time()) + _TTL_SECONDS,
            },
            self._secret,
            algorithm="HS256",
        )
        return {
            "token": token,
            "user": {k: record[k] for k in ("id", "email", "name", "is_admin")},
        }

    def verify(self, token: str) -> dict:
        try:
            payload = jwt.decode(token, self._secret, algorithms=["HS256"])
        except jwt.PyJWTError as e:
            raise AuthError("invalid or expired token") from e
        return {
            "id": payload["sub"],
            "email": payload["email"],
            "name": payload.get("name", ""),
            "is_admin": payload.get("adm", False),
        }
