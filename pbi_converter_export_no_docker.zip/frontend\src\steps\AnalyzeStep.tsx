import { useQuery } from '@tanstack/react-query'
import { ArrowRight, GitFork, Layers, Sigma, Table2 } from 'lucide-react'
import { api } from '../api/client'
import { useWizard } from '../store/wizard'

export function AnalyzeStep() {
  const conversionId = useWizard((s) => s.conversionId)
  const setStep = useWizard((s) => s.setStep)
  const summary = useQuery({
    queryKey: ['conversion', conversionId],
    queryFn: () => api.getConversion(conversionId!),
    enabled: !!conversionId,
  })

  if (!conversionId) return <p className="text-surface-500">No conversion selected.</p>
  if (summary.isLoading) return <p className="text-surface-500">Analyzing…</p>
  if (summary.isError)
    return (
      <div role="alert" className="rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
        {summary.error.message}
      </div>
    )

  const s = summary.data!
  const stats = [
    { label: 'Tables', value: s.model.tables, icon: Table2 },
    { label: 'Relationships', value: s.model.relationships, icon: GitFork },
    { label: 'Measures', value: s.model.measures, icon: Sigma },
    { label: 'Pages', value: s.pages.length, icon: Layers },
  ]

  return (
    <section>
      <div className="mb-6 overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div className="kicker mb-1">Step 3 · Coverage preview</div>
        <h2 className="text-xl font-bold">{s.report}</h2>
        <p className="mt-1 text-sm text-surface-600">
          What the engine found in your report. Conversion and validation run next.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map(({ label, value, icon: Icon }) => (
          <div key={label} className="card text-center">
            <Icon className="mx-auto mb-2 h-5 w-5 text-brand-dark" strokeWidth={1.8} />
            <div className="text-3xl font-bold">{value}</div>
            <div className="text-[11px] font-semibold tracking-wider text-surface-500 uppercase">
              {label}
            </div>
          </div>
        ))}
      </div>

      {s.source_database?.needs_migration && (
        <div
          data-testid="analyze-migration-plan"
          className="mt-6 rounded-xl border border-brand-blue/20 bg-brand-blue/5 p-4 text-sm text-surface-700"
        >
          <strong className="text-brand-blue">Source migration planned</strong>
          <p className="mt-1 text-xs text-surface-600">
            This report reads {s.source_database.kind === 'sqlserver' ? 'SQL Server' : s.source_database.kind}
            {s.source_database.tables[0]?.database ? ` (${s.source_database.tables[0].database})` : ''}.
            During conversion the {s.source_database.tables.length} base tables below are migrated
            into Snowflake — schema, data, and row-count verification — then every query is
            validated against the migrated copy.
          </p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {s.source_database.tables.map((t) => (
              <span key={t.table} className="badge bg-white text-surface-600">
                {t.schema}.{t.object}
              </span>
            ))}
          </div>
        </div>
      )}

      <h3 className="mt-8 mb-3 text-sm font-bold text-surface-900">Visuals by type</h3>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {Object.entries(s.visual_types).map(([type, count]) => (
          <div
            key={type}
            className="flex items-center justify-between rounded-lg border border-black/[0.06] bg-surface-50 px-3 py-2 text-sm"
          >
            <span className="truncate text-surface-700">{type}</span>
            <span className="badge-green ml-2">{count}</span>
          </div>
        ))}
      </div>

      {s.warnings.length > 0 && (
        <div className="mt-6 rounded-xl border border-brand-amber/20 bg-brand-amber/5 p-4 text-sm text-surface-700">
          <strong className="text-brand-amber">Warning: partial readiness</strong>
          <p className="mt-1 text-xs text-surface-600">
            Conversion can continue, but these findings may affect Migration Health and can require remediation in Review.
          </p>
          <ul className="mt-1 ml-4 list-disc">
            {s.warnings.map((w) => (
              <li key={w}>{w}</li>
            ))}
          </ul>
        </div>
      )}

      <button onClick={() => setStep('convert')} className="btn-primary mt-8 inline-flex items-center gap-2">
        Convert &amp; validate
        <ArrowRight className="h-4 w-4" strokeWidth={2} />
      </button>
    </section>
  )
}
