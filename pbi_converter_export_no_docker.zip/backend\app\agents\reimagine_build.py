"""Reimagine build compiler.

Transforms the compiled (faithful) DashboardSpec into a modern "reimagined"
variant plus a per-visual mapping manifest. The core invariant: every
reimagined visual carries a byte-identical QuerySpec — only layout, visual
type and styling change, so information parity is mechanically provable by
the zero-loss gate rather than argued.

Rules:
- Reflow, never remove: every visual maps 1:1 (v1: no merges).
- Slicers survive as a top filter bar; textbox headers become the page header.
- Layout: story-ordered 12-col responsive grid (KPI band -> hero -> pairs ->
  full-width tables) written into x/y/width/height so PageCanvas renders it
  without modification.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from app.runtime.dashboard import DashboardSpec, PageSpec, VisualSpec

# 12-col grid geometry (px) — single-viewport command-center canvas:
# everything fits 1440x~810 with zero scroll (16:9 like PBI, denser)
_GRID_COLS = 12
_COL_W = 120  # 12*120 = 1440
_ROW_H = 8
_GUTTER = 4
_PAGE_W = 1440.0
_BODY_ROWS = 88  # ~704px of chart body under header+filter


class MappingEntry(BaseModel):
    original: dict
    reimagined: dict
    change_kind: str  # restyle | re-encode | relocate | dedupe
    rationale: str
    information_delta: dict = Field(
        default_factory=lambda: {"missing": [], "relocated": [], "added": []}
    )


class VisualMappingManifest(BaseModel):
    conversion_id: str
    pages: list[str] = Field(default_factory=list)
    entries: list[MappingEntry] = Field(default_factory=list)
    # original page -> variant page (identity unless the architecture
    # analysis merged pages)
    page_map: dict[str, str] = Field(default_factory=dict)
    # evidence for the keep/merge/split decision (PageArchitectureReport dump)
    architecture: dict = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# re-encoding decisions — BI-expert redesign rules, not restyles.
# Perceptual grounding: position > length > angle > color for comparisons
# (Cleveland/McGill); gauges and >5-slice donuts are known anti-patterns
# (Few). Every rule keeps the QuerySpec byte-identical; presentation-only
# transforms (client sort, stacking, reference lines) live in options.
# ---------------------------------------------------------------------------

_TIME_HINT = ("MONTH", "DATE", "YEAR", "QUARTER", "WEEK", "DAY")


def _is_time_dim(key: str) -> bool:
    return any(h in key.upper() for h in _TIME_HINT)


def _snapshot_rows(snapshot: dict | None, page: str, visual: str) -> int:
    for r in (snapshot or {}).get("results", []):
        if r.get("page") == page and r.get("visual") == visual:
            return len(r.get("rows") or [])
    return 0


def _distinct_categories(snapshot: dict | None, page: str, visual: str, dim_key: str) -> int:
    for r in (snapshot or {}).get("results", []):
        if r.get("page") == page and r.get("visual") == visual:
            cols = r.get("columns") or []
            if dim_key in cols:
                i = cols.index(dim_key)
                return len({row[i] for row in (r.get("rows") or [])})
    return 0


def _is_percent_measure(vs: VisualSpec, key: str) -> bool:
    return "%" in (vs.measure_formats.get(key) or "")


def _reencode(
    vs: VisualSpec, rows: int, categories: int
) -> tuple[str, str, list[str], dict]:
    """(new_type, rationale, added_elements, options_patch) for one visual."""
    t = vs.visual_type
    time_series = any(_is_time_dim(k) for k in vs.dim_keys)
    has_series = bool(vs.series_keys)
    n_cats = categories or rows

    if t == "card":
        return (
            "card",
            "Executive KPI tile: oversized value, accent bar and semantic delta "
            "chip for at-a-glance scanning",
            ["accent bar", "delta chip"],
            {"kpi_tile": True},
        )

    if t == "gauge":
        return (
            "bulletChart",
            "Gauge replaced by a bullet chart: linear position beats angular "
            "sweep for value-vs-target reading, in a quarter of the space (Few)",
            ["target marker", "qualitative bands"],
            {},
        )

    if t in ("pivotTable",) and vs.column_keys and len(vs.measure_keys) == 1:
        return (
            "heatmapMatrix",
            "Numeric matrix re-encoded as a heatmap: pre-attentive color "
            "reveals hot spots and seasonality that a wall of numbers hides",
            ["color scale", "value-on-hover"],
            {},
        )

    if t in ("donutChart", "pieChart"):
        if n_cats > 5:
            return (
                "barChart",
                f"{n_cats}-slice donut re-encoded as a sorted bar ranking: "
                "angle comparison degrades past ~5 slices; aligned bars restore "
                "instant magnitude reading",
                ["value labels", "rank order"],
                {"client_sort": "value_desc", "show_labels": True},
            )
        return (
            "donutChart",
            "Donut kept (≤5 categories) with centered total and share callouts",
            ["center total"],
            {"center_total": True},
        )

    if t in ("columnChart", "clusteredColumnChart") and time_series and rows > 12:
        return (
            "areaChart",
            f"{rows} time points re-encoded as a gradient area trend: "
            "continuous line reads trajectory; columns at this density read as noise",
            ["gradient fill"],
            {},
        )

    if t in ("barChart", "clusteredBarChart", "columnChart", "clusteredColumnChart"):
        if has_series:
            return (
                t,
                "Clustered series re-encoded as stacked composition: "
                "part-to-whole and total trajectory in one read instead of "
                "interleaved bars",
                ["stacked composition"],
                {"stacked": True},
            )
        return (
            t,
            "Ranked bars with value labels: aligned position encoding, "
            "sorted by magnitude for instant ranking",
            ["value labels", "rank order"],
            {"client_sort": "value_desc" if not time_series else None, "show_labels": True},
        )

    if t in ("lineChart", "areaChart"):
        return (
            t,
            "Trend elevated to hero: gradient fill, focus points and a "
            "target band where a target measure exists",
            ["gradient fill", "target band"],
            {},
        )

    if t == "scatterChart":
        return (
            "scatterChart",
            "Scatter upgraded to quadrant analysis: mean reference lines "
            "split the field into four actionable segments",
            ["quadrant lines", "quadrant labels"],
            {"quadrant": True},
        )

    if t in ("pivotTable", "tableEx"):
        return (
            t,
            "Data grid with in-cell data bars: magnitude becomes visible "
            "without reading every number; all columns and totals preserved",
            ["data bars"],
            {"data_bars": True},
        )

    if t == "waterfallChart":
        return (
            t,
            "Waterfall kept — the canonical bridge for driver decomposition — "
            "with connector lines and semantic increase/decrease colors",
            ["connector styling"],
            {},
        )

    if t == "lineClusteredColumnComboChart":
        return (
            t,
            "Combo kept for the dual-scale pairing; bars muted so the line "
            "carries the primary signal",
            ["muted bars"],
            {},
        )

    if t == "filledMap":
        return (
            t,
            "Choropleth kept with a continuous diverging color ramp and "
            "hover detail",
            ["diverging ramp"],
            {},
        )

    if t == "decompositionTreeVisual":
        return (
            t,
            "Drill tree kept: root-cause navigation is the right idiom here",
            [],
            {},
        )

    return (t, "Restyled with the reimagined theme; encoding unchanged", [], {})


# ---------------------------------------------------------------------------
# layout
# ---------------------------------------------------------------------------


def _grid_rect(col: int, row: int, w_cols: int, h_rows: int) -> dict:
    return {
        "x": float(col * _COL_W + _GUTTER),
        "y": float(row * _ROW_H + _GUTTER),
        "width": float(w_cols * _COL_W - 2 * _GUTTER),
        "height": float(h_rows * _ROW_H - 2 * _GUTTER),
    }


def _story_rank(vs: VisualSpec) -> int:
    t = vs.visual_type
    if t == "card":
        return 0
    if t in ("lineChart", "areaChart", "lineClusteredColumnComboChart", "waterfallChart"):
        return 1
    if t in (
        "barChart",
        "clusteredBarChart",
        "columnChart",
        "clusteredColumnChart",
        "donutChart",
        "pieChart",
        "scatterChart",
        "gauge",
        "filledMap",
        "decompositionTreeVisual",
    ):
        return 2
    if t in ("pivotTable", "tableEx"):
        return 3
    return 2


def _layout_page(page: PageSpec, placements: dict[str, dict]) -> float:
    """Single-viewport command-center layout: header + filter rail up top, then
    a KPI rail and a dense mosaic of chart bands whose heights are computed
    from the remaining budget — the page NEVER exceeds one 16:9 viewport, so
    the whole report is visible without scrolling (PBI's own constraint)."""
    slicers = [v for v in page.visuals if v.visual_type == "slicer"]
    textboxes = [v for v in page.visuals if v.visual_type == "textbox"]
    data_visuals = [
        v
        for v in page.visuals
        if v.visual_type not in ("slicer", "textbox") and v.supported
    ]
    parked = [
        v for v in page.visuals if v.visual_type not in ("slicer", "textbox") and not v.supported
    ]

    row = 0
    # compact chrome: title strip + slicers share ONE row when both exist
    h_chrome = 6
    if textboxes or slicers:
        title_cols = 4 if slicers else _GRID_COLS
        col = 0
        if textboxes:
            placements[textboxes[0].name] = _grid_rect(0, row, title_cols, h_chrome)
            col = title_cols
            # secondary textboxes tuck into the chrome row's right edge
            for tb in textboxes[1:]:
                placements[tb.name] = _grid_rect(col, row, 2, h_chrome)
                col += 2
        if slicers:
            avail = _GRID_COLS - col
            per = max(avail // len(slicers), 1)
            for i, s in enumerate(slicers):
                # last slicer absorbs the remainder; never exceed the grid
                width = per if i < len(slicers) - 1 else _GRID_COLS - col
                if width <= 0:
                    # more slicers than columns: wrap to a fresh chrome row
                    row += h_chrome
                    col = 0
                    width = per
                placements[s.name] = _grid_rect(col, row, width, h_chrome)
                col += width
        row += h_chrome

    ordered = sorted(data_visuals, key=lambda v: (_story_rank(v), v.y, v.x))
    kpis = [v for v in ordered if _story_rank(v) == 0]
    charts = [v for v in ordered if _story_rank(v) in (1, 2)]
    tables = [v for v in ordered if _story_rank(v) == 3]
    charts += parked  # parked visuals still get a mosaic slot (reflow, never remove)

    # KPI rail: single row, all cards side by side (they are tiles, not charts)
    h_kpi = 11
    if kpis:
        w = max(_GRID_COLS // len(kpis), 1)
        col = 0
        for i, v in enumerate(kpis):
            width = w if i < len(kpis) - 1 else _GRID_COLS - col
            placements[v.name] = _grid_rect(col, row, width, h_kpi)
            col += w
        row += h_kpi

    # remaining budget is divided across chart/table bands so the page always
    # lands exactly on the viewport height
    budget = _BODY_ROWS - row
    # band plan: hero band (first chart, 7 cols) shares its row with the next
    # 1-2 charts stacked right; remaining charts tile 2-3 per band; tables get
    # a wide band at the bottom paired with leftover charts
    n_charts = len(charts)
    n_tables = len(tables)
    bands: list[list[tuple[VisualSpec, int]]] = []  # [(visual, col_span)]
    i = 0
    if n_charts:
        first = charts[0]
        sidekicks = charts[1:3]
        if sidekicks:
            bands.append([(first, 7)] + [(s, 5) for s in sidekicks])
        else:
            bands.append([(first, _GRID_COLS)])
        i = 1 + len(sidekicks)
    while i < n_charts:
        group = charts[i : i + 3]
        span = _GRID_COLS // len(group)
        bands.append([(v, span) for v in group])
        i += len(group)
    if n_tables:
        span = _GRID_COLS // n_tables
        bands.append([(v, span) for v in tables])

    if bands:
        h_band = max(budget // len(bands), 18)
        # hero band gets the extra remainder for visual hierarchy
        extra = max(budget - h_band * len(bands), 0)
        for bi, band in enumerate(bands):
            h = h_band + (extra if bi == 0 else 0)
            col = 0
            # side-stacked band: hero left tall, sidekicks split the right column
            if bi == 0 and len(band) == 3 and band[0][1] == 7:
                hero, s1, s2 = band[0][0], band[1][0], band[2][0]
                placements[hero.name] = _grid_rect(0, row, 7, h)
                half = h // 2
                placements[s1.name] = _grid_rect(7, row, 5, half)
                placements[s2.name] = _grid_rect(7, row + half, 5, h - half)
            else:
                for j, (v, span) in enumerate(band):
                    width = span if j < len(band) - 1 else _GRID_COLS - col
                    placements[v.name] = _grid_rect(col, row, width, h)
                    col += span
            row += h

    return float(max(row, _BODY_ROWS) * _ROW_H + 2 * _GUTTER)


# ---------------------------------------------------------------------------
# compiler
# ---------------------------------------------------------------------------


def _region(v: VisualSpec, page: PageSpec) -> str:
    horiz = "left" if v.x < page.width / 3 else "right" if v.x > 2 * page.width / 3 else "center"
    vert = "top" if v.y < page.height / 3 else "bottom" if v.y > 2 * page.height / 3 else "mid"
    return f"{vert}-{horiz}"


def _synthesize_interaction_graph(variant: DashboardSpec) -> None:
    """Dense cross-filter mesh: clicking any category in any chart filters every
    other data visual on the page — the PBI cross-filter experience turned on
    everywhere by default (PBI itself often leaves edges at 'highlight')."""
    from app.ir.report import InteractionEdge, InteractionGraph

    graph = InteractionGraph()
    seen: set[str] = set()
    for page in variant.pages:
        interactive = [
            v
            for v in page.visuals
            if v.supported and v.query is not None and v.visual_type != "textbox"
        ]
        for v in interactive:
            if v.name not in seen:
                seen.add(v.name)
                graph.nodes.append(v.name)
        sources = [v for v in interactive if v.visual_type != "slicer" and v.dim_keys]
        for src in sources:
            for dst in interactive:
                if dst.name == src.name or dst.visual_type == "slicer":
                    continue
                graph.edges.append(
                    InteractionEdge(from_visual=src.name, to_visual=dst.name, mode="filter")
                )
    variant.interaction_graph = graph


def _apply_page_merges(
    variant: DashboardSpec,
    page_map: dict[str, str],
    manifest: VisualMappingManifest,
) -> None:
    """Fold absorbed pages into their survivors. Duplicate slicers (same
    slicer target already on the survivor's filter rail) are deduped and
    recorded as `dedupe` mapping entries so the gate can verify the surviving
    twin carries an identical query."""
    survivors: dict[str, PageSpec] = {
        p.name: p for p in variant.pages if page_map.get(p.name, p.name) == p.name
    }
    for page in variant.pages:
        target = page_map.get(page.name, page.name)
        if target == page.name:
            continue
        sv = survivors[target]
        rail = {
            (v.slicer_target["table"], v.slicer_target["column"]): v
            for v in sv.visuals
            if v.slicer_target
        }
        for vs in page.visuals:
            key = (
                (vs.slicer_target["table"], vs.slicer_target["column"])
                if vs.slicer_target
                else None
            )
            if key and key in rail:
                twin = rail[key]
                manifest.entries.append(
                    MappingEntry(
                        original={
                            "page": page.name,
                            "visual": vs.name,
                            "type": vs.visual_type,
                            "title": vs.title,
                            "dims": list(vs.dim_keys),
                            "measures": list(vs.measure_keys),
                            "slicer_target": vs.slicer_target,
                            "region": "top",
                        },
                        reimagined={
                            "visual": twin.name,
                            "type": twin.visual_type,
                            "title": twin.title,
                            "dims": list(twin.dim_keys),
                            "measures": list(twin.measure_keys),
                            "region": "top",
                        },
                        change_kind="dedupe",
                        rationale=(
                            "duplicate slicer absorbed by the merged page's "
                            "shared filter rail — same target, identical query"
                        ),
                    )
                )
                continue
            sv.visuals.append(vs)
        sv.display_name = f"{sv.display_name} · {page.display_name}"
    variant.pages = [p for p in variant.pages if page_map.get(p.name, p.name) == p.name]


def build_reimagined(
    spec: DashboardSpec,
    conversion_id: str,
    snapshot: dict | None = None,
) -> tuple[DashboardSpec, VisualMappingManifest]:
    """Compile the faithful spec into the reimagined variant + mapping manifest."""
    from app.agents.page_architecture import analyze_page_architecture

    variant = spec.model_copy(deep=True)
    manifest = VisualMappingManifest(conversion_id=conversion_id)

    # information-architecture decision first: keep / merge / split-advised,
    # each with evidence — pages are never restructured on assumption
    arch = analyze_page_architecture(spec)
    manifest.architecture = arch.model_dump()
    page_map = {p.name: p.name for p in spec.pages}
    for m in arch.merges:
        page_map[m["absorbed"]] = m["into"]
    manifest.page_map = page_map
    if arch.merges:
        _apply_page_merges(variant, page_map, manifest)

    # modern theme derived from the report theme (colors kept; chrome elevated)
    variant.theme.card_background = "#FFFFFF"
    variant.theme.panel_background = "#F7F9FC"
    variant.theme.panel_border = "#E4EAF2"

    orig_by_name = {v.name: (p, v) for p in spec.pages for v in p.visuals}

    for page in variant.pages:
        manifest.pages.append(page.name)
        placements: dict[str, dict] = {}
        page_h = _layout_page(page, placements)
        page.width = _PAGE_W
        page.height = max(page_h, 320.0)

        for vs in page.visuals:
            orig_page, orig = orig_by_name[vs.name]
            rect = placements.get(vs.name)
            if rect:
                vs.x, vs.y = rect["x"], rect["y"]
                vs.width, vs.height = rect["width"], rect["height"]
            vs.z = 0
            vs.options["style_variant"] = "reimagined"

            if vs.visual_type in ("slicer", "textbox"):
                continue

            rows = _snapshot_rows(snapshot, page.name, vs.name)
            cats = (
                _distinct_categories(snapshot, page.name, vs.name, vs.dim_keys[0])
                if vs.dim_keys
                else 0
            )
            new_type, rationale, added, opts = _reencode(vs, rows, cats)
            change_kind = "re-encode" if new_type != vs.visual_type else "restyle"
            vs.visual_type = new_type
            for k, val in opts.items():
                if val is not None:
                    vs.options[k] = val

            relocated = []
            new_region = _region(vs, page)
            old_region = _region(orig, orig_page)
            if new_region != old_region:
                relocated.append(f"moved from {old_region} to {new_region}")
                if change_kind == "restyle":
                    change_kind = "relocate"

            manifest.entries.append(
                MappingEntry(
                    original={
                        "page": orig_page.name,
                        "visual": orig.name,
                        "type": orig.visual_type,
                        "title": orig.title,
                        "dims": list(orig.dim_keys),
                        "measures": list(orig.measure_keys),
                        "slicer_target": orig.slicer_target,
                        "region": old_region,
                    },
                    reimagined={
                        "visual": vs.name,
                        "type": vs.visual_type,
                        "title": vs.title,
                        "dims": list(vs.dim_keys),
                        "measures": list(vs.measure_keys),
                        "region": new_region,
                    },
                    change_kind=change_kind,
                    rationale=rationale,
                    information_delta={
                        "missing": [],
                        "relocated": relocated,
                        "added": added,
                    },
                )
            )

    _synthesize_interaction_graph(variant)
    return variant, manifest
