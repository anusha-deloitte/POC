"""Golden-value validation: compare SQL query results against exported PBI values.

Power BI's Performance Analyzer exports a JSON file containing actual query
results. This module parses that export and provides a harness check that
compares our generated SQL output cell-by-cell against the golden values.

Performance Analyzer export format (simplified):
  {
    "events": [
      {
        "name": "<visual_name>",
        "daxQuery": "EVALUATE ...",
        "data": {
          "table": {
            "columns": ["[col1]", "[col2]"],
            "rows": [[val1, val2], ...]
          }
        }
      }, ...
    ]
  }
"""

from __future__ import annotations

import json
import math
from pathlib import Path

from pydantic import BaseModel, Field

from app.validation.harness import Check, CheckStatus

REL_TOL = 1e-4  # 0.01% tolerance for floating-point measures


class GoldenRow(BaseModel):
    columns: list[str]
    values: list[list]


class GoldenEntry(BaseModel):
    visual_name: str
    dax_query: str | None = None
    rows: list[list] = Field(default_factory=list)
    columns: list[str] = Field(default_factory=list)


class GoldenSet(BaseModel):
    entries: list[GoldenEntry] = Field(default_factory=list)
    source_file: str = ""

    def find(self, visual_name: str) -> GoldenEntry | None:
        # Exact match first, then case-insensitive
        for e in self.entries:
            if e.visual_name == visual_name:
                return e
        for e in self.entries:
            if e.visual_name.lower() == visual_name.lower():
                return e
        return None


def load_golden(path: Path) -> GoldenSet:
    """Parse a Performance Analyzer export JSON into a GoldenSet."""
    data = json.loads(path.read_text(encoding="utf-8"))
    entries: list[GoldenEntry] = []

    # Handle both old and new PA export formats
    events = data.get("events") or data.get("results") or []
    if isinstance(data, list):
        events = data

    for evt in events:
        name = (
            evt.get("name")
            or evt.get("visualName")
            or evt.get("visual", {}).get("name", "unknown")
        )
        dax = evt.get("daxQuery") or evt.get("query")
        table_data = evt.get("data", {}).get("table") or evt.get("table") or {}
        cols = table_data.get("columns") or []
        rows = table_data.get("rows") or []
        entries.append(GoldenEntry(
            visual_name=str(name),
            dax_query=dax,
            columns=cols,
            rows=rows,
        ))

    return GoldenSet(entries=entries, source_file=str(path))


class GoldenMismatch(BaseModel):
    row: int
    column: str
    expected: str | None
    actual: str | None
    detail: str


class GoldenCompareResult(BaseModel):
    visual: str
    status: CheckStatus
    detail: str
    mismatches: list[GoldenMismatch] = Field(default_factory=list)
    rows_expected: int = 0
    rows_actual: int = 0


def _close(a, b) -> bool:
    """Numeric fuzzy comparison."""
    try:
        fa, fb = float(a), float(b)
        if fb == 0:
            return abs(fa) < 1e-9
        return math.isclose(fa, fb, rel_tol=REL_TOL)
    except (TypeError, ValueError):
        return str(a).strip().lower() == str(b).strip().lower()


def compare_against_golden(
    visual_name: str,
    actual_rows: list[tuple],
    actual_cols: list[str],
    golden: GoldenEntry,
) -> Check:
    """Run a golden-compare check and return a Check object for the harness."""
    if not golden.rows:
        return Check(name="golden_compare", status=CheckStatus.SKIPPED, detail="golden has no rows")

    expected_rows = golden.rows
    exp_count = len(expected_rows)
    act_count = len(actual_rows)

    if exp_count != act_count:
        return Check(
            name="golden_compare",
            status=CheckStatus.FAILED,
            detail=f"row count mismatch: expected {exp_count}, got {act_count}",
        )

    mismatches: list[str] = []
    for row_i, (exp_row, act_row) in enumerate(zip(expected_rows, actual_rows)):
        # align columns by position (golden columns may have DAX-style names)
        for col_i in range(min(len(exp_row), len(act_row))):
            ev = exp_row[col_i]
            av = act_row[col_i]
            if ev is None and av is None:
                continue
            if not _close(ev, av):
                col_name = actual_cols[col_i] if col_i < len(actual_cols) else str(col_i)
                mismatches.append(f"row {row_i} col {col_name!r}: expected {ev!r}, got {av!r}")
                if len(mismatches) >= 5:
                    mismatches.append("... (more mismatches suppressed)")
                    break
        if len(mismatches) >= 6:
            break

    if mismatches:
        return Check(
            name="golden_compare",
            status=CheckStatus.FAILED,
            detail="; ".join(mismatches),
        )
    return Check(
        name="golden_compare",
        status=CheckStatus.PASSED,
        detail=f"{exp_count} rows matched",
    )
