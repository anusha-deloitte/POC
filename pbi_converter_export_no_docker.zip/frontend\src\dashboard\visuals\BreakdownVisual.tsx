import { hierarchy, scaleOrdinal, treemap, type HierarchyNode, type HierarchyRectangularNode } from 'd3'
import { useMemo, useState } from 'react'
import { formatValue } from '../format'
import { usePalette, useThemeTokens } from '../theme'
import type { VisualResult, VisualSpec } from '../types'

type TreeNode = {
  name: string
  value?: number
  children?: TreeNode[]
}

function buildTree(spec: VisualSpec, data: VisualResult): TreeNode | null {
  const mKey = spec.measure_keys[0]
  const mi = data.columns.indexOf(mKey)
  const d0 = data.columns.indexOf(spec.dim_keys[0])
  const d1 = spec.dim_keys.length > 1 ? data.columns.indexOf(spec.dim_keys[1]) : -1
  if (mi < 0 || d0 < 0) return null

  const level1 = new Map<string, { value: number; children: Map<string, number> }>()
  for (const row of data.rows) {
    const top = String(row[d0] ?? '—')
    const value = Number(row[mi] ?? 0)
    const group = level1.get(top) ?? { value: 0, children: new Map() }
    group.value += value
    if (d1 >= 0) {
      const child = String(row[d1] ?? '—')
      group.children.set(child, (group.children.get(child) ?? 0) + value)
    }
    level1.set(top, group)
  }

  return {
    name: spec.title ?? spec.name,
    children: [...level1.entries()].map(([name, node]) => ({
      name,
      value: node.value,
      children: node.children.size
        ? [...node.children.entries()].map(([child, childValue]) => ({ name: child, value: childValue }))
        : undefined,
    })),
  }
}

/** Nearest equivalent for decompositionTreeVisual: a drillable D3 treemap. */
export function BreakdownVisual({
  spec,
  data,
  onSelect,
}: {
  spec: VisualSpec
  data?: VisualResult
  onSelect?: (values: (string | number)[]) => void
}) {
  const palette = usePalette()
  const theme = useThemeTokens()
  const [hovered, setHovered] = useState<{ name: string; value: number; x: number; y: number } | null>(null)

  const fmt = spec.measure_formats[spec.measure_keys[0]]
  const layout = useMemo(() => {
    if (!data || data.error) return null
    const tree = buildTree(spec, data)
    if (!tree) return null

    const root = hierarchy<TreeNode>(tree)
      .sum((node: TreeNode) => node.value ?? 0)
      .sort((a: HierarchyNode<TreeNode>, b: HierarchyNode<TreeNode>) => (b.value ?? 0) - (a.value ?? 0))

    treemap<TreeNode>().size([spec.width || 320, spec.height || 240]).paddingInner(2).round(true)(root)
    return root
  }, [data, spec])

  if (!data) return <div className="p-2 text-xs text-surface-400">…</div>
  if (data.error) return <div className="p-2 text-xs text-brand-red">{data.error}</div>
  if (!layout) return <div className="p-2 text-xs text-surface-400">No breakdown data.</div>

  const color = scaleOrdinal<string, string>(palette)
  const leaves = layout.descendants().filter(
    (node): node is HierarchyRectangularNode<TreeNode> => node.depth > 0,
  )

  return (
    <div className="relative h-full w-full overflow-hidden">
      <svg width="100%" height="100%" viewBox={`0 0 ${spec.width || 320} ${spec.height || 240}`}>
        {leaves.map((node) => {
          const x0 = node.x0 ?? 0
          const y0 = node.y0 ?? 0
          const w = Math.max((node.x1 ?? 0) - x0, 0)
          const h = Math.max((node.y1 ?? 0) - y0, 0)
          const fill = color(node.parent?.data.name ?? node.data.name)
          const value = Number(node.value ?? 0)
          const isLeaf = !node.children?.length
          const label = node.data.name
          return (
            <g key={`${node.depth}-${label}-${x0}-${y0}`}>
              <rect
                x={x0}
                y={y0}
                width={w}
                height={h}
                rx={6}
                fill={fill}
                fillOpacity={node.depth === 1 ? 0.9 : 0.75}
                stroke={theme.panelBorder}
                strokeWidth={1}
                onMouseMove={(event) =>
                  setHovered({ name: label, value, x: event.clientX, y: event.clientY })
                }
                onMouseLeave={() => setHovered(null)}
                onClick={() => onSelect?.([label])}
                style={{ cursor: 'pointer' }}
              />
              {w > 42 && h > 24 && (
                <text x={x0 + 8} y={y0 + 18} fill="#fff" fontSize="10" fontWeight="600">
                  <tspan x={x0 + 8} dy="0">{label}</tspan>
                  <tspan x={x0 + 8} dy="12" fillOpacity="0.9" fontWeight="500">
                    {formatValue(value, fmt)}
                  </tspan>
                </text>
              )}
              {isLeaf && w > 42 && h > 40 && (
                <text x={x0 + 8} y={y0 + h - 8} fill="#fff" fontSize="9" fillOpacity="0.9">
                  leaf
                </text>
              )}
            </g>
          )
        })}
      </svg>
      {hovered && (
        <div
          className="pointer-events-none fixed z-50 rounded-md border px-2 py-1 text-[11px] shadow-lg"
          style={{
            left: hovered.x + 12,
            top: hovered.y + 12,
            background: theme.tooltipBackground,
            color: theme.tooltipText,
            borderColor: theme.panelBorder,
            fontFamily: theme.fontFamily,
          }}
        >
          <div className="font-semibold">{hovered.name}</div>
          <div>{formatValue(hovered.value, fmt)}</div>
        </div>
      )}
    </div>
  )
}