import io
import json
import zipfile
from pathlib import Path

import pytest

from app.parsers.bundle import load_pbip
from app.runtime.dashboard import compile_dashboard
from app.services.export import build_export_zip

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


@pytest.fixture(scope="module")
def export_zip() -> zipfile.ZipFile:
    bundle = load_pbip(FIXTURE)
    spec, _ = compile_dashboard(bundle)
    payload = build_export_zip(spec, "conv-123", "conn-456")
    return zipfile.ZipFile(io.BytesIO(payload))


ROOT = "medicalcostcommandcenter-dashboard"


class TestExportZip:
    def test_project_scaffold_present(self, export_zip):
        names = set(export_zip.namelist())
        for f in ("package.json", "vite.config.ts", "tsconfig.json", "index.html", "README.md"):
            assert f"{ROOT}/{f}" in names

    def test_renderer_vendored(self, export_zip):
        names = set(export_zip.namelist())
        for f in (
            "src/dashboard/PageCanvas.tsx",
            "src/dashboard/format.ts",
            "src/dashboard/visuals/ChartVisual.tsx",
            "src/dashboard/visuals/MapVisual.tsx",
            "src/dashboard/visuals/GaugeVisual.tsx",
            "src/dashboard/visuals/BreakdownVisual.tsx",
        ):
            assert f"{ROOT}/{f}" in names

    def test_spec_baked_in(self, export_zip):
        spec = json.loads(export_zip.read(f"{ROOT}/src/spec.json"))
        assert spec["report_name"] == "MedicalCostCommandCenter"
        assert len(spec["pages"]) == 4

    def test_main_wired_with_ids(self, export_zip):
        main = export_zip.read(f"{ROOT}/src/main.tsx").decode()
        assert 'conversionId="conv-123"' in main
        assert 'connectionId="conn-456"' in main

    def test_map_asset_included(self, export_zip):
        geo = json.loads(export_zip.read(f"{ROOT}/public/us-states.geo.json"))
        assert geo["type"] == "FeatureCollection"

    def test_package_json_licenses_clean(self, export_zip):
        pkg = json.loads(export_zip.read(f"{ROOT}/package.json"))
        assert pkg["license"] == "MIT"
        assert "echarts" in pkg["dependencies"]
        assert "react" in pkg["dependencies"]
