import { describe, expect, it } from 'vitest'
import { formatValue, formatWithDisplayUnits } from '../dashboard/format'

describe('formatValue (PBI format strings)', () => {
  it('scaled currency millions: \\$#,0.0,,"M"', () => {
    expect(formatValue(18169372196.08, '\\$#,0.0,,"M"')).toBe('$18,169.4M')
  })

  it('plain thousands separator #,0', () => {
    expect(formatValue(9000000, '#,0')).toBe('9,000,000')
  })

  it('percent 0.0%', () => {
    expect(formatValue(0.123, '0.0%')).toBe('12.3%')
  })

  it('currency two decimals \\$#,0.00', () => {
    expect(formatValue(1906.14573892, '\\$#,0.00')).toBe('$1,906.15')
  })

  it('three decimals 0.000', () => {
    expect(formatValue(1.23456, '0.000')).toBe('1.235')
  })

  it('null renders empty', () => {
    expect(formatValue(null, '#,0')).toBe('')
  })

  it('string numerics from Snowflake are coerced', () => {
    expect(formatValue('15078186948.40', '\\$#,0.0,,"M"')).toBe('$15,078.2M')
  })

  it('no format falls back sensibly', () => {
    expect(formatValue(42)).toBe('42')
    expect(formatValue(42.567)).toBe('42.57')
  })

  it('negative section ignored (positive value)', () => {
    expect(formatValue(100, '\\$#,0.00;(\\$#,0.00);\\$#,0.00')).toBe('$100.00')
  })

  it('unquoted trailing suffix with scaling commas: $#,0,,bnM', () => {
    // vision-fix format: scale to millions with a literal bnM suffix
    expect(formatValue(18169372196.08, '$#,0,,bnM')).toBe('$18,169bnM')
  })

  it('unquoted single-letter suffix: 0M', () => {
    expect(formatValue(9000000, '0,,M')).toBe('9M')
  })

  it('scaling commas before decimals: $#,0,,.0M', () => {
    expect(formatValue(18169372196.08, '$#,0,,.0M')).toBe('$18,169.4M')
  })

  it('K-scaled currency: $#,0,K', () => {
    expect(formatValue(2018.82, '$#,0,K')).toBe('$2K')
  })
})

describe('formatWithDisplayUnits (PBI labelDisplayUnits)', () => {
  it('Auto (0) scales billions to bn', () => {
    expect(formatWithDisplayUnits(18169372196.08, '\\$#,0.0,,"M"', 0)).toBe('$18.2bn')
  })

  it('Auto (0) scales thousands to K', () => {
    expect(formatWithDisplayUnits(2018.82, '\\$#,0.00', 0)).toBe('$2.02K')
  })

  it('Auto (0) scales millions to M (no declared decimals)', () => {
    expect(formatWithDisplayUnits(9000000, '#,0', 0)).toBe('9.00M')
  })

  it('None (1) falls back to the format string', () => {
    expect(formatWithDisplayUnits(9000000, '#,0', 1)).toBe('9,000,000')
  })

  it('fixed millions (1e6)', () => {
    expect(formatWithDisplayUnits(18169372196.08, '\\$#,0.0,,"M"', 1000000)).toBe('$18,169.4M')
  })

  it('percent formats ignore display units', () => {
    expect(formatWithDisplayUnits(0.123, '0.0%', 0)).toBe('12.3%')
  })

  it('undefined units falls back to the format string', () => {
    expect(formatWithDisplayUnits(9000000, '#,0', undefined)).toBe('9,000,000')
  })
})

describe('negative and zero format sections (VB/PBI semantics)', () => {
  it('renders parentheses negatives from the second section', () => {
    expect(formatValue(-4.98, '\\$#,0.00;(\\$#,0.00);\\$0.00')).toBe('($4.98)')
  })

  it('positive values use the first section', () => {
    expect(formatValue(4.98, '\\$#,0.00;(\\$#,0.00);\\$0.00')).toBe('$4.98')
  })

  it('zero values use the third section', () => {
    expect(formatValue(0, '\\$#,0.00;(\\$#,0.00);\\$0.00')).toBe('$0.00')
  })

  it('single-section formats keep the minus sign', () => {
    expect(formatValue(-4.98, '\\$#,0.00')).toBe('$-4.98')
  })

  it('display units keep the negative parentheses', () => {
    expect(formatWithDisplayUnits(-7145300000, '\\$#,0;(\\$#,0)', 1000000, 0)).toBe('($7,145M)')
  })

  it('labelPrecision overrides format decimals without units', () => {
    expect(formatWithDisplayUnits(8.184e6, '#,0', 0, 1)).toBe('8.2M')
  })
})

describe('minus-prefixed negative sections', () => {
  it('renders -0.0% style negatives', () => {
    expect(formatValue(-0.00087, '0.0%;-0.0%;0.0%')).toBe('-0.1%')
  })

  it('positive stays unsigned', () => {
    expect(formatValue(0.0062, '0.0%;-0.0%;0.0%')).toBe('0.6%')
  })
})
