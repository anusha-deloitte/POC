/** Minimal Power BI format-string interpreter for the tier-1 surface.
 *
 * Handles the patterns in real reports: `\$#,0.0,,"M"` (scaled currency),
 * `#,0`, `0.0%`, `0.000`, `\$#,0.00`. Scaling commas after the digits divide
 * by 1000 each; a trailing quoted literal is appended.
 */

export function formatValue(raw: string | number | null, fmt?: string): string {
  if (raw === null || raw === undefined) return ''
  const num = typeof raw === 'number' ? raw : Number(raw)
  if (Number.isNaN(num)) return String(raw)
  if (!fmt) return defaultFormat(num)

  // VB format sections: positive;negative;zero — pick by sign, wrap in the
  // section's own literal decoration (e.g. parentheses for negatives)
  const sections = fmt.split(';')
  let section = sections[0]
  let value0 = num
  if (num < 0 && sections.length >= 2 && sections[1]) {
    section = sections[1]
    value0 = Math.abs(num) // sign is expressed by the section's decoration
  } else if (num === 0 && sections.length >= 3 && sections[2]) {
    section = sections[2]
  }
  const wrapParens = section.includes('(') && section.includes(')')
  // a negative section expresses the sign as literal decoration: () or leading -
  const minusPrefix = !wrapParens && num < 0 && section !== sections[0] && /^\s*-/.test(section)
  const body = formatSection(value0, section)
  if (wrapParens) return `(${body})`
  return minusPrefix ? `-${body}` : body
}

function formatSection(num: number, section: string): string {
  const isPercent = section.includes('%')
  // strip section decoration (parens/sign are re-applied by the caller)
  const cleaned = section.replace(/[()]/g, '').replace(/^\s*-/, '')
  // literal suffix: quoted ("M") or a trailing unquoted run of letters (bnM, K)
  let suffix = ''
  let core = cleaned
  const quoted = core.match(/"([^"]*)"\s*$/)
  const bare = quoted ? null : core.match(/([A-Za-z]+)\s*$/)
  if (quoted) {
    suffix = quoted[1]
    core = core.slice(0, quoted.index)
  } else if (bare && bare.index! > 0) {
    suffix = bare[1]
    core = core.slice(0, bare.index)
  }
  // scaling commas: a , run at the end of the numeric part or right before
  // the decimal point — each comma divides by 1000 (PBI/VB semantics)
  const scaleMatch = core.match(/(,+)\s*$/) ?? core.match(/(,+)\./)
  const scale = scaleMatch ? Math.pow(1000, scaleMatch[1].length) : 1
  const currency = /\\\$|^\$|[^"]\$/.test(cleaned) ? '$' : ''
  // decimals: digits after the last `.` in the numeric part
  const decMatch = core.match(/\.([0#]+)/)
  const decimals = decMatch ? decMatch[1].length : 0
  const grouped = core.includes('#,') || core.includes(',0')

  let value = num
  if (isPercent) value *= 100
  value /= scale

  const formatted = value.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
    useGrouping: grouped,
  })
  return `${currency}${formatted}${suffix}${isPercent ? '%' : ''}`
}

function defaultFormat(num: number): string {
  if (Number.isInteger(num)) return num.toLocaleString('en-US')
  return num.toLocaleString('en-US', { maximumFractionDigits: 2 })
}

/** PBI labelDisplayUnits: 0 = Auto (scale by magnitude), 1 = None,
 * 1e3/1e6/1e9/1e12 = fixed K/M/bn/T. Overrides the format string's own
 * scaling for card/axis display, keeping currency, percent and
 * negative-section hints. `precision` (labelPrecision) overrides decimals. */
export function formatWithDisplayUnits(
  raw: string | number | null,
  fmt: string | undefined,
  displayUnits: number | undefined,
  precision?: number,
): string {
  if (displayUnits === undefined || displayUnits === 1) {
    if (precision === undefined) return formatValue(raw, fmt)
    return formatWithPrecision(raw, fmt, precision)
  }
  if (raw === null || raw === undefined) return ''
  const num = typeof raw === 'number' ? raw : Number(raw)
  if (Number.isNaN(num)) return String(raw)
  const sections = (fmt ?? '').split(';')
  const section = sections[0]
  if (section.includes('%')) return formatValue(raw, fmt) // percent: units don't apply

  const negSection = num < 0 && sections.length >= 2 ? sections[1] : null
  const wrapParens = !!negSection && negSection.includes('(') && negSection.includes(')')
  const magnitude = Math.abs(num)
  const currency = /\\\$|^\$|[^"]\$/.test(section) ? '$' : ''
  let scale = displayUnits
  if (displayUnits === 0) {
    scale =
      magnitude >= 1e12 ? 1e12 : magnitude >= 1e9 ? 1e9 : magnitude >= 1e6 ? 1e6 : magnitude >= 1e3 ? 1e3 : 1
  }
  const suffix = { 1e3: 'K', 1e6: 'M', 1e9: 'bn', 1e12: 'T' }[scale as 1e3 | 1e6 | 1e9 | 1e12] ?? ''
  const value = (wrapParens ? magnitude : num) / scale
  // decimals: explicit labelPrecision > format-string precision > magnitude default
  const decMatch = section.match(/\.([0#]+)/)
  const decimals =
    precision !== undefined
      ? precision
      : decMatch
        ? decMatch[1].length
        : scale === 1
          ? 0
          : Math.abs(value) < 100
            ? 2
            : 1
  const body = `${currency}${value.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })}${suffix}`
  return wrapParens ? `(${body})` : body
}

function formatWithPrecision(
  raw: string | number | null,
  fmt: string | undefined,
  precision: number,
): string {
  if (raw === null || raw === undefined) return ''
  const num = typeof raw === 'number' ? raw : Number(raw)
  if (Number.isNaN(num)) return String(raw)
  const sections = (fmt ?? '').split(';')
  let section = sections[0]
  let value = num
  if (num < 0 && sections.length >= 2 && sections[1]) {
    section = sections[1]
    value = Math.abs(num)
  }
  const wrapParens = section.includes('(') && section.includes(')')
  const isPercent = section.includes('%')
  const currency = /\\\$|^\$|[^"]\$/.test(section) ? '$' : ''
  if (isPercent) value *= 100
  const body = `${currency}${value.toLocaleString('en-US', {
    minimumFractionDigits: precision,
    maximumFractionDigits: precision,
  })}${isPercent ? '%' : ''}`
  return wrapParens ? `(${body})` : body
}
