from pathlib import Path

import pytest

from app.ir.model import DataType, PartitionMode, SummarizeBy
from app.parsers.tmdl import TmdlParseError, parse_tmdl_folder, parse_tmdl_source


@pytest.fixture(scope="module")
def model(contoso_model_def: Path):
    return parse_tmdl_folder(contoso_model_def)


class TestContosoFixture:
    def test_tables_parsed(self, model):
        assert {t.name for t in model.tables} == {"Sales", "Product", "Customer", "Date"}

    def test_model_metadata(self, model):
        assert model.name == "Model"
        assert model.culture == "en-US"

    def test_sales_measures(self, model):
        sales = model.table("Sales")
        names = {m.name for m in sales.measures}
        assert names == {
            "Total Sales",
            "Total Quantity",
            "Average Price",
            "Order Count",
            "Sales YTD",
            "Sales LY",
        }
        total = sales.measure("Total Sales")
        assert total.expression == "SUM('Sales'[SalesAmount])"
        assert total.format_string.startswith("\\$#,0.00")

    def test_multiline_measure_expression(self, model):
        ytd = model.table("Sales").measure("Sales YTD")
        assert ytd.expression == "TOTALYTD([Total Sales], 'Date'[DateKey])"
        assert ytd.description == "Year-to-date sales using the conformed Date dimension."

    def test_column_details(self, model):
        col = model.table("Sales").column("SalesAmount")
        assert col.data_type == DataType.DOUBLE
        assert col.source_column == "SALES_AMOUNT"
        assert col.summarize_by == SummarizeBy.SUM
        assert col.is_hidden is True
        assert not col.is_calculated

    def test_quoted_column_name(self, model):
        col = model.table("Product").column("Product Name")
        assert col is not None
        assert col.source_column == "PRODUCT_NAME"

    def test_sort_by_column(self, model):
        col = model.table("Date").column("Month Name")
        assert col.sort_by_column == "MonthNo"

    def test_key_column(self, model):
        assert model.table("Product").column("ProductKey").is_key is True

    def test_hierarchy(self, model):
        h = model.table("Product").hierarchies[0]
        assert h.name == "Product Hierarchy"
        assert [level.column for level in h.levels] == ["Category", "Subcategory", "Product Name"]

    def test_partition_m_expression(self, model):
        part = model.table("Sales").partitions[0]
        assert part.mode == PartitionMode.IMPORT
        assert part.source_type == "m"
        assert 'Snowflake.Databases("acme-xy12345.snowflakecomputing.com"' in part.expression
        assert 'Schema{[Name="FACT_SALES"]}' in part.expression

    def test_relationships(self, model):
        assert len(model.relationships) == 4
        r = next(x for x in model.relationships if x.to_table == "Product")
        assert (r.from_table, r.from_column) == ("Sales", "ProductKey")
        assert r.is_active is True
        inactive = next(x for x in model.relationships if not x.is_active)
        assert inactive.cross_filtering_behavior == "bothDirections"

    def test_shared_expressions(self, model):
        assert "SnowflakeServer" in model.expressions
        assert "acme-xy12345.snowflakecomputing.com" in model.expressions["SnowflakeServer"]

    def test_table_description(self, model):
        assert model.table("Sales").description == "Fact table with one row per order line."

    def test_ir_roundtrips_through_json(self, model):
        """IR must serialize/deserialize losslessly - it is the pipeline contract."""
        from app.ir.model import SemanticModel

        restored = SemanticModel.model_validate_json(model.model_dump_json())
        assert restored == model


class TestTmdlEdgeCases:
    def test_escaped_quote_in_name(self):
        nodes = parse_tmdl_source("table 'It''s Sales'\n\tisHidden\n")
        assert nodes[0].name == "It's Sales"
        assert "isHidden" in nodes[0].bool_props

    def test_boolean_shortcut_and_explicit(self):
        src = "table T\n\n\tcolumn A\n\t\tisHidden\n\t\tdataType: string\n"
        nodes = parse_tmdl_source(src)
        col = nodes[0].children[0]
        assert "isHidden" in col.bool_props
        assert col.properties["dataType"] == "string"

    def test_fenced_expression(self):
        src = (
            "table T\n\n\tmeasure M1 = ```\n"
            "\t\t\tvar x = TODAY()\n"
            "\t\t\treturn x\n"
            "\t\t\t```\n"
            "\t\tformatString: 0\n"
        )
        nodes = parse_tmdl_source(src)
        m = nodes[0].children[0]
        assert "var x = TODAY()" in m.default_value
        assert m.properties["formatString"] == "0"

    def test_auto_date_table_flag(self):
        nodes = parse_tmdl_source("table LocalDateTable_abc123\n\tisHidden\n")
        from app.parsers.tmdl import _map_table

        assert _map_table(nodes[0]).is_auto_date_table is True

    def test_role_with_table_permission(self):
        src = (
            "role 'EU Only'\n"
            "\tmodelPermission: read\n\n"
            "\ttablePermission Customer = 'Customer'[Country] = \"Germany\"\n"
        )
        nodes = parse_tmdl_source(src)
        from app.parsers.tmdl import _map_role

        role = _map_role(nodes[0])
        assert role.table_permissions["Customer"] == "'Customer'[Country] = \"Germany\""

    def test_unknown_wellformed_declaration_tolerated(self):
        # preview formats drift: unknown identifiers parse generically
        nodes = parse_tmdl_source("futureThing Xyz\n\tsomeProp: 1\n")
        assert nodes[0].kind == "futureThing"
        assert nodes[0].properties["someProp"] == "1"

    def test_malformed_declaration_raises(self):
        with pytest.raises(TmdlParseError, match="unknown declaration"):
            parse_tmdl_source("!!garbage here\n")

    def test_culture_info_and_data_access_options(self):
        src = (
            "model Model\n"
            "\tdiscourageImplicitMeasures\n"
            "\tdataAccessOptions\n"
            "\t\tlegacyRedirects\n"
            "\t\treturnErrorValuesAsNull\n"
            "\nref cultureInfo en-US\n"
        )
        nodes = parse_tmdl_source(src)
        model = nodes[0]
        assert "discourageImplicitMeasures" in model.bool_props
        dao = next(c for c in model.children if c.kind == "dataAccessOptions")
        assert "legacyRedirects" in dao.bool_props

    def test_missing_folder_raises(self, tmp_path):
        with pytest.raises(TmdlParseError, match="not a directory"):
            parse_tmdl_folder(tmp_path / "nope")

    def test_calculated_column(self):
        src = "table T\n\n\tcolumn Margin = [Sales] - [Cost]\n\t\tdataType: double\n"
        nodes = parse_tmdl_source(src)
        from app.parsers.tmdl import _map_column

        col = _map_column(nodes[0].children[0])
        assert col.is_calculated
        assert col.expression == "[Sales] - [Cost]"
