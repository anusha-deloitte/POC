import { useQuery, useQueryClient } from '@tanstack/react-query'
import { toPng } from 'html-to-image'
import {
  Check,
  Eye,
  FileUp,
  Filter,
  ImageUp,
  Loader2,
  ScanSearch,
  Wrench,
} from 'lucide-react'
import { useRef, useState } from 'react'
import {
  fetchDashboardSpec,
  fetchVisualData,
} from '../dashboard/api'
import { PageCanvas } from '../dashboard/PageCanvas'
import { emptyInteractionState, resolveVisualInteractions } from '../dashboard/interactions'
import { ThemeProvider } from '../dashboard/theme'
import type { PageSpec, VisualResult } from '../dashboard/types'

interface Finding {
  id: string
  region: string
  severity: 'high' | 'medium' | 'low'
  kind: string
  difference: string
  recommendation: string
  fixable: boolean
  fix_applied: boolean
  fix?: { op: string; visual: string } | null
  fix_rejected?: string
  contradicts_harness?: boolean
  harness_note?: string
}
interface DetectedFilter {
  slicer_name: string
  slicer: string
  table: string
  column: string
  value: string | number
}
interface PageComparison {
  page: string
  display_name: string
  similarity: number
  findings: Finding[]
  filters_applied?: { slicer: string; value: string | number }[]
  compared_at: number
  stale?: boolean
  stale_reason?: string
  reference_suspect?: boolean
}
interface CaptureBundle {
  pageName: string
  results: Record<string, VisualResult>
  slicerState: Record<string, (string | number)[]>
}
interface ReferenceStatus {
  pages: { page: string; display_name: string; has_reference: boolean }[]
}

const SEV_BADGE: Record<Finding['severity'], string> = {
  high: 'badge-red',
  medium: 'badge-amber',
  low: 'badge-blue',
}

function SimilarityBadge({ value }: { value: number }) {
  const cls = value >= 90 ? 'badge-green' : value >= 70 ? 'badge-amber' : 'badge-red'
  return <span className={cls}>{value}% similar</span>
}

/** AI vision review: PBI PDF export (or screenshot) vs the converted render. */
export function VisualParity({
  conversionId,
  connectionId,
}: {
  conversionId: string
  connectionId?: string | null
}) {
  const qc = useQueryClient()
  // fall back to the first registered warehouse profile
  const conns = useQuery({
    queryKey: ['connections'],
    queryFn: async (): Promise<{ id: string }[]> => {
      const res = await fetch('/api/v1/connections')
      if (!res.ok) throw new Error('failed to load connections')
      return res.json()
    },
    enabled: !connectionId,
  })
  const effectiveConn = connectionId ?? conns.data?.[0]?.id
  const [pageName, setPageName] = useState<string>()
  const [refFile, setRefFile] = useState<File>()
  const [uploadingPdf, setUploadingPdf] = useState(false)
  const [running, setRunning] = useState(false)
  const [applying, setApplying] = useState<string | null>(null) // finding id or '*'
  const [progress, setProgress] = useState('')
  const [error, setError] = useState('')
  // when set, the offscreen canvas renders THIS page/data (filtered to match the reference)
  const [capture, setCapture] = useState<CaptureBundle | null>(null)
  const captureRef = useRef<HTMLDivElement>(null)

  const spec = useQuery({
    queryKey: ['dash-spec', conversionId],
    queryFn: () => fetchDashboardSpec(conversionId),
  })
  const stored = useQuery({
    queryKey: ['visual-compare', conversionId],
    queryFn: async (): Promise<{ pages: PageComparison[] }> => {
      const res = await fetch(`/api/v1/conversions/${conversionId}/dashboard/visual-compare`)
      if (!res.ok) throw new Error('failed to load comparisons')
      return res.json()
    },
  })
  const refs = useQuery({
    queryKey: ['visual-compare-refs', conversionId],
    queryFn: async (): Promise<ReferenceStatus> => {
      const res = await fetch(
        `/api/v1/conversions/${conversionId}/dashboard/visual-compare/references`,
      )
      if (!res.ok) throw new Error('failed to load reference status')
      return res.json()
    },
  })

  const pages = spec.data?.pages ?? []
  const page: PageSpec | undefined = pages.find((p) => p.name === pageName) ?? pages[0]
  const refReady = new Set(
    (refs.data?.pages ?? []).filter((p) => p.has_reference).map((p) => p.page),
  )
  const pageHasReference = !!page && (refReady.has(page.name) || !!refFile)

  // data for the offscreen render (default filter state, live mode)
  const renderData = useQuery({
    queryKey: ['parity-data', conversionId, page?.name, effectiveConn],
    queryFn: () =>
      fetchVisualData(
        conversionId,
        effectiveConn!,
        page!.name,
        page!.visuals.filter((v) => v.supported && v.query).map((v) => v.name),
        {},
      ),
    enabled: !!page && !!effectiveConn,
    staleTime: Infinity,
  })

  const uploadPdf = async (file: File) => {
    setUploadingPdf(true)
    setError('')
    try {
      const form = new FormData()
      form.append('pdf', file, file.name)
      const res = await fetch(
        `/api/v1/conversions/${conversionId}/dashboard/visual-compare/reference-pdf`,
        { method: 'POST', body: form },
      )
      const body = await res.json()
      if (!res.ok) throw new Error(body.detail ?? res.statusText)
      if (body.warnings?.length) setError(body.warnings.join('; '))
      await qc.invalidateQueries({ queryKey: ['visual-compare-refs', conversionId] })
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setUploadingPdf(false)
    }
  }

  const visualNames = (p: PageSpec) =>
    p.visuals.filter((v) => v.supported && v.query).map((v) => v.name)

  const captureNow = async (p: PageSpec): Promise<Blob> => {
    // charts animate in; give ECharts a settle window before capture
    await new Promise((r) => setTimeout(r, 1800))
    const dataUrl = await toPng(captureRef.current!, {
      width: p.width,
      height: p.height,
      pixelRatio: 1,
      backgroundColor: '#ffffff',
    })
    return (await fetch(dataUrl)).blob()
  }

  /** Detect the reference's slicer state so the render is captured under the
   *  SAME filters (a 2024-filtered PDF vs an all-years render would otherwise
   *  produce false differences). */
  const detectFilters = async (
    p: PageSpec,
    unfiltered: Record<string, VisualResult>,
  ): Promise<DetectedFilter[]> => {
    const slicers = p.visuals.filter((v) => v.visual_type === 'slicer' && v.slicer_target)
    if (!slicers.length) return []
    const res = await fetch(
      `/api/v1/conversions/${conversionId}/dashboard/visual-compare/${p.name}/detect-filters`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          slicers: slicers.map((s) => ({
            name: s.name,
            title: s.title ?? s.slicer_target!.column,
            table: s.slicer_target!.table,
            column: s.slicer_target!.column,
            // slicer domain values from the unfiltered render results
            options: (unfiltered[s.name]?.rows ?? [])
              .map((r) => r[0])
              .filter((v): v is string | number => v !== null)
              .slice(0, 40),
          })),
        }),
      },
    )
    if (!res.ok) return [] // detection is best-effort; compare proceeds unfiltered
    return (await res.json()).selections as DetectedFilter[]
  }

  /** Full pipeline for one page: detect reference filters -> filtered data ->
   *  render with matching slicer state -> capture -> vision compare. */
  const comparePage = async (p: PageSpec, manualRef?: File) => {
    const unfiltered = await fetchVisualData(
      conversionId,
      effectiveConn!,
      p.name,
      visualNames(p),
      {},
    )
    // manual screenshots have no stored reference to read filters from
    const detected = manualRef ? [] : await detectFilters(p, unfiltered)
    let results = unfiltered
    const slicerState: Record<string, (string | number)[]> = {}
    if (detected.length) {
      const clauses = detected.map((d) => ({
        table: d.table,
        column: d.column,
        values: [d.value],
      }))
      const visualFilters = Object.fromEntries(visualNames(p).map((name) => [name, clauses]))
      results = await fetchVisualData(
        conversionId,
        effectiveConn!,
        p.name,
        visualNames(p),
        visualFilters,
      )
      for (const d of detected) slicerState[d.slicer_name] = [d.value]
    }
    setCapture({ pageName: p.name, results, slicerState })
    try {
      const rendered = await captureNow(p)
      const form = new FormData()
      if (manualRef) form.append('reference', manualRef, 'reference.png')
      form.append('rendered', rendered, 'rendered.png')
      if (detected.length)
        form.append(
          'filters',
          JSON.stringify(detected.map((d) => ({ slicer: d.slicer, value: d.value }))),
        )
      const res = await fetch(
        `/api/v1/conversions/${conversionId}/dashboard/visual-compare/${p.name}`,
        { method: 'POST', body: form },
      )
      if (!res.ok) throw new Error((await res.json()).detail ?? res.statusText)
    } finally {
      setCapture(null)
    }
  }

  const runOne = async () => {
    if (!page || !effectiveConn) return
    setRunning(true)
    setError('')
    try {
      await comparePage(page, refFile)
      await qc.invalidateQueries({ queryKey: ['visual-compare', conversionId] })
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setRunning(false)
    }
  }

  const remainingWithRefs = pages.filter((p) => refReady.has(p.name))
  const runAll = async () => {
    setError('')
    setRunning(true)
    try {
      for (const p of remainingWithRefs) {
        setPageName(p.name)
        setProgress(`Comparing ${p.display_name}…`)
        try {
          await comparePage(p)
        } catch (e) {
          setError(`${p.display_name}: ${(e as Error).message}`)
          break
        }
      }
    } finally {
      setProgress('')
      setRunning(false)
    }
    await qc.invalidateQueries({ queryKey: ['visual-compare', conversionId] })
  }

  const result = stored.data?.pages.find((p) => p.page === page?.name)

  const applyFixes = async (findingIds: string[]) => {
    if (!page) return
    setApplying(findingIds.length === 1 ? findingIds[0] : '*')
    setError('')
    let appliedCount = 0
    try {
      const res = await fetch(
        `/api/v1/conversions/${conversionId}/dashboard/visual-compare/${page.name}/apply-fixes`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ finding_ids: findingIds }),
        },
      )
      const body = await res.json()
      if (!res.ok) throw new Error(body.detail ?? res.statusText)
      appliedCount = (body.applied ?? []).length
      if (body.skipped?.length) {
        setError(
          'Not applied: ' +
            body.skipped
              .map((s: { id: string; reason: string }) => `${s.id} (${s.reason})`)
              .join('; '),
        )
      }
      // spec changed: refresh comparisons, spec, and every render cache
      // (awaiting invalidation guarantees the offscreen canvas sees the new spec)
      await Promise.all([
        qc.invalidateQueries({ queryKey: ['visual-compare', conversionId] }),
        qc.invalidateQueries({ queryKey: ['dash-spec', conversionId] }),
        qc.invalidateQueries({ queryKey: ['parity-data', conversionId] }),
        qc.invalidateQueries({ queryKey: ['dash-data', conversionId] }),
      ])
    } catch (e) {
      setError((e as Error).message)
      appliedCount = 0
    } finally {
      setApplying(null)
    }
    // a fix landed: re-render + re-capture + re-compare so the side-by-side
    // image, similarity and findings visibly reflect the change
    if (appliedCount > 0 && effectiveConn && (refReady.has(page.name) || refFile)) {
      setRunning(true)
      setProgress('Fix applied — re-rendering and re-comparing…')
      try {
        // the closure's `page` is from the pre-fix spec; re-fetch so the
        // offscreen canvas renders the patched visuals
        const freshSpec = await fetchDashboardSpec(conversionId)
        const freshPage = freshSpec.pages.find((p) => p.name === page.name) ?? page
        await comparePage(freshPage, refFile)
        await qc.invalidateQueries({ queryKey: ['visual-compare', conversionId] })
      } catch (e) {
        setError(`fix applied, but re-compare failed: ${(e as Error).message}`)
      } finally {
        setProgress('')
        setRunning(false)
      }
    }
  }

  const fixableUnapplied = result?.stale
    ? []
    : (result?.findings ?? []).filter((f) => f.fixable && !f.fix_applied)

  return (
    <div className="card mt-6 p-0">
      <div className="flex items-center justify-between border-b border-surface-300 px-5 py-4">
        <div>
          <h3 className="flex items-center gap-2 text-sm font-bold">
            <ScanSearch size={16} strokeWidth={1.8} className="text-brand-dark" />
            Visual parity review
            <span className="badge-blue">AI vision</span>
          </h3>
          <p className="mt-0.5 text-xs text-surface-600">
            Export the original report to PDF in Power BI (File → Export → PDF) and upload it
            once — every page is matched automatically. GPT-4o then compares each converted page
            against the original and reports series, layout, color and formatting differences the
            numeric checks can't see.
          </p>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 px-5 py-4">
        <label className="btn-primary flex cursor-pointer items-center gap-2 !text-xs">
          {uploadingPdf ? (
            <>
              <Loader2 size={14} className="animate-spin" /> Splitting pages…
            </>
          ) : (
            <>
              <FileUp size={14} strokeWidth={1.8} /> Upload PBI PDF export
            </>
          )}
          <input
            type="file"
            accept="application/pdf"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && uploadPdf(e.target.files[0])}
          />
        </label>

        {refReady.size > 0 && (
          <span className="badge-green">
            {refReady.size}/{pages.length} references ready
          </span>
        )}

        <button
          className="btn-secondary flex items-center gap-2 !text-xs"
          disabled={running || uploadingPdf || remainingWithRefs.length === 0 || !effectiveConn}
          onClick={runAll}
        >
          <Eye size={14} strokeWidth={1.8} /> Compare all pages
        </button>

        {progress && (
          <span className="flex items-center gap-1.5 text-xs text-surface-600">
            <Loader2 size={12} className="animate-spin" /> {progress}
          </span>
        )}
        {error && <span className="text-xs text-brand-red">{error}</span>}
      </div>

      <div className="flex flex-wrap items-center gap-3 border-t border-surface-200 px-5 py-3">
        <select
          aria-label="Page"
          className="input !w-56"
          value={page?.name ?? ''}
          onChange={(e) => setPageName(e.target.value)}
        >
          {pages.map((p) => (
            <option key={p.name} value={p.name}>
              {p.display_name}
              {refReady.has(p.name) ? ' ✓' : ''}
            </option>
          ))}
        </select>

        <label className="btn-secondary flex cursor-pointer items-center gap-2 !text-xs">
          <ImageUp size={14} strokeWidth={1.8} />
          {refFile ? refFile.name : 'Screenshot instead…'}
          <input
            type="file"
            accept="image/png,image/jpeg"
            className="hidden"
            onChange={(e) => setRefFile(e.target.files?.[0])}
          />
        </label>

        <button
          className="btn-secondary flex items-center gap-2 !text-xs"
          disabled={!pageHasReference || !page || running || !renderData.data}
          onClick={runOne}
        >
          {running && !progress ? (
            <>
              <Loader2 size={14} className="animate-spin" /> Comparing…
            </>
          ) : (
            <>
              <Eye size={14} strokeWidth={1.8} /> Compare this page
            </>
          )}
        </button>

        {!pageHasReference && page && (
          <span className="text-xs text-surface-500">
            no reference for this page yet — upload the PDF or a screenshot
          </span>
        )}
        {!renderData.data && page && effectiveConn && (
          <span className="text-xs text-surface-500">rendering converted page…</span>
        )}
      </div>

      {result && page && (
        <div className="border-t border-surface-300 px-5 py-4">
          <div className="mb-3 flex flex-wrap items-center gap-3">
            <SimilarityBadge value={result.similarity} />
            <span className="text-xs text-surface-500">
              {result.findings.length} finding{result.findings.length === 1 ? '' : 's'} ·{' '}
              {new Date(result.compared_at * 1000).toLocaleString()}
            </span>
            {(result.filters_applied?.length ?? 0) > 0 && (
              <span className="badge-blue flex items-center gap-1">
                <Filter size={10} strokeWidth={2} />
                matched filters:{' '}
                {result.filters_applied!.map((f) => `${f.slicer}=${f.value}`).join(', ')}
              </span>
            )}
          </div>

          <div className="mb-4 grid grid-cols-2 gap-3">
            {(['reference', 'rendered'] as const).map((side) => (
              <figure key={side} className="overflow-hidden rounded-lg border border-surface-300">
                <figcaption className="bg-surface-100 px-2 py-1 text-[10px] font-semibold tracking-wide text-surface-600 uppercase">
                  {side === 'reference' ? 'Power BI original' : 'React conversion'}
                </figcaption>
                <img
                  src={`/api/v1/conversions/${conversionId}/dashboard/visual-compare/${page.name}/image/${side}?t=${result.compared_at}`}
                  alt={side}
                  className="w-full"
                />
              </figure>
            ))}
          </div>

          {result.stale && (
            <div
              data-testid="stale-banner"
              className="mb-3 rounded-lg border border-brand-red/40 bg-brand-red/5 px-3 py-2 text-xs text-surface-700"
            >
              <strong>Comparison out of date:</strong>{' '}
              {result.stale_reason ?? 'the reference image changed after this comparison ran'}.
              These findings compare against a superseded reference — re-run “Compare this
              page”. Fixes are disabled until then.
            </div>
          )}
          {!result.stale && result.reference_suspect && (
            <div
              data-testid="reference-suspect-banner"
              className="mb-3 rounded-lg border border-brand-amber/40 bg-brand-amber/5 px-3 py-2 text-xs text-surface-700"
            >
              <strong>Data verified — review differences with care:</strong> most findings
              below are on visuals whose numbers the deterministic validation already proved
              against the live warehouse. If values differ, the PDF export is stale or was
              taken under different filters (re-export and re-compare); axis/format drift is
              presentational and safe to fix via overrides.
            </div>
          )}
          {result.findings.length === 0 ? (
            <p className="text-sm text-surface-600">No meaningful differences found.</p>
          ) : (
            <>
              {/* results saved before the remediation engine existed have no ids/fix payloads */}
              {result.findings.some((f) => !f.id) && (
                <div className="mb-3 rounded-lg border border-brand-amber/30 bg-brand-amber/5 px-3 py-2 text-xs text-surface-700">
                  This comparison predates the remediation engine — re-run “Compare this page”
                  to get actionable fixes for these findings.
                </div>
              )}
              {fixableUnapplied.length > 0 && (
                <div className="mb-3 flex items-center justify-between rounded-lg border border-brand/25 bg-brand/5 px-3 py-2">
                  <span className="text-xs text-surface-700">
                    <strong>{fixableUnapplied.length}</strong> of {result.findings.length} finding
                    {result.findings.length === 1 ? '' : 's'} can be fixed automatically
                  </span>
                  <button
                    className="btn-primary flex items-center gap-1.5 !px-3 !py-1.5 !text-xs"
                    disabled={applying !== null}
                    onClick={() => applyFixes(fixableUnapplied.map((f) => f.id))}
                  >
                    {applying === '*' ? (
                      <Loader2 size={13} className="animate-spin" />
                    ) : (
                      <Wrench size={13} strokeWidth={1.8} />
                    )}
                    Apply all fixes
                  </button>
                </div>
              )}
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-surface-300 text-[10px] tracking-wide text-surface-500 uppercase">
                    <th className="py-1.5 pr-3">Visual / region</th>
                    <th className="py-1.5 pr-3">Severity</th>
                    <th className="py-1.5 pr-3">Kind</th>
                    <th className="py-1.5 pr-3">Difference</th>
                    <th className="py-1.5 pr-3">Recommendation</th>
                    <th className="py-1.5">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {result.findings.map((f) => (
                    <tr key={f.id} className="border-b border-surface-200 align-top">
                      <td className="py-2 pr-3 font-semibold">{f.region}</td>
                      <td className="py-2 pr-3">
                        <span className={SEV_BADGE[f.severity]}>{f.severity}</span>
                      </td>
                      <td className="py-2 pr-3 text-surface-600">{f.kind}</td>
                      <td className="py-2 pr-3">
                        {f.difference}
                        {f.contradicts_harness && (
                          <span
                            className="badge-blue mt-1 block w-fit"
                            title={f.harness_note}
                          >
                            data proven correct — not a conversion error
                          </span>
                        )}
                      </td>
                      <td className="py-2 pr-3 text-surface-600">{f.recommendation}</td>
                      <td className="py-2">
                        {f.fix_applied ? (
                          <span className="badge-green flex w-fit items-center gap-1">
                            <Check size={11} strokeWidth={2.5} /> Applied
                          </span>
                        ) : f.fixable && !result.stale ? (
                          <button
                            className="flex items-center gap-1 rounded-lg border border-brand px-2 py-1 text-[11px] font-semibold text-brand-dark hover:bg-brand/10 disabled:opacity-50"
                            disabled={applying !== null}
                            title={`Applies: ${f.fix?.op} on ${f.fix?.visual}`}
                            onClick={() => applyFixes([f.id])}
                          >
                            {applying === f.id ? (
                              <Loader2 size={12} className="animate-spin" />
                            ) : (
                              <Wrench size={12} strokeWidth={1.8} />
                            )}
                            Apply fix
                          </button>
                        ) : (
                          <button
                            className="flex cursor-not-allowed items-center gap-1 rounded-lg border border-surface-300 px-2 py-1 text-[11px] font-semibold text-surface-400"
                            disabled
                            title={
                              f.fix_rejected
                                ? `Proposed fix rejected: ${f.fix_rejected}`
                                : 'Not automatable — needs human review (data/color/missing-visual differences)'
                            }
                          >
                            <Wrench size={12} strokeWidth={1.8} />
                            Apply fix
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {result.findings.some((f) => f.fix_applied) && (
                <p className="mt-2 text-[11px] text-surface-500">
                  Applied fixes are saved as spec overrides; the page re-renders and
                  re-compares automatically so the result reflects the corrected visual.
                </p>
              )}
            </>
          )}
        </div>
      )}

      {/* summary strip when several pages have been compared */}
      {(stored.data?.pages.length ?? 0) > 1 && (
        <div className="flex flex-wrap gap-2 border-t border-surface-200 px-5 py-3">
          {stored.data!.pages.map((p) => (
            <button
              key={p.page}
              onClick={() => setPageName(p.page)}
              className="flex items-center gap-2 rounded-lg border border-surface-300 px-2.5 py-1.5 text-xs hover:bg-surface-100"
            >
              <span className="font-semibold">{p.display_name}</span>
              <SimilarityBadge value={p.similarity} />
            </button>
          ))}
        </div>
      )}

      {/* offscreen render target at native PBI page size for pixel-true capture;
          during a compare it renders the capture bundle (reference-matched filters) */}
      {spec.data &&
        (() => {
          const capPage = capture ? pages.find((p) => p.name === capture.pageName) : page
          if (!capPage) return null
          return (
            <div
              aria-hidden
              className="fixed top-0 left-[-10000px]"
              style={{ width: capPage.width, height: capPage.height }}
            >
              <div ref={captureRef} style={{ width: capPage.width, height: capPage.height }}>
                <ThemeProvider value={spec.data.theme}>
                  <PageCanvas
                    page={capPage}
                    results={capture?.results ?? renderData.data ?? {}}
                    slicerState={capture?.slicerState ?? {}}
                    onSlicerChange={() => {}}
                    interactionState={emptyInteractionState()}
                    onInteractionChange={() => {}}
                    visualInteractions={resolveVisualInteractions(
                      capPage,
                      spec.data.interaction_graph,
                      emptyInteractionState(),
                    )}
                    annotations={false}
                  />
                </ThemeProvider>
              </div>
            </div>
          )
        })()}
    </div>
  )
}
