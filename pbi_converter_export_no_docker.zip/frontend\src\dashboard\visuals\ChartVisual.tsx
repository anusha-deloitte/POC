import type { EChartsOption } from 'echarts'
import { formatValue, formatWithDisplayUnits } from '../format'
import { useGoodBad, usePalette, useThemeTokens } from '../theme'
import type { VisualResult, VisualSpec } from '../types'
import { EChart } from './EChart'

function seriesData(spec: VisualSpec, data: VisualResult) {
  const axisKey = spec.dim_keys.find((k) => !(spec.series_keys ?? []).includes(k))
  const dimIdx = axisKey ? data.columns.indexOf(axisKey) : -1
  const seriesKey = (spec.series_keys ?? [])[0]
  const si = seriesKey ? data.columns.indexOf(seriesKey) : -1

  // Series role present: pivot long rows into one series per legend value
  if (si >= 0 && dimIdx >= 0 && spec.measure_keys.length) {
    const mi = data.columns.indexOf(spec.measure_keys[0])
    const categories = [...new Set(data.rows.map((r) => String(r[dimIdx] ?? '')))]
    const catIdx = new Map(categories.map((c, i) => [c, i]))
    const bySeries = new Map<string, (number | null)[]>()
    for (const r of data.rows) {
      const sname = String(r[si] ?? '')
      if (!bySeries.has(sname)) bySeries.set(sname, categories.map(() => null))
      const v = r[mi]
      bySeries.get(sname)![catIdx.get(String(r[dimIdx] ?? ''))!] =
        v === null || v === undefined ? null : Number(v)
    }
    const series = [...bySeries.entries()]
      .sort(([a], [b]) => a.localeCompare(b)) // PBI legends list series ascending
      .map(([key, values]) => ({ key, values }))
    return { categories, series }
  }

  const categories = dimIdx >= 0 ? data.rows.map((r) => String(r[dimIdx] ?? '')) : []
  const series = spec.measure_keys.map((mk) => {
    const idx = data.columns.indexOf(mk)
    return {
      key: mk,
      values: data.rows.map((r) => {
        const v = idx >= 0 ? r[idx] : null
        return v === null || v === undefined ? null : Number(v)
      }),
    }
  })
  // reimagined ranking: presentation-only client sort by first-series value
  if (spec.options?.client_sort === 'value_desc' && categories.length && series.length) {
    const order = categories
      .map((_, i) => i)
      .sort((a, b) => (series[0].values[b] ?? -Infinity) - (series[0].values[a] ?? -Infinity))
    return {
      categories: order.map((i) => categories[i]),
      series: series.map((s) => ({ key: s.key, values: order.map((i) => s.values[i]) })),
    }
  }
  return { categories, series }
}

function axisFormatter(spec: VisualSpec) {
  const fmt = spec.measure_formats[spec.measure_keys[0]]
  const units = spec.options?.axis_display_units as number | undefined
  const precision = spec.options?.axis_precision as number | undefined
  if (units !== undefined || precision !== undefined) {
    return (v: number) => formatWithDisplayUnits(v, fmt, units ?? 1, precision)
  }
  return (v: number) => formatValue(v, fmt)
}

function niceInterval(value: number): number {
  // PBI compact visuals target ~2-3 gridlines
  const rough = value / 2
  const exp = Math.floor(Math.log10(rough))
  const base = Math.pow(10, exp)
  const fraction = rough / base
  const niceFraction = fraction < 1.5 ? 1 : fraction < 3 ? 2 : fraction < 7 ? 5 : 10
  return niceFraction * base
}

/** PBI line/area axes extend to the first nice tick above the data max. */
export function niceCeil(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return value
  const interval = niceInterval(value)
  return Math.ceil(value / interval - 1e-9) * interval
}

/** PBI bar/column axes keep the last full tick when the data only slightly
 * exceeds it (the bar rides past the gridline instead of forcing a new tick). */
export function niceCeilBar(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return value
  const interval = niceInterval(value)
  const floor = Math.floor(value / interval + 1e-9) * interval
  return value - floor <= interval * 0.25 && floor > 0
    ? floor
    : Math.ceil(value / interval - 1e-9) * interval
}

function seriesMax(series: { values: (number | null)[] }[]): number {
  let max = 0
  for (const s of series) for (const v of s.values) if (v !== null && v > max) max = v
  return max
}

/** PBI renders a scroll window instead of squeezing many categories. */
function categoryWindow(count: number, horizontal: boolean, seriesCount = 1) {
  const visible = horizontal ? (seriesCount > 1 ? 5 : 6) : 8
  if (count <= visible) return undefined
  return [
    {
      type: 'slider' as const,
      [horizontal ? 'yAxisIndex' : 'xAxisIndex']: 0,
      startValue: 0,
      endValue: visible - 1,
      width: horizontal ? 10 : undefined,
      height: horizontal ? undefined : 10,
      right: horizontal ? 2 : undefined,
      bottom: horizontal ? undefined : 2,
      brushSelect: false,
      zoomLock: true,
      showDetail: false,
      fillerColor: 'rgba(160,174,192,0.35)',
      borderColor: 'transparent',
      backgroundColor: 'rgba(226,232,240,0.5)',
      handleSize: 0,
      moveHandleSize: 6,
    },
  ]
}

/** PBI time axes label every point (rotated) rather than thinning to quarters. */
function denseAxisLabels(count: number) {
  if (count > 40) return { fontSize: 9 }
  return { fontSize: 8, interval: 0 as const, rotate: 90 }
}

/** PBI time-series charts virtualize long axes behind a scrollbar (~28 points). */
function timeWindow(count: number) {
  if (count <= 28) return undefined
  return [
    {
      type: 'slider' as const,
      xAxisIndex: 0,
      startValue: 0,
      endValue: 27,
      height: 10,
      bottom: 2,
      brushSelect: false,
      zoomLock: true,
      showDetail: false,
      fillerColor: 'rgba(160,174,192,0.35)',
      borderColor: 'transparent',
      backgroundColor: 'rgba(226,232,240,0.5)',
      handleSize: 0,
      moveHandleSize: 6,
    },
  ]
}

function legendConfig(spec: VisualSpec, seriesCount: number): EChartsOption['legend'] {
  const legendOn = spec.options?.show_legend as boolean | undefined
  if (legendOn === false) return undefined
  if (legendOn !== true && seriesCount <= 1) return undefined
  const fontSize = (spec.options?.legend_font_size as number | undefined) ?? 10
  const position = String(spec.options?.legend_position ?? 'Top')
  const common = { itemHeight: 8, itemWidth: 12, textStyle: { fontSize } } as const
  if (position.startsWith('Bottom')) return { ...common, bottom: 0 }
  if (position.startsWith('Left')) return { ...common, orient: 'vertical', left: 0, top: 'middle' }
  if (position.startsWith('Right')) return { ...common, orient: 'vertical', right: 0, top: 'middle' }
  return { ...common, top: 0 }
}

function dataLabelConfig(spec: VisualSpec) {
  if (spec.options?.show_labels !== true) return undefined
  const fmt = spec.measure_formats[spec.measure_keys[0]]
  const units = spec.options?.display_units as number | undefined
  const precision = spec.options?.label_precision as number | undefined
  const fontSize = (spec.options?.label_font_size as number | undefined) ?? 9
  return {
    show: true,
    fontSize,
    formatter: (p: { value?: unknown }) =>
      formatWithDisplayUnits(Number(p.value ?? 0), fmt, units ?? 1, precision),
  }
}

export function ChartVisual({
  spec,
  data,
  onSelect,
}: {
  spec: VisualSpec
  data?: VisualResult
  onSelect?: (values: (string | number)[]) => void
}) {
  const PALETTE = usePalette()
  const { good, bad, accent } = useGoodBad()
  const theme = useThemeTokens()
  if (!data) return <div className="p-2 text-xs text-surface-400">…</div>
  if (data.error) return <div className="p-2 text-xs text-brand-red">{data.error}</div>
  const { categories, series } = seriesData(spec, data)
  const fmt = (mk: string) => (v: number | null) => formatValue(v, spec.measure_formats[mk])
  // presentation options lifted from PBIR metadata at compile time
  const legendOn = spec.options?.show_legend as boolean | undefined
  const labelsOn = spec.options?.show_labels as boolean | undefined
  const fancy = spec.options?.style_variant === 'reimagined'
  const stacked = fancy && spec.options?.stacked === true && series.length > 1
  const barRadius = fancy ? ([3, 3, 0, 0] as [number, number, number, number]) : undefined
  const barRadiusH = fancy ? ([0, 3, 3, 0] as [number, number, number, number]) : undefined
  const legend = legendConfig(spec, series.length)
  const dataLabel = dataLabelConfig(spec)
  const axisTitle = spec.options?.axis_title as string | undefined
  const legendPos = String(spec.options?.legend_position ?? 'Top')
  const gridTop = legend && !legendPos.startsWith('Bottom') && !legendPos.startsWith('Left') && !legendPos.startsWith('Right') ? 28 : 8
  const gridBottom = legend && legendPos.startsWith('Bottom') ? 24 : 4

  const base: EChartsOption = {
    color: PALETTE,
    grid: { left: 8, right: 12, top: gridTop, bottom: gridBottom, containLabel: true },
    legend,
    tooltip: {
      trigger: 'axis',
      valueFormatter: (v) => formatValue(v as number, spec.measure_formats[spec.measure_keys[0]]),
      backgroundColor: theme.tooltipBackground,
      borderColor: theme.panelBorder,
      textStyle: { color: theme.tooltipText, fontFamily: theme.fontFamily, fontSize: 11 },
    },
  }

  let option: EChartsOption
  switch (spec.visual_type) {
    case 'donutChart':
    case 'pieChart':
      option = {
        color: PALETTE,
        tooltip: {
          trigger: 'item',
          valueFormatter: (v) =>
            formatValue(v as number, spec.measure_formats[spec.measure_keys[0]]),
          backgroundColor: theme.tooltipBackground,
          borderColor: theme.panelBorder,
          textStyle: { color: theme.tooltipText, fontFamily: theme.fontFamily, fontSize: 11 },
        },
        legend:
          legendOn === false
            ? undefined
            : (legendConfig(spec, 2) ?? {
                orient: 'vertical',
                right: 0,
                top: 'middle',
                textStyle: { fontSize: 10 },
              }),
        series: [
          {
            type: 'pie',
            radius: spec.visual_type === 'donutChart' ? (fancy ? ['55%', '78%'] : ['45%', '75%']) : '75%',
            center: ['40%', '55%'],
            itemStyle: fancy
              ? { borderRadius: 6, borderColor: '#fff', borderWidth: 2 }
              : undefined,
            label: {
              show: labelsOn === true,
              fontSize: (spec.options?.label_font_size as number | undefined) ?? 9,
              // PBI detail labels: value + share; the name lives in the legend
              formatter: (p) =>
                `${formatWithDisplayUnits(
                  Number(p.value ?? 0),
                  spec.measure_formats[spec.measure_keys[0]],
                  (spec.options?.display_units as number | undefined) ?? 1,
                  spec.options?.label_precision as number | undefined,
                )} (${(p.percent ?? 0).toFixed(2)}%)`,
            },
            labelLine: { show: labelsOn === true, length: 8, length2: 6 },
            data: categories.map((c, i) => ({ name: c, value: series[0]?.values[i] ?? 0 })),
          },
        ],
      }
      break

    case 'barChart':
    case 'clusteredBarChart':
      option = {
        ...base,
        xAxis: {
          type: 'value',
          name: axisTitle,
          nameLocation: 'middle',
          nameGap: axisTitle ? 24 : 0,
          max: niceCeilBar(seriesMax(series)),
          axisLabel: { formatter: axisFormatter(spec), fontSize: 9 },
        },
        yAxis: {
          type: 'category',
          data: categories,
          inverse: true,
          // PBI wraps long category labels instead of truncating them
          axisLabel: { fontSize: 9, overflow: 'break', width: 130 },
        },
        dataZoom: fancy ? undefined : categoryWindow(categories.length, true, series.length),
        series: series.map((s) => ({
          name: s.key,
          type: 'bar',
          stack: stacked ? 'total' : undefined,
          data: s.values,
          barMaxWidth: 18,
          itemStyle: fancy && !stacked ? { borderRadius: barRadiusH } : undefined,
          label:
            dataLabel ??
            (fancy && !stacked && series.length === 1
              ? {
                  show: true,
                  position: 'right' as const,
                  fontSize: 8,
                  formatter: (p: { value?: unknown }) =>
                    formatWithDisplayUnits(
                      Number(p.value ?? 0),
                      spec.measure_formats[spec.measure_keys[0]],
                      0,
                    ),
                }
              : undefined),
          tooltip: { valueFormatter: (v) => fmt(s.key)(v as number) },
        })),
      }
      break

    case 'columnChart':
    case 'clusteredColumnChart':
      option = {
        ...base,
        xAxis: {
          type: 'category',
          data: categories,
          // PBI labels every category (wrapping), never thins them away
          axisLabel:
            categories.length <= 8
              ? { fontSize: 9, interval: 0, overflow: 'break', width: 70 }
              : { fontSize: 9 },
        },
        yAxis: {
          type: 'value',
          name: axisTitle,
          max: niceCeilBar(seriesMax(series)),
          axisLabel: { formatter: axisFormatter(spec), fontSize: 9 },
        },
        dataZoom: fancy ? undefined : categoryWindow(categories.length, false),
        series: series.map((s) => ({
          name: s.key,
          type: 'bar',
          stack: stacked ? 'total' : undefined,
          data: s.values,
          barMaxWidth: 24,
          itemStyle: fancy && !stacked ? { borderRadius: barRadius } : undefined,
          label: dataLabel ? { ...dataLabel, position: 'top' } : undefined,
          tooltip: { valueFormatter: (v) => fmt(s.key)(v as number) },
        })),
      }
      break

    case 'lineChart':
    case 'areaChart':
      option = {
        ...base,
        xAxis: {
          type: 'category',
          data: categories,
          boundaryGap: false,
          axisLabel: denseAxisLabels(Math.min(categories.length, 28)),
        },
        dataZoom: fancy ? undefined : timeWindow(categories.length),
        yAxis: {
          type: 'value',
          name: axisTitle,
          // PBI: line charts auto-scale from the data minimum; area charts
          // start at zero with OVERLAPPING fills (not stacked); both end on a
          // nice bound just above the single-series max
          scale: spec.visual_type === 'lineChart',
          max: niceCeil(seriesMax(series)),
          axisLabel: { formatter: axisFormatter(spec), fontSize: 9 },
        },
        series: series.map((s, si) => ({
          name: s.key,
          type: 'line',
          data: s.values,
          showSymbol: false,
          smooth: fancy,
          lineStyle: fancy ? { width: 2.5 } : undefined,
          areaStyle:
            spec.visual_type === 'areaChart'
              ? fancy
                ? {
                    opacity: 0.85,
                    color: {
                      type: 'linear',
                      x: 0, y: 0, x2: 0, y2: 1,
                      colorStops: [
                        { offset: 0, color: PALETTE[si % PALETTE.length] },
                        { offset: 1, color: '#ffffff00' },
                      ],
                    },
                  }
                : {}
              : fancy
                ? {
                    opacity: 0.12,
                    color: PALETTE[si % PALETTE.length],
                  }
                : undefined,
          tooltip: { valueFormatter: (v) => fmt(s.key)(v as number) },
        })),
      }
      break

    case 'waterfallChart': {
      // ECharts waterfall: transparent stack base + colored deltas + total bar
      const vals = series[0]?.values.map((v) => v ?? 0) ?? []
      const bases: number[] = []
      let running = 0
      for (const v of vals) {
        bases.push(v >= 0 ? running : running + v)
        running += v
      }
      // PBI waterfalls may hide the Total column; remediations toggle it off
      const withTotal = spec.options?.waterfall_total !== false
      const cats = withTotal ? [...categories, 'Total'] : categories
      option = {
        color: PALETTE,
        grid: base.grid,
        tooltip: {
          trigger: 'axis',
          valueFormatter: (v) =>
            formatValue(v as number, spec.measure_formats[spec.measure_keys[0]]),
        },
        xAxis: { type: 'category', data: cats, axisLabel: { fontSize: 9, rotate: 30 } },
        yAxis: {
          type: 'value',
          name: axisTitle,
          axisLabel: { formatter: axisFormatter(spec), fontSize: 9 },
        },
        series: [
          {
            type: 'bar',
            stack: 'wf',
            itemStyle: { color: 'transparent' },
            emphasis: { itemStyle: { color: 'transparent' } },
            tooltip: { show: false },
            data: withTotal ? [...bases, 0] : bases,
          },
          {
            type: 'bar',
            stack: 'wf',
            data: [
              ...vals.map((v) => ({
                value: Math.abs(v),
                itemStyle: { color: v >= 0 ? good : bad },
              })),
              ...(withTotal ? [{ value: running, itemStyle: { color: accent } }] : []),
            ],
          },
        ],
      }
      break
    }

    default:
      option = base
  }

  return <EChart option={option} onItemClick={(name) => onSelect?.([name])} />
}
