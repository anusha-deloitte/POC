from pathlib import Path

import pytest

from app.dax.compiler import DaxUnsupported, MeasureCompiler
from app.dax.parser import (
    BinOp,
    ColumnRef,
    FuncCall,
    MeasureRef,
    Num,
    VarExpr,
    parse_dax,
)
from app.parsers.bundle import load_pbip

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


@pytest.fixture(scope="module")
def bundle():
    return load_pbip(FIXTURE)


@pytest.fixture(scope="module")
def compiler(bundle):
    return MeasureCompiler(bundle.model)


class TestParser:
    def test_simple_sum(self):
        ast = parse_dax("SUM(Sales[Amount])")
        assert ast == FuncCall("SUM", (ColumnRef("Sales", "Amount"),))

    def test_quoted_table(self):
        ast = parse_dax("SUM('My Sales'[Amount Due])")
        assert ast == FuncCall("SUM", (ColumnRef("My Sales", "Amount Due"),))

    def test_measure_ref_vs_column_ref(self):
        ast = parse_dax("[Total] + T[Col]")
        assert isinstance(ast, BinOp)
        assert ast.left == MeasureRef("Total")
        assert ast.right == ColumnRef("T", "Col")

    def test_var_return(self):
        ast = parse_dax("VAR x = 1 VAR y = 2 RETURN x + y")
        assert isinstance(ast, VarExpr)
        assert [b[0] for b in ast.bindings] == ["x", "y"]

    def test_concat_operator(self):
        ast = parse_dax('"a" & "b"')
        assert isinstance(ast, BinOp) and ast.op == "&"

    def test_nested_functions(self):
        ast = parse_dax("DIVIDE(SUM(T[A]), SUM(T[B]))")
        assert ast.name == "DIVIDE"
        assert len(ast.args) == 2

    def test_numbers(self):
        assert parse_dax("42") == Num(42.0)

    def test_all_real_measures_parse(self, bundle):
        for t in bundle.model.tables:
            for m in t.measures:
                parse_dax(m.expression)  # must not raise


class TestCompiler:
    def test_tier0_implicit(self, compiler):
        cm = compiler.compile_implicit("MV_MEDICAL_COST_SUMMARY", "PAID_AMOUNT", "Sum")
        assert cm.tier == 0
        [(alias, leaf)] = cm.leaves.items()
        assert leaf.sql == 'SUM("MV_MEDICAL_COST_SUMMARY"."PAID_AMOUNT")'
        assert cm.expr == alias

    def test_simple_measure_single_leaf(self, compiler):
        cm = compiler.compile_measure("Paid Amount")
        assert len(cm.leaves) == 1
        assert next(iter(cm.leaves.values())).sql == 'SUM("MV_MEDICAL_COST_SUMMARY"."PAID_AMOUNT")'

    def test_divide_null_safety(self, compiler):
        cm = compiler.compile_measure("Medical Loss Ratio")
        assert "IFF(" in cm.expr and "IS NULL" in cm.expr

    def test_measure_inlining_shares_leaves(self, compiler):
        # Total PMPM = DIVIDE([Total Cost of Care], [Member Months]); both single-leaf
        cm = compiler.compile_measure("Total PMPM")
        assert len(cm.leaves) == 2

    def test_var_expression(self, compiler):
        cm = compiler.compile_measure("Average Members")
        assert "COUNT(DISTINCT" in " ".join(leaf.sql for leaf in cm.leaves.values())

    def test_sply_context_split(self, compiler):
        cm = compiler.compile_measure("Volume Effect")
        kinds = {leaf.ctx.time_shift.kind if leaf.ctx.time_shift else None
                 for leaf in cm.leaves.values()}
        assert kinds == {"sply", None}
        assert len(cm.leaves) == 3  # shifted allowed, shifted lines, unshifted lines

    def test_ytd_shift(self, compiler):
        cm = compiler.compile_measure("Allowed YTD")
        [leaf] = cm.leaves.values()
        assert leaf.ctx.time_shift.kind == "ytd"
        assert leaf.ctx.time_shift.date_table == "DIM_MONTH"

    def test_rolling_shift(self, compiler):
        cm = compiler.compile_measure("Allowed Rolling 12M")
        [leaf] = cm.leaves.values()
        assert leaf.ctx.time_shift.kind == "rolling"
        assert leaf.ctx.time_shift.n == 12

    def test_sumx_weighted_average(self, compiler):
        cm = compiler.compile_measure("Target PMPM")
        sqls = [leaf.sql for leaf in cm.leaves.values()]
        assert any('"REF_TARGET_PMPM"."TARGET_PMPM" * ' in s for s in sqls)

    def test_calculate_removefilters(self, compiler):
        cm = compiler.compile_measure("Unit Cost Index")
        cleared = [leaf for leaf in cm.leaves.values() if leaf.ctx.clears]
        assert cleared, "expected REMOVEFILTERS leaves with cleared tables"
        assert any("MV_MEDICAL_COST_SUMMARY" in leaf.ctx.clears for leaf in cleared)

    def test_real_report_coverage_at_least_95pct(self, bundle, compiler):
        ok, total = 0, 0
        for t in bundle.model.tables:
            for m in t.measures:
                total += 1
                try:
                    compiler.compile_measure(m.name)
                    ok += 1
                except DaxUnsupported:
                    pass
        assert ok / total >= 0.95, f"tier-1 coverage regressed: {ok}/{total}"

    def test_unknown_measure_raises(self, compiler):
        with pytest.raises(DaxUnsupported, match="unknown measure"):
            compiler.compile_measure("No Such Measure")

    def test_unsupported_routes_to_tier2(self, compiler):
        with pytest.raises(DaxUnsupported):
            compiler.compile_measure("Measures Above Benchmark")
