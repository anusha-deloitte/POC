import { createContext, useContext } from 'react'
import type { ThemeSpec } from './types'

export const DEFAULT_PALETTE = [
  '#118DFF', '#12239E', '#E66C37', '#6B007B', '#E044A7',
  '#744EC2', '#D9B300', '#D64550', '#197278', '#1AAB40',
]

const EMPTY_THEME: ThemeSpec = { data_colors: [], text_classes: {} }

const ThemeContext = createContext<ThemeSpec>(EMPTY_THEME)

export const ThemeProvider = ThemeContext.Provider

export function useTheme(): ThemeSpec {
  return useContext(ThemeContext)
}

export function usePalette(): string[] {
  const theme = useTheme()
  return theme.data_colors.length ? theme.data_colors : DEFAULT_PALETTE
}

export function useGoodBad(): { good: string; bad: string; accent: string } {
  const theme = useTheme()
  return {
    good: theme.good ?? '#1AAB40',
    bad: theme.bad ?? '#D64550',
    accent: theme.data_colors[0] ?? DEFAULT_PALETTE[0],
  }
}

export function useThemeTokens() {
  const theme = useTheme()
  return {
    fontFamily: theme.font_family ?? 'Inter, system-ui, sans-serif',
    cardBackground: theme.card_background ?? '#ffffff',
    panelBackground: theme.panel_background ?? '#ffffff',
    panelBorder: theme.panel_border ?? '#dbe3ef',
    tooltipBackground: theme.tooltip_background ?? '#0f172a',
    tooltipText: theme.tooltip_text ?? '#f8fafc',
    foreground: theme.foreground ?? '#0f172a',
    background: theme.background ?? '#f8fafc',
  }
}
