"""Snowflake connection-profile service.

One profile feeds both planes: the agent plane (Snowflake MCP server config)
and the serving plane (native connector kwargs). Secrets are Fernet-encrypted
at rest and never returned by the API.
"""

from __future__ import annotations

import json
import uuid
from enum import StrEnum
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet
from pydantic import BaseModel, Field, SecretStr


class AuthMethod(StrEnum):
    PASSWORD = "password"  # noqa: S105 - enum label, not a credential
    KEY_PAIR = "key_pair"
    OAUTH_CLIENT_CREDENTIALS = "oauth_client_credentials"
    PAT = "pat"


class SnowflakeProfileIn(BaseModel):
    name: str
    account: str  # e.g. acme-xy12345
    user: str
    auth_method: AuthMethod
    role: str | None = None
    warehouse: str | None = None
    database: str | None = None
    schema_name: str | None = Field(default=None, alias="schema")
    # secrets (exactly the ones the chosen auth method needs)
    password: SecretStr | None = None
    private_key_pem: SecretStr | None = None
    private_key_passphrase: SecretStr | None = None
    oauth_client_id: str | None = None
    oauth_client_secret: SecretStr | None = None
    oauth_token_url: str | None = None
    pat_token: SecretStr | None = None

    model_config = {"populate_by_name": True}

    def required_secrets(self) -> dict[str, str | None]:
        match self.auth_method:
            case AuthMethod.PASSWORD:
                return {"password": self.password.get_secret_value() if self.password else None}
            case AuthMethod.KEY_PAIR:
                return {
                    "private_key_pem": (
                        self.private_key_pem.get_secret_value() if self.private_key_pem else None
                    ),
                    "private_key_passphrase": (
                        self.private_key_passphrase.get_secret_value()
                        if self.private_key_passphrase
                        else None
                    ),
                }
            case AuthMethod.OAUTH_CLIENT_CREDENTIALS:
                return {
                    "oauth_client_secret": (
                        self.oauth_client_secret.get_secret_value()
                        if self.oauth_client_secret
                        else None
                    )
                }
            case AuthMethod.PAT:
                return {"pat_token": self.pat_token.get_secret_value() if self.pat_token else None}


class SnowflakeProfile(BaseModel):
    """Public shape - no secret material."""

    id: str
    name: str
    account: str
    user: str
    auth_method: AuthMethod
    role: str | None = None
    warehouse: str | None = None
    database: str | None = None
    schema_name: str | None = None
    oauth_client_id: str | None = None
    oauth_token_url: str | None = None


class ConnectionValidationError(Exception):
    pass


class ConnectionStore:
    def __init__(self, storage_dir: Path, key_file: Path):
        self.dir = storage_dir / "connections"
        self.dir.mkdir(parents=True, exist_ok=True)
        key_file.parent.mkdir(parents=True, exist_ok=True)
        if not key_file.exists():
            key_file.write_bytes(Fernet.generate_key())
            key_file.chmod(0o600)
        self._fernet = Fernet(key_file.read_bytes())

    def create(self, spec: SnowflakeProfileIn) -> SnowflakeProfile:
        secrets = spec.required_secrets()
        missing = [k for k, v in secrets.items() if v is None and k != "private_key_passphrase"]
        if missing:
            raise ConnectionValidationError(
                f"auth method {spec.auth_method} requires: {', '.join(missing)}"
            )
        if spec.auth_method == AuthMethod.OAUTH_CLIENT_CREDENTIALS and not (
            spec.oauth_client_id and spec.oauth_token_url
        ):
            raise ConnectionValidationError(
                "oauth_client_credentials requires oauth_client_id and oauth_token_url"
            )

        profile_id = str(uuid.uuid4())
        profile = SnowflakeProfile(
            id=profile_id,
            name=spec.name,
            account=spec.account,
            user=spec.user,
            auth_method=spec.auth_method,
            role=spec.role,
            warehouse=spec.warehouse,
            database=spec.database,
            schema_name=spec.schema_name,
            oauth_client_id=spec.oauth_client_id,
            oauth_token_url=spec.oauth_token_url,
        )
        record = {
            "profile": profile.model_dump(),
            "secrets_enc": self._fernet.encrypt(
                json.dumps({k: v for k, v in secrets.items() if v is not None}).encode()
            ).decode(),
        }
        (self.dir / f"{profile_id}.json").write_text(json.dumps(record), encoding="utf-8")
        return profile

    def get(self, profile_id: str) -> SnowflakeProfile:
        return SnowflakeProfile.model_validate(self._record(profile_id)["profile"])

    def list(self) -> list[SnowflakeProfile]:
        out = []
        for f in sorted(self.dir.glob("*.json")):
            out.append(SnowflakeProfile.model_validate(json.loads(f.read_text())["profile"]))
        return out

    def delete(self, profile_id: str) -> None:
        path = self.dir / f"{uuid.UUID(profile_id)}.json"
        if not path.is_file():
            raise KeyError(profile_id)
        path.unlink()

    def _record(self, profile_id: str) -> dict:
        path = self.dir / f"{uuid.UUID(profile_id)}.json"
        if not path.is_file():
            raise KeyError(profile_id)
        return json.loads(path.read_text(encoding="utf-8"))

    def _secrets(self, profile_id: str) -> dict[str, str]:
        rec = self._record(profile_id)
        return json.loads(self._fernet.decrypt(rec["secrets_enc"].encode()))

    # ---- plane adapters ----

    def connector_kwargs(self, profile_id: str, query_tag: str | None = None) -> dict[str, Any]:
        """Serving plane: kwargs for snowflake.connector.connect()."""
        p = self.get(profile_id)
        secrets = self._secrets(profile_id)
        kwargs: dict[str, Any] = {
            "account": p.account,
            "user": p.user,
            "session_parameters": {"QUERY_TAG": query_tag or "pbi_converter"},
        }
        for opt in ("role", "warehouse", "database"):
            if getattr(p, opt):
                kwargs[opt] = getattr(p, opt)
        if p.schema_name:
            kwargs["schema"] = p.schema_name
        match p.auth_method:
            case AuthMethod.PASSWORD:
                kwargs["password"] = secrets["password"]
            case AuthMethod.KEY_PAIR:
                kwargs["private_key"] = _load_private_key_der(
                    secrets["private_key_pem"], secrets.get("private_key_passphrase")
                )
            case AuthMethod.OAUTH_CLIENT_CREDENTIALS:
                kwargs["authenticator"] = "oauth"
                kwargs["token"] = self._fetch_oauth_token(p, secrets)
            case AuthMethod.PAT:
                kwargs["authenticator"] = "programmatic_access_token"
                kwargs["token"] = secrets["pat_token"]
        return kwargs

    def mcp_env(self, profile_id: str) -> dict[str, str]:
        """Agent plane: env for the Snowflake-Labs MCP server process."""
        p = self.get(profile_id)
        secrets = self._secrets(profile_id)
        env = {
            "SNOWFLAKE_ACCOUNT": p.account,
            "SNOWFLAKE_USER": p.user,
        }
        if p.role:
            env["SNOWFLAKE_ROLE"] = p.role
        if p.warehouse:
            env["SNOWFLAKE_WAREHOUSE"] = p.warehouse
        if p.database:
            env["SNOWFLAKE_DATABASE"] = p.database
        match p.auth_method:
            case AuthMethod.PASSWORD:
                env["SNOWFLAKE_PASSWORD"] = secrets["password"]
            case AuthMethod.KEY_PAIR:
                env["SNOWFLAKE_PRIVATE_KEY"] = secrets["private_key_pem"]
                if secrets.get("private_key_passphrase"):
                    env["SNOWFLAKE_PRIVATE_KEY_PASSPHRASE"] = secrets["private_key_passphrase"]
            case AuthMethod.OAUTH_CLIENT_CREDENTIALS | AuthMethod.PAT:
                env["SNOWFLAKE_TOKEN"] = (
                    secrets.get("pat_token") or ""
                )
        return env

    def _fetch_oauth_token(self, p: SnowflakeProfile, secrets: dict[str, str]) -> str:
        import httpx

        resp = httpx.post(
            p.oauth_token_url,
            data={
                "grant_type": "client_credentials",
                "client_id": p.oauth_client_id,
                "client_secret": secrets["oauth_client_secret"],
            },
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()["access_token"]


def _load_private_key_der(pem: str, passphrase: str | None) -> bytes:
    from cryptography.hazmat.primitives import serialization

    password = passphrase.encode() if passphrase else None
    try:
        key = serialization.load_pem_private_key(pem.encode(), password=password)
    except TypeError as e:
        message = str(e)
        # Some clients keep sending a passphrase field even when the PEM is unencrypted.
        # Retry without a password so valid unencrypted keys still work.
        if password and "private key is not encrypted" in message:
            key = serialization.load_pem_private_key(pem.encode(), password=None)
        else:
            raise ValueError(message) from e
    except ValueError as e:
        raise ValueError(str(e)) from e
    return key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def test_connection(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Round-trip probe used by the connect wizard. Requires snowflake extra."""
    import time

    import snowflake.connector

    started = time.perf_counter()
    conn = snowflake.connector.connect(**kwargs, login_timeout=15, network_timeout=15)
    try:
        cur = conn.cursor()
        cur.execute(
            "select current_version(), current_role(), current_warehouse(), current_database()"
        )
        version, role, warehouse, database = cur.fetchone()
        return {
            "ok": True,
            "latency_ms": round((time.perf_counter() - started) * 1000),
            "version": version,
            "role": role,
            "warehouse": warehouse,
            "database": database,
        }
    finally:
        conn.close()
