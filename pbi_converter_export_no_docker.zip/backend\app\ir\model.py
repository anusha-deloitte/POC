"""PBI-IR: canonical semantic-model representation.

Every parser (TMDL today, TMSL/PBIX later) emits this; every compiler consumes it.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field


class DataType(StrEnum):
    STRING = "string"
    INT64 = "int64"
    DOUBLE = "double"
    DECIMAL = "decimal"
    BOOLEAN = "boolean"
    DATETIME = "dateTime"
    DATE = "date"
    TIME = "time"
    BINARY = "binary"
    VARIANT = "variant"
    UNKNOWN = "unknown"


class SummarizeBy(StrEnum):
    NONE = "none"
    SUM = "sum"
    MIN = "min"
    MAX = "max"
    AVERAGE = "average"
    COUNT = "count"
    DISTINCT_COUNT = "distinctCount"
    DEFAULT = "default"


class PartitionMode(StrEnum):
    IMPORT = "import"
    DIRECT_QUERY = "directQuery"
    DUAL = "dual"
    UNKNOWN = "unknown"


class SemanticViewLifecycle(StrEnum):
    DRAFT = "draft"
    CERTIFIED = "certified"
    DEPRECATED = "deprecated"
    BLOCKED = "blocked"


class CrossViewStrategy(StrEnum):
    NONE = "none"
    PRE_JOINED = "pre-joined"
    AGENT_STITCHED = "agent-stitched"


class ExecutionIdentityMode(StrEnum):
    SERVICE_ACCOUNT = "service_account"
    EXECUTE_AS_USER = "execute_as_user"


class SemanticExecutionTier(StrEnum):
    TIER_A_NATIVE = "tier_a_native"
    TIER_B_COMPATIBILITY = "tier_b_compatibility"
    TIER_C_EXCEPTION = "tier_c_exception"


class MeasureSemanticBinding(BaseModel):
    semantic_view: str | None = None
    metric_id: str | None = None
    domain_id: str | None = None
    cross_view: CrossViewStrategy = CrossViewStrategy.NONE
    lifecycle: SemanticViewLifecycle = SemanticViewLifecycle.DRAFT
    confidence: float | None = None
    parity_status: str | None = None


class Column(BaseModel):
    name: str
    data_type: DataType = DataType.UNKNOWN
    source_column: str | None = None
    format_string: str | None = None
    summarize_by: SummarizeBy = SummarizeBy.DEFAULT
    sort_by_column: str | None = None
    is_hidden: bool = False
    is_key: bool = False
    description: str | None = None
    # DAX expression => calculated column
    expression: str | None = None
    lineage_tag: str | None = None
    annotations: dict[str, str] = Field(default_factory=dict)

    @property
    def is_calculated(self) -> bool:
        return self.expression is not None


class Measure(BaseModel):
    name: str
    expression: str
    format_string: str | None = None
    display_folder: str | None = None
    is_hidden: bool = False
    description: str | None = None
    lineage_tag: str | None = None
    # set for measures defined in reportExtensions.json rather than the model
    is_report_level: bool = False
    # mechanism class (aggregate, calculate, iterator, relationship, ...)
    mechanism_class: str | None = None
    semantic_binding: MeasureSemanticBinding | None = None
    execution_tier: SemanticExecutionTier | None = None
    parity_status: str | None = None
    confidence: float | None = None
    annotations: dict[str, str] = Field(default_factory=dict)


class HierarchyLevel(BaseModel):
    name: str
    column: str
    ordinal: int = 0


class Hierarchy(BaseModel):
    name: str
    levels: list[HierarchyLevel] = Field(default_factory=list)
    is_hidden: bool = False
    lineage_tag: str | None = None


class Partition(BaseModel):
    name: str
    mode: PartitionMode = PartitionMode.UNKNOWN
    source_type: str = "m"  # m | calculated | query
    expression: str = ""


class Table(BaseModel):
    name: str
    columns: list[Column] = Field(default_factory=list)
    measures: list[Measure] = Field(default_factory=list)
    hierarchies: list[Hierarchy] = Field(default_factory=list)
    partitions: list[Partition] = Field(default_factory=list)
    is_hidden: bool = False
    description: str | None = None
    lineage_tag: str | None = None
    # auto date/time helper tables (LocalDateTable_*) get flagged, not dropped
    is_auto_date_table: bool = False
    # governance hints used by large-model decomposition/certification
    bounded_context_id: str | None = None
    is_conformed_dimension: bool = False
    annotations: dict[str, str] = Field(default_factory=dict)

    def column(self, name: str) -> Column | None:
        return next((c for c in self.columns if c.name == name), None)

    def measure(self, name: str) -> Measure | None:
        return next((m for m in self.measures if m.name == name), None)


class Relationship(BaseModel):
    name: str
    from_table: str
    from_column: str
    to_table: str
    to_column: str
    # PBI default: many-to-one from -> to
    from_cardinality: str = "many"
    to_cardinality: str = "one"
    cross_filtering_behavior: str = "singleDirection"  # or bothDirections
    is_active: bool = True
    security_filtering_behavior: str | None = None


class Role(BaseModel):
    name: str
    model_permission: str = "read"
    # table name -> DAX filter expression
    table_permissions: dict[str, str] = Field(default_factory=dict)


class SemanticModel(BaseModel):
    name: str = "Model"
    culture: str | None = None
    tables: list[Table] = Field(default_factory=list)
    relationships: list[Relationship] = Field(default_factory=list)
    roles: list[Role] = Field(default_factory=list)
    # shared M expressions (parameters etc.), name -> M source
    expressions: dict[str, str] = Field(default_factory=dict)
    # semantic runtime governance metadata
    semantic_views: list[str] = Field(default_factory=list)
    model_version: str = "v1"
    data_version: str | None = None
    identity_execution_mode: ExecutionIdentityMode = ExecutionIdentityMode.SERVICE_ACCOUNT
    user_mapping_table: str | None = None
    annotations: dict[str, str] = Field(default_factory=dict)

    def table(self, name: str) -> Table | None:
        return next((t for t in self.tables if t.name == name), None)

    def find_measure(self, name: str) -> tuple[Table, Measure] | None:
        for t in self.tables:
            m = t.measure(name)
            if m is not None:
                return t, m
        return None
