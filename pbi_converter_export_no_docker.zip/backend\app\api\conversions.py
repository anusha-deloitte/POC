import os
import shutil
import tempfile
from pathlib import Path
from typing import Annotated

from fastapi import APIRouter, Depends, Form, HTTPException, UploadFile
from pydantic import BaseModel

from app.api.deps import get_ingest_service, require_token
from app.core.config import get_settings
from app.ir.report import ReportBundle
from app.parsers.pbir import PbirParseError
from app.parsers.tmdl import TmdlParseError
from app.services.ingest import IngestError, IngestService

router = APIRouter(
    prefix="/api/v1/conversions", tags=["conversions"], dependencies=[Depends(require_token)]
)


@router.post("", status_code=201)
async def upload_pbip(
    file: UploadFile,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
    name: Annotated[str | None, Form()] = None,
) -> dict:
    if not (file.filename or "").endswith(".zip"):
        raise HTTPException(422, "upload a .zip of the .pbip folder")
    max_bytes = get_settings().max_upload_bytes
    # mkstemp + explicit close (rather than NamedTemporaryFile's open handle) so the
    # file can be reopened by path below — NamedTemporaryFile stays locked on Windows.
    fd, tmp_name = tempfile.mkstemp(suffix=".zip")
    try:
        with os.fdopen(fd, "wb") as tmp:
            written = 0
            while chunk := await file.read(1024 * 1024):
                written += len(chunk)
                if written > max_bytes:
                    raise HTTPException(413, "upload exceeds size limit")
                tmp.write(chunk)
        try:
            stored = svc.ingest_zip(Path(tmp_name))
        except (IngestError, PbirParseError, TmdlParseError) as e:
            raise HTTPException(422, str(e)) from e
    finally:
        os.unlink(tmp_name)
    if name and name.strip():
        svc.set_job_name(stored.id, name)
    bundle = svc.load_bundle(stored.id)
    return _summary(stored.id, bundle)


@router.get("")
def list_conversions(svc: Annotated[IngestService, Depends(get_ingest_service)]) -> list[dict]:
    return svc.list_conversions()


@router.get("/jobs")
def list_jobs(svc: Annotated[IngestService, Depends(get_ingest_service)]) -> list[dict]:
    return svc.list_jobs()


class RenameRequest(BaseModel):
    name: str


@router.patch("/{conversion_id}/name")
def rename_job(
    conversion_id: str,
    req: RenameRequest,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    if not req.name.strip():
        raise HTTPException(422, "name must not be empty")
    try:
        svc.set_job_name(conversion_id, req.name)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e
    return {"id": conversion_id, "name": req.name.strip()[:120]}


@router.get("/{conversion_id}")
def get_conversion(
    conversion_id: str,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    try:
        bundle = svc.load_bundle(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e
    return _summary(conversion_id, bundle)


@router.get("/{conversion_id}/bundle", response_model=ReportBundle)
def get_bundle(
    conversion_id: str,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> ReportBundle:
    try:
        return svc.load_bundle(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e


@router.get("/{conversion_id}/migration")
def get_migration_result(
    conversion_id: str,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> dict:
    """Source-database migration result (schema+data mover), if one ran."""
    import json as _json

    path = svc.conversion_dir(conversion_id) / "migration_result.json"
    if not path.is_file():
        return {"ran": False}
    return {"ran": True, **_json.loads(path.read_text(encoding="utf-8"))}


@router.delete("/{conversion_id}", status_code=204)
def delete_conversion(
    conversion_id: str,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> None:
    try:
        root = svc.conversion_dir(conversion_id)
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e
    if not root.is_dir():
        raise HTTPException(404, "conversion not found")
    shutil.rmtree(root)


def _summary(conversion_id: str, bundle: ReportBundle) -> dict:
    visual_types: dict[str, int] = {}
    for page in bundle.report.pages:
        for v in page.visuals:
            visual_types[v.visual_type] = visual_types.get(v.visual_type, 0) + 1
    measures = sum(len(t.measures) for t in bundle.model.tables)
    return {
        "id": conversion_id,
        "report": bundle.report.name,
        "model": {
            "tables": len(bundle.model.tables),
            "relationships": len(bundle.model.relationships),
            "measures": measures,
            "roles": len(bundle.model.roles),
        },
        "pages": [
            {
                "name": p.name,
                "display_name": p.display_name,
                "visuals": len(p.visuals),
            }
            for p in bundle.report.pages
        ],
        "visual_types": visual_types,
        "source_database": _detect_source_database(bundle),
        "warnings": bundle.warnings,
    }


def _detect_source_database(bundle: ReportBundle) -> dict:
    """Which database the report reads today — drives the source-connection prompt."""
    from app.binding.m_parser import parse_m_binding

    kinds: dict[str, int] = {}
    tables: list[dict] = []
    for table in bundle.model.tables:
        if not table.partitions or table.partitions[0].source_type != "m":
            continue
        mb = parse_m_binding(table.partitions[0].expression, bundle.model.expressions)
        if mb.foreign_source:
            kinds[mb.foreign_source] = kinds.get(mb.foreign_source, 0) + 1
            tables.append(
                {
                    "table": table.name,
                    "kind": mb.foreign_source,
                    "schema": mb.schema,
                    "object": mb.object_name,
                    "database": mb.database,
                }
            )
    if not kinds:
        return {"kind": "snowflake", "needs_migration": False, "tables": []}
    primary = max(kinds, key=lambda k: kinds[k])
    return {"kind": primary, "needs_migration": True, "tables": tables}
