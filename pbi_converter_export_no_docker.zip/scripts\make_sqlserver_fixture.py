#!/usr/bin/env python3
"""Derive the SQL-Server-bound demo fixture from the Snowflake medical fixture.

Rewrites every physical table's M partition from Snowflake.Databases navigation
to Sql.Database Schema/Item navigation (database ClaimsDW, schema dbo) — the
shape Power BI Desktop emits for SQL Server sources. Everything else (measures,
visuals, theme, relationships) is untouched.
"""

from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "fixtures"
SRC = ROOT / "medical_cost_care_analytics"
DST = ROOT / "medical_cost_sqlserver"

# model table -> physical object name in the mssql demo database
OBJECTS = {
    "DIM_LOB": "DIM_LOB",
    "DIM_MONTH": "DIM_MONTH",
    "DIM_PROVIDER_TIER": "DIM_PROVIDER_TIER",
    "DIM_SERVICE_LINE": "DIM_SERVICE_LINE_GROUP",
    "DIM_STATE": "DIM_STATE",
    "DT_TOTAL_COST_OF_CARE": "DT_TOTAL_COST_OF_CARE",
    "FACT_QUALITY_MEASURE": "FACT_QUALITY_MEASURE",
    "MV_MEDICAL_COST_SUMMARY": "MV_MEDICAL_COST_SUMMARY",
    "REF_TARGET_PMPM": "REF_TARGET_PMPM",
}

M_TEMPLATE = """\t\t\t\tlet
\t\t\t\t    Source = Sql.Database("legacy-sql01.corp.local", "ClaimsDW"),
\t\t\t\t    dbo_{obj} = Source{{[Schema = "dbo", Item = "{obj}"]}}[Data]
\t\t\t\tin
\t\t\t\t    dbo_{obj}"""

PARTITION_RE = re.compile(
    r"(partition\s+\S+\s*=\s*m\s*\n\s*mode:\s*import\s*\n\s*source\s*=\s*\n)(.*?)(\n\n|\n\tannotation|\n\s*annotation)",
    re.DOTALL,
)


def rewrite_tmdl(path: Path, obj: str) -> bool:
    text = path.read_text(encoding="utf-8")
    if "Snowflake.Databases" not in text:
        return False
    m = PARTITION_RE.search(text)
    if not m:
        return False
    new_body = M_TEMPLATE.format(obj=obj)
    text = text[: m.start(2)] + new_body + text[m.end(2) :]
    path.write_text(text, encoding="utf-8")
    return True


def main() -> int:
    if DST.exists():
        shutil.rmtree(DST)
    shutil.copytree(SRC, DST)

    # rename .pbip artifacts to the new report name
    old_name = "MedicalCostCareAnalytics"
    new_name = "MedicalCostSqlServer"
    for p in sorted(DST.rglob("*"), key=lambda x: -len(str(x))):
        if old_name in p.name:
            p.rename(p.with_name(p.name.replace(old_name, new_name)))
    pbip = DST / f"{new_name}.pbip"
    if pbip.exists():
        pbip.write_text(
            pbip.read_text(encoding="utf-8").replace(old_name, new_name), encoding="utf-8"
        )
    # platform + definition files referencing the report name
    for p in DST.rglob("*"):
        if p.is_file() and p.suffix in {".json", ".pbir"}:
            try:
                t = p.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            if old_name in t:
                p.write_text(t.replace(old_name, new_name), encoding="utf-8")

    tables_dir = DST / f"{new_name}.SemanticModel" / "definition" / "tables"
    rewritten = []
    for tmdl in tables_dir.glob("*.tmdl"):
        table = tmdl.stem
        if table in OBJECTS and rewrite_tmdl(tmdl, OBJECTS[table]):
            rewritten.append(table)

    # drop the Snowflake connection parameters from expressions.tmdl if present
    expr = DST / f"{new_name}.SemanticModel" / "definition" / "expressions.tmdl"
    if expr.exists():
        expr.unlink()

    print(f"fixture: {DST}")
    print(f"rewritten to Sql.Database: {sorted(rewritten)}")
    missing = set(OBJECTS) - set(rewritten)
    if missing:
        print(f"WARNING not rewritten: {sorted(missing)}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
