import type { VisualSpec } from '../types'

interface TextRun {
  value?: string
  textStyle?: { fontSize?: string; color?: string; fontWeight?: string }
}
interface Paragraph {
  textRuns?: TextRun[]
}

export function TextboxVisual({ spec }: { spec: VisualSpec }) {
  const paragraphs = (spec.static_content?.paragraphs ?? []) as Paragraph[]
  return (
    <div className="flex h-full w-full flex-col justify-center overflow-hidden px-2">
      {paragraphs.map((p, i) => (
        <p key={i} className="truncate leading-tight">
          {(p.textRuns ?? []).map((run, j) => (
            <span
              key={j}
              style={{
                fontSize: run.textStyle?.fontSize
                  ? `${parseFloat(run.textStyle.fontSize) * 1.1}px`
                  : undefined,
                color: run.textStyle?.color,
                fontWeight: run.textStyle?.fontWeight as React.CSSProperties['fontWeight'],
              }}
            >
              {run.value}
            </span>
          ))}
        </p>
      ))}
    </div>
  )
}
