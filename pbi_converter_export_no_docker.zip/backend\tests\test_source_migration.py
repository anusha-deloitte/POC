"""Source-database detection, migration mover, and bundle rewrite."""

from app.binding.m_parser import parse_m_binding
from app.binding.resolver import build_binding_map
from app.ir.model import Partition, SemanticModel, Table
from app.services.migration import (
    MigrationResult,
    migrate_tables,
    rewrite_bundle_to_snowflake,
)

SQLSERVER_M = """let
    Source = Sql.Database("legacy-sql01", "ClaimsDW"),
    dbo_FactClaims = Source{[Schema="dbo", Item="FactClaims"]}[Data]
in
    dbo_FactClaims"""

POSTGRES_M = """let
    Source = PostgreSQL.Database("pg-host", "warehouse"),
    public_dim = Source{[Schema="public", Item="dim_customer"]}[Data]
in
    public_dim"""

MYSQL_M = """let
    Source = MySQL.Database("my-host", "sales"),
    t = Source{[Schema="sales", Item="orders"]}[Data]
in
    t"""

ORACLE_M = """let
    Source = Oracle.Database("ORCL", [HierarchicalNavigation=true]),
    t = Source{[Schema="SCOTT", Item="EMP"]}[Data]
in
    t"""

SNOWFLAKE_M = """let
    Source = Snowflake.Databases("acct", "WH"),
    DB = Source{[Name="D", Kind="Database"]}[Data],
    S = DB{[Name="S", Kind="Schema"]}[Data],
    T = S{[Name="T", Kind="Table"]}[Data]
in
    T"""


class TestForeignMParsing:
    def test_sqlserver_schema_item_navigation(self):
        b = parse_m_binding(SQLSERVER_M)
        assert b.foreign_source == "sqlserver"
        assert not b.is_snowflake
        assert b.database == "ClaimsDW"
        assert b.schema == "dbo"
        assert b.object_name == "FactClaims"
        assert b.is_foreign_resolved
        assert not b.is_resolved  # not snowflake-resolved

    def test_postgres_pattern(self):
        b = parse_m_binding(POSTGRES_M)
        assert b.foreign_source == "postgres"
        assert (b.schema, b.object_name) == ("public", "dim_customer")
        assert b.is_foreign_resolved

    def test_mysql_pattern(self):
        b = parse_m_binding(MYSQL_M)
        assert b.foreign_source == "mysql"
        assert (b.schema, b.object_name) == ("sales", "orders")

    def test_oracle_pattern(self):
        b = parse_m_binding(ORACLE_M)
        assert b.foreign_source == "oracle"
        assert (b.schema, b.object_name) == ("SCOTT", "EMP")

    def test_snowflake_untouched(self):
        b = parse_m_binding(SNOWFLAKE_M)
        assert b.is_snowflake and b.foreign_source is None
        assert b.is_resolved


def _model(m_expr: str) -> SemanticModel:
    return SemanticModel(
        tables=[
            Table(name="FactClaims", partitions=[Partition(name="p", expression=m_expr)])
        ]
    )


class TestResolverForeign:
    def test_foreign_binding_status(self):
        bm = build_binding_map(_model(SQLSERVER_M))
        b = bm.bindings["FactClaims"]
        assert b.status == "needs_migration"
        assert b.source_kind == "sqlserver"
        assert (b.source_schema, b.source_object) == ("dbo", "FactClaims")
        assert bm.needs_migration == [b]

    def test_snowflake_still_resolves(self):
        bm = build_binding_map(_model(SNOWFLAKE_M))
        assert bm.bindings["FactClaims"].status == "resolved"


class _FakeCursor:
    """Stands in for both source (sqlserver dialect) and Snowflake cursors."""

    def __init__(self, columns, rows):
        self._columns = columns
        self._rows = rows
        self._pending = []
        self.executed: list[str] = []
        self.inserted: list[tuple] = []
        self.connection = None

    def execute(self, sql, params=None):
        self.executed.append(sql)
        s = sql.upper()
        if "INFORMATION_SCHEMA.COLUMNS" in s:
            self._pending = list(self._columns)
        elif s.startswith("SELECT COUNT"):
            # source cursor counts its rows; snowflake cursor counts inserts
            n = len(self._rows) if self._rows else len(self.inserted)
            self._pending = [(n,)]
        elif s.startswith("SELECT"):
            self._pending = list(self._rows)
        else:
            self._pending = []

    def executemany(self, sql, rows):
        self.executed.append(sql)
        self.inserted.extend(rows)

    def fetchone(self):
        return self._pending[0] if self._pending else (0,)

    def fetchmany(self, n):
        out, self._pending = self._pending[:n], self._pending[n:]
        return out

    def fetchall(self):
        out, self._pending = self._pending, []
        return out

    def close(self):
        pass


class _FakeConn:
    def __init__(self, cursor):
        self._cursor = cursor

    def cursor(self):
        return self._cursor

    def close(self):
        pass


def test_migrate_tables_end_to_end_with_fakes(monkeypatch):
    # force the executemany fallback path (no pandas involvement in the fake)
    import app.services.migration as mig

    monkeypatch.setattr(
        mig, "_make_batch_writer",
        lambda sf_cursor, insert_sql, tm, db, sch, load_object=None: (
            lambda rows: sf_cursor.executemany(insert_sql, [tuple(r) for r in rows])
        ),
    )

    bm = build_binding_map(_model(SQLSERVER_M))
    src_cursor = _FakeCursor(
        columns=[("CLAIM_ID", "int", None, 10, 0), ("AMOUNT", "decimal", None, 18, 2)],
        rows=[(1, 100.5), (2, 200.25), (3, 300.0)],
    )
    sf_cursor = _FakeCursor(columns=[], rows=[])

    result = migrate_tables(
        bm,
        _FakeConn(src_cursor),
        "sqlserver",
        sf_cursor,
        target_database="TGT_DB",
        target_schema="TGT_SCHEMA",
        batch_size=2,
    )

    assert isinstance(result, MigrationResult)
    t = result.tables[0]
    assert t.error is None, t.error
    assert t.rows_copied == 3
    assert t.verified
    # DDL used mapped Snowflake types (plain CREATE — never destructive)
    ddl = next(s for s in sf_cursor.executed if s.startswith("CREATE TABLE"))
    assert '"CLAIM_ID" NUMBER(10,0)' in ddl
    assert '"AMOUNT" NUMBER(18,2)' in ddl
    # binding rebound to Snowflake
    b = bm.bindings["FactClaims"]
    assert b.status == "resolved"
    assert (b.database, b.schema_name, b.object_name) == ("TGT_DB", "TGT_SCHEMA", "FACTCLAIMS")


def test_bundle_rewrite_points_partitions_at_snowflake():
    from app.services.migration import TableMigration

    model = _model(SQLSERVER_M)

    class _B:  # minimal bundle shim
        pass

    bundle = _B()
    bundle.model = model
    tm = TableMigration(
        model_table="FactClaims",
        source_schema="dbo",
        source_object="FactClaims",
        target_schema="TGT_SCHEMA",
        target_object="FACTCLAIMS",
    )
    tm.verified = True
    n = rewrite_bundle_to_snowflake(bundle, [tm], "acct-x", "WH1", "TGT_DB")
    assert n == 1
    expr = model.tables[0].partitions[0].expression
    assert 'Snowflake.Databases("acct-x", "WH1")' in expr
    assert 'Name="TGT_DB", Kind="Database"' in expr
    assert 'Name="FACTCLAIMS", Kind="Table"' in expr
    # the rewritten M now resolves as native Snowflake
    bm = build_binding_map(model)
    assert bm.bindings["FactClaims"].status == "resolved"


def test_migration_failure_isolated():
    bm = build_binding_map(_model(SQLSERVER_M))

    class _Boom:
        def cursor(self):
            raise RuntimeError("source down")

        def close(self):
            pass

    sf_cursor = _FakeCursor(columns=[], rows=[])
    result = migrate_tables(
        bm, _Boom(), "sqlserver", sf_cursor, target_database="D", target_schema="S"
    )
    assert not result.ok
    assert result.tables[0].error and "source down" in result.tables[0].error
    # binding untouched on failure
    assert bm.bindings["FactClaims"].status == "needs_migration"


def test_user_chosen_kind_overrides_detected_kind(monkeypatch):
    """The report declares SQL Server M, but the user connects a postgres copy —
    the mover must run with the CONNECTION's dialect, not the detected one."""
    import app.services.migration as mig

    monkeypatch.setattr(
        mig, "_make_batch_writer",
        lambda sf_cursor, insert_sql, tm, db, sch, load_object=None: (
            lambda rows: sf_cursor.executemany(insert_sql, [tuple(r) for r in rows])
        ),
    )
    bm = build_binding_map(_model(SQLSERVER_M))
    src_cursor = _FakeCursor(
        columns=[("id", "integer", None, 10, 0)],
        rows=[(1,), (2,)],
    )
    captured: list[str] = []
    orig_execute = src_cursor.execute

    def spy(sql, params=None):
        captured.append(sql)
        return orig_execute(sql, params)

    src_cursor.execute = spy
    sf_cursor = _FakeCursor(columns=[], rows=[])
    result = migrate_tables(
        bm, _FakeConn(src_cursor), "postgres", sf_cursor,
        target_database="D", target_schema="S",
    )
    assert result.ok, result.tables[0].error
    # postgres dialect used on the source side: %s placeholders and "quoted" idents
    assert any("%s" in s for s in captured)
    assert any('FROM "dbo"."FactClaims"' in s for s in captured)


class _SFCursorWithTable(_FakeCursor):
    """Snowflake-side fake simulating a PRE-EXISTING target table."""

    def __init__(self, existing_cols: list[tuple[str, str]], existing_rows: int):
        super().__init__(columns=[], rows=[])
        self.existing_cols = list(existing_cols)
        self.existing_rows = existing_rows
        self.swapped = False

    def execute(self, sql, params=None):
        s = sql.upper().strip()
        if s.startswith("DESCRIBE TABLE"):
            self.executed.append(sql)
            self._pending = list(self.existing_cols)
            return
        if s.startswith("SELECT COUNT"):
            self.executed.append(sql)
            # staging table counts inserts; the real table reports existing rows
            # until a swap or a direct load lands rows in it
            if "__PBIC_STAGE" in s:
                self._pending = [(len(self.inserted),)]
            elif self.swapped:
                self._pending = [(len(self.inserted),)]
            else:
                self._pending = [(self.existing_rows + len(self.inserted),)]
            return
        if "SWAP WITH" in s:
            self.executed.append(sql)
            self.swapped = True
            self._pending = []
            return
        super().execute(sql, params)


def _writer_fallback(monkeypatch):
    import app.services.migration as mig

    monkeypatch.setattr(
        mig, "_make_batch_writer",
        lambda sf_cursor, insert_sql, tm, db, sch, load_object=None: (
            lambda rows: sf_cursor.executemany(insert_sql, [tuple(r) for r in rows])
        ),
    )


class TestSchemaOnlyAndPreexisting:
    def test_copy_data_false_creates_schema_and_skips_rows(self, monkeypatch):
        _writer_fallback(monkeypatch)
        bm = build_binding_map(_model(SQLSERVER_M))
        src_cursor = _FakeCursor(
            columns=[("CLAIM_ID", "int", None, 10, 0)], rows=[(1,), (2,)],
        )
        sf_cursor = _FakeCursor(columns=[], rows=[])
        result = migrate_tables(
            bm, _FakeConn(src_cursor), "sqlserver", sf_cursor,
            target_database="D", target_schema="S", copy_data=False,
        )
        assert result.ok  # copy_skipped counts as ok
        t = result.tables[0]
        assert t.copy_skipped and t.rows_copied == 0 and t.ddl_action == "created"
        # DDL ran, but no INSERT / staging happened
        assert any(s.startswith("CREATE TABLE") for s in sf_cursor.executed)
        assert not sf_cursor.inserted
        # binding still repointed at Snowflake
        assert bm.bindings["FactClaims"].status == "resolved"
        assert "schema-only" in bm.bindings["FactClaims"].detail

    def test_preexisting_empty_table_reused_not_dropped(self, monkeypatch):
        _writer_fallback(monkeypatch)
        bm = build_binding_map(_model(SQLSERVER_M))
        src_cursor = _FakeCursor(
            columns=[("CLAIM_ID", "int", None, 10, 0)], rows=[(1,), (2,)],
        )
        sf_cursor = _SFCursorWithTable(
            existing_cols=[("CLAIM_ID", "NUMBER(10,0)")], existing_rows=0,
        )
        result = migrate_tables(
            bm, _FakeConn(src_cursor), "sqlserver", sf_cursor,
            target_database="D", target_schema="S",
        )
        assert result.ok, result.tables[0].error
        t = result.tables[0]
        assert t.ddl_action == "reused"
        # never a destructive recreate of the existing table
        assert not any(
            s.startswith("CREATE OR REPLACE TABLE") and "__PBIC_STAGE" not in s
            for s in sf_cursor.executed
        )
        # empty table -> direct load, no staging
        assert not any("__PBIC_STAGE" in s for s in sf_cursor.executed)

    def test_preexisting_populated_table_staged_swap_and_column_add(self, monkeypatch):
        _writer_fallback(monkeypatch)
        bm = build_binding_map(_model(SQLSERVER_M))
        src_cursor = _FakeCursor(
            columns=[("CLAIM_ID", "int", None, 10, 0), ("AMOUNT", "decimal", None, 18, 2)],
            rows=[(1, 10.0), (2, 20.0)],
        )
        # existing table has data and is MISSING the AMOUNT column
        sf_cursor = _SFCursorWithTable(
            existing_cols=[("CLAIM_ID", "NUMBER(10,0)")], existing_rows=7,
        )
        result = migrate_tables(
            bm, _FakeConn(src_cursor), "sqlserver", sf_cursor,
            target_database="D", target_schema="S",
        )
        assert result.ok, result.tables[0].error
        t = result.tables[0]
        assert t.ddl_action == "reconciled"
        executed = sf_cursor.executed
        # DDL evolved additively, no drop of the populated table
        assert any("ADD COLUMN" in s and '"AMOUNT"' in s for s in executed)
        assert not any(s.startswith("DROP TABLE") and "__PBIC_STAGE" not in s for s in executed)
        # load went through the staging table and swapped in atomically
        assert any("__PBIC_STAGE" in s and s.startswith("CREATE OR REPLACE TABLE") for s in executed)
        assert sf_cursor.swapped
        assert any("SWAP WITH" in s for s in executed)

    def test_reconcile_widens_varchar_and_number(self):
        from app.services.migration import _reconcile_table_ddl

        recorded: list[str] = []

        class _Cur:
            def execute(self, sql, params=None):
                recorded.append(sql)

        msgs: list[tuple] = []
        _reconcile_table_ddl(
            _Cur(),
            '"D"."S"."T"',
            desired=[("NAME", "VARCHAR(200)"), ("AMT", "NUMBER(18,2)"), ("KEEP", "DATE")],
            existing={"NAME": "VARCHAR(50)", "AMT": "NUMBER(10,2)", "KEEP": "TIMESTAMP_NTZ"},
            emit=lambda *a: msgs.append(a),
            label="t",
        )
        assert any("SET DATA TYPE VARCHAR(200)" in s for s in recorded)
        assert any("SET DATA TYPE NUMBER(18,2)" in s for s in recorded)
        # incompatible drift (DATE vs TIMESTAMP) is reported, never altered
        assert not any('"KEEP"' in s for s in recorded)
        assert any("keeping existing type" in m[1] for m in msgs)


def test_schema_relocation_fallback(monkeypatch):
    """Declared schema absent in the user's source — mover relocates the table
    via a catalog-wide lookup instead of failing."""
    import app.services.migration as mig

    monkeypatch.setattr(
        mig, "_make_batch_writer",
        lambda sf_cursor, insert_sql, tm, db, sch, load_object=None: (
            lambda rows: sf_cursor.executemany(insert_sql, [tuple(r) for r in rows])
        ),
    )

    class _RelocatingCursor(_FakeCursor):
        def execute(self, sql, params=None):
            s = sql.upper()
            if "INFORMATION_SCHEMA.COLUMNS" in s:
                # only the relocated schema has the table
                if params and params[0] == "public":
                    self._pending = list(self._columns)
                else:
                    self._pending = []
                self.executed.append(sql)
                return
            if "INFORMATION_SCHEMA.TABLES" in s:
                self._pending = [("public", "factclaims")]
                self.executed.append(sql)
                return
            super().execute(sql, params)

    src_cursor = _RelocatingCursor(
        columns=[("id", "integer", None, 10, 0)],
        rows=[(1,)],
    )
    sf_cursor = _FakeCursor(columns=[], rows=[])
    bm = build_binding_map(_model(SQLSERVER_M))
    messages: list[str] = []
    result = migrate_tables(
        bm, _FakeConn(src_cursor), "postgres", sf_cursor,
        target_database="D", target_schema="S",
        on_progress=lambda t, m: messages.append(m),
    )
    assert result.ok, result.tables[0].error
    assert result.tables[0].source_schema == "public"
    assert any("using public.factclaims" in m for m in messages)
