from pathlib import Path

import pytest

from app.parsers.bundle import load_pbip
from app.runtime.dashboard import compile_dashboard

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


@pytest.fixture(scope="module")
def spec():
    s, _ = compile_dashboard(load_pbip(FIXTURE))
    return s


class TestThemeCompiler:
    def test_custom_theme_extracted(self, spec):
        t = spec.theme
        assert t.data_colors[0] == "#1F4E79"
        assert len(t.data_colors) == 12
        assert t.good == "#1E8449"
        assert t.bad == "#C0392B"
        assert t.table_accent == "#1F4E79"

    def test_text_classes(self, spec):
        assert spec.theme.text_classes["callout"]["fontSize"] == 32


class TestColumnsRole:
    def test_heat_matrix_column_keys(self, spec):
        heat = next(v for p in spec.pages for v in p.visuals if v.name == "p2heat")
        assert heat.column_keys == ["DIM_MONTH.MONTH_NAME"]
        assert "MV_MEDICAL_COST_SUMMARY.SERVICE_LINE_GROUP" in heat.dim_keys

    def test_plain_tables_have_no_column_keys(self, spec):
        tbl = next(v for p in spec.pages for v in p.visuals if v.name == "p3tbl")
        assert tbl.column_keys == []


class TestWindowedMeasure:
    def test_moving_average_flagged_as_window(self):
        from app.dax.compiler import MeasureCompiler

        bundle = load_pbip(FIXTURE)
        cm = MeasureCompiler(bundle.model).compile_measure("PMPM 3M Moving Average")
        assert cm.window_avg is not None
        assert cm.window_avg.measure == "Total PMPM"
        assert cm.window_avg.n == 3
        assert cm.window_avg.date_table == "DIM_MONTH"

    def test_window_requires_date_grain(self):
        from app.binding.resolver import build_binding_map
        from app.runtime.engine import (
            MeasureRefSpec,
            QueryPlanError,
            QuerySpec,
            SemanticEngine,
        )

        bundle = load_pbip(FIXTURE)
        engine = SemanticEngine(bundle.model, build_binding_map(bundle.model))
        with pytest.raises(QueryPlanError, match="companion|grain"):
            engine.build_sql(
                QuerySpec(measures=[MeasureRefSpec(name="PMPM 3M Moving Average")])
            )

    def test_window_sql_shape(self):
        from app.binding.resolver import build_binding_map
        from app.runtime.engine import (
            DimensionRef,
            MeasureRefSpec,
            QuerySpec,
            SemanticEngine,
        )

        bundle = load_pbip(FIXTURE)
        engine = SemanticEngine(bundle.model, build_binding_map(bundle.model))
        sql, _ = engine.build_sql(
            QuerySpec(
                dimensions=[DimensionRef(table="DIM_MONTH", column="YEAR_MONTH")],
                measures=[
                    MeasureRefSpec(name="Total PMPM"),
                    MeasureRefSpec(name="PMPM 3M Moving Average"),
                ],
            )
        )
        assert "ROWS BETWEEN 2 PRECEDING AND CURRENT ROW" in sql
        assert '"wiq' in sql  # inner CTEs renamed to avoid scope collision


class TestTier2Wiring:
    def test_tier2_sql_rescues_measure(self):
        from app.binding.resolver import build_binding_map
        from app.runtime.engine import MeasureRefSpec, QuerySpec, SemanticEngine

        bundle = load_pbip(FIXTURE)
        engine = SemanticEngine(
            bundle.model,
            build_binding_map(bundle.model),
            tier2_sql={"Measures Above Benchmark": "SELECT 12 AS RESULT"},
        )
        sql, warnings = engine.build_sql(
            QuerySpec(measures=[MeasureRefSpec(name="Measures Above Benchmark")])
        )
        assert "SELECT 12 AS RESULT" in sql
        assert any("AI-translated" in w for w in warnings)

    def test_tier2_spec_marks_supported(self):
        bundle = load_pbip(FIXTURE)
        spec2, _ = compile_dashboard(
            bundle, tier2_sql={"Measures Above Benchmark": "SELECT 12 AS RESULT"}
        )
        assert spec2.measure_tiers["Measures Above Benchmark"] == 2
        rescued = [
            v
            for p in spec2.pages
            for v in p.visuals
            if v.unsupported_reason and "Measures Above Benchmark" in v.unsupported_reason
        ]
        assert rescued == []
