export interface QuerySpecDto {
  dimensions: { table: string; column: string; alias?: string | null }[]
  measures: {
    name?: string | null
    table?: string | null
    column?: string | null
    aggregate?: string | null
    alias?: string | null
  }[]
  filters: FilterClause[]
  sort: { key: string; direction?: string }[]
  limit?: number | null
}

export interface FilterClause {
  table: string
  column: string
  values: (string | number | boolean | null)[]
  op?: string
}

export interface VisualSpec {
  name: string
  visual_type: string
  x: number
  y: number
  width: number
  height: number
  z: number
  title?: string | null
  supported: boolean
  unsupported_reason?: string | null
  substituted_as?: string | null
  query?: QuerySpecDto | null
  dim_keys: string[]
  column_keys: string[]
  series_keys: string[]
  measure_keys: string[]
  measure_roles: Record<string, string>
  measure_formats: Record<string, string>
  slicer_target?: { table: string; column: string } | null
  static_content: Record<string, unknown>
  sort: { key: string; direction?: string }[]
  options?: Record<string, boolean | number | string | object>
}

export interface PageSpec {
  name: string
  display_name: string
  width: number
  height: number
  ordinal: number
  visuals: VisualSpec[]
}

export interface ThemeSpec {
  data_colors: string[]
  background?: string | null
  foreground?: string | null
  table_accent?: string | null
  good?: string | null
  bad?: string | null
  neutral?: string | null
  font_family?: string | null
  card_background?: string | null
  panel_background?: string | null
  panel_border?: string | null
  tooltip_background?: string | null
  tooltip_text?: string | null
  text_classes: Record<string, { fontSize?: number; fontFace?: string; color?: string }>
}

export type InteractionMode = 'filter' | 'highlight' | 'none'

export interface InteractionEdge {
  from_visual: string
  to_visual: string
  mode: InteractionMode
}

export interface InteractionGraph {
  nodes: string[]
  edges: InteractionEdge[]
  sync_groups: Record<string, string[]>
}

export interface Bookmark {
  name: string
  state: Record<string, unknown>
}

export interface DrillThroughTarget {
  page: string
  fields: string[]
}

export interface DashboardSpec {
  report_name: string
  pages: PageSpec[]
  warnings: string[]
  measure_tiers: Record<string, number>
  theme: ThemeSpec
  interaction_graph: InteractionGraph
  bookmarks: Bookmark[]
  drill_through: DrillThroughTarget[]
}

export interface InteractionState {
  selections: Record<string, (string | number)[]>
  hoveredVisual: string | null
  activeBookmark: string | null
}

export interface VisualResult {
  visual: string
  columns: string[]
  rows: (string | number | null)[][]
  sql?: string | null
  warnings: string[]
  error?: string | null
  elapsed_ms: number
  cached: boolean
  execution_tier?: 'tier_a_native' | 'tier_b_compatibility' | 'tier_c_exception'
  trace_codes?: string[]
  execution_path?: 'semantic_view' | 'compatibility' | 'error' | 'static'
  fallback_reason?: string | null
  totals?: { columns: string[]; row: (string | number | null)[] } | null
}

export interface ReimagineBlock {
  kind: 'metric' | 'chart' | 'table' | 'callout' | 'section'
  title: string
  detail: string
  tone: 'brand' | 'neutral' | 'positive' | 'warning'
}

export interface ReimaginePageRecommendation {
  page: string
  display_name: string
  template: string
  summary: string
  rationale: string
  changes: string[]
  blocks: ReimagineBlock[]
}

export interface ReimagineMetricEvidence {
  metric_key: string
  visual: string
  page: string
  sample_value: string
  rationale: string
}

export interface ReimagineVisualDecision {
  page: string
  visual: string
  from_type: string
  to_type: string
  title: string
  kpi_intent: string
  expected_gain: string
  confidence: number
  evidence: ReimagineMetricEvidence[]
}

export interface ReimagineMockupVisual {
  visual: string
  title: string
  visual_type: string
  x: number
  y: number
  width: number
  height: number
}

export interface ReimagineMockupScene {
  page: string
  display_name: string
  story_headline: string
  visuals: ReimagineMockupVisual[]
  data: Record<string, { columns: string[]; rows: (string | number | null)[][] }>
}

export interface ReimagineWebStoryModule {
  slug: string
  title: string
  objective: string
  narrative: string
  layout_pattern: string
  visual_refs: string[]
  best_practices: string[]
}

export interface ReimagineQuality {
  coverage: number
  evidence_count: number
  unsupported_intents: number
  narrative_quality: number
  visual_justification_quality: number
  mockup_realism: number
  generic_penalty: number
  ready: boolean
  failures: string[]
}

export interface ReimagineSnapshotMeta {
  id: string
  generated_at: number
  visual_count: number
  connection_id: string
  mode: 'live' | 'accelerated'
}

export interface DashboardRecommendation {
  id: string
  conversion_id: string
  created_at: number
  status: 'draft' | 'approved' | 'rejected'
  summary: string
  strategy: string[]
  risks: string[]
  pages: ReimaginePageRecommendation[]
  build_message: string
  decisions: { status: 'approved' | 'rejected'; note?: string; decided_at: number; build_message: string }[]
  intent_hypothesis: string
  audience: string
  decision_questions: string[]
  kpi_hierarchy: string[]
  visual_decisions: ReimagineVisualDecision[]
  mockup_scenes: ReimagineMockupScene[]
  web_story_modules: ReimagineWebStoryModule[]
  snapshot?: ReimagineSnapshotMeta | null
  quality: ReimagineQuality
}
