"""Compile a PBI-IR SemanticModel + BindingMap into a Snowflake Semantic View
YAML specification, ready for SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML.

Mapping:
  model.tables          → tables  (base_table = physical binding)
  model.relationships   → relationships (many_to_one / one_to_one / many_to_many)
  table.columns         → dimensions (physical columns)
  calculated columns    → dimensions with sql_expr
  model measures        → metrics  (DAX compiled to SQL expr via tier-1, else tier-2)
  model.roles           → skipped (caller may layer RLS separately)
  auto-date tables      → skipped (matched to real date tables via relationship)

The YAML schema follows Snowflake's semantic model specification:
  https://docs.snowflake.com/en/user-guide/views-semantic/sql
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from typing import Any

import yaml

from app.binding.resolver import BindingMap
from app.dax.compiler import DaxUnsupported, MeasureCompiler, qcol
from app.dax.parser import (
    BinOp,
    Blank,
    Bool,
    ColumnRef,
    DaxParseError,
    FuncCall,
    MeasureRef,
    Num,
    Str,
    UnaryOp,
    VarExpr,
    VarRef,
    parse_dax,
)
from app.ir.model import Column, Measure, SemanticModel, Table

# Snowflake YAML data type mapping from PBI DataType
_TYPE_MAP = {
    "string": "VARCHAR",
    "int64": "NUMBER(18,0)",
    "double": "FLOAT",
    "decimal": "NUMBER(28,6)",
    "boolean": "BOOLEAN",
    "dateTime": "TIMESTAMP_NTZ",
    "date": "DATE",
    "time": "TIME",
    "binary": "BINARY",
    "variant": "VARIANT",
    "unknown": "VARCHAR",
}

# DAX functions that map simply to SQL equivalents for calculated columns
_CALC_COL_FUNCS: dict[str, str] = {
    "YEAR": "YEAR",
    "MONTH": "MONTH",
    "DAY": "DAY",
    "HOUR": "HOUR",
    "MINUTE": "MINUTE",
    "SECOND": "SECOND",
    "QUARTER": "QUARTER",
    "WEEKDAY": "DAYOFWEEK",
    "WEEKNUM": "WEEKOFYEAR",
    "ABS": "ABS",
    "SQRT": "SQRT",
    "FLOOR": "FLOOR",
    "CEILING": "CEIL",
    "LEN": "LENGTH",
    "UPPER": "UPPER",
    "LOWER": "LOWER",
    "TRIM": "TRIM",
}


class YamlCompileError(Exception):
    pass


def _safe_str(value: str) -> str:
    """Ensure a string is safe for YAML output (strip control chars)."""
    return re.sub(r"[\x00-\x1f\x7f]", " ", str(value)).strip()


# ---------------------------------------------------------------------------
# Calculated-column DAX → SQL expression compiler
# ---------------------------------------------------------------------------

class _CalcColCompiler:
    """Compile simple single-table calculated column DAX to a SQL expression.

    Supports: literals, arithmetic, IF, IFF, SWITCH, CONCATENATE, &,
    YEAR/MONTH/DAY/QUARTER/WEEKDAY, UPPER/LOWER/TRIM/LEN, LEFT/RIGHT/MID,
    RELATED (single hop), FORMAT basics, BLANK()/NULL.

    Returns None if unsupported (caller skips the column).
    """

    def __init__(self, table_name: str, model: SemanticModel, bindings: BindingMap):
        self.table_name = table_name
        self.model = model
        self.bindings = bindings

    def compile(self, dax_expr: str) -> str | None:
        try:
            ast = parse_dax(dax_expr)
            return self._expr(ast)
        except (DaxParseError, DaxUnsupported):
            return None

    def _expr(self, node) -> str:
        match node:
            case Num(value=v):
                return str(int(v)) if v == int(v) else repr(v)
            case Str(value=s):
                return "'" + s.replace("'", "''") + "'"
            case Bool(value=b):
                return "TRUE" if b else "FALSE"
            case Blank():
                return "NULL"
            case ColumnRef(table=t, column=c):
                return qcol(t, c)
            case UnaryOp(op="-", operand=o):
                return f"(-{self._expr(o)})"
            case UnaryOp(op="NOT", operand=o):
                return f"(NOT {self._expr(o)})"
            case BinOp(op="&", left=left, right=right):
                return f"({self._expr(left)} || {self._expr(right)})"
            case BinOp(op=op, left=left, right=right):
                sql_op = {"=": "=", "<>": "<>", "&&": "AND", "||": "OR"}.get(op, op)
                return f"({self._expr(left)} {sql_op} {self._expr(right)})"
            case VarExpr(bindings=bindings, body=body):
                # Expand VARs inline (no side effects)
                scope: dict[str, str] = {}
                for var_name, var_ast in bindings:
                    scope[var_name] = f"({self._expr(var_ast)})"
                return self._expr_with_scope(body, scope)
            case VarRef(name=n):
                raise DaxUnsupported(f"unresolved VAR {n!r}")
            case FuncCall():
                return self._func(node)
        raise DaxUnsupported(f"unsupported calc-col node: {node!r}")

    def _expr_with_scope(self, node, scope: dict[str, str]) -> str:
        match node:
            case VarRef(name=n):
                if n in scope:
                    return scope[n]
                raise DaxUnsupported(f"unresolved VAR {n!r}")
            case FuncCall(name=fname, args=args):
                new_args = []
                for a in args:
                    new_args.append(self._expr_with_scope(a, scope))
                # Re-dispatch with resolved args (simplified - just return
                # original expression with scope resolution)
                return self._expr(node)  # fallback to normal path
        return self._expr(node)

    def _func(self, node: FuncCall) -> str:
        fname, args = node.name, node.args

        if fname in _CALC_COL_FUNCS:
            if not args:
                raise DaxUnsupported(f"{fname} needs an argument")
            return f"{_CALC_COL_FUNCS[fname]}({self._expr(args[0])})"

        match fname:
            case "IF":
                cond = self._expr(args[0])
                then = self._expr(args[1])
                alt = self._expr(args[2]) if len(args) > 2 else "NULL"
                return f"IFF({cond}, {then}, {alt})"

            case "IFERROR":
                try_val = self._expr(args[0])
                alt = self._expr(args[1]) if len(args) > 1 else "NULL"
                return f"IFF(TRY_CAST({try_val} AS VARCHAR) IS NULL, {alt}, {try_val})"

            case "SWITCH":
                return self._switch(args)

            case "CONCATENATE":
                if len(args) != 2:
                    raise DaxUnsupported("CONCATENATE expects 2 args")
                return f"({self._expr(args[0])} || {self._expr(args[1])})"

            case "DIVIDE":
                num = self._expr(args[0])
                den = self._expr(args[1])
                alt = self._expr(args[2]) if len(args) > 2 else "NULL"
                return f"IFF(({den}) = 0 OR ({den}) IS NULL, {alt}, ({num}) / ({den}))"

            case "ROUND":
                inner = self._expr(args[0])
                digits = self._expr(args[1]) if len(args) > 1 else "0"
                return f"ROUND({inner}, {digits})"

            case "ISBLANK":
                return f"(({self._expr(args[0])}) IS NULL)"

            case "COALESCE":
                parts = ", ".join(self._expr(a) for a in args)
                return f"COALESCE({parts})"

            case "LEFT":
                return f"LEFT({self._expr(args[0])}, {self._expr(args[1])})"

            case "RIGHT":
                return f"RIGHT({self._expr(args[0])}, {self._expr(args[1])})"

            case "MID":
                s = self._expr(args[0])
                start = self._expr(args[1])
                length = self._expr(args[2]) if len(args) > 2 else "NULL"
                return f"SUBSTR({s}, {start}, {length})"

            case "SUBSTITUTE":
                s = self._expr(args[0])
                old = self._expr(args[1])
                new = self._expr(args[2])
                return f"REPLACE({s}, {old}, {new})"

            case "VALUE":
                return f"TRY_CAST({self._expr(args[0])} AS NUMBER)"

            case "TEXT" | "FORMAT":
                # Basic FORMAT: just cast to string
                return f"TO_VARCHAR({self._expr(args[0])})"

            case "DATE":
                y, m, d = self._expr(args[0]), self._expr(args[1]), self._expr(args[2])
                return f"DATE_FROM_PARTS({y}, {m}, {d})"

            case "DATEDIFF":
                unit_map = {
                    "day": "DAY", "month": "MONTH", "year": "YEAR",
                    "quarter": "QUARTER", "week": "WEEK",
                }
                unit_node = args[0]
                unit_str = getattr(unit_node, "value", "").lower() if isinstance(unit_node, Str) else ""
                sf_unit = unit_map.get(unit_str, "DAY")
                start = self._expr(args[1])
                end = self._expr(args[2])
                return f"DATEDIFF({sf_unit}, {start}, {end})"

            case "RELATED":
                # Single-hop RELATED: compile to a correlated subquery / join hint
                if not args or not isinstance(args[0], ColumnRef):
                    raise DaxUnsupported("RELATED expects a column reference")
                col = args[0]
                # Find the relationship path from this table to col.table
                rel = self._find_relationship(self.table_name, col.table)
                if rel is None:
                    raise DaxUnsupported(
                        f"RELATED: no relationship from {self.table_name} to {col.table}"
                    )
                from_col = rel["from_column"]
                b = self.bindings.get(col.table)
                if b is None or b.status != "resolved":
                    raise DaxUnsupported(f"RELATED: {col.table} has no physical binding")
                phys = b.qualified_name
                # Emit as scalar correlated subquery
                return (
                    f'(SELECT {qcol(col.table, col.column)} FROM {phys} AS "{col.table}" '
                    f'WHERE {qcol(col.table, rel["to_column"])} = {qcol(self.table_name, from_col)} LIMIT 1)'
                )

            case _:
                raise DaxUnsupported(f"calc-col function {fname!r} not supported")

    def _switch(self, args) -> str:
        if len(args) < 3:
            raise DaxUnsupported("SWITCH expects at least 3 args")
        subject = args[0]
        rest = list(args[1:])
        default_sql = "NULL"
        if len(rest) % 2 == 1:
            default_sql = self._expr(rest.pop())

        # SWITCH(TRUE(), cond, val, ...) → CASE WHEN cond THEN val ...
        if isinstance(subject, Bool) and subject.value:
            cases = " ".join(
                f"WHEN {self._expr(rest[i])} THEN {self._expr(rest[i+1])}"
                for i in range(0, len(rest), 2)
            )
            return f"(CASE {cases} ELSE {default_sql} END)"

        subj_sql = self._expr(subject)
        cases = " ".join(
            f"WHEN {self._expr(rest[i])} THEN {self._expr(rest[i+1])}"
            for i in range(0, len(rest), 2)
        )
        return f"(CASE {subj_sql} {cases} ELSE {default_sql} END)"

    def _find_relationship(self, from_table: str, to_table: str) -> dict | None:
        for r in self.model.relationships:
            if r.from_table == from_table and r.to_table == to_table:
                return {"from_column": r.from_column, "to_column": r.to_column}
            if r.to_table == from_table and r.from_table == to_table:
                return {"from_column": r.to_column, "to_column": r.from_column}
        return None


# ---------------------------------------------------------------------------
# Metric SQL compiler (reuses MeasureCompiler's tier-1 output)
# ---------------------------------------------------------------------------

def _compile_metric_expr(
    measure: Measure,
    compiler: MeasureCompiler,
    tier2_sql: dict[str, str],
) -> tuple[str | None, str]:
    """Compile a DAX measure to a Snowflake metric SQL expression.

    Returns (expr_or_None, tier) where tier is "tier1", "tier2", or "unsupported".

    For tier-1: the expr is the leaf aggregate (for single-leaf measures) or
    a note that complex multi-leaf measures need raw SQL fallback.
    For tier-2: uses the validated LLM SQL.
    """
    try:
        cm = compiler.compile_measure(measure.name)
        if cm.window_avg is not None:
            # Window averages require the full SQL engine; can't be a simple metric expr
            return None, "unsupported_window"
        if not cm.leaves:
            # Scalar combiner with no aggregation (e.g. pure literal)
            return cm.expr, "tier1"
        if len(cm.leaves) == 1:
            # Single leaf: the expr IS the aggregate
            alias, leaf = next(iter(cm.leaves.items()))
            return leaf.sql, "tier1"
        # Multi-leaf: reconstruct inline using the combiner + leaf SQL
        # Replace leaf aliases with their actual SQL in the combiner
        expr = cm.expr
        for alias, leaf in cm.leaves.items():
            expr = expr.replace(f"({alias})", f"({leaf.sql})")
            expr = expr.replace(alias, leaf.sql)
        return expr.strip(), "tier1_multi"
    except DaxUnsupported:
        if measure.name in tier2_sql:
            return tier2_sql[measure.name], "tier2"
        return None, "unsupported"


def metric_ident(name: str) -> str:
    """Semantic-view metric identifier for a PBI measure name.

    Prefixed M_ so a metric can never shadow a physical column of the same
    name (Snowflake resolves same-table name references metric-first, which
    would turn SUM(col) into an invalid aggregate-of-metric). Names that lose
    characters in sanitization get a short hash suffix so distinct measures
    like 'PMPM Variance' and 'PMPM Variance %' can never collide.
    """
    ident = re.sub(r"[^A-Za-z0-9_]", "_", name).strip("_")
    if re.search(r"[^A-Za-z0-9_ ]", name):
        digest = hashlib.blake2s(name.encode("utf-8"), digest_size=2).hexdigest().upper()
        ident = f"{ident}_{digest}"
    return "M_" + ident.upper()


@dataclass
class SemanticMetricPlan:
    """How a PBI measure maps onto the semantic-view metric surface.

    kind="table":   a single aggregate → table metric `home.ident`.
    kind="derived": multi-aggregate scalar → helper table metrics (one per
                    leaf) + a view-level derived metric combining them.
    """

    kind: str  # "table" | "derived"
    ident: str
    home: str | None = None
    expr: str = ""
    helpers: list[tuple[str, str, str]] = field(default_factory=list)  # (home, ident, agg_sql)


def _leaf_home(model: SemanticModel, tables: set[str]) -> str | None:
    if len(tables) == 1:
        return next(iter(tables))
    # multi-table leaf: anchor on the many-side (fact) if unambiguous
    one_side = {r.to_table for r in model.relationships}
    facts = [t for t in tables if t not in one_side]
    return facts[0] if len(facts) == 1 else None


def semantic_metric_plan(
    model: SemanticModel,
    compiler: MeasureCompiler,
    measure_name: str,
) -> SemanticMetricPlan | None:
    """Plan a semantic-view metric for a tier-1 measure with default-context
    leaves; None when the measure needs the full SQL engine (window fns,
    CALCULATE contexts, time shifts, tier-2)."""
    try:
        cm = compiler.compile_measure(measure_name)
    except DaxUnsupported:
        return None
    if cm.window_avg is not None or not cm.leaves:
        return None
    for leaf in cm.leaves.values():
        if leaf.ctx.filters or leaf.ctx.clears or leaf.ctx.time_shift or leaf.ctx.use_relationships:
            return None

    ident = metric_ident(measure_name)

    if len(cm.leaves) == 1:
        leaf = next(iter(cm.leaves.values()))
        home = _leaf_home(model, leaf.tables)
        if home is None:
            return None
        return SemanticMetricPlan(kind="table", ident=ident, home=home, expr=leaf.sql.strip())

    # multi-aggregate scalar: Snowflake forbids inlining several aggregates in
    # one metric expr — emit private helper metrics and a derived combiner.
    helpers: list[tuple[str, str, str]] = []
    expr = cm.expr
    for i, alias in enumerate(sorted(cm.leaves, key=len, reverse=True)):
        leaf = cm.leaves[alias]
        home = _leaf_home(model, leaf.tables)
        if home is None:
            return None
        helper_ident = f"{ident}__L{i}"
        helpers.append((home, helper_ident, leaf.sql.strip()))
        expr = expr.replace(alias, f"{home}.{helper_ident}")
    return SemanticMetricPlan(kind="derived", ident=ident, expr=expr.strip(), helpers=helpers)


# ---------------------------------------------------------------------------
# Main YAML compiler
# ---------------------------------------------------------------------------

class SemanticViewYamlCompiler:
    """Compile SemanticModel + BindingMap → Snowflake Semantic View YAML."""

    def __init__(
        self,
        model: SemanticModel,
        bindings: BindingMap,
        tier2_sql: dict[str, str] | None = None,
        view_name: str | None = None,
    ):
        self.model = model
        self.bindings = bindings
        self.tier2_sql = tier2_sql or {}
        self.view_name = view_name or _safe_str(model.name).replace(" ", "_").upper() + "_SV"
        self._compiler = MeasureCompiler(model)

    def compile(self) -> dict:
        """Return the semantic view spec as a Python dict (serializable to YAML)."""
        spec: dict[str, Any] = {
            "name": self.view_name,
            "description": _safe_str(f"Semantic view migrated from Power BI model: {self.model.name}"),
            "tables": [],
            "relationships": [],
        }

        # Build table specs
        table_map: dict[str, str] = {}  # PBI table name → YAML table alias
        for table in self.model.tables:
            if table.is_auto_date_table:
                continue
            b = self.bindings.get(table.name)
            if b is None or b.status not in ("resolved",) or b.is_virtual:
                continue

            alias = re.sub(r"[^A-Za-z0-9_]", "_", table.name)
            table_map[table.name] = alias

            table_spec = self._build_table_spec(table, alias, b)
            spec["tables"].append(table_spec)

        # Build relationships
        for rel in self.model.relationships:
            if rel.from_table not in table_map or rel.to_table not in table_map:
                continue
            rel_type = self._cardinality(rel.from_cardinality, rel.to_cardinality)
            spec["relationships"].append({
                "name": re.sub(r"[^A-Za-z0-9_]", "_", rel.name),
                "left_table": table_map[rel.from_table],
                "right_table": table_map[rel.to_table],
                "relationship_columns": [
                    {
                        "left_column": rel.from_column,
                        "right_column": rel.to_column,
                    }
                ],
                "relationship_type": rel_type,
            })

        # Measures on virtual measure-tables (e.g. _Measures) have no physical
        # home; attach each as a metric on the fact table its leaves aggregate,
        # so the semantic view exposes the full measure surface.
        alias_to_spec = {t["name"]: t for t in spec["tables"]}
        existing_metrics = {
            m["name"].upper() for t in spec["tables"] for m in t.get("metrics", [])
        }
        derived_metrics: list[dict] = []
        for table in self.model.tables:
            b = self.bindings.get(table.name)
            if b is None or not b.is_virtual:
                continue
            for measure in table.measures:
                if measure.is_hidden:
                    continue
                plan = semantic_metric_plan(self.model, self._compiler, measure.name)
                if plan is None or plan.ident in existing_metrics:
                    continue
                if plan.kind == "table":
                    home_alias = table_map.get(plan.home or "")
                    tspec = alias_to_spec.get(home_alias) if home_alias else None
                    if tspec is None:
                        continue
                    existing_metrics.add(plan.ident)
                    metric: dict[str, Any] = {"name": plan.ident, "expr": plan.expr}
                    if measure.name != plan.ident:
                        metric["synonyms"] = [measure.name]
                    if measure.description:
                        metric["description"] = _safe_str(measure.description)
                    tspec.setdefault("metrics", []).append(metric)
                    continue
                # derived: private helper metrics + a view-level combiner
                helper_specs = []
                ok = True
                for home, helper_ident, agg_sql in plan.helpers:
                    home_alias = table_map.get(home)
                    tspec = alias_to_spec.get(home_alias) if home_alias else None
                    if tspec is None:
                        ok = False
                        break
                    helper_specs.append((tspec, helper_ident, agg_sql))
                if not ok:
                    continue
                existing_metrics.add(plan.ident)
                for tspec, helper_ident, agg_sql in helper_specs:
                    if helper_ident.upper() not in existing_metrics:
                        existing_metrics.add(helper_ident.upper())
                        tspec.setdefault("metrics", []).append(
                            {
                                "name": helper_ident,
                                "expr": agg_sql,
                                "access_modifier": "private_access",
                            }
                        )
                derived: dict[str, Any] = {"name": plan.ident, "expr": plan.expr}
                if measure.name != plan.ident:
                    derived["synonyms"] = [measure.name]
                if measure.description:
                    derived["description"] = _safe_str(measure.description)
                derived_metrics.append(derived)

        # Snowflake requires the referenced side of a relationship to be the PK
        # or a declared unique key; PBI one-side columns are unique by contract,
        # so declare them when they differ from the table's primary key.
        for rel in spec["relationships"]:
            tspec = alias_to_spec.get(rel["right_table"])
            if tspec is None:
                continue
            ref_cols = [p["right_column"] for p in rel["relationship_columns"]]
            ref_set = sorted(c.upper() for c in ref_cols)
            pk_set = sorted(
                c.upper() for c in (tspec.get("primary_key") or {}).get("columns", [])
            )
            if ref_set == pk_set:
                continue
            uks = tspec.setdefault("unique_keys", [])
            if not any(
                sorted(c.upper() for c in uk.get("columns", [])) == ref_set for uk in uks
            ):
                uks.append({"columns": ref_cols})

        # Build top-level metrics (cross-table measures go here)
        top_metrics = self._build_top_level_metrics(table_map)
        top_names = {m["name"].upper() for m in top_metrics}
        top_metrics.extend(
            m for m in derived_metrics if m["name"].upper() not in top_names
        )
        if top_metrics:
            spec["metrics"] = top_metrics

        # Clean empty sections
        if not spec["relationships"]:
            del spec["relationships"]

        return spec

    def compile_yaml(self) -> str:
        """Return the spec as a YAML string."""
        spec = self.compile()
        return yaml.dump(spec, default_flow_style=False, allow_unicode=True, sort_keys=False)

    def materialization_plan(self) -> list[dict[str, Any]]:
        """Best-effort physical plans for derived tables that must exist before
        the semantic view can bind them.

        For now, only simple Table.Group-derived tables with parseable group-by
        columns and count/min-style aggregates produce a plan.
        """
        plans: list[dict[str, Any]] = []
        for table in self.model.tables:
            b = self.bindings.get(table.name)
            if b is None or b.status != "materialization_required":
                continue
            plan: dict[str, Any] = {
                "table": table.name,
                "strategy": b.materialization_strategy or "view",
                "detail": b.detail,
            }
            if b.materialization_sql:
                plan["sql"] = b.materialization_sql
            plans.append(plan)
        return plans

    def _build_table_spec(self, table: Table, alias: str, binding) -> dict:
        b_parts: list[str] = []
        if binding.database:
            b_parts.append(("database", binding.database))
        b_parts_dict: dict = {}
        if binding.database:
            b_parts_dict["database"] = binding.database
        if binding.schema_name:
            b_parts_dict["schema"] = binding.schema_name
        b_parts_dict["table"] = binding.object_name or alias

        tspec: dict[str, Any] = {
            "name": alias,
            "base_table": b_parts_dict,
            "dimensions": [],
            "facts": [],
            "metrics": [],
        }

        if table.description:
            tspec["description"] = _safe_str(table.description)

        # Primary key detection
        key_cols = [c.name for c in table.columns if c.is_key]
        if key_cols:
            tspec["primary_key"] = {"columns": key_cols}

        calc_compiler = _CalcColCompiler(table.name, self.model, self.bindings)

        # hidden columns are included: PBI hides them from field lists only,
        # but visuals/relationships still query them (e.g. sort-by columns)
        for col in table.columns:
            dtype = _TYPE_MAP.get(str(col.data_type), "VARCHAR")

            if col.is_calculated and col.expression:
                # Calculated column → dimension with sql_expr
                sql_expr = calc_compiler.compile(col.expression)
                if sql_expr is None:
                    # Can't compile — skip with comment tracking
                    continue
                dim = {
                    "name": col.name,
                    "expr": sql_expr,
                    "data_type": dtype,
                }
                if col.description:
                    dim["description"] = _safe_str(col.description)
                tspec["dimensions"].append(dim)
            else:
                # Physical column → dimension (use table_alias.column_name)
                source_col = col.source_column or col.name
                dim = {
                    "name": col.name,
                    "expr": f"{alias}.{source_col}",
                    "data_type": dtype,
                }
                if col.description:
                    dim["description"] = _safe_str(col.description)
                tspec["dimensions"].append(dim)

        # Table-scoped measures → metrics on this table
        for measure in table.measures:
            if measure.is_hidden:
                continue
            expr, tier = _compile_metric_expr(measure, self._compiler, self.tier2_sql)
            if expr is None:
                continue
            metric: dict[str, Any] = {
                "name": measure.name,
                "expr": expr,
            }
            if measure.description:
                metric["description"] = _safe_str(measure.description)
            elif tier == "tier2":
                metric["description"] = "AI-translated from DAX (tier-2); verify for accuracy."
            if measure.format_string:
                metric["synonyms"] = [measure.name]  # help Cortex Analyst find it by name
            tspec["metrics"].append(metric)

        # Clean empty lists
        for key in ("dimensions", "facts", "metrics"):
            if not tspec[key]:
                del tspec[key]

        return tspec

    def _build_top_level_metrics(self, table_map: dict[str, str]) -> list[dict]:
        """Report-level measures and cross-table measures → top-level metrics."""
        out = []
        for table in self.model.tables:
            for measure in table.measures:
                if not measure.is_report_level:
                    continue
                expr, tier = _compile_metric_expr(measure, self._compiler, self.tier2_sql)
                if expr is None:
                    continue
                metric: dict[str, Any] = {
                    "name": measure.name,
                    "expr": expr,
                    "description": "Report-level measure (migrated from Power BI report).",
                }
                if tier == "tier2":
                    metric["description"] += " AI-translated from DAX."
                out.append(metric)
        return out

    @staticmethod
    def _cardinality(from_card: str, to_card: str) -> str:
        if from_card == "many" and to_card == "one":
            return "many_to_one"
        if from_card == "one" and to_card == "many":
            return "one_to_many"
        if from_card == "many" and to_card == "many":
            return "many_to_many"
        return "one_to_one"


def compile_to_yaml(
    model: SemanticModel,
    bindings: BindingMap,
    tier2_sql: dict[str, str] | None = None,
    view_name: str | None = None,
) -> str:
    """Convenience wrapper: return YAML string for the Snowflake Semantic View."""
    compiler = SemanticViewYamlCompiler(model, bindings, tier2_sql, view_name)
    return compiler.compile_yaml()


_COL_REF = re.compile(r"\b([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\b")


def prune_spec_to_live_schema(spec: dict, cursor) -> tuple[dict, list[str]]:
    """Drop spec elements referencing columns absent from the live schema.

    PBI models can declare columns produced by unapplied M transforms (e.g.
    Table.Group aggregates like CARE_FAMILY_COUNT) that have no physical
    counterpart; deploying them fails the whole CREATE SEMANTIC VIEW call.
    Returns the pruned spec and human-readable warnings for each removal.
    """
    warnings: list[str] = []
    live: dict[str, set[str]] = {}

    for tbl in spec.get("tables", []):
        base = tbl.get("base_table") or {}
        db, schema, name = base.get("database"), base.get("schema"), base.get("table")
        alias = tbl.get("name")
        if not (db and schema and name and alias):
            continue
        try:
            db_q = str(db).replace('"', '""')
            cursor.execute(
                f'SELECT column_name FROM "{db_q}".INFORMATION_SCHEMA.COLUMNS '  # noqa: S608
                "WHERE table_schema = %s AND table_name = %s",
                (schema, name),
            )
            live[alias] = {r[0].upper() for r in cursor.fetchall()}
        except Exception:  # noqa: BLE001 - introspection failure: skip pruning for table
            continue

    # declared facts/metrics are valid expr refs even though they are not
    # physical columns (metric-to-metric refs like FACT.M_TOTAL_PMPM__L0);
    # dimensions are NOT exempt — their exprs must resolve physically.
    declared: dict[str, set[str]] = {}
    for tbl in spec.get("tables", []):
        names = declared.setdefault(tbl.get("name", ""), set())
        for section in ("facts", "metrics"):
            for item in tbl.get(section, []):
                if item.get("name"):
                    names.add(item["name"].upper())

    def missing(expr: str) -> list[str]:
        out = []
        for alias, col in _COL_REF.findall(expr or ""):
            cols = live.get(alias)
            if cols is None:
                continue
            if col.upper() in cols or col.upper() in declared.get(alias, set()):
                continue
            out.append(f"{alias}.{col}")
        return out

    for tbl in spec.get("tables", []):
        alias = tbl.get("name")
        for section in ("dimensions", "facts", "metrics"):
            kept = []
            for item in tbl.get(section, []):
                bad = missing(item.get("expr", ""))
                if bad:
                    warnings.append(
                        f"pruned {section[:-1]} {alias}.{item.get('name')}: "
                        f"column(s) not in live schema: {', '.join(bad)}"
                    )
                else:
                    kept.append(item)
            if section in tbl:
                if kept:
                    tbl[section] = kept
                else:
                    del tbl[section]
        pk = tbl.get("primary_key") or {}
        cols = live.get(alias)
        if cols is not None and pk.get("columns"):
            bad_pk = [c for c in pk["columns"] if c.upper() not in cols]
            if bad_pk:
                warnings.append(
                    f"pruned primary_key on {alias}: column(s) not in live schema: "
                    + ", ".join(bad_pk)
                )
                del tbl["primary_key"]
        if cols is not None and tbl.get("unique_keys"):
            kept_uks = []
            for uk in tbl["unique_keys"]:
                bad_uk = [c for c in uk.get("columns", []) if c.upper() not in cols]
                if bad_uk:
                    warnings.append(
                        f"pruned unique_key on {alias}: column(s) not in live schema: "
                        + ", ".join(bad_uk)
                    )
                else:
                    kept_uks.append(uk)
            if kept_uks:
                tbl["unique_keys"] = kept_uks
            else:
                del tbl["unique_keys"]

    if "relationships" in spec:
        kept_rels = []
        for rel in spec["relationships"]:
            bad = []
            for pair in rel.get("relationship_columns", []):
                lcols = live.get(rel.get("left_table"))
                rcols = live.get(rel.get("right_table"))
                if lcols is not None and pair.get("left_column", "").upper() not in lcols:
                    bad.append(f"{rel.get('left_table')}.{pair.get('left_column')}")
                if rcols is not None and pair.get("right_column", "").upper() not in rcols:
                    bad.append(f"{rel.get('right_table')}.{pair.get('right_column')}")
            if bad:
                warnings.append(
                    f"pruned relationship {rel.get('name')}: column(s) not in live schema: "
                    + ", ".join(bad)
                )
            else:
                kept_rels.append(rel)
        if kept_rels:
            spec["relationships"] = kept_rels
        else:
            del spec["relationships"]

    if "metrics" in spec:
        kept_metrics = []
        for metric in spec["metrics"]:
            bad = missing(metric.get("expr", ""))
            if bad:
                warnings.append(
                    f"pruned metric {metric.get('name')}: column(s) not in live schema: "
                    + ", ".join(bad)
                )
            else:
                kept_metrics.append(metric)
        if kept_metrics:
            spec["metrics"] = kept_metrics
        else:
            del spec["metrics"]

    return spec, warnings
