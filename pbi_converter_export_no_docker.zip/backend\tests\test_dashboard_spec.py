from pathlib import Path

import pytest

from app.parsers.bundle import load_pbip
from app.runtime.dashboard import compile_dashboard

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


@pytest.fixture(scope="module")
def spec():
    bundle = load_pbip(FIXTURE)
    s, _ = compile_dashboard(bundle)
    return s


class TestDashboardSpec:
    def test_all_pages_compiled(self, spec):
        assert [p.display_name for p in spec.pages] == [
            "1. Executive Summary",
            "2. Utilization & Cost Drivers",
            "3. Provider Network",
            "4. Membership, Risk & Quality",
        ]

    def test_exec_summary_fully_supported(self, spec):
        page = spec.pages[0]
        unsupported = [v for v in page.visuals if not v.supported]
        assert unsupported == [], [
            (v.name, v.unsupported_reason) for v in unsupported
        ]

    def test_card_query_shape(self, spec):
        page = spec.pages[0]
        card = next(v for v in page.visuals if v.name == "p1k0")
        assert card.query is not None
        assert card.measure_keys == ["Total Cost of Care"]
        assert card.query.dimensions == []

    def test_donut_query_shape(self, spec):
        donut = next(v for v in spec.pages[0].visuals if v.name == "p1donut")
        assert donut.dim_keys == ["MV_MEDICAL_COST_SUMMARY.CARE_SETTING"]
        assert donut.measure_keys == ["Allowed Amount"]

    def test_series_role_becomes_second_dim(self, spec):
        """Series role must group the query AND be flagged for renderer pivot."""
        v = next(v for p in spec.pages for v in p.visuals if v.name == "p3ctr")
        assert v.dim_keys == [
            "MV_MEDICAL_COST_SUMMARY.NETWORK_STATUS",
            "MV_MEDICAL_COST_SUMMARY.PROVIDER_TIER",
        ]
        assert v.series_keys == ["MV_MEDICAL_COST_SUMMARY.PROVIDER_TIER"]
        assert v.dropped_fields == []

    def test_no_silent_projection_loss(self, spec):
        """Every dropped projection must be explicit; only the documented
        treemap substitution (depth-limited Explain By) is tolerated."""
        offenders = [
            (v.name, v.dropped_fields)
            for p in spec.pages
            for v in p.visuals
            if v.dropped_fields and not v.substituted_as
        ]
        assert offenders == []

    def test_line_three_measures(self, spec):
        line = next(v for v in spec.pages[0].visuals if v.name == "p1trend")
        assert line.measure_keys == ["Total PMPM", "Target PMPM", "PMPM 3M Moving Average"]

    def test_pivot_multi_measures(self, spec):
        mtx = next(v for v in spec.pages[0].visuals if v.name == "p1mtx")
        assert mtx.visual_type == "pivotTable"
        assert len(mtx.measure_keys) == 4

    def test_slicer_target_and_domain_query(self, spec):
        sl = next(v for v in spec.pages[0].visuals if v.name == "p1slyr")
        assert sl.slicer_target == {"table": "DIM_MONTH", "column": "CALENDAR_YEAR"}
        assert sl.query.dimensions[0].column == "CALENDAR_YEAR"

    def test_textbox_static_content(self, spec):
        hdr = next(v for v in spec.pages[0].visuals if v.name == "p1hdr")
        runs = hdr.static_content["paragraphs"][0]["textRuns"]
        assert "Command Center" in runs[0]["value"]

    def test_measure_formats_propagated(self, spec):
        card = next(v for v in spec.pages[0].visuals if v.name == "p1k0")
        assert "M" in card.measure_formats["Total Cost of Care"]

    def test_decomposition_tree_substituted(self, spec):
        page2 = spec.pages[1]
        decomp = next(v for v in page2.visuals if v.visual_type == "decompositionTreeVisual")
        assert decomp.supported
        assert decomp.substituted_as == "decomposition tree (top 2 levels)"
        # limited to first 2 explain-by levels
        assert len(decomp.dim_keys) == 2

    def test_all_pages_fully_supported(self, spec):
        gaps = [
            (p.display_name, v.name, v.visual_type, v.unsupported_reason)
            for p in spec.pages
            for v in p.visuals
            if not v.supported
        ]
        assert gaps == []

    def test_presentation_options_extracted_from_metadata(self, spec):
        """legend/labels/display-units from PBIR objects surface in the spec
        at compile time (not discovered later by the vision compare)."""
        donut = next(v for v in spec.pages[0].visuals if v.name == "p1donut")
        assert donut.options.get("show_legend") is True
        assert donut.options.get("show_labels") is True
        assert donut.options.get("legend_position") == "Right"
        card = next(v for v in spec.pages[0].visuals if v.name == "p1k0")
        assert card.options.get("display_units") == 0  # Auto

    def test_presentation_check_flags_lost_format(self, spec):
        from app.binding.resolver import build_binding_map
        from app.parsers.bundle import load_pbip
        from app.runtime.engine import SemanticEngine
        from app.validation.harness import CheckStatus, ValidationHarness

        bundle = load_pbip(FIXTURE)
        engine = SemanticEngine(bundle.model, build_binding_map(bundle.model))
        validator = ValidationHarness(engine, cursor=None)

        card = next(v for v in spec.pages[0].visuals if v.name == "p1k0").model_copy(deep=True)
        ok = validator._presentation_check(card)
        assert ok is not None and ok.status == CheckStatus.PASSED

        card.measure_formats.pop("Total Cost of Care")
        bad = validator._presentation_check(card)
        assert bad is not None and bad.status == CheckStatus.FAILED
        assert "Total Cost of Care" in bad.detail
    def test_combo_roles(self, spec):
        combo = next(
            v
            for p in spec.pages
            for v in p.visuals
            if v.visual_type == "lineClusteredColumnComboChart"
        )
        assert combo.measure_roles["High Cost Claimants"] == "Y"
        assert combo.measure_roles["Average Risk Score"] == "Y2"

    def test_gauge_roles(self, spec):
        gauge = next(v for p in spec.pages for v in p.visuals if v.visual_type == "gauge")
        assert gauge.measure_roles["Value Based Penetration"] == "Y"
        assert gauge.measure_roles["Preventive Share"] == "TargetValue"

    def test_table_bare_columns_become_dims(self, spec):
        tbl = next(v for p in spec.pages for v in p.visuals if v.name == "p3tbl")
        assert "DIM_PROVIDER_TIER.PROVIDER_TIER" in tbl.dim_keys
        assert "DIM_PROVIDER_TIER.PROVIDER_COUNT" in tbl.dim_keys
        assert "Allowed Amount" in tbl.measure_keys

    def test_role_aliases_are_canonicalised(self):
        """PBIR writes 'Analyze'/'ExplainBy' in some exports; both spellings of
        each role must map to the same compiler role."""
        from app.runtime.dashboard import _canonical_role

        assert _canonical_role("ExplainBy") == "Explain By"
        assert _canonical_role("Explain By") == "Explain By"
        assert _canonical_role("Analyze") == "Analyzed"
        assert _canonical_role("Analyzed") == "Analyzed"
        # unknown roles pass through so they still surface as dropped projections
        assert _canonical_role("Sparkline") == "Sparkline"

    def test_decomposition_tree_with_alias_roles_compiles(self):
        """A decomposition tree authored with 'Analyze'/'ExplainBy' must still
        produce a query instead of being parked as 'no query fields'."""
        from app.ir.report import VisualField
        from app.runtime.dashboard import compile_dashboard

        bundle = load_pbip(FIXTURE)
        tree = next(
            v
            for p in bundle.report.pages
            for v in p.visuals
            if v.visual_type == "decompositionTreeVisual"
        )
        tree.fields = [
            VisualField(
                role="Analyze" if f.role == "Analyzed" else "ExplainBy",
                table=f.table,
                name=f.name,
                is_measure=f.is_measure,
                display_name=f.display_name,
                query_ref=f.query_ref,
                aggregate=f.aggregate,
            )
            for f in tree.fields
        ]
        s, _ = compile_dashboard(bundle)
        compiled = next(v for p in s.pages for v in p.visuals if v.name == tree.name)
        assert compiled.supported, compiled.unsupported_reason
        assert compiled.query is not None
        assert len(compiled.dim_keys) == 2
        assert compiled.measure_keys

    def test_dimension_unrelated_to_any_metric_home_forces_compat(self, spec):
        """A SEMANTIC_VIEW query joins every metric home at once, so a dimension
        unrelated to even ONE home must route to the compatibility runtime."""
        tbl = next(v for p in spec.pages for v in p.visuals if v.name == "p3tbl")
        assert tbl.options.get("semantic_force_compatibility") is True
        assert "DIM_PROVIDER_TIER" in tbl.options["semantic_force_compatibility_reason"]

    def test_tier2_measure_visual_badged(self, spec):
        # any visual using 'Measures Above Benchmark' must be parked with reason
        parked = [
            v
            for p in spec.pages
            for v in p.visuals
            if v.unsupported_reason and "Measures Above Benchmark" in v.unsupported_reason
        ]
        # the quality page uses it; if present it must be parked not broken
        for v in parked:
            assert not v.supported

    def test_measure_tiers_summary(self, spec):
        tiers = spec.measure_tiers
        assert tiers["Paid Amount"] == 1
        assert tiers["Measures Above Benchmark"] == -1
        supported = sum(1 for t in tiers.values() if t >= 0)
        assert supported >= 70
