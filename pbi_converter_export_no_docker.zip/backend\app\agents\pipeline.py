"""Conversion pipeline: Binding -> Compile -> Validate -> Repair -> Report.

A deterministic state machine with agent stages; every stage emits events to
a persisted JSON log (the live event feed in the Studio and the audit trace).
RepairAgent is bounded (max 2 rounds) and monotonic: a repair is kept only if
the overall fidelity score does not regress.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path

from app.binding.resolver import build_binding_map
from app.ir.report import ReportBundle
from app.runtime.dashboard import DashboardSpec, compile_dashboard
from app.runtime.engine import SemanticEngine
from app.validation.harness import (
    CheckStatus,
    FidelityReport,
    run_filter_probes,
    run_validation,
)

_MAX_REPAIR_ROUNDS = 3


@dataclass
class ConversionRun:
    conversion_id: str
    events: list[dict] = field(default_factory=list)
    spec: DashboardSpec | None = None
    fidelity: FidelityReport | None = None
    tier2_accepted: dict[str, str] = field(default_factory=dict)  # measure -> sql
    # Phase-8: track which stages have completed for resume-on-failure
    stages_complete: dict[str, bool] = field(default_factory=dict)
    # progressive sink: called after every emit so the Studio can stream the log live
    on_emit: object = None

    def emit(self, stage: str, message: str, **data) -> None:
        self.events.append(
            {"ts": round(time.time(), 3), "stage": stage, "message": message, **data}
        )
        if self.on_emit is not None:
            self.on_emit(self.events)  # type: ignore[operator]

    def stage_done(self, stage: str) -> bool:
        return self.stages_complete.get(stage, False)

    def mark_stage(self, stage: str) -> None:
        self.stages_complete[stage] = True


def _progress_writer(root: Path):
    """Persist the running event list so GET /convert/progress can stream it."""
    path = root / "conversion_progress.json"

    def write(events: list[dict], done: bool = False) -> None:
        path.write_text(
            json.dumps({"events": events, "done": done}, default=str), encoding="utf-8"
        )

    return write


def _persist(run: ConversionRun, root: Path) -> None:
    (root / "conversion_run.json").write_text(
        json.dumps(
            {
                "events": run.events,
                "fidelity": run.fidelity.model_dump() if run.fidelity else None,
                "summary": run.fidelity.summary() if run.fidelity else None,
                "tier2_accepted": run.tier2_accepted,
                # Phase-8: stage completion map for resume support
                "stages_complete": run.stages_complete,
            },
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )


def _load_existing_run(root: Path) -> dict:
    """Load a persisted conversion_run.json if it exists."""
    path = root / "conversion_run.json"
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _compile_with_overrides(
    bundle: ReportBundle, storage_root: Path, tier2_sql: dict[str, str]
):
    """Compile and apply persisted spec overrides — the pipeline must validate
    the same spec the dashboard will serve (repairs land as overrides)."""
    from app.services.overrides import apply_overrides, load_overrides

    spec, binding_map = compile_dashboard(bundle, tier2_sql=tier2_sql)
    overrides = load_overrides(storage_root)
    if overrides:
        spec.warnings.extend(apply_overrides(spec, overrides))
    return spec, binding_map


def run_conversion(
    bundle: ReportBundle,
    conversion_id: str,
    storage_root: Path,
    cursor_factory,
    llm_client=None,
    resume: bool = False,
    migrator=None,
) -> ConversionRun:
    """`migrator`: optional callable(binding_map, bundle, emit) -> dict summary.
    Runs when the report is bound to a foreign source database; lifts base
    tables into Snowflake and repoints the bundle so binding resolves natively."""
    progress = _progress_writer(storage_root)
    run = ConversionRun(conversion_id=conversion_id, on_emit=progress)

    # Phase-8: load prior run for resume support
    if resume:
        prior = _load_existing_run(storage_root)
        if prior:
            run.events = prior.get("events", [])
            run.tier2_accepted = prior.get("tier2_accepted", {})
            run.stages_complete = prior.get("stages_complete", {})
            run.emit("pipeline", "resuming from prior run state")
        else:
            run.emit("pipeline", "no prior run found, starting fresh")

    # ---- Discovery (binding) ----
    run.emit("binding", "matching report tables to your Snowflake warehouse")
    binding_map = build_binding_map(bundle.model)

    # ---- Source migration (foreign database -> Snowflake) ----
    to_migrate = binding_map.needs_migration
    if to_migrate:
        sources = sorted({b.source_kind or "?" for b in to_migrate})
        if migrator is None:
            run.emit(
                "migration",
                f"{len(to_migrate)} tables live in a {'/'.join(sources)} source database "
                "but no source connection was provided — they cannot be resolved",
                tables=[b.table for b in to_migrate],
            )
        else:
            run.emit(
                "migration",
                f"migrating {len(to_migrate)} base tables from {'/'.join(sources)} "
                "into Snowflake (schema + data + verification)",
                tables=[b.table for b in to_migrate],
            )
            summary = migrator(
                binding_map,
                bundle,
                lambda table, msg: run.emit("migration", f"{table}: {msg}"),
            )
            run.emit(
                "migration",
                (
                    "source migration complete — all tables verified and rebound to Snowflake"
                    if summary.get("ok")
                    else "source migration finished with errors"
                ),
                **summary,
            )
            # rebuild bindings from the rewritten bundle: everything now Snowflake
            binding_map = build_binding_map(bundle.model)
        run.mark_stage("migration")
        _persist(run, storage_root)

    resolved = sum(1 for b in binding_map.bindings.values() if b.status == "resolved")
    virtual = sum(1 for b in binding_map.bindings.values() if b.status == "virtual")
    materialization_required = sum(
        1 for b in binding_map.bindings.values() if b.status == "materialization_required"
    )
    materialization_by_strategy = {
        strategy: sum(
            1
            for b in binding_map.bindings.values()
            if b.status == "materialization_required" and b.materialization_strategy == strategy
        )
        for strategy in sorted(
            {
                b.materialization_strategy
                for b in binding_map.bindings.values()
                if b.status == "materialization_required" and b.materialization_strategy
            }
        )
    }
    unresolved = [b.table for b in binding_map.unresolved]
    still_foreign = [b.table for b in binding_map.needs_migration]
    run.emit(
        "binding",
        f"{resolved} tables matched, {virtual} calculated in-model, "
        f"{materialization_required} need staging, {len(unresolved)} not found"
        + (f", {len(still_foreign)} awaiting source migration" if still_foreign else ""),
        unresolved=unresolved,
        needs_migration=still_foreign,
        materialization_required=[b.table for b in binding_map.materialization_required],
        materialization_by_strategy=materialization_by_strategy,
        warnings=binding_map.warnings,
    )
    run.mark_stage("binding")
    _persist(run, storage_root)

    # ---- Translation (compile) ----
    run.emit("compile", "translating measures and visuals into the new dashboard")
    spec, binding_map = _compile_with_overrides(bundle, storage_root, run.tier2_accepted)
    run.spec = spec
    parked = [m for m, t in spec.measure_tiers.items() if t < 0]
    run.emit(
        "compile",
        f"{sum(1 for t in spec.measure_tiers.values() if t >= 0)}/{len(spec.measure_tiers)} "
        f"measures translated automatically; {len(parked)} need assistance",
        parked=parked,
    )
    for page in spec.pages:
        unsupported = [v.name for v in page.visuals if not v.supported]
        substituted = [v.name for v in page.visuals if v.substituted_as]
        run.emit(
            "compile",
            f"page '{page.display_name}': {len(page.visuals)} visuals, "
            f"{len(unsupported)} unsupported, {len(substituted)} substituted",
        )
    run.mark_stage("compile")
    _persist(run, storage_root)

    engine = SemanticEngine(bundle.model, binding_map)

    # ---- ValidationAgent ----
    cursor = cursor_factory()
    try:
        run.emit("validate", "checking every visual's numbers against Snowflake")
        fidelity = run_validation(
            spec,
            engine,
            cursor,
            on_page=lambda ps: run.emit(
                "validate",
                f"page '{ps.display_name}': {len(ps.visuals)} visuals checked, "
                f"score {ps.score:.2%}",
            ),
            bundle=bundle,
        )
        run.fidelity = fidelity
        run.emit("validate", "fidelity computed", summary=fidelity.summary())
        run.mark_stage("validate")
        _persist(run, storage_root)

        # ---- RepairAgent (bounded, monotonic) ----
        from app.agents.presentation_repair import presentation_gaps, propose_overrides
        from app.services.overrides import add_override, validate_override

        for round_no in range(1, _MAX_REPAIR_ROUNDS + 1):
            failures = [
                v
                for p in fidelity.pages
                for v in p.visuals
                if v.status == CheckStatus.FAILED
            ]
            tier2_candidates = [m for m in parked if m not in run.tier2_accepted]
            gaps = presentation_gaps(bundle, spec)
            if not failures and not tier2_candidates and not gaps:
                break
            run.emit(
                "repair",
                f"round {round_no}: {len(failures)} visuals need attention, "
                f"{len(tier2_candidates)} measures need AI translation, "
                f"{len(gaps)} presentation gaps detected",
            )
            progressed = False

            # deterministic presentation repair: re-read declared PBIR intent
            # and patch the spec through the whitelisted override vocabulary
            proposals = propose_overrides(gaps)
            applied = 0
            for proposal in proposals:
                err = validate_override(spec, proposal)
                if err:
                    run.emit(
                        "repair",
                        f"presentation fix skipped ({proposal['op']}@{proposal['visual']}): {err}",
                    )
                    continue
                finding = (
                    f"presentation:{proposal['page']}:{proposal['visual']}:"
                    f"{proposal.get('key') or proposal.get('measure')}"
                )
                add_override(storage_root, proposal, finding_id=finding)
                applied += 1
            if applied:
                run.emit(
                    "repair",
                    f"round {round_no}: applied {applied} declared-presentation "
                    "repairs (legend/labels/units/containers/formats from the PBIR source)",
                )
                progressed = True

            if llm_client is not None and tier2_candidates:
                from app.agents.tier2 import propose_and_validate

                for m in tier2_candidates:
                    run.emit(
                        "repair",
                        f"[{m}]: complex formula — asking AI for a Snowflake "
                        "translation (checked against real data before acceptance)",
                    )
                    result = propose_and_validate(
                        bundle.model, binding_map, m, cursor, client=llm_client
                    )
                    run.emit(
                        "repair",
                        f"[{m}]: AI translation {'accepted' if result.accepted else 'rejected'} "
                        f"after {result.attempts} attempt(s)",
                        trace=result.trace,
                    )
                    if result.accepted and result.sql:
                        run.tier2_accepted[m] = result.sql
                        progressed = True

            if not progressed:
                run.emit("repair", f"round {round_no}: no further automatic fix available")
                break

            # recompile with accepted tier-2 SQL and repair overrides applied
            spec, binding_map = _compile_with_overrides(
                bundle, storage_root, run.tier2_accepted
            )
            engine = SemanticEngine(bundle.model, binding_map, tier2_sql=run.tier2_accepted)
            candidate = run_validation(spec, engine, cursor, bundle=bundle)
            if candidate.score >= fidelity.score:
                fidelity = candidate
                run.fidelity = candidate
                run.spec = spec
                run.emit("repair", f"round {round_no}: accepted (score {candidate.score:.4f})")
                _persist(run, storage_root)
            else:
                run.emit(
                    "repair",
                    f"round {round_no}: REJECTED - score regressed "
                    f"{fidelity.score:.4f} -> {candidate.score:.4f}",
                )
                break
    finally:
        try:
            cursor.connection.close()
        except Exception:  # noqa: S110 - best-effort close
            pass

    # ---- Filter Testing (probe): prove filters propagate correctly ----
    cursor2 = cursor_factory()
    try:
        run.emit("probe", "testing that slicers and filters change the numbers correctly")
        probes = run_filter_probes(
            run.spec or spec,
            SemanticEngine(bundle.model, binding_map, tier2_sql=run.tier2_accepted),
            cursor2,
            on_probe=lambda p: run.emit(
                "probe",
                " · ".join(
                    [
                        p.display_name,
                        " & ".join(f"{f['column']}={f['value']}" for f in p.filters),
                        f"[{p.measure}]: "
                        + {
                            CheckStatus.PASSED: "✓ reconciled",
                            CheckStatus.SKIPPED: f"⊘ skipped — {p.detail}",
                        }.get(p.status, f"✗ {p.detail}"),
                    ]
                ),
            ),
        )
        if run.fidelity is not None:
            run.fidelity.filter_probes = probes
        tested = [p for p in probes if p.status != CheckStatus.SKIPPED]
        passed = sum(1 for p in tested if p.status == CheckStatus.PASSED)
        skipped = len(probes) - len(tested)
        run.emit(
            "probe",
            f"filter checks: {passed}/{len(tested)} combinations verified"
            + (f" ({skipped} skipped: unrelated fields)" if skipped else ""),
        )
        run.mark_stage("probe")
        _persist(run, storage_root)
    finally:
        try:
            cursor2.connection.close()
        except Exception:  # noqa: S110 - best-effort close
            pass

    # ---- Summary (report) ----
    s = run.fidelity.summary() if run.fidelity else {}
    run.emit(
        "report",
        f"conversion complete: score {s.get('overall_score', 0):.2%}, "
        f"{s.get('visuals_passed', 0)}/{s.get('visuals_total', 0)} visuals passing, "
        f"{s.get('substituted', 0)} closest-match substitutions, "
        f"{s.get('measures_parked', 0)} measures awaiting review",
    )
    run.mark_stage("report")
    _persist(run, storage_root)
    progress(run.events, done=True)
    return run
