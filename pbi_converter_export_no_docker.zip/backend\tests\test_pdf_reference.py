"""PDF reference service: rasterize + ordinal mapping (offline, Pillow-authored PDFs)."""

import io

import pytest

from app.services.pdf_reference import (
    PdfReferenceError,
    map_pages_to_report,
    rasterize_pdf,
)


def make_pdf(n_pages: int, size=(640, 360)) -> bytes:
    from PIL import Image

    # distinct fill per page so rasterized outputs are distinguishable
    pages = [Image.new("RGB", size, (40 * (i + 1) % 255, 90, 130)) for i in range(n_pages)]
    buf = io.BytesIO()
    pages[0].save(buf, format="PDF", save_all=True, append_images=pages[1:])
    return buf.getvalue()


REPORT_PAGES = [
    {"name": "01-exec", "display_name": "1. Exec", "ordinal": 0},
    {"name": "02-cost", "display_name": "2. Cost", "ordinal": 1},
    {"name": "03-network", "display_name": "3. Network", "ordinal": 2},
]


class TestRasterize:
    def test_pages_rendered_in_order(self):
        images = rasterize_pdf(make_pdf(3))
        assert [i.index for i in images] == [0, 1, 2]
        assert all(i.png.startswith(b"\x89PNG") for i in images)
        # scaled to the vision-friendly width
        assert all(i.width == 1920 for i in images)
        # pages with different fills must produce different bytes
        assert images[0].png != images[1].png

    def test_rejects_non_pdf(self):
        with pytest.raises(PdfReferenceError, match="not a readable PDF"):
            rasterize_pdf(b"definitely not a pdf")

    def test_rejects_empty(self):
        with pytest.raises(PdfReferenceError):
            rasterize_pdf(b"")


class TestMapping:
    def test_exact_match_by_ordinal(self):
        images = rasterize_pdf(make_pdf(3))
        mapping, warnings = map_pages_to_report(images, REPORT_PAGES)
        assert list(mapping) == ["01-exec", "02-cost", "03-network"]
        assert warnings == []
        assert mapping["02-cost"].index == 1

    def test_count_mismatch_warns_and_maps_overlap(self):
        images = rasterize_pdf(make_pdf(2))
        mapping, warnings = map_pages_to_report(images, REPORT_PAGES)
        assert list(mapping) == ["01-exec", "02-cost"]
        assert len(warnings) == 1
        assert "2 pages but the report has 3" in warnings[0]

    def test_unsorted_report_pages_sorted_by_ordinal(self):
        images = rasterize_pdf(make_pdf(3))
        shuffled = [REPORT_PAGES[2], REPORT_PAGES[0], REPORT_PAGES[1]]
        mapping, _ = map_pages_to_report(images, shuffled)
        assert mapping["01-exec"].index == 0
        assert mapping["03-network"].index == 2
