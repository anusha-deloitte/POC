#!/usr/bin/env bash
# Full E2E: convert the SQL-Server-bound report with source+target connections.
# The pipeline migrates ClaimsDW tables into Snowflake CLAIMSDW_MIGRATED, then
# binds/compiles/validates against the migrated copies.
set -euo pipefail

CID=$(cat /tmp/democid.txt)
SRC=$(cat /tmp/srcid.txt)
TGT=$(cat /tmp/tgtid.txt)
TOKEN=$(curl -s -X POST localhost:8010/api/auth/login -H 'Content-Type: application/json' \
  -d "{\"email\":\"${PBIC_QA_EMAIL:?set PBIC_QA_EMAIL}\",\"password\":\"${PBIC_QA_PASSWORD:?set PBIC_QA_PASSWORD}\"}" | python3 -c "import sys,json;print(json.load(sys.stdin)['token'])")

echo "conversion=$CID source=$SRC target=$TGT"
curl -s -X POST "localhost:8010/api/v1/conversions/$CID/dashboard/convert" \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d "{\"connection_id\":\"$TGT\",\"source_connection_id\":\"$SRC\",\"use_llm\":true,\"policy_mode\":\"advisory\"}" \
  -o /tmp/convert_result.json -w "HTTP %{http_code} in %{time_total}s\n"

python3 - <<'EOF'
import json
d = json.load(open('/tmp/convert_result.json'))
migration_events = [e for e in d.get('events', []) if e.get('stage') == 'migration']
print(f"\n=== MIGRATION EVENTS ({len(migration_events)}) ===")
for e in migration_events[:6] + (['...'] if len(migration_events) > 12 else []) + migration_events[-6:]:
    print(' ', e if isinstance(e, str) else e.get('message'))
s = d.get('summary') or {}
print("\n=== FIDELITY ===")
print(json.dumps(s, indent=1)[:400])
EOF
