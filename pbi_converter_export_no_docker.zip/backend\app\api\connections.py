from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException

from app.api.deps import get_connection_store, require_token
from app.services.connections import (
    ConnectionStore,
    ConnectionValidationError,
    SnowflakeProfile,
    SnowflakeProfileIn,
)

router = APIRouter(
    prefix="/api/v1/connections", tags=["connections"], dependencies=[Depends(require_token)]
)

# data-source catalogue for the connect wizard; snowflake is implemented,
# the rest are roadmap surfaces shown for scoping conversations
SOURCE_TYPES = [
    {"id": "snowflake", "label": "Snowflake", "available": True},
    {"id": "databricks", "label": "Databricks SQL", "available": False},
    {"id": "bigquery", "label": "Google BigQuery", "available": False},
    {"id": "synapse", "label": "Azure Synapse", "available": False},
    {"id": "redshift", "label": "Amazon Redshift", "available": False},
    {"id": "postgres", "label": "PostgreSQL", "available": False},
    {"id": "sqlserver", "label": "SQL Server", "available": False},
]


@router.get("/source-types")
def source_types() -> list[dict]:
    return SOURCE_TYPES


@router.post("", status_code=201, response_model=SnowflakeProfile)
def create_connection(
    spec: SnowflakeProfileIn,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> SnowflakeProfile:
    try:
        return store.create(spec)
    except ConnectionValidationError as e:
        raise HTTPException(422, str(e)) from e


@router.get("", response_model=list[SnowflakeProfile])
def list_connections(
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> list[SnowflakeProfile]:
    return store.list()


@router.get("/{profile_id}", response_model=SnowflakeProfile)
def get_connection(
    profile_id: str,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> SnowflakeProfile:
    try:
        return store.get(profile_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e


@router.delete("/{profile_id}", status_code=204)
def delete_connection(
    profile_id: str,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> None:
    try:
        store.delete(profile_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e


@router.post("/{profile_id}/test")
def test_connection_endpoint(
    profile_id: str,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> dict:
    try:
        store.get(profile_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e
    try:
        kwargs = store.connector_kwargs(profile_id, query_tag="pbic:connection-test")
    except ValueError as e:
        raise HTTPException(422, f"invalid connection configuration: {e}") from e
    try:
        from app.services.connections import test_connection

        return test_connection(kwargs)
    except ModuleNotFoundError as e:
        raise HTTPException(
            501, "snowflake-connector-python not installed (install extra: snowflake)"
        ) from e
    except Exception as e:  # connector raises many exception types
        return {"ok": False, "error": str(e)}
