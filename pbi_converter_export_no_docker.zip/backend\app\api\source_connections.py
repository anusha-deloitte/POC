"""Source-database connection API (the system the PBI report reads today)."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException

from app.api.deps import get_source_connection_store, require_token
from app.services.source_connections import (
    SourceConnectionError,
    SourceConnectionStore,
    SourceProfile,
    SourceProfileIn,
    test_source_connection,
)

router = APIRouter(
    prefix="/api/v1/source-connections",
    tags=["source-connections"],
    dependencies=[Depends(require_token)],
)

_KIND_LABELS = {
    "sqlserver": "SQL Server",
    "postgres": "PostgreSQL",
    "mysql": "MySQL",
    "oracle": "Oracle",
}


@router.get("/kinds")
def source_kinds() -> list[dict]:
    from app.services.source_connections import SourceKind, driver_available

    return [
        {"id": k.value, "label": _KIND_LABELS[k.value], "available": driver_available(k)}
        for k in (SourceKind.SQLSERVER, SourceKind.POSTGRES, SourceKind.MYSQL, SourceKind.ORACLE)
    ]


@router.post("", status_code=201, response_model=SourceProfile)
def create_source_connection(
    spec: SourceProfileIn,
    store: Annotated[SourceConnectionStore, Depends(get_source_connection_store)],
) -> SourceProfile:
    return store.create(spec)


@router.get("", response_model=list[SourceProfile])
def list_source_connections(
    store: Annotated[SourceConnectionStore, Depends(get_source_connection_store)],
) -> list[SourceProfile]:
    return store.list()


@router.delete("/{profile_id}", status_code=204)
def delete_source_connection(
    profile_id: str,
    store: Annotated[SourceConnectionStore, Depends(get_source_connection_store)],
) -> None:
    try:
        store.delete(profile_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "source connection not found") from e


@router.post("/{profile_id}/test")
def test_source(
    profile_id: str,
    store: Annotated[SourceConnectionStore, Depends(get_source_connection_store)],
) -> dict:
    try:
        return test_source_connection(store, profile_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "source connection not found") from e
    except SourceConnectionError as e:
        raise HTTPException(501, str(e)) from e
    except Exception as e:  # noqa: BLE001 - driver errors surface as 400
        raise HTTPException(400, f"connection failed: {e}") from e
