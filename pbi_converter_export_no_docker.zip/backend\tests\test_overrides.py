"""Whitelisted spec-override service (remediation engine)."""

from pathlib import Path

import pytest

from app.parsers.bundle import load_pbip
from app.runtime.dashboard import compile_dashboard
from app.services.overrides import (
    add_override,
    apply_overrides,
    load_overrides,
    validate_override,
)

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


@pytest.fixture()
def spec():
    bundle = load_pbip(FIXTURE)
    s, _ = compile_dashboard(bundle)
    return s


PAGE = "03-provider-network"
CHART = "p3ctr"  # Spend by Network Status and Tier (clusteredColumnChart)


class TestValidate:
    def test_unknown_op_rejected(self, spec):
        err = validate_override(spec, {"op": "drop_table", "page": PAGE, "visual": CHART})
        assert err and "not in the automatable vocabulary" in err

    def test_unknown_visual_rejected(self, spec):
        err = validate_override(
            spec, {"op": "set_title", "page": PAGE, "visual": "nope", "value": "x"}
        )
        assert err and "unknown visual" in err

    def test_missing_params_rejected(self, spec):
        err = validate_override(spec, {"op": "set_title", "page": PAGE, "visual": CHART})
        assert err and "missing params" in err

    def test_type_switch_only_within_chart_family(self, spec):
        ok = validate_override(
            spec,
            {"op": "set_visual_type", "page": PAGE, "visual": CHART, "value": "barChart"},
        )
        assert ok is None
        bad = validate_override(
            spec,
            {"op": "set_visual_type", "page": PAGE, "visual": CHART, "value": "pivotTable"},
        )
        assert bad and "not a chart-family type" in bad

    def test_drop_only_measure_rejected(self, spec):
        err = validate_override(
            spec,
            {"op": "drop_measure", "page": PAGE, "visual": CHART, "measure": "Allowed Amount"},
        )
        assert err and "only measure" in err

    def test_foreign_measure_rejected(self, spec):
        err = validate_override(
            spec,
            {"op": "set_measure_format", "page": PAGE, "visual": CHART,
             "measure": "Not A Measure", "value": "0.0%"},
        )
        assert err and "not on this visual" in err


class TestApply:
    def _get(self, spec, name=CHART, page=PAGE):
        p = next(p for p in spec.pages if p.name == page)
        return next(v for v in p.visuals if v.name == name)

    def test_set_title_and_type(self, spec):
        warnings = apply_overrides(
            spec,
            [
                {"op": "set_title", "page": PAGE, "visual": CHART, "value": "Spend by Tier"},
                {"op": "set_visual_type", "page": PAGE, "visual": CHART, "value": "barChart"},
            ],
        )
        assert warnings == []
        vs = self._get(spec)
        assert vs.title == "Spend by Tier"
        assert vs.visual_type == "barChart"

    def test_move_resize_partial(self, spec):
        apply_overrides(spec, [{"op": "move_resize", "page": PAGE, "visual": CHART, "x": 10}])
        assert self._get(spec).x == 10.0

    def test_swap_series_role(self, spec):
        vs = self._get(spec)
        target = vs.dim_keys[0]
        apply_overrides(
            spec, [{"op": "swap_series_role", "page": PAGE, "visual": CHART, "column": target}]
        )
        assert self._get(spec).series_keys == [target]

    def test_drop_dimension_updates_query(self, spec):
        vs = self._get(spec)
        col = vs.series_keys[0]
        apply_overrides(
            spec, [{"op": "drop_dimension", "page": PAGE, "visual": CHART, "column": col}]
        )
        vs = self._get(spec)
        assert col not in vs.dim_keys
        assert col not in vs.series_keys
        assert all(f"{d.table}.{d.column}" != col for d in vs.query.dimensions)

    def test_invalid_override_becomes_warning(self, spec):
        warnings = apply_overrides(
            spec, [{"op": "set_title", "page": PAGE, "visual": "ghost", "value": "x"}]
        )
        assert len(warnings) == 1 and "unknown visual" in warnings[0]

    def test_hide_visual(self, spec):
        apply_overrides(spec, [{"op": "hide_visual", "page": PAGE, "visual": CHART}])
        vs = self._get(spec)
        assert vs.supported is False
        assert "remediation" in (vs.unsupported_reason or "")


class TestPersistence:
    def test_add_replaces_same_finding(self, tmp_path):
        add_override(
            tmp_path,
            {"op": "set_title", "page": PAGE, "visual": CHART, "value": "A"},
            finding_id="f1",
        )
        overrides = add_override(
            tmp_path,
            {"op": "set_title", "page": PAGE, "visual": CHART, "value": "B"},
            finding_id="f1",
        )
        assert len(overrides) == 1
        assert overrides[0]["value"] == "B"
        assert load_overrides(tmp_path)[0]["finding_id"] == "f1"

    def test_manual_overrides_accumulate(self, tmp_path):
        add_override(tmp_path, {"op": "set_title", "page": PAGE, "visual": CHART, "value": "A"})
        overrides = add_override(
            tmp_path, {"op": "set_limit", "page": PAGE, "visual": CHART, "value": 10}
        )
        assert len(overrides) == 2


class TestSetOption:
    def test_waterfall_total_toggle(self, spec):
        from app.services.overrides import apply_overrides, validate_override

        wf_page = next(p for p in spec.pages for v in p.visuals if v.visual_type == "waterfallChart")
        wf = next(v for v in wf_page.visuals if v.visual_type == "waterfallChart")
        o = {"op": "set_option", "page": wf_page.name, "visual": wf.name,
             "key": "waterfall_total", "value": False}
        assert validate_override(spec, o) is None
        apply_overrides(spec, [o])
        # options may also carry compile-time presentation metadata
        assert wf.options["waterfall_total"] is False

    def test_unknown_option_key_rejected(self, spec):
        from app.services.overrides import validate_override

        err = validate_override(
            spec, {"op": "set_option", "page": PAGE, "visual": CHART,
                   "key": "sparkles", "value": True},
        )
        assert err and "not in" in err

    def test_non_bool_value_rejected(self, spec):
        from app.services.overrides import validate_override

        err = validate_override(
            spec, {"op": "set_option", "page": PAGE, "visual": CHART,
                   "key": "show_legend", "value": "yes"},
        )
        assert err and "boolean" in err


def test_move_resize_rejects_degenerate_geometry(spec_fixture=None):
    """Vision models sometimes emit all-zero geometry; applying it would
    destroy the visual, so validation must reject it."""
    from pathlib import Path

    from app.parsers.bundle import load_pbip
    from app.runtime.dashboard import compile_dashboard
    from app.services.overrides import validate_override

    fixture = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_care_analytics"
    spec, _ = compile_dashboard(load_pbip(fixture))
    page = spec.pages[1].name
    base = {"op": "move_resize", "page": page, "visual": "p2bar"}
    assert validate_override(spec, {**base, "x": 0, "y": 0, "width": 0, "height": 0}) is not None
    assert validate_override(spec, {**base, "width": 4}) is not None
    assert validate_override(spec, {**base, "x": -5}) is not None
    assert validate_override(spec, {**base, "x": 20, "width": 300}) is None
