import { describe, expect, it } from 'vitest'
import { niceCeil, niceCeilBar } from '../dashboard/visuals/ChartVisual'

describe('PBI-style axis bounds (validated against PDF reference maxima)', () => {
  it('line/area axes extend to the next nice tick', () => {
    expect(niceCeil(2870)).toBe(3000) // PMPM trend -> $3,000
    expect(niceCeil(82000)).toBe(100000) // membership -> 100K
    expect(niceCeil(3800)).toBe(4000) // high-cost claimants -> 4,000
    expect(niceCeil(8900000000)).toBe(10000000000) // premium -> $10bn
  })

  it('bar axes keep the last full tick when overflow is small', () => {
    expect(niceCeilBar(10300000000)).toBe(10000000000) // spend by tier -> $10.0bn
  })
})
