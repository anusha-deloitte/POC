"""Source-database connection profiles (the system the PBI report reads today).

Separate from the Snowflake (target) store on purpose: source connections are
read-only ingest credentials used exclusively by the migration mover, while
Snowflake profiles power the serving plane. Secrets are Fernet-encrypted with
the same key file.

postgres is fully implemented (psycopg); sqlserver is registered and parses,
requiring the optional pyodbc driver at runtime.
"""

from __future__ import annotations

import json
import uuid
from enum import StrEnum
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet
from pydantic import BaseModel, SecretStr


class SourceKind(StrEnum):
    POSTGRES = "postgres"
    SQLSERVER = "sqlserver"
    MYSQL = "mysql"
    ORACLE = "oracle"


_DRIVER_MODULES: dict[SourceKind, str] = {
    SourceKind.POSTGRES: "psycopg",
    SourceKind.SQLSERVER: "pyodbc",
    SourceKind.MYSQL: "pymysql",
    SourceKind.ORACLE: "oracledb",
}


def driver_available(kind: SourceKind) -> bool:
    import importlib.util

    return importlib.util.find_spec(_DRIVER_MODULES[kind]) is not None


class SourceProfileIn(BaseModel):
    name: str
    kind: SourceKind
    host: str
    port: int | None = None
    database: str
    user: str
    password: SecretStr


class SourceProfile(BaseModel):
    """Public shape — no secret material."""

    id: str
    name: str
    kind: SourceKind
    host: str
    port: int | None = None
    database: str
    user: str


class SourceConnectionError(Exception):
    pass


class SourceConnectionStore:
    def __init__(self, storage_dir: Path, key_file: Path):
        self.dir = storage_dir / "source_connections"
        self.dir.mkdir(parents=True, exist_ok=True)
        key_file.parent.mkdir(parents=True, exist_ok=True)
        if not key_file.exists():
            key_file.write_bytes(Fernet.generate_key())
            key_file.chmod(0o600)
        self._fernet = Fernet(key_file.read_bytes())

    def create(self, spec: SourceProfileIn) -> SourceProfile:
        profile_id = str(uuid.uuid4())
        profile = SourceProfile(
            id=profile_id,
            name=spec.name,
            kind=spec.kind,
            host=spec.host,
            port=spec.port,
            database=spec.database,
            user=spec.user,
        )
        record = {
            "profile": profile.model_dump(),
            "secrets_enc": self._fernet.encrypt(
                json.dumps({"password": spec.password.get_secret_value()}).encode()
            ).decode(),
        }
        (self.dir / f"{profile_id}.json").write_text(json.dumps(record), encoding="utf-8")
        return profile

    def get(self, profile_id: str) -> SourceProfile:
        return SourceProfile.model_validate(self._record(profile_id)["profile"])

    def list(self) -> list[SourceProfile]:
        out = []
        for f in sorted(self.dir.glob("*.json")):
            out.append(SourceProfile.model_validate(json.loads(f.read_text())["profile"]))
        return out

    def delete(self, profile_id: str) -> None:
        path = self.dir / f"{uuid.UUID(profile_id)}.json"
        if not path.is_file():
            raise KeyError(profile_id)
        path.unlink()

    def _record(self, profile_id: str) -> dict:
        path = self.dir / f"{uuid.UUID(profile_id)}.json"
        if not path.is_file():
            raise KeyError(profile_id)
        return json.loads(path.read_text(encoding="utf-8"))

    def password(self, profile_id: str) -> str:
        rec = self._record(profile_id)
        return json.loads(self._fernet.decrypt(rec["secrets_enc"].encode()))["password"]

    def connect(self, profile_id: str) -> Any:
        """Open a DB-API connection to the source database."""
        p = self.get(profile_id)
        pw = self.password(profile_id)
        if not driver_available(p.kind):
            raise SourceConnectionError(
                f"driver for {p.kind} not installed "
                f"(python module {_DRIVER_MODULES[p.kind]!r} missing)"
            )
        if p.kind == SourceKind.POSTGRES:
            import psycopg

            return psycopg.connect(
                host=p.host,
                port=p.port or 5432,
                dbname=p.database,
                user=p.user,
                password=pw,
                connect_timeout=10,
            )
        if p.kind == SourceKind.SQLSERVER:
            import pyodbc  # type: ignore[import-not-found]

            return pyodbc.connect(
                "DRIVER={ODBC Driver 18 for SQL Server};"
                f"SERVER={p.host},{p.port or 1433};DATABASE={p.database};"
                f"UID={p.user};PWD={pw};TrustServerCertificate=yes;",
                timeout=10,
            )
        if p.kind == SourceKind.MYSQL:
            import pymysql  # type: ignore[import-not-found]

            return pymysql.connect(
                host=p.host,
                port=p.port or 3306,
                database=p.database,
                user=p.user,
                password=pw,
                connect_timeout=10,
            )
        if p.kind == SourceKind.ORACLE:
            import oracledb  # type: ignore[import-not-found]

            return oracledb.connect(
                user=p.user,
                password=pw,
                dsn=f"{p.host}:{p.port or 1521}/{p.database}",
            )
        raise SourceConnectionError(f"unsupported source kind: {p.kind}")


def test_source_connection(store: SourceConnectionStore, profile_id: str) -> dict:
    conn = store.connect(profile_id)
    try:
        cur = conn.cursor()
        cur.execute("SELECT 1")
        cur.fetchone()
        return {"ok": True}
    finally:
        conn.close()
