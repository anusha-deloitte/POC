"""Bind PBI-IR model tables to physical Snowflake objects.

Produces a BindingMap consumed by the SQL emitter; anything unresolved is
reported (never guessed) so the UI can escalate to a human.
"""

from __future__ import annotations

import re

from pydantic import BaseModel, Field

from app.binding.m_parser import parse_m_binding
from app.ir.model import SemanticModel

_IDENT_OK = re.compile(r"^[A-Za-z0-9_$. -]+$")


def safe_ident(name: str) -> str:
    """Identifiers can't be bind-parameterized; whitelist their charset instead."""
    if not _IDENT_OK.match(name) or '"' in name:
        raise ValueError(f"unsafe SQL identifier: {name!r}")
    return name


class TableBinding(BaseModel):
    table: str
    database: str | None = None
    schema_name: str | None = None
    object_name: str | None = None
    object_kind: str | None = None
    native_query: str | None = None
    transform_steps: list[str] = Field(default_factory=list)
    # M query SelectRows predicates → WHERE clause injected at query time
    where_clause: str | None = None
    # M query RenameColumns → source column name → display name
    column_aliases: dict[str, str] = Field(default_factory=dict)
    # calculated / measure-only tables have no physical source
    is_virtual: bool = False
    # resolved | virtual | materialization_required | unresolved | needs_migration
    status: str = "resolved"
    materialization_strategy: str | None = None  # view | dynamic_table | table | None
    materialization_sql: str | None = None
    detail: str | None = None
    # foreign (non-Snowflake) source coordinates — filled when status=needs_migration
    source_kind: str | None = None  # sqlserver | postgres
    source_schema: str | None = None
    source_object: str | None = None

    @property
    def qualified_name(self) -> str | None:
        if not self.object_name:
            return None
        parts = [p for p in (self.database, self.schema_name, self.object_name) if p]
        return ".".join(f'"{safe_ident(p)}"' for p in parts)


class BindingMap(BaseModel):
    bindings: dict[str, TableBinding] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)

    def get(self, table: str) -> TableBinding | None:
        return self.bindings.get(table)

    @property
    def unresolved(self) -> list[TableBinding]:
        return [b for b in self.bindings.values() if b.status == "unresolved"]

    @property
    def materialization_required(self) -> list[TableBinding]:
        return [b for b in self.bindings.values() if b.status == "materialization_required"]

    @property
    def needs_migration(self) -> list[TableBinding]:
        return [b for b in self.bindings.values() if b.status == "needs_migration"]


def build_binding_map(model: SemanticModel) -> BindingMap:
    out = BindingMap()
    query_time_transform_steps = {"Table.SelectRows", "Table.RenameColumns"}
    materialization_required_steps = {"Table.Group"}

    def _qident(value: str) -> str:
        return '"' + value.replace('"', '""') + '"'

    def _materialization_sql(binding: TableBinding, mb) -> str | None:
        if not (binding.qualified_name and mb.group_by_columns and mb.group_aggregations):
            return None
        select_parts = [
            f"{_qident(col)}" for col in mb.group_by_columns
        ]
        for out_name, agg_kind, src_col in mb.group_aggregations:
            src = _qident(src_col)
            if agg_kind == "count_distinct":
                expr = f"COUNT(DISTINCT {src})"
            elif agg_kind == "count":
                expr = f"COUNT({src})"
            else:
                expr = f"MIN({src})"
            select_parts.append(f"{expr} AS {_qident(out_name)}")
        group_by = ", ".join(_qident(col) for col in mb.group_by_columns)
        return (
            "SELECT "
            + ", ".join(select_parts)
            + f"\nFROM {binding.qualified_name}\nGROUP BY {group_by}"
        )
    for table in model.tables:
        if table.is_auto_date_table:
            out.bindings[table.name] = TableBinding(
                table=table.name, is_virtual=True, status="virtual", detail="auto date table"
            )
            continue
        if not table.partitions:
            # measure-table pattern (_Measures) or calculated table
            out.bindings[table.name] = TableBinding(
                table=table.name,
                is_virtual=True,
                status="virtual",
                detail="no partition (measure table or calculated)",
            )
            continue
        part = table.partitions[0]
        if part.source_type == "calculated":
            # measure-table pattern: `_Measures = Row("Placeholder", BLANK())`
            out.bindings[table.name] = TableBinding(
                table=table.name,
                is_virtual=True,
                status="virtual",
                detail="calculated table",
            )
            continue
        if part.source_type != "m":
            out.bindings[table.name] = TableBinding(
                table=table.name,
                status="unresolved",
                detail=f"unsupported partition type: {part.source_type}",
            )
            continue
        mb = parse_m_binding(part.expression, model.expressions)
        if mb.native_query:
            out.bindings[table.name] = TableBinding(
                table=table.name, native_query=mb.native_query, status="resolved"
            )
        elif mb.is_resolved:
            where_clause = " AND ".join(mb.where_predicates) if mb.where_predicates else None
            out.bindings[table.name] = TableBinding(
                table=table.name,
                database=mb.database,
                schema_name=mb.schema,
                object_name=mb.object_name,
                object_kind=mb.object_kind,
                transform_steps=mb.transform_steps,
                where_clause=where_clause,
                column_aliases=dict(mb.column_renames),
            )
            if mb.transform_steps:
                applied = []
                blocking = []
                non_applied = []
                for step in mb.transform_steps:
                    if step in query_time_transform_steps:
                        applied.append(step)
                    elif step in materialization_required_steps:
                        blocking.append(step)
                    else:
                        non_applied.append(step)
                if blocking:
                    out.bindings[table.name].status = "materialization_required"
                    out.bindings[table.name].materialization_strategy = "dynamic_table"
                    out.bindings[table.name].materialization_sql = _materialization_sql(
                        out.bindings[table.name], mb
                    )
                    out.bindings[table.name].detail = (
                        "materialization required for M transforms: " + ", ".join(blocking)
                    )
                if blocking or non_applied:
                    out.warnings.append(
                        f"{table.name}: complex M transforms not auto-applied: "
                        + ", ".join(blocking + non_applied)
                    )
                if applied:
                    out.warnings.append(
                        f"{table.name}: M transforms applied: " + ", ".join(applied)
                    )
        elif mb.is_foreign_resolved:
            # source database table — the migration mover lifts it into Snowflake
            out.bindings[table.name] = TableBinding(
                table=table.name,
                status="needs_migration",
                source_kind=mb.foreign_source,
                source_schema=mb.schema,
                source_object=mb.object_name,
                detail=(
                    f"bound to {mb.foreign_source} source "
                    f"{mb.schema}.{mb.object_name}; will migrate to Snowflake"
                ),
            )
        else:
            missing = ", ".join(mb.unresolved_params) or "no schema/object found"
            out.bindings[table.name] = TableBinding(
                table=table.name,
                status="unresolved",
                detail=f"could not resolve M source ({missing})",
            )
    return out


def verify_against_information_schema(
    binding_map: BindingMap, cursor, database: str
) -> BindingMap:
    """Mark resolved bindings missing from the live INFORMATION_SCHEMA."""
    cursor.execute(
        f'select table_schema, table_name from "{safe_ident(database)}"'  # noqa: S608
        ".INFORMATION_SCHEMA.TABLES"
    )
    live = {(r[0].upper(), r[1].upper()) for r in cursor.fetchall()}
    for b in binding_map.bindings.values():
        if b.status == "resolved" and b.object_name and not b.native_query:
            key = ((b.schema_name or "").upper(), b.object_name.upper())
            if key not in live:
                b.status = "unresolved"
                b.detail = f"not found in live {database}.INFORMATION_SCHEMA"
    return binding_map
