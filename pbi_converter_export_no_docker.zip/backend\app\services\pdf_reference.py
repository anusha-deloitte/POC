"""Power BI PDF export -> per-page reference PNGs for the visual parity review.

PBI's File > Export > PDF emits exactly one PDF page per visible report page,
in report order. We rasterize each PDF page (pypdfium2, BSD-licensed PDFium)
and map it to the corresponding report page by ordinal, so one upload seeds
the reference side of every page comparison.
"""

from __future__ import annotations

import io
from dataclasses import dataclass

# render scale ~1.5x of the typical 1280x720 canvas keeps text legible for the
# vision model without exceeding request-size limits
_TARGET_WIDTH = 1920
_MAX_PAGES = 50


class PdfReferenceError(Exception):
    pass


@dataclass
class PdfPageImage:
    index: int  # 0-based PDF page index == report page ordinal
    png: bytes
    width: int
    height: int


def rasterize_pdf(pdf_bytes: bytes) -> list[PdfPageImage]:
    """Render every PDF page to PNG at a vision-friendly resolution."""
    try:
        import pypdfium2 as pdfium
    except ModuleNotFoundError as e:  # pragma: no cover - install-time guard
        raise PdfReferenceError("PDF support not installed (pip install .[pdf])") from e

    try:
        doc = pdfium.PdfDocument(pdf_bytes)
    except Exception as e:
        raise PdfReferenceError(f"not a readable PDF: {e}") from e

    try:
        n = len(doc)
        if n == 0:
            raise PdfReferenceError("PDF has no pages")
        if n > _MAX_PAGES:
            raise PdfReferenceError(f"PDF has {n} pages; limit is {_MAX_PAGES}")

        out: list[PdfPageImage] = []
        for i in range(n):
            page = doc[i]
            w_pt = page.get_width() or 1
            scale = _TARGET_WIDTH / w_pt
            bitmap = page.render(scale=scale)
            pil = bitmap.to_pil()
            buf = io.BytesIO()
            pil.save(buf, format="PNG")
            out.append(
                PdfPageImage(index=i, png=buf.getvalue(), width=pil.width, height=pil.height)
            )
        return out
    finally:
        doc.close()


def map_pages_to_report(
    images: list[PdfPageImage], report_pages: list[dict]
) -> tuple[dict[str, PdfPageImage], list[str]]:
    """Match PDF pages to visible report pages by order.

    `report_pages` is [{"name", "display_name", "ordinal"}] for VISIBLE pages
    sorted by ordinal (hidden pages are not exported to PDF by Power BI).
    Returns ({page_name: image}, warnings).
    """
    warnings: list[str] = []
    pages_sorted = sorted(report_pages, key=lambda p: p["ordinal"])
    if len(images) != len(pages_sorted):
        warnings.append(
            f"PDF has {len(images)} pages but the report has {len(pages_sorted)} visible "
            "pages; matched in order for the overlap"
        )
    mapping: dict[str, PdfPageImage] = {}
    for img, page in zip(images, pages_sorted, strict=False):
        mapping[page["name"]] = img
    return mapping, warnings
