import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { ConnectStep } from '../steps/ConnectStep'
import { useWizard } from '../store/wizard'

function renderStep() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <ConnectStep />
    </QueryClientProvider>,
  )
}

const profile = { id: 'p1', name: 'demo', account: 'a', user: 'u', auth_method: 'password' }

describe('ConnectStep', () => {
  beforeEach(() => useWizard.getState().reset())
  afterEach(() => vi.restoreAllMocks())

  it('surfaces a status even when the test endpoint errors (501, regression)', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.endsWith('/connections') && init?.method === 'POST')
          return new Response(JSON.stringify(profile), { status: 201 })
        if (url.endsWith('/test'))
          return new Response(JSON.stringify({ detail: 'connector not installed' }), {
            status: 501,
          })
        if (url.endsWith('/source-types'))
          return new Response(
            JSON.stringify([{ id: 'snowflake', label: 'Snowflake', available: true }]),
            { status: 200 },
          )
        return new Response(JSON.stringify([]), { status: 200 })
      }),
    )

    renderStep()
    const user = userEvent.setup()
    // no existing connections -> the new-connection form is shown directly
    const target = () => within(screen.getByTestId('target-panel'))
    await waitFor(() => expect(target().getByLabelText('Authentication')).toBeVisible())
    await user.selectOptions(target().getByLabelText('Authentication'), 'password')
    await user.type(target().getByLabelText('Connection name'), 'demo')
    await user.type(target().getByLabelText('Account identifier'), 'a')
    await user.type(target().getByLabelText('User'), 'u')
    await user.type(target().getByLabelText('Default database'), 'db')
    await user.type(target().getByLabelText('Default schema'), 'sch')
    await user.type(target().getByLabelText('Password'), 'x')
    await user.click(target().getByRole('button', { name: /Save & test/ }))

    await waitFor(() => {
      expect(screen.getByRole('status')).toHaveTextContent(/saved, but probe failed:/i)
      expect(screen.getByRole('status')).toHaveTextContent(/connector not installed/i)
    })
    // saved profile is still usable
    expect(screen.getByRole('button', { name: /Continue with this connection/ })).toBeVisible()
  })

  it('allows deleting an existing connection', async () => {
    let deleted = false
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.endsWith('/connections') && !init?.method) {
          return new Response(JSON.stringify(deleted ? [] : [profile]), { status: 200 })
        }
        if (url.endsWith('/connections/p1') && init?.method === 'DELETE') {
          deleted = true
          return new Response(null, { status: 204 })
        }
        return new Response(JSON.stringify([]), { status: 200 })
      }),
    )

    renderStep()
    const user = userEvent.setup()

    await waitFor(() => expect(screen.getByRole('button', { name: /delete/i })).toBeVisible())
    await user.click(screen.getByRole('button', { name: /delete/i }))

    await waitFor(() => {
      expect(screen.queryByText('demo')).not.toBeInTheDocument()
    })
  })

  it('shows latency on successful probe', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.endsWith('/connections') && init?.method === 'POST')
          return new Response(JSON.stringify(profile), { status: 201 })
        if (url.endsWith('/test'))
          return new Response(
            JSON.stringify({ ok: true, latency_ms: 42, warehouse: 'DEMO_WH' }),
            { status: 200 },
          )
        if (url.endsWith('/source-types'))
          return new Response(
            JSON.stringify([{ id: 'snowflake', label: 'Snowflake', available: true }]),
            { status: 200 },
          )
        return new Response(JSON.stringify([]), { status: 200 })
      }),
    )

    renderStep()
    const user = userEvent.setup()
    const target = () => within(screen.getByTestId('target-panel'))
    await waitFor(() => expect(target().getByLabelText('Authentication')).toBeVisible())
    await user.selectOptions(target().getByLabelText('Authentication'), 'password')
    await user.type(target().getByLabelText('Connection name'), 'demo')
    await user.type(target().getByLabelText('Account identifier'), 'a')
    await user.type(target().getByLabelText('User'), 'u')
    await user.type(target().getByLabelText('Default database'), 'db')
    await user.type(target().getByLabelText('Default schema'), 'sch')
    await user.type(target().getByLabelText('Password'), 'x')
    await user.click(target().getByRole('button', { name: /Save & test/ }))

    await waitFor(() => {
      expect(screen.getByRole('status')).toHaveTextContent('Connected in 42 ms (DEMO_WH)')
    })
  })

  it('shows the source-migration panel when the report reads a foreign database', async () => {
    useWizard.setState({ conversionId: 'c1' })
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        if (url.endsWith('/conversions/c1'))
          return new Response(
            JSON.stringify({
              id: 'c1',
              report: 'r',
              model: { tables: 1, relationships: 0, measures: 0, roles: 0 },
              pages: [],
              visual_types: {},
              source_database: {
                kind: 'sqlserver',
                needs_migration: true,
                tables: [
                  {
                    table: 'FactClaims',
                    kind: 'sqlserver',
                    schema: 'dbo',
                    object: 'FactClaims',
                    database: 'ClaimsDW',
                  },
                ],
              },
              warnings: [],
            }),
            { status: 200 },
          )
        return new Response(JSON.stringify([]), { status: 200 })
      }),
    )

    renderStep()
    // terse detection banner: just the DB type + database name
    await waitFor(() =>
      expect(screen.getByTestId('source-migration-panel')).toHaveTextContent(/Detected:/),
    )
    const panel = within(screen.getByTestId('source-migration-panel'))
    expect(panel.getByText('SQL Server')).toBeInTheDocument()
    expect(panel.getByText('ClaimsDW')).toBeInTheDocument()
    // NO table list and NO over-instruction in this page
    expect(screen.getByTestId('source-migration-panel')).not.toHaveTextContent('dbo.FactClaims')
    // no saved sources -> inline creation form, prefilled and kind FIXED (detected)
    expect(panel.getByLabelText('Database')).toHaveValue('ClaimsDW')
    expect(panel.queryByLabelText('Database type')).not.toBeInTheDocument()
    // target panel rendered side by side with equal prominence
    expect(screen.getByTestId('target-panel')).toBeVisible()
  })

  it('offers the source panel even for Snowflake-native reports (optional)', async () => {
    useWizard.setState({ conversionId: 'c2' })
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        if (url.endsWith('/conversions/c2'))
          return new Response(
            JSON.stringify({
              id: 'c2',
              report: 'r',
              model: { tables: 1, relationships: 0, measures: 0, roles: 0 },
              pages: [],
              visual_types: {},
              source_database: { kind: 'snowflake', needs_migration: false, tables: [] },
              warnings: [],
            }),
            { status: 200 },
          )
        return new Response(JSON.stringify([]), { status: 200 })
      }),
    )

    renderStep()
    await waitFor(() => expect(screen.getByTestId('source-migration-panel')).toBeVisible())
    expect(screen.getByTestId('source-migration-panel')).toHaveTextContent(
      /Reads Snowflake — no source needed/,
    )
    // undetected case keeps the free kind picker in the inline form
    const panel = within(screen.getByTestId('source-migration-panel'))
    expect(panel.getByLabelText('Database type')).toBeVisible()
    // plan bar reflects no-migration state and continue is gated on target only
    expect(screen.getByText(/No source migration/)).toBeInTheDocument()
  })
})
