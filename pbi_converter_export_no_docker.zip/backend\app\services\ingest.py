"""Upload ingestion: safe zip extraction + PBIP parsing into stored bundles."""

from __future__ import annotations

import json
import shutil
import uuid
import zipfile
from dataclasses import dataclass
from pathlib import Path

from app.ir.report import ReportBundle
from app.parsers.bundle import load_pbip

_MAX_MEMBERS = 5000
_MAX_UNCOMPRESSED = 500 * 1024 * 1024
_MAX_RATIO = 200  # zip-bomb guard


class IngestError(Exception):
    pass


def safe_extract_zip(archive: Path, dest: Path) -> None:
    """Extract with zip-slip, zip-bomb and member-count protection."""
    dest = dest.resolve()
    with zipfile.ZipFile(archive) as zf:
        members = zf.infolist()
        if len(members) > _MAX_MEMBERS:
            raise IngestError(f"archive has too many entries ({len(members)})")
        total = sum(m.file_size for m in members)
        if total > _MAX_UNCOMPRESSED:
            raise IngestError("archive too large when uncompressed")
        compressed = sum(m.compress_size for m in members) or 1
        if total / compressed > _MAX_RATIO:
            raise IngestError("suspicious compression ratio")
        for m in members:
            target = (dest / m.filename).resolve()
            if not target.is_relative_to(dest):
                raise IngestError(f"unsafe path in archive: {m.filename}")
        zf.extractall(dest)  # noqa: S202 - members validated above


@dataclass
class StoredConversion:
    id: str
    root: Path
    bundle_file: Path


class IngestService:
    def __init__(self, storage_dir: Path):
        self.storage_dir = storage_dir
        storage_dir.mkdir(parents=True, exist_ok=True)

    def conversion_dir(self, conversion_id: str) -> Path:
        # uuid-validate to keep ids path-safe
        return self.storage_dir / str(uuid.UUID(conversion_id))

    def set_job_name(self, conversion_id: str, name: str) -> None:
        d = self.conversion_dir(conversion_id)
        if not d.is_dir():
            raise IngestError("conversion not found")
        meta_file = d / "meta.json"
        meta = {}
        if meta_file.is_file():
            try:
                meta = json.loads(meta_file.read_text(encoding="utf-8"))
            except ValueError:
                meta = {}
        meta["name"] = name.strip()[:120]
        meta_file.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    def job_name(self, conversion_dir: Path) -> str | None:
        meta_file = conversion_dir / "meta.json"
        if not meta_file.is_file():
            return None
        try:
            return json.loads(meta_file.read_text(encoding="utf-8")).get("name") or None
        except ValueError:
            return None

    def ingest_zip(self, archive: Path) -> StoredConversion:
        conversion_id = str(uuid.uuid4())
        root = self.storage_dir / conversion_id
        src_dir = root / "source"
        src_dir.mkdir(parents=True)
        try:
            safe_extract_zip(archive, src_dir)
            bundle = load_pbip(src_dir)
        except Exception:
            shutil.rmtree(root, ignore_errors=True)
            raise
        return self._store(conversion_id, root, bundle)

    def ingest_folder(self, folder: Path) -> StoredConversion:
        """Ingest an already-extracted .pbip folder (dev/demo path)."""
        conversion_id = str(uuid.uuid4())
        root = self.storage_dir / conversion_id
        root.mkdir(parents=True)
        try:
            bundle = load_pbip(folder)
        except Exception:
            shutil.rmtree(root, ignore_errors=True)
            raise
        return self._store(conversion_id, root, bundle)

    def _store(self, conversion_id: str, root: Path, bundle: ReportBundle) -> StoredConversion:
        bundle_file = root / "bundle.json"
        bundle_file.write_text(bundle.model_dump_json(indent=2), encoding="utf-8")
        return StoredConversion(id=conversion_id, root=root, bundle_file=bundle_file)

    def load_bundle(self, conversion_id: str) -> ReportBundle:
        bundle_file = self.conversion_dir(conversion_id) / "bundle.json"
        if not bundle_file.is_file():
            raise IngestError(f"unknown conversion: {conversion_id}")
        return ReportBundle.model_validate_json(bundle_file.read_text(encoding="utf-8"))

    def list_conversions(self) -> list[dict]:
        out = []
        for d in sorted(self.storage_dir.iterdir()):
            bf = d / "bundle.json"
            if bf.is_file():
                data = json.loads(bf.read_text(encoding="utf-8"))
                out.append(
                    {
                        "id": d.name,
                        "report": data["report"]["name"],
                        "pages": len(data["report"]["pages"]),
                        "tables": len(data["model"]["tables"]),
                        "warnings": data.get("warnings", []),
                    }
                )
        return out

    def list_jobs(self) -> list[dict]:
        """Conversions enriched with run status for the Jobs page."""
        jobs = []
        for d in sorted(self.storage_dir.iterdir(), reverse=True):
            bf = d / "bundle.json"
            if not bf.is_file():
                continue
            data = json.loads(bf.read_text(encoding="utf-8"))
            run_file = d / "conversion_run.json"
            score = None
            status = "ingested"
            converted_at = None
            if run_file.is_file():
                run = json.loads(run_file.read_text(encoding="utf-8"))
                summary = run.get("summary") or {}
                score = summary.get("overall_score")
                failed = summary.get("visuals_failed", 0)
                status = "needs_review" if failed else "complete"
                events = run.get("events") or []
                converted_at = events[-1]["ts"] if events else None
            jobs.append(
                {
                    "id": d.name,
                    "name": self.job_name(d),
                    "report": data["report"]["name"],
                    "pages": len(data["report"]["pages"]),
                    "visuals": sum(len(p["visuals"]) for p in data["report"]["pages"]),
                    "measures": sum(len(t["measures"]) for t in data["model"]["tables"]),
                    "status": status,
                    "fidelity": score,
                    "uploaded_at": bf.stat().st_mtime,
                    "converted_at": converted_at,
                    "accelerated": (d / "accelerated.duckdb").exists(),
                }
            )
        return jobs
