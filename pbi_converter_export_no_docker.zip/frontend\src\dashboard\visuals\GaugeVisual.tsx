import type { EChartsOption } from 'echarts'
import { formatValue } from '../format'
import { useGoodBad } from '../theme'
import type { VisualResult, VisualSpec } from '../types'
import { EChart } from './EChart'

/** PBI gauge: Y value vs TargetValue marker; range 0..max(2*value, target). */
export function GaugeVisual({ spec, data }: { spec: VisualSpec; data?: VisualResult }) {
  const { bad, accent } = useGoodBad()
  if (!data) return <div className="p-2 text-xs text-surface-400">…</div>
  if (data.error) return <div className="p-2 text-xs text-brand-red">{data.error}</div>

  const roleOf = (role: string) =>
    spec.measure_keys.find((k) => spec.measure_roles[k] === role)
  const valKey = roleOf('Y') ?? spec.measure_keys[0]
  const tgtKey = roleOf('TargetValue')
  const vi = data.columns.indexOf(valKey!)
  const ti = tgtKey ? data.columns.indexOf(tgtKey) : -1

  const value = Number(data.rows[0]?.[vi] ?? 0)
  const target = ti >= 0 ? Number(data.rows[0]?.[ti] ?? 0) : null
  const fmt = spec.measure_formats[valKey!]
  const isPct = (fmt ?? '').includes('%') || value <= 1
  const max = isPct ? 1 : Math.max(value * 2, target ?? 0)

  const option: EChartsOption = {
    series: [
      {
        type: 'gauge',
        startAngle: 200,
        endAngle: -20,
        min: 0,
        max,
        radius: '95%',
        center: ['50%', '62%'],
        progress: { show: true, width: 14, itemStyle: { color: accent } },
        axisLine: { lineStyle: { width: 14, color: [[1, '#E2E8F0']] } },
        axisTick: { show: false },
        splitLine: { show: false },
        axisLabel: { show: false },
        pointer: { show: false },
        anchor: { show: false },
        title: { show: false },
        detail: {
          valueAnimation: false,
          offsetCenter: [0, '-12%'],
          fontSize: 18,
          fontWeight: 'bold',
          color: '#1e293b',
          formatter: (v: number) => formatValue(v, fmt),
        },
        data: [{ value }],
        markLine: undefined,
      },
      ...(target !== null
        ? [
            {
              type: 'gauge' as const,
              startAngle: 200,
              endAngle: -20,
              min: 0,
              max,
              radius: '95%',
              center: ['50%', '62%'] as [string, string],
              progress: { show: false },
              axisLine: { lineStyle: { width: 0, color: [[1, 'transparent']] as [number, string][] } },
              axisTick: { show: false },
              splitLine: { show: false },
              axisLabel: { show: false },
              pointer: {
                show: true,
                length: '60%',
                width: 3,
                itemStyle: { color: bad },
              },
              detail: { show: false },
              data: [{ value: target }],
            },
          ]
        : []),
    ],
  }
  // PBI gauges show only the target needle, no caption text
  return (
    <div className="relative h-full w-full">
      <EChart option={option} />
    </div>
  )
}
