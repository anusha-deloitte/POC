"""Query explainer and conversion diff endpoints.

GET  /api/v1/conversions/{id}/explain/{page}/{visual}
  Returns: dax_source, compiled_leaves, generated_sql, warnings, tier

GET  /api/v1/conversions/{id}/diff
  Returns: per-visual diff of original PBI definition vs. converted VisualSpec
"""

from __future__ import annotations

import json

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from app.api.deps import get_ingest_service, require_token
from app.runtime.dashboard import compile_dashboard
from app.runtime.engine import QueryPlanError, SemanticEngine
from app.services.ingest import IngestService

router = APIRouter(
    prefix="/api/v1/conversions/{conversion_id}",
    tags=["explain"],
    dependencies=[Depends(require_token)],
)


# ---------------------------------------------------------------------------
# Query Explainer
# ---------------------------------------------------------------------------

class LeafExplanation(BaseModel):
    alias: str
    sql: str
    tables: list[str]
    time_shift: str | None = None
    filters: list[str] = Field(default_factory=list)
    use_relationships: list[str] = Field(default_factory=list)


class MeasureExplanation(BaseModel):
    name: str
    dax_source: str | None = None
    tier: int
    combiner_expr: str
    leaves: list[LeafExplanation] = Field(default_factory=list)
    is_window_avg: bool = False
    tier2_sql: str | None = None


class QueryExplanation(BaseModel):
    visual: str
    page: str
    visual_type: str
    generated_sql: str
    warnings: list[str] = Field(default_factory=list)
    measures: list[MeasureExplanation] = Field(default_factory=list)


@router.get("/explain/{page_name}/{visual_name}", response_model=QueryExplanation)
def explain_visual(
    conversion_id: str,
    page_name: str,
    visual_name: str,
    svc: IngestService = Depends(get_ingest_service),
) -> QueryExplanation:
    """Return the full query lineage for a specific visual: DAX → compiled
    leaves → generated SQL.  Use this as the 'Show SQL' feature in the UI."""
    t2 = _tier2_sql(conversion_id, svc)

    try:
        bundle = svc.load_bundle(conversion_id)
        spec, binding_map = compile_dashboard(bundle, tier2_sql=t2)
    except Exception as e:
        raise HTTPException(404, str(e)) from e

    # Find the page
    page_spec = next((p for p in spec.pages if p.name == page_name or p.display_name == page_name), None)
    if page_spec is None:
        raise HTTPException(404, f"page {page_name!r} not found")

    # Find the visual
    vs = next((v for v in page_spec.visuals if v.name == visual_name), None)
    if vs is None:
        raise HTTPException(404, f"visual {visual_name!r} not found on page {page_name!r}")

    if vs.query is None:
        return QueryExplanation(
            visual=vs.name,
            page=page_name,
            visual_type=vs.visual_type,
            generated_sql="-- static visual, no query",
        )

    engine = SemanticEngine(bundle.model, binding_map, tier2_sql=t2)
    try:
        sql, warnings = engine.build_sql(vs.query)
    except QueryPlanError as e:
        raise HTTPException(422, str(e)) from e

    # Build measure explanations
    from app.dax.compiler import DaxUnsupported, MeasureCompiler

    compiler = MeasureCompiler(bundle.model)
    measure_exps: list[MeasureExplanation] = []

    for m_ref in vs.query.measures:
        m_name = m_ref.name
        dax_src: str | None = None
        if m_name:
            found = bundle.model.find_measure(m_name)
            if found:
                _, m_obj = found
                dax_src = m_obj.expression

        tier = 1
        combiner = ""
        leaves_out: list[LeafExplanation] = []
        is_window = False
        t2_sql_val: str | None = None

        if m_name and m_name in t2:
            tier = 2
            t2_sql_val = t2[m_name]
            combiner = f"(tier-2 subquery)"
        elif m_name:
            try:
                cm = compiler.compile_measure(m_name)
                tier = cm.tier
                combiner = cm.expr
                is_window = cm.window_avg is not None
                for alias, leaf in cm.leaves.items():
                    shift_str = None
                    if leaf.ctx.time_shift:
                        ts = leaf.ctx.time_shift
                        shift_str = f"{ts.kind}({ts.date_table}.{ts.date_column})"
                    leaves_out.append(LeafExplanation(
                        alias=alias,
                        sql=leaf.sql,
                        tables=sorted(leaf.tables),
                        time_shift=shift_str,
                        filters=[p.sql for p in leaf.ctx.filters],
                        use_relationships=[f"{a} → {b}" for a, b in leaf.ctx.use_relationships],
                    ))
            except DaxUnsupported:
                tier = -1
                combiner = "-- unsupported (parked)"
        else:
            tier = 0
            combiner = "(implicit aggregate)"

        measure_exps.append(MeasureExplanation(
            name=m_ref.key,
            dax_source=dax_src,
            tier=tier,
            combiner_expr=combiner,
            leaves=leaves_out,
            is_window_avg=is_window,
            tier2_sql=t2_sql_val,
        ))

    return QueryExplanation(
        visual=vs.name,
        page=page_name,
        visual_type=vs.visual_type,
        generated_sql=sql,
        warnings=warnings,
        measures=measure_exps,
    )


# ---------------------------------------------------------------------------
# Conversion Diff
# ---------------------------------------------------------------------------

class VisualDiff(BaseModel):
    visual: str
    page: str
    original_type: str
    converted_type: str
    title: str | None = None
    fields_kept: list[str] = Field(default_factory=list)
    fields_dropped: list[str] = Field(default_factory=list)
    is_substituted: bool = False
    substituted_as: str | None = None
    filters_count: int = 0
    is_hidden: bool = False
    warnings: list[str] = Field(default_factory=list)


class ConversionDiff(BaseModel):
    conversion_id: str
    visuals_total: int
    visuals_exact: int
    visuals_substituted: int
    visuals_dropped_fields: int
    visuals_unsupported: int
    type_changes: dict[str, int] = Field(default_factory=dict)
    diffs: list[VisualDiff] = Field(default_factory=list)


@router.get("/diff", response_model=ConversionDiff)
def get_conversion_diff(
    conversion_id: str,
    svc: IngestService = Depends(get_ingest_service),
) -> ConversionDiff:
    """Return a structured diff of the original PBI visual definitions vs.
    the converted VisualSpec objects.  Surfaces type substitutions, dropped
    fields, filter simplifications, and unsupported visuals."""
    t2 = _tier2_sql(conversion_id, svc)
    try:
        bundle = svc.load_bundle(conversion_id)
        spec, _ = compile_dashboard(bundle, tier2_sql=t2)
    except Exception as e:
        raise HTTPException(404, str(e)) from e

    # Build a lookup of original PBI visuals
    orig_lookup: dict[str, tuple] = {}  # (page_name, visual_name) → IR Visual
    for page in bundle.report.pages:
        for vis in page.visuals:
            orig_lookup[(page.name, vis.name)] = (page, vis)

    diffs: list[VisualDiff] = []
    type_changes: dict[str, int] = {}

    for page_spec in spec.pages:
        for vs in page_spec.visuals:
            orig_pair = orig_lookup.get((page_spec.name, vs.name))
            orig_type = orig_pair[1].visual_type if orig_pair else vs.visual_type

            fields_kept: list[str] = []
            fields_dropped: list[str] = vs.dropped_fields or []

            if orig_pair:
                ir_vis = orig_pair[1]
                orig_fields = [f.name for f in ir_vis.fields if f.name]
                kept_set = set(orig_fields) - set(fields_dropped)
                fields_kept = sorted(kept_set)

            if orig_type != vs.visual_type and not vs.substituted_as:
                # type changed
                key = f"{orig_type} → {vs.visual_type}"
                type_changes[key] = type_changes.get(key, 0) + 1

            if vs.substituted_as:
                key = f"{orig_type} → {vs.substituted_as} (substituted)"
                type_changes[key] = type_changes.get(key, 0) + 1

            diffs.append(VisualDiff(
                visual=vs.name,
                page=page_spec.display_name,
                original_type=orig_type,
                converted_type=vs.visual_type if not vs.substituted_as else vs.substituted_as,
                title=vs.title,
                fields_kept=fields_kept,
                fields_dropped=fields_dropped,
                is_substituted=bool(vs.substituted_as),
                substituted_as=vs.substituted_as,
                filters_count=len(vs.query.filters) if vs.query else 0,
                is_hidden=orig_pair[1].is_hidden if orig_pair else False,
                warnings=[w for w in (spec.warnings or []) if vs.name in w],
            ))

    total = len(diffs)
    return ConversionDiff(
        conversion_id=conversion_id,
        visuals_total=total,
        visuals_exact=sum(
            1 for d in diffs
            if d.original_type == d.converted_type and not d.is_substituted and not d.fields_dropped
        ),
        visuals_substituted=sum(1 for d in diffs if d.is_substituted),
        visuals_dropped_fields=sum(1 for d in diffs if d.fields_dropped),
        visuals_unsupported=sum(1 for d in diffs if d.original_type not in _SUPPORTED_TYPES),
        type_changes=type_changes,
        diffs=diffs,
    )


_SUPPORTED_TYPES = {
    "card", "slicer", "donutChart", "pieChart", "clusteredColumnChart",
    "clusteredBarChart", "barChart", "columnChart", "lineChart", "areaChart",
    "waterfallChart", "pivotTable", "tableEx", "textbox", "scatterChart",
    "lineClusteredColumnComboChart", "gauge", "filledMap", "decompositionTreeVisual",
}


def _tier2_sql(conversion_id: str, svc: IngestService) -> dict[str, str]:
    try:
        path = svc.conversion_dir(conversion_id) / "conversion_run.json"
    except ValueError:
        return {}
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8")).get("tier2_accepted", {})
    except (OSError, ValueError):
        return {}
