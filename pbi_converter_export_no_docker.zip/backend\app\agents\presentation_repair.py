"""Presentation repair agent.

Deterministic (no LLM): re-reads the raw PBIR payload through
`extract_declared_presentation` — the same source of truth the validation
harness checks against — diffs it with the compiled spec, and expresses every
gap as a whitelisted spec override. The pipeline applies the proposals and
re-validates; the monotonic score guard decides whether they stick.
"""

from __future__ import annotations

from app.ir.report import ReportBundle, Visual
from app.runtime.dashboard import DashboardSpec, extract_declared_presentation
from app.services.overrides import _OPTION_KEYS


def _visual_index(bundle: ReportBundle) -> dict[tuple[str, str], Visual]:
    return {
        (page.name, visual.name): visual
        for page in bundle.report.pages
        for visual in page.visuals
    }


def presentation_gaps(bundle: ReportBundle, spec: DashboardSpec) -> list[dict]:
    """Every declared presentation property missing or wrong in the compiled spec.

    Returns dicts: {page, visual, kind, key, declared, compiled} where kind is
    'option' (renderer option) or 'measure_format'.
    """
    raw = _visual_index(bundle)
    gaps: list[dict] = []
    for page in spec.pages:
        for vs in page.visuals:
            visual = raw.get((page.name, vs.name))
            if visual is None or not vs.supported:
                continue
            declared = extract_declared_presentation(visual)
            for key, value in declared.items():
                if vs.options.get(key) != value:
                    gaps.append(
                        {
                            "page": page.name,
                            "visual": vs.name,
                            "kind": "option",
                            "key": key,
                            "declared": value,
                            "compiled": vs.options.get(key),
                        }
                    )
            if vs.query is not None:
                for m in vs.query.measures:
                    if not m.name:
                        continue
                    found = bundle.model.find_measure(m.name)
                    model_fmt = found[1].format_string if found else None
                    if model_fmt and vs.measure_formats.get(m.key) != model_fmt:
                        gaps.append(
                            {
                                "page": page.name,
                                "visual": vs.name,
                                "kind": "measure_format",
                                "key": m.key,
                                "declared": model_fmt,
                                "compiled": vs.measure_formats.get(m.key),
                            }
                        )
    return gaps


def propose_overrides(gaps: list[dict]) -> list[dict]:
    """Convert gaps into the whitelisted override vocabulary (skip anything the
    vocabulary cannot express — those stay visible as validation findings)."""
    proposals: list[dict] = []
    for gap in gaps:
        if gap["kind"] == "option" and gap["key"] in _OPTION_KEYS:
            proposals.append(
                {
                    "op": "set_option",
                    "page": gap["page"],
                    "visual": gap["visual"],
                    "key": gap["key"],
                    "value": gap["declared"],
                }
            )
        elif gap["kind"] == "measure_format":
            proposals.append(
                {
                    "op": "set_measure_format",
                    "page": gap["page"],
                    "visual": gap["visual"],
                    "measure": gap["key"],
                    "value": gap["declared"],
                }
            )
    return proposals
