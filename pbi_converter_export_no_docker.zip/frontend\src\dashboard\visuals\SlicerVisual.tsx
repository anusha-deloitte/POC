import type { VisualResult, VisualSpec } from '../types'

export function SlicerVisual({
  spec,
  data,
  selected,
  onChange,
}: {
  spec: VisualSpec
  data?: VisualResult
  selected: (string | number)[]
  onChange: (values: (string | number)[]) => void
}) {
  const options = (data?.rows ?? []).map((r) => r[0]).filter((v) => v !== null) as (
    | string
    | number
  )[]
  const label = spec.title ?? spec.slicer_target?.column ?? 'Filter'
  return (
    <label className="flex h-full w-full flex-col justify-center gap-0.5 px-1">
      <span className="truncate text-[10px] font-medium uppercase tracking-wide text-surface-500">
        {label}
      </span>
      <select
        multiple={false}
        className="w-full rounded border border-surface-400 bg-white px-1.5 py-1 text-xs"
        value={selected.length ? String(selected[0]) : ''}
        onChange={(e) => {
          const v = e.target.value
          if (v === '') onChange([])
          else {
            const original = options.find((o) => String(o) === v)
            onChange([original ?? v])
          }
        }}
      >
        <option value="">All</option>
        {options.map((o) => (
          <option key={String(o)} value={String(o)}>
            {String(o)}
          </option>
        ))}
      </select>
    </label>
  )
}
