from app.binding.resolver import BindingMap, TableBinding
from app.api.dashboards import _apply_what_if_values
from app.ir.model import (
    Column,
    Measure,
    Partition,
    SemanticModel,
    Table,
)
from app.ir.report import (
    Page,
    Report,
    ReportBundle,
    Visual,
    VisualField,
    VisualPosition,
)
from app.runtime.dashboard import compile_dashboard
from app.runtime.engine import DimensionRef, MeasureRefSpec, QuerySpec, SemanticEngine
from types import SimpleNamespace


def _binding_map(*tables: str) -> BindingMap:
    return BindingMap(
        bindings={
            t: TableBinding(table=t, schema_name="PUBLIC", object_name=t, status="resolved")
            for t in tables
        }
    )


def test_dashboard_hierarchy_metadata_and_drill_levels():
    model = SemanticModel(
        tables=[
            Table(
                name="Date",
                columns=[Column(name="Year"), Column(name="Month")],
                partitions=[Partition(name="p", source_type="calculated", expression="Row(1,1)")],
            ),
            Table(
                name="Sales",
                columns=[Column(name="Amount")],
                measures=[Measure(name="Total Sales", expression="SUM(Sales[Amount])")],
                partitions=[Partition(name="p", source_type="calculated", expression="Row(1,1)")],
            ),
        ]
    )
    visual = Visual(
        name="v1",
        visual_type="lineChart",
        position=VisualPosition(x=0, y=0, width=10, height=10),
        fields=[
            VisualField(
                role="Axis",
                table="Date",
                name="Year",
                is_hierarchy_level=True,
                hierarchy="Calendar",
            ),
            VisualField(
                role="Axis",
                table="Date",
                name="Month",
                is_hierarchy_level=True,
                hierarchy="Calendar",
            ),
            VisualField(role="Y", is_measure=True, name="Total Sales"),
        ],
    )
    bundle = ReportBundle(
        source_path="/tmp",
        model=model,
        report=Report(name="R", pages=[Page(name="p", display_name="P", visuals=[visual])]),
    )

    spec, _ = compile_dashboard(bundle)
    vs = spec.pages[0].visuals[0]
    assert vs.hierarchy is not None
    assert vs.hierarchy["name"] == "Calendar"
    assert vs.hierarchy["levels"] == ["Date.Year", "Date.Month"]
    assert vs.hierarchy["drill_enabled"] is True


def test_what_if_parameter_detection_and_measure_linking():
    model = SemanticModel(
        tables=[
            Table(
                name="WhatIf",
                columns=[Column(name="WhatIf Value")],
                partitions=[
                    Partition(
                        name="p",
                        source_type="calculated",
                        expression="GENERATESERIES(0, 100, 5)",
                    )
                ],
            ),
            Table(
                name="Fact",
                columns=[Column(name="Base")],
                measures=[
                    Measure(
                        name="Scenario Value",
                        expression="SELECTEDVALUE('WhatIf'[WhatIf Value], 0) + SUM(Fact[Base])",
                    )
                ],
                partitions=[Partition(name="p", source_type="calculated", expression="Row(1,1)")],
            ),
        ]
    )
    visual = Visual(
        name="v1",
        visual_type="card",
        position=VisualPosition(x=0, y=0, width=10, height=10),
        fields=[VisualField(role="Y", is_measure=True, name="Scenario Value")],
    )
    bundle = ReportBundle(
        source_path="/tmp",
        model=model,
        report=Report(name="R", pages=[Page(name="p", display_name="P", visuals=[visual])]),
    )

    spec, _ = compile_dashboard(bundle)
    assert spec.what_if_parameters
    assert spec.what_if_parameters[0]["table"] == "WhatIf"
    assert spec.pages[0].visuals[0].options.get("what_if", {}).get("column") == "WhatIf Value"


def test_engine_emits_warning_on_many_to_many_path():
    model = SemanticModel(
        tables=[
            Table(name="Fact", columns=[Column(name="K"), Column(name="Value")]),
            Table(name="Bridge", columns=[Column(name="FK"), Column(name="DK")]),
            Table(name="Dim", columns=[Column(name="DK"), Column(name="Name")]),
        ],
        relationships=[
            # Intentional M:M edge
            {
                "name": "FactBridge",
                "from_table": "Fact",
                "from_column": "K",
                "to_table": "Bridge",
                "to_column": "FK",
                "from_cardinality": "many",
                "to_cardinality": "many",
                "cross_filtering_behavior": "singleDirection",
                "is_active": True,
            },
            {
                "name": "BridgeDim",
                "from_table": "Bridge",
                "from_column": "DK",
                "to_table": "Dim",
                "to_column": "DK",
                "from_cardinality": "many",
                "to_cardinality": "one",
                "cross_filtering_behavior": "singleDirection",
                "is_active": True,
            },
        ],
    )
    # Pydantic normalizes dicts to Relationship models
    engine = SemanticEngine(model, _binding_map("Fact", "Bridge", "Dim"))

    sql, warnings = engine.build_sql(
        QuerySpec(
            dimensions=[DimensionRef(table="Dim", column="Name")],
            measures=[MeasureRefSpec(table="Fact", column="Value", aggregate="Sum")],
        )
    )
    assert "SUM(\"Fact\".\"Value\")" in sql
    assert any("M2M_PATH" in w for w in warnings)


def test_apply_what_if_values_injects_eq_filter():
    visual = SimpleNamespace(options={"what_if": {"table": "WhatIf", "column": "WhatIf Value"}})
    query = QuerySpec(
        filters=[
            # Existing same-column filter should be replaced by injected value.
            {
                "table": "WhatIf",
                "column": "WhatIf Value",
                "values": [0],
                "op": "eq",
            }
        ]
    )
    _apply_what_if_values(visual, query, {"WhatIf.WhatIf Value": 25})
    assert len(query.filters) == 1
    assert query.filters[0].table == "WhatIf"
    assert query.filters[0].column == "WhatIf Value"
    assert query.filters[0].op == "eq"
    assert query.filters[0].values == [25]
