"""Zero-loss gate for the reimagined dashboard variant.

Deterministic proof that the redesign dropped nothing: every dimension key,
measure key, slicer target and visual-level filter present in the original
spec must be present in the variant, and every mapping entry must declare an
empty `information_delta.missing`. Accept is blocked unless `passed`.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from app.agents.reimagine_build import VisualMappingManifest
from app.runtime.dashboard import DashboardSpec


class ZeroLossResult(BaseModel):
    passed: bool
    coverage: dict[str, str] = Field(default_factory=dict)
    gaps: list[str] = Field(default_factory=list)


def _collect(spec: DashboardSpec):
    dims: set[str] = set()
    measures: set[str] = set()
    slicers: set[str] = set()
    filters: set[str] = set()
    for page in spec.pages:
        for vs in page.visuals:
            dims.update(vs.dim_keys)
            measures.update(vs.measure_keys)
            if vs.slicer_target:
                slicers.add(f"{vs.slicer_target['table']}.{vs.slicer_target['column']}")
            if vs.query is not None:
                for f in vs.query.filters:
                    filters.add(f"{f.table}.{f.column}:{f.op}")
    return dims, measures, slicers, filters


def run_zero_loss_gate(
    original: DashboardSpec,
    variant: DashboardSpec,
    manifest: VisualMappingManifest,
) -> ZeroLossResult:
    o_dims, o_measures, o_slicers, o_filters = _collect(original)
    v_dims, v_measures, v_slicers, v_filters = _collect(variant)

    gaps: list[str] = []
    for d in sorted(o_dims - v_dims):
        gaps.append(f"dimension lost: {d}")
    for m in sorted(o_measures - v_measures):
        gaps.append(f"measure lost: {m}")
    for s in sorted(o_slicers - v_slicers):
        gaps.append(f"slicer lost: {s}")
    for f in sorted(o_filters - v_filters):
        gaps.append(f"filter lost: {f}")

    # per-visual query identity: each original data visual must survive with an
    # identical QuerySpec on its mapped page (page_map follows architecture
    # merges; identity when pages are kept). Deduped duplicates (merged pages'
    # redundant slicers) must map to a surviving twin with an identical query.
    page_map = manifest.page_map or {}
    dedupe_map = {
        e.original["visual"]: e.reimagined["visual"]
        for e in manifest.entries
        if e.change_kind == "dedupe"
    }
    v_index = {(p.name, vs.name): vs for p in variant.pages for vs in p.visuals}
    by_name = {vs.name: vs for p in variant.pages for vs in p.visuals}
    for page in original.pages:
        target_page = page_map.get(page.name, page.name)
        for vs in page.visuals:
            if vs.query is None:
                continue
            twin = v_index.get((target_page, vs.name))
            if twin is None and vs.name in dedupe_map:
                twin = by_name.get(dedupe_map[vs.name])
            if twin is None:
                gaps.append(f"visual lost: {page.name}/{vs.name}")
                continue
            if twin.query is None or twin.query.model_dump() != vs.query.model_dump():
                gaps.append(f"query changed: {page.name}/{vs.name}")

    for entry in manifest.entries:
        missing = entry.information_delta.get("missing") or []
        for item in missing:
            gaps.append(f"mapping declares missing on {entry.original['visual']}: {item}")

    coverage = {
        "measures": f"{len(o_measures & v_measures)}/{len(o_measures)}",
        "dimensions": f"{len(o_dims & v_dims)}/{len(o_dims)}",
        "slicers": f"{len(o_slicers & v_slicers)}/{len(o_slicers)}",
        "filters": f"{len(o_filters & v_filters)}/{len(o_filters)}",
        "visuals_mapped": f"{len(manifest.entries)}",
    }
    return ZeroLossResult(passed=not gaps, coverage=coverage, gaps=gaps)
