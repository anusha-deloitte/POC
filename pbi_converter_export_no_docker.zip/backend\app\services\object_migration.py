"""Smart source-object migration: map each SQL Server/PostgreSQL/... object to
its industry-standard Snowflake counterpart instead of flattening everything
into table copies.

Policy: the FULL GRANULAR dependency closure moves. Reports must stay correct
as incremental rows land in the source, so base facts are copied at grain —
never replaced by materialized snapshots — and every derived object is
recreated over those granular bases.

Mapping rules (documented per object in the result):
- base TABLE                -> Snowflake TABLE (schema + data copy, row-verified)
- VIEW                      -> Snowflake VIEW (definition transpiled via sqlglot,
                               schema references remapped, fully qualified names)
- INDEXED VIEW (SQL Server) -> Snowflake DYNAMIC TABLE over the migrated granular
  bases (auto-refresh semantics preserved via TARGET_LAG); falls back to a plain
  VIEW if dynamic-table creation is unavailable.
- STORED PROCEDURE          -> transpiled Snowflake SQL procedure; its table
  dependencies are included in the copy closure so it is callable immediately.
- A view result is materialized as a snapshot TABLE only when its definition
  cannot be read from the source catalog.

Every emitted DDL fully qualifies objects as "DB"."SCHEMA"."NAME".
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field

from app.binding.resolver import BindingMap
from app.services.migration import (
    MigrationResult,
    TableMigration,
    _qident,
    migrate_tables,
)


@dataclass
class SourceObjectInfo:
    schema: str
    name: str
    obj_type: str  # table | view | indexed_view | procedure
    definition: str | None = None
    # base relations the object references: [(schema, name)]
    dependencies: list[tuple[str, str]] = field(default_factory=list)
    row_count: int | None = None


@dataclass
class ObjectDecision:
    source: str  # schema.name
    source_type: str
    target: str  # schema.name in Snowflake
    target_type: str  # table | view | table (materialized snapshot) | procedure
    reason: str
    status: str = "planned"  # planned | done | failed | skipped
    detail: str | None = None


@dataclass
class ObjectMigrationResult:
    tables: MigrationResult = field(default_factory=MigrationResult)
    decisions: list[ObjectDecision] = field(default_factory=list)
    # model table -> (target_schema, target_object, object_kind) for bundle rewrite
    bindings_out: dict[str, tuple[str, str, str]] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.tables.ok and not any(d.status == "failed" for d in self.decisions)

    def summary(self) -> dict:
        base = self.tables.summary()
        base["objects"] = [
            {
                "source": d.source,
                "source_type": d.source_type,
                "target": d.target,
                "target_type": d.target_type,
                "reason": d.reason,
                "status": d.status,
                "detail": d.detail,
            }
            for d in self.decisions
        ]
        base["ok"] = self.ok
        return base


# ---------------------------------------------------------------------------
# introspection
# ---------------------------------------------------------------------------


def introspect_objects(
    src_cursor, source_kind: str, targets: list[tuple[str, str]]
) -> dict[tuple[str, str], SourceObjectInfo]:
    """Classify each (schema, name) the report reads. Unknown/failed lookups
    default to plain tables so simpler sources keep working unchanged."""
    out: dict[tuple[str, str], SourceObjectInfo] = {}
    for schema, name in targets:
        out[(schema.upper(), name.upper())] = SourceObjectInfo(
            schema=schema, name=name, obj_type="table"
        )
    if source_kind == "sqlserver":
        _introspect_sqlserver(src_cursor, out)
    elif source_kind in ("postgres", "mysql"):
        _introspect_information_schema_views(src_cursor, source_kind, out)
    return out


def _introspect_sqlserver(cur, out: dict[tuple[str, str], SourceObjectInfo]) -> None:
    try:
        cur.execute(
            "SELECT s.name, o.name, o.type_desc, m.definition, "
            " CASE WHEN EXISTS (SELECT 1 FROM sys.indexes i "
            "   WHERE i.object_id = o.object_id AND i.index_id = 1) "
            " THEN 1 ELSE 0 END AS is_indexed "
            "FROM sys.objects o "
            "JOIN sys.schemas s ON o.schema_id = s.schema_id "
            "LEFT JOIN sys.sql_modules m ON o.object_id = m.object_id "
            "WHERE o.type IN ('U','V')"
        )
        rows = cur.fetchall()
    except Exception:  # noqa: BLE001 - introspection is best-effort
        return
    catalog = {}
    for schema, name, type_desc, definition, is_indexed in rows:
        catalog[(schema.upper(), name.upper())] = (schema, name, type_desc, definition, is_indexed)
    for key, info in out.items():
        hit = catalog.get(key)
        if hit is None:
            continue
        schema, name, type_desc, definition, is_indexed = hit
        info.schema, info.name = schema, name
        if type_desc == "VIEW":
            info.obj_type = "indexed_view" if is_indexed else "view"
            info.definition = definition
            info.dependencies = _sqlserver_dependencies(cur, schema, name)
            info.row_count = _sqlserver_closure_rows(cur, info.dependencies)


def _sqlserver_dependencies(cur, schema: str, name: str) -> list[tuple[str, str]]:
    try:
        cur.execute(
            "SELECT DISTINCT rs.name, ro.name "
            "FROM sys.sql_expression_dependencies d "
            "JOIN sys.objects o ON d.referencing_id = o.object_id "
            "JOIN sys.schemas s ON o.schema_id = s.schema_id "
            "JOIN sys.objects ro ON d.referenced_id = ro.object_id "
            "JOIN sys.schemas rs ON ro.schema_id = rs.schema_id "
            "WHERE s.name = ? AND o.name = ? AND ro.type = 'U'",
            (schema, name),
        )
        return [(r[0], r[1]) for r in cur.fetchall()]
    except Exception:  # noqa: BLE001
        return []


def _sqlserver_closure_rows(cur, deps: list[tuple[str, str]]) -> int | None:
    if not deps:
        return None
    total = 0
    for schema, name in deps:
        try:
            cur.execute(
                "SELECT SUM(p.rows) FROM sys.tables t "
                "JOIN sys.schemas s ON t.schema_id = s.schema_id "
                "JOIN sys.partitions p ON t.object_id = p.object_id AND p.index_id IN (0,1) "
                "WHERE s.name = ? AND t.name = ?",
                (schema, name),
            )
            total += int(cur.fetchone()[0] or 0)
        except Exception:  # noqa: BLE001
            return None
    return total


def _introspect_information_schema_views(
    cur, source_kind: str, out: dict[tuple[str, str], SourceObjectInfo]
) -> None:
    placeholder = "%s"
    for info in out.values():
        try:
            cur.execute(
                "SELECT view_definition FROM information_schema.views "
                f"WHERE UPPER(table_schema) = UPPER({placeholder}) "
                f"AND UPPER(table_name) = UPPER({placeholder})",
                (info.schema, info.name),
            )
            row = cur.fetchone()
        except Exception:  # noqa: BLE001
            return
        if row and row[0]:
            info.obj_type = "view"
            info.definition = row[0]


# ---------------------------------------------------------------------------
# view transpilation (T-SQL -> Snowflake, schema remap, full qualification)
# ---------------------------------------------------------------------------

_SCHEMABINDING_RE = re.compile(r"\bWITH\s+SCHEMABINDING\b", re.IGNORECASE)
_CREATE_VIEW_RE = re.compile(
    r"^\s*CREATE\s+(?:OR\s+ALTER\s+)?VIEW\s+.*?\bAS\b", re.IGNORECASE | re.DOTALL
)
_SRC_DIALECT = {"sqlserver": "tsql", "postgres": "postgres", "mysql": "mysql", "oracle": "oracle"}


def transpile_view_definition(
    definition: str,
    source_kind: str,
    schema_map: dict[str, str],
    target_db: str,
    target_schema: str,
    view_name: str,
) -> str:
    """Return a fully-qualified Snowflake CREATE OR REPLACE VIEW statement."""
    import sqlglot
    from sqlglot import exp

    body = _SCHEMABINDING_RE.sub("", definition)
    tree = sqlglot.parse_one(body, read=_SRC_DIALECT.get(source_kind, "tsql"))
    # sys.sql_modules returns the full CREATE VIEW (often preceded by comments);
    # unwrap to the SELECT so we can emit our own fully-qualified CREATE
    if isinstance(tree, exp.Create):
        tree = tree.expression

    def requalify(node: exp.Expression) -> exp.Expression:
        if isinstance(node, exp.Table):
            src_schema = node.text("db") or ""
            mapped = schema_map.get(src_schema.upper())
            if mapped:
                node.set("db", exp.to_identifier(mapped, quoted=True))
                node.set("catalog", exp.to_identifier(target_db.upper(), quoted=True))
        return node

    tree = tree.transform(requalify).transform(_snowflake_legal_types)
    select_sql = tree.sql(dialect="snowflake")
    fq_view = f"{_qident(target_db)}.{_qident(target_schema)}.{_qident(view_name)}"
    return f"CREATE OR REPLACE VIEW {fq_view} AS\n{select_sql}"


# source-engine types with no Snowflake equivalent -> nearest legal type
_TYPE_SUBSTITUTIONS = {
    "BIT": "BOOLEAN",
    "UTINYINT": "SMALLINT",
    "TINYINT": "SMALLINT",
    "DATETIME2": "TIMESTAMP_NTZ",
    "SMALLDATETIME": "TIMESTAMP_NTZ",
    "UNIQUEIDENTIFIER": "VARCHAR",
    "MONEY": "NUMBER(19,4)",
    "SMALLMONEY": "NUMBER(10,4)",
}


def _snowflake_legal_types(node):
    from sqlglot import exp

    if isinstance(node, exp.DataType):
        name = node.sql(dialect="snowflake").upper()
        sub = _TYPE_SUBSTITUTIONS.get(name)
        if sub:
            return exp.DataType.build(sub, dialect="snowflake")
    # Snowflake cannot CAST(boolean AS numeric); the source's bit columns land
    # as BOOLEAN after migration -> route numeric casts through IFF
    if isinstance(node, exp.Cast):
        to = node.to.sql(dialect="snowflake").upper()
        if to in ("FLOAT", "DOUBLE", "INT", "SMALLINT", "BIGINT") or to.startswith("NUMBER"):
            inner = node.this
            if isinstance(inner, exp.Column) and _looks_boolean(inner.name):
                return exp.func(
                    "IFF", inner.copy(), exp.Literal.number(1), exp.Literal.number(0)
                )
    return node


def _looks_boolean(column_name: str) -> bool:
    return column_name.upper().startswith(("IS_", "HAS_", "FLAG_")) or column_name.upper().endswith(
        ("_FLAG", "_IND", "_YN")
    )


_PROC_NAME_RE = re.compile(
    r"CREATE\s+(?:OR\s+ALTER\s+)?PROC(?:EDURE)?\s+(?:\[?[\w]+\]?\.)?\[?([\w]+)\]?",
    re.IGNORECASE,
)


def transpile_procedure(
    definition: str,
    source_kind: str,
    schema_map: dict[str, str],
    target_db: str,
    target_schema: str,
) -> tuple[str, str] | None:
    """Best-effort proc translation -> (proc_name, CREATE PROCEDURE sql)."""
    import sqlglot
    from sqlglot import exp

    name_m = _PROC_NAME_RE.search(definition)
    if not name_m:
        return None
    proc_name = name_m.group(1)
    # strip everything up to the procedure's AS (header may be preceded by
    # comment banners that contain the words AS/BEGIN — anchor on the header)
    hdr_end = name_m.end()
    body_m = re.search(
        r"\bAS\b\s*(?:\bBEGIN\b)?(.*?)(?:\bEND\b\s*;?\s*)?$",
        definition[hdr_end:],
        re.IGNORECASE | re.DOTALL,
    )
    body = body_m.group(1) if body_m else definition[hdr_end:]
    # strip T-SQL-isms with no Snowflake equivalent
    body = re.sub(r"\bSET\s+(NOCOUNT|XACT_ABORT)\s+(ON|OFF)\s*;?", "", body, flags=re.IGNORECASE)
    body = re.sub(r"\bUPDATE\s+STATISTICS\s+[^;]+;?", "", body, flags=re.IGNORECASE)

    statements = []
    for stmt in sqlglot.parse(body, read=_SRC_DIALECT.get(source_kind, "tsql")):
        if stmt is None:
            continue

        def requalify(node: exp.Expression) -> exp.Expression:
            if isinstance(node, exp.Table):
                src_schema = node.text("db") or ""
                mapped = schema_map.get(src_schema.upper())
                if mapped:
                    node.set("db", exp.to_identifier(mapped, quoted=True))
                    node.set("catalog", exp.to_identifier(target_db.upper(), quoted=True))
            return node

        stmt = stmt.transform(requalify)
        # T-SQL allows `WITH ctes MERGE ...`; Snowflake does not — push the
        # CTEs down into the USING subquery instead (sqlglot stores the
        # leading WITH of a Merge under 'with' or 'with_' depending on version)
        if isinstance(stmt, exp.Merge):
            with_key = next((k for k in ("with", "with_") if stmt.args.get(k)), None)
            ctes = stmt.args.pop(with_key) if with_key else None
            if ctes is not None:
                using = stmt.args.get("using")
                target_select = None
                node = using
                while node is not None and target_select is None:
                    if isinstance(node, exp.Select):
                        target_select = node
                        break
                    node = getattr(node, "this", None) if isinstance(node, exp.Expression) else None
                if target_select is not None:
                    # arg key differs across sqlglot versions ('with' vs 'with_')
                    select_with_key = "with_" if "with_" in target_select.arg_types else "with"
                    target_select.set(select_with_key, ctes)
                else:
                    stmt.set(with_key, ctes)  # leave as-is; better to fail loudly
            _snowflakeify_merge_whens(stmt)
        statements.append(stmt.sql(dialect="snowflake"))
    if not statements:
        return None
    fq_proc = f"{_qident(target_db)}.{_qident(target_schema)}.{_qident(proc_name)}"
    scripted = ";\n  ".join(statements)
    sql = (
        f"CREATE OR REPLACE PROCEDURE {fq_proc}()\n"
        "RETURNS VARCHAR\nLANGUAGE SQL\nAS\n$$\nBEGIN\n  "
        f"{scripted};\n  RETURN 'ok';\nEND;\n$$"
    )
    return proc_name, sql


# ---------------------------------------------------------------------------
# orchestrator
# ---------------------------------------------------------------------------


def migrate_objects(
    binding_map: BindingMap,
    source_conn,
    source_kind: str,
    sf_cursor,
    target_database: str,
    target_schema: str,
    batch_size: int = 100_000,
    warehouse: str | None = None,
    copy_data: bool = True,
    on_progress=None,
) -> ObjectMigrationResult:
    """Type-aware migration of the FULL granular closure: every base table any
    report view or refresh procedure depends on is copied at grain; views are
    recreated as views, indexed views as dynamic tables, procs as procedures.
    copy_data=False creates/reconciles every object but moves no rows."""
    emit = on_progress or (lambda *_: None)
    result = ObjectMigrationResult()
    src_cur = source_conn.cursor()

    report_bindings = list(binding_map.needs_migration)
    targets = [(b.source_schema or "", b.source_object or "") for b in report_bindings]
    objects = introspect_objects(src_cur, source_kind, targets)

    report_schemas = {b.source_schema.upper() for b in report_bindings if b.source_schema}
    # schema map: the report's schema -> target schema; base schemas get suffixes
    schema_map: dict[str, str] = {s: target_schema.upper() for s in report_schemas}

    def map_schema(src: str) -> str:
        key = src.upper()
        if key not in schema_map:
            schema_map[key] = f"{target_schema}__{key}".upper()
        return schema_map[key]

    # ---- classify and plan --------------------------------------------------
    plain: list = []  # bindings to run through the standard table mover
    views: list[tuple] = []  # (binding, SourceObjectInfo)
    base_tables: dict[tuple[str, str], None] = {}

    for b in report_bindings:
        info = objects.get(((b.source_schema or "").upper(), (b.source_object or "").upper()))
        if info is None or info.obj_type == "table":
            plain.append(b)
            continue
        if info.obj_type in ("view", "indexed_view") and info.definition:
            views.append((b, info))
            for dep in info.dependencies:
                base_tables[(dep[0], dep[1])] = None
        else:
            # opaque view (definition unreadable): materialize its result
            result.decisions.append(
                ObjectDecision(
                    source=f"{b.source_schema}.{b.source_object}",
                    source_type=info.obj_type,
                    target=f"{target_schema}.{(b.source_object or '').upper()}",
                    target_type="table (materialized snapshot)",
                    reason="view definition unavailable in source catalog; "
                    "materialized the view result",
                )
            )
            plain.append(b)

    # refresh procedures' table dependencies join the closure so the migrated
    # proc is CALLable and incremental loads keep flowing after cutover
    already_bound = {
        ((b.source_schema or "").upper(), (b.source_object or "").upper())
        for b in report_bindings
    }
    for dep_schema, dep_name in _proc_table_dependencies(src_cur, source_kind, report_schemas):
        if (dep_schema.upper(), dep_name.upper()) in already_bound:
            continue  # migrated as a report table already
        base_tables[(dep_schema, dep_name)] = None

    # ---- migrate base tables (dependency closure) ---------------------------
    from app.binding.resolver import TableBinding

    # migrate base tables grouped per source schema — each schema keeps its own
    # mapped target schema so cross-schema names never collide
    by_schema: dict[str, list[str]] = {}
    for schema, name in base_tables:
        by_schema.setdefault(schema, []).append(name)
    for schema, names in by_schema.items():
        base_bm = BindingMap()
        for name in names:
            key = f"__base__{schema}.{name}"
            base_bm.bindings[key] = TableBinding(
                table=key,
                status="needs_migration",
                source_kind=source_kind,
                source_schema=schema,
                source_object=name,
            )
        base_target_schema = map_schema(schema)
        emit("bases", f"migrating {len(names)} base tables into {base_target_schema}")
        base_result = migrate_tables(
            base_bm,
            source_conn,
            source_kind,
            sf_cursor,
            target_database,
            base_target_schema,
            batch_size=batch_size,
            copy_data=copy_data,
            on_progress=emit,
        )
        result.tables.tables.extend(base_result.tables)
        for t in base_result.tables:
            result.decisions.append(
                ObjectDecision(
                    source=f"{t.source_schema}.{t.source_object}",
                    source_type="table",
                    target=f"{t.target_schema}.{t.target_object}",
                    target_type="table" if not t.copy_skipped else "table (schema only)",
                    reason="granular base table (report views / refresh procedure closure)",
                    status="done" if (t.verified or t.copy_skipped) else "failed",
                    detail=t.error or ("data copy skipped by request" if t.copy_skipped else None),
                )
            )

    # ---- migrate report-level plain tables (and materialized snapshots) -----
    plain_bm = BindingMap()
    for b in plain:
        plain_bm.bindings[b.table] = b
    if plain_bm.bindings:
        plain_result = migrate_tables(
            plain_bm,
            source_conn,
            source_kind,
            sf_cursor,
            target_database,
            target_schema,
            batch_size=batch_size,
            copy_data=copy_data,
            on_progress=emit,
        )
        result.tables.tables.extend(plain_result.tables)
        for t in plain_result.tables:
            ok = t.verified or t.copy_skipped
            if not any(d.source == f"{t.source_schema}.{t.source_object}" for d in result.decisions):
                result.decisions.append(
                    ObjectDecision(
                        source=f"{t.source_schema}.{t.source_object}",
                        source_type="table",
                        target=f"{t.target_schema}.{t.target_object}",
                        target_type="table" if not t.copy_skipped else "table (schema only)",
                        reason="report reads this table directly",
                        status="done" if ok else "failed",
                        detail=t.error or ("data copy skipped by request" if t.copy_skipped else None),
                    )
                )
            else:
                for d in result.decisions:
                    if d.source == f"{t.source_schema}.{t.source_object}":
                        d.status = "done" if ok else "failed"
                        d.detail = t.error
        for t in plain_result.tables:
            if t.verified or t.copy_skipped:
                result.bindings_out[t.model_table] = (target_schema, t.target_object, "Table")

    # ---- recreate views over migrated granular bases -------------------------
    for b, info in views:
        view_name = (b.source_object or "").upper()
        is_indexed = info.obj_type == "indexed_view"
        decision = ObjectDecision(
            source=f"{b.source_schema}.{b.source_object}",
            source_type=info.obj_type,
            target=f"{target_schema}.{view_name}",
            target_type="dynamic table" if is_indexed else "view",
            reason=(
                "indexed view -> dynamic table over granular bases "
                "(auto-refresh preserved via TARGET_LAG)"
                if is_indexed
                else "regular view; base tables migrated, definition transpiled "
                f"({_SRC_DIALECT.get(source_kind, source_kind)} -> snowflake)"
            ),
        )
        result.decisions.append(decision)
        try:
            ddl = transpile_view_definition(
                info.definition or "",
                source_kind,
                schema_map,
                target_database,
                target_schema,
                view_name,
            )
            kind_out = "View"
            if is_indexed:
                select_sql = ddl.split(" AS\n", 1)[1]
                fq_dt = f"{_qident(target_database)}.{_qident(target_schema)}.{_qident(view_name)}"
                try:
                    sf_cursor.execute(f"DROP VIEW IF EXISTS {fq_dt}")
                    sf_cursor.execute(f"DROP TABLE IF EXISTS {fq_dt}")
                    sf_cursor.execute(
                        f"CREATE OR REPLACE DYNAMIC TABLE {fq_dt} "
                        f"TARGET_LAG = '1 hour' WAREHOUSE = {_qident(warehouse or 'COMPUTE_WH')} "
                        f"AS {select_sql}"
                    )
                    # dynamic tables initialize asynchronously; wait for first refresh
                    # (skip when no data was copied — there is nothing to wait for)
                    for _ in range(60 if copy_data else 0):
                        try:
                            sf_cursor.execute(f"SELECT COUNT(*) FROM {fq_dt}")  # noqa: S608
                            if int(sf_cursor.fetchone()[0]) > 0:
                                break
                        except Exception:  # noqa: BLE001 - still initializing
                            pass
                        time.sleep(5)
                except Exception as dt_err:  # noqa: BLE001 - fall back to a view
                    emit(b.table, f"dynamic table unavailable ({str(dt_err)[:80]}); using VIEW")
                    decision.target_type = "view (dynamic-table fallback)"
                    sf_cursor.execute(ddl)
            else:
                sf_cursor.execute(ddl)
            # verify: object queryable and row counts match the source view
            fq = f"{_qident(target_database)}.{_qident(target_schema)}.{_qident(view_name)}"
            sf_cursor.execute(f"SELECT COUNT(*) FROM {fq}")  # noqa: S608
            tgt_rows = int(sf_cursor.fetchone()[0])
            src_cur.execute(
                f"SELECT COUNT(*) FROM {_quote_src_pair(source_kind, b.source_schema, b.source_object)}"  # noqa: S608
            )
            src_rows = int(src_cur.fetchone()[0])
            if not copy_data:
                # schema-only: the view compiled and is queryable; row parity is
                # meaningless until the customer's pipeline lands the data
                decision.status = "done"
                decision.detail = (
                    f"created (schema-only run); queryable, {tgt_rows:,} rows present "
                    f"vs {src_rows:,} at source — parity deferred to data provisioning"
                )
                b.status = "resolved"
                b.database = target_database
                b.schema_name = target_schema
                b.object_name = view_name
                b.object_kind = kind_out
                b.detail = decision.detail
                result.bindings_out[b.table] = (target_schema, view_name, kind_out)
                emit(b.table, f"{decision.target_type} {view_name} created (schema-only)")
            elif tgt_rows != src_rows:
                decision.status = "failed"
                decision.detail = f"row mismatch: source view {src_rows:,}, target view {tgt_rows:,}"
            else:
                decision.status = "done"
                decision.detail = f"{tgt_rows:,} rows verified"
                b.status = "resolved"
                b.database = target_database
                b.schema_name = target_schema
                b.object_name = view_name
                b.object_kind = kind_out
                b.detail = f"{decision.target_type} recreated over granular bases ({tgt_rows:,} rows verified)"
                result.bindings_out[b.table] = (target_schema, view_name, kind_out)
                emit(b.table, f"{decision.target_type} {view_name} verified ({tgt_rows:,} rows)")
        except Exception as e:  # noqa: BLE001 - per-object isolation
            decision.status = "failed"
            decision.detail = str(e)
            emit(b.table, f"view transpile/deploy FAILED: {e}")

    # ---- stored procedures referencing migrated objects (best effort) -------
    if source_kind == "sqlserver":
        _migrate_sqlserver_procs(
            src_cur,
            sf_cursor,
            report_schemas,
            schema_map,
            target_database,
            target_schema,
            result,
            emit,
        )

    return result


def _quote_src_pair(source_kind: str, schema: str, obj: str) -> str:
    from app.services.migration import _quote_src

    return f"{_quote_src(source_kind, schema)}.{_quote_src(source_kind, obj)}"


def _proc_table_dependencies(
    src_cur, source_kind: str, report_schemas: set[str]
) -> list[tuple[str, str]]:
    """Base tables referenced by stored procedures in the report's schemas —
    they join the copy closure so refresh logic works after cutover."""
    if source_kind != "sqlserver" or not report_schemas:
        return []
    try:
        placeholders = ", ".join(["?"] * len(report_schemas))
        src_cur.execute(
            "SELECT DISTINCT rs.name, ro.name "
            "FROM sys.sql_expression_dependencies d "
            "JOIN sys.objects o ON d.referencing_id = o.object_id "
            "JOIN sys.schemas s ON o.schema_id = s.schema_id "
            "JOIN sys.objects ro ON d.referenced_id = ro.object_id "
            "JOIN sys.schemas rs ON ro.schema_id = rs.schema_id "
            f"WHERE o.type = 'P' AND UPPER(s.name) IN ({placeholders}) AND ro.type = 'U'",  # noqa: S608
            tuple(report_schemas),
        )
        return [(r[0], r[1]) for r in src_cur.fetchall()]
    except Exception:  # noqa: BLE001 - introspection is best-effort
        return []


def _migrate_sqlserver_procs(
    src_cur,
    sf_cursor,
    report_schemas: set[str],
    schema_map: dict[str, str],
    target_database: str,
    target_schema: str,
    result: ObjectMigrationResult,
    emit,
) -> None:
    try:
        placeholders = ", ".join(["?"] * len(report_schemas))
        src_cur.execute(
            "SELECT s.name, o.name, m.definition FROM sys.objects o "
            "JOIN sys.schemas s ON o.schema_id = s.schema_id "
            "JOIN sys.sql_modules m ON o.object_id = m.object_id "
            f"WHERE o.type = 'P' AND UPPER(s.name) IN ({placeholders})",  # noqa: S608
            tuple(report_schemas),
        )
        procs = src_cur.fetchall()
    except Exception:  # noqa: BLE001
        return
    for schema, name, definition in procs:
        decision = ObjectDecision(
            source=f"{schema}.{name}",
            source_type="procedure",
            target=f"{target_schema}.{name.upper()}",
            target_type="procedure",
            reason="refresh logic transpiled to a Snowflake SQL procedure "
            "(schedule as a TASK to replace the SQL Agent job)",
        )
        result.decisions.append(decision)
        try:
            out = transpile_procedure(
                definition, "sqlserver", schema_map, target_database, target_schema
            )
            if out is None:
                decision.status = "skipped"
                decision.detail = "could not parse procedure body"
                continue
            _, sql = out
            sf_cursor.execute(sql)
            decision.status = "done"
            unmigrated = _proc_unmigrated_refs(sql, sf_cursor)
            decision.detail = (
                "deployed; references not yet migrated (migrate before CALL): "
                + ", ".join(unmigrated)
                if unmigrated
                else "deployed and callable"
            )
            emit(name, f"procedure {name} transpiled and deployed")
        except Exception as e:  # noqa: BLE001
            decision.status = "failed"
            decision.detail = str(e)
            emit(name, f"procedure transpile FAILED: {e}")


def _snowflakeify_merge_whens(stmt) -> None:
    """Snowflake MERGE supports only MATCHED UPDATE/DELETE and NOT MATCHED
    INSERT. T-SQL's `WHEN NOT MATCHED BY SOURCE THEN DELETE` (prune rows gone
    from the source) is emulated as MATCHED-with-guard is impossible, so it is
    dropped — safe for full-refresh MERGEs whose USING covers the whole grain;
    recorded in the emitted SQL as a comment."""
    from sqlglot import exp

    whens = stmt.args.get("whens")
    when_list = whens.expressions if isinstance(whens, exp.Whens) else (whens or [])
    kept = []
    for w in when_list:
        matched = bool(w.args.get("matched"))
        source = bool(w.args.get("source"))  # BY SOURCE flag
        then = w.args.get("then")
        is_insert = isinstance(then, exp.Insert)
        if not matched and source and not is_insert:
            continue  # NOT MATCHED BY SOURCE THEN DELETE/UPDATE: unsupported
        if not matched and not is_insert:
            continue  # NOT MATCHED must be INSERT in Snowflake
        w.args.pop("source", None)  # BY TARGET is implicit
        kept.append(w)
    if isinstance(whens, exp.Whens):
        whens.set("expressions", kept)
    elif whens is not None:
        stmt.set("whens", kept)


def _proc_unmigrated_refs(proc_sql: str, sf_cursor) -> list[str]:
    """Which fully-qualified tables in the proc body don't exist in Snowflake."""
    # skip the CREATE PROCEDURE header — only scan the body for table refs
    body = proc_sql.split("$$", 1)[1] if "$$" in proc_sql else proc_sql
    missing = []
    seen: set[tuple[str, str, str]] = set()
    # last part may be unquoted (sqlglot leaves simple identifiers bare)
    for m in re.finditer(r'"([A-Z0-9_]+)"\."([A-Z0-9_]+)"\.("?)([A-Za-z0-9_]+)\3', body):
        db, schema, name = m.group(1), m.group(2), m.group(4).upper()
        key = (db, schema, name)
        if key in seen:
            continue
        seen.add(key)
        try:
            sf_cursor.execute(
                "SELECT COUNT(*) FROM {}.INFORMATION_SCHEMA.TABLES "  # noqa: S608
                "WHERE table_schema = %s AND table_name = %s".format(f'"{db}"'),
                (schema, name),
            )
            if int(sf_cursor.fetchone()[0]) == 0:
                missing.append(f"{schema}.{name}")
        except Exception:  # noqa: BLE001
            continue
    return sorted(set(missing))
