from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.auth import router as auth_router
from app.api.connections import router as connections_router
from app.api.conversions import router as conversions_router
from app.api.governance import router as governance_router
from app.api.dashboards import router as dashboards_router
from app.api.semantic_deploy import router as semantic_deploy_router
from app.api.explain import router as explain_router
from app.api.source_connections import router as source_connections_router

app = FastAPI(
    title="PBI Converter",
    description="Agentic Power BI (.pbip) to React dashboard converter",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:8080"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(conversions_router)
app.include_router(connections_router)
app.include_router(governance_router)
app.include_router(dashboards_router)
app.include_router(semantic_deploy_router)
app.include_router(explain_router)
app.include_router(source_connections_router)


@app.get("/healthz")
def healthz() -> dict:
    return {"status": "ok"}
