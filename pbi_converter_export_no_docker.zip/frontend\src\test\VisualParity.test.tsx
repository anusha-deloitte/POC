import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { VisualParity } from '../steps/VisualParity'

function renderParity() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <VisualParity conversionId="conv-1" connectionId="conn-1" />
    </QueryClientProvider>,
  )
}

describe('VisualParity', () => {
  afterEach(() => vi.restoreAllMocks())

  it('renders parity workflow and no longer embeds reimagine controls', async () => {
    class ResizeObserverMock {
      observe() {}
      disconnect() {}
      unobserve() {}
    }
    vi.stubGlobal('ResizeObserver', ResizeObserverMock)
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        if (url.endsWith('/dashboard/spec')) {
          return new Response(
            JSON.stringify({
              report_name: 'Demo Report',
              pages: [
                { name: 'page_1', display_name: 'Overview', width: 1200, height: 800, ordinal: 0, visuals: [] },
              ],
              warnings: [],
              measure_tiers: {},
              theme: { data_colors: [], text_classes: {} },
              interaction_graph: { nodes: [], edges: [], sync_groups: {} },
              bookmarks: [],
              drill_through: [],
            }),
            { status: 200 },
          )
        }
        if (url.endsWith('/visual-compare')) return new Response(JSON.stringify({ pages: [] }), { status: 200 })
        if (url.endsWith('/visual-compare/references')) return new Response(JSON.stringify({ pages: [] }), { status: 200 })
        if (url.endsWith('/dashboard/query')) {
          return new Response(JSON.stringify({ results: {} }), { status: 200 })
        }
        return new Response(JSON.stringify({ detail: 'unexpected fetch: ' + url }), { status: 404 })
      }),
    )

    renderParity()
    expect(await screen.findByText('Visual parity review')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Compare all pages' })).toBeInTheDocument()
    expect(screen.queryByText('Reimagine dashboard')).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: 'Generate concept' })).not.toBeInTheDocument()
  })
})
