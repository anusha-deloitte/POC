"""Presentation fidelity: declared-metadata extraction, validation, and the
deterministic repair loop that patches compile gaps via spec overrides."""

from pathlib import Path

import pytest

from app.parsers.bundle import load_pbip
from app.runtime.dashboard import (
    _default_sort,
    compile_dashboard,
    extract_declared_presentation,
)

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_care_analytics"


@pytest.fixture(scope="module")
def bundle():
    return load_pbip(FIXTURE)


@pytest.fixture(scope="module")
def spec(bundle):
    s, _ = compile_dashboard(bundle)
    return s


def _raw(bundle, name):
    return next(v for p in bundle.report.pages for v in p.visuals if v.name == name)


def _compiled(spec, name):
    return next(v for p in spec.pages for v in p.visuals if v.name == name)


class TestDeclaredExtraction:
    def test_container_background_extracted(self, bundle):
        hdr = _raw(bundle, "p1hdr")
        declared = extract_declared_presentation(hdr)
        bg = declared.get("container_background")
        assert bg and bg["color"].startswith("#")

    def test_textbox_spec_carries_banner_background(self, spec):
        hdr = _compiled(spec, "p1hdr")
        assert "container_background" in hdr.options

    def test_axis_units_and_precision(self, bundle, spec):
        water = _raw(bundle, "p1water")
        declared = extract_declared_presentation(water)
        assert declared.get("axis_display_units") == 1000000
        assert declared.get("axis_precision") == 0
        compiled = _compiled(spec, "p1water")
        assert compiled.options.get("axis_display_units") == 1000000
        assert compiled.options.get("axis_precision") == 0

    def test_label_units_precision_on_donut(self, spec):
        donut = _compiled(spec, "p1donut")
        assert donut.options.get("display_units") == 1000000000
        assert donut.options.get("label_precision") == 1
        assert donut.options.get("legend_position") == "Right"

    def test_card_label_color_and_category_labels(self, spec):
        card = _compiled(spec, "p1k0")
        assert card.options.get("label_color", "").startswith("#")
        assert card.options.get("show_category_labels") is False
        assert card.options.get("label_precision") is not None

    def test_axis_title_extracted(self, spec):
        trend = _compiled(spec, "p1trend")
        assert trend.options.get("axis_title") == "PMPM ($)"
        assert trend.options.get("legend_position") == "Bottom"

    def test_matrix_totals_default_on(self, spec):
        mtx = _compiled(spec, "p1mtx")
        assert mtx.options.get("show_totals") is True
        assert mtx.options.get("column_headers_bold") is True
        assert mtx.options.get("grid_vertical") is True


class TestDefaultSort:
    def test_categorical_chart_sorts_category_asc(self, spec):
        """PBI default: category ascending — this drives both row order and the
        category→color assignment, so it must match the original exactly."""
        donut = _compiled(spec, "p1donut")
        assert donut.sort, "donut must get a default sort"
        assert donut.sort[0]["direction"] == "Ascending"
        assert donut.sort[0]["key"] == donut.dim_keys[0]

    def test_pivot_sorts_all_group_columns(self, spec):
        """Both row AND pivot-column dims sort ascending so month columns come
        out Jan..Dec via sortByColumn, not warehouse order."""
        heat = _compiled(spec, "p2heat")
        assert [s["key"] for s in heat.sort] == heat.dim_keys
        assert all(s["direction"] == "Ascending" for s in heat.sort)

    def test_table_sorts_first_dim_asc(self, spec):
        mtx = _compiled(spec, "p1mtx")
        assert mtx.sort
        assert mtx.sort[0]["direction"] == "Ascending"
        assert mtx.sort[0]["key"] == mtx.dim_keys[0]

    def test_default_sort_helper_no_fields(self):
        from app.ir.report import Visual

        v = Visual(name="x", visual_type="barChart")
        assert _default_sort(v, [], []) == []


class TestPresentationRepairAgent:
    def test_no_gaps_on_fresh_compile(self, bundle, spec):
        from app.agents.presentation_repair import presentation_gaps

        gaps = presentation_gaps(bundle, spec)
        assert gaps == [], f"fresh compile must carry all declared presentation: {gaps[:5]}"

    def test_gap_detected_and_proposed_when_option_lost(self, bundle):
        from app.agents.presentation_repair import presentation_gaps, propose_overrides

        s, _ = compile_dashboard(bundle)
        donut = _compiled(s, "p1donut")
        del donut.options["legend_position"]  # simulate a compiler gap
        gaps = presentation_gaps(bundle, s)
        assert any(g["key"] == "legend_position" and g["visual"] == "p1donut" for g in gaps)
        proposals = propose_overrides(gaps)
        fix = next(p for p in proposals if p["visual"] == "p1donut")
        assert fix == {
            "op": "set_option",
            "page": fix["page"],
            "visual": "p1donut",
            "key": "legend_position",
            "value": "Right",
        }

    def test_measure_format_gap_proposed(self, bundle):
        from app.agents.presentation_repair import presentation_gaps, propose_overrides

        s, _ = compile_dashboard(bundle)
        card = _compiled(s, "p1k0")
        assert "Total Cost of Care" in card.measure_formats
        card.measure_formats.pop("Total Cost of Care")
        gaps = presentation_gaps(bundle, s)
        gap = next(g for g in gaps if g["kind"] == "measure_format")
        proposals = propose_overrides([gap])
        assert proposals[0]["op"] == "set_measure_format"
        assert proposals[0]["measure"] == "Total Cost of Care"

    def test_repair_proposals_are_appliable_overrides(self, bundle, tmp_path):
        from app.agents.presentation_repair import presentation_gaps, propose_overrides
        from app.services.overrides import apply_overrides, validate_override

        s, _ = compile_dashboard(bundle)
        donut = _compiled(s, "p1donut")
        del donut.options["legend_position"]
        del donut.options["display_units"]
        proposals = propose_overrides(presentation_gaps(bundle, s))
        for p in proposals:
            assert validate_override(s, p) is None, p
        warnings = apply_overrides(s, proposals)
        assert warnings == []
        assert donut.options["legend_position"] == "Right"
        assert donut.options["display_units"] == 1000000000


class TestHarnessPresentationCheck:
    def test_declared_option_loss_fails_validation(self, bundle):
        from app.binding.resolver import build_binding_map
        from app.runtime.engine import SemanticEngine
        from app.validation.harness import CheckStatus, ValidationHarness

        s, bm = compile_dashboard(bundle)
        engine = SemanticEngine(bundle.model, bm)
        harness = ValidationHarness(engine, cursor=None, bundle=bundle)
        donut = _compiled(s, "p1donut")

        ok = harness._presentation_check(donut, page_name="01-executive-summary")
        assert ok is not None and ok.status == CheckStatus.PASSED

        broken = donut.model_copy(deep=True)
        del broken.options["legend_position"]
        bad = harness._presentation_check(broken, page_name="01-executive-summary")
        assert bad is not None and bad.status == CheckStatus.FAILED
        assert "legend_position" in bad.detail


class TestOverrideVocabulary:
    def test_typed_option_values_enforced(self, spec):
        from app.services.overrides import validate_override

        page = spec.pages[0].name
        base = {"op": "set_option", "page": page, "visual": "p1donut"}
        assert validate_override(spec, {**base, "key": "legend_position", "value": "Right"}) is None
        assert validate_override(spec, {**base, "key": "legend_position", "value": True}) is not None
        assert validate_override(spec, {**base, "key": "display_units", "value": 1000}) is None
        assert validate_override(spec, {**base, "key": "display_units", "value": True}) is not None
        assert validate_override(spec, {**base, "key": "show_totals", "value": True}) is None
        assert validate_override(spec, {**base, "key": "show_totals", "value": 1}) is not None
        assert (
            validate_override(
                spec, {**base, "key": "container_background", "value": {"color": "#123456"}}
            )
            is None
        )
