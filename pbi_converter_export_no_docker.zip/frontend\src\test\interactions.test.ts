import { describe, expect, it } from 'vitest'
import {
  buildVisualQueryFilters,
  emptyInteractionState,
  resolveVisualInteractions,
  toggleSelection,
} from '../dashboard/interactions'
import type { InteractionGraph, PageSpec, VisualSpec } from '../dashboard/types'

const visual: VisualSpec = {
  name: 'chart-1',
  visual_type: 'columnChart',
  x: 0,
  y: 0,
  width: 300,
  height: 200,
  z: 0,
  supported: true,
  dim_keys: ['sales.region'],
  column_keys: [],
  series_keys: [],
  measure_keys: ['sales.amount'],
  measure_roles: {},
  measure_formats: {},
  static_content: {},
  sort: [],
}

const page: PageSpec = {
  name: 'page-1',
  display_name: 'Page 1',
  width: 800,
  height: 600,
  ordinal: 0,
  visuals: [
    visual,
    {
      ...visual,
      name: 'chart-2',
    },
    {
      ...visual,
      name: 'chart-3',
    },
  ],
}

const graph: InteractionGraph = {
  nodes: ['chart-1', 'chart-2', 'chart-3'],
  edges: [
    { from_visual: 'chart-1', to_visual: 'chart-2', mode: 'filter' },
    { from_visual: 'chart-1', to_visual: 'chart-3', mode: 'highlight' },
  ],
  sync_groups: {},
}

describe('interaction helpers', () => {
  it('toggles a visual selection on repeat click', () => {
    const selected = toggleSelection(emptyInteractionState(), page.visuals[0], ['West'])
    expect(selected.selections['chart-1']).toEqual(['West'])

    const cleared = toggleSelection(selected, page.visuals[0], ['West'])
    expect(cleared.selections['chart-1']).toBeUndefined()
  })

  it('turns selection into page filters', () => {
    const state = toggleSelection(emptyInteractionState(), page.visuals[0], ['West'])
    const views = resolveVisualInteractions(page, graph, state)
    expect(views['chart-2'].filtered).toBe(true)
    expect(views['chart-3'].highlighted).toBe(true)

    const filters = buildVisualQueryFilters(page, graph, state, [
      { table: 'sales', column: 'year', values: [2025] },
    ])
    expect(filters['chart-1']).toEqual([{ table: 'sales', column: 'year', values: [2025] }])
    expect(filters['chart-2']).toEqual([
      { table: 'sales', column: 'year', values: [2025] },
      { table: 'sales', column: 'region', values: ['West'] },
    ])
    expect(filters['chart-3']).toEqual([{ table: 'sales', column: 'year', values: [2025] }])
  })
})