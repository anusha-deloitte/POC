"""Schema drift detection: compare compiled SQL column expectations against
current Snowflake INFORMATION_SCHEMA to surface stale bindings.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from app.binding.resolver import BindingMap


class DriftWarning(BaseModel):
    table: str
    column: str | None = None
    detail: str
    severity: str = "warning"  # warning | error


class DriftReport(BaseModel):
    database: str
    warnings: list[DriftWarning] = Field(default_factory=list)
    tables_checked: int = 0
    tables_ok: int = 0

    @property
    def has_drift(self) -> bool:
        return bool(self.warnings)


def detect_schema_drift(
    binding_map: BindingMap,
    cursor,
    database: str,
) -> DriftReport:
    """Check each resolved binding against INFORMATION_SCHEMA.

    Returns a DriftReport with warnings for:
    - Tables that no longer exist
    - Columns that were renamed or dropped
    """
    # Load current schema
    try:
        cursor.execute(
            f'SELECT table_schema, table_name, column_name FROM "{database}"'  # noqa: S608
            ".INFORMATION_SCHEMA.COLUMNS ORDER BY table_schema, table_name, column_name"
        )
        live_cols: dict[tuple[str, str], set[str]] = {}
        for schema, table, col in cursor.fetchall():
            key = (schema.upper(), table.upper())
            live_cols.setdefault(key, set()).add(col.upper())
    except Exception as e:
        return DriftReport(
            database=database,
            warnings=[DriftWarning(table="*", detail=f"Could not query INFORMATION_SCHEMA: {e}", severity="error")],
        )

    report = DriftReport(database=database)
    for binding in binding_map.bindings.values():
        if binding.status != "resolved" or binding.is_virtual or binding.native_query:
            continue
        if not binding.object_name or not binding.schema_name:
            continue

        report.tables_checked += 1
        key = (binding.schema_name.upper(), binding.object_name.upper())

        if key not in live_cols:
            report.warnings.append(DriftWarning(
                table=binding.table,
                detail=f"{binding.schema_name}.{binding.object_name} not found in INFORMATION_SCHEMA",
                severity="error",
            ))
            continue

        report.tables_ok += 1

        # Check for renamed columns via column_aliases
        if binding.column_aliases:
            for old_col, new_col in binding.column_aliases.items():
                if old_col.upper() not in live_cols[key] and new_col.upper() not in live_cols[key]:
                    report.warnings.append(DriftWarning(
                        table=binding.table,
                        column=old_col,
                        detail=f"Column {old_col!r} (renamed to {new_col!r} in M) not found in live schema",
                        severity="warning",
                    ))

    return report
