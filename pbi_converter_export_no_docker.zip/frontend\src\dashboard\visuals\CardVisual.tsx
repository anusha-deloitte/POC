import { formatValue, formatWithDisplayUnits } from '../format'
import { useGoodBad } from '../theme'
import type { VisualResult, VisualSpec } from '../types'

const VARIANCE_HINT = /variance|vs target|yoy|change|delta|growth/i

export function CardVisual({ spec, data }: { spec: VisualSpec; data?: VisualResult }) {
  const { good, bad } = useGoodBad()
  const key = spec.measure_keys[0]
  const idx = data?.columns.indexOf(key) ?? -1
  const raw = idx >= 0 ? (data?.rows[0]?.[idx] ?? null) : null
  const num = raw === null ? null : Number(raw)
  // declared data-label color wins; variance-style KPIs fall back to
  // semantic coloring (PBI conditional-formatting basics)
  const declaredColor = spec.options?.label_color as string | undefined
  const isVariance = VARIANCE_HINT.test(spec.title ?? key)
  const color =
    declaredColor ??
    (isVariance && num !== null && !Number.isNaN(num)
      ? num > 0
        ? bad // in cost dashboards, above target/growth = bad
        : good
      : undefined)
  const precision = spec.options?.label_precision as number | undefined
  const value = data
    ? spec.options?.display_units !== undefined || precision !== undefined
      ? formatWithDisplayUnits(
          raw,
          spec.measure_formats[key],
          spec.options?.display_units as number | undefined,
          precision,
        )
      : formatValue(raw, spec.measure_formats[key])
    : '…'
  const fontSize = spec.options?.label_font_size as number | undefined
  const fancy = spec.options?.style_variant === 'reimagined'
  // PBI card: container title on top, big value under it (category label hidden)
  const titleOnTop = (spec.options?.show_category_labels === false && !!spec.title) || fancy
  const label = (
    <span
      className={
        fancy
          ? 'truncate text-[10px] font-semibold uppercase tracking-wider text-surface-400'
          : 'truncate text-xs text-surface-500'
      }
    >
      {spec.title ?? key}
    </span>
  )
  if (fancy) {
    // executive KPI tile: accent bar + oversized value + semantic delta chip
    const chipTone =
      isVariance && num !== null && !Number.isNaN(num)
        ? num > 0
          ? { bg: '#FDECEA', fg: bad, sign: '▲' }
          : { bg: '#E8F6EE', fg: good, sign: '▼' }
        : null
    return (
      <div className="relative flex h-full w-full flex-col justify-center overflow-hidden px-4">
        <span
          className="absolute left-0 top-2 bottom-2 w-1 rounded-full"
          style={{ background: color ?? '#2E86AB' }}
        />
        {label}
        <span className="flex items-baseline gap-2">
          <span
            className="truncate text-3xl font-bold tracking-tight text-surface-800"
            style={color ? { color } : undefined}
            data-testid="card-value"
          >
            {value}
          </span>
          {chipTone && (
            <span
              className="shrink-0 rounded-full px-1.5 py-0.5 text-[9px] font-bold"
              style={{ background: chipTone.bg, color: chipTone.fg }}
            >
              {chipTone.sign}
            </span>
          )}
        </span>
      </div>
    )
  }
  return (
    <div className="flex h-full w-full flex-col items-center justify-center overflow-hidden">
      {titleOnTop && label}
      <span
        className="truncate text-2xl font-semibold text-surface-800"
        style={{
          ...(color ? { color } : {}),
          ...(fontSize ? { fontSize: `${fontSize * 1.33}px` } : {}),
        }}
        data-testid="card-value"
      >
        {value}
      </span>
      {!titleOnTop && label}
    </div>
  )
}
