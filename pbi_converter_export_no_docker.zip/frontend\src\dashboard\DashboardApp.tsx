import { useQuery } from '@tanstack/react-query'
import { useMemo, useState } from 'react'
import { fetchDashboardSpec, fetchVisualData } from './api'
import { ModeToggle, type QueryMode } from './ModeToggle'
import { PageCanvas, slicersToFilters } from './PageCanvas'
import {
  buildVisualQueryFilters,
  emptyInteractionState,
  resolveVisualInteractions,
} from './interactions'
import { ThemeProvider } from './theme'
import type { Bookmark, InteractionState, VisualSpec } from './types'

/** Standalone full-tab dashboard: #/dashboard/{conversionId}/{connectionId} */
export function DashboardApp({
  conversionId,
  connectionId,
}: {
  conversionId: string
  connectionId: string
}) {
  const [pageIdx, setPageIdx] = useState(0)
  const [mode, setMode] = useState<QueryMode>('live')
  const [slicerState, setSlicerState] = useState<Record<string, (string | number)[]>>({})
  const [interactionState, setInteractionState] = useState<InteractionState>(emptyInteractionState())

  const spec = useQuery({
    queryKey: ['dash-spec', conversionId],
    queryFn: () => fetchDashboardSpec(conversionId),
  })

  const page = spec.data?.pages[pageIdx]
  const pageByName = new Map(spec.data?.pages.map((p, idx) => [p.name, idx]) ?? [])
  const slicerFilters = useMemo(() => (page ? slicersToFilters(page, slicerState) : []), [page, slicerState])
  const visualInteractions = useMemo(
    () => (page && spec.data ? resolveVisualInteractions(page, spec.data.interaction_graph, interactionState) : {}),
    [page, spec.data, interactionState],
  )
  const filtersByVisual = useMemo(
    () =>
      page && spec.data
        ? buildVisualQueryFilters(page, spec.data.interaction_graph, interactionState, slicerFilters)
        : {},
    [page, spec.data, interactionState, slicerFilters],
  )

  const data = useQuery({
    queryKey: ['dash-data', conversionId, page?.name, filtersByVisual, mode],
    queryFn: () =>
      fetchVisualData(
        conversionId,
        connectionId,
        page!.name,
        page!.visuals.filter((v) => v.supported && v.query).map((v) => v.name),
        filtersByVisual,
        mode,
      ),
    enabled: !!page,
    placeholderData: (prev) => prev,
  })

  if (spec.isLoading)
    return <p className="p-8 text-surface-500">Loading dashboard…</p>
  if (spec.isError)
    return (
      <div role="alert" className="m-8 rounded-lg bg-red-50 p-4 text-sm text-red-700">
        {spec.error.message}
      </div>
    )

  const onSlicerChange = (visual: VisualSpec, values: (string | number)[]) =>
    setSlicerState((s) => ({ ...s, [visual.name]: values }))

  const applyBookmark = (bookmark: Bookmark) => {
    const state = bookmark.state as Record<string, unknown>
    const nextSelections = state.selections as Record<string, (string | number)[]> | undefined
    if (nextSelections) setInteractionState({ ...emptyInteractionState(), selections: nextSelections })
    const bookmarkPage =
      typeof state.page_name === 'string'
        ? state.page_name
        : typeof state.page === 'string'
          ? state.page
          : null
    if (bookmarkPage && pageByName.has(bookmarkPage)) {
      setPageIdx(pageByName.get(bookmarkPage) ?? 0)
    }
  }

  const goToDrillThrough = (pageName: string) => {
    const targetIdx = pageByName.get(pageName)
    if (targetIdx === undefined) return
    setPageIdx(targetIdx)
    setSlicerState({})
    setInteractionState(emptyInteractionState())
  }

  return (
    <div className="min-h-screen bg-surface-200">
      <header className="flex items-center justify-between border-b border-white/[0.08] bg-black px-6 py-3">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand to-brand-dark text-xs font-extrabold text-white">
            P
          </div>
          <div>
            <h1 className="text-sm font-bold text-white">{spec.data!.report_name}</h1>
            <p className="text-[10px] text-white/50">
              Converted from Power BI · live on Snowflake
              {data.isFetching ? ' · refreshing…' : ''}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <ModeToggle
            conversionId={conversionId}
            connectionId={connectionId}
            mode={mode}
            onChange={setMode}
            dark
          />
          <nav className="flex gap-1">
            {spec.data!.pages.map((p, i) => (
              <button
                key={p.name}
                onClick={() => {
                  setPageIdx(i)
                  setSlicerState({})
                  setInteractionState(emptyInteractionState())
                }}
                data-active={i === pageIdx}
                className="rounded-[10px] px-3 py-1.5 text-xs font-semibold text-gray-400 hover:bg-white/10 hover:text-white data-[active=true]:bg-brand/20 data-[active=true]:text-brand"
              >
                {p.display_name}
              </button>
            ))}
          </nav>
          {!!spec.data!.bookmarks.length && (
            <div className="hidden items-center gap-1 lg:flex">
              {spec.data!.bookmarks.slice(0, 3).map((bookmark) => (
                <button
                  key={bookmark.name}
                  onClick={() => applyBookmark(bookmark)}
                  className="rounded-[10px] border border-white/10 px-3 py-1.5 text-xs font-semibold text-white/70 hover:border-white/20 hover:bg-white/10 hover:text-white"
                >
                  {bookmark.name}
                </button>
              ))}
            </div>
          )}
          {!!spec.data!.drill_through.length && (
            <div className="hidden items-center gap-1 xl:flex">
              {spec.data!.drill_through.slice(0, 2).map((target) => (
                <button
                  key={`${target.page}-${target.fields.join('|')}`}
                  onClick={() => goToDrillThrough(target.page)}
                  className="rounded-[10px] border border-brand/30 px-3 py-1.5 text-xs font-semibold text-brand/90 hover:bg-brand/10"
                  title={target.fields.join(', ')}
                >
                  Drill: {target.page}
                </button>
              ))}
            </div>
          )}
        </div>
      </header>
      <main className="mx-auto max-w-[1400px] p-6">
        {data.isError && (
          <div role="alert" className="mb-3 rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
            {data.error.message}
          </div>
        )}
        {page && (
          <ThemeProvider value={spec.data!.theme}>
            <PageCanvas
              page={page}
              results={data.data ?? {}}
              slicerState={slicerState}
              onSlicerChange={onSlicerChange}
              interactionState={interactionState}
              onInteractionChange={setInteractionState}
              visualInteractions={visualInteractions}
            />
          </ThemeProvider>
        )}
      </main>
    </div>
  )
}
