import { formatValue } from '../format'
import type { VisualResult, VisualSpec } from '../types'
import { pivotResult } from './pivot'

export function TableVisual({
  spec,
  data,
  onSelect,
}: {
  spec: VisualSpec
  data?: VisualResult
  onSelect?: (values: (string | number)[]) => void
}) {
  if (!data) return <div className="p-2 text-xs text-surface-400">…</div>
  if (data.error) return <div className="p-2 text-xs text-brand-red">{data.error}</div>
  const { headers, rows, measureCols, formatFor } = pivotResult(spec, data)
  // grand-total row computed server-side at the empty-group context (PBI semantics)
  const totals = data.totals as { columns: string[]; row: unknown[] } | undefined | null
  const totalCells: (unknown | null)[] | null =
    spec.options?.show_totals && totals
      ? headers.map((h, i) => {
          if (i === 0) return 'Total'
          const ti = totals.columns.indexOf(h)
          return ti >= 0 ? totals.row[ti] : null
        })
      : null
  // in-cell data bars (reimagined): per-column max for proportional fills
  const dataBars = spec.options?.data_bars === true
  const colMax: Record<number, number> = {}
  if (dataBars) {
    for (const j of measureCols) {
      let mx = 0
      for (const row of rows) {
        const v = Math.abs(Number(row[j] ?? 0))
        if (Number.isFinite(v) && v > mx) mx = v
      }
      colMax[j] = mx || 1
    }
  }
  return (
    <div className="h-full w-full overflow-auto">
      <table className="w-full border-collapse text-[11px]">
        <thead className="sticky top-0 bg-surface-200">
          <tr>
            {headers.map((c, i) => (
              <th
                key={`${c}-${i}`}
                className={`border-b border-surface-400 px-2 py-1 font-semibold ${
                  measureCols.has(i) ? 'text-right' : 'text-left'
                }`}
              >
                {c.includes('.') ? c.split('.').pop() : c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr
              key={i}
              className={`odd:bg-white even:bg-surface-100 ${onSelect ? 'cursor-pointer hover:bg-brand/5' : ''}`}
              onClick={() => {
                if (!onSelect || !headers.length) return
                const firstDim = headers.findIndex((_, idx) => !measureCols.has(idx))
                if (firstDim >= 0) onSelect([String(row[firstDim] ?? '')])
              }}
            >
              {row.map((cell, j) => {
                const isMeasure = measureCols.has(j)
                const barPct =
                  dataBars && isMeasure
                    ? Math.min(Math.abs(Number(cell ?? 0)) / colMax[j], 1) * 100
                    : null
                return (
                  <td
                    key={j}
                    className={`relative border-b border-surface-200 px-2 py-1 ${
                      isMeasure ? 'text-right tabular-nums' : 'text-left'
                    }`}
                  >
                    {barPct !== null && (
                      <span
                        aria-hidden
                        className="absolute inset-y-0.5 left-0 rounded-r-sm bg-[#2E86AB]/15"
                        style={{ width: `${barPct}%` }}
                      />
                    )}
                    <span className="relative">
                      {isMeasure ? formatValue(cell, formatFor(j)) : String(cell ?? '')}
                    </span>
                  </td>
                )
              })}
            </tr>
          ))}
          {totalCells && (
            <tr className="border-t border-surface-400 bg-surface-100 font-bold" data-testid="totals-row">
              {totalCells.map((cell, j) => (
                <td
                  key={j}
                  className={`px-2 py-1 ${
                    measureCols.has(j) ? 'text-right tabular-nums' : 'text-left'
                  }`}
                >
                  {measureCols.has(j)
                    ? formatValue(cell as string | number | null, formatFor(j))
                    : String(cell ?? '')}
                </td>
              ))}
            </tr>
          )}
        </tbody>
      </table>
    </div>
  )
}
