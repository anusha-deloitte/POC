import type { EChartsOption } from 'echarts'
import { formatValue } from '../format'
import { usePalette } from '../theme'
import type { VisualResult, VisualSpec } from '../types'
import { niceCeil } from './ChartVisual'
import { EChart } from './EChart'

/** lineClusteredColumnComboChart: Y measures as columns, Y2 measures as lines on axis 2. */
export function ComboVisual({ spec, data }: { spec: VisualSpec; data?: VisualResult }) {
  const palette = usePalette()
  if (!data) return <div className="p-2 text-xs text-surface-400">…</div>
  if (data.error) return <div className="p-2 text-xs text-brand-red">{data.error}</div>

  const dimKey = spec.dim_keys[0]
  const di = data.columns.indexOf(dimKey)
  const categories = data.rows.map((r) => String(r[di] ?? ''))
  const colKeys = spec.measure_keys.filter((k) => spec.measure_roles[k] !== 'Y2')
  const lineKeys = spec.measure_keys.filter((k) => spec.measure_roles[k] === 'Y2')

  const series: NonNullable<EChartsOption['series']> = []
  for (const k of colKeys) {
    const i = data.columns.indexOf(k)
    series.push({
      name: k,
      type: 'bar',
      barMaxWidth: 20,
      data: data.rows.map((r) => (r[i] === null ? null : Number(r[i]))),
      tooltip: { valueFormatter: (v) => formatValue(v as number, spec.measure_formats[k]) },
    })
  }
  for (const k of lineKeys) {
    const i = data.columns.indexOf(k)
    series.push({
      name: k,
      type: 'line',
      yAxisIndex: 1,
      showSymbol: false,
      data: data.rows.map((r) => (r[i] === null ? null : Number(r[i]))),
      tooltip: { valueFormatter: (v) => formatValue(v as number, spec.measure_formats[k]) },
    })
  }

  const option: EChartsOption = {
    color: palette,
    grid: { left: 8, right: 8, top: 28, bottom: 4, containLabel: true },
    legend: { top: 0, itemHeight: 8, itemWidth: 12, textStyle: { fontSize: 10 } },
    tooltip: { trigger: 'axis' },
    xAxis: {
      type: 'category',
      data: categories,
      // PBI time axes label every point (rotated) instead of thinning
      axisLabel:
        categories.length > 12 && categories.length <= 40
          ? { fontSize: 8, interval: 0, rotate: 90 }
          : { fontSize: 9 },
    },
    // PBI virtualizes long time axes behind a scrollbar (~24 visible points);
    // the reimagined single-viewport layout shows the full series instead
    dataZoom:
      categories.length > 28 && spec.options?.style_variant !== 'reimagined'
        ? [
            {
              type: 'slider',
              xAxisIndex: 0,
              startValue: 0,
              endValue: 23,
              height: 10,
              bottom: 2,
              brushSelect: false,
              zoomLock: true,
              showDetail: false,
              fillerColor: 'rgba(160,174,192,0.35)',
              borderColor: 'transparent',
              backgroundColor: 'rgba(226,232,240,0.5)',
              handleSize: 0,
              moveHandleSize: 6,
            },
          ]
        : undefined,
    yAxis: [
      {
        type: 'value',
        max: niceCeil(
          Math.max(
            ...colKeys.map((k) => {
              const i = data.columns.indexOf(k)
              return Math.max(...data.rows.map((r) => Number(r[i] ?? 0)))
            }),
            0,
          ),
        ),
        axisLabel: {
          fontSize: 9,
          formatter: (v: number) => formatValue(v, spec.measure_formats[colKeys[0]]),
        },
      },
      {
        type: 'value',
        // PBI auto-scales the secondary axis tightly around the line's range
        ...(() => {
          const vals = lineKeys.flatMap((k) => {
            const i = data.columns.indexOf(k)
            return data.rows.map((r) => Number(r[i] ?? 0)).filter((v) => Number.isFinite(v))
          })
          if (!vals.length) return {}
          const lo = Math.min(...vals)
          const hi = Math.max(...vals)
          const span = hi - lo || Math.abs(hi) || 1
          const exp = Math.floor(Math.log10(span / 2))
          const base = Math.pow(10, exp)
          const f = span / 2 / base
          const interval = (f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10) * base
          return {
            min: Math.floor(lo / interval) * interval,
            max: Math.ceil(hi / interval) * interval,
          }
        })(),
        axisLabel: {
          fontSize: 9,
          formatter: (v: number) => formatValue(v, spec.measure_formats[lineKeys[0]]),
        },
        splitLine: { show: false },
      },
    ],
    series,
  }
  return <EChart option={option} />
}
