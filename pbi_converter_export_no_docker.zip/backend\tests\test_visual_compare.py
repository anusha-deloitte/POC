"""Vision parity agent with a scripted fake OpenAI client (offline)."""

import json

from app.agents.visual_compare import (
    CompareResult,
    compare_page_images,
    detect_slicer_state,
)


class FakeVision:
    def __init__(self, responses: list[str]):
        self._responses = list(responses)
        self.calls: list[list] = []
        outer = self

        class _Completions:
            def create(self, model, temperature, messages):
                outer.calls.append(messages)

                class _Msg:
                    content = outer._responses.pop(0)

                class _Choice:
                    message = _Msg()

                class _Resp:
                    choices = [_Choice()]

                return _Resp()

        class _Chat:
            completions = _Completions()

        self.chat = _Chat()


PNG = b"\x89PNG fake"
INVENTORY = [
    {"name": "p3ctr", "title": "Spend by Network Status and Tier",
     "visual_type": "clusteredColumnChart", "x": 798.0, "y": 474.0},
]


class TestVisualCompare:
    def test_valid_findings_parsed(self):
        payload = {
            "similarity": 72,
            "findings": [
                {
                    "region": "Spend by Network Status and Tier",
                    "severity": "high",
                    "kind": "series",
                    "difference": "Converted chart shows one series; original splits by tier.",
                    "recommendation": "Group by PROVIDER_TIER as chart series.",
                }
            ],
        }
        client = FakeVision([json.dumps(payload)])
        r = compare_page_images(PNG, PNG, INVENTORY, client=client)
        assert isinstance(r, CompareResult)
        assert r.similarity == 72
        assert r.findings[0]["kind"] == "series"
        assert r.error is None
        # inventory listed in the prompt so the model can name visuals
        prompt_text = client.calls[0][1]["content"][0]["text"]
        assert "Spend by Network Status and Tier" in prompt_text

    def test_retry_then_success(self):
        ok = json.dumps({"similarity": 95, "findings": []})
        client = FakeVision(["sorry, here you go:", ok])
        r = compare_page_images(PNG, PNG, INVENTORY, client=client)
        assert r.similarity == 95
        assert r.findings == []
        assert len(client.calls) == 2

    def test_unparseable_twice_errors(self):
        client = FakeVision(["nope", "still nope"])
        r = compare_page_images(PNG, PNG, INVENTORY, client=client)
        assert r.error is not None
        assert r.findings == []

    def test_bad_severity_and_kind_normalized(self):
        payload = {
            "similarity": 250,  # clamped
            "findings": [
                {"region": "x", "severity": "CRITICAL", "kind": "weird",
                 "difference": "d", "recommendation": "r"},
                {"not_a_finding": True},  # dropped: no difference
            ],
        }
        client = FakeVision([json.dumps(payload)])
        r = compare_page_images(PNG, PNG, INVENTORY, client=client)
        assert r.similarity == 100
        assert len(r.findings) == 1
        assert r.findings[0]["severity"] == "medium"
        assert r.findings[0]["kind"] == "layout"

    def test_no_client_and_no_key(self, monkeypatch):
        from app.core import config

        monkeypatch.setenv("PBIC_OPENAI_API_KEY", "")
        config.get_settings.cache_clear()
        r = compare_page_images(PNG, PNG, INVENTORY)
        assert r.error is not None
        config.get_settings.cache_clear()

    def test_filter_context_included_in_prompt(self):
        ok = json.dumps({"similarity": 97, "findings": []})
        client = FakeVision([ok])
        r = compare_page_images(
            PNG, PNG, INVENTORY, client=client, filter_context="Both images share Year=2024."
        )
        assert r.similarity == 97
        prompt_text = client.calls[0][1]["content"][0]["text"]
        assert "Year=2024" in prompt_text


SLICERS = [
    {"title": "Year", "options": [2023, 2024, 2025]},
    {"title": "State", "options": ["Texas", "Ohio"]},
]


class TestDetectSlicerState:
    def test_selections_parsed(self):
        payload = {"selections": [{"slicer": "Year", "value": "2024"}]}
        client = FakeVision([json.dumps(payload)])
        r = detect_slicer_state(PNG, SLICERS, client=client)
        assert r.error is None
        assert r.selections == [{"slicer": "Year", "value": "2024"}]
        # slicer inventory (with options) is in the prompt
        prompt_text = client.calls[0][1]["content"][0]["text"]
        assert "Year" in prompt_text and "2024" in prompt_text

    def test_empty_selections_means_unfiltered(self):
        client = FakeVision([json.dumps({"selections": []})])
        r = detect_slicer_state(PNG, SLICERS, client=client)
        assert r.selections == []
        assert r.error is None

    def test_retry_then_error(self):
        client = FakeVision(["not json", "still not json"])
        r = detect_slicer_state(PNG, SLICERS, client=client)
        assert r.error is not None
        assert r.selections == []

    def test_malformed_entries_dropped(self):
        payload = {"selections": [{"slicer": "Year", "value": "2024"}, {"bogus": 1}, "x"]}
        client = FakeVision([json.dumps(payload)])
        r = detect_slicer_state(PNG, SLICERS, client=client)
        assert r.selections == [{"slicer": "Year", "value": "2024"}]
