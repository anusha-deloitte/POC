import { BadgeCheck, Gauge, Lock, ShieldCheck } from 'lucide-react'
import { useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { login, signup } from '../auth'

const PROOF_POINTS = [
  { icon: BadgeCheck, text: 'Every measure numerically validated against your warehouse' },
  { icon: Gauge, text: 'Live Snowflake or in-memory accelerated serving modes' },
  { icon: Lock, text: 'Credentials encrypted at rest, key-pair auth first' },
]

export function Login() {
  const [params] = useSearchParams()
  const nav = useNavigate()
  const [mode, setMode] = useState<'signin' | 'signup'>(
    params.get('mode') === 'signup' ? 'signup' : 'signin',
  )
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setBusy(true)
    setError('')
    try {
      if (mode === 'signup') await signup(email, password, name)
      else await login(email, password)
      nav(params.get('next') ?? '/app', { replace: true })
    } catch (err) {
      setError((err as Error).message)
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="aurora-bg grid-pattern relative flex min-h-screen items-center justify-center overflow-hidden bg-surface-200 p-6">
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        <div className="absolute -top-24 -left-24 h-96 w-96 rounded-full bg-brand/15 blur-[110px]" />
        <div className="absolute right-0 bottom-0 h-96 w-96 rounded-full bg-brand-blue/10 blur-[110px]" />
      </div>

      <div className="relative grid w-full max-w-4xl overflow-hidden rounded-2xl border border-black/[0.06] shadow-card-hover md:grid-cols-[1.05fr_1fr]">
        {/* brand panel */}
        <div className="grid-pattern-dark relative hidden flex-col justify-between bg-surface-900 p-10 text-white md:flex">
          <div
            className="pointer-events-none absolute inset-0"
            aria-hidden
            style={{
              background:
                'radial-gradient(70% 50% at 20% 0%, rgba(134,188,37,0.22), transparent 65%), radial-gradient(60% 50% at 100% 100%, rgba(0,118,168,0.18), transparent 60%)',
            }}
          />
          <Link to="/" className="relative flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-brand to-brand-dark text-sm font-extrabold text-white">
              P
            </div>
            <span className="text-lg font-bold tracking-tight">PBI Converter</span>
          </Link>

          <div className="relative">
            <p className="kicker mb-3 !text-brand-light">Power BI → React, provably correct</p>
            <h2 className="mb-4 text-3xl leading-tight font-bold">
              Modernize reports without losing a single number.
            </h2>
            <ul className="space-y-3">
              {PROOF_POINTS.map(({ icon: Icon, text }) => (
                <li key={text} className="flex items-start gap-3 text-sm text-white/80">
                  <Icon size={17} strokeWidth={1.8} className="mt-0.5 shrink-0 text-brand" />
                  {text}
                </li>
              ))}
            </ul>
          </div>

          <div className="relative flex items-center gap-2 text-xs text-white/50">
            <ShieldCheck size={14} strokeWidth={1.8} className="text-brand" />
            Accuracy-gated conversion · Migration Health report on every run
          </div>
        </div>

        {/* form panel */}
        <div className="bg-surface-50/95 p-8 backdrop-blur-sm md:p-10">
          <Link to="/" className="mb-6 flex items-center gap-2.5 md:hidden">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand to-brand-dark text-xs font-extrabold text-white">
              P
            </div>
            <span className="font-bold">PBI Converter</span>
          </Link>

          <h1 className="mb-1 text-2xl font-bold">
            {mode === 'signup' ? 'Create your account' : 'Welcome back'}
          </h1>
          <p className="mb-6 text-sm text-surface-600">
            {mode === 'signup'
              ? 'The first account becomes the workspace admin.'
              : 'Sign in with your work email and password.'}
          </p>

          <form onSubmit={submit} className="space-y-4">
            {mode === 'signup' && (
              <label className="block">
                <span className="text-sm font-semibold text-surface-700">Name</span>
                <input
                  className="input mt-1.5"
                  value={name}
                  placeholder="Jane Analyst"
                  onChange={(e) => setName(e.target.value)}
                />
              </label>
            )}
            <label className="block">
              <span className="text-sm font-semibold text-surface-700">Email</span>
              <input
                className="input mt-1.5"
                type="email"
                required
                autoFocus
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </label>
            <label className="block">
              <span className="text-sm font-semibold text-surface-700">Password</span>
              <input
                className="input mt-1.5"
                type="password"
                required
                minLength={8}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </label>
            {error && (
              <div className="rounded-lg border border-brand-red/20 bg-brand-red/5 px-3 py-2 text-sm text-brand-red">
                {error}
              </div>
            )}
            <button className="btn-primary mt-1 w-full !py-2.5" disabled={busy}>
              {busy ? 'Working…' : mode === 'signup' ? 'Create account' : 'Sign in'}
            </button>
          </form>

          <div className="mt-6 border-t border-surface-300 pt-4 text-sm text-surface-600">
            {mode === 'signup' ? (
              <>
                Already registered?{' '}
                <button
                  className="font-semibold text-brand-dark hover:underline"
                  onClick={() => setMode('signin')}
                >
                  Sign in
                </button>
              </>
            ) : (
              <>
                New here?{' '}
                <button
                  className="font-semibold text-brand-dark hover:underline"
                  onClick={() => setMode('signup')}
                >
                  Create an account
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
