from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

_DEFAULT_STORAGE = Path.home() / ".pbic" / "storage"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="PBIC_", env_file=".env", extra="ignore")

    storage_dir: Path = _DEFAULT_STORAGE
    max_upload_bytes: int = 300 * 1024 * 1024  # PBIR service cap
    # Fernet key for connection-secret encryption; generated on first run in dev
    secrets_key_file: Path = _DEFAULT_STORAGE / ".secrets.key"
    api_token: str = ""  # empty = auth disabled (local dev only)
    openai_api_key: str = ""
    database_url: str = "postgresql://pbic:pbic@localhost:5432/pbic"


@lru_cache
def get_settings() -> Settings:
    return Settings()
