from fastapi.testclient import TestClient

from app.api.deps import (
    get_connection_store,
    get_dashboard_token_store,
    get_snowflake_session_manager,
)
from app.main import app
from app.services.connections import AuthMethod, ConnectionStore, SnowflakeProfileIn
from app.services.dashboard_tokens import DashboardTokenStore
from app.services.snowflake_sessions import SnowflakeSessionManager


class FakeCursor:
    def execute(self, sql, params=None):
        return self

    def fetchone(self):
        return ("9.0", "ROLE", "WH", "DB")

    def close(self):
        pass


class FakeConnection:
    closed = False

    def cursor(self):
        return FakeCursor()

    def is_closed(self):
        return self.closed

    def close(self):
        self.closed = True


def test_published_session_requires_scoped_token_and_can_authenticate(tmp_path):
    connection_store = ConnectionStore(tmp_path, tmp_path / ".key")
    profile = connection_store.create(
        SnowflakeProfileIn(
            name="sso",
            account="acct",
            user="u",
            auth_method=AuthMethod.EXTERNAL_BROWSER,
        )
    )
    sessions = SnowflakeSessionManager(
        connection_store, connect=lambda **kwargs: FakeConnection()
    )
    tokens = DashboardTokenStore(tmp_path, default_ttl_seconds=300)
    issued = tokens.create("conversion-1", profile.id)
    app.dependency_overrides[get_connection_store] = lambda: connection_store
    app.dependency_overrides[get_snowflake_session_manager] = lambda: sessions
    app.dependency_overrides[get_dashboard_token_store] = lambda: tokens
    try:
        with TestClient(app) as client:
            assert client.get("/api/v1/published/session").status_code == 401
            headers = {"Authorization": f"Bearer {issued.token}"}
            assert client.get("/api/v1/published/session", headers=headers).json() == {
                "authenticated": False
            }
            authenticated = client.post(
                "/api/v1/published/session/authenticate", headers=headers
            )
            assert authenticated.status_code == 200
            assert authenticated.json()["ok"] is True
            assert client.get("/api/v1/published/session", headers=headers).json() == {
                "authenticated": True
            }
    finally:
        sessions.close_all()
        app.dependency_overrides.clear()