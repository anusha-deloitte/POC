from typing import Annotated

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field

from app.api.dashboards import (
    AccelerateRequest,
    BatchQueryRequest,
    BatchQueryResponse,
    QueryExecutionTier,
    VisualQuery,
    accelerate,
    acceleration_status,
    batch_query,
    get_dashboard_spec,
)
from app.api.deps import (
    get_connection_store,
    get_dashboard_token_store,
    get_snowflake_session_manager,
    require_token,
)
from app.services.connections import ConnectionStore, probe_connection
from app.services.dashboard_tokens import (
    DashboardPublication,
    DashboardTokenError,
    DashboardTokenStore,
)
from app.services.snowflake_sessions import SnowflakeSessionManager

router = APIRouter(prefix="/api/v1/published", tags=["published-dashboard"])
admin_router = APIRouter(
    prefix="/api/v1/dashboard-publications",
    tags=["dashboard-publications"],
    dependencies=[Depends(require_token)],
)


def require_publication(
    tokens: Annotated[DashboardTokenStore, Depends(get_dashboard_token_store)],
    authorization: Annotated[str | None, Header()] = None,
) -> DashboardPublication:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "missing dashboard token")
    try:
        return tokens.verify(authorization.removeprefix("Bearer ").strip())
    except DashboardTokenError as e:
        raise HTTPException(401, str(e)) from e


class PublishedBatchQueryRequest(BaseModel):
    queries: list[VisualQuery]
    mode: str = "live"
    execution_tier: QueryExecutionTier = QueryExecutionTier.TIER_A_NATIVE
    allow_tier_a_fallback: bool = True
    row_scope_id: str | None = None
    model_version: str | None = None
    data_version: str | None = None
    what_if_values: dict[str, str | int | float | bool | None] = Field(default_factory=dict)


class RotatePublicationRequest(BaseModel):
    overlap_seconds: int = Field(default=0, ge=0, le=3600)


@admin_router.get("")
def list_publications(
    tokens: Annotated[DashboardTokenStore, Depends(get_dashboard_token_store)],
) -> list[DashboardPublication]:
    return tokens.list()


@admin_router.post("/{publication_id}/rotate")
def rotate_publication(
    publication_id: str,
    request: RotatePublicationRequest,
    tokens: Annotated[DashboardTokenStore, Depends(get_dashboard_token_store)],
):
    try:
        return tokens.rotate(publication_id, overlap_seconds=request.overlap_seconds)
    except DashboardTokenError as e:
        raise HTTPException(404, str(e)) from e


@admin_router.delete("/{publication_id}")
def revoke_publication(
    publication_id: str,
    tokens: Annotated[DashboardTokenStore, Depends(get_dashboard_token_store)],
) -> DashboardPublication:
    try:
        return tokens.revoke(publication_id)
    except DashboardTokenError as e:
        raise HTTPException(404, str(e)) from e


@router.get("/session")
def session_status(
    publication: Annotated[DashboardPublication, Depends(require_publication)],
    sessions: Annotated[SnowflakeSessionManager, Depends(get_snowflake_session_manager)],
) -> dict[str, bool]:
    try:
        return sessions.status(publication.connection_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e


@router.post("/session/authenticate")
def authenticate_session(
    publication: Annotated[DashboardPublication, Depends(require_publication)],
    sessions: Annotated[SnowflakeSessionManager, Depends(get_snowflake_session_manager)],
) -> dict:
    try:
        connection = sessions.authenticate(
            publication.connection_id,
            query_tag=f"pbic:published:{publication.conversion_id}",
        )
        return probe_connection(connection)
    except ModuleNotFoundError as e:
        raise HTTPException(501, "snowflake-connector-python not installed") from e
    except (KeyError, ValueError) as e:
        raise HTTPException(422, f"invalid connection configuration: {e}") from e
    except Exception as e:  # connector authentication errors vary by version
        return {"ok": False, "error": str(e)}


@router.get("/dashboard/spec")
def published_spec(
    publication: Annotated[DashboardPublication, Depends(require_publication)],
    variant: str | None = None,
):
    return get_dashboard_spec(publication.conversion_id, variant)


@router.post("/dashboard/query", response_model=BatchQueryResponse)
def published_query(
    request: PublishedBatchQueryRequest,
    publication: Annotated[DashboardPublication, Depends(require_publication)],
    connections: Annotated[ConnectionStore, Depends(get_connection_store)],
    variant: str | None = None,
) -> BatchQueryResponse:
    bound_request = BatchQueryRequest(
        connection_id=publication.connection_id,
        **request.model_dump(),
    )
    return batch_query(publication.conversion_id, bound_request, connections, variant)


@router.get("/dashboard/accelerate")
def published_acceleration_status(
    publication: Annotated[DashboardPublication, Depends(require_publication)],
) -> dict:
    return acceleration_status(publication.conversion_id)


@router.post("/dashboard/accelerate")
def published_accelerate(
    publication: Annotated[DashboardPublication, Depends(require_publication)],
    connections: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> dict:
    return accelerate(
        publication.conversion_id,
        AccelerateRequest(connection_id=publication.connection_id),
        connections,
    )