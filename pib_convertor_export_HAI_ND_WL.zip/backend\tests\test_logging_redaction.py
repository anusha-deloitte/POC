"""Structured logging must never leak credentials to disk.

These tests treat redaction as a checked invariant, not a convention: they
plant known-shaped secrets (password, private key PEM, OAuth secret, PAT,
bearer token, dashboard capability token) exactly as they'd appear in real
code paths (e.g. ConnectionStore.connector_kwargs) and assert the literal
secret string never survives into `redact()` output or an emitted log line.
"""

from __future__ import annotations

import json

from app.core.logging import append_jsonl, configure_logging, get_logger, log_event, redact

_FAKE_PASSWORD = "hunter2-super-secret"
_FAKE_PEM = (
    "-----BEGIN PRIVATE KEY-----\nMIIFAKEKEYDATAxxxxxxxxxxxxxxxx\n-----END PRIVATE KEY-----"
)
_FAKE_OAUTH_SECRET = "oauth-client-secret-abc123"
_FAKE_PAT = "pat-abcdef0123456789"
_FAKE_BEARER = "Bearer sk-live-abcdef0123456789"
_FAKE_DASH_TOKEN = "pbic_dash_ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"


def test_redact_masks_known_secret_keys_recursively():
    payload = {
        "account": "acme-xy12345",
        "user": "jdoe",
        "password": _FAKE_PASSWORD,
        "nested": {
            "private_key_pem": _FAKE_PEM,
            "private_key_passphrase": "swordfish",
            "oauth_client_secret": _FAKE_OAUTH_SECRET,
            "pat_token": _FAKE_PAT,
            "token": "abc.def.ghi",
        },
    }
    out = redact(payload)
    dumped = json.dumps(out)
    for secret in (
        _FAKE_PASSWORD,
        _FAKE_PEM,
        "swordfish",
        _FAKE_OAUTH_SECRET,
        _FAKE_PAT,
        "abc.def.ghi",
    ):
        assert secret not in dumped
    # non-secret fields survive untouched
    assert out["account"] == "acme-xy12345"
    assert out["user"] == "jdoe"


def test_redact_scrubs_secret_shaped_strings_under_unexpected_keys():
    """Defense in depth: even if a secret lands under a field name we didn't
    anticipate, PEM/bearer/dashboard-token shapes are still caught."""
    payload = {
        "note": f"connected using {_FAKE_BEARER}",
        "debug_dump": _FAKE_PEM,
        "config_snippet": f"api_base=/x token={_FAKE_DASH_TOKEN}",
    }
    dumped = json.dumps(redact(payload))
    assert _FAKE_BEARER not in dumped
    assert _FAKE_PEM not in dumped
    assert _FAKE_DASH_TOKEN not in dumped
    assert "REDACTED" in dumped


def test_log_event_writes_redacted_json_line(tmp_path):
    configure_logging(tmp_path, "INFO")
    logger = get_logger("test_redaction")
    log_event(
        logger,
        "info",
        "snowflake_connect_attempt",
        account="acme-xy12345",
        password=_FAKE_PASSWORD,
        private_key_pem=_FAKE_PEM,
        oauth_client_secret=_FAKE_OAUTH_SECRET,
        pat_token=_FAKE_PAT,
    )
    for handler in logger.parent.handlers:
        handler.flush()
    log_file = tmp_path / "app.jsonl"
    contents = log_file.read_text(encoding="utf-8")
    for secret in (_FAKE_PASSWORD, _FAKE_PEM, _FAKE_OAUTH_SECRET, _FAKE_PAT):
        assert secret not in contents
    last_line = json.loads(contents.strip().splitlines()[-1])
    assert last_line["event"] == "snowflake_connect_attempt"
    assert last_line["account"] == "acme-xy12345"
    assert last_line["password"] == "***REDACTED***"


def test_append_jsonl_redacts_per_conversion_trace(tmp_path):
    events_path = tmp_path / "conv-123" / "events.jsonl"
    append_jsonl(
        events_path,
        "dashboard_query",
        conversion_id="conv-123",
        sql='SELECT 1 FROM "D01_DX"."PUBLIC"."FACT_SALES"',
        error='002003 (02000): SQL compilation error: Database "D01_DX" does not exist or not authorized',
        connection_id="conn-1",
        token=_FAKE_DASH_TOKEN,
    )
    contents = events_path.read_text(encoding="utf-8")
    assert _FAKE_DASH_TOKEN not in contents
    line = json.loads(contents.strip().splitlines()[-1])
    # legitimate diagnostic info (the whole point of this feature) is preserved
    assert "D01_DX" in line["sql"]
    assert "does not exist or not authorized" in line["error"]


def test_connector_kwargs_secret_keys_are_all_in_the_redaction_denylist():
    """Guards against ConnectionStore growing a new secret field that the
    redaction denylist doesn't know about yet."""
    from app.core.logging import _SECRET_KEYS

    # mirrors the keys connector_kwargs()/required_secrets() can populate
    known_secret_fields = {
        "password",
        "private_key",
        "private_key_pem",
        "private_key_passphrase",
        "oauth_client_secret",
        "pat_token",
        "token",
    }
    assert known_secret_fields <= _SECRET_KEYS
