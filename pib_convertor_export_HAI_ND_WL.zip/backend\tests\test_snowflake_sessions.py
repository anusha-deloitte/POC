from __future__ import annotations

from types import SimpleNamespace

import pytest

from app.services.connections import AuthMethod
from app.services.snowflake_sessions import (
    SnowflakeAuthenticationRequired,
    SnowflakeSessionManager,
)


class FakeCursor:
    def __init__(self):
        self.executed = []
        self.closed = False

    def execute(self, sql, params=None):
        self.executed.append((sql, params))
        return self

    def close(self):
        self.closed = True


class FakeConnection:
    def __init__(self):
        self.closed = False
        self.cursors = []

    def cursor(self):
        cursor = FakeCursor()
        self.cursors.append(cursor)
        return cursor

    def is_closed(self):
        return self.closed

    def close(self):
        self.closed = True


class FakeStore:
    def __init__(self, auth_method=AuthMethod.EXTERNAL_BROWSER):
        self.profile = SimpleNamespace(auth_method=auth_method, account="acct", user="user")

    def get(self, profile_id):
        assert profile_id == "profile-1"
        return self.profile

    def connector_kwargs(self, profile_id, query_tag=None):
        assert profile_id == "profile-1"
        return {"account": "acct", "session_parameters": {"QUERY_TAG": query_tag}}


def test_external_browser_requires_explicit_authentication():
    manager = SnowflakeSessionManager(FakeStore(), connect=lambda **kwargs: FakeConnection())

    with pytest.raises(SnowflakeAuthenticationRequired):
        with manager.lease("profile-1", "pbic:test"):
            pass


def test_authenticate_reuses_connection_and_updates_query_tag():
    connections = []

    def connect(**kwargs):
        connection = FakeConnection()
        connections.append(connection)
        return connection

    manager = SnowflakeSessionManager(FakeStore(), connect=connect)
    authenticated = manager.authenticate("profile-1", "pbic:authenticate")

    with manager.lease("profile-1", "pbic:dashboard") as leased:
        assert leased is authenticated

    assert len(connections) == 1
    assert authenticated.cursors[-1].executed == [
        ("ALTER SESSION SET QUERY_TAG = %s", ("pbic:dashboard",))
    ]
    assert authenticated.cursors[-1].closed is True


def test_noninteractive_profile_connects_on_first_lease():
    connections = []

    def connect(**kwargs):
        connection = FakeConnection()
        connections.append(connection)
        return connection

    manager = SnowflakeSessionManager(FakeStore(AuthMethod.KEY_PAIR), connect=connect)

    with manager.lease("profile-1", "pbic:test") as leased:
        assert leased is connections[0]

    assert manager.status("profile-1")["authenticated"] is True


def test_evict_and_close_all_close_managed_connections():
    connections = []

    def connect(**kwargs):
        connection = FakeConnection()
        connections.append(connection)
        return connection

    manager = SnowflakeSessionManager(FakeStore(), connect=connect)
    first = manager.authenticate("profile-1")
    manager.evict("profile-1")
    second = manager.authenticate("profile-1")
    manager.close_all()

    assert first.closed is True
    assert second.closed is True
    assert manager.status("profile-1")["authenticated"] is False


def test_open_connection_close_releases_lease_without_closing_session():
    underlying = FakeConnection()
    manager = SnowflakeSessionManager(FakeStore(), connect=lambda **kwargs: underlying)
    manager.authenticate("profile-1")

    managed = manager.open_connection("profile-1", "pbic:dashboard")
    cursor = managed.cursor()
    assert cursor.connection is managed
    cursor.connection.close()

    assert underlying.closed is False
    with manager.lease("profile-1", "pbic:next") as reused:
        assert reused is underlying


def test_open_cursor_close_releases_connection_lease():
    underlying = FakeConnection()
    manager = SnowflakeSessionManager(FakeStore(), connect=lambda **kwargs: underlying)
    manager.authenticate("profile-1")

    cursor = manager.open_cursor("profile-1", "pbic:semantic")
    cursor.close()

    assert underlying.closed is False
    with manager.lease("profile-1", "pbic:next") as reused:
        assert reused is underlying