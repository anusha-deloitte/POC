# PBI Converter

Agentic asset that converts Power BI reports (`.pbip` — PBIR + TMDL formats) into React
dashboards backed by live Snowflake data, then validates conversion accuracy against
golden results and iteratively repairs failures.

## Architecture

```
.pbip upload ──> S1 Ingest ──> S2 PBI-IR ──> S3 Snowflake binding ──> S4 DAX compiler (tiered)
                                                                            │
Studio wizard <── S8 Agent loop <── S7 Accuracy harness <── S6 Renderer <── S5 Query engine
```

- **PBI-IR** ([backend/app/ir](backend/app/ir)) — canonical Pydantic models; every parser emits it, every compiler consumes it.
- **TMDL parser** ([backend/app/parsers/tmdl.py](backend/app/parsers/tmdl.py)) — pure-Python semantic model parser (tables, measures, relationships, roles, M partitions).
- **PBIR parser** ([backend/app/parsers/pbir.py](backend/app/parsers/pbir.py)) — report layer: pages, visuals, filters, projections, sort, theme.
- **Connection profiles** ([backend/app/services/connections.py](backend/app/services/connections.py)) — Snowflake multi-auth (External Browser SSO, key-pair/JWT, password, OAuth client-credentials, PAT); secrets Fernet-encrypted at rest; one profile feeds both the agent plane (Snowflake MCP server) and serving plane (native connector).
- **Ingest** ([backend/app/services/ingest.py](backend/app/services/ingest.py)) — zip-slip/zip-bomb-safe extraction and bundle storage.

## Quickstart

### One command (Windows)

```powershell
./start.ps1
```

Installs every backend extra (`uv sync --all-extras --all-groups` — Snowflake, LLM tiers,
DuckDB acceleration, source-DB migration drivers, PDF parity review, plus dev tooling) and
every frontend package (`npm install`), then starts the API (`:8000`) and Studio (`:5173`)
as detached background processes and waits for both to report healthy. Re-run it any time —
already-installed dependencies are skipped, so it's fast on subsequent runs. Useful flags:

- `-SkipInstall` — just (re)start the servers, skip the dependency check
- `-InstallOnly` — install dependencies only, don't start anything
- `-ApiPort` / `-WebPort` — override the default ports

Stop both with `./stop.ps1`. Raw server output lands in `logs/api.out.log` /
`logs/web.out.log` at the repo root (separate from the structured app logs — see
[Logging](#logging) below).

The `sources` extra installs `pyodbc`'s Python driver, but migrating *from* SQL Server also
needs Microsoft's **ODBC Driver 17/18 for SQL Server** installed at the OS level — that's
not on PyPI, so `start.ps1` can't install it for you; get it from Microsoft's own installer
if you need SQL Server source migration.

### Manual (any OS)

```bash
# Backend (Python 3.12 + uv)
cd backend
uv venv && uv pip install -e ".[snowflake]" --group dev   # add other extras as needed: .[snowflake,duckdb,sources,pdf]
uv run pytest                      # 52 tests, coverage gate >= 80%
uv run uvicorn app.main:app --reload   # http://localhost:8000/docs

# Frontend (Node 20)
cd frontend
npm install
npm test
npm run dev                        # http://localhost:5173
```

### Native Windows with Snowflake SSO

`./start.ps1` (above) already covers this — it installs the `snowflake` extra needed for
`external_browser` auth. If running manually instead, use separate PowerShell terminals. If
PowerShell blocks the `npm.ps1` shim, use `npm.cmd` as shown below.

```powershell
cd backend
uv venv
uv pip install -e ".[snowflake]" --group dev
uv run uvicorn app.main:app --reload

cd frontend
npm.cmd install
npm.cmd run dev
```

In **Connect**, select **External browser (SSO)** and enter the Snowflake account and
user. Testing the connection deliberately opens the system browser. After sign-in, the
backend keeps one locked Snowflake connection per profile and reuses it for Studio and
exported-dashboard queries.

For optional Snowflake ID-token caching, an account administrator can run:

```sql
ALTER ACCOUNT SET ALLOW_ID_TOKEN = TRUE;
```

The backend process must remain running while a migrated dashboard is used. Managed
Snowflake sessions are process-local: restarting the backend closes them, and the next
dashboard request prompts for External Browser authentication again.

## Environment variables

| Variable | Purpose | Default |
|---|---|---|
| `PBIC_STORAGE_DIR` | Uploaded conversions + encrypted connection store | `/tmp/pbic-storage` |
| `PBIC_SECRETS_KEY_FILE` | Fernet key location (chmod 600, generated on first run) | `<storage>/.secrets.key` |
| `PBIC_API_TOKEN` | Bearer token for all API routes (empty = auth off, dev only) | empty |
| `PBIC_DASHBOARD_TOKEN_TTL_SECONDS` | Lifetime of exported-dashboard capability tokens | 30 days |
| `PBIC_HORIZON_CLIENT_ID` / `PBIC_HORIZON_CLIENT_SECRET` | OAuth2 client-credentials for Elevance Health's Horizon LLM gateway (tier-2 DAX repair, AI visual parity, governance AI assist); empty = LLM features disabled, deterministic paths still work | empty |
| `PBIC_HORIZON_BASE_URL` | Horizon gateway base URL | `https://api.horizon.elevancehealth.com` |
| `PBIC_HORIZON_QOS` | Quality-of-service tier for tier-2/visual-parity calls (`accurate`\|`cheap`) | `accurate` |
| `PBIC_HORIZON_GOVERNANCE_QOS` | QoS tier for the lighter-weight governance Q&A/override calls | `cheap` |
| `PBIC_HORIZON_MAX_REQUESTS_PER_MINUTE` | Client-side self-throttle to stay under the gateway's rate limit | 15 |
| `PBIC_DATABASE_URL` | Postgres (metadata + LangGraph checkpoints, M2+) | local |
| `PBIC_MAX_UPLOAD_BYTES` | Upload cap | 300 MB |
| `PBIC_LOG_LEVEL` | Minimum level written to `logs/app.jsonl` | `INFO` |
| `PBIC_LOG_SQL_TEXT` | Include compiled SQL text in query logs (`false` to omit — it can embed literal filter values a user picked, which is business data, not a credential, but you may still want it off) | `true` |

## Logging

Everything the backend logs is structured JSON-lines (one JSON object per line) under
`<PBIC_STORAGE_DIR>/logs/app.jsonl` (rotated at 10MB × 5 backups) — every HTTP request,
every Snowflake connect attempt/failure, and every dashboard query (with its `query_tag`,
elapsed time, row count, and SQL/error text). The same `query_tag` is sent to Snowflake, so
a failing query's log line can be cross-referenced directly against Snowflake's own
`QUERY_HISTORY`.

Each conversion also gets its own durable, append-only trace at
`<PBIC_STORAGE_DIR>/<conversion_id>/events.jsonl` — every pipeline stage the agent ran,
every query executed against that conversion, and any forwarded frontend error, in one
file, kept across re-runs (unlike `conversion_run.json` next to it, which is overwritten on
every run).

Frontend errors are forwarded to `POST /api/v1/client-logs` and land in the same files, so a
UI-visible failure is still there to inspect after a page refresh.

**Secrets are never written to these files.** Every log line goes through a single
redaction chokepoint (`app/core/logging.log_event`) that masks known-secret fields
(`password`, `private_key*`, `token`, `oauth_client_secret`, `pat_token`, etc.) and, as
defense in depth, also scrubs PEM blocks, `Bearer` headers, and dashboard capability tokens
found anywhere in a logged value. This is enforced by tests
([backend/tests/test_logging_redaction.py](backend/tests/test_logging_redaction.py)), not
just convention.

## Testing

- `backend`: `uv run pytest --cov=app` — parser round-trips against the fixture corpus in [fixtures/contoso_sales](fixtures/contoso_sales), API + security tests (zip-slip, auth, secret encryption).
- `frontend`: `npm run test:coverage` — wizard shell + store.
- CI ([.github/workflows/ci.yml](.github/workflows/ci.yml)): lint (ruff), SAST (bandit), coverage gate ≥80%, and a **license gate** (pip-licenses / license-checker) that fails the build on any non-permissive dependency.

## Fixture corpus

[fixtures/contoso_sales](fixtures/contoso_sales) is a complete hand-authored `.pbip`
(4-table star schema on Snowflake, 6 DAX measures incl. time intelligence, 4 visuals,
page/visual/TopN filters, hierarchy, sortByColumn, inactive + bidirectional relationship).
It is both the regression suite and the demo seed. Add more reports as
`fixtures/<name>/` and they are picked up by tests.

## Feature status

Delivered (all verified against a real 71-measure healthcare payer report on live Snowflake):

- **Parsing** — PBIP/PBIR + TMDL (pure-Python, preview-drift tolerant), M-partition binding
  with parameter resolution, custom theme extraction.
- **DAX compiler** — tiered: implicit aggregates → deterministic Metric Algebra
  (CALCULATE, VAR, time intelligence, iterators, windowed rolling averages via
  `AVG OVER`) → execution-validated Horizon LLM gateway fallback. 71/71 measures on the hero report.
- **Semantic runtime** — join-path planning, PBI filter propagation, dimension frames for
  multi-fact visuals, SPLY/YTD dual-date joins, `USERELATIONSHIP` + bidirectional
  cross-filter, sortByColumn ordering.
- **Renderer** — spec-driven PageCanvas: cards, slicers, bar/column/line/area/donut/
  waterfall, scatter, dual-axis combo, gauge, US choropleth, drillable treemap
  (decomposition-tree substitute), matrix pivot tables; PBI format strings; report theme
  (dataColors, good/bad semantics); variance conditional formatting.
- **Accuracy** — per-visual compile/execute/sanity/totals checks → Fidelity Scorecard;
  live golden-equivalence pytest suite (`-m live`); agent pipeline with bounded monotonic
  repair and a persisted event log.
- **Modes** — Live (every interaction hits Snowflake) and **Accelerated** (DuckDB extract
  hydrated from Snowflake via Arrow; 5–90× faster interactions, numerically equivalent).
- **Delivery** — standalone full-tab dashboard route; one-click export of a runnable
  Vite + React project (vendored renderer + spec, builds clean). Each export is bound to
  its selected Snowflake profile and receives a scoped capability token. The backend must
  remain reachable at the `api_base` in `public/dashboard-config.json`. Rotate a token in
  Preview, deploy the downloaded replacement `dashboard-config.json`, then revoke the old
  publication when it is no longer needed. Tokens are shown only when issued; only hashes
  are stored by the backend.

Backlog: RLS → Snowflake row access policies, Entra External OAuth, OTel tracing,
per-visual typed endpoints, offline demo kit, PBIX adapter.
