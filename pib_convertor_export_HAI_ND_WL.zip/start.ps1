<#
.SYNOPSIS
  One-command setup + run for PBI Converter: installs every backend/frontend
  dependency (uv sync --all-extras --all-groups, npm install), then starts
  both servers as detached background processes.

.PARAMETER SkipInstall
  Skip the dependency-install step and go straight to starting the servers.

.PARAMETER InstallOnly
  Install dependencies only; do not start the servers.

.EXAMPLE
  ./start.ps1
.EXAMPLE
  ./start.ps1 -SkipInstall
#>
[CmdletBinding()]
param(
    [switch]$SkipInstall,
    [switch]$InstallOnly,
    [int]$ApiPort = 8000,
    [int]$WebPort = 5173
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$backend = Join-Path $root 'backend'
$frontend = Join-Path $root 'frontend'
$logDir = Join-Path $root 'logs'
$pidFile = Join-Path $root '.dev-pids.json'

function Test-CommandExists {
    param([string]$Name)
    return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
}

function Wait-ForHttp {
    param([string]$Url, [int]$TimeoutSec = 40)
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        try {
            Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 2 | Out-Null
            return $true
        } catch {
            Start-Sleep -Milliseconds 500
        }
    }
    return $false
}

Write-Host "== PBI Converter ==" -ForegroundColor Cyan

if (-not (Test-CommandExists 'uv')) {
    Write-Error "uv is not on PATH. Install it: https://docs.astral.sh/uv/getting-started/installation/"
    exit 1
}
if (-not (Test-CommandExists 'node') -or -not (Test-CommandExists 'npm')) {
    Write-Error "Node.js/npm not found on PATH. Install Node 20+: https://nodejs.org/"
    exit 1
}

if (-not $SkipInstall) {
    Write-Host "-> backend: uv sync --all-extras --all-groups" -ForegroundColor Yellow
    Push-Location $backend
    try {
        if (-not (Test-Path (Join-Path $backend '.venv'))) {
            uv venv
        }
        uv sync --all-extras --all-groups
        if ($LASTEXITCODE -ne 0) { throw "uv sync failed with exit code $LASTEXITCODE" }
    } finally {
        Pop-Location
    }
    Write-Host "   note: the 'sources' extra installs pyodbc's Python driver only." -ForegroundColor DarkGray
    Write-Host "   Migrating FROM SQL Server also needs Microsoft's 'ODBC Driver 17/18" -ForegroundColor DarkGray
    Write-Host "   for SQL Server' installed at the OS level -- that part is not on PyPI" -ForegroundColor DarkGray
    Write-Host "   and can't be installed by this script." -ForegroundColor DarkGray

    Write-Host "-> frontend: npm install" -ForegroundColor Yellow
    Push-Location $frontend
    try {
        npm install
        if ($LASTEXITCODE -ne 0) { throw "npm install failed with exit code $LASTEXITCODE" }
    } finally {
        Pop-Location
    }
    Write-Host "Install complete." -ForegroundColor Green
}

if ($InstallOnly) {
    exit 0
}

New-Item -ItemType Directory -Force -Path $logDir | Out-Null

Write-Host "== starting ==" -ForegroundColor Cyan

$apiOut = Join-Path $logDir 'api.out.log'
$apiErr = Join-Path $logDir 'api.err.log'
$apiProc = Start-Process -FilePath 'uv.exe' `
    -ArgumentList @('run', 'uvicorn', 'app.main:app', '--reload', '--port', $ApiPort) `
    -WorkingDirectory $backend `
    -RedirectStandardOutput $apiOut -RedirectStandardError $apiErr `
    -WindowStyle Hidden -PassThru

Write-Host "-> API starting on :$ApiPort (pid $($apiProc.Id))"
if (-not (Wait-ForHttp -Url "http://localhost:$ApiPort/healthz")) {
    Write-Warning "API did not report healthy in time -- check $apiErr"
}

$env:PBIC_API_URL = "http://localhost:$ApiPort"
$webOut = Join-Path $logDir 'web.out.log'
$webErr = Join-Path $logDir 'web.err.log'
$webProc = Start-Process -FilePath 'npm.cmd' `
    -ArgumentList @('run', 'dev', '--', '--port', $WebPort) `
    -WorkingDirectory $frontend `
    -RedirectStandardOutput $webOut -RedirectStandardError $webErr `
    -WindowStyle Hidden -PassThru

Write-Host "-> Web starting on :$WebPort (pid $($webProc.Id))"
if (-not (Wait-ForHttp -Url "http://localhost:$WebPort")) {
    Write-Warning "Web did not report ready in time -- check $webErr"
}

@{ api = $apiProc.Id; web = $webProc.Id } | ConvertTo-Json | Set-Content -Path $pidFile -Encoding utf8

Write-Host ""
Write-Host "  Studio:   http://localhost:$WebPort" -ForegroundColor Green
Write-Host "  API docs: http://localhost:$ApiPort/docs" -ForegroundColor Green
Write-Host "  Raw logs: $logDir"
Write-Host "  Stop:     ./stop.ps1"
