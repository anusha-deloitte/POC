import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useMemo, useState } from 'react'
import { api } from '../api/client'
import { fetchDashboardSpec, fetchVisualData } from '../dashboard/api'
import { ModeToggle, type QueryMode } from '../dashboard/ModeToggle'
import { PageCanvas, slicersToFilters } from '../dashboard/PageCanvas'
import {
  buildVisualQueryFilters,
  emptyInteractionState,
  resolveVisualInteractions,
} from '../dashboard/interactions'
import { ThemeProvider } from '../dashboard/theme'
import type { InteractionState, VisualSpec } from '../dashboard/types'
import { useWizard } from '../store/wizard'

const dashboardUrl = (conversionId: string, connectionId: string) =>
  `${window.location.origin}${window.location.pathname}#/dashboard/${conversionId}/${connectionId}`

export function PreviewStep() {
  const queryClient = useQueryClient()
  const conversionId = useWizard((s) => s.conversionId)
  const connectionId = useWizard((s) => s.connectionId)
  const [pageIdx, setPageIdx] = useState(0)
  const [mode, setMode] = useState<QueryMode>('live')
  const [slicerState, setSlicerState] = useState<Record<string, (string | number)[]>>({})
  const [interactionState, setInteractionState] = useState<InteractionState>(emptyInteractionState())

  const spec = useQuery({
    queryKey: ['dash-spec', conversionId],
    queryFn: () => fetchDashboardSpec(conversionId!),
    enabled: !!conversionId,
  })
  const publications = useQuery({
    queryKey: ['dashboard-publications'],
    queryFn: api.listDashboardPublications,
  })
  const download = useMutation({
    mutationFn: () => api.exportDashboard(conversionId!, connectionId!),
    onSuccess: async (blob) => {
      const href = URL.createObjectURL(blob)
      const anchor = document.createElement('a')
      anchor.href = href
      anchor.download = `${spec.data?.report_name ?? 'dashboard'}-dashboard.zip`
      anchor.click()
      URL.revokeObjectURL(href)
      await queryClient.invalidateQueries({ queryKey: ['dashboard-publications'] })
    },
  })
  const rotate = useMutation({
    mutationFn: (id: string) => api.rotateDashboardPublication(id),
    onSuccess: async (issued) => {
      const config = {
        api_base: '/api/v1/published',
        publication_id: issued.publication.id,
        token: issued.token,
      }
      const href = URL.createObjectURL(
        new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' }),
      )
      const anchor = document.createElement('a')
      anchor.href = href
      anchor.download = 'dashboard-config.json'
      anchor.click()
      URL.revokeObjectURL(href)
      await queryClient.invalidateQueries({ queryKey: ['dashboard-publications'] })
    },
  })
  const revoke = useMutation({
    mutationFn: (id: string) => api.revokeDashboardPublication(id),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['dashboard-publications'] })
    },
  })

  const page = spec.data?.pages[pageIdx]
  const filters = useMemo(
    () => (page ? slicersToFilters(page, slicerState) : []),
    [page, slicerState],
  )
  const visualInteractions = useMemo(
    () =>
      page && spec.data
        ? resolveVisualInteractions(page, spec.data.interaction_graph, interactionState)
        : {},
    [page, spec.data, interactionState],
  )
  const filtersByVisual = useMemo(
    () =>
      page && spec.data
        ? buildVisualQueryFilters(page, spec.data.interaction_graph, interactionState, filters)
        : {},
    [page, spec.data, interactionState, filters],
  )

  const data = useQuery({
    queryKey: ['dash-data', conversionId, page?.name, filtersByVisual, mode],
    queryFn: () =>
      fetchVisualData(
        conversionId!,
        connectionId!,
        page!.name,
        page!.visuals.filter((v) => v.supported && v.query).map((v) => v.name),
        filtersByVisual,
        mode,
      ),
    enabled: !!conversionId && !!connectionId && !!page,
    placeholderData: (prev) => prev,
  })

  if (!conversionId) return <p className="text-surface-500">No conversion selected.</p>
  if (!connectionId) return <p className="text-surface-500">No Snowflake connection selected.</p>
  if (spec.isLoading) return <p className="text-surface-500">Compiling dashboard…</p>
  if (spec.isError)
    return (
      <div role="alert" className="rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
        {spec.error.message}
      </div>
    )

  const onSlicerChange = (visual: VisualSpec, values: (string | number)[]) =>
    setSlicerState((s) => ({ ...s, [visual.name]: values }))

  return (
    <section className="max-w-none">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">{spec.data!.report_name}</h2>
          <p className="text-xs text-surface-500">
            Live against Snowflake{data.isFetching ? ' — refreshing…' : ''}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <ModeToggle
            conversionId={conversionId}
            connectionId={connectionId}
            mode={mode}
            onChange={setMode}
          />
          <a
            href={dashboardUrl(conversionId, connectionId)}
            target="_blank"
            rel="noreferrer"
            className="rounded-[10px] border border-brand px-3 py-1.5 text-xs font-semibold text-brand-dark hover:bg-brand/10"
          >
            Open full dashboard ↗
          </a>
          <button
            type="button"
            disabled={download.isPending}
            onClick={() => download.mutate()}
            className="rounded-[10px] bg-brand px-3 py-1.5 text-xs font-semibold text-white hover:bg-brand-dark"
          >
            {download.isPending ? 'Preparing export…' : 'Download React code ⬇'}
          </button>
        </div>
      </div>
      {(publications.data ?? []).some(
        (publication) =>
          publication.conversion_id === conversionId && publication.revoked_at == null,
      ) && (
        <div className="mb-3 flex flex-wrap items-center gap-2 text-xs text-surface-600">
          {(publications.data ?? [])
            .filter(
              (publication) =>
                publication.conversion_id === conversionId && publication.revoked_at == null,
            )
            .map((publication) => (
              <div key={publication.id} className="flex items-center gap-2 rounded-lg border border-surface-300 px-3 py-2">
                <span>
                  Token {publication.token_fingerprint} · expires{' '}
                  {new Date(publication.expires_at * 1000).toLocaleDateString()}
                </span>
                <button
                  type="button"
                  className="font-semibold text-brand-dark underline"
                  disabled={rotate.isPending}
                  onClick={() => rotate.mutate(publication.id)}
                >
                  Rotate
                </button>
                <button
                  type="button"
                  className="font-semibold text-brand-red underline"
                  disabled={revoke.isPending}
                  onClick={() => revoke.mutate(publication.id)}
                >
                  Revoke
                </button>
              </div>
            ))}
        </div>
      )}
      <div className="mb-3 flex items-center justify-between">
        <nav className="flex gap-1">
          {spec.data!.pages.map((p, i) => (
            <button
              key={p.name}
              onClick={() => {
                setPageIdx(i)
                setSlicerState({})
                setInteractionState(emptyInteractionState())
              }}
              data-active={i === pageIdx}
              className="rounded px-3 py-1.5 text-xs font-medium text-surface-600 hover:bg-surface-300 data-[active=true]:bg-brand data-[active=true]:text-white"
            >
              {p.display_name}
            </button>
          ))}
        </nav>
      </div>

      {data.isError && (
        <div role="alert" className="mb-3 rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
          {data.error.message}
        </div>
      )}

      {page && (
        <ThemeProvider value={spec.data!.theme}>
          <PageCanvas
            page={page}
            results={data.data ?? {}}
            slicerState={slicerState}
            onSlicerChange={onSlicerChange}
            interactionState={interactionState}
            onInteractionChange={setInteractionState}
            visualInteractions={visualInteractions}
          />
        </ThemeProvider>
      )}
    </section>
  )
}
