"""HorizonClient: token exchange, request shape, retry/rate-limit behavior,
and secret redaction. No real network calls — httpx.Client.post is replaced
with a scripted fake per test.
"""

from __future__ import annotations

import httpx
import pytest

from app.core.logging import configure_logging, get_logger, log_event
from app.services.horizon_client import HorizonClient, HorizonError, image_content_part


class _FakeResponse:
    def __init__(self, status_code: int, json_body: dict, headers: dict | None = None):
        self.status_code = status_code
        self._json = json_body
        self.headers = headers or {}

    def json(self) -> dict:
        return self._json

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            request = httpx.Request("POST", "https://x/")
            response = httpx.Response(self.status_code, request=request)
            raise httpx.HTTPStatusError(f"status {self.status_code}", request=request, response=response)


def _make_client(monkeypatch, post_handler, **kwargs) -> HorizonClient:
    client = HorizonClient(
        base_url="https://api.horizon.example.com",
        client_id="cid-123",
        client_secret="super-secret-value",
        max_requests_per_minute=1000,  # don't let the limiter slow the test
        **kwargs,
    )
    monkeypatch.setattr(client._http, "post", post_handler)
    monkeypatch.setattr("app.services.horizon_client.time.sleep", lambda _s: None)
    return client


def test_token_fetch_uses_json_body_and_is_cached(monkeypatch):
    calls = []

    def post(url, **kwargs):
        calls.append(url)
        if url.endswith("/v2/oauth2/token"):
            assert kwargs["json"] == {
                "client_id": "cid-123",
                "client_secret": "super-secret-value",
                "grant_type": "client_credentials",
            }
            assert kwargs["headers"]["Content-Type"] == "application/json"
            return _FakeResponse(200, {"access_token": "tok-1", "token_type": "bearer", "expires_in": 300})
        return _FakeResponse(200, {"message": {"role": "assistant", "content": "hi"}})

    client = _make_client(monkeypatch, post)
    assert client.chat([{"role": "user", "content": "hello"}]) == "hi"
    client.chat([{"role": "user", "content": "again"}])
    assert [c for c in calls if c.endswith("/v2/oauth2/token")] == [calls[0]]  # fetched once


def test_chat_request_shape(monkeypatch):
    captured = {}

    def post(url, **kwargs):
        if url.endswith("/v2/oauth2/token"):
            return _FakeResponse(200, {"access_token": "tok", "expires_in": 300})
        captured["url"] = url
        captured.update(kwargs)
        return _FakeResponse(200, {"message": {"content": "ok"}})

    client = _make_client(monkeypatch, post)
    result = client.chat([{"role": "user", "content": "hi"}], qos="cheap", reasoning=True)

    assert result == "ok"
    assert captured["url"].endswith("/v2/text/chats")
    assert captured["params"] == {"provider": "openai", "qos": "cheap", "reasoning": "true"}
    assert captured["json"] == {"Messages": [{"role": "user", "content": "hi"}], "stream": False}
    assert captured["headers"]["Authorization"] == "Bearer tok"
    assert captured["headers"]["Content-Type"] == "application/json"


def test_default_qos_used_when_not_overridden(monkeypatch):
    captured = {}

    def post(url, **kwargs):
        if url.endswith("/v2/oauth2/token"):
            return _FakeResponse(200, {"access_token": "tok", "expires_in": 300})
        captured["params"] = kwargs["params"]
        return _FakeResponse(200, {"message": {"content": "ok"}})

    client = _make_client(monkeypatch, post, default_qos="accurate")
    client.chat([{"role": "user", "content": "hi"}])
    assert captured["params"]["qos"] == "accurate"


def test_image_content_part_shape():
    part = image_content_part(b"\x89PNGfake", mime="image/png")
    assert part["type"] == "image"
    assert part["image"]["type"] == "base64"
    assert part["image"]["format"] == "image/png"
    assert part["image"]["data"]  # base64 string, non-empty


def test_429_retries_then_succeeds(monkeypatch):
    responses = iter(
        [
            _FakeResponse(429, {}, headers={"Retry-After": "0"}),
            _FakeResponse(200, {"message": {"content": "recovered"}}),
        ]
    )

    def post(url, **kwargs):
        if url.endswith("/v2/oauth2/token"):
            return _FakeResponse(200, {"access_token": "tok", "expires_in": 300})
        return next(responses)

    client = _make_client(monkeypatch, post)
    assert client.chat([{"role": "user", "content": "hi"}]) == "recovered"


def test_429_exhausted_raises(monkeypatch):
    def post(url, **kwargs):
        if url.endswith("/v2/oauth2/token"):
            return _FakeResponse(200, {"access_token": "tok", "expires_in": 300})
        return _FakeResponse(429, {}, headers={"Retry-After": "0"})

    client = _make_client(monkeypatch, post)
    with pytest.raises(HorizonError):
        client.chat([{"role": "user", "content": "hi"}], max_retries=2)


def test_client_secret_never_appears_in_logs(monkeypatch, tmp_path):
    """The credential exchange must never leak client_secret or the bearer
    token to the log files, even though log_event is called around it."""
    configure_logging(tmp_path, "INFO")

    def post(url, **kwargs):
        if url.endswith("/v2/oauth2/token"):
            return _FakeResponse(200, {"access_token": "top-secret-bearer-token", "expires_in": 300})
        return _FakeResponse(200, {"message": {"content": "hi"}})

    client = _make_client(monkeypatch, post)
    client.chat([{"role": "user", "content": "hi"}])
    for handler in get_logger("horizon").parent.handlers:
        handler.flush()
    contents = (tmp_path / "app.jsonl").read_text(encoding="utf-8")
    assert "super-secret-value" not in contents
    assert "top-secret-bearer-token" not in contents
