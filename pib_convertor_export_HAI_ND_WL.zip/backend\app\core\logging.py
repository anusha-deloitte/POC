"""Structured, file-based logging with mandatory secret redaction.

Every log line is one JSON object (JSONL) so it can be appended safely, tailed
by a human, or parsed line-by-line by a log-analysis tool. `log_event` is the
single chokepoint all app code must go through instead of calling a stdlib
logger directly — it redacts known-secret fields (and PEM/bearer-token shaped
values) before anything is serialized, so a future call site that accidentally
passes a credential dict cannot leak it to disk.
"""

from __future__ import annotations

import json
import logging
import re
import time
from functools import lru_cache
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any

# key names redacted case-insensitively, anywhere they appear in nested data
_SECRET_KEYS = {
    "password",
    "private_key",
    "private_key_pem",
    "private_key_passphrase",
    "oauth_client_secret",
    "pat_token",
    "token",
    "access_token",
    "secret",
    "secrets",
    "authorization",
    "api_key",
    "secrets_enc",
    "client_secret",
    "horizon_client_secret",
}
_REDACTED = "***REDACTED***"

# defense-in-depth: catch secret-shaped values even under an unexpected key
_PEM_RE = re.compile(r"-----BEGIN [^-]+-----.*?-----END [^-]+-----", re.DOTALL)
_BEARER_RE = re.compile(r"Bearer\s+[A-Za-z0-9\-_.=]+")
_DASH_TOKEN_RE = re.compile(r"pbic_dash_[A-Za-z0-9\-_]+")


def _redact_string(value: str) -> str:
    value = _PEM_RE.sub(_REDACTED, value)
    value = _BEARER_RE.sub(f"Bearer {_REDACTED}", value)
    value = _DASH_TOKEN_RE.sub(_REDACTED, value)
    return value


def redact(value: Any) -> Any:
    """Recursively redact secret-shaped values from dicts/lists/strings."""
    if isinstance(value, dict):
        return {
            k: (_REDACTED if k.lower() in _SECRET_KEYS else redact(v)) for k, v in value.items()
        }
    if isinstance(value, list):
        return [redact(v) for v in value]
    if isinstance(value, str):
        return _redact_string(value)
    return value


class _JsonLineFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        # log_event() pre-serializes structured records as the message itself;
        # anything logged the plain way still gets a safe, redacted envelope.
        if getattr(record, "_preformatted", False):
            return record.getMessage()
        payload = {
            "ts": round(time.time(), 3),
            "level": record.levelname.lower(),
            "logger": record.name,
            "message": redact(record.getMessage()),
        }
        return json.dumps(payload, default=str)


@lru_cache
def _file_handler(log_dir: Path) -> RotatingFileHandler:
    log_dir.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(
        log_dir / "app.jsonl", maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    handler.setFormatter(_JsonLineFormatter())
    return handler


def configure_logging(log_dir: Path, level: str = "INFO") -> None:
    """Idempotent: safe to call once at app startup."""
    root = logging.getLogger("app")
    root.setLevel(level)
    handler = _file_handler(log_dir)
    if handler not in root.handlers:
        root.addHandler(handler)
    root.propagate = False


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(f"app.{name}")


def log_event(logger: logging.Logger, level: str, event: str, **fields: Any) -> None:
    """The only sanctioned way to write a structured log line.

    Redacts `fields` before serializing, so passing a raw secret-bearing dict
    (e.g. Snowflake connector kwargs) here is safe by construction — callers
    should still prefer an explicit allow-list of fields over a whole dict.
    """
    level_no = logging.getLevelName(level.upper())
    if not logger.isEnabledFor(level_no):
        return
    safe_fields = redact(fields)
    payload = {
        "ts": round(time.time(), 3),
        "level": level.lower(),
        "event": event,
        **safe_fields,
    }
    record = logging.LogRecord(
        name=logger.name,
        level=level_no,
        pathname="",
        lineno=0,
        msg=json.dumps(payload, default=str),
        args=None,
        exc_info=None,
    )
    record._preformatted = True  # type: ignore[attr-defined]
    logger.handle(record)


def append_jsonl(path: Path, event: str, **fields: Any) -> None:
    """Append one redacted JSON line directly to a per-conversion log file."""
    safe_fields = redact(fields)
    payload = {"ts": round(time.time(), 3), "event": event, **safe_fields}
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload, default=str) + "\n")
