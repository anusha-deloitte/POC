import json

import pytest

from app.services.dashboard_tokens import DashboardTokenError, DashboardTokenStore


def test_token_is_scoped_and_only_hash_is_persisted(tmp_path):
    store = DashboardTokenStore(tmp_path, default_ttl_seconds=300, clock=lambda: 1000)

    issued = store.create("conversion-1", "connection-1")
    verified = store.verify(issued.token)

    assert verified.id == issued.publication.id
    assert verified.conversion_id == "conversion-1"
    assert verified.connection_id == "connection-1"
    raw = (tmp_path / "dashboard_publications.json").read_text()
    assert issued.token not in raw
    assert issued.publication.token_fingerprint in raw


def test_immediate_rotation_invalidates_old_token(tmp_path):
    store = DashboardTokenStore(tmp_path, default_ttl_seconds=300, clock=lambda: 1000)
    first = store.create("conversion-1", "connection-1")

    replacement = store.rotate(first.publication.id)

    with pytest.raises(DashboardTokenError):
        store.verify(first.token)
    assert store.verify(replacement.token).id == first.publication.id


def test_overlap_rotation_expires_old_token_after_cutover(tmp_path):
    now = [1000.0]
    store = DashboardTokenStore(tmp_path, default_ttl_seconds=300, clock=lambda: now[0])
    first = store.create("conversion-1", "connection-1")
    replacement = store.rotate(first.publication.id, overlap_seconds=30)

    assert store.verify(first.token).id == first.publication.id
    now[0] = 1031
    with pytest.raises(DashboardTokenError):
        store.verify(first.token)
    assert store.verify(replacement.token).id == first.publication.id


def test_revoke_invalidates_every_token(tmp_path):
    store = DashboardTokenStore(tmp_path, default_ttl_seconds=300, clock=lambda: 1000)
    first = store.create("conversion-1", "connection-1")
    replacement = store.rotate(first.publication.id, overlap_seconds=30)

    store.revoke(first.publication.id)

    for token in (first.token, replacement.token):
        with pytest.raises(DashboardTokenError):
            store.verify(token)

    persisted = json.loads((tmp_path / "dashboard_publications.json").read_text())
    assert persisted[0]["revoked_at"] == 1000