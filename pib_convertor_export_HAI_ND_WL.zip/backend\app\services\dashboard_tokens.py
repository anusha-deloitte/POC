"""Revocable capability tokens for exported dashboard access."""

from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import time
import uuid
from collections.abc import Callable
from pathlib import Path
from threading import RLock

from pydantic import BaseModel


class DashboardTokenError(Exception):
    pass


class DashboardPublication(BaseModel):
    id: str
    conversion_id: str
    connection_id: str
    created_at: float
    expires_at: float
    revoked_at: float | None = None
    token_fingerprint: str


class IssuedDashboardToken(BaseModel):
    publication: DashboardPublication
    token: str


class DashboardTokenStore:
    def __init__(
        self,
        storage_dir: Path,
        default_ttl_seconds: int,
        clock: Callable[[], float] = time.time,
    ):
        self.file = storage_dir / "dashboard_publications.json"
        self.file.parent.mkdir(parents=True, exist_ok=True)
        self._default_ttl_seconds = default_ttl_seconds
        self._clock = clock
        self._lock = RLock()

    @staticmethod
    def _hash(token: str) -> str:
        return hashlib.sha256(token.encode()).hexdigest()

    @staticmethod
    def _public(record: dict) -> DashboardPublication:
        latest = record["tokens"][-1]
        return DashboardPublication(
            id=record["id"],
            conversion_id=record["conversion_id"],
            connection_id=record["connection_id"],
            created_at=record["created_at"],
            expires_at=latest["expires_at"],
            revoked_at=record.get("revoked_at"),
            token_fingerprint=latest["fingerprint"],
        )

    def _load(self) -> list[dict]:
        if not self.file.is_file():
            return []
        return json.loads(self.file.read_text(encoding="utf-8"))

    def _save(self, records: list[dict]) -> None:
        temporary = self.file.with_suffix(".tmp")
        temporary.write_text(json.dumps(records, indent=2), encoding="utf-8")
        temporary.replace(self.file)

    def _new_token(self, now: float, ttl_seconds: int) -> tuple[str, dict]:
        token = f"pbic_dash_{secrets.token_urlsafe(32)}"
        token_hash = self._hash(token)
        return token, {
            "hash": token_hash,
            "fingerprint": token_hash[:12],
            "created_at": now,
            "expires_at": now + ttl_seconds,
            "revoke_after": None,
        }

    def create(
        self,
        conversion_id: str,
        connection_id: str,
        ttl_seconds: int | None = None,
    ) -> IssuedDashboardToken:
        now = self._clock()
        ttl = ttl_seconds or self._default_ttl_seconds
        token, token_record = self._new_token(now, ttl)
        record = {
            "id": str(uuid.uuid4()),
            "conversion_id": conversion_id,
            "connection_id": connection_id,
            "created_at": now,
            "revoked_at": None,
            "tokens": [token_record],
        }
        with self._lock:
            records = self._load()
            records.append(record)
            self._save(records)
        return IssuedDashboardToken(publication=self._public(record), token=token)

    def verify(self, token: str) -> DashboardPublication:
        candidate_hash = self._hash(token)
        now = self._clock()
        with self._lock:
            records = self._load()
        matched_record = None
        matched_token = None
        for record in records:
            for token_record in record["tokens"]:
                if hmac.compare_digest(candidate_hash, token_record["hash"]):
                    matched_record = record
                    matched_token = token_record
        if matched_record is None or matched_token is None:
            raise DashboardTokenError("invalid dashboard token")
        revoke_after = matched_token.get("revoke_after")
        if (
            matched_record.get("revoked_at") is not None
            or matched_token["expires_at"] <= now
            or (revoke_after is not None and revoke_after <= now)
        ):
            raise DashboardTokenError("invalid or expired dashboard token")
        public = self._public(matched_record)
        return public.model_copy(
            update={
                "expires_at": matched_token["expires_at"],
                "token_fingerprint": matched_token["fingerprint"],
            }
        )

    def list(self) -> list[DashboardPublication]:
        with self._lock:
            return [self._public(record) for record in self._load()]

    def rotate(
        self,
        publication_id: str,
        overlap_seconds: int = 0,
        ttl_seconds: int | None = None,
    ) -> IssuedDashboardToken:
        now = self._clock()
        ttl = ttl_seconds or self._default_ttl_seconds
        with self._lock:
            records = self._load()
            record = next((item for item in records if item["id"] == publication_id), None)
            if record is None or record.get("revoked_at") is not None:
                raise DashboardTokenError("dashboard publication not found")
            for token_record in record["tokens"]:
                if token_record.get("revoke_after") is None:
                    token_record["revoke_after"] = now + max(0, overlap_seconds)
            token, token_record = self._new_token(now, ttl)
            record["tokens"].append(token_record)
            self._save(records)
        return IssuedDashboardToken(publication=self._public(record), token=token)

    def revoke(self, publication_id: str) -> DashboardPublication:
        now = self._clock()
        with self._lock:
            records = self._load()
            record = next((item for item in records if item["id"] == publication_id), None)
            if record is None:
                raise DashboardTokenError("dashboard publication not found")
            record["revoked_at"] = now
            self._save(records)
        return self._public(record)