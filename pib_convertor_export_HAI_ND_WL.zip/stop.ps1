<#
.SYNOPSIS
  Stops the API/web processes started by start.ps1.
#>
$root = $PSScriptRoot
$pidFile = Join-Path $root '.dev-pids.json'

if (-not (Test-Path $pidFile)) {
    Write-Host "No .dev-pids.json found -- nothing started by start.ps1 to stop." -ForegroundColor Yellow
    exit 0
}

$pids = Get-Content $pidFile -Raw | ConvertFrom-Json
foreach ($entry in @(@{name='api'; pid=$pids.api}, @{name='web'; pid=$pids.web})) {
    $proc = Get-Process -Id $entry.pid -ErrorAction SilentlyContinue
    if ($proc) {
        # uv/npm launch a nested child (uvicorn's --reload spawns one too);
        # Stop-Process on just the top PID leaves those running, so use
        # taskkill's /T to kill the whole tree.
        Write-Host "Stopping $($entry.name) (pid $($entry.pid))"
        taskkill /F /T /PID $entry.pid | Out-Null
    } else {
        Write-Host "$($entry.name) (pid $($entry.pid)) already stopped"
    }
}
Remove-Item $pidFile -ErrorAction SilentlyContinue
