import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  authenticatePublishedSession,
  fetchVisualData,
} from '../dashboard/api'

const publishedConfig = {
  baseUrl: 'http://localhost:8000/api/v1/published',
  token: 'pbic_dash_secret',
  published: true,
}

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('published dashboard API', () => {
  it('uses the scoped route and bearer token without exposing a connection id', async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response(JSON.stringify({ results: [{ visual: 'sales', rows: [] }] }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      }),
    )
    vi.stubGlobal('fetch', fetchMock)

    await fetchVisualData('ignored-conversion', 'ignored-connection', 'Overview', ['sales'], {}, 'live', undefined, publishedConfig)

    const [url, init] = fetchMock.mock.calls[0] as [string, RequestInit]
    expect(url).toBe('http://localhost:8000/api/v1/published/dashboard/query')
    expect(init.headers).toMatchObject({
      Authorization: 'Bearer pbic_dash_secret',
      'Content-Type': 'application/json',
    })
    expect(JSON.parse(init.body as string)).toEqual({
      mode: 'live',
      queries: [{ page: 'Overview', visual: 'sales', filters: [] }],
    })
  })

  it('preserves the structured reauthentication error code', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn().mockResolvedValue(
        new Response(
          JSON.stringify({
            detail: {
              code: 'snowflake_reauthentication_required',
              message: 'Sign in to Snowflake again.',
            },
          }),
          { status: 401, headers: { 'Content-Type': 'application/json' } },
        ),
      ),
    )

    await expect(authenticatePublishedSession(publishedConfig)).rejects.toMatchObject({
      message: 'Sign in to Snowflake again.',
      code: 'snowflake_reauthentication_required',
    })
  })
})
