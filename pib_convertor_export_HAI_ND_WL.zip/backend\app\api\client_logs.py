"""Accepts client-side (browser) error reports so they land in the same
durable, redacted logs as backend events instead of vanishing on refresh.
"""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from app.api.deps import get_ingest_service, require_token
from app.core.logging import append_jsonl, get_logger, log_event
from app.services.ingest import IngestService

router = APIRouter(
    prefix="/api/v1/client-logs", tags=["client-logs"], dependencies=[Depends(require_token)]
)
_logger = get_logger("client")


class ClientErrorReport(BaseModel):
    message: str = Field(max_length=2000)
    path: str = Field(max_length=500)
    method: str | None = None
    status: int | None = None
    context: str | None = Field(default=None, max_length=200)
    conversion_id: str | None = None


@router.post("", status_code=204)
def report_client_error(
    report: ClientErrorReport,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
) -> None:
    fields = report.model_dump()
    log_event(_logger, "warning", "client_error", **fields)
    if report.conversion_id:
        try:
            events_path = svc.conversion_dir(report.conversion_id) / "events.jsonl"
            append_jsonl(events_path, "client_error", **fields)
        except (ValueError, OSError):
            pass  # best-effort: never let logging break the response
