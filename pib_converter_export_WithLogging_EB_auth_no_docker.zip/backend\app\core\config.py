from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

_DEFAULT_STORAGE = Path.home() / ".pbic" / "storage"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="PBIC_", env_file=".env", extra="ignore")

    storage_dir: Path = _DEFAULT_STORAGE
    max_upload_bytes: int = 300 * 1024 * 1024  # PBIR service cap
    # Fernet key for connection-secret encryption; generated on first run in dev
    secrets_key_file: Path = _DEFAULT_STORAGE / ".secrets.key"
    api_token: str = ""  # empty = auth disabled (local dev only)
    dashboard_token_ttl_seconds: int = 30 * 24 * 3600
    openai_api_key: str = ""
    database_url: str = "postgresql://pbic:pbic@localhost:5432/pbic"
    log_level: str = "INFO"
    # SQL text is useful for troubleshooting but may embed literal filter
    # values a user picked (business data, not credentials); off switch here.
    log_sql_text: bool = True

    @property
    def log_dir(self) -> Path:
        return self.storage_dir / "logs"


@lru_cache
def get_settings() -> Settings:
    return Settings()
