"""Process-local Snowflake sessions for the native Windows application."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from contextlib import contextmanager
from threading import Lock, RLock
from typing import Any

from app.services.connections import AuthMethod, ConnectionStore


class SnowflakeAuthenticationRequired(Exception):
    """Raised when an interactive profile has no active authenticated session."""


class _ManagedCursor:
    def __init__(
        self, cursor: Any, connection: _ManagedConnection, release_connection: bool = False
    ):
        self._cursor = cursor
        self.connection = connection
        self._release_connection = release_connection
        self._closed = False

    def __getattr__(self, name: str) -> Any:
        return getattr(self._cursor, name)

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._cursor.close()
            if self._release_connection:
                self.connection.close()


class _ManagedConnection:
    def __init__(self, connection: Any, lease: Any):
        self._connection = connection
        self._lease = lease
        self._cursors: list[_ManagedCursor] = []
        self._closed = False

    def __getattr__(self, name: str) -> Any:
        return getattr(self._connection, name)

    def cursor(self, *args: Any, **kwargs: Any) -> _ManagedCursor:
        cursor = self._open_cursor(False, *args, **kwargs)
        return cursor

    def _open_cursor(
        self, release_connection: bool, *args: Any, **kwargs: Any
    ) -> _ManagedCursor:
        cursor = _ManagedCursor(
            self._connection.cursor(*args, **kwargs), self, release_connection
        )
        self._cursors.append(cursor)
        return cursor

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        for cursor in self._cursors:
            cursor.close()
        self._lease.__exit__(None, None, None)


class SnowflakeSessionManager:
    def __init__(
        self,
        store: ConnectionStore,
        connect: Callable[..., Any] | None = None,
    ):
        self._store = store
        self._connect_override = connect
        self._connections: dict[str, Any] = {}
        self._locks: dict[str, RLock] = {}
        self._state_lock = Lock()

    def _lock_for(self, profile_id: str) -> RLock:
        with self._state_lock:
            return self._locks.setdefault(profile_id, RLock())

    def _connect(self, profile_id: str, query_tag: str | None = None):
        connect = self._connect_override
        if connect is None:
            import snowflake.connector

            connect = snowflake.connector.connect
        kwargs = self._store.connector_kwargs(profile_id, query_tag=query_tag)
        return connect(**kwargs, login_timeout=120, network_timeout=30)

    @staticmethod
    def _is_open(connection: Any | None) -> bool:
        if connection is None:
            return False
        try:
            return not connection.is_closed()
        except (AttributeError, TypeError):
            return True

    @staticmethod
    def _close(connection: Any | None) -> None:
        if connection is None:
            return
        try:
            connection.close()
        except Exception:  # noqa: BLE001 - cleanup must remain best effort
            pass

    def authenticate(self, profile_id: str, query_tag: str = "pbic:authenticate"):
        """Establish a session. This is the only operation allowed to launch SSO."""
        lock = self._lock_for(profile_id)
        with lock:
            current = self._connections.get(profile_id)
            if self._is_open(current):
                return current

            connection = self._connect(profile_id, query_tag)
            previous = self._connections.pop(profile_id, None)
            self._connections[profile_id] = connection
            self._close(previous)
            return connection

    @contextmanager
    def lease(self, profile_id: str, query_tag: str = "pbi_converter") -> Iterator[Any]:
        lock = self._lock_for(profile_id)
        with lock:
            connection = self._connections.get(profile_id)
            if not self._is_open(connection):
                self._connections.pop(profile_id, None)
                self._close(connection)
                profile = self._store.get(profile_id)
                if profile.auth_method == AuthMethod.EXTERNAL_BROWSER:
                    raise SnowflakeAuthenticationRequired(
                        "Snowflake browser authentication is required"
                    )
                connection = self._connect(profile_id, query_tag)
                self._connections[profile_id] = connection
            else:
                cursor = connection.cursor()
                try:
                    cursor.execute("ALTER SESSION SET QUERY_TAG = %s", (query_tag,))
                finally:
                    cursor.close()
            yield connection

    def status(self, profile_id: str) -> dict[str, bool]:
        self._store.get(profile_id)
        lock = self._lock_for(profile_id)
        with lock:
            connection = self._connections.get(profile_id)
            authenticated = self._is_open(connection)
            if not authenticated:
                self._connections.pop(profile_id, None)
                self._close(connection)
            return {"authenticated": authenticated}

    def open_connection(
        self, profile_id: str, query_tag: str = "pbi_converter"
    ) -> _ManagedConnection:
        """Return a close-compatible lease for existing synchronous call sites."""
        lease = self.lease(profile_id, query_tag)
        connection = lease.__enter__()
        return _ManagedConnection(connection, lease)

    def open_cursor(self, profile_id: str, query_tag: str = "pbi_converter") -> _ManagedCursor:
        connection = self.open_connection(profile_id, query_tag)
        return connection._open_cursor(True)

    def evict(self, profile_id: str) -> None:
        lock = self._lock_for(profile_id)
        with lock:
            self._close(self._connections.pop(profile_id, None))

    def close_all(self) -> None:
        with self._state_lock:
            profile_ids = list(self._connections)
        for profile_id in profile_ids:
            self.evict(profile_id)