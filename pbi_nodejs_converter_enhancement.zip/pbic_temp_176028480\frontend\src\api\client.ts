import { reportClientError } from './errorReporting'
import type {
  ConnectionProfile,
  ConnectionSessionStatus,
  ConnectionTestResult,
  ConnectionUpdate,
  ConversionSummary,
  DashboardPublication,
  IssuedDashboardToken,
  CompilationAuditData,
  DaxRewrite,
  MeasureSqlResult,
  NoSqlPane,
  NoSqlPaneDetail,
  QueryAudit,
  RecheckResult,
  SqlEditorInfo,
  SqlTestResult,
  LlmProviders,
  PreflightResult,
  SourceHints,
  NewConnection,
  NewSourceConnection,
  SourceConnectionProfile,
} from './types'

const BASE = '/api/v1'

export async function readErrorDetail(res: Response): Promise<string> {
  let detail = res.statusText
  const contentType = res.headers.get('content-type') ?? ''

  try {
    if (contentType.includes('application/json')) {
      const body = await res.json()
      return typeof body.detail === 'string' ? body.detail : JSON.stringify(body.detail)
    }

    const text = (await res.text()).trim()
    // proxy/gateway error pages are HTML — show a readable message instead
    if (/<html|<head|<body/i.test(text)) {
      if (res.status === 504)
        return 'The request timed out at the gateway (504). The operation may still be running server-side — check progress or retry shortly.'
      return `${res.status} ${res.statusText || 'gateway error'}`
    }
    if (text) return text
  } catch {
    /* fall back to statusText */
  }

  return detail
}

export async function handle<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const message = await readErrorDetail(res)
    reportClientError({ message, path: res.url, status: res.status })
    throw new Error(message)
  }
  if (res.status === 204) return undefined as T
  return res.json() as Promise<T>
}

function exportDashboard(conversionId: string, connectionId: string): Promise<Blob>
function exportDashboard(conversionId: string, connectionId: string, kind: 'react'): Promise<Blob>
function exportDashboard(
  conversionId: string,
  connectionId: string,
  kind: 'standalone',
): Promise<{ blob: Blob; filename: string }>
async function exportDashboard(
  conversionId: string,
  connectionId: string,
  kind: 'react' | 'standalone' = 'react',
): Promise<Blob | { blob: Blob; filename: string }> {
  const response = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/${kind === 'standalone' ? 'export-standalone' : 'export'}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ connection_id: connectionId }),
    },
  )
  if (!response.ok) {
    const message = await readErrorDetail(response)
    reportClientError({ message, path: response.url, status: response.status, context: 'export' })
    throw new Error(message)
  }
  const blob = await response.blob()
  if (kind === 'react') return blob
  const match = /filename="?([^";]+)"?/i.exec(response.headers.get('content-disposition') ?? '')
  return { blob, filename: match?.[1] ?? 'dashboard-standalone.zip' }
}

export const api = {
  uploadPbip(file: File, name?: string): Promise<ConversionSummary> {
    const form = new FormData()
    form.append('file', file)
    if (name?.trim()) form.append('name', name.trim())
    return fetch(`${BASE}/conversions`, { method: 'POST', body: form }).then((r) =>
      handle<ConversionSummary>(r),
    )
  },
  deleteConversion(id: string): Promise<void> {
    return fetch(`${BASE}/conversions/${id}`, { method: 'DELETE' }).then((r) => handle<void>(r))
  },
  renameJob(id: string, name: string): Promise<{ id: string; name: string }> {
    return fetch(`${BASE}/conversions/${id}/name`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    }).then((r) => handle<{ id: string; name: string }>(r))
  },
  listConversions(): Promise<ConversionSummary[]> {
    return fetch(`${BASE}/conversions`).then((r) => handle<ConversionSummary[]>(r))
  },
  getConversion(id: string): Promise<ConversionSummary> {
    return fetch(`${BASE}/conversions/${id}`).then((r) => handle<ConversionSummary>(r))
  },
  createConnection(spec: NewConnection): Promise<ConnectionProfile> {
    return fetch(`${BASE}/connections`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(spec),
    }).then((r) => handle<ConnectionProfile>(r))
  },
  listConnections(): Promise<ConnectionProfile[]> {
    return fetch(`${BASE}/connections`).then((r) => handle<ConnectionProfile[]>(r))
  },
  deleteConnection(id: string): Promise<void> {
    return fetch(`${BASE}/connections/${id}`, { method: 'DELETE' }).then((r) => handle<void>(r))
  },
  updateConnection(id: string, patch: ConnectionUpdate): Promise<ConnectionProfile> {
    return fetch(`${BASE}/connections/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    }).then((r) => handle<ConnectionProfile>(r))
  },
  testConnection(
    id: string,
    passcode?: string,
    opts?: { force?: boolean },
  ): Promise<ConnectionTestResult> {
    const body: Record<string, unknown> = {}
    if (passcode) body.passcode = passcode
    if (opts?.force) body.force = true
    const hasBody = Object.keys(body).length > 0
    return fetch(`${BASE}/connections/${id}/test`, {
      method: 'POST',
      ...(hasBody
        ? { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
        : {}),
    }).then((r) => handle<ConnectionTestResult>(r))
  },
  connectionSession(id: string, opts?: { verify?: boolean }): Promise<ConnectionSessionStatus> {
    const q = opts?.verify ? '?verify=true' : ''
    return fetch(`${BASE}/connections/${id}/session${q}`).then((r) =>
      handle<ConnectionSessionStatus>(r),
    )
  },
  daxRewrites(conversionId: string): Promise<{ rewrites: Record<string, DaxRewrite> }> {
    return fetch(`${BASE}/conversions/${conversionId}/dashboard/dax-rewrites`).then((r) =>
      handle<{ rewrites: Record<string, DaxRewrite> }>(r),
    )
  },
  revertDaxRewrite(
    conversionId: string,
    measure: string,
  ): Promise<{ reverted: string; remaining: string[] }> {
    return fetch(
      `${BASE}/conversions/${conversionId}/dashboard/dax-rewrites/${encodeURIComponent(measure)}`,
      { method: 'DELETE' },
    ).then((r) => handle<{ reverted: string; remaining: string[] }>(r))
  },
  llmProviders(): Promise<LlmProviders> {
    return fetch(`${BASE}/llm/providers`).then((r) => handle<LlmProviders>(r))
  },
  sourceHints(conversionId: string): Promise<SourceHints> {
    return fetch(`${BASE}/conversions/${conversionId}/source-hints`).then((r) =>
      handle<SourceHints>(r),
    )
  },
  preflight(
    conversionId: string,
    body: {
      connection_id: string
      database_override?: string | null
      schema_override?: string | null
    },
  ): Promise<PreflightResult> {
    return fetch(`${BASE}/conversions/${conversionId}/dashboard/preflight`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then((r) => handle<PreflightResult>(r))
  },
  exportDashboard,
  listDashboardPublications(): Promise<DashboardPublication[]> {
    return fetch(`${BASE}/dashboard-publications`).then((response) =>
      handle<DashboardPublication[]>(response),
    )
  },
  rotateDashboardPublication(
    id: string,
    overlapSeconds = 0,
  ): Promise<IssuedDashboardToken> {
    return fetch(`${BASE}/dashboard-publications/${id}/rotate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ overlap_seconds: overlapSeconds }),
    }).then((response) => handle<IssuedDashboardToken>(response))
  },
  revokeDashboardPublication(id: string): Promise<DashboardPublication> {
    return fetch(`${BASE}/dashboard-publications/${id}`, { method: 'DELETE' }).then((response) =>
      handle<DashboardPublication>(response),
    )
  },
  listSourceKinds(): Promise<{ id: string; label: string; available: boolean }[]> {
    return fetch(`${BASE}/source-connections/kinds`).then((r) =>
      handle<{ id: string; label: string; available: boolean }[]>(r),
    )
  },
  createSourceConnection(spec: NewSourceConnection): Promise<SourceConnectionProfile> {
    return fetch(`${BASE}/source-connections`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(spec),
    }).then((r) => handle<SourceConnectionProfile>(r))
  },
  listSourceConnections(): Promise<SourceConnectionProfile[]> {
    return fetch(`${BASE}/source-connections`).then((r) =>
      handle<SourceConnectionProfile[]>(r),
    )
  },
  deleteSourceConnection(id: string): Promise<void> {
    return fetch(`${BASE}/source-connections/${id}`, { method: 'DELETE' }).then((r) =>
      handle<void>(r),
    )
  },
  testSourceConnection(id: string): Promise<{ ok: boolean }> {
    return fetch(`${BASE}/source-connections/${id}/test`, { method: 'POST' }).then((r) =>
      handle<{ ok: boolean }>(r),
    )
  },
  getMigrationResult(conversionId: string): Promise<{ ran: boolean; ok?: boolean; tables?: unknown[] }> {
    return fetch(`${BASE}/conversions/${conversionId}/migration`).then((r) =>
      handle<{ ran: boolean; ok?: boolean; tables?: unknown[] }>(r),
    )
  },
}

export interface QueryAuditParams {
  kind?: string
  source?: string
  page?: string
  history_for?: string
  status?: string
  search?: string
}

function auditQuery(params: QueryAuditParams): string {
  const q = new URLSearchParams()
  for (const [k, v] of Object.entries(params)) if (v) q.set(k, v)
  const text = q.toString()
  return text ? `?${text}` : ''
}

const dashboardUrl = (id: string, path: string) => `${BASE}/conversions/${id}/dashboard/${path}`

function sendJson<T>(method: string, url: string, body: unknown): Promise<T> {
  return fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  }).then((r) => handle<T>(r))
}

export const auditApi = {
  queryAudit(id: string, params: QueryAuditParams = {}): Promise<QueryAudit> {
    return fetch(dashboardUrl(id, `query-audit${auditQuery(params)}`)).then((r) =>
      handle<QueryAudit>(r),
    )
  },
  queryAuditExportUrl(id: string, format: 'xlsx' | 'json', params: QueryAuditParams = {}): string {
    return dashboardUrl(id, `query-audit/export${auditQuery({ ...params, ...{ format } })}`)
  },
  sqlEditor(id: string, page: string, visual: string): Promise<SqlEditorInfo> {
    const q = new URLSearchParams({ page, visual })
    return fetch(dashboardUrl(id, `sql-editor?${q}`)).then((r) => handle<SqlEditorInfo>(r))
  },
  testSql(
    id: string,
    body: { page: string; visual: string; connection_id: string; sql: string; filters?: unknown[] },
  ): Promise<SqlTestResult> {
    return sendJson('POST', dashboardUrl(id, 'sql-overrides/test'), { filters: [], ...body })
  },
  saveSql(id: string, body: { page: string; visual: string; sql: string }) {
    return sendJson<{ override: unknown }>('PUT', dashboardUrl(id, 'sql-overrides'), body)
  },
  deleteSql(id: string, page: string, visual: string): Promise<{ deleted: boolean }> {
    return fetch(
      dashboardUrl(id, `sql-overrides/${encodeURIComponent(page)}/${encodeURIComponent(visual)}`),
      { method: 'DELETE' },
    ).then((r) => handle<{ deleted: boolean }>(r))
  },
  noSqlPanes(id: string): Promise<{ panes: NoSqlPane[] }> {
    return fetch(dashboardUrl(id, 'no-sql-panes')).then((r) => handle<{ panes: NoSqlPane[] }>(r))
  },
  noSqlPane(id: string, page: string, visual: string): Promise<NoSqlPaneDetail> {
    return fetch(
      dashboardUrl(id, `no-sql-panes/${encodeURIComponent(page)}/${encodeURIComponent(visual)}`),
    ).then((r) => handle<NoSqlPaneDetail>(r))
  },
  recheck(
    id: string,
    body: { page: string; visual: string; connection_id: string },
  ): Promise<RecheckResult> {
    return sendJson('POST', dashboardUrl(id, 'recheck'), body)
  },
  compilationAudit(id: string): Promise<CompilationAuditData> {
    return fetch(dashboardUrl(id, 'compilation-audit')).then((r) =>
      handle<CompilationAuditData>(r),
    )
  },
  compilationAuditExportUrl(id: string, format: 'xlsx' | 'json'): string {
    return dashboardUrl(id, `compilation-audit/export?format=${format}`)
  },
  testMeasureSql(
    id: string,
    body: { measure: string; sql: string; connection_id: string },
  ): Promise<MeasureSqlResult> {
    return sendJson('POST', dashboardUrl(id, 'measure-sql/test'), body)
  },
  saveMeasureSql(id: string, body: { measure: string; sql: string }) {
    return sendJson<{ fix: unknown }>('PUT', dashboardUrl(id, 'measure-sql'), body)
  },
  measureSqlFixes(id: string): Promise<{ fixes: Record<string, { sql: string; original: string }> }> {
    return fetch(dashboardUrl(id, 'measure-sql')).then((r) =>
      handle<{ fixes: Record<string, { sql: string; original: string }> }>(r),
    )
  },
  revertMeasureSql(id: string, measure: string): Promise<{ reverted: string; remaining: string[] }> {
    return fetch(dashboardUrl(id, `measure-sql/${encodeURIComponent(measure)}`), {
      method: 'DELETE',
    }).then((r) => handle<{ reverted: string; remaining: string[] }>(r))
  },
}
