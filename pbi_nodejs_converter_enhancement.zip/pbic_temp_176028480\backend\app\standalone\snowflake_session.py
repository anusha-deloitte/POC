"""The standalone dashboard's Snowflake session: the user's own sign-in, five methods.

Key pair, PAT, OAuth client credentials and plain-password logins reconnect silently when the
session expires; browser SSO and MFA wait for the user (`authenticate`). Shipped verbatim inside
the package as `service/snowflake_session.py`.
"""

from __future__ import annotations

import json
import re
import sys
import threading
import webbrowser
from collections.abc import Callable
from typing import Any

try:
    from .connection_store import ConnectionStore, SettingsError, identifier
except ImportError:  # shipped flat in service/
    from connection_store import ConnectionStore, SettingsError, identifier  # type: ignore

__all__ = ["AuthenticationRequired", "SettingsError", "Session"]

_PASSCODE_RE = re.compile(r"^\d{6,8}$")
_MFA_ERROR_RE = re.compile(r"\b394508\b|MFA with TOTP|TOTP passcode", re.IGNORECASE)
_SETTINGS_HINT = "open Connection settings"


class AuthenticationRequired(Exception):
    def __init__(self, message: str, mfa_required: bool = False):
        super().__init__(message)
        self.mfa_required = mfa_required


def _private_key_der(pem: str, passphrase: str | None) -> bytes:
    from cryptography.hazmat.primitives import serialization

    password = passphrase.encode() if passphrase else None
    try:
        key = serialization.load_pem_private_key(pem.encode(), password=password)
    except TypeError as e:
        if password and "not encrypted" in str(e):  # a passphrase sent for an unencrypted key
            key = serialization.load_pem_private_key(pem.encode(), password=None)
        else:
            raise ValueError(str(e)) from e
    return key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def _fetch_oauth_token(url: str, client_id: str, client_secret: str) -> str:
    import urllib.parse
    import urllib.request

    body = urllib.parse.urlencode(
        {"grant_type": "client_credentials", "client_id": client_id, "client_secret": client_secret}
    ).encode()
    req = urllib.request.Request(  # noqa: S310 - the user's own token endpoint
        url, data=body, headers={"Content-Type": "application/x-www-form-urlencoded"}
    )
    with urllib.request.urlopen(req, timeout=30) as resp:  # noqa: S310
        return json.loads(resp.read())["access_token"]


class Session:
    def __init__(
        self,
        store: ConnectionStore,
        query_tag: str = "pbi_standalone_dashboard",
        connect: Callable[..., Any] | None = None,
    ):
        self._store = store
        self._query_tag = query_tag
        self._connect_fn = connect
        self._lock = threading.RLock()  # the connection and what is applied to it
        self._state = threading.Lock()  # status fields: never held while signing in
        self._connection: Any = None
        self._applied: tuple[str | None, str] | None = None
        self._settings_error: str | None = None
        self._last_error: str | None = None
        self._signing_in = False
        self._sso_url: str | None = None
        self._mfa = False
        self._who: dict[str, str | None] = {}

    # ------------------------------------------------------------------ connecting

    def _kwargs(self, passcode: str | None) -> dict[str, Any]:
        s = self._store.settings()
        method = s["auth_method"] or "external_browser"
        if not s["account"] or not s["user"]:
            raise AuthenticationRequired(
                f"Snowflake account and user are not set: {_SETTINGS_HINT}"
            )
        if not (s["warehouse"] or "").strip():
            raise AuthenticationRequired(f"no warehouse is set: {_SETTINGS_HINT}")
        kwargs: dict[str, Any] = {
            "account": s["account"],
            "user": s["user"],
            "session_parameters": {"QUERY_TAG": self._query_tag},
        }
        if s["database"]:
            kwargs["database"] = s["database"]
        if s["schema"]:
            kwargs["schema"] = s["schema"]

        def need(name: str, label: str) -> str:
            value = self._store.secret(name)
            if not value:
                raise AuthenticationRequired(f"{label} is not set: {_SETTINGS_HINT}")
            return value

        if method == "password":
            kwargs["password"] = need("password", "the password")
            if passcode:
                if not _PASSCODE_RE.match(passcode):
                    raise AuthenticationRequired(
                        "MFA passcode must be the 6-8 digit code from your authenticator",
                        mfa_required=True,
                    )
                kwargs["passcode"] = passcode
            if passcode or self._mfa:
                kwargs["authenticator"] = "username_password_mfa"
        elif method == "key_pair":
            kwargs["private_key"] = _private_key_der(
                need("private_key_pem", "the private key"),
                self._store.secret("private_key_passphrase"),
            )
        elif method == "oauth_client_credentials":
            if not (s["oauth_client_id"] and s["oauth_token_url"]):
                raise AuthenticationRequired(
                    f"OAuth client id / token URL not set: {_SETTINGS_HINT}"
                )
            kwargs["authenticator"] = "oauth"
            kwargs["token"] = _fetch_oauth_token(
                s["oauth_token_url"],
                s["oauth_client_id"],
                need("oauth_client_secret", "the client secret"),
            )
        elif method == "pat":
            kwargs["authenticator"] = "programmatic_access_token"
            kwargs["token"] = need("pat_token", "the access token")
        else:
            kwargs["authenticator"] = "externalbrowser"
            kwargs["client_store_temporary_credential"] = True
        return kwargs

    def _connect(self, passcode: str | None = None) -> Any:
        connect = self._connect_fn
        if connect is None:
            import snowflake.connector

            connect = snowflake.connector.connect
        method = self._store.settings()["auth_method"]
        kwargs = self._kwargs((passcode or "").strip() or None)
        try:
            if method == "external_browser":
                return self._connect_via_browser(connect, kwargs)
            conn = connect(**kwargs, login_timeout=120, network_timeout=30)
            if method == "password":
                self._mfa = (
                    "passcode" in kwargs or kwargs.get("authenticator") == "username_password_mfa"
                )
            return conn
        except AuthenticationRequired:
            raise
        except Exception as e:
            if method == "password" and _MFA_ERROR_RE.search(str(e)):
                self._mfa = True
                suffix = " (the code was rejected or expired)" if passcode else ""
                raise AuthenticationRequired(
                    "Snowflake requires MFA for this user: enter the current 6-digit code "
                    "from your authenticator app and sign in again" + suffix,
                    mfa_required=True,
                ) from e
            raise

    def _connect_via_browser(self, connect: Callable[..., Any], kwargs: dict[str, Any]) -> Any:
        """SSO, capturing the sign-in URL so the page can show it when no browser opens."""
        real_new, real_open = webbrowser.open_new, webbrowser.open

        def capture(url: str, *args: Any, **kw: Any) -> bool:
            with self._state:
                self._sso_url = url
            print(f"[pbi-standalone] Snowflake SSO sign-in URL: {url}", file=sys.stderr)
            webbrowser.open_new, webbrowser.open = real_new, real_open
            try:
                return real_new(url)
            finally:
                webbrowser.open_new = webbrowser.open = capture

        webbrowser.open_new = webbrowser.open = capture
        try:
            return connect(**kwargs, login_timeout=120, network_timeout=30)
        finally:
            webbrowser.open_new, webbrowser.open = real_new, real_open
            with self._state:
                self._sso_url = None

    @staticmethod
    def _is_open(connection: Any) -> bool:
        if connection is None:
            return False
        try:
            return not connection.is_closed()
        except (AttributeError, TypeError):
            return True

    @staticmethod
    def _close(connection: Any) -> None:
        if connection is None:
            return
        try:
            connection.close()
        except Exception:  # noqa: BLE001, S110 - cleanup is best effort
            pass

    def _method(self) -> str:
        return self._store.settings()["auth_method"] or "external_browser"

    # ------------------------------------------------------------------ role / warehouse

    def apply_settings(self) -> None:
        """Re-apply role / warehouse on the open session (`USE ROLE` / `USE WAREHOUSE`)."""
        with self._lock:
            conn = self._connection
            if not self._is_open(conn):
                self._applied = None
                return
            self._apply(conn)

    def _apply(self, conn: Any) -> None:
        s = self._store.settings()
        role, warehouse = (s["role"] or None), (s["warehouse"] or "").strip()
        if self._applied == (role, warehouse):
            return
        cur = conn.cursor()
        try:
            try:
                if role:
                    cur.execute(f"USE ROLE {identifier(role)}")
                cur.execute(f"USE WAREHOUSE {identifier(warehouse)}")
            except Exception as e:  # noqa: BLE001 - the connector raises many types
                self._applied = None
                message = (
                    f"signed in, but role/warehouse could not be activated "
                    f"(role {role or 'default'}, warehouse {warehouse}): {e}"
                )
                with self._state:
                    self._settings_error = message
                return
            self._applied = (role, warehouse)
            with self._state:
                self._settings_error = None
            self._read_who(cur)
        finally:
            cur.close()

    def _read_who(self, cur: Any) -> None:
        try:
            cur.execute("SELECT CURRENT_USER(), CURRENT_ROLE(), CURRENT_WAREHOUSE()")
            row = cur.fetchone()
            if row:
                with self._state:
                    self._who = {
                        "current_user": row[0], "current_role": row[1], "current_warehouse": row[2],
                    }  # fmt: skip
        except Exception:  # noqa: BLE001, S110 - decoration only
            pass

    # ------------------------------------------------------------------ public API

    def authenticate(self, passcode: str | None = None) -> None:
        """Sign in (the only call that may open the SSO browser or use an MFA code)."""
        with self._state:
            self._signing_in = True
            self._last_error = None
        try:
            with self._lock:
                connection = self._connect(passcode)
                previous, self._connection = self._connection, connection
                self._close(previous)
                self._applied = None
                self._apply(connection)
        except AuthenticationRequired as e:
            with self._state:
                self._last_error = str(e)
            raise
        except Exception as e:
            with self._state:
                self._last_error = str(e)[:500]
            raise
        finally:
            with self._state:
                self._signing_in = False

    def _ensure(self) -> Any:
        """The open connection; silent methods reconnect, SSO / MFA ask the user to sign in."""
        with self._lock:
            conn = self._connection
            if self._is_open(conn):
                return conn
            self._close(conn)
            self._connection = None
            self._applied = None
            method = self._method()
            if method == "external_browser":
                raise AuthenticationRequired("Snowflake browser authentication is required")
            if method == "password" and self._mfa:
                raise AuthenticationRequired(
                    "Snowflake requires MFA for this user: enter the current code to sign in",
                    mfa_required=True,
                )
            self._connection = self._connect()
            self._apply(self._connection)
            return self._connection

    def run(self, sql: str) -> tuple[list[str], list[list], str | None]:
        """`(columns, rows, query_id)` on a cursor of its own (safe from several threads)."""
        conn = self._ensure()
        cur = conn.cursor()
        try:
            try:
                cur.execute(sql)
            except Exception as e:  # an expired token surfaces here; reconnect once when silent
                if self._method() in ("external_browser",) or not self._expired(e):
                    raise
                with self._lock:
                    if self._connection is conn:
                        self._close(conn)
                        self._connection = None
                        self._applied = None
                conn = self._ensure()
                cur.close()
                cur = conn.cursor()
                cur.execute(sql)
            columns = [d[0] for d in cur.description or []]
            rows = [list(r) for r in cur.fetchall()]
            return columns, rows, getattr(cur, "sfqid", None)
        finally:
            cur.close()

    @staticmethod
    def _expired(error: Exception) -> bool:
        text = str(error).lower()
        return any(w in text for w in ("expired", "session no longer exists", "390114", "390111"))

    def reset(self) -> None:
        """Drop the connection (settings changed); the next call signs in again."""
        with self._lock:
            self._close(self._connection)
            self._connection = None
            self._applied = None
        with self._state:
            self._last_error = None
            self._settings_error = None
            self._who = {}

    def sign_out(self) -> None:
        self.reset()
        self._mfa = False

    def status(self) -> dict[str, Any]:
        s = self._store.settings()
        with self._state:
            sso_url, signing_in = self._sso_url, self._signing_in
            settings_error, last_error, who = (
                self._settings_error,
                self._last_error,
                dict(self._who),
            )
        if signing_in:  # a sign-in holds the connection lock: never wait for it here
            authenticated = False
        else:
            with self._lock:
                authenticated = self._is_open(self._connection)
        return {
            "auth_method": s["auth_method"],
            "account": s["account"],
            "user": s["user"],
            "role": s["role"],
            "warehouse": s["warehouse"],
            **who,
            "authenticated": authenticated,
            "signing_in": signing_in,
            "sso_url": sso_url,
            "mfa_required": (not authenticated) and self._method() == "password" and self._mfa,
            "settings_error": settings_error if authenticated else None,
            "last_error": last_error,
        }
