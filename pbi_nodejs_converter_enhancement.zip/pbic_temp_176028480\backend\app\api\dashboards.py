import json
import os
import re
import threading
import time
from functools import lru_cache
from pathlib import Path
from typing import Annotated, Literal

import yaml
from fastapi import APIRouter, Depends, Form, HTTPException, Response, UploadFile
from pydantic import BaseModel, Field

from app.agents.reimagine import (
    DashboardRecommendation,
    build_recommendation,
    latest_recommendation,
    list_recommendations,
    load_recommendation,
    save_recommendation,
    save_snapshot,
    update_recommendation_status,
)
from app.api.deps import (
    get_connection_store,
    get_dashboard_token_store,
    get_ingest_service,
    require_token,
)
from app.binding.resolver import BindingMap, build_bundle_binding_map, quote_ident
from app.core.config import get_settings
from app.core.logging import get_logger, log_event
from app.ir.report import AskDataPolicy
from app.runtime import pbir_passthrough as _pt
from app.runtime.dashboard import (
    DashboardSpec,
    VisualSpec,
    compile_dashboard,
    default_filter_clauses,
    filter_values_query,
)
from app.runtime.engine import (
    DimensionRef,
    FilterClause,
    MeasureRefSpec,
    QueryPlanError,
    QuerySpec,
    SemanticEngine,
)
from app.runtime.semantic_governance import QueryExecutionTier, cache_key, trace_codes
from app.runtime.semantic_view import (
    SemanticViewAdapter,
    SemanticViewPlanError,
    SemanticViewRequest,
)
from app.semantic.yaml_compiler import SemanticViewYamlCompiler, prune_spec_to_live_schema
from app.services import query_audit as _qa
from app.services import sql_overrides as _sqlo
from app.services.connections import ConnectionStore
from app.services.dashboard_tokens import DashboardTokenStore
from app.services.ingest import IngestError, IngestService
from app.services.snowflake_sessions import SnowflakeAuthenticationRequired
from app.validation.golden import compare_against_golden, load_golden
from app.validation.harness import run_dual_run_parity

_query_logger = get_logger("dashboard_query")

router = APIRouter(
    prefix="/api/v1/conversions/{conversion_id}/dashboard",
    tags=["dashboard"],
    dependencies=[Depends(require_token)],
)

_TTL_SECONDS = 300
_result_cache: dict[str, tuple[float, dict]] = {}


def _tier2_sql(conversion_id: str, svc: IngestService | None = None) -> dict[str, str]:
    """Execution-validated LLM SQL persisted by the conversion pipeline."""
    import json as _json

    svc = svc or get_ingest_service()
    try:
        path = svc.conversion_dir(conversion_id) / "conversion_run.json"
    except ValueError:
        return {}
    if not path.is_file():
        return {}
    try:
        return _json.loads(path.read_text(encoding="utf-8")).get("tier2_accepted", {})
    except (OSError, ValueError):
        return {}


def _reimagine_dir(conversion_id: str) -> Path:
    svc = get_ingest_service()
    try:
        conv_dir = svc.conversion_dir(conversion_id)
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e
    out_dir = conv_dir / "recommendations"
    out_dir.mkdir(exist_ok=True)
    return out_dir


_content_hashes: dict[tuple[str, str, float], str] = {}


def _content_hash(conversion_id: str, storage_dir: str, mtime: float, bundle) -> str:
    """Hash of model + report only: saving binding settings (case fixes, overrides)
    changes bundle.json but never forces a recompile."""
    import hashlib

    key = (conversion_id, storage_dir, mtime)
    cached = _content_hashes.get(key)
    if cached is None:
        digest = hashlib.sha256()
        digest.update(bundle.model.model_dump_json().encode())
        digest.update(bundle.report.model_dump_json().encode())
        cached = digest.hexdigest()
        if len(_content_hashes) > 64:
            _content_hashes.clear()
        _content_hashes[key] = cached
    return cached


@lru_cache(maxsize=8)
def _compiled(
    conversion_id: str,
    storage_dir: str,
    content_hash: str,
    run_mtime: float,
    overrides_mtime: float,
    sql_mtime: float = 0.0,
) -> tuple[DashboardSpec, BindingMap]:
    from app.services.overrides import apply_overrides, load_overrides

    svc = IngestService(Path(storage_dir))
    bundle = svc.load_bundle(conversion_id)
    spec, bm = compile_dashboard(bundle, tier2_sql=_tier2_sql(conversion_id, svc))
    overrides = load_overrides(svc.conversion_dir(conversion_id))
    if overrides:
        spec.warnings.extend(apply_overrides(spec, overrides))
    # hand-edited SQL of untranslated panes: the front end requests them, `_apply_sql_overrides`
    # runs the edit
    edits = _sqlo.load_overrides(svc.conversion_dir(conversion_id))
    for page in spec.pages:
        for vs in page.visuals:
            edit = edits.get(_sqlo.key_for(page.name, vs.name))
            if edit and vs.data_status == "untranslated":
                vs.manual_sql = edit["sql"]
    return spec, bm


def _load(
    conversion_id: str, svc: IngestService | None = None
) -> tuple[DashboardSpec, BindingMap, SemanticEngine]:
    from app.services.overrides import overrides_mtime

    svc = svc or get_ingest_service()
    try:
        conv_dir = svc.conversion_dir(conversion_id)
        mtime = (conv_dir / "bundle.json").stat().st_mtime
    except (ValueError, FileNotFoundError) as e:
        raise HTTPException(404, "conversion not found") from e
    run_file = conv_dir / "conversion_run.json"
    run_mtime = run_file.stat().st_mtime if run_file.is_file() else 0.0
    try:
        bundle = svc.load_bundle(conversion_id)
        storage = str(svc.storage_dir.resolve())
        spec, _compiled_bindings = _compiled(
            conversion_id,
            storage,
            _content_hash(conversion_id, storage, mtime, bundle),
            run_mtime,
            overrides_mtime(conv_dir),
            _sqlo.overrides_mtime(conv_dir),
        )
    except IngestError as e:
        raise HTTPException(404, "conversion not found") from e
    # bindings are rebuilt per request so overrides and case fixes apply immediately
    binding_map = build_bundle_binding_map(bundle)
    binding_map = _apply_deployed_materializations(
        binding_map,
        _latest_semantic_deployment(conversion_id),
    )
    engine = SemanticEngine(bundle.model, binding_map, tier2_sql=_tier2_sql(conversion_id, svc))
    return spec, binding_map, engine


def _default_semantic_target(store: ConnectionStore, connection_id: str, binding_map: BindingMap) -> tuple[str, str]:
    # Prefer resolved table bindings (actual data source), then connection defaults.
    for binding in binding_map.bindings.values():
        if binding.status == "resolved" and not binding.is_virtual and binding.database and binding.schema_name:
            return binding.database, binding.schema_name
    profile = store.get(connection_id)
    if profile.database and profile.schema_name:
        return profile.database, profile.schema_name
    raise ValueError("Unable to determine semantic-view target database/schema from bindings or connection profile")


def _persist_traceability_deployment(root: Path, payload: dict) -> None:
    path = root / "semantic_traceability.json"
    existing: dict = {}
    if path.is_file():
        try:
            existing = json.loads(path.read_text(encoding="utf-8"))
        except ValueError:
            existing = {}
    deployments = list(existing.get("deployments", []))
    deployments.append(payload)
    path.write_text(json.dumps({"deployments": deployments}, indent=2), encoding="utf-8")


def _augment_conversion_run(root: Path, updates: dict) -> None:
    path = root / "conversion_run.json"
    if not path.is_file():
        return
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except ValueError:
        payload = {}
    payload.update(updates)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _qident(value: str) -> str:
    return quote_ident(value)


def _slug_materialization_name(view_name: str, table_name: str, lifecycle: str) -> str:
    suffix = "DT" if lifecycle == "dynamic_table" else "TB"
    raw = f"{view_name}__{suffix}__{table_name}"
    return re.sub(r"[^A-Za-z0-9_]+", "_", raw).strip("_") or "PBI_MATERIALIZATION"


def _materialization_target(
    view_name: str,
    table_name: str,
    database: str,
    schema_name: str,
    lifecycle: str,
) -> dict:
    return {
        "database": database,
        "schema": schema_name,
        "table": _slug_materialization_name(view_name, table_name, lifecycle),
    }


def _materialization_ddl(
    target: dict,
    sql: str,
    lifecycle: str,
    warehouse: str | None,
) -> str:
    target_fq = (
        f'{_qident(target["database"])}.{_qident(target["schema"])}.{_qident(target["table"])}'
    )
    if lifecycle == "dynamic_table":
        if not warehouse:
            raise HTTPException(422, "dynamic table materializations require a Snowflake warehouse")
        return (
            f"CREATE OR REPLACE DYNAMIC TABLE {target_fq} "
            f"TARGET_LAG = '1 hour' WAREHOUSE = {_qident(warehouse)} AS {sql}"
        )
    return f"CREATE OR REPLACE TABLE {target_fq} AS {sql}"


def _apply_materialization_targets(
    spec: dict,
    materializations: list[dict],
    database: str,
    schema_name: str,
    view_name: str,
) -> dict:
    if not materializations:
        return spec

    target_by_table = {
        item["table"]: _materialization_target(
            view_name,
            item["table"],
            database,
            schema_name,
            item.get("lifecycle", "table"),
        )
        for item in materializations
    }
    for table in spec.get("tables", []):
        target = target_by_table.get(table.get("name"))
        if target is not None:
            table["base_table"] = target
    return spec


def _latest_semantic_deployment(conversion_id: str) -> dict | None:
    svc = get_ingest_service()
    try:
        conv_dir = svc.conversion_dir(conversion_id)
    except ValueError:
        return None

    run_path = conv_dir / "conversion_run.json"
    if run_path.is_file():
        try:
            run_payload = json.loads(run_path.read_text(encoding="utf-8"))
            semantic = run_payload.get("semantic_view")
            if isinstance(semantic, dict):
                return semantic
        except ValueError:
            pass

    trace_path = conv_dir / "semantic_traceability.json"
    if trace_path.is_file():
        try:
            trace_payload = json.loads(trace_path.read_text(encoding="utf-8"))
            deployments = trace_payload.get("deployments") or []
            if deployments:
                latest = deployments[-1]
                if isinstance(latest, dict):
                    return latest
        except ValueError:
            pass
    return None


class ReimagineRequest(BaseModel):
    connection_id: str
    mode: Literal["live", "accelerated"] = "live"
    use_llm: bool = False


class ReimagineDecisionRequest(BaseModel):
    note: str | None = None


@router.post("/reimagine", response_model=DashboardRecommendation)
def generate_reimagine_recommendation(
    conversion_id: str,
    req: ReimagineRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> DashboardRecommendation:
    spec, _, _ = _load(conversion_id)
    root = _reimagine_dir(conversion_id)

    # Build a snapshot from live dashboard queries so mockups use real values.
    queries = [
        VisualQuery(page=p.name, visual=v.name)
        for p in spec.pages
        for v in p.visuals
        if v.supported and v.query is not None
    ]
    if not queries:
        raise HTTPException(422, "no queryable visuals found for this conversion")

    snapshot_result = batch_query(
        conversion_id,
        BatchQueryRequest(
            connection_id=req.connection_id,
            queries=queries,
            mode=req.mode,
            allow_tier_a_fallback=True,
        ),
        store,
    )

    snapshot_payload = {
        "connection_id": req.connection_id,
        "mode": req.mode,
        "results": [
            {
                "page": q.page,
                "visual": r.visual,
                "columns": r.columns,
                "rows": r.rows,
                "warnings": r.warnings,
                "execution_path": r.execution_path,
                "fallback_reason": r.fallback_reason,
            }
            for q, r in zip(queries, snapshot_result.results, strict=False)
        ],
    }
    snapshot_meta = save_snapshot(root, snapshot_payload)

    recommendation = build_recommendation(spec, conversion_id, snapshot_payload, snapshot_meta)
    if req.use_llm:
        recommendation.strategy.insert(
            0,
            "Optional LLM pass requested; deterministic evidence validation remains enforced.",
        )
    save_recommendation(root, recommendation)
    return recommendation


@router.get("/reimagine/latest", response_model=DashboardRecommendation)
def get_latest_reimagine_recommendation(conversion_id: str) -> DashboardRecommendation:
    root = _reimagine_dir(conversion_id)
    payload = latest_recommendation(root)
    if payload is None:
        raise HTTPException(404, "no dashboard recommendation yet; POST /reimagine first")
    return payload


@router.get("/reimagine/history")
def get_reimagine_history(conversion_id: str) -> dict:
    root = _reimagine_dir(conversion_id)
    return {"recommendations": list_recommendations(root)}


@router.get("/reimagine/{recommendation_id}/mockups")
def get_reimagine_mockups(conversion_id: str, recommendation_id: str) -> dict:
    root = _reimagine_dir(conversion_id)
    payload = latest_recommendation(root) if recommendation_id == "latest" else None
    if payload is None:
        payload = load_recommendation(root, recommendation_id)
    if payload is None:
        raise HTTPException(404, "recommendation not found")
    return {
        "id": payload.id,
        "snapshot": payload.snapshot.model_dump(mode="json") if payload.snapshot else None,
        "quality": payload.quality.model_dump(mode="json"),
        "scenes": [scene.model_dump(mode="json") for scene in payload.mockup_scenes],
        "pages": [page.model_dump(mode="json") for page in payload.pages],
        "visual_decisions": [d.model_dump(mode="json") for d in payload.visual_decisions],
    }


@router.post("/reimagine/{recommendation_id}/approve", response_model=DashboardRecommendation)
def approve_reimagine_recommendation(
    conversion_id: str,
    recommendation_id: str,
    req: ReimagineDecisionRequest,
) -> DashboardRecommendation:
    root = _reimagine_dir(conversion_id)
    payload = update_recommendation_status(root, recommendation_id, "approved", req.note)
    if payload is None:
        raise HTTPException(404, "recommendation not found")
    return payload


@router.post("/reimagine/{recommendation_id}/reject", response_model=DashboardRecommendation)
def reject_reimagine_recommendation(
    conversion_id: str,
    recommendation_id: str,
    req: ReimagineDecisionRequest,
) -> DashboardRecommendation:
    root = _reimagine_dir(conversion_id)
    payload = update_recommendation_status(root, recommendation_id, "rejected", req.note)
    if payload is None:
        raise HTTPException(404, "recommendation not found")
    return payload


# ---------------------------------------------------------------------------
# Reimagine build: compile the variant spec + mapping manifest + zero-loss gate
# ---------------------------------------------------------------------------


def _resolve_recommendation(root: Path, recommendation_id: str):
    payload = latest_recommendation(root) if recommendation_id == "latest" else None
    if payload is None:
        payload = load_recommendation(root, recommendation_id)
    return payload


@router.post("/reimagine/{recommendation_id}/build")
def build_reimagine_variant(conversion_id: str, recommendation_id: str) -> dict:
    """Compile the reimagined dashboard variant with byte-identical queries,
    produce the before->after mapping manifest, and run the zero-loss gate."""
    import json as _json

    from app.agents.reimagine import load_snapshot
    from app.agents.reimagine_build import build_reimagined
    from app.validation.reimagine_gate import run_zero_loss_gate

    root = _reimagine_dir(conversion_id)
    payload = _resolve_recommendation(root, recommendation_id)
    if payload is None:
        raise HTTPException(404, "recommendation not found; POST /reimagine first")

    spec, _, _ = _load(conversion_id)
    snapshot = load_snapshot(root, payload.snapshot.id) if payload.snapshot else None
    variant, manifest = build_reimagined(spec, conversion_id, snapshot)
    gate = run_zero_loss_gate(spec, variant, manifest)

    (root / "reimagined_spec.json").write_text(
        variant.model_dump_json(), encoding="utf-8"
    )
    (root / "visual_mapping.json").write_text(
        manifest.model_dump_json(), encoding="utf-8"
    )
    (root / "zero_loss.json").write_text(gate.model_dump_json(), encoding="utf-8")
    _result_cache.clear()  # variant spec changed; cached visual data may alias
    return {
        "recommendation_id": payload.id,
        "built": True,
        "zero_loss": _json.loads(gate.model_dump_json()),
        "pages": manifest.pages,
        "mappings": len(manifest.entries),
    }


@router.get("/reimagine/{recommendation_id}/built")
def get_reimagine_built(conversion_id: str, recommendation_id: str) -> dict:
    import json as _json

    root = _reimagine_dir(conversion_id)
    spec_file = root / "reimagined_spec.json"
    if not spec_file.is_file():
        raise HTTPException(404, "variant not built; POST /reimagine/{id}/build first")
    return {
        "spec": _json.loads(spec_file.read_text(encoding="utf-8")),
        "mapping": _json.loads((root / "visual_mapping.json").read_text(encoding="utf-8")),
        "zero_loss": _json.loads((root / "zero_loss.json").read_text(encoding="utf-8")),
    }


@router.post("/reimagine/{recommendation_id}/accept")
def accept_reimagine_variant(
    conversion_id: str,
    recommendation_id: str,
    req: ReimagineDecisionRequest,
) -> dict:
    """Accept the built variant. Blocked (409) unless the zero-loss gate passed."""
    import json as _json

    root = _reimagine_dir(conversion_id)
    gate_file = root / "zero_loss.json"
    if not gate_file.is_file():
        raise HTTPException(409, "variant not built yet; POST build first")
    gate = _json.loads(gate_file.read_text(encoding="utf-8"))
    if not gate.get("passed"):
        raise HTTPException(
            409,
            "zero-loss gate failed: " + "; ".join(gate.get("gaps", [])[:5]),
        )
    resolved = _resolve_recommendation(root, recommendation_id)
    if resolved is None:
        raise HTTPException(404, "recommendation not found")
    payload = update_recommendation_status(root, resolved.id, "approved", req.note)
    if payload is None:
        raise HTTPException(404, "recommendation not found")
    (root / "variant_accepted.json").write_text(
        _json.dumps(
            {"recommendation_id": payload.id, "accepted_at": time.time(), "note": req.note}
        ),
        encoding="utf-8",
    )
    return {"accepted": True, "recommendation_id": payload.id, "zero_loss": gate}


def _split_target_object(
    target_object: str,
    default_database: str | None,
    default_schema: str | None,
) -> tuple[str, str, str] | None:
    parts = [p.strip().strip('"') for p in target_object.split(".") if p.strip()]
    if len(parts) == 3:
        return parts[0], parts[1], parts[2]
    if len(parts) == 2 and default_database:
        return default_database, parts[0], parts[1]
    if len(parts) == 1 and default_database and default_schema:
        return default_database, default_schema, parts[0]
    return None


def _apply_deployed_materializations(binding_map: BindingMap, deployment: dict | None) -> BindingMap:
    if not isinstance(deployment, dict):
        return binding_map

    default_database = deployment.get("database")
    default_schema = deployment.get("schema_name")
    materializations = deployment.get("materializations") or []
    for item in materializations:
        if not isinstance(item, dict):
            continue
        table_name = item.get("table")
        target_object = item.get("target_object")
        if not table_name or not target_object:
            continue
        resolved = _split_target_object(str(target_object), default_database, default_schema)
        if resolved is None:
            continue

        binding = binding_map.get(str(table_name))
        if binding is None or binding.status != "materialization_required":
            continue

        database, schema_name, object_name = resolved
        binding.database = database
        binding.schema_name = schema_name
        binding.object_name = object_name
        binding.object_kind = "dynamic_table" if item.get("lifecycle") == "dynamic_table" else "table"
        binding.native_query = None
        binding.where_clause = None
        binding.status = "resolved"
        binding.detail = f"resolved via deployed materialization {target_object}"

    return binding_map


def _preferred_semantic_view(conversion_id: str) -> str | None:
    """Resolve preferred semantic view from persisted deployment metadata.

    This closes the gap where semantic view was deployed but model measure bindings
    were not yet populated with semantic_view identifiers.
    """
    deployment = _latest_semantic_deployment(conversion_id)
    if isinstance(deployment, dict):
        fq = deployment.get("fully_qualified_view")
        if fq:
            return str(fq)
        name = deployment.get("view_name")
        if name:
            return str(name)
    return None


def _deploy_semantic_view_for_conversion(
    *,
    conversion_id: str,
    bundle,
    binding_map: BindingMap,
    tier2_sql: dict[str, str],
    root: Path,
    store: ConnectionStore,
    connection_id: str,
) -> dict:
    compiler = SemanticViewYamlCompiler(bundle.model, binding_map, tier2_sql=tier2_sql)
    spec = compiler.compile()
    materializations = compiler.materialization_plan()
    database, schema_name = _default_semantic_target(store, connection_id, binding_map)
    schema_fq = f"{database}.{schema_name}".replace("'", "''")
    profile = store.get(connection_id)

    conn = _connect(store, connection_id, conversion_id)
    try:
        cur = conn.cursor()
        deployed_materializations: list[dict] = []
        if materializations:
            lifecycle = "dynamic_table" if profile.warehouse else "table"
            for item in materializations:
                target = _materialization_target(
                    compiler.view_name,
                    item["table"],
                    database,
                    schema_name,
                    lifecycle,
                )
                cur.execute(_materialization_ddl(target, item["sql"], lifecycle, profile.warehouse))
                deployed_materializations.append(
                    {
                        **item,
                        "target_object": f"{target['database']}.{target['schema']}.{target['table']}",
                        "lifecycle": lifecycle,
                    }
                )

        spec = _apply_materialization_targets(
            spec,
            deployed_materializations,
            database,
            schema_name,
            compiler.view_name,
        )
        # model columns from unapplied M transforms may not exist physically
        spec, prune_warnings = prune_spec_to_live_schema(spec, cur)
        yaml_text = yaml.dump(
            spec, default_flow_style=False, allow_unicode=True, sort_keys=False
        )
        sql = (
            "CALL SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML("
            f"'{schema_fq}', $${yaml_text}$$, FALSE, TRUE)"
        )
        cur.execute(sql)
        row = cur.fetchone()
        message = str(row[0]) if row else "Done"
        cur.close()
    finally:
        conn.close()

    entry = {
        "deployed_at": time.time(),
        "database": database,
        "schema_name": schema_name,
        "view_name": compiler.view_name,
        "fully_qualified_view": f"{database}.{schema_name}.{compiler.view_name}",
        "dry_run": False,
        "create_or_alter": True,
        "message": message,
        "yaml": yaml_text,
        "prune_warnings": prune_warnings,
        "materialization_count": len(deployed_materializations),
        "materializations": deployed_materializations,
        "refresh_owner": profile.name,
    }
    _persist_traceability_deployment(root, entry)
    return entry


def _load_variant_spec(conversion_id: str) -> DashboardSpec:
    """The built reimagined variant (404 until POST /reimagine/{id}/build)."""
    import json as _json

    spec_file = _reimagine_dir(conversion_id) / "reimagined_spec.json"
    if not spec_file.is_file():
        raise HTTPException(404, "reimagined variant not built")
    return DashboardSpec(**_json.loads(spec_file.read_text(encoding="utf-8")))


@router.get("/spec", response_model=DashboardSpec)
def get_dashboard_spec(conversion_id: str, variant: str | None = None) -> DashboardSpec:
    if variant == "reimagined":
        return _load_variant_spec(conversion_id)
    spec, _, _ = _load(conversion_id)
    return spec


class ExportDashboardRequest(BaseModel):
    connection_id: str


@router.post("/export")
def export_dashboard(
    conversion_id: str,
    request: ExportDashboardRequest,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
    connections: Annotated[ConnectionStore, Depends(get_connection_store)],
    tokens: Annotated[DashboardTokenStore, Depends(get_dashboard_token_store)],
) -> Response:
    """Download a standalone Vite+React project of this dashboard."""
    from app.services.export import ExportError, build_export_zip

    spec, _, _ = _load(conversion_id, svc)
    try:
        connections.get(request.connection_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e
    issued = tokens.create(conversion_id, request.connection_id)
    resources: dict[str, bytes] = {}
    try:
        bundle = svc.load_bundle(conversion_id)
        for name in _pt.referenced_resources(spec):
            path = _pt.resolve_resource(bundle, name)
            if path is not None:
                resources[name] = path.read_bytes()
    except (IngestError, ValueError, OSError):
        resources = {}
    try:
        payload = build_export_zip(
            spec,
            conversion_id,
            request.connection_id,
            publication_id=issued.publication.id,
            publication_token=issued.token,
            resources=resources,
        )
    except ExportError as e:
        raise HTTPException(503, str(e)) from e
    slug = spec.report_name.lower().replace(" ", "-")
    return Response(
        content=payload,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{slug}-dashboard.zip"'},
    )


@router.post("/export-standalone")
def export_standalone_dashboard(
    conversion_id: str,
    request: ExportDashboardRequest,
    svc: Annotated[IngestService, Depends(get_ingest_service)],
    connections: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> Response:
    """Download the standalone dashboard package (service + app + query templates)."""
    from app.services.standalone_export import StandaloneExportError, build_standalone_zip

    spec, _, engine = _load(conversion_id, svc)
    try:
        profile = connections.get(request.connection_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e
    resources: dict[str, bytes] = {}
    try:
        bundle = svc.load_bundle(conversion_id)
        for name in _pt.referenced_resources(spec):
            path = _pt.resolve_resource(bundle, name)
            if path is not None:
                resources[name] = path.read_bytes()
    except (IngestError, ValueError, OSError):
        resources = {}
    try:
        conv_dir = svc.conversion_dir(conversion_id)
    except ValueError:
        conv_dir = None
    try:
        payload = build_standalone_zip(spec, engine, conv_dir, profile, resources)
    except StandaloneExportError as e:
        raise HTTPException(503, str(e)) from e
    slug = re.sub(r"[^a-z0-9-]+", "-", spec.report_name.lower()).strip("-") or "dashboard"
    return Response(
        content=payload,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{slug}-standalone.zip"'},
    )


class ConvertRequest(BaseModel):
    connection_id: str
    # source database the report reads today; enables base-table migration
    source_connection_id: str | None = None
    # False = schema-only migration: create/reconcile every object, move no rows
    # (data provisioning delegated to the customer's own pipeline)
    copy_data: bool = True
    use_llm: bool = False
    # Snowflake target overrides (blank/None clears); only stored when explicitly sent
    database_override: str | None = None
    schema_override: str | None = None
    # None = the server default (PBIC_LLM_PROVIDER)
    llm_provider: Literal["cortex", "horizon"] | None = None
    resume: bool = False
    policy_mode: Literal["advisory", "strict", "release_candidate"] = "advisory"


def _build_gate_status(
    *,
    mode: str,
    summary: dict | None,
    semantic_view: dict | None,
    semantic_view_error: str | None,
    dual_run_summary: dict | None,
    dual_run_error: str | None,
) -> dict:
    checks: list[dict] = []
    parked = int((summary or {}).get("measures_parked") or 0)
    checks.append(
        {
            "name": "semantic_view_deployed",
            "passed": semantic_view is not None,
            "detail": semantic_view.get("fully_qualified_view") if semantic_view else (semantic_view_error or "not deployed"),
        }
    )
    checks.append(
        {
            "name": "parked_measures",
            "passed": parked == 0,
            "detail": f"{parked} parked measure(s)",
        }
    )

    if dual_run_summary is not None:
        pass_rate = float(dual_run_summary.get("pass_rate") or 0.0)
        visuals_failed = int(dual_run_summary.get("visuals_failed") or 0)
        checks.append(
            {
                "name": "dual_run_parity",
                "passed": visuals_failed == 0,
                "detail": f"pass_rate={pass_rate:.4f}, failed={visuals_failed}",
            }
        )
    else:
        checks.append(
            {
                "name": "dual_run_parity",
                "passed": False,
                "detail": dual_run_error or "not available",
            }
        )

    if mode == "advisory":
        passed = True
    elif mode == "strict":
        passed = all(check["passed"] for check in checks)
    else:
        # release_candidate: require deployment and parity, tolerate up to 2 parked measures.
        deployed_ok = bool(checks[0]["passed"])
        parked_ok = parked <= 2
        parity_ok = bool(checks[2]["passed"]) if len(checks) > 2 else False
        checks[1]["passed"] = parked_ok
        checks[1]["detail"] = f"{parked} parked measure(s), threshold<=2"
        passed = deployed_ok and parked_ok and parity_ok

    return {
        "mode": mode,
        "passed": passed,
        "checks": checks,
        "generated_at": time.time(),
    }


@router.get("/resources/{name}")
def get_resource(conversion_id: str, name: str) -> Response:
    """A registered report image (png/jpg/gif/svg/webp/bmp) from RegisteredResources."""
    svc = get_ingest_service()
    try:
        bundle = svc.load_bundle(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e
    path = _pt.resolve_resource(bundle, name)
    if path is None:
        raise HTTPException(404, "resource not found")
    return Response(
        path.read_bytes(),
        media_type=_pt.MEDIA_TYPES.get(path.suffix.lower(), "application/octet-stream"),
        headers={
            "Cache-Control": "private, max-age=3600",
            "X-Content-Type-Options": "nosniff",
            "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox",
        },
    )


@router.get("/dax-rewrites")
def list_dax_rewrites(conversion_id: str) -> dict:
    """AI rewrites of measure DAX into the tier-1 subset, with the gates each passed."""
    svc = get_ingest_service()
    try:
        bundle = svc.load_bundle(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e
    return {
        "rewrites": {
            name: rewrite.model_dump()
            for name, rewrite in sorted(bundle.model.dax_rewrites.items())
        }
    }


@router.delete("/dax-rewrites/{measure}")
def revert_dax_rewrite(conversion_id: str, measure: str) -> dict:
    svc = get_ingest_service()
    try:
        bundle = svc.load_bundle(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e
    if measure not in bundle.model.dax_rewrites:
        raise HTTPException(404, f"no AI rewrite for measure '{measure}'")
    del bundle.model.dax_rewrites[measure]
    svc.save_bundle(conversion_id, bundle)
    _result_cache.clear()
    return {"reverted": measure, "remaining": sorted(bundle.model.dax_rewrites)}


class PreflightRequest(BaseModel):
    connection_id: str
    database_override: str | None = None
    schema_override: str | None = None


@router.post("/preflight")
def preflight_dashboard(
    conversion_id: str,
    req: PreflightRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> dict:
    """Analyze "Check access": letter-case check + reachability of the bound objects."""
    from app.binding.case_check import correct_bundle_case
    from app.binding.preflight import run_preflight
    from app.binding.resolver import apply_binding_settings, build_binding_map

    svc = get_ingest_service()
    try:
        bundle = svc.load_bundle(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e

    trial = bundle.model_copy(deep=True)
    trial.binding_settings.database_override = (req.database_override or "").strip() or None
    trial.binding_settings.schema_override = (req.schema_override or "").strip() or None

    conn = _connect(store, req.connection_id, conversion_id)
    try:
        cursor = conn.cursor()
        case_report, changed = correct_bundle_case(trial, cursor)
        binding_map = apply_binding_settings(
            build_binding_map(trial.model), trial.binding_settings
        )
        report = run_preflight(binding_map, cursor)
    finally:
        conn.close()

    saved = False
    if changed:
        # only the case fixes and their timestamp are persisted; Convert saves the overrides
        bundle.binding_settings.case_fixes = trial.binding_settings.case_fixes
        bundle.binding_settings.case_checked_at = trial.binding_settings.case_checked_at
        svc.save_bundle(conversion_id, bundle)
        saved = True
    _result_cache.clear()
    return {
        **report.summary(),
        "message": report.message(),
        "case": case_report.summary(),
        "case_saved": saved,
    }


@router.post("/convert")
def convert_dashboard(
    conversion_id: str,
    req: ConvertRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> dict:
    """Run the full agent pipeline: bind -> compile -> validate -> repair -> report."""
    from app.agents.pipeline import run_conversion

    svc = get_ingest_service()
    try:
        bundle = svc.load_bundle(conversion_id)
        root = svc.conversion_dir(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e

    if "database_override" in req.model_fields_set or "schema_override" in req.model_fields_set:
        settings_ = bundle.binding_settings
        settings_.database_override = (req.database_override or "").strip() or None
        settings_.schema_override = (req.schema_override or "").strip() or None
        svc.save_bundle(conversion_id, bundle)

    def raw_cursor_factory():
        conn = _connect(store, req.connection_id, conversion_id)
        return conn.cursor()

    def cursor_factory():
        conn = _audited(
            _connect(store, req.connection_id, conversion_id),
            store,
            req.connection_id,
            conversion_id,
            "validation",
        )
        return conn.cursor()

    # fail fast: an unsigned session answers 409 now, not after compiling
    _connect(store, req.connection_id, conversion_id).close()

    llm_client = None
    llm_provider: str | None = None
    if req.use_llm:
        from app.services.cortex_client import CortexError
        from app.services.llm_provider import build_llm_client, resolve_provider

        llm_provider = resolve_provider(req.llm_provider)
        llm_client = build_llm_client(llm_provider, cursor_factory)
        if llm_provider == "cortex":
            try:
                llm_client.preflight()
            except CortexError as e:
                raise HTTPException(
                    422, detail={"code": "cortex_unavailable", "message": str(e)}
                ) from e

    migrator = None
    if req.source_connection_id:
        from app.api.deps import get_source_connection_store
        from app.services.migration import rewrite_bundle_to_snowflake
        from app.services.object_migration import migrate_objects

        src_store = get_source_connection_store()
        try:
            src_profile = src_store.get(req.source_connection_id)
        except (KeyError, ValueError) as e:
            raise HTTPException(404, "source connection not found") from e
        target_profile = store.get(req.connection_id)
        if not (target_profile.database and target_profile.schema_name):
            raise HTTPException(
                422, "target Snowflake connection needs database and schema for migration"
            )

        def migrator(binding_map, bundle_ref, emit):
            src_conn = src_store.connect(req.source_connection_id)
            sf_cursor = raw_cursor_factory()
            try:
                if not req.copy_data:
                    emit("mode", "schema-only migration: objects created, data copy skipped")
                result = migrate_objects(
                    binding_map,
                    src_conn,
                    src_profile.kind.value,
                    sf_cursor,
                    target_database=target_profile.database,
                    target_schema=target_profile.schema_name,
                    warehouse=target_profile.warehouse,
                    copy_data=req.copy_data,
                    on_progress=emit,
                )
                if result.ok:
                    resolved_warehouse = target_profile.warehouse or result.resolved_warehouse
                    if resolved_warehouse:
                        rewritten = rewrite_bundle_to_snowflake(
                            bundle_ref,
                            result.tables.tables,
                            account=target_profile.account,
                            warehouse=resolved_warehouse,
                            database=target_profile.database,
                            extra_bindings=result.bindings_out,
                        )
                        # persist so every later load binds straight to Snowflake
                        (root / "bundle.json").write_text(
                            bundle_ref.model_dump_json(indent=2), encoding="utf-8"
                        )
                        emit("bundle", f"repointed {rewritten} table partitions at Snowflake")
                    else:
                        emit(
                            "bundle",
                            "no warehouse configured on the connection and none resolved "
                            "from the Snowflake session; table partitions were not "
                            "repointed at Snowflake",
                        )
                summary = result.summary()
                summary["copy_data"] = req.copy_data
                (root / "migration_result.json").write_text(
                    json.dumps(summary, indent=2), encoding="utf-8"
                )
                return summary
            finally:
                src_conn.close()
                sf_cursor.close()

    run = run_conversion(
        bundle,
        conversion_id,
        root,
        cursor_factory,
        llm_client=llm_client,
        resume=req.resume,
        migrator=migrator,
        llm_provider=llm_provider,
    )

    tier2_payload = dict(run.tier2_accepted)
    spec, binding_map = compile_dashboard(bundle, tier2_sql=tier2_payload)

    semantic_view: dict | None = None
    semantic_view_error: str | None = None
    try:
        semantic_view = _deploy_semantic_view_for_conversion(
            conversion_id=conversion_id,
            bundle=bundle,
            binding_map=binding_map,
            tier2_sql=tier2_payload,
            root=root,
            store=store,
            connection_id=req.connection_id,
        )
        run.events.append(
            {
                "ts": round(time.time(), 3),
                "stage": "semantic_view",
                "message": f"published governed semantic view {semantic_view['fully_qualified_view']}",
            }
        )
    except Exception as e:  # noqa: BLE001 - deployment should not abort conversion
        semantic_view_error = str(e)
        run.events.append(
            {
                "ts": round(time.time(), 3),
                "stage": "semantic_view",
                "message": "semantic view publishing failed; dashboard will use the direct query path",
                "error": semantic_view_error,
            }
        )

    dual_run_summary: dict | None = None
    dual_run_error: str | None = None
    if semantic_view is not None:
        engine = SemanticEngine(bundle.model, binding_map, tier2_sql=tier2_payload)
        planner = _SemanticViewPlanner(
            engine,
            model_version=bundle.model.model_version,
            data_version=bundle.model.data_version,
            row_scope_id=None,
            preferred_view=semantic_view.get("fully_qualified_view") or semantic_view.get("view_name"),
        )
        conn = _audited(
            _connect(store, req.connection_id, conversion_id),
            store,
            req.connection_id,
            conversion_id,
            "validation",
            "parity",
        )
        try:
            report = run_dual_run_parity(
                spec=spec,
                expected_engine=engine,
                actual_engine=planner,
                expected_cursor=conn.cursor(),
                actual_cursor=conn.cursor(),
                pages=None,
                max_mismatches_per_visual=25,
            )
            artifact = {
                "summary": report.summary(),
                "request": {
                    "pages": [],
                    "model_version": bundle.model.model_version,
                    "data_version": bundle.model.data_version,
                },
                "report": report.model_dump(),
                "generated_at": time.time(),
            }
            (root / "dual_run_parity.json").write_text(json.dumps(artifact, indent=2), encoding="utf-8")
            dual_run_summary = artifact["summary"]
            run.events.append(
                {
                    "ts": round(time.time(), 3),
                    "stage": "parity",
                    "message": (
                        f"cross-check complete: {dual_run_summary.get('visuals_passed', 0)}/"
                        f"{dual_run_summary.get('visuals_total', 0)} visuals match on both query paths"
                    ),
                }
            )
        except Exception as e:  # noqa: BLE001
            dual_run_error = str(e)
            run.events.append(
                {
                    "ts": round(time.time(), 3),
                    "stage": "parity",
                    "message": "cross-check could not complete",
                    "error": dual_run_error,
                }
            )
        finally:
            conn.close()

    fidelity_summary = run.fidelity.summary() if run.fidelity else None
    gate_status = _build_gate_status(
        mode=req.policy_mode,
        summary=fidelity_summary,
        semantic_view=semantic_view,
        semantic_view_error=semantic_view_error,
        dual_run_summary=dual_run_summary,
        dual_run_error=dual_run_error,
    )

    _augment_conversion_run(
        root,
        {
            "events": run.events,
            "semantic_view": semantic_view,
            "semantic_view_error": semantic_view_error,
            "dual_run_parity": dual_run_summary,
            "dual_run_parity_error": dual_run_error,
            "policy_mode": req.policy_mode,
            "gate_status": gate_status,
        },
    )

    if req.policy_mode in {"strict", "release_candidate"} and not gate_status["passed"]:
        raise HTTPException(
            422,
            {
                "message": "Conversion gate failed",
                "gate_status": gate_status,
                "semantic_view_error": semantic_view_error,
                "dual_run_parity_error": dual_run_error,
            },
        )

    return {
        "events": run.events,
        "summary": fidelity_summary,
        "tier2_accepted": list(run.tier2_accepted),
        "semantic_view": semantic_view,
        "semantic_view_error": semantic_view_error,
        "dual_run_parity": dual_run_summary,
        "dual_run_parity_error": dual_run_error,
        "policy_mode": req.policy_mode,
        "gate_status": gate_status,
    }


@router.get("/convert/progress")
def convert_progress(conversion_id: str) -> dict:
    """Live event feed for an in-flight conversion (poll while POST /convert runs)."""
    import json as _json

    svc = get_ingest_service()
    try:
        path = svc.conversion_dir(conversion_id) / "conversion_progress.json"
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e
    if not path.is_file():
        return {"events": [], "done": False}
    try:
        return _json.loads(path.read_text(encoding="utf-8"))
    except ValueError:
        return {"events": [], "done": False}


@router.get("/fidelity")
def get_fidelity(conversion_id: str) -> dict:
    """Latest persisted conversion run (events + fidelity scorecard)."""
    import json as _json

    svc = get_ingest_service()
    try:
        path = svc.conversion_dir(conversion_id) / "conversion_run.json"
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e
    if not path.is_file():
        raise HTTPException(404, "no conversion run yet; POST /convert first")
    return _json.loads(path.read_text(encoding="utf-8"))


@router.get("/report")
def conversion_report(conversion_id: str) -> Response:
    """Client-facing Conversion Report as a self-contained HTML document."""
    import json as _json

    from app.services.report_doc import build_conversion_report_html

    svc = get_ingest_service()
    try:
        run_path = svc.conversion_dir(conversion_id) / "conversion_run.json"
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e
    if not run_path.is_file():
        raise HTTPException(404, "no conversion run yet; POST /convert first")
    spec, _, _ = _load(conversion_id)
    html_doc = build_conversion_report_html(
        _json.loads(run_path.read_text(encoding="utf-8")), spec.model_dump()
    )
    slug = spec.report_name.lower().replace(" ", "-")
    return Response(
        content=html_doc,
        media_type="text/html",
        headers={
            "Content-Disposition": f'attachment; filename="{slug}-conversion-report.html"'
        },
    )


def _compare_dir(conversion_id: str):
    svc = get_ingest_service()
    out_dir = svc.conversion_dir(conversion_id) / "visual_compare"
    out_dir.mkdir(exist_ok=True)
    return out_dir


def _sha256(data: bytes) -> str:
    import hashlib

    return hashlib.sha256(data).hexdigest()


def _harness_pass_map(conversion_id: str, page_name: str) -> dict[str, bool]:
    """title/name -> True when the numeric harness proved the visual (all
    checks passed/skipped). Vision findings that claim a DATA mismatch on a
    proven visual indicate a stale/filtered reference, not a conversion bug."""
    import json as _json

    svc = get_ingest_service()
    path = svc.conversion_dir(conversion_id) / "conversion_run.json"
    if not path.is_file():
        return {}
    try:
        fid = _json.loads(path.read_text(encoding="utf-8")).get("fidelity") or {}
    except ValueError:
        return {}
    out: dict[str, bool] = {}
    for page in fid.get("pages", []):
        if page.get("page") != page_name:
            continue
        for v in page.get("visuals", []):
            ok = all(
                c.get("status") in ("passed", "skipped") for c in v.get("checks", [])
            )
            for key in (v.get("visual"), v.get("title")):
                if key:
                    out[str(key).strip().lower()] = ok
    return out


_DATA_KINDS = ("data-shape", "formatting", "text")


def _arbitrate_findings(conversion_id: str, page_name: str, findings: list[dict]) -> bool:
    """Cross-check vision findings against the deterministic harness.

    Non-automatable data/value findings on visuals the harness already proved
    are marked contradicts_harness. When half or more of the findings
    contradict proven visuals, the reference image itself is suspect (stale
    export or different filter state) — that verdict is returned so the
    caller can flag the whole comparison."""
    proven = _harness_pass_map(conversion_id, page_name)
    if not proven:
        return False
    contradictions = 0
    considered = 0
    for f in findings:
        if f.get("kind") not in _DATA_KINDS or f.get("fix"):
            continue
        considered += 1
        key = str(f.get("region", "")).strip().lower()
        if proven.get(key):
            f["contradicts_harness"] = True
            f["harness_note"] = (
                "numeric validation proved this visual's data against the live "
                "warehouse; this difference is presentational or on the reference "
                "side (stale export / filter state), not a conversion data error"
            )
            contradictions += 1
    return considered > 0 and contradictions * 2 >= considered


def _fix_direction_guard(spec, page_name: str, finding: dict) -> str | None:
    """Vision models sometimes take the fix value from the CONVERTED image
    instead of the original, producing a no-op. For set_title: if the proposed
    value equals the current title, recover the original from the quoted
    strings in the difference text; reject if unrecoverable. For
    set_measure_format: reject values that are echoed RENDERED numbers
    (e.g. '$7.1,,bnM') rather than PBI format strings."""
    import re as _re

    fix = finding.get("fix") or {}
    if fix.get("op") == "set_measure_format":
        val = str(fix.get("value", ""))
        unquoted = _re.sub(r'"[^"]*"', "", val)
        if not _re.search(r"[0#]", unquoted):
            return "proposed format has no digit placeholder (0 or #)"
        if _re.search(r"[1-9]", unquoted):
            return (
                "proposed format contains literal digits — looks like a rendered "
                "value, not a PBI format string"
            )
        return None
    if fix.get("op") != "set_title":
        return None
    page = next((p for p in spec.pages if p.name == page_name), None)
    vs = next((v for v in page.visuals if v.name == fix.get("visual")), None) if page else None
    if vs is None or str(fix.get("value", "")).strip() != str(vs.title or "").strip():
        return None  # not a no-op; keep the proposal
    quoted = _re.findall(r"'([^']{2,120})'", finding.get("difference", ""))
    other = [q for q in quoted if q.strip() != str(vs.title or "").strip()]
    if other:
        fix["value"] = other[0]
        return None
    return "proposed title equals the current title (no-op) and the original could not be recovered"


def _run_page_compare(
    conversion_id: str,
    page,
    ref_bytes: bytes,
    ren_bytes: bytes,
    filters_applied: list[dict] | None = None,
) -> dict:
    """Shared compare core: vision call + persistence for one page."""
    import json as _json

    from app.agents.visual_compare import compare_page_images
    from app.services.overrides import validate_override

    inventory = [
        {
            "name": v.name,
            "title": v.title,
            "visual_type": v.visual_type,
            "dim_keys": v.dim_keys,
            "measure_keys": v.measure_keys,
        }
        for v in page.visuals
        if v.visual_type != "textbox"
    ]
    filter_context = None
    if filters_applied:
        pairs = ", ".join(f"{f['slicer']}={f['value']}" for f in filters_applied)
        filter_context = (
            f"Both images share the same active filters: {pairs} "
            "(detected from the original and applied to the converted render). "
            "Data differences explained by these filters are NOT expected; only "
            "report a filter-state finding if the visible slicer selections differ."
        )
    result = compare_page_images(ref_bytes, ren_bytes, inventory, filter_context=filter_context)
    if result.error:
        raise HTTPException(502, f"vision compare failed: {result.error}")

    # attach ids + automatability: a fix is actionable only if it validates
    # against the whitelisted vocabulary AND the current spec
    spec, _, _ = _load(conversion_id)
    for i, f in enumerate(result.findings):
        f["id"] = f"{page.name}:{i}"
        fix = f.get("fix")
        if fix:
            fix.setdefault("page", page.name)
            err = validate_override(spec, fix) or _fix_direction_guard(spec, page.name, f)
            if err:
                f["fix"] = None
                f["fix_rejected"] = err
        f["fixable"] = f.get("fix") is not None
        f["fix_applied"] = False

    reference_suspect = _arbitrate_findings(conversion_id, page.name, result.findings)

    out_dir = _compare_dir(conversion_id)
    payload = {
        "page": page.name,
        "display_name": page.display_name,
        "similarity": result.similarity,
        "findings": result.findings,
        "filters_applied": filters_applied or [],
        "compared_at": time.time(),
        # lineage: which exact images produced these findings
        "reference_sha": _sha256(ref_bytes),
        "rendered_sha": _sha256(ren_bytes),
        "reference_suspect": reference_suspect,
        "stale": False,
    }
    (out_dir / f"{page.name}.json").write_text(_json.dumps(payload, indent=2), encoding="utf-8")
    (out_dir / f"{page.name}_reference.png").write_bytes(ref_bytes)
    (out_dir / f"{page.name}_rendered.png").write_bytes(ren_bytes)
    return payload


@router.post("/visual-compare/reference-pdf")
async def upload_reference_pdf(conversion_id: str, pdf: UploadFile) -> dict:
    """Seed reference images for ALL pages from one Power BI PDF export.

    PBI's File > Export > PDF emits one PDF page per visible report page in
    order; each is rasterized and stored as that page's reference image.
    """
    from app.services.pdf_reference import PdfReferenceError, map_pages_to_report, rasterize_pdf

    spec, _, _ = _load(conversion_id)
    pdf_bytes = await pdf.read()
    if not pdf_bytes:
        raise HTTPException(422, "empty upload")
    if len(pdf_bytes) > 50_000_000:
        raise HTTPException(413, "PDF larger than 50 MB")

    try:
        images = rasterize_pdf(pdf_bytes)
    except PdfReferenceError as e:
        raise HTTPException(422, str(e)) from e

    report_pages = [
        {"name": p.name, "display_name": p.display_name, "ordinal": p.ordinal}
        for p in spec.pages
    ]
    mapping, warnings = map_pages_to_report(images, report_pages)

    out_dir = _compare_dir(conversion_id)
    superseded: list[str] = []
    for page_name, img in mapping.items():
        ref_path = out_dir / f"{page_name}_reference.png"
        new_sha = _sha256(img.png)
        # a new reference invalidates any comparison made against a different one
        result_path = out_dir / f"{page_name}.json"
        if result_path.is_file():
            try:
                payload = json.loads(result_path.read_text(encoding="utf-8"))
            except ValueError:
                payload = None
            if payload is not None and payload.get("reference_sha") != new_sha:
                payload["stale"] = True
                payload["stale_reason"] = "reference image replaced after this comparison ran"
                result_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
                superseded.append(page_name)
        ref_path.write_bytes(img.png)
    return {
        "pdf_pages": len(images),
        "report_pages": len(report_pages),
        "superseded_comparisons": superseded,
        "references_stored": [
            {
                "page": name,
                "display_name": next(
                    p["display_name"] for p in report_pages if p["name"] == name
                ),
            }
            for name in mapping
        ],
        "warnings": warnings,
    }


@router.get("/visual-compare/references")
def reference_status(conversion_id: str) -> dict:
    """Which pages already have a stored reference image."""
    spec, _, _ = _load(conversion_id)
    out_dir = _compare_dir(conversion_id)
    return {
        "pages": [
            {
                "page": p.name,
                "display_name": p.display_name,
                "has_reference": (out_dir / f"{p.name}_reference.png").is_file(),
            }
            for p in spec.pages
        ]
    }


class SlicerInfo(BaseModel):
    name: str  # slicer visual name in the spec
    title: str
    table: str
    column: str
    options: list[str | int | float] = Field(default_factory=list)


class DetectFiltersRequest(BaseModel):
    slicers: list[SlicerInfo]


@router.post("/visual-compare/{page_name}/detect-filters")
def detect_reference_filters(
    conversion_id: str, page_name: str, req: DetectFiltersRequest
) -> dict:
    """Read the active slicer selections off the stored reference image.

    Ensures the converted render is captured under the SAME filter state as
    the original before comparing (a 2024-filtered PDF vs an all-years render
    would otherwise produce false differences).
    """
    from app.agents.visual_compare import detect_slicer_state

    stored = _compare_dir(conversion_id) / f"{page_name}_reference.png"
    if not stored.is_file():
        raise HTTPException(422, "no reference for this page; upload the PBI PDF export first")

    result = detect_slicer_state(
        stored.read_bytes(),
        [{"title": s.title, "options": s.options} for s in req.slicers],
    )
    if result.error:
        raise HTTPException(502, f"filter detection failed: {result.error}")

    by_title = {s.title.strip().lower(): s for s in req.slicers}
    selections = []
    for sel in result.selections:
        slicer = by_title.get(sel["slicer"].strip().lower())
        if slicer is None:
            continue
        # snap the detected text to a canonical option value (preserves type)
        value: str | int | float = sel["value"]
        for opt in slicer.options:
            if str(opt) == sel["value"] or str(opt).lower() == sel["value"].lower():
                value = opt
                break
        selections.append(
            {
                "slicer_name": slicer.name,
                "slicer": slicer.title,
                "table": slicer.table,
                "column": slicer.column,
                "value": value,
            }
        )
    return {"selections": selections}


@router.post("/visual-compare/{page_name}")
async def visual_compare(
    conversion_id: str,
    page_name: str,
    rendered: UploadFile,
    reference: UploadFile | None = None,
    filters: str | None = Form(None),
) -> dict:
    """GPT-4o vision parity review: original PBI page vs React render.

    `reference` is optional: when omitted, the page's stored reference (seeded
    by the PDF upload) is used. `rendered` = converted page captured client-side.
    `filters` = JSON list of the slicer selections applied to the render.
    """
    import json as _json

    spec, _, _ = _load(conversion_id)
    page = next((p for p in spec.pages if p.name == page_name), None)
    if page is None:
        raise HTTPException(404, f"page '{page_name}' not in spec")

    ren_bytes = await rendered.read()
    if reference is not None:
        ref_bytes = await reference.read()
    else:
        stored = _compare_dir(conversion_id) / f"{page_name}_reference.png"
        if not stored.is_file():
            raise HTTPException(
                422, "no reference for this page; upload the PBI PDF export or a screenshot"
            )
        ref_bytes = stored.read_bytes()
    if not ref_bytes or not ren_bytes:
        raise HTTPException(422, "both reference and rendered images are required")
    if len(ref_bytes) > 8_000_000 or len(ren_bytes) > 8_000_000:
        raise HTTPException(413, "image larger than 8 MB")

    filters_applied: list[dict] | None = None
    if filters:
        try:
            parsed = _json.loads(filters)
            if isinstance(parsed, list):
                filters_applied = [
                    {"slicer": str(f.get("slicer", ""))[:80], "value": f.get("value")}
                    for f in parsed
                    if isinstance(f, dict)
                ]
        except ValueError as e:
            raise HTTPException(422, "filters must be a JSON list") from e

    return _run_page_compare(conversion_id, page, ref_bytes, ren_bytes, filters_applied)


@router.get("/visual-compare")
def visual_compare_results(conversion_id: str) -> dict:
    """All persisted per-page vision findings for this conversion.

    Staleness is recomputed on read: a result whose reference_sha no longer
    matches the stored reference image was produced against a superseded
    reference and must not drive review decisions or fixes."""
    import json as _json

    svc = get_ingest_service()
    try:
        out_dir = svc.conversion_dir(conversion_id) / "visual_compare"
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e
    pages = []
    if out_dir.is_dir():
        for f in sorted(out_dir.glob("*.json")):
            try:
                payload = _json.loads(f.read_text(encoding="utf-8"))
            except ValueError:
                continue
            pages.append(_apply_staleness(out_dir, payload))
    return {"pages": pages}


def _apply_staleness(out_dir, payload: dict) -> dict:
    """Recompute payload['stale'] against the current reference image."""
    ref_path = out_dir / f"{payload.get('page')}_reference.png"
    stored_sha = payload.get("reference_sha")
    if stored_sha is None:
        # pre-lineage result: cannot prove which reference produced it
        payload["stale"] = True
        payload.setdefault("stale_reason", "comparison predates reference tracking; re-run")
    elif ref_path.is_file() and _sha256(ref_path.read_bytes()) != stored_sha:
        payload["stale"] = True
        payload.setdefault("stale_reason", "reference image replaced after this comparison ran")
    return payload


class ApplyFixRequest(BaseModel):
    finding_ids: list[str] = Field(default_factory=list)  # empty = all fixable


@router.post("/visual-compare/{page_name}/apply-fixes")
def apply_finding_fixes(conversion_id: str, page_name: str, req: ApplyFixRequest) -> dict:
    """Apply the machine-executable fixes attached to findings.

    Each fix is a whitelisted spec override; applying persists it, recompiles
    the spec, and re-validates the touched override set. Non-fixable findings
    are ignored (the UI greys them out).
    """
    import json as _json

    from app.services.overrides import add_override, validate_override

    svc = get_ingest_service()
    conv_dir = svc.conversion_dir(conversion_id)
    result_file = conv_dir / "visual_compare" / f"{page_name}.json"
    if not result_file.is_file():
        raise HTTPException(404, "no comparison stored for this page")
    payload = _json.loads(result_file.read_text(encoding="utf-8"))
    payload = _apply_staleness(conv_dir / "visual_compare", payload)
    if payload.get("stale"):
        raise HTTPException(
            409,
            "comparison is stale ("
            + str(payload.get("stale_reason", "reference changed"))
            + "); re-run the page comparison before applying fixes",
        )

    spec, _, _ = _load(conversion_id)
    wanted = set(req.finding_ids)
    applied: list[str] = []
    skipped: list[dict] = []
    for f in payload.get("findings", []):
        if wanted and f.get("id") not in wanted:
            continue
        fix = f.get("fix")
        if not fix:
            if wanted:  # explicitly requested but not automatable
                skipped.append({"id": f.get("id"), "reason": "not automatable"})
            continue
        if f.get("fix_applied"):
            continue
        err = validate_override(spec, fix) or _fix_direction_guard(spec, page_name, f)
        if err:
            skipped.append({"id": f.get("id"), "reason": err})
            continue
        add_override(conv_dir, fix, finding_id=f["id"])
        f["fix_applied"] = True
        applied.append(f["id"])

    result_file.write_text(_json.dumps(payload, indent=2), encoding="utf-8")
    _result_cache.clear()  # spec changed; cached visual data is stale
    return {"applied": applied, "skipped": skipped, "findings": payload["findings"]}


@router.get("/overrides")
def list_overrides(conversion_id: str) -> dict:
    """Persisted spec overrides (reviewer remediations) for this conversion."""
    from app.services.overrides import load_overrides

    svc = get_ingest_service()
    try:
        conv_dir = svc.conversion_dir(conversion_id)
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e
    return {"overrides": load_overrides(conv_dir)}


@router.delete("/overrides")
def clear_overrides(conversion_id: str) -> dict:
    """Remove all remediations (revert to the as-compiled spec)."""
    from app.services.overrides import save_overrides

    svc = get_ingest_service()
    conv_dir = svc.conversion_dir(conversion_id)
    save_overrides(conv_dir, [])
    _result_cache.clear()
    # reset fix_applied flags on stored findings
    import json as _json

    cmp_dir = conv_dir / "visual_compare"
    if cmp_dir.is_dir():
        for f in cmp_dir.glob("*.json"):
            try:
                payload = _json.loads(f.read_text(encoding="utf-8"))
            except ValueError:
                continue
            for finding in payload.get("findings", []):
                finding["fix_applied"] = False
            f.write_text(_json.dumps(payload, indent=2), encoding="utf-8")
    return {"overrides": []}


@router.get("/visual-compare/{page_name}/image/{side}")
def visual_compare_image(conversion_id: str, page_name: str, side: str) -> Response:
    """Stored screenshot for side ('reference' | 'rendered')."""
    if side not in ("reference", "rendered"):
        raise HTTPException(422, "side must be 'reference' or 'rendered'")
    svc = get_ingest_service()
    try:
        path = svc.conversion_dir(conversion_id) / "visual_compare" / f"{page_name}_{side}.png"
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e
    if not path.is_file():
        raise HTTPException(404, "no comparison stored for this page")
    return Response(content=path.read_bytes(), media_type="image/png")


class VisualQuery(BaseModel):
    visual: str  # visual name in the spec
    page: str
    # active slicer selections merged into that visual's QuerySpec
    filters: list[FilterClause] = Field(default_factory=list)


class BatchQueryRequest(BaseModel):
    connection_id: str
    queries: list[VisualQuery]
    mode: str = "live"  # live | accelerated
    # semantic view is the primary execution path; compatibility remains as fallback
    execution_tier: QueryExecutionTier = QueryExecutionTier.TIER_A_NATIVE
    allow_tier_a_fallback: bool = True
    row_scope_id: str | None = None
    model_version: str | None = None
    data_version: str | None = None
    # optional What-If parameter overrides keyed by "Table.Column" (or table/column)
    what_if_values: dict[str, str | int | float | bool | None] = Field(default_factory=dict)


class VisualResult(BaseModel):
    visual: str
    columns: list[str] = Field(default_factory=list)
    rows: list[list] = Field(default_factory=list)
    sql: str | None = None
    warnings: list[str] = Field(default_factory=list)
    error: str | None = None
    elapsed_ms: int = 0
    cached: bool = False
    execution_tier: QueryExecutionTier = QueryExecutionTier.TIER_A_NATIVE
    trace_codes: list[str] = Field(default_factory=list)
    execution_path: str = "semantic_view"
    fallback_reason: str | None = None
    # grand-total row (PBI table/matrix totals) evaluated at the empty-group
    # context so non-additive measures (ratios) total correctly
    totals: dict | None = None


class BatchQueryResponse(BaseModel):
    results: list[VisualResult]


class AccelerateRequest(BaseModel):
    connection_id: str


class DualRunParityRequest(BaseModel):
    connection_id: str
    pages: list[str] = Field(default_factory=list)
    row_scope_id: str | None = None
    model_version: str | None = None
    data_version: str | None = None
    max_mismatches_per_visual: int = Field(default=25, ge=1, le=200)


class AskDataRequest(BaseModel):
    connection_id: str
    question: str
    question_class: str = "general"
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    dimensions: list[DimensionRef] = Field(default_factory=list)
    measures: list[MeasureRefSpec] = Field(default_factory=list)
    filters: list[FilterClause] = Field(default_factory=list)
    sort: list[dict] = Field(default_factory=list)
    limit: int | None = None
    row_scope_id: str | None = None
    model_version: str | None = None
    data_version: str | None = None
    allow_fallback: bool | None = None


class AskDataResponse(BaseModel):
    question: str
    question_class: str
    policy: AskDataPolicy
    domain_view: str | None = None
    sql: str | None = None
    columns: list[str] = Field(default_factory=list)
    rows: list[list] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    trace_codes: list[str] = Field(default_factory=list)
    fallback_used: bool = False
    fallback_allowed: bool = False
    execution_path: str = "semantic_view"
    fallback_reason: str | None = None


class DrillQueryRequest(BaseModel):
    connection_id: str
    page: str
    visual: str
    direction: str = "down"  # down | up
    level_key: str | None = None
    parent_filters: list[FilterClause] = Field(default_factory=list)
    # the slicer / cross filters in force on the visual
    filters: list[FilterClause] = Field(default_factory=list)


class DrillQueryResponse(BaseModel):
    page: str
    visual: str
    level_key: str
    level_index: int
    total_levels: int
    columns: list[str] = Field(default_factory=list)
    rows: list[list] = Field(default_factory=list)
    sql: str
    warnings: list[str] = Field(default_factory=list)


class FilterValuesRequest(BaseModel):
    connection_id: str
    page: str | None = None
    table: str
    column: str
    search: str | None = None
    limit: int = Field(default=500, ge=1, le=5000)


def run_filter_values(
    conversion_id: str,
    req: FilterValuesRequest,
    store: ConnectionStore,
    source: str = "editor",
) -> dict:
    """Distinct values of a column for a Filters-pane card (NULL kept; never cross-filtered)."""
    _, _, engine = _load(conversion_id)
    visual = f"filter-values:{req.table}.{req.column}"
    try:
        sql, _warnings = engine.build_sql(
            filter_values_query(req.table, req.column, req.search, req.limit),
            sql_context=f"visual:{req.page or ''}/{visual}:main",
        )
    except QueryPlanError as e:
        raise HTTPException(422, str(e)) from e
    conn = _connect(store, req.connection_id, conversion_id)
    started = time.perf_counter()
    try:
        cur = conn.cursor()
        cur.execute(sql)
        rows = [r[0] for r in cur.fetchall()]
        query_id = getattr(cur, "sfqid", None)
    except Exception as e:
        _log_query(
            conversion_id, req.connection_id, visual, req.page or "", sql,
            round((time.perf_counter() - started) * 1000), None, str(e),
            source=source, **_profile_info(store, req.connection_id),
        )  # fmt: skip
        raise HTTPException(422, f"could not load the values: {e}") from e
    finally:
        conn.close()
    _log_query(
        conversion_id, req.connection_id, visual, req.page or "", sql,
        round((time.perf_counter() - started) * 1000), len(rows), None, query_id=query_id,
        source=source, tables=_tables_read(_load(conversion_id)[1], sql),
        **_profile_info(store, req.connection_id),
    )  # fmt: skip
    return {"values": rows[: req.limit], "truncated": len(rows) > req.limit}


@router.post("/filter-values")
def filter_values(
    conversion_id: str,
    req: FilterValuesRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> dict:
    return run_filter_values(conversion_id, req, store)


@router.get("/what-if")
def get_what_if_parameters(conversion_id: str) -> dict:
    """List detected What-If parameters in the compiled dashboard spec."""
    spec, _, _ = _load(conversion_id)
    return {"parameters": spec.what_if_parameters}


@router.post("/query/drill", response_model=DrillQueryResponse)
def drill_query(
    conversion_id: str,
    req: DrillQueryRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> DrillQueryResponse:
    """Execute a hierarchy drill step for a visual.

    The endpoint derives the next/previous hierarchy level from VisualSpec.hierarchy,
    rewrites the visual QuerySpec dimensions to that level, applies parent filters,
    and executes the query.
    """
    spec, binding_map, engine = _load(conversion_id)
    visuals = {(p.name, v.name): v for p in spec.pages for v in p.visuals}
    vs = visuals.get((req.page, req.visual))
    if vs is None:
        raise HTTPException(404, "visual not found")
    if vs.query is None or not vs.hierarchy:
        raise HTTPException(422, "visual has no drillable hierarchy")

    levels = list(vs.hierarchy.get("levels", []))
    if not levels:
        raise HTTPException(422, "hierarchy has no levels")

    current = req.level_key or vs.hierarchy.get("current_level") or levels[-1]
    if current not in levels:
        current = levels[-1]
    cur_idx = levels.index(current)

    if req.direction == "down":
        target_idx = min(cur_idx + 1, len(levels) - 1)
    elif req.direction == "up":
        target_idx = max(cur_idx - 1, 0)
    else:
        raise HTTPException(422, "direction must be 'down' or 'up'")

    target_level = levels[target_idx]
    active_levels = set(levels[: target_idx + 1])

    # Keep only dimensions up to the target level for the selected hierarchy.
    drill_query = vs.query.model_copy(deep=True)
    drill_query.dimensions = [
        d for d in drill_query.dimensions if d.key in active_levels or d.key not in levels
    ]
    drill_query.filters.extend(req.filters)
    drill_query.filters.extend(req.parent_filters)

    try:
        sql, warnings = engine.build_sql(drill_query)
    except QueryPlanError as e:
        raise HTTPException(422, str(e)) from e

    conn = _connect(store, req.connection_id, conversion_id)
    started = time.perf_counter()
    drill_fields = {
        **_profile_info(store, req.connection_id),
        "kind": "drill",
        "drill": {"direction": req.direction, "level": target_level, "level_index": target_idx},
        "request_filters": _filter_dump(req.parent_filters, "drill"),
        "visual_filters": _filter_dump(vs.query.filters, "visual"),
        "tables": _tables_read(binding_map, sql),
        "execution_path": "compatibility",
    }
    try:
        cur = conn.cursor()
        cur.execute(sql)
        cols = [d[0] for d in cur.description]
        rows = [list(r) for r in cur.fetchall()]
    except Exception as e:
        _log_query(
            conversion_id, req.connection_id, req.visual, req.page, sql,
            round((time.perf_counter() - started) * 1000), None, str(e), **drill_fields,
        )  # fmt: skip
        raise
    else:
        _log_query(
            conversion_id, req.connection_id, req.visual, req.page, sql,
            round((time.perf_counter() - started) * 1000), len(rows), None,
            query_id=getattr(cur, "sfqid", None), **drill_fields,
        )  # fmt: skip
    finally:
        conn.close()

    return DrillQueryResponse(
        page=req.page,
        visual=req.visual,
        level_key=target_level,
        level_index=target_idx,
        total_levels=len(levels),
        columns=cols,
        rows=rows,
        sql=sql,
        warnings=warnings,
    )


class _SemanticViewPlanner:
    """Build SQL through semantic-view execution contracts for parity checks."""

    def __init__(
        self,
        engine: SemanticEngine,
        model_version: str | None,
        data_version: str | None,
        row_scope_id: str | None,
        preferred_view: str | None = None,
    ):
        self._engine = engine
        self._adapter = SemanticViewAdapter(engine.model)
        self._model_version = model_version or engine.model.model_version
        self._data_version = data_version or engine.model.data_version
        self._row_scope_id = row_scope_id
        self._preferred_view = preferred_view

    def build_sql(self, query):
        plan = self._adapter.build_sql(
            SemanticViewRequest(
                query=query,
                model_version=self._model_version,
                data_version=self._data_version,
                row_scope_id=self._row_scope_id,
                preferred_view=self._preferred_view,
            )
        )
        return plan.sql, list(plan.warnings)


def _merge_trace_codes(warnings: list[str], extra: list[str] | None = None) -> list[str]:
    merged: list[str] = []
    for code in trace_codes(warnings) + (extra or []):
        if code not in merged:
            merged.append(code)
    return merged


def _apply_what_if_values(
    visual,
    query,
    what_if_values: dict[str, str | int | float | bool | None],
) -> None:
    """Inject What-If parameter filter into the query when the visual uses one."""
    if not what_if_values:
        return
    what_if = getattr(visual, "options", {}).get("what_if") if visual is not None else None
    if not isinstance(what_if, dict):
        return
    table = what_if.get("table")
    column = what_if.get("column")
    if not table or not column:
        return

    keys = [f"{table}.{column}", str(table), str(column)]
    chosen = next((k for k in keys if k in what_if_values), None)
    if chosen is None:
        return

    query.filters = [
        f
        for f in query.filters
        if not (f.table == table and f.column == column and f.op in {"eq", "in"})
    ]
    query.filters.append(FilterClause(table=table, column=column, values=[what_if_values[chosen]], op="eq"))


@router.post("/accelerate")
def accelerate(
    conversion_id: str,
    req: AccelerateRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> dict:
    """Hydrate a local DuckDB extract from Snowflake for sub-100ms interactions."""
    from app.runtime.accelerate import hydrate

    _, binding_map, _ = _load(conversion_id)
    svc = get_ingest_service()
    conn = _connect(store, req.connection_id, conversion_id)
    try:
        meta = hydrate(binding_map, conn.cursor(), svc.conversion_dir(conversion_id))
    finally:
        conn.close()
    return meta


@router.get("/accelerate")
def acceleration_status(conversion_id: str) -> dict:
    from app.runtime.accelerate import hydration_meta

    svc = get_ingest_service()
    try:
        meta = hydration_meta(svc.conversion_dir(conversion_id))
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e
    return {"hydrated": meta is not None, "meta": meta}


@router.post("/parity/dual-run")
def dual_run_parity(
    conversion_id: str,
    req: DualRunParityRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> dict:
    """Run cell-grain parity: compatibility SQL vs semantic-view SQL plans."""
    import json as _json

    spec, _, engine = _load(conversion_id)
    actual_planner = _SemanticViewPlanner(
        engine,
        model_version=req.model_version,
        data_version=req.data_version,
        row_scope_id=req.row_scope_id,
        preferred_view=_preferred_semantic_view(conversion_id),
    )

    conn = _connect(store, req.connection_id, conversion_id)
    try:
        report = run_dual_run_parity(
            spec=spec,
            expected_engine=engine,
            actual_engine=actual_planner,
            expected_cursor=conn.cursor(),
            actual_cursor=conn.cursor(),
            pages=req.pages or None,
            max_mismatches_per_visual=req.max_mismatches_per_visual,
        )
    finally:
        conn.close()

    svc = get_ingest_service()
    artifact = {
        "summary": report.summary(),
        "request": req.model_dump(),
        "report": report.model_dump(),
        "generated_at": time.time(),
    }
    out = svc.conversion_dir(conversion_id) / "dual_run_parity.json"
    out.write_text(_json.dumps(artifact, indent=2), encoding="utf-8")
    return artifact


@router.get("/parity/dual-run")
def get_dual_run_parity(conversion_id: str) -> dict:
    """Retrieve latest persisted dual-run parity artifact."""
    import json as _json

    svc = get_ingest_service()
    try:
        path = svc.conversion_dir(conversion_id) / "dual_run_parity.json"
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e
    if not path.is_file():
        raise HTTPException(404, "no dual-run parity report yet; POST /parity/dual-run first")
    return _json.loads(path.read_text(encoding="utf-8"))


class GoldenParityRequest(BaseModel):
    connection_id: str
    pages: list[str] = Field(default_factory=list)


@router.post("/parity/golden/upload")
async def upload_golden_export(conversion_id: str, file: UploadFile) -> dict:
    """Upload a Power BI Performance Analyzer export JSON used as golden output."""
    import json as _json

    if not file.filename or not file.filename.lower().endswith(".json"):
        raise HTTPException(400, "expected a .json file")

    svc = get_ingest_service()
    try:
        root = svc.conversion_dir(conversion_id)
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e

    raw = await file.read()
    try:
        # Validate JSON shape by parsing through loader
        tmp = root / "golden_performance_analyzer.json"
        tmp.write_bytes(raw)
        golden = load_golden(tmp)
    except Exception as e:
        raise HTTPException(400, f"invalid performance analyzer export: {e}") from e

    meta = {
        "source_file": file.filename,
        "entries": len(golden.entries),
        "uploaded_at": time.time(),
    }
    (root / "golden_meta.json").write_text(_json.dumps(meta, indent=2), encoding="utf-8")
    return meta


@router.post("/parity/golden")
def run_golden_parity(
    conversion_id: str,
    req: GoldenParityRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> dict:
    """Execute dashboard visuals and compare against uploaded golden values."""
    import json as _json

    svc = get_ingest_service()
    try:
        root = svc.conversion_dir(conversion_id)
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e

    golden_path = root / "golden_performance_analyzer.json"
    if not golden_path.is_file():
        raise HTTPException(404, "no golden export uploaded; POST /parity/golden/upload first")

    golden = load_golden(golden_path)
    spec, _, engine = _load(conversion_id)

    conn = _connect(store, req.connection_id, conversion_id)
    results: list[dict] = []
    passed = 0
    failed = 0
    skipped = 0
    try:
        cur = conn.cursor()
        for page in spec.pages:
            if req.pages and page.name not in req.pages and page.display_name not in req.pages:
                continue
            for vis in page.visuals:
                if vis.query is None or not vis.supported:
                    skipped += 1
                    results.append(
                        {
                            "page": page.display_name,
                            "visual": vis.name,
                            "status": "skipped",
                            "detail": "static or unsupported visual",
                        }
                    )
                    continue

                golden_entry = golden.find(vis.name)
                if golden_entry is None:
                    skipped += 1
                    results.append(
                        {
                            "page": page.display_name,
                            "visual": vis.name,
                            "status": "skipped",
                            "detail": "no matching golden visual entry",
                        }
                    )
                    continue

                try:
                    sql, _warnings = engine.build_sql(vis.query)
                    cur.execute(sql)
                    cols = [d[0] for d in cur.description]
                    rows = cur.fetchall()
                    chk = compare_against_golden(vis.name, rows, cols, golden_entry)
                    status = chk.status.value
                    if status == "passed":
                        passed += 1
                    elif status == "failed":
                        failed += 1
                    else:
                        skipped += 1
                    results.append(
                        {
                            "page": page.display_name,
                            "visual": vis.name,
                            "status": status,
                            "detail": chk.detail,
                        }
                    )
                except Exception as e:  # noqa: BLE001 - keep parity run going
                    failed += 1
                    results.append(
                        {
                            "page": page.display_name,
                            "visual": vis.name,
                            "status": "failed",
                            "detail": str(e),
                        }
                    )
    finally:
        conn.close()

    artifact = {
        "summary": {
            "passed": passed,
            "failed": failed,
            "skipped": skipped,
            "total": len(results),
            "pass_rate": (passed / (passed + failed)) if (passed + failed) else 1.0,
        },
        "results": results,
        "generated_at": time.time(),
    }
    (root / "golden_parity.json").write_text(_json.dumps(artifact, indent=2), encoding="utf-8")
    return artifact


@router.get("/parity/golden")
def get_golden_parity(conversion_id: str) -> dict:
    """Retrieve latest persisted golden parity artifact."""
    import json as _json

    svc = get_ingest_service()
    try:
        path = svc.conversion_dir(conversion_id) / "golden_parity.json"
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e
    if not path.is_file():
        raise HTTPException(404, "no golden parity report yet; POST /parity/golden first")
    return _json.loads(path.read_text(encoding="utf-8"))


@router.post("/ask", response_model=AskDataResponse)
def ask_data(
    conversion_id: str,
    req: AskDataRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> AskDataResponse:
    """Ask-data execution on the same semantic-view runtime with policy gates."""
    spec, _, engine = _load(conversion_id)
    adapter = SemanticViewAdapter(engine.model)
    svc = get_ingest_service()
    bundle = svc.load_bundle(conversion_id)
    coverage = next(
        (c for c in bundle.report.ask_data_coverage if c.question_class == req.question_class),
        None,
    )
    if coverage is None:
        policy = AskDataPolicy.REFUSE_ON_LOW_CONFIDENCE
        domain_view = None
        fallback_allowed = False
    else:
        policy = coverage.policy
        domain_view = coverage.domain_view
        fallback_allowed = coverage.fallback_allowed

    if req.allow_fallback is not None:
        fallback_allowed = req.allow_fallback

    if policy == AskDataPolicy.REFUSE_ON_LOW_CONFIDENCE and req.confidence < 0.75:
        raise HTTPException(422, "ask-data request refused due to low confidence policy")

    query = QuerySpec(
        dimensions=req.dimensions,
        measures=req.measures,
        filters=req.filters,
        sort=req.sort,
        limit=req.limit,
    )

    warnings: list[str] = []
    sv_traces: list[str] = []
    fallback_used = False
    fallback_reason: str | None = None
    preferred_view = domain_view or _preferred_semantic_view(conversion_id)
    try:
        plan = adapter.build_sql(
            SemanticViewRequest(
                query=query,
                model_version=req.model_version or engine.model.model_version,
                data_version=req.data_version or engine.model.data_version,
                row_scope_id=req.row_scope_id,
                preferred_view=preferred_view,
            )
        )
        sql, warnings, sv_traces = plan.sql, list(plan.warnings), list(plan.trace_codes)
    except SemanticViewPlanError:
        if not fallback_allowed:
            raise HTTPException(422, "semantic-view coverage missing for this question class")
        fallback_reason = "semantic-view coverage missing"
        try:
            sql, compat_warnings = engine.build_sql(query)
        except QueryPlanError as e:
            raise HTTPException(422, str(e)) from e
        warnings = [
            "[OVERLAY:ASKDATA_FALLBACK] ask-data fell back to compatibility runtime"
        ] + compat_warnings
        fallback_used = True

    conn = _connect(store, req.connection_id, conversion_id)
    try:
        cur = conn.cursor()
        cur.execute(sql)
        cols = [d[0] for d in cur.description]
        rows = [list(r) for r in cur.fetchall()]
    finally:
        conn.close()

    if policy == AskDataPolicy.COVERED_ONLY and fallback_used:
        raise HTTPException(422, "ask-data policy requires semantic-view coverage only")

    return AskDataResponse(
        question=req.question,
        question_class=req.question_class,
        policy=policy,
        domain_view=domain_view,
        sql=sql,
        columns=cols,
        rows=rows,
        warnings=warnings,
        trace_codes=_merge_trace_codes(warnings, sv_traces),
        fallback_used=fallback_used,
        fallback_allowed=fallback_allowed,
        execution_path="compatibility" if fallback_used else "semantic_view",
        fallback_reason=fallback_reason,
    )


_STATIC_VISUAL_TYPES = {
    "textbox", "shape", "basicShape", "image", "actionButton",
    "visualGroup", "bookmarkNavigator", "pageNavigator",
}  # fmt: skip


def _is_static_visual(vs) -> bool:
    return vs.visual_type in _STATIC_VISUAL_TYPES


def _execute_compat_fallback(
    conn,
    visual: str,
    compat_sql: str,
    warnings: list[str],
    tier: QueryExecutionTier,
    sv_traces: list[str],
    sv_error: str,
) -> dict | None:
    """Re-run a visual on the compatibility runtime after the semantic-view SQL errored."""
    started = time.perf_counter()
    try:
        cur = conn.cursor()
        cur.execute(compat_sql)
        cols = [d[0] for d in cur.description]
        rows = [list(r) for r in cur.fetchall()]
    except Exception as e:
        # the original semantic-view error (sv_error) is still surfaced to the
        # caller; this fallback's own failure reason would otherwise vanish
        log_event(
            _query_logger,
            "warning",
            "compat_fallback_failed",
            visual=visual,
            semantic_view_error=sv_error,
            fallback_error=str(e),
        )
        return None
    merged_warnings = [
        "[OVERLAY:TIER_A_FALLBACK] semantic-view execution failed; "
        "fell back to compatibility runtime"
    ] + warnings
    return {
        "visual": visual,
        "columns": cols,
        "rows": rows,
        "sql": compat_sql,
        "warnings": merged_warnings,
        "execution_tier": tier,
        "trace_codes": _merge_trace_codes(merged_warnings, sv_traces),
        "elapsed_ms": round((time.perf_counter() - started) * 1000),
        "execution_path": "compatibility",
        "fallback_reason": f"semantic-view execution failed: {sv_error.splitlines()[0][:200]}",
    }


@router.post("/query", response_model=BatchQueryResponse)
def batch_query(
    conversion_id: str,
    req: BatchQueryRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
    variant: str | None = None,
) -> BatchQueryResponse:
    return run_batch_query(conversion_id, req, store, variant, source="editor")


def _manual_plan(q, vs, override: dict, engine, extra_filters: list, plan):
    """Replace the planned MAIN query of an edited visual with its rendered SQL."""
    filters = []
    for f in [*q.filters, *extra_filters]:
        if vs is not None and vs.slicer_target and (
            f.table == vs.slicer_target["table"] and f.column == vs.slicer_target["column"]
        ):
            continue
        filters.append(f)
    sql, unapplied = _sqlo.render(override["sql"], filters, engine)
    warnings = list(plan[2]) if plan else []
    totals_sql = plan[8] if plan and len(plan) > 8 else None
    return (
        (q, sql, warnings, None, [], "manual_sql", None, None, totals_sql),
        unapplied,
    )


def _apply_sql_overrides(plans, visuals, engine, conversion_id, extra_filters_for=None):
    """Edited SQL replaces the generated main query (also rescuing plan errors / untranslated
    panes). Returns (plans, {(page, visual): unapplied filter tables})."""
    try:
        root = get_ingest_service().conversion_dir(conversion_id)
    except ValueError:
        return plans, {}
    overrides = _sqlo.load_overrides(root)
    if not overrides:
        return plans, {}
    unapplied: dict[tuple[str, str], list[str]] = {}
    out = []
    for plan in plans:
        q = plan[0]
        override = overrides.get(_sqlo.key_for(q.page, q.visual))
        if override is None or plan[5] == "static":
            out.append(plan)
            continue
        extra = extra_filters_for(q, visuals.get((q.page, q.visual))) if extra_filters_for else []
        try:
            new_plan, missing = _manual_plan(
                q, visuals.get((q.page, q.visual)), override, engine, extra, plan
            )
        except Exception as e:  # noqa: BLE001 - a bad edit must surface per pane, not 500
            reason = f"edited SQL: {e}"
            out.append((q, None, [], reason, [], "error", reason, None, None))
            continue
        unapplied[(q.page, q.visual)] = missing
        out.append(new_plan)
    return plans if not out else out, unapplied


def run_batch_query(
    conversion_id: str,
    req: BatchQueryRequest,
    store: ConnectionStore,
    variant: str | None = None,
    source: str = "editor",
) -> BatchQueryResponse:
    spec, binding_map, engine = _load(conversion_id)
    if variant == "reimagined":
        # identical QuerySpecs by construction; the variant only changes
        # layout/type/options, so execution planning is unchanged
        spec = _load_variant_spec(conversion_id)
    tier = req.execution_tier
    sv_adapter = SemanticViewAdapter(engine.model)
    preferred_view = _preferred_semantic_view(conversion_id)

    if tier == QueryExecutionTier.TIER_C_EXCEPTION:
        raise HTTPException(
            422,
            "tier_c_exception requires a human-approved exception workflow before execution",
        )

    visuals = {(p.name, v.name): v for p in spec.pages for v in p.visuals}
    # measure-driven titles / button text: `<visual>#title` is a measure-only query under the
    # visual's own column filters, returned as an extra result of every request for its visual
    for (page_name, visual_name), vs in list(visuals.items()):
        if vs.title_query is not None:
            visuals[(page_name, f"{visual_name}{_qa.TITLE_SUFFIX}")] = VisualSpec(
                name=f"{visual_name}{_qa.TITLE_SUFFIX}", visual_type="card",
                x=0, y=0, width=0, height=0, query=vs.title_query,
            )  # fmt: skip
    queries = list(req.queries)
    requested = {(q.page, q.visual) for q in queries}
    for q in req.queries:
        extra = (q.page, f"{q.visual}{_qa.TITLE_SUFFIX}")
        if extra in visuals and extra not in requested:
            requested.add(extra)
            queries.append(VisualQuery(visual=extra[1], page=q.page, filters=q.filters))
    # (query, sql, warnings, error, sv_traces, execution_path, fallback_reason,
    #  compat_sql, totals_sql)
    plans: list[
        tuple[
            VisualQuery,
            str | None,
            list[str],
            str | None,
            list[str],
            str,
            str | None,
            str | None,
            str | None,
        ]
    ] = []
    for q in queries:
        vs = visuals.get((q.page, q.visual))
        if vs is None:
            plans.append((q, None, [], "unknown visual", [], "error", "unknown visual", None, None))
            continue
        if vs.supported and vs.query is None and _is_static_visual(vs):
            # static visuals (textbox/shape/image) render from the spec alone
            results_static = "static visual: renders from spec, no data query"
            plans.append((q, None, [], None, [], "static", results_static, None, None))
            continue
        if not vs.supported or vs.query is None:
            plans.append(
                (
                    q,
                    None,
                    [],
                    vs.unsupported_reason or "unsupported visual",
                    [],
                    "error",
                    vs.unsupported_reason or "unsupported visual",
                    None,
                    None,
                )
            )
            continue
        merged = vs.query.model_copy(deep=True)
        for f in q.filters:
            # a slicer must not filter its own domain query
            if vs.slicer_target and (
                f.table == vs.slicer_target["table"]
                and f.column == vs.slicer_target["column"]
            ):
                continue
            merged.filters.append(f)
        _apply_what_if_values(vs, merged, req.what_if_values)
        totals_sql: str | None = None
        if merged.dimensions and merged.measures and (
            (vs.options.get("show_totals") and vs.visual_type in ("pivotTable", "tableEx"))
            or vs.measure_show_as  # "% of grand total" divides by the grand total
        ):
            try:
                totals_query = merged.model_copy(deep=True)
                totals_query.dimensions = []
                totals_query.sort = []
                totals_sql = engine.build_sql(totals_query)[0]
            except QueryPlanError:
                totals_sql = None
        try:
            sv_traces: list[str] = []
            execution_path = "semantic_view"
            fallback_reason: str | None = None
            compat_sql: str | None = None
            if tier == QueryExecutionTier.TIER_A_NATIVE:
                if vs.options.get("semantic_force_compatibility"):
                    fallback_reason = str(
                        vs.options.get("semantic_force_compatibility_reason")
                        or "semantic-view coverage missing"
                    )
                    sql, warnings = engine.build_sql(merged)
                    warnings = [
                        "[OVERLAY:TIER_A_FORCE_COMPAT] semantic-view planning skipped for visual; "
                        "executed via compatibility runtime"
                    ] + warnings
                    execution_path = "compatibility"
                    plans.append(
                        (
                            q,
                            sql,
                            warnings,
                            None,
                            sv_traces,
                            execution_path,
                            fallback_reason,
                            None,
                            totals_sql,
                        )
                    )
                    continue
                try:
                    sv_req = SemanticViewRequest(
                        query=merged,
                        model_version=req.model_version or engine.model.model_version,
                        data_version=req.data_version or engine.model.data_version,
                        row_scope_id=req.row_scope_id,
                        preferred_view=preferred_view,
                    )
                    plan = sv_adapter.build_sql(sv_req)
                    sql, warnings = plan.sql, list(plan.warnings)
                    sv_traces = list(plan.trace_codes)
                    if req.allow_tier_a_fallback:
                        # kept in reserve: Snowflake can still reject a plannable
                        # semantic-view query (e.g. unrelated entities) at execution time
                        try:
                            compat_sql = engine.build_sql(merged)[0]
                        except QueryPlanError:
                            compat_sql = None
                except SemanticViewPlanError:
                    if not req.allow_tier_a_fallback:
                        raise
                    fallback_reason = "semantic-view coverage missing"
                    sql, warnings = engine.build_sql(merged)
                    warnings = [
                        "[OVERLAY:TIER_A_FALLBACK] semantic-view execution unavailable; "
                        "fell back to compatibility runtime"
                    ] + warnings
                    execution_path = "compatibility"
            else:
                sql, warnings = engine.build_sql(merged)
                warnings = [
                    f"[OVERLAY:TIER_FALLBACK] executed via compatibility tier '{tier.value}'"
                ] + warnings
                execution_path = "compatibility"
            plans.append(
                (
                    q,
                    sql,
                    warnings,
                    None,
                    sv_traces,
                    execution_path,
                    fallback_reason,
                    compat_sql,
                    totals_sql,
                )
            )
        except (QueryPlanError, SemanticViewPlanError) as e:
            plans.append((q, None, [], str(e), [], "error", str(e), None, None))

    accelerated = req.mode == "accelerated"
    page_of = {v.name: p for p in spec.pages for v in p.visuals}
    plans, unapplied_by_pane = _apply_sql_overrides(
        plans,
        visuals,
        engine,
        conversion_id,
        # the page's report / page default filters follow an edited pane too
        extra_filters_for=lambda q, _vs: default_filter_clauses(spec, page_of[q.visual])
        if q.visual in page_of
        else [],
    )
    profile = {} if accelerated else _profile_info(store, req.connection_id)

    def audit(
        q,
        status: str,
        *,
        attempt: str = "primary",
        sql: str | None = None,
        compat_sql: str | None = None,
        totals_sql: str | None = None,
        elapsed_ms: float = 0,
        row_count: int | None = None,
        error: str | None = None,
        query_id: str | None = None,
        execution_path: str | None = None,
        fallback_reason: str | None = None,
        kind: str = "dashboard",
    ) -> None:
        if accelerated:  # extract runs are not Snowflake queries
            return
        vs = visuals.get((q.page, q.visual))
        own = vs.slicer_target if vs else None
        request_filters = [
            f
            for f in q.filters
            if not (own and f.table == own["table"] and f.column == own["column"])
        ]
        fields: dict = {
            **profile,
            "kind": kind,
            "status": status,
            "attempt": attempt,
            "source": source,
            "tables": _tables_read(binding_map, sql, compat_sql, totals_sql),
            "visual_filters": _filter_dump(vs.query.filters, "visual") if vs and vs.query else [],
            "request_filters": _filter_dump(request_filters, "slicer"),
            "measures": [m.name for m in (vs.query or vs.draft_query).measures if m.name]
            if vs and (vs.query or vs.draft_query)
            else [],
            "query_id": query_id,
            "execution_path": execution_path,
            "fallback_reason": fallback_reason,
            "compat_sql": compat_sql,
            "totals_sql": totals_sql,
        }
        if execution_path == "manual_sql":
            fields["sql_override"] = True
            fields["unapplied_filters"] = unapplied_by_pane.get((q.page, q.visual), [])
        _log_query(
            conversion_id,
            req.connection_id,
            q.visual,
            q.page,
            sql or "",
            elapsed_ms,
            row_count,
            error,
            **fields,
        )

    results: list[VisualResult] = []
    conn = None
    duck = None
    if accelerated:
        from app.runtime.accelerate import AccelerationError, DuckDBExecutor

        svc = get_ingest_service()
        try:
            duck = DuckDBExecutor(svc.conversion_dir(conversion_id), binding_map)
        except AccelerationError as e:
            raise HTTPException(409, str(e)) from e
    try:
        for (
            q,
            sql,
            warnings,
            error,
            sv_traces,
            execution_path,
            fallback_reason,
            compat_sql,
            totals_sql,
        ) in plans:
            if sql is None:
                results.append(
                    VisualResult(
                        visual=q.visual,
                        error=error,
                        execution_path=execution_path,
                        fallback_reason=fallback_reason,
                    )
                )
                if error and execution_path != "static":
                    audit(
                        q,
                        "plan_error",
                        attempt="plan",
                        error=error,
                        execution_path=execution_path,
                        fallback_reason=fallback_reason,
                    )
                continue
            key = cache_key(
                conversion_id,
                req.mode,
                sql,
                tier,
                req.row_scope_id,
                req.model_version,
                req.data_version,
            )
            now = time.time()
            hit = _result_cache.get(key)
            if hit and now - hit[0] < _TTL_SECONDS:
                # identical SQL can be shared across visuals; relabel per request
                results.append(
                    VisualResult(**{**hit[1], "visual": q.visual}, cached=True)
                )
                audit(
                    q,
                    "cached",
                    sql=sql,
                    compat_sql=compat_sql,
                    totals_sql=totals_sql,
                    row_count=len(hit[1].get("rows") or []),
                    execution_path=execution_path,
                    fallback_reason=fallback_reason,
                )
                continue
            if accelerated:
                started = time.perf_counter()
                try:
                    duck.execute(sql)
                    cols = [d[0] for d in duck.description]
                    rows = [list(r) for r in duck.fetchall()]
                    payload = {
                        "visual": q.visual,
                        "columns": cols,
                        "rows": rows,
                        "sql": sql,
                        "warnings": warnings,
                        "execution_tier": tier,
                        "trace_codes": _merge_trace_codes(warnings, sv_traces),
                        "elapsed_ms": round((time.perf_counter() - started) * 1000),
                        "execution_path": execution_path,
                        "fallback_reason": fallback_reason,
                    }
                    _result_cache[key] = (now, payload)
                    results.append(VisualResult(**payload))
                except Exception as e:
                    results.append(
                        VisualResult(
                            visual=q.visual,
                            sql=sql,
                            error=str(e),
                            warnings=warnings,
                            execution_tier=tier,
                            trace_codes=_merge_trace_codes(warnings, sv_traces),
                            execution_path=execution_path,
                            fallback_reason=fallback_reason,
                        )
                    )
                continue
            if conn is None:
                conn = _connect(store, req.connection_id, conversion_id)
            started = time.perf_counter()
            try:
                cur = conn.cursor()
                cur.execute(sql)
                query_id = getattr(cur, "sfqid", None)
                cols = [d[0] for d in cur.description]
                rows = [list(r) for r in cur.fetchall()]
                elapsed = round((time.perf_counter() - started) * 1000)
                totals = None
                if totals_sql:
                    totals_started = time.perf_counter()
                    try:
                        cur.execute(totals_sql)
                        totals_id = getattr(cur, "sfqid", None)
                        t_cols = [d[0] for d in cur.description]
                        t_rows = cur.fetchall()
                        if t_rows:
                            totals = {"columns": t_cols, "row": list(t_rows[0])}
                        audit(
                            q,
                            "ok" if t_rows else "empty",
                            kind="totals",
                            sql=totals_sql,
                            elapsed_ms=round((time.perf_counter() - totals_started) * 1000),
                            row_count=len(t_rows),
                            query_id=totals_id,
                            execution_path=execution_path,
                        )
                    except Exception as te:  # noqa: BLE001 - totals are best-effort decoration
                        totals = None
                        audit(
                            q,
                            "error",
                            kind="totals",
                            sql=totals_sql,
                            elapsed_ms=round((time.perf_counter() - totals_started) * 1000),
                            error=str(te),
                            execution_path=execution_path,
                        )
                payload = {
                    "visual": q.visual,
                    "columns": cols,
                    "rows": rows,
                    "sql": sql,
                    "warnings": warnings,
                    "execution_tier": tier,
                    "trace_codes": _merge_trace_codes(warnings, sv_traces),
                    "elapsed_ms": elapsed,
                    "execution_path": execution_path,
                    "fallback_reason": fallback_reason,
                    "totals": totals,
                }
                _result_cache[key] = (now, payload)
                results.append(VisualResult(**payload))
                audit(
                    q,
                    "ok" if rows else "empty",
                    sql=sql,
                    compat_sql=compat_sql,
                    totals_sql=totals_sql,
                    elapsed_ms=elapsed,
                    row_count=len(rows),
                    query_id=query_id,
                    execution_path=execution_path,
                    fallback_reason=fallback_reason,
                )
            except Exception as e:  # snowflake raises many types
                audit(
                    q,
                    "error",
                    sql=sql,
                    compat_sql=compat_sql,
                    totals_sql=totals_sql,
                    elapsed_ms=round((time.perf_counter() - started) * 1000),
                    error=str(e),
                    execution_path=execution_path,
                    fallback_reason=fallback_reason,
                )
                retried = None
                if compat_sql and compat_sql != sql:
                    retried = _execute_compat_fallback(
                        conn,
                        q.visual,
                        compat_sql,
                        warnings,
                        tier,
                        sv_traces,
                        str(e),
                    )
                    audit(
                        q,
                        "ok" if retried and retried["rows"] else ("empty" if retried else "error"),
                        attempt="fallback",
                        sql=compat_sql,
                        elapsed_ms=retried["elapsed_ms"] if retried else 0,
                        row_count=len(retried["rows"]) if retried else None,
                        error=None if retried else "compatibility fallback failed",
                        execution_path="compatibility",
                        fallback_reason=retried["fallback_reason"] if retried else None,
                    )
                if retried is not None:
                    _result_cache[cache_key(
                        conversion_id,
                        req.mode,
                        compat_sql,
                        tier,
                        req.row_scope_id,
                        req.model_version,
                        req.data_version,
                    )] = (now, retried)
                    results.append(VisualResult(**retried))
                    continue
                results.append(
                    VisualResult(
                        visual=q.visual,
                        sql=sql,
                        error=str(e),
                        warnings=warnings,
                        execution_tier=tier,
                        trace_codes=_merge_trace_codes(warnings, sv_traces),
                        execution_path=execution_path,
                        fallback_reason=fallback_reason,
                    )
                )
    finally:
        if conn is not None:
            conn.close()
        if duck is not None:
            duck.close()
    return BatchQueryResponse(results=results)


def _events_path(conversion_id: str) -> Path | None:
    try:
        return get_ingest_service().conversion_dir(conversion_id) / "events.jsonl"
    except (ValueError, OSError):
        return None


def _profile_info(store: ConnectionStore, connection_id: str | None) -> dict:
    """Warehouse / role / connection name as configured at query time (never secrets)."""
    if not connection_id:
        return {}
    try:
        p = store.get(connection_id)
    except (KeyError, ValueError):
        return {}
    return {"warehouse": p.warehouse, "role": p.role, "connection_name": p.name}


def _audited(
    conn,
    store: ConnectionStore,
    connection_id: str | None,
    conversion_id: str,
    kind: str = "validation",
    context: str | None = None,
    extra: dict | None = None,
):
    """Wrap a connection so every execute writes a `dashboard_query` audit event."""
    path = _events_path(conversion_id)
    if path is None:
        return conn
    audited = _qa.AuditedConnection(
        conn,
        path,
        conversion_id=conversion_id,
        connection_id=connection_id,
        profile=_profile_info(store, connection_id),
        kind=kind,
        extra=extra,
    )
    audited.context = context
    return audited


def _tables_read(binding_map: BindingMap, *sqls: str | None) -> list[dict]:
    """Every bound model table whose qualified name or native query appears in the SQL."""
    text = "\n".join(s for s in sqls if s)
    if not text:
        return []
    out = []
    for b in binding_map.bindings.values():
        needle = b.native_query or b.qualified_name
        if needle and needle in text:
            out.append({"model_table": b.table, "physical": b.qualified_name or "(native query)"})
    return sorted(out, key=lambda t: t["model_table"])


def _filter_dump(filters, default_source: str | None = None) -> list[dict]:
    return [
        {
            "table": f.table,
            "column": f.column,
            "op": f.op,
            "values": list(f.values),
            "source": f.source or default_source,
        }
        for f in filters
    ]


def _log_query(
    conversion_id: str,
    connection_id: str,
    visual: str,
    page: str,
    sql: str,
    elapsed_ms: float,
    row_count: int | None,
    error: str | None,
    **fields,
) -> None:
    """One `dashboard_query` audit event (kind, status, attempt, source, filters, tables, ...)."""
    settings = get_settings()
    record: dict = {
        "conversion_id": conversion_id,
        "connection_id": connection_id,
        "query_tag": f"pbic:dash:{conversion_id}",
        "runtime": "snowflake",
        "kind": "dashboard",
        "attempt": "primary",
        "source": "editor",
        "page": page,
        "visual": visual,
        "elapsed_ms": elapsed_ms,
        "row_count": row_count,
        "error": error,
        "sql": sql,
        **fields,
    }
    record.setdefault(
        "status",
        "error" if error else ("empty" if row_count == 0 else "ok"),
    )
    public = {k: v for k, v in record.items() if k not in ("sql", "compat_sql", "totals_sql")}
    if settings.log_sql_text:
        public.update({k: record[k] for k in ("sql", "compat_sql", "totals_sql") if record.get(k)})
    log_event(
        _query_logger,
        "error" if record["status"] in ("error", "plan_error") else "info",
        "dashboard_query",
        **public,
    )
    path = _events_path(conversion_id)
    if path is not None:
        _qa.write_query_event(path, record)  # best-effort: never breaks query execution


def _connect(store: ConnectionStore, connection_id: str, conversion_id: str):
    try:
        store.get(connection_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e

    try:
        return store.session_manager.open_connection(
            connection_id, query_tag=f"pbic:dash:{conversion_id}"
        )
    except ModuleNotFoundError as e:
        raise HTTPException(501, "snowflake-connector-python not installed") from e
    except SnowflakeAuthenticationRequired as e:
        raise HTTPException(
            409,
            detail={
                "code": "snowflake_authentication_required",
                "message": str(e),
            },
        ) from e
    except ValueError as e:
        # Preserve credential/config validation errors (for example malformed key-pair PEM).
        raise HTTPException(422, f"invalid connection configuration: {e}") from e


# ====================================================================== phase 08: audits & editing


def _pane_label(vs) -> str:
    return vs.title or f"{vs.visual_type} {vs.name}"


def _find_visual(spec: DashboardSpec, page: str, visual: str):
    for p in spec.pages:
        if p.name == page:
            for v in p.visuals:
                if v.name == visual:
                    return p, v
    raise HTTPException(404, "visual not found")


# ---------------------------------------------------------------- query audit


@router.get("/query-audit")
def get_query_audit(
    conversion_id: str,
    source: str = "all",
    page: str | None = None,
    history_for: str | None = None,
    kind: str = "dashboard",
) -> dict:
    spec, _, _ = _load(conversion_id)
    path = _events_path(conversion_id)
    rows, summary = _qa.load_query_audit(
        path, spec, source=source, page=page, history_for=history_for, kind=kind
    ) if path else ([], _qa._summary([], 0, _qa.MAX_EVENTS, {}))
    return {"records": rows, "summary": summary}


@router.get("/query-audit/export")
def export_query_audit(
    conversion_id: str,
    format: Literal["xlsx", "json"] = "xlsx",
    source: str = "all",
    page: str | None = None,
    status: str | None = None,
    search: str | None = None,
    kind: str = "dashboard",
) -> Response:
    spec, _, _ = _load(conversion_id)
    path = _events_path(conversion_id)
    rows, summary = _qa.load_query_audit(path, spec, source=source, page=page, kind=kind)
    rows = _qa.filter_records(rows, status, search)
    if format == "json":
        payload = _qa.build_query_audit_json(rows, summary, conversion_id)
        return Response(
            json.dumps(payload, indent=2, default=str),
            media_type="application/json",
            headers={
                "Content-Disposition": f'attachment; filename="{conversion_id}_query_audit.json"'
            },
        )
    return Response(
        _qa.build_query_audit_xlsx(rows, summary, conversion_id),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{conversion_id}_query_audit.xlsx"'},
    )


# ---------------------------------------------------------------- Edit SQL


def _expected_columns(vs) -> list[str]:
    return list(
        dict.fromkeys([*vs.dim_keys, *vs.column_keys, *vs.series_keys, *vs.measure_keys])
    )


def _conversion_root(conversion_id: str) -> Path:
    try:
        return get_ingest_service().conversion_dir(conversion_id)
    except ValueError as e:
        raise HTTPException(404, "conversion not found") from e


def _generated_sql(engine: SemanticEngine, vs) -> tuple[str | None, str | None]:
    query = vs.query or vs.draft_query
    if query is None:
        return None, vs.unsupported_reason or "no query"
    try:
        return engine.build_sql(query)[0], None
    except Exception as e:  # noqa: BLE001 - shown to the reviewer as base_error
        return None, str(e)


def _filter_tables(spec: DashboardSpec, page, vs, engine: SemanticEngine) -> list[dict]:
    tables: list[str] = []
    query = vs.query or vs.draft_query
    if query is not None:
        tables.extend(d.table for d in query.dimensions)
    for key in vs.dim_keys:
        if "." in key:
            tables.append(key.split(".", 1)[0])
    for other in page.visuals:
        if other.slicer_target:
            tables.append(other.slicer_target["table"])
    out, seen = [], set()
    for t in tables:
        if t.casefold() in seen:
            continue
        seen.add(t.casefold())
        out.append({"table": t, "alias": engine.table_alias(t)})
    return out


@router.get("/sql-editor")
def get_sql_editor(conversion_id: str, page: str, visual: str) -> dict:
    spec, _, engine = _load(conversion_id)
    p, vs = _find_visual(spec, page, visual)
    base_sql, base_error = _generated_sql(engine, vs)
    override = _sqlo.load_overrides(_conversion_root(conversion_id)).get(
        _sqlo.key_for(page, visual)
    )
    return {
        "page": page,
        "visual": visual,
        "pane": _pane_label(vs),
        "base_sql": base_sql,
        "base_error": base_error,
        "expected_columns": _expected_columns(vs),
        "filter_tables": _filter_tables(spec, p, vs, engine),
        "override": override,
    }


class SqlOverrideRequest(BaseModel):
    page: str
    visual: str
    sql: str


class SqlOverrideTestRequest(SqlOverrideRequest):
    connection_id: str
    filters: list[FilterClause] = Field(default_factory=list)


_PREVIEW_ROWS = 50


def _check_sql(sql: str) -> str:
    try:
        return _sqlo.validate_sql(sql)
    except _sqlo.SqlOverrideError as e:
        raise HTTPException(422, str(e)) from e


@router.post("/sql-overrides/test")
def test_sql_override(
    conversion_id: str,
    req: SqlOverrideTestRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> dict:
    spec, _, engine = _load(conversion_id)
    _, vs = _find_visual(spec, req.page, req.visual)
    text = _check_sql(req.sql)
    try:
        rendered, unapplied = _sqlo.render(text, req.filters, engine)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(422, f"could not apply the filters: {e}") from e
    expected = _expected_columns(vs)
    out: dict = {
        "rendered_sql": rendered,
        "unapplied_filter_tables": unapplied,
        "has_filters_placeholder": _sqlo.has_filters_placeholder(text),
        "null_comparison_warnings": _sqlo.null_comparison_warnings(text),
        "expected_columns": expected,
        "columns": [],
        "rows": [],
        "row_count": 0,
        "elapsed_ms": 0,
        "query_id": None,
        "error": None,
        "missing_columns": [],
    }
    conn = _audited(
        _connect(store, req.connection_id, conversion_id),
        store,
        req.connection_id,
        conversion_id,
        "setup",
        "sql edit test",
        {"page": req.page, "visual": req.visual},
    )
    started = time.perf_counter()
    try:
        cur = conn.cursor()
        cur.execute(rendered)
        out["columns"] = [d[0] for d in cur.description]
        rows = [list(r) for r in cur.fetchall()]
        out["row_count"] = len(rows)
        out["rows"] = rows[:_PREVIEW_ROWS]
        out["query_id"] = getattr(cur, "sfqid", None)
        out["missing_columns"] = [c for c in expected if c not in out["columns"]]
    except Exception as e:  # noqa: BLE001 - Snowflake raises many types
        out["error"] = str(e)
    finally:
        out["elapsed_ms"] = round((time.perf_counter() - started) * 1000)
        conn.close()
    return out


@router.get("/sql-overrides")
def list_sql_overrides(conversion_id: str) -> dict:
    root = _conversion_root(conversion_id)
    return {"overrides": sorted(
        _sqlo.load_overrides(root).values(), key=lambda o: (o["page"], o["visual"])
    )}


@router.put("/sql-overrides")
def save_sql_override(conversion_id: str, req: SqlOverrideRequest) -> dict:
    spec, _, engine = _load(conversion_id)
    _, vs = _find_visual(spec, req.page, req.visual)
    text = _check_sql(req.sql)
    base_sql, _ = _generated_sql(engine, vs)
    record = _sqlo.save_override(
        _conversion_root(conversion_id), req.page, req.visual, text, base_sql
    )
    _result_cache.clear()
    return {"override": record}


@router.delete("/sql-overrides/{page}/{visual}")
def delete_sql_override(conversion_id: str, page: str, visual: str) -> dict:
    if not _sqlo.delete_override(_conversion_root(conversion_id), page, visual):
        raise HTTPException(404, "no edited SQL for this pane")
    _result_cache.clear()
    return {"deleted": True}


# ---------------------------------------------------------------- No SQL generated

_NEEDS_TIER2 = re.compile(r"measure \[(.+?)\] needs tier-2")


@router.get("/no-sql-panes")
def list_no_sql_panes(conversion_id: str) -> dict:
    spec, _, _ = _load(conversion_id)
    overrides = _sqlo.load_overrides(_conversion_root(conversion_id))
    panes = []
    for p in spec.pages:
        for vs in p.visuals:
            if vs.data_status != "untranslated":
                continue
            m = _NEEDS_TIER2.search(vs.unsupported_reason or "")
            saved = overrides.get(_sqlo.key_for(p.name, vs.name))
            panes.append(
                {
                    "page": p.name,
                    "page_name": p.display_name,
                    "visual": vs.name,
                    "pane": _pane_label(vs),
                    "visual_type": vs.visual_type,
                    "measure": m.group(1) if m else None,
                    "reason": vs.unsupported_reason,
                    "expected_columns": _expected_columns(vs),
                    "manual_sql": saved is not None,
                    "saved_at": saved.get("saved_at") if saved else None,
                }
            )
    return {"panes": panes}


def _measure_info(engine: SemanticEngine, name: str, tier2: dict[str, str]) -> dict | None:
    found = engine.model.find_measure(name)
    if found is None:
        return None
    table, measure = found
    rewrite = engine.model.dax_rewrites.get(measure.name)
    error = None
    translated = measure.name in tier2
    try:
        engine.compiler.compile_measure(measure.name)
        translated = True
    except Exception as e:  # noqa: BLE001 - DaxUnsupported and friends
        error = str(e)
    return {
        "name": measure.name,
        "table": table.name,
        "dax": measure.expression,
        "rewrite": rewrite.expression if rewrite else None,
        "error": None if translated else error,
        "translated": translated,
    }


@router.get("/no-sql-panes/{page}/{visual}")
def get_no_sql_pane(conversion_id: str, page: str, visual: str) -> dict:
    from app.agents.tier2 import dependency_closure
    from app.dax.visual_query import visual_dax_query

    spec, _, engine = _load(conversion_id)
    _, vs = _find_visual(spec, page, visual)
    if vs.data_status != "untranslated":
        raise HTTPException(422, "this pane has generated SQL")
    tier2 = _tier2_sql(conversion_id)
    dax_query, dax_error = None, None
    if vs.draft_query is not None:
        try:
            dax_query = visual_dax_query(vs.draft_query, vs.title)
        except Exception as e:  # noqa: BLE001
            dax_error = str(e)
    measures = []
    for m in vs.draft_query.measures if vs.draft_query else []:
        if not m.name:
            continue
        info = _measure_info(engine, m.name, tier2)
        if info is None or info["translated"]:
            continue
        deps = []
        for dep in dependency_closure(engine.model, info["name"]):
            d = _measure_info(engine, dep, tier2)
            if d is not None:
                deps.append(
                    {k: d[k] for k in ("name", "table", "dax", "rewrite", "translated")}
                )
        measures.append({k: info[k] for k in ("name", "table", "dax", "rewrite", "error")}
                        | {"dependencies": deps})
    return {
        "page": page,
        "visual": visual,
        "pane": _pane_label(vs),
        "dax_query": dax_query,
        "dax_query_error": dax_error,
        "measures": measures,
    }


# ---------------------------------------------------------------- Re-check this pane

_run_lock = threading.Lock()


class RecheckRequest(BaseModel):
    page: str
    visual: str
    connection_id: str


def _replace_visual_score(fidelity: dict, score: dict) -> str | None:
    """Replace (or append) one pane's entry in a serialized FidelityReport; returns the previous
    status."""
    page = next((p for p in fidelity.get("pages", []) if p["page"] == score["page"]), None)
    if page is None:
        page = {"page": score["page"], "display_name": score["page"], "visuals": []}
        fidelity.setdefault("pages", []).append(page)
    for i, old in enumerate(page["visuals"]):
        if old["visual"] == score["visual"]:
            prev = _status_of(old)
            page["visuals"][i] = score
            return prev
    page["visuals"].append(score)
    return None


def _status_of(visual: dict) -> str:
    statuses = {c["status"] for c in visual.get("checks", [])}
    if "failed" in statuses:
        return "failed"
    if statuses == {"skipped"}:
        return "skipped"
    return "passed"


@router.post("/recheck")
def recheck_pane(
    conversion_id: str,
    req: RecheckRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> dict:
    from app.validation.harness import FidelityReport, ValidationHarness, with_default_filters

    root = _conversion_root(conversion_id)
    run_file = root / "conversion_run.json"
    if not run_file.is_file():
        raise HTTPException(404, "no conversion run yet; POST /convert first")
    spec, _, engine = _load(conversion_id)
    defaults = [
        c
        for p in spec.pages
        if p.name == req.page
        for c in default_filter_clauses(spec, p)
    ]
    spec = with_default_filters(spec)
    page, vs = _find_visual(spec, req.page, req.visual)
    override = _sqlo.load_overrides(root).get(_sqlo.key_for(req.page, req.visual))
    main_sql: str | None = None
    render_error: str | None = None
    if override:
        try:
            main_sql, _ = _sqlo.render(override["sql"], defaults, engine)
        except Exception as e:  # noqa: BLE001
            render_error = f"edited SQL: {e}"
    conn = _audited(
        _connect(store, req.connection_id, conversion_id),
        store,
        req.connection_id,
        conversion_id,
        "validation",
        None,
        {"recheck": True, "sql_override": bool(override)},
    )
    try:
        harness = ValidationHarness(engine, conn.cursor())
        if render_error:
            from app.validation.harness import Check, CheckStatus, VisualScore

            score = VisualScore(
                visual=vs.name,
                page=page.name,
                visual_type=vs.visual_type,
                title=vs.title,
                checks=[Check(name="execute", status=CheckStatus.FAILED, detail=render_error)],
                sql_override=True,
            )
        else:
            score = harness.validate_visual(page.name, vs, main_sql=main_sql)
    finally:
        conn.close()
    score.rechecked_at = time.time()
    payload = score.model_dump(mode="json")
    with _run_lock:
        run = json.loads(run_file.read_text(encoding="utf-8"))
        fidelity = run.get("fidelity") or {
            "report_name": spec.report_name, "pages": [], "measure_tiers": spec.measure_tiers
        }
        previous_status = _replace_visual_score(fidelity, payload)
        previous_summary = dict(run.get("summary") or {})
        merged = {**previous_summary, **FidelityReport.model_validate(fidelity).summary()}
        run["fidelity"], run["summary"] = fidelity, merged
        tmp = run_file.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(run, indent=2, default=str), encoding="utf-8")
        os.replace(tmp, run_file)
    return {
        "visual": {**payload, "status": score.status.value, "score": score.score},
        "previous_status": previous_status,
        "summary": {
            "overall_score": merged.get("overall_score"),
            "previous_overall_score": previous_summary.get("overall_score"),
            "visuals_passed": merged.get("visuals_passed"),
            "visuals_total": merged.get("visuals_total"),
        },
        "used_edited_sql": bool(override) and render_error is None,
    }


# ---------------------------------------------------------------- Fix measure (measure SQL)

_measure_checks: dict[tuple[str, str], tuple[str, list[str]]] = {}
_MEASURE_PANE_RUNS = 12


class MeasureSqlRequest(BaseModel):
    measure: str
    sql: str


class MeasureSqlTestRequest(MeasureSqlRequest):
    connection_id: str


def _measure_or_404(bundle, name: str):
    found = bundle.model.find_measure(name)
    if found is None:
        raise HTTPException(404, f"unknown measure [{name}]")
    return found


def _value_kind(value) -> str | None:
    """None when a measure's SQL result is acceptable (number or text), else its kind."""
    import datetime as _dt
    import decimal

    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, (int, float, decimal.Decimal, str)):
        return None
    if isinstance(value, (_dt.date, _dt.datetime, _dt.time)):
        return "date"
    return type(value).__name__


def _impact(conversion_id: str, bundle, measure: str, sql: str, spec_before: DashboardSpec):
    """Compile a candidate bundle carrying the fix: which panes/measures it newly translates."""
    from app.ir.model import ManualMeasureSql

    candidate = bundle.model_copy(deep=True)
    found = candidate.model.find_measure(measure)
    candidate.model.measure_sql[found[1].name] = ManualMeasureSql(
        sql=sql, original=found[1].expression
    )
    root = _conversion_root(conversion_id)
    spec_after, bindings = compile_dashboard(candidate, tier2_sql=_tier2_sql(conversion_id))
    overrides = _sqlo.load_overrides(root)
    for p in spec_after.pages:
        for vs in p.visuals:
            ov = overrides.get(_sqlo.key_for(p.name, vs.name))
            if ov and vs.data_status == "untranslated":
                vs.manual_sql = ov["sql"]
    tiers_before = spec_before.measure_tiers
    newly = sorted(
        n for n, t in spec_after.measure_tiers.items() if t >= 0 and tiers_before.get(n, 0) < 0
    )
    still_measures = sorted(n for n, t in spec_after.measure_tiers.items() if t < 0)
    after = {(p.name, v.name): v for p in spec_after.pages for v in p.visuals}
    fixed, still, n_a = [], [], []
    for p in spec_before.pages:
        for vs_b in p.visuals:
            if vs_b.data_status != "untranslated":
                continue
            vs_a = after.get((p.name, vs_b.name))
            entry = {"page": p.name, "visual": vs_b.name, "pane": _pane_label(vs_b)}
            if vs_a is None or vs_a.query is None or not vs_a.supported:
                still.append({**entry, "reason": vs_a.unsupported_reason if vs_a else None})
            elif vs_a.query.dimensions:
                n_a.append({**entry, "reason": "groups by rows; hand-written SQL gives one value"})
            else:
                fixed.append(entry)
    return candidate, spec_after, bindings, {
        "newly_translated": newly,
        "still_untranslated_measures": still_measures,
        "fixed_panes": fixed,
        "still_untranslated": still,
        "not_applicable": n_a,
    }


@router.post("/measure-sql/test")
def test_measure_sql(
    conversion_id: str,
    req: MeasureSqlTestRequest,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> dict:
    svc = get_ingest_service()
    try:
        bundle = svc.load_bundle(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e
    _, measure = _measure_or_404(bundle, req.measure)
    text = _check_sql(req.sql)
    spec_before, _, _ = _load(conversion_id)
    candidate, spec_after, bindings, impact = _impact(
        conversion_id, bundle, measure.name, text, spec_before
    )
    engine = SemanticEngine(candidate.model, bindings, tier2_sql=_tier2_sql(conversion_id))
    out: dict = {
        "ok": False,
        "measure": measure.name,
        "measure_run": {"sql": None, "value": None, "query_id": None, "error": None},
        "pane_runs": [],
        "panes_not_run": 0,
        "null_comparison_warnings": _sqlo.null_comparison_warnings(text),
        **impact,
    }
    try:
        rendered, _ = _sqlo.render(text, [], engine)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(422, f"could not render the SQL: {e}") from e
    out["measure_run"]["sql"] = rendered
    conn = _audited(
        _connect(store, req.connection_id, conversion_id),
        store,
        req.connection_id,
        conversion_id,
        "setup",
        f"measure_sql_test:{measure.name}",
    )
    checked: list[str] = []
    try:
        run = out["measure_run"]
        try:
            cur = conn.cursor()
            cur.execute(rendered)
            rows = cur.fetchall()
            width = len(cur.description or [])
            run["query_id"] = getattr(cur, "sfqid", None)
            if len(rows) != 1 or width != 1:
                run["error"] = (
                    "must return exactly one row with one column "
                    f"(got {len(rows)} row(s), {width} column(s))"
                )
            else:
                value = rows[0][0]
                kind = _value_kind(value)
                if kind:
                    run["error"] = f"must return a number or text (got {kind})"
                else:
                    run["value"] = value if isinstance(value, (int, float, str)) else float(value)
                    checked.append("returns exactly one row with one value")
        except Exception as e:  # noqa: BLE001
            run["error"] = str(e)
        if run["error"] is None:
            after = {(p.name, v.name): v for p in spec_after.pages for v in p.visuals}
            panes = impact["fixed_panes"]
            for pane in panes[:_MEASURE_PANE_RUNS]:
                vs = after[(pane["page"], pane["visual"])]
                entry = {**pane, "rows": None, "query_id": None, "error": None}
                try:
                    sql, _ = engine.build_sql(
                        vs.query, sql_context=f"visual:{pane['page']}/{pane['visual']}:main"
                    )
                    cur = conn.cursor()
                    cur.execute(sql)
                    entry["rows"] = len(cur.fetchall())
                    entry["query_id"] = getattr(cur, "sfqid", None)
                except Exception as e:  # noqa: BLE001
                    entry["error"] = str(e)
                out["pane_runs"].append(entry)
            out["panes_not_run"] = max(len(panes) - _MEASURE_PANE_RUNS, 0)
            if out["pane_runs"] and all(r["error"] is None for r in out["pane_runs"]):
                checked.append(f"{len(out['pane_runs'])} pane(s) ran on Snowflake")
            out["ok"] = all(r["error"] is None for r in out["pane_runs"])
    finally:
        conn.close()
    key = (conversion_id, measure.name)
    if out["ok"]:
        _measure_checks[key] = (text, checked)
    else:
        _measure_checks.pop(key, None)
    return out


@router.put("/measure-sql")
def save_measure_sql(conversion_id: str, req: MeasureSqlRequest) -> dict:
    from app.ir.model import ManualMeasureSql

    svc = get_ingest_service()
    try:
        bundle = svc.load_bundle(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e
    _, measure = _measure_or_404(bundle, req.measure)
    text = _check_sql(req.sql)
    remembered = _measure_checks.get((conversion_id, measure.name))
    if remembered is None or remembered[0] != text:
        raise HTTPException(
            409, "run 'Check on Snowflake' on this exact SQL before saving"
        )
    bundle.model.measure_sql[measure.name] = ManualMeasureSql(
        sql=text, original=measure.expression, saved_at=time.time(), checked=remembered[1]
    )
    svc.save_bundle(conversion_id, bundle)
    _measure_checks.pop((conversion_id, measure.name), None)
    _result_cache.clear()
    return {"fix": bundle.model.measure_sql[measure.name].model_dump()}


@router.get("/measure-sql")
def list_measure_sql(conversion_id: str) -> dict:
    svc = get_ingest_service()
    try:
        bundle = svc.load_bundle(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e
    return {"fixes": {k: v.model_dump() for k, v in sorted(bundle.model.measure_sql.items())}}


@router.delete("/measure-sql/{measure}")
def revert_measure_sql(conversion_id: str, measure: str) -> dict:
    svc = get_ingest_service()
    try:
        bundle = svc.load_bundle(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "conversion not found") from e
    if measure not in bundle.model.measure_sql:
        raise HTTPException(404, f"no hand-written SQL for measure '{measure}'")
    del bundle.model.measure_sql[measure]
    svc.save_bundle(conversion_id, bundle)
    _result_cache.clear()
    return {"reverted": measure, "remaining": sorted(bundle.model.measure_sql)}


# ---------------------------------------------------------------- DAX Audit


def _audit_with_current_model(conversion_id: str, records: list[dict]) -> tuple[list[dict], dict]:
    """The compilation log overlaid with the current model: hand-written SQL shows as
    `manual_sql`, and broken rows that compile now are shown working."""
    from app.services.compilation_logger import summarize_records

    svc = get_ingest_service()
    try:
        bundle = svc.load_bundle(conversion_id)
    except (IngestError, ValueError):
        return records, summarize_records(records)
    _, _, engine = _load(conversion_id, svc)
    out = []
    for rec in records:
        rec = dict(rec)
        name = rec.get("measure_name")
        if name in bundle.model.measure_sql:
            rec.update(compiler_type="manual_sql", compilation_status="success",
                       compilation_error=None, overall_status="working")  # fmt: skip
            rec["generated_sql"] = bundle.model.measure_sql[name].sql
        elif rec.get("overall_status") == "broken":
            try:
                compiled = engine.compiler.compile_measure(name)
            except Exception:  # noqa: BLE001, S110 - still broken
                pass
            else:
                kind = f"tier{compiled.tier}"
                rec.update(compilation_status="success", compilation_error=None,
                           compiler_type=kind, overall_status="working")  # fmt: skip
        out.append(rec)
    return out, summarize_records(out)


def _compilation_log_path(conversion_id: str) -> Path:
    path = (
        _conversion_root(conversion_id)
        / "compilation_logs"
        / f"{conversion_id}_compilation.jsonl"
    )
    if not path.is_file():
        raise HTTPException(404, "no compilation logs found; run the conversion first")
    return path


@router.get("/compilation-audit")
def get_compilation_audit(conversion_id: str) -> dict:
    from app.services.compilation_logger import load_compilation_log

    records, _ = load_compilation_log(_compilation_log_path(conversion_id))
    records, summary = _audit_with_current_model(conversion_id, records)
    return {"records": records, "summary": summary}


@router.get("/compilation-audit/export")
def export_compilation_audit(
    conversion_id: str, format: Literal["xlsx", "json"] = "xlsx"
) -> Response:
    from app.services.compilation_logger import (
        build_audit_json,
        build_audit_xlsx,
        load_compilation_log,
    )

    records, _ = load_compilation_log(_compilation_log_path(conversion_id))
    records, summary = _audit_with_current_model(conversion_id, records)
    if format == "json":
        return Response(
            json.dumps(build_audit_json(records, summary, conversion_id), indent=2, default=str),
            media_type="application/json",
            headers={
                "Content-Disposition": f'attachment; filename="{conversion_id}_dax_audit.json"'
            },
        )
    return Response(
        build_audit_xlsx(records, summary, conversion_id),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{conversion_id}_dax_audit.xlsx"'},
    )
