export interface SourceDatabaseInfo {
  kind: 'snowflake' | 'sqlserver' | 'postgres' | 'mysql' | 'oracle'
  needs_migration: boolean
  tables: { table: string; kind: string; schema: string | null; object: string | null; database: string | null }[]
}

export interface ConversionSummary {
  id: string
  report: string
  model: {
    tables: number
    relationships: number
    measures: number
    roles: number
  }
  pages: { name: string; display_name: string; visuals: number }[]
  visual_types: Record<string, number>
  source_database?: SourceDatabaseInfo
  warnings: string[]
}

export type SourceKind = 'sqlserver' | 'postgres' | 'mysql' | 'oracle'

export interface SourceConnectionProfile {
  id: string
  name: string
  kind: SourceKind
  host: string
  port: number | null
  database: string
  user: string
}

export interface NewSourceConnection {
  name: string
  kind: SourceKind
  host: string
  port?: number | null
  database: string
  user: string
  password: string
}

export type AuthMethod =
  | 'password'
  | 'key_pair'
  | 'oauth_client_credentials'
  | 'pat'
  | 'external_browser'

export interface ConnectionProfile {
  id: string
  name: string
  account: string
  user: string
  auth_method: AuthMethod
  role?: string | null
  warehouse: string
  database?: string | null
  schema_name?: string | null
}

export interface SourceHints {
  server?: string | null
  warehouse?: string | null
  database?: string | null
  schema?: string | null
  binding_settings?: {
    database_override?: string | null
    schema_override?: string | null
    case_checked_at?: number | null
  }
}

export interface PreflightTarget {
  database: string
  schema_name: string
  tables: string[]
  found: string[]
  case_mismatch: string[]
  error?: string | null
  listed: number
  unreachable?: boolean
}

export interface IdentifierCaseSummary {
  checked: number
  exact: number
  corrected: string[]
  ambiguous: string[]
  missing: string[]
  errors: string[]
}

export interface PreflightResult {
  role?: string | null
  warehouse?: string | null
  session_error?: string | null
  targets: PreflightTarget[]
  bound: number
  accessible: number
  blocking: boolean
  message: string
  case: IdentifierCaseSummary
  case_saved: boolean
}

export interface DaxRewrite {
  expression: string
  original: string
  source: string
  gates: string[]
  created_at: number
  provider?: string | null
}

export interface LlmProviders {
  default: 'cortex' | 'horizon'
  cortex: { model: string }
  horizon: { configured: boolean }
}

export interface ConnectionUpdate {
  name?: string
  role?: string | null
  warehouse?: string
  database?: string | null
  schema?: string | null
}

export interface ConnectionTestResult {
  ok: boolean
  mfa_required?: boolean
  latency_ms?: number
  version?: string
  role?: string
  warehouse?: string
  database?: string
  error?: string
}

export interface ConnectionSessionStatus {
  authenticated: boolean
  sso_url?: string | null
  settings_error?: string | null
  mfa_required?: boolean
  mfa_enforced?: boolean
  verified?: boolean
  checked_at?: number
  expired?: boolean
  reason?: string
}

export interface DashboardPublication {
  id: string
  conversion_id: string
  connection_id: string
  created_at: number
  expires_at: number
  revoked_at?: number | null
  token_fingerprint: string
}

export interface IssuedDashboardToken {
  publication: DashboardPublication
  token: string
}

export interface NewConnection {
  name: string
  account: string
  user: string
  auth_method: AuthMethod
  database: string
  schema: string
  role?: string
  warehouse?: string
  password?: string
  private_key_pem?: string
  private_key_passphrase?: string
  oauth_client_id?: string
  oauth_client_secret?: string
  oauth_token_url?: string
  pat_token?: string
}

// ---- phase 08: audits and editing

export type QueryStatus = 'ok' | 'empty' | 'error' | 'plan_error' | 'cached'
export type QueryKind =
  | 'dashboard'
  | 'totals'
  | 'drill'
  | 'validation'
  | 'probe'
  | 'ai_check'
  | 'ai_llm'
  | 'setup'

export interface QueryFilter {
  table: string
  column: string
  op: string
  values: (string | number | boolean | null)[]
  source?: string | null
}

export interface QueryRecord {
  kind: QueryKind
  page?: string | null
  page_name?: string | null
  visual?: string | null
  pane: string
  check?: string | null
  attempt: 'primary' | 'fallback' | 'plan' | string
  status: QueryStatus
  source: 'editor' | 'published' | string
  elapsed_ms?: number | null
  row_count?: number | null
  error?: string | null
  query_id?: string | null
  sql?: string | null
  compat_sql?: string | null
  totals_sql?: string | null
  warehouse?: string | null
  role?: string | null
  connection_name?: string | null
  tables?: { model_table: string; physical: string }[]
  visual_filters?: QueryFilter[]
  request_filters?: QueryFilter[]
  execution_path?: string | null
  fallback_reason?: string | null
  sql_override?: boolean
  unapplied_filters?: string[]
  drill?: { direction: string; level: string; level_index: number } | null
  sql_logged?: boolean
  legacy?: boolean
  ts?: number
  measures?: string[]
}

export interface QueryAuditSummary {
  total: number
  panes: number
  ok: number
  empty: number
  error: number
  plan_error: number
  cached: number
  slowest_ms: number | null
  slowest_pane: string | null
  avg_ms: number | null
  warehouses: string[]
  roles: string[]
  sql_logging: boolean | null
  events_read: number
  events_cap: number
  kinds: Record<string, number>
}

export interface QueryAudit {
  records: QueryRecord[]
  summary: QueryAuditSummary
}

export interface SqlEditorInfo {
  page: string
  visual: string
  pane: string
  base_sql: string | null
  base_error: string | null
  expected_columns: string[]
  filter_tables: { table: string; alias: string }[]
  override: { sql: string; base_sql: string | null; saved_at: number } | null
}

export interface SqlTestResult {
  rendered_sql: string
  unapplied_filter_tables: string[]
  has_filters_placeholder: boolean
  null_comparison_warnings: string[]
  expected_columns: string[]
  columns: string[]
  rows: unknown[][]
  row_count: number
  elapsed_ms: number
  query_id: string | null
  error: string | null
  missing_columns: string[]
}

export interface NoSqlPane {
  page: string
  page_name: string
  visual: string
  pane: string
  visual_type: string
  measure: string | null
  reason: string | null
  expected_columns: string[]
  manual_sql: boolean
  saved_at: number | null
}

export interface NoSqlPaneDetail {
  page: string
  visual: string
  pane: string
  dax_query: string | null
  dax_query_error: string | null
  measures: {
    name: string
    table: string
    dax: string
    rewrite: string | null
    error: string | null
    dependencies: {
      name: string
      table: string
      dax: string
      rewrite: string | null
      translated: boolean
    }[]
  }[]
}

export interface RecheckCheck {
  name: string
  status: 'passed' | 'failed' | 'skipped'
  detail: string
}

export interface RecheckResult {
  visual: {
    visual: string
    page: string
    status: 'passed' | 'failed' | 'skipped'
    score: number
    checks: RecheckCheck[]
    rechecked_at: number | null
    sql_override: boolean
  }
  previous_status: string | null
  summary: {
    overall_score: number | null
    previous_overall_score: number | null
    visuals_passed: number | null
    visuals_total: number | null
  }
  used_edited_sql: boolean
}

export interface MeasureSqlResult {
  ok: boolean
  measure: string
  measure_run: { sql: string | null; value: string | number | null; query_id: string | null; error: string | null }
  pane_runs: { page: string; visual: string; pane: string; rows: number | null; query_id: string | null; error: string | null }[]
  panes_not_run: number
  null_comparison_warnings: string[]
  newly_translated: string[]
  still_untranslated_measures: string[]
  fixed_panes: { page: string; visual: string; pane: string }[]
  still_untranslated: { page: string; visual: string; pane: string; reason: string | null }[]
  not_applicable: { page: string; visual: string; pane: string; reason?: string }[]
}

export interface CompilationRecord {
  measure_name: string
  model_table: string
  dax_expression: string
  compiler_type: 'tier0' | 'tier1' | 'tier2' | 'parked' | 'manual_sql' | string
  compilation_status: 'success' | 'failed'
  compilation_error?: string | null
  overall_status: 'working' | 'degraded' | 'broken'
  dax_complexity_score?: number | null
  sql_complexity?: number | null
  generated_sql?: string | null
  sql_error?: string | null
  validation_attempted?: boolean
  validation_passed?: boolean | null
  validation_error?: string | null
  dax_leaves?: { alias: string; sql: string; tables: string[] }[]
}

export interface CompilationAuditData {
  records: CompilationRecord[]
  summary: {
    total: number
    working: number
    degraded: number
    broken: number
    percentage_working: number
    by_compiler_type: Record<string, number>
    avg_dax_complexity: number
    avg_sql_complexity: number
  }
}
