import { useMutation, useQuery } from '@tanstack/react-query'
import { ArrowRight, GitFork, Layers, Sigma, Table2 } from 'lucide-react'
import { api } from '../api/client'
import type { IdentifierCaseSummary } from '../api/types'
import { useWizard } from '../store/wizard'

const MAX_CASE_LINES = 50

function CaseList({ title, items }: { title: string; items: string[] }) {
  if (items.length === 0) return null
  return (
    <div className="mt-1">
      <div className="font-semibold">{title}</div>
      <ul className="ml-4 list-disc">
        {items.slice(0, MAX_CASE_LINES).map((line) => (
          <li key={line}>{line}</li>
        ))}
        {items.length > MAX_CASE_LINES && <li>…and {items.length - MAX_CASE_LINES} more</li>}
      </ul>
    </div>
  )
}

function CaseCheckDetails({ summary }: { summary: IdentifierCaseSummary }) {
  return (
    <div data-testid="case-check" className="mt-2 text-xs">
      <div className="font-semibold">
        Letter case: {summary.exact}/{summary.checked} names match Snowflake exactly
      </div>
      <CaseList
        title="Corrected to Snowflake's spelling (saved with this conversion)"
        items={summary.corrected}
      />
      <CaseList title="Ambiguous (not changed)" items={summary.ambiguous} />
      <CaseList title="Not found" items={summary.missing} />
      <CaseList title="Could not check" items={summary.errors} />
    </div>
  )
}

function SnowflakeTargetCard() {
  const conversionId = useWizard((s) => s.conversionId)
  const connectionId = useWizard((s) => s.connectionId)
  const bindingTarget = useWizard((s) => s.bindingTarget)
  const setBindingTarget = useWizard((s) => s.setBindingTarget)
  const hints = useQuery({
    queryKey: ['source-hints', conversionId],
    queryFn: () => api.sourceHints(conversionId!),
    enabled: !!conversionId,
    retry: false,
  })
  const saved = hints.data?.binding_settings
  const database = bindingTarget?.database ?? saved?.database_override ?? ''
  const schema = bindingTarget?.schema ?? saved?.schema_override ?? ''
  const h = hints.data
  const check = useMutation({
    mutationFn: () =>
      api.preflight(conversionId!, {
        connection_id: connectionId!,
        database_override: database.trim() || null,
        schema_override: schema.trim() || null,
      }),
  })
  const result = check.data
  const warn = !!result && (result.blocking || result.accessible < result.bound)
  return (
    <div data-testid="snowflake-target" className="card mt-6 p-4">
      <h3 className="text-sm font-bold text-surface-900">Snowflake target</h3>
      <p className="mt-1 text-xs text-surface-600">
        The report&apos;s Power Query reads {h?.database ?? '…'}.{h?.schema ?? '…'}
        {h?.warehouse ? ` (warehouse ${h.warehouse})` : ''}. Leave the overrides empty to keep that,
        or point every table at another database/schema.
      </p>
      <div className="mt-3 flex flex-wrap items-end gap-3">
        <label className="flex flex-col gap-1 text-xs font-semibold text-surface-700">
          Database override
          <input
            className="input !w-48"
            placeholder={h?.database ?? ''}
            value={database}
            onChange={(e) => setBindingTarget({ database: e.target.value, schema })}
          />
        </label>
        <label className="flex flex-col gap-1 text-xs font-semibold text-surface-700">
          Schema override
          <input
            className="input !w-48"
            placeholder={h?.schema ?? ''}
            value={schema}
            onChange={(e) => setBindingTarget({ database, schema: e.target.value })}
          />
        </label>
        <button
          type="button"
          className="btn-secondary"
          disabled={!connectionId || check.isPending}
          onClick={() => check.mutate()}
        >
          {check.isPending ? 'Checking…' : 'Check access'}
        </button>
      </div>
      {check.isError && (
        <p role="alert" className="mt-2 text-xs text-brand-red">
          {check.error.message}
        </p>
      )}
      {result && (
        <div
          role="status"
          className={`mt-3 rounded-lg border p-3 text-xs ${
            warn
              ? 'border-brand-amber/30 bg-brand-amber/5'
              : 'border-emerald-300 bg-emerald-50 text-emerald-900'
          }`}
        >
          <div className="font-semibold">{result.message}</div>
          <ul className="mt-1 ml-4 list-disc">
            {result.targets.map((t) => (
              <li key={`${t.database}.${t.schema_name}`}>
                {t.database}.{t.schema_name}:{' '}
                {t.error ?? `${t.found.length}/${t.tables.length} tables found`}
                {t.case_mismatch.length > 0 && ` · case differs: ${t.case_mismatch.join(', ')}`}
              </li>
            ))}
          </ul>
          <CaseCheckDetails summary={result.case} />
        </div>
      )}
    </div>
  )
}

function TranslationAiCard() {
  const llmProvider = useWizard((s) => s.llmProvider)
  const setLlmProvider = useWizard((s) => s.setLlmProvider)
  const providers = useQuery({ queryKey: ['llm-providers'], queryFn: api.llmProviders })
  const info = providers.data
  const value = llmProvider ?? info?.default ?? 'cortex'
  return (
    <div data-testid="translation-ai" className="card mt-6 p-4">
      <label htmlFor="llmProvider" className="text-sm font-bold text-surface-900">
        Translation AI
      </label>
      <select
        id="llmProvider"
        className="input mt-2 max-w-xs"
        value={value}
        onChange={(e) => setLlmProvider(e.target.value as 'cortex' | 'horizon')}
      >
        <option value="cortex">Snowflake Cortex ({info?.cortex.model ?? '…'})</option>
        <option value="horizon">
          Horizon{info && !info.horizon.configured ? ' (not configured)' : ''}
        </option>
      </select>
      <p className="mt-2 text-xs text-surface-600">
        {value === 'cortex'
          ? 'Runs SNOWFLAKE.CORTEX.COMPLETE on the selected Snowflake connection; its role needs the SNOWFLAKE.CORTEX_USER database role.'
          : 'Uses the Horizon LLM gateway credentials configured on the server.'}{' '}
        Switching provider re-translates measures an earlier run translated with the other one.
      </p>
    </div>
  )
}

export function AnalyzeStep() {
  const conversionId = useWizard((s) => s.conversionId)
  const setStep = useWizard((s) => s.setStep)
  const summary = useQuery({
    queryKey: ['conversion', conversionId],
    queryFn: () => api.getConversion(conversionId!),
    enabled: !!conversionId,
  })

  if (!conversionId) return <p className="text-surface-500">No conversion selected.</p>
  if (summary.isLoading) return <p className="text-surface-500">Analyzing…</p>
  if (summary.isError)
    return (
      <div role="alert" className="rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
        {summary.error.message}
      </div>
    )

  const s = summary.data!
  const stats = [
    { label: 'Tables', value: s.model.tables, icon: Table2 },
    { label: 'Relationships', value: s.model.relationships, icon: GitFork },
    { label: 'Measures', value: s.model.measures, icon: Sigma },
    { label: 'Pages', value: s.pages.length, icon: Layers },
  ]

  return (
    <section>
      <div className="mb-6 overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div className="kicker mb-1">Step 3 · Coverage preview</div>
        <h2 className="text-xl font-bold">{s.report}</h2>
        <p className="mt-1 text-sm text-surface-600">
          What the engine found in your report. Conversion and validation run next.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map(({ label, value, icon: Icon }) => (
          <div key={label} className="card text-center">
            <Icon className="mx-auto mb-2 h-5 w-5 text-brand-dark" strokeWidth={1.8} />
            <div className="text-3xl font-bold">{value}</div>
            <div className="text-[11px] font-semibold tracking-wider text-surface-500 uppercase">
              {label}
            </div>
          </div>
        ))}
      </div>

      {s.source_database?.needs_migration && (
        <div
          data-testid="analyze-migration-plan"
          className="mt-6 rounded-xl border border-brand-blue/20 bg-brand-blue/5 p-4 text-sm text-surface-700"
        >
          <strong className="text-brand-blue">Source migration planned</strong>
          <p className="mt-1 text-xs text-surface-600">
            This report reads {s.source_database.kind === 'sqlserver' ? 'SQL Server' : s.source_database.kind}
            {s.source_database.tables[0]?.database ? ` (${s.source_database.tables[0].database})` : ''}.
            During conversion the {s.source_database.tables.length} base tables below are migrated
            into Snowflake — schema, data, and row-count verification — then every query is
            validated against the migrated copy.
          </p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {s.source_database.tables.map((t) => (
              <span key={t.table} className="badge bg-white text-surface-600">
                {t.schema}.{t.object}
              </span>
            ))}
          </div>
        </div>
      )}

      <SnowflakeTargetCard />

      <TranslationAiCard />

      <h3 className="mt-8 mb-3 text-sm font-bold text-surface-900">Visuals by type</h3>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {Object.entries(s.visual_types).map(([type, count]) => (
          <div
            key={type}
            className="flex items-center justify-between rounded-lg border border-black/[0.06] bg-surface-50 px-3 py-2 text-sm"
          >
            <span className="truncate text-surface-700">{type}</span>
            <span className="badge-green ml-2">{count}</span>
          </div>
        ))}
      </div>

      {s.warnings.length > 0 && (
        <div className="mt-6 rounded-xl border border-brand-amber/20 bg-brand-amber/5 p-4 text-sm text-surface-700">
          <strong className="text-brand-amber">Warning: partial readiness</strong>
          <p className="mt-1 text-xs text-surface-600">
            Conversion can continue, but these findings may affect Migration Health and can require remediation in Review.
          </p>
          <ul className="mt-1 ml-4 list-disc">
            {s.warnings.map((w) => (
              <li key={w}>{w}</li>
            ))}
          </ul>
        </div>
      )}

      <button onClick={() => setStep('convert')} className="btn-primary mt-8 inline-flex items-center gap-2">
        Convert &amp; validate
        <ArrowRight className="h-4 w-4" strokeWidth={2} />
      </button>
    </section>
  )
}
