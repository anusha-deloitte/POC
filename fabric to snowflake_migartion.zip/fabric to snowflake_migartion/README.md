# Fabric/Databricks Notebook → Snowflake Migration Tool

A Flask web application that migrates the `healthcare_pipeline_standalone.ipynb`
Databricks/Fabric PySpark notebook into a Snowflake medallion architecture
(**Raw → Silver → Gold**) using `TRANSIENT` tables, with human-in-the-loop
approval at every SQL generation step.

## What it does

1. **Upload** the source `.ipynb` notebook — the app parses the BRONZE-layer
   cells to learn the expected raw table names and column lists (`MEMBER`,
   `PROVIDER`, `PRODUCT`, `PHARMACY`, `CLAIM`).
2. **Connect** to a Snowflake account/warehouse/database.
3. **Validate** that those raw tables and columns already exist in
   `RAW_SCHEMA` (you must load the CSVs into Snowflake yourself first — this
   tool migrates transformation logic, not raw data).
4. **Generate** the 3 Silver-layer `CREATE OR REPLACE TRANSIENT TABLE`
   statements, review/approve/reject them, then execute.
5. **Generate** the 4 Gold-layer statements (built on top of Silver), review/
   approve/reject, then execute.
6. **Generate a migration report** (summary, lineage diagram, rollback
   script, data-quality checklist) downloadable as `.txt` / `.sql`.

## Project layout

```
app.py                  Flask backend (9 API endpoints + page route)
templates/index.html     5-tab single-page UI (Dashboard/Connection/Validator/SQL Review/Results)
static/css/style.css     Pure CSS, purple/dark theme, responsive
static/js/app.js         Vanilla JS driving the workflow, no frameworks
uploads/                 Uploaded .ipynb files land here
docs/                    User guide, troubleshooting, SQL pattern reference
requirements.txt
```

## Setup

```bash
pip install -r requirements.txt
python app.py
```

Then open http://localhost:5000

## Before you start

The five raw tables (`MEMBER`, `PROVIDER`, `PRODUCT`, `PHARMACY`, `CLAIM`)
must already exist with data in `<DATABASE>.RAW_SCHEMA` in your Snowflake
account — Step 3 (Validator) only checks/compares, it does not load data.

## Architecture produced in Snowflake

```
RAW_SCHEMA                         SILVER_SCHEMA                          GOLD_SCHEMA
├── MEMBER                         ├── vw_silver_member_claims            ├── vw_gold_member_dashboard
├── PROVIDER          ─────────►   ├── vw_silver_network_performance ───► ├── vw_gold_claims_timeline
├── PRODUCT                        └── vw_silver_provider_performance     ├── vw_gold_network_summary
├── PHARMACY                                                              └── vw_gold_provider_top (top 50)
└── CLAIM
```

All Silver/Gold objects are created as `TRANSIENT` tables (24-hour Snowflake
Time Travel, no Fail-safe) so they auto-cleanup and cost less to maintain
than permanent tables.

## Notes & limitations

- Session state (uploaded notebook metadata, Snowflake credentials, approval
  flags, execution results) is held **in server memory**, keyed by the Flask
  session cookie. This is appropriate for a single local user running the
  dev server — do not run this behind multiple worker processes or deploy it
  multi-tenant without moving state into a shared store.
- Credentials you enter in the Connection tab are kept in memory for the
  lifetime of your browser session only; they are never written to disk.
- See [docs/USER_GUIDE.md](docs/USER_GUIDE.md) for a full walkthrough,
  [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) for error meanings, and
  [docs/SQL_PATTERNS.md](docs/SQL_PATTERNS.md) for the generated SQL
  reference.
