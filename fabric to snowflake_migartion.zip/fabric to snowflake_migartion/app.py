"""
Fabric/Databricks Notebook -> Snowflake Migration Tool
Flask backend implementing the 8-step medallion-architecture migration workflow
described in COPILOT_PROMPT.txt.
"""
import json
import os
import re
import time
import uuid
from datetime import datetime

from flask import Flask, jsonify, render_template, request, session
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", uuid.uuid4().hex)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16 MB

# ---------------------------------------------------------------------------
# In-memory per-session state (single-process dev server; see README.md)
# ---------------------------------------------------------------------------
SESSIONS = {}


def get_state():
    if "sid" not in session:
        session["sid"] = uuid.uuid4().hex
    sid = session["sid"]
    if sid not in SESSIONS:
        SESSIONS[sid] = {
            "notebook_tables": None,
            "connection": None,
            "snowflake_conn": None,
            "validation_report": None,
            "sql": {
                "table_validation": {"approved": False},
                "silver": {"statements": None, "approved": False},
                "gold": {"statements": None, "approved": False},
            },
            "execution": {"silver": None, "gold": None},
        }
    return SESSIONS[sid]


def ok(data=None, message="OK"):
    payload = {"status": "success", "message": message}
    if data is not None:
        payload["data"] = data
    return jsonify(payload)


def error(message, http_status=400, details=None):
    payload = {"status": "error", "message": message}
    if details:
        payload["details"] = details
    return jsonify(payload), http_status


# ---------------------------------------------------------------------------
# Reference schema (derived from healthcare_pipeline_standalone.ipynb, Cell 8
# "BRONZE LAYER" - used as a fallback if a differently-formatted notebook is
# uploaded and dynamic parsing cannot locate a table's column block).
# ---------------------------------------------------------------------------
EXPECTED_TABLES = ["MEMBER", "PROVIDER", "PRODUCT", "PHARMACY", "CLAIM"]

FALLBACK_SCHEMA = {
    "MEMBER": ["MEMBER_ID", "FIRST_NAME", "LAST_NAME", "DATE_OF_BIRTH", "GENDER",
               "STATE", "PRODUCT_ID", "ENROLLMENT_DATE", "TERMINATION_DATE",
               "LAST_VISIT_DATE", "CREATED_AT"],
    "PROVIDER": ["PROVIDER_ID", "PROVIDER_NAME", "SPECIALTY", "NETWORK_STATUS",
                 "CREDENTIALING_DATE", "LAST_REVIEW_DATE", "CREATED_AT"],
    "PRODUCT": ["PRODUCT_ID", "PRODUCT_NAME", "PRODUCT_TYPE", "PLAN_LEVEL",
                "DEDUCTIBLE", "COPAY", "COINSURANCE_RATE", "OUT_OF_POCKET_MAX",
                "EFFECTIVE_DATE", "TERMINATION_DATE", "CREATED_AT"],
    "PHARMACY": ["PHARMACY_ID", "PHARMACY_NAME", "PHARMACY_TYPE", "NCPDP_ID",
                 "NETWORK_STATUS", "CONTRACT_START_DATE", "CONTRACT_END_DATE",
                 "CREATED_AT"],
    "CLAIM": ["CLAIM_ID", "MEMBER_ID", "PROVIDER_ID", "SERVICE_DATE",
              "CLAIM_AMOUNT", "PAID_AMOUNT", "CLAIM_STATUS", "SUBMITTED_DATE",
              "PROCESSED_DATE", "CREATED_AT", "UPDATED_AT"],
}

# Expected row counts, calibrated against the actual reference notebook run
# (1000-row MEMBER/PROVIDER/CLAIM sample) rather than COPILOT_PROMPT.txt's
# illustrative "944" placeholder, which doesn't match this dataset's real
# 1-claim-per-member distribution. vw_silver_claims_trend / vw_gold_claims_timeline
# are additions - the prompt's spec omitted them (see generate_silver_sql).
ROW_COUNT_EXPECTATIONS = {
    "vw_silver_member_claims": {"expected": 1000, "tolerance_pct": 10},
    "vw_silver_network_performance": {"min": 2, "max": 3},
    "vw_silver_provider_performance": {"expected": 1000, "tolerance_pct": 10},
    "vw_silver_claims_trend": {"expected": 97, "tolerance_pct": 20},
    "vw_gold_member_dashboard": {"expected": 1000, "tolerance_pct": 10},
    "vw_gold_claims_timeline": {"expected": 97, "tolerance_pct": 20},
    "vw_gold_network_summary": {"min": 2, "max": 3},
    "vw_gold_provider_top": {"expected": 50, "tolerance_pct": 0},
}


def check_row_count(table_name, actual):
    rule = ROW_COUNT_EXPECTATIONS.get(table_name)
    if rule is None:
        return "UNKNOWN", None
    if "min" in rule:
        if rule["min"] <= actual <= rule["max"]:
            return "MATCH", f"{rule['min']}-{rule['max']}"
        return "WARNING", f"{rule['min']}-{rule['max']}"
    expected = rule["expected"]
    tol = expected * rule["tolerance_pct"] / 100
    if abs(actual - expected) <= tol:
        return "MATCH", str(expected)
    return "WARNING", str(expected)


# ---------------------------------------------------------------------------
# Step 1: Notebook parsing
# ---------------------------------------------------------------------------
def parse_notebook(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            nb = json.load(f)
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise ValueError("Invalid notebook format. Ensure it's a valid .ipynb file")

    if not isinstance(nb, dict) or "cells" not in nb:
        raise ValueError("Invalid notebook format. Ensure it's a valid .ipynb file")

    full_source = ""
    for cell in nb["cells"]:
        if cell.get("cell_type") == "code":
            src = cell.get("source", "")
            full_source += ("".join(src) if isinstance(src, list) else src) + "\n"

    tables = {}
    for table in EXPECTED_TABLES:
        var = table.lower()
        pattern = (
            rf'bronze_{var}\s*=\s*raw_{var}(.*?)'
            rf'(?=\n\s*print\(f?"[^\n]*BRONZE|\n\s*#\s*BRONZE:|\Z)'
        )
        match = re.search(pattern, full_source, re.DOTALL)
        cols = []
        if match:
            block = match.group(1)
            found = re.findall(r'\.withColumn\(\s*"([A-Za-z0-9_]+)"', block)
            seen = set()
            for c in found:
                if c not in seen:
                    seen.add(c)
                    cols.append(c)
        tables[table] = cols if cols else FALLBACK_SCHEMA.get(table, [])

    if not any(tables.values()):
        raise ValueError("No table definitions found in notebook cells")

    return tables


# ---------------------------------------------------------------------------
# Snowflake connection helpers
# ---------------------------------------------------------------------------
def get_connector():
    try:
        import snowflake.connector  # noqa: F401
        return snowflake.connector
    except ImportError:
        raise RuntimeError(
            "snowflake-connector-python is not installed. "
            "Run: pip install -r requirements.txt"
        )


def open_connection(conn_cfg):
    sf = get_connector()
    kwargs = {
        "account": conn_cfg["account"],
        "user": conn_cfg["user"],
        "password": conn_cfg.get("password") or None,
        "warehouse": conn_cfg["warehouse"],
        "database": conn_cfg["database"],
        "role": conn_cfg.get("role") or None,
        "authenticator": conn_cfg.get("authenticator") or None,
        "passcode": conn_cfg.get("passcode") or None,
    }
    kwargs = {k: v for k, v in kwargs.items() if v}
    return sf.connect(**kwargs)


def get_live_connection(state, conn_cfg):
    """Reuse the session's open Snowflake connection instead of reconnecting.

    Re-authenticating on every step is wrong here: MFA passcodes are single-use
    and external-browser/Duo approval shouldn't be repeated for every button
    click, so the same connection is kept alive for the whole session and only
    replaced if it has actually died.
    """
    conn = state.get("snowflake_conn")
    if conn is not None:
        try:
            if not conn.is_closed():
                return conn
        except Exception:
            pass
    conn = open_connection(conn_cfg)
    state["snowflake_conn"] = conn
    return conn


def classify_snowflake_error(exc, conn_cfg):
    msg = str(exc)
    lower = msg.lower()
    if "warehouse" in lower and ("does not exist" in lower or "not authorized" in lower):
        return f"Warehouse {conn_cfg.get('warehouse')} does not exist"
    if "role" in lower and ("does not exist" in lower or "not exist or not authorized" in lower):
        return f"Role {conn_cfg.get('role')} does not exist"
    if "database" in lower and "does not exist" in lower:
        return f"Database {conn_cfg.get('database')} does not exist"
    if "mfa" in lower or "passcode" in lower or "duo" in lower or "two-factor" in lower:
        return (
            "Multi-factor authentication failed or a passcode is required. "
            "Enter the 6-digit code from your MFA app (Duo Mobile/authenticator) "
            "in the Passcode field, or approve the Duo push notification on your phone."
        )
    if "incorrect username or password" in lower or "authentication" in lower or "250001" in lower:
        return "Invalid Snowflake credentials"
    if "404 not found" in lower or "250003" in lower:
        return (
            f"Could not reach Snowflake account '{conn_cfg.get('account')}'. "
            "Check the account identifier (e.g. 'xy12345.us-east-1' or "
            "'orgname-accountname') - no https:// or .snowflakecomputing.com suffix."
        )
    return msg


# ---------------------------------------------------------------------------
# Steps 3 & 6: SQL generation
# ---------------------------------------------------------------------------
def generate_silver_sql(db, raw_schema, silver_schema):
    statements = {}

    statements["vw_silver_member_claims"] = f"""-- =====================================================================
-- SILVER LAYER: vw_silver_member_claims
-- Purpose : One row per member summarizing claim volume, spend and risk
-- Source  : {db}.{raw_schema}.CLAIM (LEFT JOIN {raw_schema}.MEMBER for reference)
-- Expected row count: ~1000 rows (one per distinct MEMBER_ID with claims)
-- =====================================================================
CREATE OR REPLACE TRANSIENT TABLE {db}.{silver_schema}.vw_silver_member_claims AS
SELECT
    c.MEMBER_ID,
    COUNT(c.CLAIM_ID)                                                   AS TOTAL_CLAIMS,
    ROUND(COALESCE(SUM(c.CLAIM_AMOUNT), 0), 2)                          AS TOTAL_CLAIM_AMOUNT,
    ROUND(COALESCE(SUM(c.PAID_AMOUNT), 0), 2)                           AS TOTAL_PAID_AMOUNT,
    ROUND(COALESCE(AVG(c.CLAIM_AMOUNT), 0), 2)                          AS AVG_CLAIM_AMOUNT,
    -- APPROVAL_RATE: approved claims / total claims, NULLIF guards divide-by-zero
    ROUND(
        (COUNT(CASE WHEN c.CLAIM_STATUS = 'Approved' THEN 1 END) /
         NULLIF(COUNT(c.CLAIM_ID), 0)) * 100, 2
    )                                                                    AS APPROVAL_RATE,
    MIN(c.SERVICE_DATE)                                                 AS FIRST_CLAIM_DATE,
    MAX(c.SERVICE_DATE)                                                 AS LAST_CLAIM_DATE,
    -- MEMBER_RISK_CATEGORY: High > 50000, Medium > 10000, else Low
    CASE
        WHEN SUM(c.CLAIM_AMOUNT) > 50000 THEN 'High'
        WHEN SUM(c.CLAIM_AMOUNT) > 10000 THEN 'Medium'
        ELSE 'Low'
    END                                                                  AS MEMBER_RISK_CATEGORY
FROM {db}.{raw_schema}.CLAIM c
LEFT JOIN {db}.{raw_schema}.MEMBER m
    ON c.MEMBER_ID = m.MEMBER_ID
WHERE c.MEMBER_ID IS NOT NULL
  AND c.CLAIM_ID IS NOT NULL
GROUP BY c.MEMBER_ID
ORDER BY TOTAL_CLAIM_AMOUNT DESC;
"""

    statements["vw_silver_network_performance"] = f"""-- =====================================================================
-- SILVER LAYER: vw_silver_network_performance
-- Purpose : Claim volume and payment performance grouped by provider
--           network status (In-Network / Out-of-Network)
-- Source  : {db}.{raw_schema}.CLAIM LEFT JOIN {raw_schema}.PROVIDER
-- Expected row count: 2-3 rows
-- =====================================================================
CREATE OR REPLACE TRANSIENT TABLE {db}.{silver_schema}.vw_silver_network_performance AS
SELECT
    COALESCE(p.NETWORK_STATUS, 'Unknown')                               AS NETWORK_STATUS,
    COUNT(c.CLAIM_ID)                                                   AS TOTAL_CLAIMS,
    ROUND(COALESCE(SUM(c.CLAIM_AMOUNT), 0), 2)                          AS CLAIM_AMOUNT_TOTAL,
    ROUND(COALESCE(SUM(c.PAID_AMOUNT), 0), 2)                           AS PAID_AMOUNT_TOTAL,
    ROUND(COALESCE(AVG(c.CLAIM_AMOUNT), 0), 2)                          AS AVG_CLAIM_AMOUNT,
    COUNT(DISTINCT c.MEMBER_ID)                                         AS UNIQUE_MEMBERS,
    COUNT(DISTINCT c.PROVIDER_ID)                                       AS PROVIDER_COUNT,
    -- PAYMENT_RATE_PCT: paid / claimed, NULLIF guards divide-by-zero
    ROUND(
        (SUM(c.PAID_AMOUNT) / NULLIF(SUM(c.CLAIM_AMOUNT), 0)) * 100, 2
    )                                                                    AS PAYMENT_RATE_PCT
FROM {db}.{raw_schema}.CLAIM c
LEFT JOIN {db}.{raw_schema}.PROVIDER p
    ON c.PROVIDER_ID = p.PROVIDER_ID
WHERE c.PROVIDER_ID IS NOT NULL
GROUP BY COALESCE(p.NETWORK_STATUS, 'Unknown')
ORDER BY CLAIM_AMOUNT_TOTAL DESC;
"""

    statements["vw_silver_provider_performance"] = f"""-- =====================================================================
-- SILVER LAYER: vw_silver_provider_performance
-- Purpose : Per-provider claim volume, spend, and approval performance
-- Source  : {db}.{raw_schema}.CLAIM LEFT JOIN {raw_schema}.PROVIDER
-- Expected row count: ~1000 rows
-- =====================================================================
CREATE OR REPLACE TRANSIENT TABLE {db}.{silver_schema}.vw_silver_provider_performance AS
SELECT
    p.PROVIDER_ID,
    p.PROVIDER_NAME,
    p.SPECIALTY,
    COUNT(c.CLAIM_ID)                                                   AS TOTAL_CLAIMS,
    ROUND(COALESCE(SUM(c.CLAIM_AMOUNT), 0), 2)                          AS TOTAL_CLAIM_AMOUNT,
    ROUND(COALESCE(SUM(c.PAID_AMOUNT), 0), 2)                           AS TOTAL_PAID_AMOUNT,
    ROUND(COALESCE(AVG(c.CLAIM_AMOUNT), 0), 2)                          AS AVG_CLAIM_AMOUNT,
    COUNT(DISTINCT c.MEMBER_ID)                                         AS UNIQUE_MEMBERS,
    ROUND(
        (COUNT(CASE WHEN c.CLAIM_STATUS = 'Approved' THEN 1 END) /
         NULLIF(COUNT(c.CLAIM_ID), 0)) * 100, 2
    )                                                                    AS APPROVAL_RATE,
    ROUND(
        (SUM(c.PAID_AMOUNT) / NULLIF(SUM(c.CLAIM_AMOUNT), 0)) * 100, 2
    )                                                                    AS PAYMENT_RATE_PCT
FROM {db}.{raw_schema}.CLAIM c
LEFT JOIN {db}.{raw_schema}.PROVIDER p
    ON c.PROVIDER_ID = p.PROVIDER_ID
WHERE c.PROVIDER_ID IS NOT NULL
GROUP BY p.PROVIDER_ID, p.PROVIDER_NAME, p.SPECIALTY
ORDER BY TOTAL_CLAIMS DESC;
"""

    statements["vw_silver_claims_trend"] = f"""-- =====================================================================
-- SILVER LAYER: vw_silver_claims_trend
-- Purpose : Monthly claim volume and spend trend, split by claim status
-- Source  : {db}.{raw_schema}.CLAIM
-- Expected row count: ~97 rows (distinct year/month/quarter/status combos)
-- =====================================================================
CREATE OR REPLACE TRANSIENT TABLE {db}.{silver_schema}.vw_silver_claims_trend AS
SELECT
    YEAR(c.SERVICE_DATE)                                                AS CLAIM_YEAR,
    MONTH(c.SERVICE_DATE)                                               AS CLAIM_MONTH,
    QUARTER(c.SERVICE_DATE)                                             AS CLAIM_QUARTER,
    c.CLAIM_STATUS,
    COUNT(c.CLAIM_ID)                                                   AS CLAIM_COUNT,
    ROUND(COALESCE(SUM(c.CLAIM_AMOUNT), 0), 2)                          AS CLAIM_AMOUNT_TOTAL,
    ROUND(COALESCE(SUM(c.PAID_AMOUNT), 0), 2)                           AS PAID_AMOUNT_TOTAL,
    ROUND(COALESCE(AVG(c.CLAIM_AMOUNT), 0), 2)                          AS AVG_CLAIM_AMOUNT,
    COUNT(DISTINCT c.MEMBER_ID)                                         AS UNIQUE_MEMBERS
FROM {db}.{raw_schema}.CLAIM c
WHERE c.SERVICE_DATE IS NOT NULL
  AND c.CLAIM_ID IS NOT NULL
GROUP BY YEAR(c.SERVICE_DATE), MONTH(c.SERVICE_DATE), QUARTER(c.SERVICE_DATE), c.CLAIM_STATUS
ORDER BY CLAIM_YEAR, CLAIM_MONTH;
"""
    return statements


def generate_gold_sql(db, raw_schema, silver_schema, gold_schema):
    statements = {}

    statements["vw_gold_member_dashboard"] = f"""-- =====================================================================
-- GOLD LAYER: vw_gold_member_dashboard
-- Purpose : React-optimized member dashboard feed (dates as strings)
-- Source  : {silver_schema}.vw_silver_member_claims + {raw_schema}.MEMBER
-- Expected row count: ~1000 rows
-- =====================================================================
CREATE OR REPLACE TRANSIENT TABLE {db}.{gold_schema}.vw_gold_member_dashboard AS
SELECT
    s.MEMBER_ID,
    COALESCE(m.FIRST_NAME || ' ' || m.LAST_NAME, 'Unknown')             AS MEMBER_NAME,
    s.TOTAL_CLAIMS,
    s.TOTAL_CLAIM_AMOUNT,
    s.TOTAL_PAID_AMOUNT,
    ROUND(s.TOTAL_CLAIM_AMOUNT - s.TOTAL_PAID_AMOUNT, 2)                AS TOTAL_DENIED_AMOUNT,
    s.AVG_CLAIM_AMOUNT,
    s.APPROVAL_RATE,
    s.MEMBER_RISK_CATEGORY,
    TO_VARCHAR(s.FIRST_CLAIM_DATE, 'YYYY-MM-DD')                        AS FIRST_CLAIM_DATE,
    TO_VARCHAR(s.LAST_CLAIM_DATE, 'YYYY-MM-DD')                         AS LAST_CLAIM_DATE,
    TO_VARCHAR(m.ENROLLMENT_DATE, 'YYYY-MM-DD')                         AS ENROLLMENT_DATE
FROM {db}.{silver_schema}.vw_silver_member_claims s
LEFT JOIN {db}.{raw_schema}.MEMBER m
    ON s.MEMBER_ID = m.MEMBER_ID
WHERE s.MEMBER_ID IS NOT NULL
ORDER BY TOTAL_CLAIM_AMOUNT DESC;
"""

    statements["vw_gold_claims_timeline"] = f"""-- =====================================================================
-- GOLD LAYER: vw_gold_claims_timeline
-- Purpose : Monthly claim volume/spend trend feed for timeline widgets
-- Source  : {silver_schema}.vw_silver_claims_trend
-- Expected row count: ~97 rows
-- =====================================================================
CREATE OR REPLACE TRANSIENT TABLE {db}.{gold_schema}.vw_gold_claims_timeline AS
SELECT
    CLAIM_YEAR,
    CLAIM_MONTH,
    CLAIM_QUARTER,
    CLAIM_YEAR || '-' || LPAD(CLAIM_MONTH, 2, '0')                      AS YEAR_MONTH,
    CLAIM_STATUS,
    CLAIM_COUNT,
    CLAIM_AMOUNT_TOTAL,
    PAID_AMOUNT_TOTAL,
    AVG_CLAIM_AMOUNT,
    UNIQUE_MEMBERS
FROM {db}.{silver_schema}.vw_silver_claims_trend
WHERE CLAIM_YEAR IS NOT NULL
ORDER BY YEAR_MONTH DESC;
"""

    statements["vw_gold_network_summary"] = f"""-- =====================================================================
-- GOLD LAYER: vw_gold_network_summary
-- Purpose : Network-level spend summary for dashboard KPI tiles
-- Source  : {silver_schema}.vw_silver_network_performance
-- Expected row count: 2-3 rows
-- =====================================================================
CREATE OR REPLACE TRANSIENT TABLE {db}.{gold_schema}.vw_gold_network_summary AS
SELECT
    NETWORK_STATUS,
    TOTAL_CLAIMS,
    CLAIM_AMOUNT_TOTAL,
    PAID_AMOUNT_TOTAL,
    UNIQUE_MEMBERS,
    PROVIDER_COUNT,
    PAYMENT_RATE_PCT
FROM {db}.{silver_schema}.vw_silver_network_performance
WHERE NETWORK_STATUS IS NOT NULL
ORDER BY CLAIM_AMOUNT_TOTAL DESC;
"""

    statements["vw_gold_provider_top"] = f"""-- =====================================================================
-- GOLD LAYER: vw_gold_provider_top
-- Purpose : Top 50 providers by claim volume for leaderboard widgets
-- Source  : {silver_schema}.vw_silver_provider_performance
-- Expected row count: 50 rows
-- =====================================================================
CREATE OR REPLACE TRANSIENT TABLE {db}.{gold_schema}.vw_gold_provider_top AS
SELECT
    PROVIDER_ID,
    PROVIDER_NAME,
    SPECIALTY,
    TOTAL_CLAIMS,
    TOTAL_CLAIM_AMOUNT,
    TOTAL_PAID_AMOUNT,
    AVG_CLAIM_AMOUNT,
    UNIQUE_MEMBERS,
    APPROVAL_RATE,
    PAYMENT_RATE_PCT
FROM {db}.{silver_schema}.vw_silver_provider_performance
WHERE PROVIDER_ID IS NOT NULL
ORDER BY TOTAL_CLAIMS DESC
LIMIT 50;
"""
    return statements


def execute_statements(state, conn_cfg, statements, db, schema):
    """Execute CREATE TABLE statements sequentially, capturing status/rows/time."""
    conn = get_live_connection(state, conn_cfg)
    results = []
    cur = conn.cursor()
    try:
        cur.execute("ALTER SESSION SET STATEMENT_TIMEOUT_IN_SECONDS = 30")
    except Exception:
        pass
    for table_name, sql in statements.items():
        entry = {
            "table": table_name,
            "status": "FAILED",
            "row_count": None,
            "execution_time_sec": None,
            "error": None,
            "row_count_check": None,
            "expected": None,
        }
        start = time.perf_counter()
        try:
            cur.execute(sql)
            cur.execute(f"SELECT COUNT(*) FROM {db}.{schema}.{table_name}")
            row_count = cur.fetchone()[0]
            elapsed = round(time.perf_counter() - start, 2)
            check, expected = check_row_count(table_name, row_count)
            entry.update({
                "status": "SUCCESS",
                "row_count": row_count,
                "execution_time_sec": elapsed,
                "row_count_check": check,
                "expected": expected,
            })
        except Exception as e:
            elapsed = round(time.perf_counter() - start, 2)
            msg = str(e)
            if "timeout" in msg.lower():
                msg = "Query execution exceeded 30 second timeout"
            entry.update({
                "status": "FAILED",
                "execution_time_sec": elapsed,
                "error": msg,
            })
        results.append(entry)
    cur.close()
    return results


def run_data_quality_checks(state, conn_cfg, db, gold_schema):
    checks = []
    try:
        conn = get_live_connection(state, conn_cfg)
        cur = conn.cursor()

        def scalar(sql):
            cur.execute(sql)
            return cur.fetchone()[0]

        table = f"{db}.{gold_schema}.vw_gold_member_dashboard"
        null_member_id = scalar(f"SELECT COUNT(*) FROM {table} WHERE MEMBER_ID IS NULL")
        checks.append(("No NULL values in MEMBER_ID", null_member_id == 0,
                        f"{null_member_id} null MEMBER_ID rows"))

        neg_claim = scalar(f"SELECT COUNT(*) FROM {table} WHERE TOTAL_CLAIM_AMOUNT < 0")
        checks.append(("No negative claim amounts", neg_claim == 0,
                        f"{neg_claim} rows with negative TOTAL_CLAIM_AMOUNT"))

        neg_paid = scalar(f"SELECT COUNT(*) FROM {table} WHERE TOTAL_PAID_AMOUNT < 0")
        checks.append(("No negative paid amounts", neg_paid == 0,
                        f"{neg_paid} rows with negative TOTAL_PAID_AMOUNT"))

        bad_rate = scalar(
            f"SELECT COUNT(*) FROM {table} "
            f"WHERE APPROVAL_RATE < 0 OR APPROVAL_RATE > 100"
        )
        checks.append(("All approval rates between 0-100", bad_rate == 0,
                        f"{bad_rate} rows outside 0-100 range"))

        paid_gt_claim = scalar(
            f"SELECT COUNT(*) FROM {table} WHERE TOTAL_PAID_AMOUNT > TOTAL_CLAIM_AMOUNT"
        )
        checks.append(("Paid amount never exceeds claim amount", paid_gt_claim == 0,
                        f"{paid_gt_claim} rows where paid > claimed"))

        cur.close()
    except Exception as e:
        checks.append(("Data quality query execution", False, str(e)))
    return checks


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/upload-notebook", methods=["POST"])
def upload_notebook():
    if "notebook" not in request.files or request.files["notebook"].filename == "":
        return error("File not found: no file uploaded")

    file = request.files["notebook"]
    filename = secure_filename(file.filename)
    if not filename.lower().endswith(".ipynb"):
        return error("Invalid notebook format. Ensure it's a valid .ipynb file")

    path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(path)

    try:
        tables = parse_notebook(path)
    except ValueError as e:
        return error(str(e))
    except Exception as e:
        return error(f"Failed to parse notebook: {e}", 500)

    state = get_state()
    state["notebook_tables"] = tables

    return ok({
        "filename": filename,
        "tables": tables,
        "table_count": len(tables),
    }, "Notebook parsed successfully")


IDENTIFIER_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_$]*$')


@app.route("/api/snowflake/test-connection", methods=["POST"])
def test_connection():
    body = request.get_json(silent=True) or {}
    authenticator = (body.get("authenticator") or "snowflake").strip()
    uses_password = authenticator == "snowflake"

    required = ["account", "user", "warehouse", "database"]
    if uses_password:
        required.append("password")
    missing = [f for f in required if not body.get(f)]
    if missing:
        return error(f"Missing required field(s): {', '.join(missing)}")

    conn_cfg = {
        "account": body["account"],
        "user": body["user"],
        "password": body.get("password", ""),
        "warehouse": body["warehouse"],
        "database": body["database"],
        "role": body.get("role", ""),
        "authenticator": authenticator,
        "passcode": body.get("passcode", ""),
        "raw_schema": body.get("raw_schema", "RAW_SCHEMA"),
        "silver_schema": body.get("silver_schema", "SILVER_SCHEMA"),
        "gold_schema": body.get("gold_schema", "GOLD_SCHEMA"),
    }

    for field in ("database", "raw_schema", "silver_schema", "gold_schema"):
        if not IDENTIFIER_RE.match(conn_cfg[field]):
            return error(
                f"Invalid Snowflake identifier for {field}: '{conn_cfg[field]}'. "
                "Use letters, numbers and underscores only."
            )

    state = get_state()

    old_conn = state.get("snowflake_conn")
    if old_conn is not None:
        try:
            old_conn.close()
        except Exception:
            pass
        state["snowflake_conn"] = None

    try:
        conn = open_connection(conn_cfg)
        cur = conn.cursor()
        cur.execute("SELECT CURRENT_VERSION(), CURRENT_ACCOUNT(), CURRENT_WAREHOUSE()")
        version, account, warehouse = cur.fetchone()
        cur.close()
    except RuntimeError as e:
        return error(str(e), 500)
    except Exception as e:
        return error(classify_snowflake_error(e, conn_cfg), 400)

    state["connection"] = conn_cfg
    state["snowflake_conn"] = conn

    return ok({
        "snowflake_version": version,
        "account": account,
        "warehouse": warehouse,
        "database": conn_cfg["database"],
    }, "Connection successful")


@app.route("/api/snowflake/validate-tables", methods=["POST"])
def validate_tables():
    state = get_state()
    conn_cfg = state.get("connection")
    if not conn_cfg:
        return error("No active Snowflake connection. Test connection first.")

    notebook_tables = state.get("notebook_tables")
    if not notebook_tables:
        return error("No table definitions found in notebook cells")

    try:
        conn = get_live_connection(state, conn_cfg)
        cur = conn.cursor()

        cur.execute(
            "SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES "
            "WHERE TABLE_SCHEMA = %s", (conn_cfg["raw_schema"],)
        )
        existing_tables = {row[0].upper() for row in cur.fetchall()}

        matching, missing, column_mismatches = [], [], []
        for table, expected_cols in notebook_tables.items():
            if table.upper() not in existing_tables:
                missing.append(table)
                continue
            matching.append(table)
            cur.execute(
                "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS "
                "WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
                (conn_cfg["raw_schema"], table),
            )
            actual_cols = {row[0].upper() for row in cur.fetchall()}
            missing_cols = [c for c in expected_cols if c.upper() not in actual_cols]
            if missing_cols:
                column_mismatches.append({"table": table, "missing_columns": missing_cols})

        cur.close()
    except RuntimeError as e:
        return error(str(e), 500)
    except Exception as e:
        return error(classify_snowflake_error(e, conn_cfg), 400)

    overall_status = "PASS" if not missing and not column_mismatches else "FAIL"
    report = {
        "status": overall_status,
        "matching_tables": matching,
        "missing_tables": missing,
        "column_mismatches": column_mismatches,
    }
    state["validation_report"] = report
    state["sql"]["table_validation"]["approved"] = False

    return ok(report, f"Validation {overall_status}")


@app.route("/api/generate-silver-sql", methods=["POST"])
def generate_silver_sql_route():
    state = get_state()
    conn_cfg = state.get("connection")
    if not conn_cfg:
        return error("No active Snowflake connection. Test connection first.")
    if not state["sql"]["table_validation"]["approved"]:
        return error("Raw table validation must be approved before generating SQL.")

    statements = generate_silver_sql(
        conn_cfg["database"], conn_cfg["raw_schema"], conn_cfg["silver_schema"]
    )
    state["sql"]["silver"] = {"statements": statements, "approved": False}

    return ok({"statements": statements}, "Silver layer SQL generated")


@app.route("/api/review-sql", methods=["POST"])
def review_sql():
    body = request.get_json(silent=True) or {}
    stage = body.get("stage")
    action = body.get("action")

    if stage not in ("table_validation", "silver", "gold"):
        return error("Invalid stage. Must be one of: table_validation, silver, gold")
    if action not in ("approve", "reject", "modify"):
        return error("Invalid action. Must be one of: approve, reject, modify")

    state = get_state()

    if stage == "table_validation":
        if action == "reject":
            return error("Table validation rejected. Resolve mismatches in Snowflake and re-validate.")
        state["sql"]["table_validation"]["approved"] = True
        return ok({"stage": stage, "approved": True}, "Table validation approved")

    layer_state = state["sql"][stage]
    if layer_state.get("statements") is None:
        return error(f"No {stage} SQL has been generated yet.")

    if action == "reject":
        layer_state["statements"] = None
        layer_state["approved"] = False
        return ok({"stage": stage, "approved": False}, "SQL rejected; regenerate to continue")

    if action == "modify":
        table_name = body.get("table_name")
        new_sql = body.get("sql")
        if not table_name or table_name not in layer_state["statements"]:
            return error("Unknown table_name for modification.")
        if not new_sql:
            return error("No SQL provided for modification.")
        layer_state["statements"][table_name] = new_sql
        return ok({"stage": stage, "table_name": table_name}, "SQL statement updated")

    layer_state["approved"] = True
    return ok({"stage": stage, "approved": True}, f"{stage.capitalize()} layer SQL approved")


@app.route("/api/execute-silver", methods=["POST"])
def execute_silver():
    state = get_state()
    conn_cfg = state.get("connection")
    if not conn_cfg:
        return error("No active Snowflake connection. Test connection first.")
    silver_state = state["sql"]["silver"]
    if not silver_state.get("statements"):
        return error("No silver layer SQL has been generated yet.")
    if not silver_state.get("approved"):
        return error("Silver layer SQL must be approved before execution.")

    try:
        results = execute_statements(
            state, conn_cfg, silver_state["statements"],
            conn_cfg["database"], conn_cfg["silver_schema"]
        )
    except RuntimeError as e:
        return error(str(e), 500)
    except Exception as e:
        return error(classify_snowflake_error(e, conn_cfg), 400)

    state["execution"]["silver"] = results
    all_success = all(r["status"] == "SUCCESS" for r in results)
    return ok({"results": results, "all_success": all_success},
              "Silver layer executed" if all_success else "Silver layer executed with errors")


@app.route("/api/generate-gold-sql", methods=["POST"])
def generate_gold_sql_route():
    state = get_state()
    conn_cfg = state.get("connection")
    if not conn_cfg:
        return error("No active Snowflake connection. Test connection first.")
    silver_results = state["execution"].get("silver")
    if not silver_results or not all(r["status"] == "SUCCESS" for r in silver_results):
        return error("Silver layer must execute successfully before generating gold SQL.")

    statements = generate_gold_sql(
        conn_cfg["database"], conn_cfg["raw_schema"],
        conn_cfg["silver_schema"], conn_cfg["gold_schema"]
    )
    state["sql"]["gold"] = {"statements": statements, "approved": False}

    return ok({"statements": statements}, "Gold layer SQL generated")


@app.route("/api/execute-gold", methods=["POST"])
def execute_gold():
    state = get_state()
    conn_cfg = state.get("connection")
    if not conn_cfg:
        return error("No active Snowflake connection. Test connection first.")
    gold_state = state["sql"]["gold"]
    if not gold_state.get("statements"):
        return error("No gold layer SQL has been generated yet.")
    if not gold_state.get("approved"):
        return error("Gold layer SQL must be approved before execution.")

    try:
        results = execute_statements(
            state, conn_cfg, gold_state["statements"],
            conn_cfg["database"], conn_cfg["gold_schema"]
        )
    except RuntimeError as e:
        return error(str(e), 500)
    except Exception as e:
        return error(classify_snowflake_error(e, conn_cfg), 400)

    state["execution"]["gold"] = results
    all_success = all(r["status"] == "SUCCESS" for r in results)
    return ok({"results": results, "all_success": all_success},
              "Gold layer executed" if all_success else "Gold layer executed with errors")


@app.route("/api/generate-report", methods=["POST"])
def generate_report():
    state = get_state()
    conn_cfg = state.get("connection")
    silver_results = state["execution"].get("silver")
    gold_results = state["execution"].get("gold")

    if not conn_cfg or not silver_results or not gold_results:
        return error("Complete silver and gold execution before generating a report.")

    validation_report = state.get("validation_report") or {"missing_tables": [], "column_mismatches": []}

    db = conn_cfg["database"]
    timestamp = datetime.now()
    quality_checks = run_data_quality_checks(state, conn_cfg, db, conn_cfg["gold_schema"])

    total_rows = sum(r["row_count"] or 0 for r in silver_results + gold_results)
    total_time = round(sum(r["execution_time_sec"] or 0 for r in silver_results + gold_results), 2)
    tables_created = sum(1 for r in silver_results + gold_results if r["status"] == "SUCCESS")
    overall_success = all(r["status"] == "SUCCESS" for r in silver_results + gold_results)

    lines = []
    lines.append("=" * 78)
    lines.append("HEALTHCARE DATA PIPELINE - FABRIC TO SNOWFLAKE MIGRATION REPORT")
    lines.append("=" * 78)
    lines.append("")
    lines.append("9a) MIGRATION SUMMARY")
    lines.append("-" * 78)
    lines.append(f"  Account            : {conn_cfg.get('account')}")
    lines.append(f"  Database           : {db}")
    lines.append(f"  Warehouse          : {conn_cfg.get('warehouse')}")
    lines.append(f"  Migration timestamp: {timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"  Total tables created: {tables_created}")
    lines.append(f"  Total rows created  : {total_rows}")
    lines.append(f"  Total execution time: {total_time}s")
    lines.append("")

    lines.append("9b) TABLES CREATED")
    lines.append("-" * 78)
    lines.append("  Silver Layer:")
    for r in silver_results:
        mark = "SUCCESS" if r["status"] == "SUCCESS" else "FAILED"
        detail = f"{r['row_count']} rows ({r['execution_time_sec']}s)" if r["status"] == "SUCCESS" else r["error"]
        lines.append(f"  - {db}.{conn_cfg['silver_schema']}.{r['table']}: {detail} [{mark}]")
    lines.append("  Gold Layer:")
    for r in gold_results:
        mark = "SUCCESS" if r["status"] == "SUCCESS" else "FAILED"
        detail = f"{r['row_count']} rows ({r['execution_time_sec']}s)" if r["status"] == "SUCCESS" else r["error"]
        lines.append(f"  - {db}.{conn_cfg['gold_schema']}.{r['table']}: {detail} [{mark}]")
    lines.append("")

    lines.append("9c) DATA LINEAGE DIAGRAM")
    lines.append("-" * 78)
    lines.append(f"""  RAW_SCHEMA
  |-- MEMBER
  |-- PROVIDER
  |-- CLAIM
  |-- PRODUCT
  \\-- PHARMACY

      |
      v

  SILVER_SCHEMA
  |-- vw_silver_member_claims
  |-- vw_silver_network_performance
  |-- vw_silver_provider_performance
  \\-- vw_silver_claims_trend

      |
      v

  GOLD_SCHEMA
  |-- vw_gold_member_dashboard
  |-- vw_gold_claims_timeline
  |-- vw_gold_network_summary
  \\-- vw_gold_provider_top
""")

    rollback_sql = build_rollback_sql(db, conn_cfg["silver_schema"], conn_cfg["gold_schema"])
    lines.append("9d) ROLLBACK INSTRUCTIONS")
    lines.append("-" * 78)
    lines.append(rollback_sql)
    lines.append("")

    lines.append("9e) MIGRATION VALIDATION CHECKLIST")
    lines.append("-" * 78)
    checklist_lines = []
    for label, passed, detail in quality_checks:
        mark = "[PASS]" if passed else "[FAIL]"
        checklist_lines.append(f"  {mark} {label} ({detail})")
    silver_ok = sum(1 for r in silver_results if r["status"] == "SUCCESS")
    gold_ok = sum(1 for r in gold_results if r["status"] == "SUCCESS")
    silver_rows_ok = sum(1 for r in silver_results if r.get("row_count_check") == "MATCH")
    gold_rows_ok = sum(1 for r in gold_results if r.get("row_count_check") == "MATCH")
    lines.append(f"  [{'PASS' if not validation_report['missing_tables'] else 'FAIL'}] All raw tables found in Snowflake")
    lines.append(f"  [{'PASS' if not validation_report['column_mismatches'] else 'FAIL'}] All column names matched")
    lines.append(f"  [{'PASS' if silver_ok == len(silver_results) else 'FAIL'}] Silver layer created successfully ({silver_ok}/{len(silver_results)})")
    lines.append(f"  [{'PASS' if silver_rows_ok == len(silver_results) else 'WARN'}] Silver row counts validated ({silver_rows_ok}/{len(silver_results)} match expected)")
    lines.append(f"  [{'PASS' if gold_ok == len(gold_results) else 'FAIL'}] Gold layer created successfully ({gold_ok}/{len(gold_results)})")
    lines.append(f"  [{'PASS' if gold_rows_ok == len(gold_results) else 'WARN'}] Gold row counts validated ({gold_rows_ok}/{len(gold_results)} match expected)")
    lines.extend(checklist_lines)
    lines.append("")

    lines.append("9f) FINAL STATUS")
    lines.append("-" * 78)
    lines.append(f"  MIGRATION: {'SUCCESS' if overall_success else 'COMPLETED WITH ERRORS'}")
    lines.append(f"  TIMESTAMP: {timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"  DURATION : {total_time} seconds")
    lines.append(f"  TABLES CREATED: {tables_created}")
    lines.append(f"  TOTAL ROWS: {total_rows}")
    lines.append(f"  READY FOR DASHBOARD: {'YES' if overall_success else 'NO'}")
    lines.append("=" * 78)

    report_text = "\n".join(lines)

    return ok({
        "report_text": report_text,
        "rollback_sql": rollback_sql,
        "summary": {
            "tables_created": tables_created,
            "total_rows": total_rows,
            "execution_time": total_time,
            "timestamp": timestamp.isoformat() + "Z",
            "success": overall_success,
        },
    }, "Migration completed successfully" if overall_success else "Migration completed with errors")


def build_rollback_sql(db, silver_schema, gold_schema):
    gold_tables = ["vw_gold_member_dashboard", "vw_gold_claims_timeline",
                   "vw_gold_network_summary", "vw_gold_provider_top"]
    silver_tables = ["vw_silver_member_claims", "vw_silver_network_performance",
                     "vw_silver_provider_performance", "vw_silver_claims_trend"]
    lines = ["-- Drop Gold Layer"]
    lines += [f"DROP TABLE IF EXISTS {db}.{gold_schema}.{t};" for t in gold_tables]
    lines.append("")
    lines.append("-- Drop Silver Layer")
    lines += [f"DROP TABLE IF EXISTS {db}.{silver_schema}.{t};" for t in silver_tables]
    return "\n".join(lines)


if __name__ == "__main__":
    # use_reloader=False: the debug auto-reloader watches every imported module's
    # source file: once snowflake.connector (and its large dependency tree) is
    # imported, its freshly pip-installed files perpetually look "changed" to the
    # watcher and it never stops restarting. Debug error pages are still enabled.
    app.run(debug=True, use_reloader=False, threaded=True, host="0.0.0.0", port=5000)
