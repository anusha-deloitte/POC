// Fabric -> Snowflake Migration Tool - frontend logic (vanilla JS, no dependencies)

const state = {
  reportText: "",
  rollbackSql: "",
};

// ---------------------------------------------------------------------------
// Tab navigation
// ---------------------------------------------------------------------------
function switchTab(tabName) {
  document.querySelectorAll(".tab-btn").forEach((b) => b.classList.toggle("active", b.dataset.tab === tabName));
  document.querySelectorAll(".tab-pane").forEach((p) => p.classList.toggle("active", p.id === "tab-" + tabName));
}

document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => switchTab(btn.dataset.tab));
});

function setGlobalStatus(text) {
  document.getElementById("global-status").textContent = text;
}

function setStep(stepId, cls) {
  const li = document.querySelector(`#stepper li[data-step="${stepId}"]`);
  if (!li) return;
  li.classList.remove("done", "active");
  if (cls) li.classList.add(cls);
}

async function apiCall(url, options = {}) {
  const opts = Object.assign({ headers: {} }, options);
  if (opts.body && !(opts.body instanceof FormData)) {
    opts.headers["Content-Type"] = "application/json";
  }
  const res = await fetch(url, opts);
  const data = await res.json().catch(() => ({ status: "error", message: "Invalid server response" }));
  if (!res.ok || data.status === "error") {
    throw new Error(data.message || "Request failed");
  }
  return data;
}

function showResultBox(el, message, kind) {
  el.classList.remove("hidden", "status-success", "status-error", "status-warning");
  el.classList.add(`status-${kind}`);
  el.textContent = message;
}

// ---------------------------------------------------------------------------
// Step 1: Upload notebook
// ---------------------------------------------------------------------------
document.getElementById("upload-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fileInput = document.getElementById("notebook-file");
  const resultBox = document.getElementById("upload-result");
  if (!fileInput.files.length) return;

  const formData = new FormData();
  formData.append("notebook", fileInput.files[0]);

  setGlobalStatus("Uploading notebook...");
  try {
    const data = await apiCall("/api/upload-notebook", { method: "POST", body: formData });
    const tables = data.data.tables;
    const lines = [`Parsed ${data.data.table_count} table(s) from ${data.data.filename}:`, ""];
    for (const [name, cols] of Object.entries(tables)) {
      lines.push(`  ${name} (${cols.length} columns): ${cols.join(", ")}`);
    }
    showResultBox(resultBox, lines.join("\n"), "success");
    setStep("upload", "done");
    setGlobalStatus("Notebook parsed");
  } catch (err) {
    showResultBox(resultBox, err.message, "error");
    setGlobalStatus("Upload failed");
  }
});

// ---------------------------------------------------------------------------
// Step 2: Connection
// ---------------------------------------------------------------------------
const authenticatorSelect = document.getElementById("sf-authenticator");
const passwordLabel = document.getElementById("sf-password-label");
const passwordInput = document.getElementById("sf-password");
const passcodeLabel = document.getElementById("sf-passcode-label");

function syncPasswordField() {
  const needsPassword = authenticatorSelect.value === "snowflake" ||
                         authenticatorSelect.value === "username_password_mfa";
  passwordLabel.style.display = needsPassword ? "" : "none";
  passwordInput.required = needsPassword;
  passcodeLabel.style.display = needsPassword ? "" : "none";
}
authenticatorSelect.addEventListener("change", syncPasswordField);
syncPasswordField();

document.getElementById("connection-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const resultBox = document.getElementById("connection-result");
  const payload = {
    account: document.getElementById("sf-account").value.trim(),
    user: document.getElementById("sf-user").value.trim(),
    password: document.getElementById("sf-password").value,
    passcode: document.getElementById("sf-passcode").value.trim(),
    authenticator: authenticatorSelect.value,
    warehouse: document.getElementById("sf-warehouse").value.trim(),
    database: document.getElementById("sf-database").value.trim(),
    role: document.getElementById("sf-role").value.trim(),
    raw_schema: document.getElementById("sf-raw-schema").value.trim() || "RAW_SCHEMA",
    silver_schema: document.getElementById("sf-silver-schema").value.trim() || "SILVER_SCHEMA",
    gold_schema: document.getElementById("sf-gold-schema").value.trim() || "GOLD_SCHEMA",
  };

  if (payload.authenticator === "externalbrowser") {
    showResultBox(resultBox, "Waiting for SSO login in the browser window opened on the server machine...", "warning");
  }
  setGlobalStatus("Testing Snowflake connection...");
  try {
    const data = await apiCall("/api/snowflake/test-connection", {
      method: "POST",
      body: JSON.stringify(payload),
    });
    showResultBox(
      resultBox,
      `Connected. Snowflake ${data.data.snowflake_version} | Account: ${data.data.account} | Warehouse: ${data.data.warehouse} | Database: ${data.data.database}`,
      "success"
    );
    setStep("connect", "done");
    setGlobalStatus("Connected to Snowflake");
  } catch (err) {
    showResultBox(resultBox, err.message, "error");
    setGlobalStatus("Connection failed");
  }
});

// ---------------------------------------------------------------------------
// Step 3: Validator
// ---------------------------------------------------------------------------
document.getElementById("btn-validate").addEventListener("click", async () => {
  const resultBox = document.getElementById("validation-result");
  const approvalRow = document.getElementById("validation-approval");
  setGlobalStatus("Validating raw tables...");
  try {
    const data = await apiCall("/api/snowflake/validate-tables", { method: "POST" });
    const r = data.data;
    const lines = [`Validation status: ${r.status}`, ""];
    lines.push(`Matching tables: ${r.matching_tables.map((t) => "✓ " + t).join(", ") || "none"}`);
    lines.push(`Missing tables: ${r.missing_tables.length ? r.missing_tables.map((t) => "✗ " + t).join(", ") : "None"}`);
    if (r.column_mismatches.length) {
      lines.push("Column mismatches:");
      r.column_mismatches.forEach((m) => lines.push(`  - ${m.table}: missing ${m.missing_columns.join(", ")}`));
    } else {
      lines.push("Column mismatches: None");
    }
    showResultBox(resultBox, lines.join("\n"), r.status === "PASS" ? "success" : "warning");
    approvalRow.classList.remove("hidden");
    setGlobalStatus(`Validation ${r.status}`);
  } catch (err) {
    showResultBox(resultBox, err.message, "error");
    setGlobalStatus("Validation failed");
  }
});

document.getElementById("btn-approve-validation").addEventListener("click", async (e) => {
  const btn = e.target;
  try {
    btn.disabled = true;
    await apiCall("/api/review-sql", {
      method: "POST",
      body: JSON.stringify({ stage: "table_validation", action: "approve" }),
    });
    setStep("validate", "done");
    setGlobalStatus("Table validation approved");
    document.getElementById("btn-generate-silver").disabled = false;
    document.getElementById("validation-approval").classList.add("hidden");
    document.getElementById("validation-approved-msg").classList.remove("hidden");
  } catch (err) {
    btn.disabled = false;
    setGlobalStatus(err.message);
    alert(err.message);
  }
});

document.getElementById("btn-goto-sql-review").addEventListener("click", () => switchTab("sql-review"));

// ---------------------------------------------------------------------------
// SQL rendering helper
// ---------------------------------------------------------------------------
function renderSqlList(container, statements) {
  container.innerHTML = "";
  for (const [name, sql] of Object.entries(statements)) {
    const block = document.createElement("div");
    block.className = "sql-block";
    block.innerHTML = `
      <div class="sql-block-header">
        <span>${name}</span>
        <span class="sql-badge">CREATE OR REPLACE TRANSIENT TABLE</span>
      </div>
      <pre>${escapeHtml(sql)}</pre>
    `;
    container.appendChild(block);
  }
}

function escapeHtml(str) {
  return str.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  })[c]);
}

// ---------------------------------------------------------------------------
// Step 4: Silver SQL generation / review / execution
// ---------------------------------------------------------------------------
document.getElementById("btn-generate-silver").addEventListener("click", async () => {
  setGlobalStatus("Generating silver layer SQL...");
  try {
    const data = await apiCall("/api/generate-silver-sql", { method: "POST" });
    renderSqlList(document.getElementById("silver-sql-list"), data.data.statements);
    document.getElementById("silver-approval").classList.remove("hidden");
    setStep("silver-sql", "active");
    setGlobalStatus("Silver SQL generated - review and approve");
  } catch (err) {
    setGlobalStatus(err.message);
    alert(err.message);
  }
});

document.getElementById("btn-approve-silver").addEventListener("click", async () => {
  try {
    await apiCall("/api/review-sql", {
      method: "POST",
      body: JSON.stringify({ stage: "silver", action: "approve" }),
    });
    setStep("silver-sql", "done");
    document.getElementById("btn-execute-silver").disabled = false;
    setGlobalStatus("Silver SQL approved");
  } catch (err) {
    setGlobalStatus(err.message);
  }
});

document.getElementById("btn-reject-silver").addEventListener("click", async () => {
  try {
    await apiCall("/api/review-sql", {
      method: "POST",
      body: JSON.stringify({ stage: "silver", action: "reject" }),
    });
    document.getElementById("silver-sql-list").innerHTML = "";
    document.getElementById("silver-approval").classList.add("hidden");
    setGlobalStatus("Silver SQL rejected - regenerate to continue");
  } catch (err) {
    setGlobalStatus(err.message);
  }
});

document.getElementById("btn-execute-silver").addEventListener("click", async () => {
  const resultBox = document.getElementById("silver-exec-result");
  setGlobalStatus("Executing silver layer...");
  try {
    const data = await apiCall("/api/execute-silver", { method: "POST" });
    renderExecResults(resultBox, data.data.results);
    setStep("silver-exec", data.data.all_success ? "done" : "active");
    if (data.data.all_success) {
      document.getElementById("btn-generate-gold").disabled = false;
    }
    setGlobalStatus(data.message);
  } catch (err) {
    showResultBox(resultBox, err.message, "error");
    setGlobalStatus("Silver execution failed");
  }
});

function renderExecResults(container, results) {
  const rows = results.map((r) => {
    const rowLabel = r.status === "SUCCESS"
      ? `${r.row_count} rows (${r.execution_time_sec}s) [${r.row_count_check}${r.expected ? " vs expected " + r.expected : ""}]`
      : `ERROR: ${r.error}`;
    return `<tr><td>${r.table}</td><td>${r.status}</td><td>${rowLabel}</td></tr>`;
  }).join("");
  container.innerHTML = `<table class="report-table"><thead><tr><th>Table</th><th>Status</th><th>Detail</th></tr></thead><tbody>${rows}</tbody></table>`;
  container.classList.remove("hidden", "status-error", "status-success");
  const allOk = results.every((r) => r.status === "SUCCESS");
  container.classList.add(allOk ? "status-success" : "status-error");
}

// ---------------------------------------------------------------------------
// Step 6: Gold SQL generation / review / execution
// ---------------------------------------------------------------------------
document.getElementById("btn-generate-gold").addEventListener("click", async () => {
  setGlobalStatus("Generating gold layer SQL...");
  try {
    const data = await apiCall("/api/generate-gold-sql", { method: "POST" });
    renderSqlList(document.getElementById("gold-sql-list"), data.data.statements);
    document.getElementById("gold-approval").classList.remove("hidden");
    setStep("gold-sql", "active");
    setGlobalStatus("Gold SQL generated - review and approve");
  } catch (err) {
    setGlobalStatus(err.message);
    alert(err.message);
  }
});

document.getElementById("btn-approve-gold").addEventListener("click", async () => {
  try {
    await apiCall("/api/review-sql", {
      method: "POST",
      body: JSON.stringify({ stage: "gold", action: "approve" }),
    });
    setStep("gold-sql", "done");
    document.getElementById("btn-execute-gold").disabled = false;
    setGlobalStatus("Gold SQL approved");
  } catch (err) {
    setGlobalStatus(err.message);
  }
});

document.getElementById("btn-reject-gold").addEventListener("click", async () => {
  try {
    await apiCall("/api/review-sql", {
      method: "POST",
      body: JSON.stringify({ stage: "gold", action: "reject" }),
    });
    document.getElementById("gold-sql-list").innerHTML = "";
    document.getElementById("gold-approval").classList.add("hidden");
    setGlobalStatus("Gold SQL rejected - regenerate to continue");
  } catch (err) {
    setGlobalStatus(err.message);
  }
});

document.getElementById("btn-execute-gold").addEventListener("click", async () => {
  const resultBox = document.getElementById("gold-exec-result");
  setGlobalStatus("Executing gold layer...");
  try {
    const data = await apiCall("/api/execute-gold", { method: "POST" });
    renderExecResults(resultBox, data.data.results);
    setStep("gold-exec", data.data.all_success ? "done" : "active");
    setGlobalStatus(data.message);
  } catch (err) {
    showResultBox(resultBox, err.message, "error");
    setGlobalStatus("Gold execution failed");
  }
});

// ---------------------------------------------------------------------------
// Step 9: Report generation & download
// ---------------------------------------------------------------------------
document.getElementById("btn-generate-report").addEventListener("click", async () => {
  const summaryBox = document.getElementById("report-summary");
  const reportPre = document.getElementById("report-text");
  const actionsRow = document.getElementById("report-actions");
  setGlobalStatus("Generating migration report...");
  try {
    const data = await apiCall("/api/generate-report", { method: "POST" });
    const s = data.data.summary;
    showResultBox(
      summaryBox,
      `Migration ${s.success ? "SUCCESS" : "COMPLETED WITH ERRORS"} | Tables: ${s.tables_created} | Rows: ${s.total_rows} | Duration: ${s.execution_time}s`,
      s.success ? "success" : "warning"
    );
    state.reportText = data.data.report_text;
    state.rollbackSql = data.data.rollback_sql;
    reportPre.textContent = state.reportText;
    reportPre.classList.remove("hidden");
    actionsRow.classList.remove("hidden");
    setStep("report", "done");
    setGlobalStatus("Report generated");
  } catch (err) {
    showResultBox(summaryBox, err.message, "error");
    setGlobalStatus("Report generation failed");
  }
});

function downloadText(filename, content, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

document.getElementById("btn-download-report").addEventListener("click", () => {
  downloadText("migration_report.txt", state.reportText, "text/plain");
});

document.getElementById("btn-download-rollback").addEventListener("click", () => {
  downloadText("rollback.sql", state.rollbackSql, "application/sql");
});
