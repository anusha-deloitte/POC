# SQL Pattern Reference

All generated DDL follows these rules (see `generate_silver_sql` /
`generate_gold_sql` in `app.py`):

- `CREATE OR REPLACE TRANSIENT TABLE <DATABASE>.<SCHEMA>.<name> AS SELECT ...`
  — fully-qualified 3-part names, never bare table names.
- `COALESCE(...)` wraps every aggregate that could return `NULL` (e.g. no
  rows for a group).
- `NULLIF(denominator, 0)` guards every division to avoid divide-by-zero.
- `ROUND(..., 2)` on every decimal metric.
- `CASE WHEN` for categorical derivations (e.g. `MEMBER_RISK_CATEGORY`).
- Explicit `WHERE` filters exclude rows with `NULL` join/group keys before
  `GROUP BY` runs.
- Every statement ends with an `ORDER BY` for deterministic output.
- No `SELECT *` — every column is named explicitly.

## Silver layer

### `vw_silver_member_claims` (~944 rows)
- **Grain**: one row per `MEMBER_ID`
- **Source**: `RAW_SCHEMA.CLAIM` (LEFT JOIN `RAW_SCHEMA.MEMBER` for reference)
- **Metrics**: `TOTAL_CLAIMS`, `TOTAL_CLAIM_AMOUNT`, `TOTAL_PAID_AMOUNT`,
  `AVG_CLAIM_AMOUNT`, `APPROVAL_RATE`, `FIRST_CLAIM_DATE`, `LAST_CLAIM_DATE`,
  `MEMBER_RISK_CATEGORY` (`High` > 50000, `Medium` > 10000, else `Low`)

### `vw_silver_network_performance` (2-3 rows)
- **Grain**: one row per `PROVIDER.NETWORK_STATUS`
- **Source**: `RAW_SCHEMA.CLAIM` LEFT JOIN `RAW_SCHEMA.PROVIDER`
- **Metrics**: `TOTAL_CLAIMS`, `CLAIM_AMOUNT_TOTAL`, `PAID_AMOUNT_TOTAL`,
  `AVG_CLAIM_AMOUNT`, `UNIQUE_MEMBERS`, `PROVIDER_COUNT`, `PAYMENT_RATE_PCT`

### `vw_silver_provider_performance` (~1000 rows)
- **Grain**: one row per `PROVIDER_ID` / `PROVIDER_NAME` / `SPECIALTY`
- **Source**: `RAW_SCHEMA.CLAIM` LEFT JOIN `RAW_SCHEMA.PROVIDER`
- **Metrics**: `TOTAL_CLAIMS`, `TOTAL_CLAIM_AMOUNT`, `TOTAL_PAID_AMOUNT`,
  `AVG_CLAIM_AMOUNT`, `UNIQUE_MEMBERS`, `APPROVAL_RATE`, `PAYMENT_RATE_PCT`

## Gold layer

Gold statements build on top of Silver views and additionally:
- Convert all `DATE` columns to `VARCHAR` via `TO_VARCHAR(col, 'YYYY-MM-DD')`
  so the React frontend can consume them without client-side date parsing.
- Preserve numeric types (decimals stay `DECIMAL`, never cast to string).

### `vw_gold_member_dashboard` (~944 rows)
Source: `vw_silver_member_claims` + `RAW_SCHEMA.MEMBER`. Adds `MEMBER_NAME`
and `ENROLLMENT_DATE`; computes
`TOTAL_DENIED_AMOUNT = TOTAL_CLAIM_AMOUNT - TOTAL_PAID_AMOUNT`. Ordered by
`TOTAL_CLAIM_AMOUNT DESC`.

### `vw_gold_claims_timeline` (2-3 rows)
Source: `vw_silver_network_performance`, selected as-is. Ordered by
`TOTAL_CLAIMS DESC`.

### `vw_gold_network_summary` (2-3 rows)
Source: `vw_silver_network_performance`, a narrower KPI-tile projection.
Ordered by `CLAIM_AMOUNT_TOTAL DESC`.

### `vw_gold_provider_top` (50 rows)
Source: `vw_silver_provider_performance`. Ordered by `TOTAL_CLAIMS DESC`,
`LIMIT 50`.

## Row-count expectations (`ROW_COUNT_EXPECTATIONS` in `app.py`)

| Table | Rule |
|---|---|
| `vw_silver_member_claims` | 944 ± 10% |
| `vw_silver_network_performance` | 2-3 (exact range) |
| `vw_silver_provider_performance` | 1000 ± 10% |
| `vw_gold_member_dashboard` | 944 ± 10% |
| `vw_gold_claims_timeline` | 2-3 (exact range) |
| `vw_gold_network_summary` | 2-3 (exact range) |
| `vw_gold_provider_top` | 50 (exact) |

A mismatch is reported as a `WARNING`, not a hard failure — the pipeline
still completes so you can inspect why counts differ from the reference
1000-row sample dataset.
