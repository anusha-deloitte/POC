# User Guide

## 1. Dashboard tab — Upload Notebook

- Click **Upload & Parse** after choosing your `.ipynb` file.
- The tool scans the BRONZE-layer cells (`bronze_<table> = raw_<table>...withColumn(...)`)
  and extracts each expected raw table's column list. If it cannot find a
  table's block, it falls back to the known schema for `healthcare_pipeline_standalone.ipynb`.
- The stepper at the top tracks your progress through all 8 steps.

## 2. Connection tab — Connect to Snowflake

Fill in:

| Field | Notes |
|---|---|
| Account | e.g. `xy12345.us-east-1` (no `https://`, no `.snowflakecomputing.com`) |
| User / Password | Snowflake login credentials |
| Warehouse | Must be running or auto-resume enabled |
| Database | Defaults to `HEALTHCARE_DB` |
| Role | Optional — leave blank to use your default role |
| Raw/Silver/Gold Schema | Defaults to `RAW_SCHEMA` / `SILVER_SCHEMA` / `GOLD_SCHEMA` |

Click **Test Connection**. On success you'll see the Snowflake version,
account, warehouse and database confirmed.

## 3. Validator tab — Raw Table Validation

Click **Run Validation**. The tool queries
`INFORMATION_SCHEMA.TABLES` / `INFORMATION_SCHEMA.COLUMNS` in your Raw schema
and compares against the notebook's expected tables/columns:

- ✓ **Matching tables** — found with all expected columns
- ✗ **Missing tables** — not present in `RAW_SCHEMA`
- **Column mismatches** — table exists but is missing expected column(s)

You must click **Approve & Continue** before SQL generation is unlocked,
even if the status is `FAIL` — for example if you've intentionally
added extra columns and want to proceed anyway.

## 4. SQL Review tab — Silver then Gold

1. **Generate Silver SQL** — produces the 3 `CREATE OR REPLACE TRANSIENT
   TABLE` statements (`vw_silver_member_claims`, `vw_silver_network_performance`,
   `vw_silver_provider_performance`) with syntax-highlighted, commented SQL.
2. Read each statement. Choose:
   - **Approve Silver SQL** — unlocks execution
   - **Reject & Regenerate** — clears the statements; click Generate again
3. **Execute Silver Layer** — runs the 3 statements sequentially against
   Snowflake. Each row shows status, row count, execution time, and whether
   the row count matched the expected value (944 / 2-3 / ~1000).
4. Once Silver executes successfully, **Generate Gold SQL** unlocks. Repeat
   the same approve/execute flow for the 4 Gold statements.

> Modifying a statement before approval is supported via the API
> (`POST /api/review-sql` with `action: "modify"`) if you want to hand-edit
> SQL outside the UI.

## 5. Results tab — Migration Report

Click **Generate Report** once both layers have executed. You get:

- A summary banner (tables created, total rows, duration, pass/fail)
- A full report in the dark text panel: migration summary, tables created,
  data lineage diagram, rollback script, validation checklist, final status
- **Download Report (.txt)** and **Download Rollback (.sql)** buttons

Run the downloaded `rollback.sql` in Snowflake to drop all Silver/Gold
transient tables created by this migration if you need to start over.
