# Troubleshooting Guide

## Notebook upload

| Message | Cause | Fix |
|---|---|---|
| `File not found: no file uploaded` | No file was attached to the upload request | Choose a `.ipynb` file before clicking Upload & Parse |
| `Invalid notebook format. Ensure it's a valid .ipynb file` | The file isn't valid JSON, or isn't an `.ipynb` | Confirm you exported/saved a real Jupyter notebook, not a renamed `.py` or `.txt` file |
| `No table definitions found in notebook cells` | The parser couldn't find any `bronze_<table> = raw_<table>` blocks with `.withColumn(...)` calls | Make sure the notebook still contains the BRONZE layer cell unmodified, or edit `FALLBACK_SCHEMA` in `app.py` for a custom notebook structure |

## Snowflake connection

| Message | Cause | Fix |
|---|---|---|
| `Invalid Snowflake credentials` | Wrong username/password, or MFA required | Re-enter credentials; if MFA is enforced, use a service account or app password |
| `Warehouse <name> does not exist` | Typo, or warehouse was dropped/renamed | Check **Warehouses** in Snowsight and re-enter the exact name |
| `Role <name> does not exist` | Typo, or your user isn't granted that role | Leave Role blank to use your default role, or verify the role name |
| `Database <name> does not exist` | Typo, or database not yet created | Create the database, or correct the name in the Connection tab |
| `snowflake-connector-python is not installed...` | Dependencies weren't installed | Run `pip install -r requirements.txt` |

## Table validation

| Symptom | Cause | Fix |
|---|---|---|
| Missing tables list is non-empty | The raw CSVs haven't been loaded into `RAW_SCHEMA` yet | Load `MEMBER.csv`, `PROVIDER.csv`, `PRODUCT.csv`, `PHARMACY.csv`, `CLAIM.csv` into Snowflake first (`COPY INTO` / Snowsight upload) |
| Column mismatches listed for a table | The Snowflake table's columns don't match the notebook's BRONZE layer | Either add/rename the missing columns in Snowflake, or approve validation anyway if the mismatch is expected (e.g. extra audit columns) |

## SQL execution

| Message | Cause | Fix |
|---|---|---|
| `Expected [N] rows, got [M] rows` (shown as a `WARNING` row-count check) | Underlying raw data differs from the 1000-row sample dataset the notebook was built against | Not necessarily an error — review whether the discrepancy is expected for your dataset |
| `Query execution exceeded 30 second timeout` | Warehouse too small, or a very large `CLAIM` table | Resume/scale up the warehouse, or increase the timeout in `execute_statements()` in `app.py` |
| Full Snowflake error text under a `FAILED` row | SQL compile/runtime error against your schema | Check that referenced columns exist; if you modified a statement in the SQL Review tab, verify the edited SQL is valid Snowflake syntax |
| "Silver layer must execute successfully before generating gold SQL" | Gold generation was attempted before all 3 Silver statements returned `SUCCESS` | Fix the failing Silver statement and re-execute before moving to Gold |

## General

- All API responses follow `{"status": "success"|"error", "message": "...", "data": {...}}`.
  Check the browser DevTools Network tab for the raw JSON if the UI message
  seems truncated.
- Session state resets if the Flask process restarts (in-memory only) — you
  will need to re-upload the notebook and reconnect to Snowflake.
