"""WS4: schema/fidelity gate.

After WS3 builds the Gold-layer Snowflake objects, diff their actual columns
(name, type) against what the PBI semantic model expects for that table --
block/report mismatches rather than silently letting WS5 repoint a report at
something that doesn't actually match its model.

Table matching is by bare name (decision #13's convention: object names
throughout this pipeline match what the Fabric notebooks/scripts/model
already used, not a separate internal naming scheme) -- a model table with
no Snowflake counterpart in this build simply has nothing to gate here, it
isn't a hard failure on its own.
"""

from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, Field

from app.ir.model import DataType, SemanticModel
from app.services.fabric_build import BuildPlan

MismatchKind = Literal["missing_in_snowflake", "type_mismatch"]

_TYPE_FAMILIES: dict[DataType, set[str]] = {
    DataType.STRING: {"VARCHAR", "TEXT", "STRING", "CHAR", "CHARACTER"},
    DataType.INT64: {"NUMBER", "INT", "INTEGER", "BIGINT", "SMALLINT", "TINYINT", "BYTEINT"},
    DataType.DOUBLE: {"FLOAT", "DOUBLE", "REAL", "FLOAT4", "FLOAT8"},
    DataType.DECIMAL: {"NUMBER", "DECIMAL", "NUMERIC"},
    DataType.BOOLEAN: {"BOOLEAN"},
    DataType.DATETIME: {"TIMESTAMP_NTZ", "TIMESTAMP_LTZ", "TIMESTAMP_TZ", "TIMESTAMP", "DATETIME"},
    DataType.DATE: {"DATE"},
    DataType.TIME: {"TIME"},
    DataType.BINARY: {"BINARY", "VARBINARY"},
    DataType.VARIANT: {"VARIANT", "OBJECT", "ARRAY"},
}

_BASE_TYPE_RE = re.compile(r"^([A-Za-z_]+)")


def _base_type(snowflake_type: str) -> str:
    m = _BASE_TYPE_RE.match(snowflake_type.strip().upper())
    return m.group(1) if m else snowflake_type.strip().upper()


def _type_compatible(expected: DataType, actual_sf_type: str) -> bool:
    if expected == DataType.UNKNOWN:
        return True
    families = _TYPE_FAMILIES.get(expected)
    if families is None:
        return True
    return _base_type(actual_sf_type) in families


class ColumnMismatch(BaseModel):
    column: str
    kind: MismatchKind
    expected_type: str | None = None
    actual_type: str | None = None


class TableFidelityResult(BaseModel):
    table: str
    matched: bool
    mismatches: list[ColumnMismatch] = Field(default_factory=list)


class FidelityReport(BaseModel):
    results: list[TableFidelityResult] = Field(default_factory=list)
    # model tables with no built counterpart -- not gated, just not checked
    skipped_tables: list[str] = Field(default_factory=list)

    @property
    def blocking(self) -> bool:
        return any(not r.matched for r in self.results)

    @property
    def ok(self) -> bool:
        return not self.blocking


def compare_schema(
    model: SemanticModel, actual_columns: dict[str, list[tuple[str, str]]]
) -> FidelityReport:
    """`actual_columns`: bare table name (any case) -> [(column_name, snowflake_type)],
    typically from `describe_built_tables()`."""
    by_upper = {k.upper(): v for k, v in actual_columns.items()}
    results: list[TableFidelityResult] = []
    skipped: list[str] = []

    for table in model.tables:
        actual = by_upper.get(table.name.upper())
        if actual is None:
            skipped.append(table.name)
            continue
        actual_by_name = {name.upper(): sf_type for name, sf_type in actual}
        mismatches: list[ColumnMismatch] = []
        for col in model.table(table.name).columns:
            if col.is_calculated:
                continue  # not sourced from the physical table, nothing to gate
            physical_name = (col.source_column or col.name).upper()
            if physical_name not in actual_by_name:
                mismatches.append(ColumnMismatch(column=col.name, kind="missing_in_snowflake"))
                continue
            sf_type = actual_by_name[physical_name]
            if not _type_compatible(col.data_type, sf_type):
                mismatches.append(
                    ColumnMismatch(
                        column=col.name,
                        kind="type_mismatch",
                        expected_type=col.data_type.value,
                        actual_type=sf_type,
                    )
                )
        results.append(
            TableFidelityResult(table=table.name, matched=not mismatches, mismatches=mismatches)
        )

    return FidelityReport(results=results, skipped_tables=skipped)


def describe_built_tables(
    plan: BuildPlan, sf_cursor, target_database: str, skipped: set[str] = frozenset()
) -> dict[str, list[tuple[str, str]]]:
    """`DESCRIBE TABLE` every table/dynamic-table this plan built (task_proc
    items don't have a single well-known output table at this layer -- their
    own DDL already names whatever they write to, so they're skipped here).

    `skipped` names objects execute_build_plan() never created (unresolved
    source, or a dependent of one) -- DESCRIBE TABLE on those would fail the
    same way the original CREATE did, so they're left out of the report
    rather than raising."""
    out: dict[str, list[tuple[str, str]]] = {}
    for item in plan.items:
        if item.object_kind == "task_proc" or item.object_name in skipped:
            continue
        fq = f'"{target_database}"."{item.schema_name}"."{item.object_name}"'
        sf_cursor.execute(f"DESCRIBE TABLE {fq}")
        rows = sf_cursor.fetchall()
        out[item.object_name] = [(row[0], row[1]) for row in rows]
    return out
