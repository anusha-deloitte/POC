import { useFabricWizard } from './store/fabricWizard'
import { FabricBuildStep } from './steps/fabric/FabricBuildStep'
import { FabricExportStep } from './steps/fabric/FabricExportStep'
import { FabricReviewStep } from './steps/fabric/FabricReviewStep'
import { FabricUploadStep } from './steps/fabric/FabricUploadStep'

/** Fabric-migration wizard body, rendered inside the AppShell outlet at
 * /app/fabric — a parallel flow to the PBI-conversion wizard (./App.tsx),
 * not a branch of it (see store/fabricWizard.ts). */
export default function FabricApp() {
  const step = useFabricWizard((s) => s.step)
  return (
    <>
      {step === 'upload' && <FabricUploadStep />}
      {step === 'review' && <FabricReviewStep />}
      {step === 'build' && <FabricBuildStep />}
      {step === 'export' && <FabricExportStep />}
    </>
  )
}
