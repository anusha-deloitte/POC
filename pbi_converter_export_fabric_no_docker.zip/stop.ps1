<#
.SYNOPSIS
  Stops the API/web dev servers started by start.ps1.

.DESCRIPTION
  Doesn't rely solely on .dev-pids.json: if start.ps1 is run again while a
  previous session is still up (forgotten terminal, machine sleep/wake, a
  crashed reload worker restarted by hand, etc.), the pidfile gets overwritten
  and the earlier generation's whole process tree (uv -> uvicorn -> reload
  worker -> multiprocessing forks, or npm -> cmd -> vite) becomes untracked —
  taskkill /T on the new PIDs alone never sees it, so it leaks forever. This
  finds every generation by recognizing this checkout's own processes by
  command line (paths under backend/ and frontend/), in addition to whatever
  the pidfile and the dev ports currently point at, and kills each one's full
  ancestor/descendant chain.
#>
param(
    [int]$ApiPort = 8000,
    [int]$WebPort = 5173
)

$root = $PSScriptRoot
$backend = Join-Path $root 'backend'
$frontend = Join-Path $root 'frontend'
$pidFile = Join-Path $root '.dev-pids.json'

# Process names that can plausibly appear between our recorded/discovered PID
# and the process that actually matters (uv's uvicorn child, npm's vite
# grandchild, ...). Walking ancestors/descendants stops at anything outside
# this set, so we never reach into whatever shell/terminal launched start.ps1.
$ownNames = @('uv.exe', 'uvicorn.exe', 'python.exe', 'node.exe', 'cmd.exe', 'npm.cmd')

function Get-DescendantIds {
    # $RootId itself is always included even if its own name isn't in
    # $ownNames (the caller already decided it's relevant, e.g. it owns a
    # dev port); only the walk *into* further descendants is name-restricted,
    # so this never wanders into an unrelated child a matched process happens
    # to have spawned for some unrelated reason.
    param([int]$RootId)
    $ids = [System.Collections.Generic.List[int]]::new()
    $frontier = [System.Collections.Generic.Queue[int]]::new()
    $frontier.Enqueue($RootId)
    while ($frontier.Count -gt 0) {
        $current = $frontier.Dequeue()
        $ids.Add($current)
        Get-CimInstance Win32_Process -Filter "ParentProcessId=$current" -ErrorAction SilentlyContinue |
            Where-Object { $ownNames -contains $_.Name } |
            ForEach-Object { $frontier.Enqueue($_.ProcessId) }
    }
    return $ids
}

function Get-AncestorIds {
    param([int]$StartId)
    $ids = [System.Collections.Generic.List[int]]::new()
    $currentId = $StartId
    for ($i = 0; $i -lt 8; $i++) {
        $proc = Get-CimInstance Win32_Process -Filter "ProcessId=$currentId" -ErrorAction SilentlyContinue
        if (-not $proc) { break }
        $parent = Get-CimInstance Win32_Process -Filter "ProcessId=$($proc.ParentProcessId)" -ErrorAction SilentlyContinue
        if (-not $parent -or ($ownNames -notcontains $parent.Name)) { break }
        $ids.Add($parent.ProcessId)
        $currentId = $parent.ProcessId
    }
    return $ids
}

$killSet = [System.Collections.Generic.HashSet[int]]::new()

function Add-ProjectProcess {
    param([int]$ProcId)
    if ($killSet.Contains($ProcId)) { return }
    foreach ($id in (Get-AncestorIds -StartId $ProcId)) { [void]$killSet.Add($id) }
    foreach ($id in (Get-DescendantIds -RootId $ProcId)) { [void]$killSet.Add($id) }
}

# 1) whatever start.ps1 last recorded
if (Test-Path $pidFile) {
    $recorded = Get-Content $pidFile -Raw | ConvertFrom-Json
    foreach ($p in @($recorded.api, $recorded.web)) {
        if ($p -and (Get-Process -Id $p -ErrorAction SilentlyContinue)) { Add-ProjectProcess -ProcId $p }
    }
}

# 2) whoever currently holds the dev ports (covers a stale/overwritten pidfile)
Get-NetTCPConnection -LocalPort $ApiPort, $WebPort -State Listen -ErrorAction SilentlyContinue |
    ForEach-Object { Add-ProjectProcess -ProcId $_.OwningProcess }

# 3) any other generation of this checkout's server, orphaned by an earlier
#    start.ps1 run whose pidfile entry was since overwritten (decision #12) —
#    found by command line referencing this project's own backend/frontend
#    paths, not by a recorded PID, so it's caught no matter how many
#    generations piled up or whether either one still owns a port.
#    Restricted to $ownNames: matching on command-line substring alone,
#    system-wide, previously killed unrelated processes (e.g. a browser)
#    whose command line happened to contain this path for an unrelated
#    reason, along with that process's *entire* descendant tree.
Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
    Where-Object {
        ($ownNames -contains $_.Name) -and
        $_.CommandLine -and ($_.CommandLine.Contains($backend) -or $_.CommandLine.Contains($frontend))
    } | ForEach-Object { Add-ProjectProcess -ProcId $_.ProcessId }

if ($killSet.Count -eq 0) {
    Write-Host "Nothing running for this project." -ForegroundColor Yellow
} else {
    foreach ($procId in $killSet) {
        $proc = Get-Process -Id $procId -ErrorAction SilentlyContinue
        if ($proc) {
            Write-Host "Stopping $($proc.ProcessName) (pid $procId)"
            try { Stop-Process -Id $procId -Force -ErrorAction Stop } catch {}
        }
    }
}

Remove-Item $pidFile -ErrorAction SilentlyContinue
