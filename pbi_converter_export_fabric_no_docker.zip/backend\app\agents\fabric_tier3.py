"""WS2 tier 3: LLM-assisted, execution-validated translation for Fabric
notebook cells the deterministic (tier 1 SQL-literal) and rule-based
(tier 2 DataFrame-chain) passes can't reach -- genuinely imperative logic:
recursive schema introspection, dynamic column flattening/renaming, custom
UDFs beyond the filename-derived-column idiom, joins/aggregations expressed
imperatively.

Mirrors agents/tier2.py's propose -> execute -> validate -> retry-with-error
loop exactly (same Horizon client, same JSON-only contract, same forbidden-
statement guard), just for a different source language and a broader
acceptance criterion: any SELECT that executes cleanly, not a single scalar
measure -- an arbitrary Fabric transform's output shape isn't known upfront
the way a DAX measure's is.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field

_MAX_ATTEMPTS = 3

_SYSTEM = """You translate one Fabric/PySpark notebook cell into equivalent
Snowflake SQL. Rules:
- Output ONLY a JSON object: {"sql": "..."} with a single SELECT (a
  WITH ... SELECT is fine), or {"error": "reason"} if it truly can't be
  expressed as one SELECT against the given input.
- No DDL, no DML -- SELECT/WITH only.
- explode()/explode_outer() over an array column -> a Snowflake
  LATERAL FLATTEN(input => <col>) joined into the FROM clause.
- A nested struct field (col.child) read from semi-structured data ->
  Snowflake's colon path notation on a VARIANT column
  (col:child::<type>), or a plain qualified column reference if the input
  is already fully relational.
- If translating requires knowing the *actual* field names/shape of real
  data you don't have (e.g. a function that inspects df.schema or
  df.columns at runtime to decide what to do), say so via {"error"} rather
  than guessing plausible-looking column names."""


@dataclass
class Tier3Result:
    cell_index: int
    sql: str | None
    accepted: bool
    attempts: int
    trace: list[str] = field(default_factory=list)


def _extract_json(text: str) -> dict | None:
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except json.JSONDecodeError:
        return None


_FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|DROP|ALTER|GRANT|TRUNCATE|CALL)\b", re.IGNORECASE
)


def _cell_context(cell_source: str, upstream_sql: str | None, reason: str) -> str:
    lines = ["Notebook cell (PySpark) that static rules couldn't translate:", "", cell_source, ""]
    if upstream_sql:
        lines += ["Its input, as SQL already resolved by earlier translation:", upstream_sql, ""]
    lines.append(f"Why static translation gave up: {reason}")
    return "\n".join(lines)


def propose_and_validate(
    cell_index: int,
    cell_source: str,
    reason: str,
    cursor,
    *,
    upstream_sql: str | None = None,
    client=None,
) -> Tier3Result:
    """Ask Horizon for SQL, execute to validate, retry with the error, bounded."""
    trace: list[str] = []
    if client is None:
        from app.services.horizon_client import build_client_from_settings

        client = build_client_from_settings()
        if client is None:
            return Tier3Result(cell_index, None, False, 0, ["Horizon credentials not configured"])

    messages = [
        {"role": "system", "content": _SYSTEM},
        {"role": "user", "content": _cell_context(cell_source, upstream_sql, reason)},
    ]

    for attempt in range(1, _MAX_ATTEMPTS + 1):
        text = client.chat(messages) or ""
        payload = _extract_json(text)
        if payload is None or ("sql" not in payload and "error" not in payload):
            trace.append(f"attempt {attempt}: unparseable response")
            messages.append({"role": "assistant", "content": text})
            messages.append({"role": "user", "content": 'Respond with only {"sql": "..."} JSON.'})
            continue
        if "error" in payload:
            trace.append(f"attempt {attempt}: model declared impossible: {payload['error']}")
            return Tier3Result(cell_index, None, False, attempt, trace)

        sql = payload["sql"].strip().rstrip(";")
        if _FORBIDDEN.search(sql) or not sql.upper().startswith(("SELECT", "WITH")):
            trace.append(f"attempt {attempt}: rejected non-SELECT statement")
            messages.append({"role": "assistant", "content": text})
            messages.append({"role": "user", "content": "Only a single SELECT/WITH is allowed."})
            continue

        try:
            cursor.execute(sql)
            cursor.fetchall()  # must execute cleanly -- shape isn't known upfront
            trace.append(f"attempt {attempt}: executed OK")
            return Tier3Result(cell_index, sql, True, attempt, trace)
        except Exception as e:  # noqa: BLE001 - any execution failure feeds the retry loop
            trace.append(f"attempt {attempt}: execution failed: {str(e)[:200]}")
            messages.append({"role": "assistant", "content": text})
            feedback = f"That SQL failed: {str(e)[:300]}. Fix it."
            messages.append({"role": "user", "content": feedback})

    return Tier3Result(cell_index, None, False, _MAX_ATTEMPTS, trace)
