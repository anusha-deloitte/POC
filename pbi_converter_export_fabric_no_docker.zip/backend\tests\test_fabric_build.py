"""WS3: Snowflake object build + scheduling (dependency-ordered DDL plan)."""

from app.services.fabric_build import execute_build_plan, plan_build
from app.services.fabric_notebooks import FabricArtifact, FabricPipeline, NotebookCell
from app.services.fabric_translate import translate_notebook, translate_sql_artifact


def _notebook_artifact(artifact_id, path, layer, schedule, cells, reviewed=True):
    return FabricArtifact(
        id=artifact_id,
        relative_path=path,
        kind="notebook",
        layer=layer,
        schedule=schedule,
        reviewed=reviewed,
        cells=[NotebookCell(index=i, cell_type="code", source=src) for i, src in enumerate(cells)],
    )


def _sql_artifact(artifact_id, path, layer, schedule, sql_text, reviewed=True):
    return FabricArtifact(
        id=artifact_id,
        relative_path=path,
        kind="sql",
        layer=layer,
        schedule=schedule,
        reviewed=reviewed,
        sql_text=sql_text,
    )


class _FakeCursor:
    def __init__(self):
        self.executed: list[str] = []

    def execute(self, sql):
        self.executed.append(sql)


class _FakeDescribeCursor:
    """Answers `DESCRIBE TABLE <name>` with a preconfigured column list --
    for exercising the source_bindings case-correction, which needs a
    cursor that can actually return rows, unlike _FakeCursor above."""

    def __init__(self, real_columns_by_table: dict[str, list[str]]):
        self.real_columns_by_table = real_columns_by_table
        self.executed: list[str] = []
        self._last_rows: list[tuple[str, str]] = []

    def execute(self, sql):
        self.executed.append(sql)
        table = sql.removeprefix("DESCRIBE TABLE ").strip()
        self._last_rows = [(c, "TEXT") for c in self.real_columns_by_table[table]]

    def fetchall(self):
        return self._last_rows


class TestDeclarativeChain:
    def _pipeline_and_translations(self):
        bronze = _notebook_artifact(
            "bronze",
            "notebooks/01-bronze.ipynb",
            "bronze",
            "daily",
            ["df = spark.read.format('csv').load('Files/raw/*.csv')", "df.write.saveAsTable('bronze_orders')"],
        )
        silver = _notebook_artifact(
            "silver",
            "notebooks/02-silver.ipynb",
            "silver",
            "",
            ["df = spark.sql('SELECT * FROM bronze_orders')", "df.write.saveAsTable('silver_orders')"],
        )
        pipeline = FabricPipeline(id="p1", has_semantic_model=False, artifacts=[bronze, silver])
        translations = {
            bronze.id: translate_notebook(bronze),
            silver.id: translate_notebook(silver),
        }
        return pipeline, translations

    def test_schemas_created_per_layer(self):
        pipeline, translations = self._pipeline_and_translations()
        plan = plan_build(
            pipeline, translations, target_database="MYDB", target_schema="TGT", warehouse="WH"
        )
        assert plan.schemas == ["TGT__BRONZE", "TGT__SILVER"]

    def test_bronze_is_dynamic_table_silver_is_transient(self):
        pipeline, translations = self._pipeline_and_translations()
        plan = plan_build(
            pipeline, translations, target_database="MYDB", target_schema="TGT", warehouse="WH"
        )
        by_name = {i.object_name: i for i in plan.items}
        assert by_name["BRONZE_ORDERS"].object_kind == "dynamic_table"
        assert "TARGET_LAG" in by_name["BRONZE_ORDERS"].ddl[0]
        assert by_name["SILVER_ORDERS"].object_kind == "transient_table"

    def test_silver_depends_on_bronze_and_is_ordered_after(self):
        pipeline, translations = self._pipeline_and_translations()
        plan = plan_build(
            pipeline, translations, target_database="MYDB", target_schema="TGT", warehouse="WH"
        )
        assert "BRONZE_ORDERS" in next(i for i in plan.items if i.object_name == "SILVER_ORDERS").depends_on
        order = [i.object_name for i in plan.items]
        assert order.index("BRONZE_ORDERS") < order.index("SILVER_ORDERS")

    def test_resolved_sql_is_fully_qualified(self):
        pipeline, translations = self._pipeline_and_translations()
        plan = plan_build(
            pipeline, translations, target_database="MYDB", target_schema="TGT", warehouse="WH"
        )
        silver_item = next(i for i in plan.items if i.object_name == "SILVER_ORDERS")
        assert '"MYDB"."TGT__BRONZE"."BRONZE_ORDERS"' in silver_item.ddl[0]

    def test_unresolved_external_source_is_noted(self):
        pipeline, translations = self._pipeline_and_translations()
        plan = plan_build(
            pipeline, translations, target_database="MYDB", target_schema="TGT", warehouse="WH"
        )
        bronze_item = next(i for i in plan.items if i.object_name == "BRONZE_ORDERS")
        assert any("unresolved source" in n for n in bronze_item.notes)

    def test_unresolved_source_sanitizes_the_whole_path_not_just_the_extension(self):
        """Regression: a file path/glob like "Files/raw/*.csv" was collapsing
        down to a bare "CSV" placeholder (_bare_table_name's "keep only the
        part after the last dot" is correct for a schema.table SQL reference,
        but on a file path the last dot is the extension) -- Snowflake then
        rejected it outright since no object named CSV exists, crashing
        execute-build. The placeholder must retain the whole path."""
        pipeline, translations = self._pipeline_and_translations()
        plan = plan_build(
            pipeline, translations, target_database="MYDB", target_schema="TGT", warehouse="WH"
        )
        bronze_item = next(i for i in plan.items if i.object_name == "BRONZE_ORDERS")
        ddl = bronze_item.ddl[0]
        assert 'FROM "FILES_RAW_CSV"' in ddl
        assert 'FROM "CSV"' not in ddl

    def test_source_binding_resolves_external_source(self):
        pipeline, translations = self._pipeline_and_translations()
        plan = plan_build(
            pipeline,
            translations,
            target_database="MYDB",
            target_schema="TGT",
            warehouse="WH",
            source_bindings={"Files/raw/*.csv": '"MYDB"."RAW"."ORDERS_CSV"'},
        )
        bronze_item = next(i for i in plan.items if i.object_name == "BRONZE_ORDERS")
        assert not any("unresolved source" in n for n in bronze_item.notes)
        assert '"MYDB"."RAW"."ORDERS_CSV"' in bronze_item.ddl[0]

    def test_source_binding_case_correction_rewrites_mismatched_column_refs(self):
        """Regression: a human-loaded raw table's real column casing
        routinely disagrees with the exact case the original notebook code
        literally wrote (e.g. Snowflake's own default CREATE TABLE folds
        everything to uppercase) -- generated DDL that assumes the two
        match crashes with 'column does not exist' the first time they
        don't. Given a live cursor, plan_build() must DESCRIBE the bound
        table and auto-correct every quoted reference to match reality."""
        bronze = _notebook_artifact(
            "bronze",
            "notebooks/01-bronze.ipynb",
            "bronze",
            "daily",
            [
                "df = spark.read.format('csv').load('Files/raw/*.csv')",
                "df = df.withColumn('Total', df.Total.cast(DecimalType(10,2)))",
                "df.write.saveAsTable('bronze_orders')",
            ],
        )
        pipeline = FabricPipeline(id="p13", artifacts=[bronze])
        translations = {bronze.id: translate_notebook(bronze)}
        cursor = _FakeDescribeCursor({'"MYDB"."RAW"."ORDERS_CSV"': ["ID", "TOTAL"]})
        plan = plan_build(
            pipeline,
            translations,
            target_database="MYDB",
            target_schema="TGT",
            warehouse="WH",
            source_bindings={"Files/raw/*.csv": '"MYDB"."RAW"."ORDERS_CSV"'},
            sf_cursor=cursor,
        )
        bronze_item = next(i for i in plan.items if i.object_name == "BRONZE_ORDERS")
        assert cursor.executed == ['DESCRIBE TABLE "MYDB"."RAW"."ORDERS_CSV"']
        assert '"TOTAL"' in bronze_item.ddl[0]
        assert '"Total"' not in bronze_item.ddl[0]

    def test_no_cursor_given_skips_correction_without_crashing(self):
        """sf_cursor is optional -- plan preview/tests must still work as
        pure computation with no live connection (just without the
        case-correction safety net until execute time)."""
        pipeline, translations = self._pipeline_and_translations()
        plan = plan_build(
            pipeline,
            translations,
            target_database="MYDB",
            target_schema="TGT",
            warehouse="WH",
            source_bindings={"Files/raw/*.csv": '"MYDB"."RAW"."ORDERS_CSV"'},
            sf_cursor=None,
        )
        bronze_item = next(i for i in plan.items if i.object_name == "BRONZE_ORDERS")
        assert '"MYDB"."RAW"."ORDERS_CSV"' in bronze_item.ddl[0]

    def test_filename_derived_year_falls_back_to_real_column_when_source_bound(self):
        """Regression: METADATA$FILENAME (tier2's translation of
        input_file_name()) only resolves when Snowflake scans a stage
        directly. Once bound via source_bindings to a plain table the user
        loaded manually, that pseudo-column doesn't exist -- the build layer
        must swap it for a real "file_path" column instead of shipping DDL
        that crashes with 'invalid identifier METADATA$FILENAME'."""
        cells = [
            "source_dir = 'Files/cms_raw'",
            "import os\nfrom urllib.parse import urlparse\n"
            "def extract_year_from_file_name(path):\n"
            "    parsed_url = urlparse(path)\n"
            "    file_name_with_extension = os.path.basename(parsed_url.path)\n"
            "    file_name, extension = os.path.splitext(file_name_with_extension)\n"
            "    return int(file_name)\n",
            "from pyspark.sql.functions import udf\nfrom pyspark.sql.types import IntegerType\n"
            "extract_year_from_file_name_udf = udf(extract_year_from_file_name, IntegerType())",
            "df = spark.read.format('csv').load(source_dir + '/*.csv')"
            ".withColumn('file_path', input_file_name())",
            "df = df.withColumn('Year', extract_year_from_file_name_udf(df['file_path'])).drop('file_path')",
            "df.write.mode('overwrite').saveAsTable('cms_data')",
        ]
        bronze = _notebook_artifact("b", "b.ipynb", "bronze", "", cells)
        pipeline = FabricPipeline(id="p10", artifacts=[bronze])
        translations = {bronze.id: translate_notebook(bronze)}

        plan = plan_build(
            pipeline,
            translations,
            target_database="MYDB",
            target_schema="TGT",
            warehouse="WH",
            source_bindings={"Files/cms_raw/*.csv": '"MYDB"."RAW"."CMS_RAW"'},
        )
        item = next(i for i in plan.items if i.object_name == "CMS_DATA")
        assert not any("unresolved source" in n for n in item.notes)
        assert "METADATA$FILENAME" not in item.ddl[0]
        assert '"FILE_PATH"' in item.ddl[0]
        assert "EXCLUDE" not in item.ddl[0]

    def test_unreviewed_or_skip_artifacts_excluded(self):
        bronze = _notebook_artifact(
            "b", "b.ipynb", "bronze", "", ["x = spark.sql('SELECT 1')", "x.write.saveAsTable('t1')"]
        )
        skipped = _notebook_artifact(
            "s", "s.ipynb", "skip", "", ["y = spark.sql('SELECT 1')", "y.write.saveAsTable('t2')"]
        )
        unreviewed = _notebook_artifact(
            "u",
            "u.ipynb",
            "gold",
            "",
            ["z = spark.sql('SELECT 1')", "z.write.saveAsTable('t3')"],
            reviewed=False,
        )
        pipeline = FabricPipeline(id="p2", artifacts=[bronze, skipped, unreviewed])
        translations = {a.id: translate_notebook(a) for a in pipeline.artifacts}
        plan = plan_build(
            pipeline, translations, target_database="DB", target_schema="TGT", warehouse="WH"
        )
        assert [i.object_name for i in plan.items] == ["T1"]


class TestImperativeTasks:
    def test_tsql_script_becomes_proc_and_task(self):
        artifact = _sql_artifact(
            "sproc",
            "scripts/load_dim.sql",
            "gold",
            "daily 02:00",
            "INSERT INTO provider_dim SELECT id, name FROM staging_provider",
        )
        pipeline = FabricPipeline(id="p3", artifacts=[artifact])
        translations = {artifact.id: translate_sql_artifact(artifact, source_kind="tsql")}
        plan = plan_build(
            pipeline, translations, target_database="DB", target_schema="TGT", warehouse="WH"
        )
        assert len(plan.items) == 1
        item = plan.items[0]
        assert item.object_kind == "task_proc"
        assert item.object_name == "LOAD_DIM_TASK"
        assert "CREATE OR REPLACE PROCEDURE" in item.ddl[0]
        assert "LOAD_DIM_PROC" in item.ddl[0]
        assert "CREATE OR REPLACE TASK" in item.ddl[1]
        assert "SCHEDULE = 'USING CRON 0 2 * * * UTC'" in item.ddl[1]

    def test_task_chains_after_upstream_task_via_shared_table(self):
        bronze = _sql_artifact(
            "b", "scripts/build_staging.sql", "bronze", "hourly", "INSERT INTO staging_x SELECT 1"
        )
        gold = _sql_artifact(
            "g", "scripts/build_gold.sql", "gold", "daily", "INSERT INTO gold_x SELECT * FROM staging_x"
        )
        pipeline = FabricPipeline(id="p4", artifacts=[bronze, gold])
        translations = {
            bronze.id: translate_sql_artifact(bronze, source_kind="tsql"),
            gold.id: translate_sql_artifact(gold, source_kind="tsql"),
        }
        plan = plan_build(
            pipeline, translations, target_database="DB", target_schema="TGT", warehouse="WH"
        )
        by_name = {i.object_name: i for i in plan.items}
        gold_task_ddl = by_name["BUILD_GOLD_TASK"].ddl[1]
        assert "AFTER" in gold_task_ddl
        assert "BUILD_STAGING_TASK" in gold_task_ddl
        order = [i.object_name for i in plan.items]
        assert order.index("BUILD_STAGING_TASK") < order.index("BUILD_GOLD_TASK")

    def test_sproc_bare_column_ref_quoted_to_match_notebook_produced_column(self):
        """Regression: tier2 (fabric_translate.py) always quotes a computed
        column with its exact original-code case (e.g. AS "Order_Total") --
        but a T-SQL SPROC script is case-insensitive and never quotes its
        column references. Left bare, Snowflake folds it to uppercase for
        matching (ORDER_TOTAL) and can't find the quoted mixed-case column,
        crashing with 'invalid identifier'. _qualify_known_tables must quote
        every bare column reference (and select alias) it emits so both
        tiers agree on exact-case matching."""
        bronze = _notebook_artifact(
            "b",
            "b.ipynb",
            "bronze",
            "",
            ["df = spark.sql('SELECT 1')", "df = df.withColumn('Order_Total', lit(5))", "df.write.saveAsTable('sales_data')"],
        )
        gold = _sql_artifact(
            "g", "scripts/summary.sql", "gold", "daily", "INSERT INTO summary_tbl SELECT Order_Total FROM sales_data"
        )
        pipeline = FabricPipeline(id="p12", artifacts=[bronze, gold])
        translations = {
            bronze.id: translate_notebook(bronze),
            gold.id: translate_sql_artifact(gold, source_kind="tsql"),
        }
        plan = plan_build(
            pipeline, translations, target_database="DB", target_schema="TGT", warehouse="WH"
        )
        by_name = {i.object_name: i for i in plan.items}
        assert '"Order_Total"' in by_name["SALES_DATA"].ddl[0]
        summary_ddl = by_name["SUMMARY_TASK"].ddl[0]
        assert '"Order_Total"' in summary_ddl
        assert "Order_Total FROM" not in summary_ddl  # not left bare/unquoted

    def test_bare_reference_to_a_never_built_table_is_reported_and_blocked(self):
        """Regression: _qualify_known_tables used to silently leave a bare
        table reference unqualified when it matched nothing this pipeline
        builds (a typo, or the artifact that would have produced it got
        skipped) -- the generated DDL shipped anyway and only failed once it
        hit Snowflake with an opaque 'object does not exist'. It must be
        reported the same way an unresolved {{source: ...}} token is, and
        the item must be skipped rather than executed."""
        artifact = _sql_artifact(
            "g", "scripts/build_gold.sql", "gold", "daily", "INSERT INTO gold_x SELECT * FROM nonexistent_staging"
        )
        pipeline = FabricPipeline(id="p11", artifacts=[artifact])
        translations = {artifact.id: translate_sql_artifact(artifact, source_kind="tsql")}
        plan = plan_build(
            pipeline, translations, target_database="DB", target_schema="TGT", warehouse="WH"
        )
        item = plan.items[0]
        assert any(
            "unresolved source" in n and "nonexistent_staging" in n for n in item.notes
        )
        cursor = _FakeCursor()
        created, skipped = execute_build_plan(plan, cursor)
        assert created == []
        assert skipped == [item.object_name]

    def test_cross_schema_reference_flagged_not_silently_rewritten(self):
        artifact = _sql_artifact(
            "x", "scripts/x.sql", "gold", "", "INSERT INTO dbo.target_tbl SELECT * FROM dbo.source_tbl"
        )
        pipeline = FabricPipeline(id="p5", artifacts=[artifact])
        translations = {artifact.id: translate_sql_artifact(artifact, source_kind="tsql")}
        plan = plan_build(
            pipeline, translations, target_database="DB", target_schema="TGT", warehouse="WH"
        )
        assert any("schema-qualified" in n for n in plan.items[0].notes)


class TestExecuteBuildPlan:
    def test_executes_schema_then_items_in_order(self):
        bronze = _notebook_artifact(
            "b", "b.ipynb", "bronze", "", ["x = spark.sql('SELECT 1')", "x.write.saveAsTable('t1')"]
        )
        pipeline = FabricPipeline(id="p6", artifacts=[bronze])
        translations = {bronze.id: translate_notebook(bronze)}
        plan = plan_build(
            pipeline, translations, target_database="DB", target_schema="TGT", warehouse="WH"
        )
        cursor = _FakeCursor()
        created, skipped = execute_build_plan(plan, cursor)
        assert created == ["T1"]
        assert skipped == []
        assert cursor.executed[0].startswith("CREATE SCHEMA IF NOT EXISTS")
        assert "CREATE OR REPLACE TRANSIENT TABLE" in cursor.executed[1]

    def test_unresolved_source_item_is_skipped_not_executed(self):
        """Regression: an item whose own notes flag an unresolved source
        produces a placeholder object name (e.g. FILES_RAW_CSV) that doesn't
        exist in Snowflake -- executing its DDL crashed the whole request
        with an opaque 500 instead of reporting the item as unbuildable."""
        bronze = _notebook_artifact(
            "b",
            "b.ipynb",
            "bronze",
            "",
            ["df = spark.read.format('csv').load('Files/raw/*.csv')", "df.write.saveAsTable('t1')"],
        )
        pipeline = FabricPipeline(id="p7", artifacts=[bronze])
        translations = {bronze.id: translate_notebook(bronze)}
        plan = plan_build(
            pipeline, translations, target_database="DB", target_schema="TGT", warehouse="WH"
        )
        cursor = _FakeCursor()
        created, skipped = execute_build_plan(plan, cursor)
        assert created == []
        assert skipped == ["T1"]
        # only the schema DDL ran -- the unresolved item's own DDL never executed
        assert len(cursor.executed) == 1
        assert cursor.executed[0].startswith("CREATE SCHEMA IF NOT EXISTS")

    def test_dependent_of_unresolved_source_is_also_skipped(self):
        """A downstream item that depends on an unresolved-source item must
        be skipped too -- it references an object that was never created."""
        bronze = _notebook_artifact(
            "b",
            "b.ipynb",
            "bronze",
            "",
            ["df = spark.read.format('csv').load('Files/raw/*.csv')", "df.write.saveAsTable('bronze_orders')"],
        )
        silver = _notebook_artifact(
            "s",
            "s.ipynb",
            "silver",
            "",
            ["df = spark.sql('SELECT * FROM bronze_orders')", "df.write.saveAsTable('silver_orders')"],
        )
        pipeline = FabricPipeline(id="p8", artifacts=[bronze, silver])
        translations = {bronze.id: translate_notebook(bronze), silver.id: translate_notebook(silver)}
        plan = plan_build(
            pipeline, translations, target_database="DB", target_schema="TGT", warehouse="WH"
        )
        cursor = _FakeCursor()
        created, skipped = execute_build_plan(plan, cursor)
        assert created == []
        assert set(skipped) == {"BRONZE_ORDERS", "SILVER_ORDERS"}

    def test_source_binding_allows_execution_to_proceed(self):
        """Once a source_binding resolves the external source, the item is
        no longer blocked and its DDL executes normally."""
        bronze = _notebook_artifact(
            "b",
            "b.ipynb",
            "bronze",
            "",
            ["df = spark.read.format('csv').load('Files/raw/*.csv')", "df.write.saveAsTable('t1')"],
        )
        pipeline = FabricPipeline(id="p9", artifacts=[bronze])
        translations = {bronze.id: translate_notebook(bronze)}
        plan = plan_build(
            pipeline,
            translations,
            target_database="DB",
            target_schema="TGT",
            warehouse="WH",
            source_bindings={"Files/raw/*.csv": '"DB"."RAW"."ORDERS_CSV"'},
        )
        cursor = _FakeCursor()
        created, skipped = execute_build_plan(plan, cursor)
        assert created == ["T1"]
        assert skipped == []
