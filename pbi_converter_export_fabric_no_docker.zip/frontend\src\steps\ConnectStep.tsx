import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { AlertTriangle, ArrowDown, ArrowRight, CheckCircle2, Database, Trash2 } from 'lucide-react'
import { useEffect } from 'react'
import { useState } from 'react'
import { api } from '../api/client'
import type { ConversionSummary, NewSourceConnection } from '../api/types'
import { SnowflakeConnectionPicker } from '../components/SnowflakeConnectionPicker'
import { useWizard } from '../store/wizard'

export function ConnectStep() {
  const setConnection = useWizard((s) => s.setConnection)
  const lastConnectionId = useWizard((s) => s.connectionId)
  const conversionId = useWizard((s) => s.conversionId)
  const sourceConnectionId = useWizard((s) => s.sourceConnectionId)
  const setUnsavedChanges = useWizard((s) => s.setUnsavedChanges)
  const [selected, setSelected] = useState<string | null>(lastConnectionId)

  const conversion = useQuery({
    queryKey: ['conversion', conversionId],
    queryFn: () => api.getConversion(conversionId!),
    enabled: !!conversionId,
  })
  const sources = useQuery({
    queryKey: ['source-connections'],
    queryFn: api.listSourceConnections,
  })
  const sourceDb = conversion.data?.source_database
  const needsMigration = !!sourceDb?.needs_migration
  const detectedLabel = sourceDb && sourceDb.kind !== 'snowflake'
    ? (SOURCE_KIND_LABELS[sourceDb.kind] ?? sourceDb.kind)
    : null
  const sourceReady = !needsMigration || !!sourceConnectionId
  const selectedSource = (sources.data ?? []).find((s) => s.id === sourceConnectionId)

  return (
    <section>
      <div className="mb-6 overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div className="kicker mb-1">Step 2 · Connections</div>
        <h2 className="text-xl font-bold">Where does the data live — and where should it go?</h2>
        <p className="mt-1 max-w-2xl text-sm text-surface-600">
          {needsMigration ? (
            <>
              This report reads <b>{detectedLabel}</b> — connect it, pick the target Snowflake,
              and the conversion migrates everything automatically.
            </>
          ) : (
            <>Pick the target Snowflake this report runs on.</>
          )}{' '}
          Credentials are encrypted at rest.
        </p>
      </div>

      {/* two equal panels: SOURCE -> TARGET */}
      <div className="grid items-stretch gap-4 lg:grid-cols-[1fr_auto_1fr]">
        <SourcePanel sourceDb={sourceDb} />

        <div className="flex items-center justify-center lg:flex-col">
          <span className="flex h-11 w-11 items-center justify-center rounded-full border border-black/[0.08] bg-white shadow-card">
            <ArrowRight className="hidden h-5 w-5 text-brand-dark lg:block" strokeWidth={2} />
            <ArrowDown className="h-5 w-5 text-brand-dark lg:hidden" strokeWidth={2} />
          </span>
          <span className="mt-2 hidden text-center text-[10px] font-bold tracking-wider text-surface-400 uppercase lg:block">
            schema
            <br />+ data
            <br />+ semantics
          </span>
        </div>

        <SnowflakeConnectionPicker
          selected={selected}
          onSelect={setSelected}
          setUnsavedChanges={setUnsavedChanges}
          readyMessage="Target ready — migrated tables and the semantic model land here."
        />
      </div>

      {/* migration plan summary + continue */}
      <div className="mt-6 rounded-2xl border border-black/[0.08] bg-white p-4 shadow-card">
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm">
          <span className="font-bold text-surface-800">Plan</span>
          <span className="flex items-center gap-1.5">
            {sourceReady ? (
              <CheckCircle2 className="h-4 w-4 text-brand-dark" strokeWidth={2} />
            ) : (
              <AlertTriangle className="h-4 w-4 text-brand-amber" strokeWidth={2} />
            )}
            <span className="text-surface-600">
              {needsMigration
                ? selectedSource
                  ? `Migrate ${sourceDb!.tables.length} tables from ${selectedSource.name}`
                  : `Source connection needed (${detectedLabel} detected)`
                : selectedSource
                  ? `Source on standby: ${selectedSource.name}`
                  : 'No source migration — report already reads Snowflake'}
            </span>
          </span>
          <span className="flex items-center gap-1.5">
            {selected ? (
              <CheckCircle2 className="h-4 w-4 text-brand-dark" strokeWidth={2} />
            ) : (
              <AlertTriangle className="h-4 w-4 text-brand-amber" strokeWidth={2} />
            )}
            <span className="text-surface-600">
              {selected ? 'Target Snowflake selected' : 'Pick the target Snowflake connection'}
            </span>
          </span>
          <button
            onClick={() => selected && setConnection(selected)}
            disabled={!selected || !sourceReady}
            title={
              !selected
                ? 'Select the target Snowflake connection'
                : !sourceReady
                  ? 'Connect the source database this report reads'
                  : ''
            }
            className="btn-primary ml-auto"
          >
            Continue →
          </button>
        </div>
      </div>
    </section>
  )
}

/* ------------------------------------------------------------------ */
/* SOURCE panel: the database the report reads today                    */
/* ------------------------------------------------------------------ */

function SourcePanel({ sourceDb }: { sourceDb?: ConversionSummary['source_database'] }) {
  const queryClient = useQueryClient()
  const sourceConnectionId = useWizard((s) => s.sourceConnectionId)
  const setSourceConnection = useWizard((s) => s.setSourceConnection)
  const copyData = useWizard((s) => s.copyData)
  const setCopyData = useWizard((s) => s.setCopyData)
  const detected = sourceDb?.needs_migration ? sourceDb : undefined
  const detectedDb = detected?.tables.find((t) => t.database)?.database
  const [showForm, setShowForm] = useState(false)
  const [testMsg, setTestMsg] = useState('')

  const kindsQuery = useQuery({ queryKey: ['source-kinds'], queryFn: api.listSourceKinds })
  const sources = useQuery({
    queryKey: ['source-connections'],
    queryFn: api.listSourceConnections,
  })
  const kinds = kindsQuery.data ?? []
  const saved = sources.data ?? []

  const [form, setForm] = useState<NewSourceConnection>({
    name: '',
    kind: 'sqlserver',
    host: '',
    port: SOURCE_DEFAULT_PORTS.sqlserver,
    database: '',
    user: '',
    password: '',
  })

  // detection resolves after mount — prefill untouched fields only
  useEffect(() => {
    if (!detected) return
    setForm((f) => ({
      ...f,
      kind: f.host ? f.kind : (detected.kind as NewSourceConnection['kind']),
      port: f.host ? f.port : (SOURCE_DEFAULT_PORTS[detected.kind] ?? null),
      database: f.database || (detectedDb ?? ''),
    }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [detected?.kind, detectedDb])

  const create = useMutation({
    mutationFn: () =>
      api.createSourceConnection({
        ...form,
        name: form.name || `${SOURCE_KIND_LABELS[form.kind] ?? form.kind} · ${form.database}`,
      }),
    onSuccess: async (profile) => {
      setSourceConnection(profile.id)
      setShowForm(false)
      await queryClient.invalidateQueries({ queryKey: ['source-connections'] })
    },
  })
  const remove = useMutation({
    mutationFn: (id: string) => api.deleteSourceConnection(id),
    onSuccess: async (_d, id) => {
      if (sourceConnectionId === id) setSourceConnection(null)
      await queryClient.invalidateQueries({ queryKey: ['source-connections'] })
    },
  })
  const test = useMutation({
    mutationFn: (id: string) => api.testSourceConnection(id),
    onSuccess: () => setTestMsg('Connection OK — source reachable.'),
    onError: (e) => setTestMsg((e as Error).message),
  })

  // a report bound to one database kind only ever migrates from that kind
  const visible = detected ? saved.filter((s) => s.kind === detected.kind) : saved
  const showFormNow = showForm || visible.length === 0

  return (
    <div
      data-testid="source-migration-panel"
      className="flex flex-col rounded-2xl border border-black/[0.08] bg-white shadow-card"
    >
      <div className="flex items-center gap-3 rounded-t-2xl border-b border-black/[0.06] bg-gradient-to-r from-brand-amber/10 to-transparent px-5 py-4">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-amber/15">
          <Database className="h-5 w-5 text-brand-amber" strokeWidth={1.8} />
        </span>
        <div className="min-w-0">
          <div className="text-[10px] font-bold tracking-wider text-brand-amber uppercase">
            Source
          </div>
          <h3 className="truncate font-bold">Where the report reads data today</h3>
        </div>
      </div>

      <div className="flex-1 p-5">
        {detected ? (
          <div className="mb-4 flex items-center gap-3 rounded-xl border border-brand-amber/25 bg-brand-amber/5 px-3 py-2.5 text-sm">
            <span className="text-surface-600">Detected:</span>
            <span className="badge-blue !text-sm">
              {SOURCE_KIND_LABELS[detected.kind] ?? detected.kind}
            </span>
            {detectedDb && <span className="font-semibold text-surface-800">{detectedDb}</span>}
            <span className="ml-auto text-xs text-surface-500">Connect to it below</span>
          </div>
        ) : (
          <p className="mb-4 rounded-xl bg-surface-100 p-3 text-sm text-surface-600">
            Reads Snowflake — no source needed.
          </p>
        )}

        {visible.length > 0 && !showFormNow && (
          <div className="space-y-2">
            {visible.map((s) => (
              <label
                key={s.id}
                className="flex cursor-pointer items-center gap-3 rounded-xl border border-black/[0.08] p-3 text-sm transition-colors has-[:checked]:border-brand-amber has-[:checked]:bg-brand-amber/5"
              >
                <input
                  type="radio"
                  name="source-connection"
                  checked={sourceConnectionId === s.id}
                  onChange={() => setSourceConnection(s.id)}
                />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2">
                    <span className="truncate font-semibold">{s.name}</span>
                    <span className="badge-blue shrink-0">
                      {SOURCE_KIND_LABELS[s.kind] ?? s.kind}
                    </span>
                  </span>
                  <span className="block truncate text-xs text-surface-500">
                    {s.host} · {s.database}
                  </span>
                </span>
                <button
                  type="button"
                  className="btn-secondary !px-2.5 !py-1 !text-xs"
                  disabled={test.isPending}
                  onClick={(e) => {
                    e.preventDefault()
                    setTestMsg('')
                    test.mutate(s.id)
                  }}
                >
                  Test
                </button>
                <button
                  type="button"
                  aria-label={`Delete ${s.name}`}
                  className="rounded-lg p-1.5 text-surface-400 hover:bg-brand-red/10 hover:text-brand-red"
                  onClick={(e) => {
                    e.preventDefault()
                    remove.mutate(s.id)
                  }}
                >
                  <Trash2 className="h-3.5 w-3.5" strokeWidth={2} />
                </button>
              </label>
            ))}
            {testMsg && <p className="text-xs text-surface-600">{testMsg}</p>}
            <div className="flex items-center gap-4 pt-1">
              <button
                type="button"
                onClick={() => setShowForm(true)}
                className="text-xs font-semibold text-brand-dark underline"
              >
                + New source connection
              </button>
              {sourceConnectionId && !detected && (
                <button
                  type="button"
                  onClick={() => setSourceConnection(null)}
                  className="text-xs text-surface-500 underline"
                >
                  Clear selection
                </button>
              )}
            </div>
          </div>
        )}

        {showFormNow && (
          <form
            className="grid gap-3 sm:grid-cols-2"
            onSubmit={(e) => {
              e.preventDefault()
              create.mutate()
            }}
          >
            {detected ? (
              // detected kind is definitive — no picker needed
              <input type="hidden" value={form.kind} />
            ) : (
              <Field label="Database type" wide>
                <select
                  className="input"
                  value={form.kind}
                  onChange={(e) => {
                    const kind = e.target.value as NewSourceConnection['kind']
                    setForm({ ...form, kind, port: SOURCE_DEFAULT_PORTS[kind] ?? null })
                  }}
                >
                  {(kinds.length
                    ? kinds
                    : Object.entries(SOURCE_KIND_LABELS).map(([id, label]) => ({
                        id,
                        label,
                        available: true,
                      }))
                  ).map((k) => (
                    <option key={k.id} value={k.id} disabled={!k.available}>
                      {k.label}
                      {!k.available ? ' (driver not installed)' : ''}
                    </option>
                  ))}
                </select>
              </Field>
            )}
            <Field label="Host">
              <input
                required
                className="input"
                placeholder="db-host.corp.local"
                value={form.host}
                onChange={(e) => setForm({ ...form, host: e.target.value })}
              />
            </Field>
            <Field label="Port">
              <input
                type="number"
                className="input"
                value={form.port ?? ''}
                onChange={(e) =>
                  setForm({ ...form, port: e.target.value ? Number(e.target.value) : null })
                }
              />
            </Field>
            <Field label="Database">
              <input
                required
                className="input"
                value={form.database}
                onChange={(e) => setForm({ ...form, database: e.target.value })}
              />
            </Field>
            <Field label="User">
              <input
                required
                className="input"
                value={form.user}
                onChange={(e) => setForm({ ...form, user: e.target.value })}
              />
            </Field>
            <Field label="Password" wide>
              <input
                required
                type="password"
                className="input"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
            </Field>
            <div className="col-span-2 flex items-center gap-3">
              <button type="submit" className="btn-primary" disabled={create.isPending}>
                Save source connection
              </button>
              {saved.length > 0 && (
                <button type="button" className="btn-secondary" onClick={() => setShowForm(false)}>
                  Cancel
                </button>
              )}
              {create.isError && (
                <span className="text-xs text-brand-red">{create.error.message}</span>
              )}
            </div>
          </form>
        )}

        {sourceConnectionId && !showFormNow && (
          <>
            <p className="mt-3 flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
              <CheckCircle2 className="h-3.5 w-3.5" /> Source ready
              {detected ? ' — objects migrate during conversion.' : ' (on standby).'}
            </p>
            <label
              className="mt-2 flex cursor-pointer items-start gap-2 rounded-lg border border-surface-300 bg-surface-50 px-3 py-2"
              data-testid="copy-data-toggle"
            >
              <input
                type="checkbox"
                className="mt-0.5"
                checked={copyData}
                onChange={(e) => setCopyData(e.target.checked)}
              />
              <span className="text-xs text-surface-700">
                <strong>Copy data during migration</strong>
                <span className="mt-0.5 block text-surface-500">
                  Off = schema-only: tables, views &amp; procedures are created and the report
                  is rebound, but rows are provisioned by your own pipeline. Validation of
                  numbers waits until data lands.
                </span>
              </span>
            </label>
          </>
        )}
      </div>
    </div>
  )
}

function Field({
  label,
  children,
  wide,
}: {
  label: string
  children: React.ReactNode
  wide?: boolean
}) {
  return (
    <label className={`flex flex-col gap-1 text-sm ${wide ? 'col-span-2' : ''}`}>
      <span className="font-semibold text-surface-700">{label}</span>
      {children}
    </label>
  )
}

const SOURCE_KIND_LABELS: Record<string, string> = {
  sqlserver: 'SQL Server',
  postgres: 'PostgreSQL',
  mysql: 'MySQL',
  oracle: 'Oracle',
}

const SOURCE_DEFAULT_PORTS: Record<string, number> = {
  sqlserver: 1433,
  postgres: 5432,
  mysql: 3306,
  oracle: 1521,
}
