import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { FabricReviewStep } from '../steps/fabric/FabricReviewStep'
import { useFabricWizard } from '../store/fabricWizard'

function renderStep() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <FabricReviewStep />
    </QueryClientProvider>,
  )
}

const pipeline = {
  id: 'p1',
  has_semantic_model: false,
  artifacts: [
    {
      id: 'a1',
      relative_path: 'notebooks/gold.ipynb',
      kind: 'notebook',
      size_bytes: 100,
      cells: [{ index: 0, cell_type: 'code', source: "x.write.saveAsTable('sales')" }],
      sql_text: null,
      layer: 'skip',
      schedule: '',
      notes: '',
      reviewed: false,
    },
    {
      id: 'a2',
      relative_path: 'notebooks/gold.pbip',
      kind: 'pbip',
      size_bytes: 50,
      cells: [],
      sql_text: null,
      layer: 'skip',
      schedule: '',
      notes: '',
      reviewed: false,
    },
  ],
  warnings: ['docs/Readme.md: ignored reference material'],
}

describe('FabricReviewStep', () => {
  beforeEach(() => useFabricWizard.getState().reset())
  afterEach(() => vi.restoreAllMocks())

  it('renders artifacts, warnings, and lets the user edit layer/schedule', async () => {
    let lastPatch: Record<string, unknown> | null = null
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.includes('/artifacts/a1') && init?.method === 'PATCH') {
          lastPatch = JSON.parse(String(init.body))
          const updated = {
            ...pipeline,
            artifacts: pipeline.artifacts.map((a) =>
              a.id === 'a1' ? { ...a, ...lastPatch } : a,
            ),
          }
          return new Response(JSON.stringify(updated))
        }
        if (url.endsWith('/fabric-pipelines/p1')) return new Response(JSON.stringify(pipeline))
        return new Response(JSON.stringify({}), { status: 404 })
      }),
    )

    useFabricWizard.getState().setPipeline('p1')
    renderStep()

    await waitFor(() => expect(screen.getByText('notebooks/gold.ipynb')).toBeInTheDocument())
    expect(screen.getByText(/1 warning/)).toBeInTheDocument()
    // the pbip artifact isn't editable -- no layer/schedule controls for it
    expect(screen.queryByLabelText('Layer for notebooks/gold.pbip')).not.toBeInTheDocument()

    const user = userEvent.setup()
    await user.selectOptions(screen.getByLabelText('Layer for notebooks/gold.ipynb'), 'gold')
    await waitFor(() => expect(lastPatch).toEqual({ layer: 'gold' }))

    await user.click(screen.getByLabelText('Reviewed: notebooks/gold.ipynb'))
    await waitFor(() => expect(lastPatch).toEqual({ reviewed: true }))
  })

  it('disables Continue until at least one artifact is reviewed', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        if (url.endsWith('/fabric-pipelines/p1')) return new Response(JSON.stringify(pipeline))
        return new Response(JSON.stringify({}), { status: 404 })
      }),
    )
    useFabricWizard.getState().setPipeline('p1')
    renderStep()
    await waitFor(() =>
      expect(screen.getByRole('button', { name: /continue to build plan/i })).toBeDisabled(),
    )
  })

  const unhandledTranslation = {
    artifact_id: 'a1',
    cells: [
      {
        cell_index: 0,
        tier: 'unhandled',
        statements: [],
        reason: "unsupported expression for column 'results'",
      },
    ],
  }

  it('prompts to set a connection before offering tier 3', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        if (url.endsWith('/fabric-pipelines/p1')) return new Response(JSON.stringify(pipeline))
        if (url.includes('/translation')) return new Response(JSON.stringify(unhandledTranslation))
        return new Response(JSON.stringify({}), { status: 404 })
      }),
    )
    useFabricWizard.getState().setPipeline('p1')
    renderStep()

    const user = userEvent.setup()
    await waitFor(() => expect(screen.getByText('notebooks/gold.ipynb')).toBeInTheDocument())
    await user.click(screen.getByLabelText('Expand translation preview'))

    await waitFor(() =>
      expect(screen.getByText(/set a snowflake connection on the build step/i)).toBeInTheDocument(),
    )
    expect(screen.queryByRole('button', { name: /try tier 3/i })).not.toBeInTheDocument()
  })

  it('runs tier 3 and shows the accepted result', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.endsWith('/fabric-pipelines/p1')) return new Response(JSON.stringify(pipeline))
        if (url.includes('/translation')) return new Response(JSON.stringify(unhandledTranslation))
        if (url.includes('/cells/0/tier3') && init?.method === 'POST') {
          return new Response(
            JSON.stringify({
              cell_index: 0,
              sql: 'SELECT * FROM LATERAL FLATTEN(input => x)',
              accepted: true,
              attempts: 2,
              trace: ['attempt 1: rejected non-SELECT statement', 'attempt 2: executed OK'],
            }),
          )
        }
        return new Response(JSON.stringify({}), { status: 404 })
      }),
    )
    useFabricWizard.getState().setPipeline('p1')
    useFabricWizard.getState().setConnection('conn-1')
    renderStep()

    const user = userEvent.setup()
    await waitFor(() => expect(screen.getByText('notebooks/gold.ipynb')).toBeInTheDocument())
    await user.click(screen.getByLabelText('Expand translation preview'))
    await waitFor(() => expect(screen.getByRole('button', { name: /try tier 3/i })).toBeInTheDocument())

    await user.click(screen.getByRole('button', { name: /try tier 3/i }))
    await waitFor(() => expect(screen.getByText(/accepted after 2 attempts/i)).toBeInTheDocument())
    expect(screen.getByText(/LATERAL FLATTEN/)).toBeInTheDocument()
  })
})
