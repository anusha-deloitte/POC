import { useQuery } from '@tanstack/react-query'
import { AlertTriangle, CheckCircle2, Cloud, FileUp, Inbox, PlusCircle } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { fabricPipelinesApi, type FabricPipelineJob } from '../api/fabricPipelines'
import { useFabricWizard } from '../store/fabricWizard'

function fmtTime(ts: number): string {
  return new Date(ts * 1000).toLocaleString(undefined, {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

type ReviewState = 'nothing_to_build' | 'needs_review' | 'reviewed'

function reviewState(job: FabricPipelineJob): ReviewState {
  if (job.buildable_count === 0) return 'nothing_to_build'
  if (job.reviewed_count < job.buildable_count) return 'needs_review'
  return 'reviewed'
}

function StatusBadge({ job }: { job: FabricPipelineJob }) {
  const state = reviewState(job)
  if (state === 'reviewed')
    return (
      <span className="badge-green inline-flex items-center gap-1">
        <CheckCircle2 size={12} /> Reviewed
      </span>
    )
  if (state === 'needs_review')
    return (
      <span className="badge-amber inline-flex items-center gap-1">
        <AlertTriangle size={12} /> Needs review
      </span>
    )
  return (
    <span className="badge-blue inline-flex items-center gap-1">
      <FileUp size={12} /> Nothing to build
    </span>
  )
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div
      className={`rounded-xl border p-4 shadow-card ${accent ? 'border-brand/25 bg-brand/5' : 'border-black/[0.06] bg-surface-50'}`}
    >
      <div className="text-[10px] font-bold tracking-wider text-surface-500 uppercase">{label}</div>
      <div className={`mt-1 text-2xl font-bold ${accent ? 'text-brand-dark' : ''}`}>{value}</div>
    </div>
  )
}

export function FabricJobs() {
  const nav = useNavigate()
  const resume = useFabricWizard((s) => s.resume)

  const jobs = useQuery({
    queryKey: ['fabric-jobs'],
    queryFn: () => fabricPipelinesApi.listJobs(),
    refetchInterval: 15000,
  })

  const rows = jobs.data ?? []
  const needsReview = rows.filter((r) => reviewState(r) === 'needs_review').length
  const reviewed = rows.filter((r) => reviewState(r) === 'reviewed').length

  const openJob = (job: FabricPipelineJob) => {
    resume(job.id, 'review')
    nav('/app/fabric')
  }

  const startNew = () => {
    resume(null, 'upload')
    nav('/app/fabric')
  }

  return (
    <section>
      <div className="mb-6 flex items-end justify-between overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div>
          <div className="kicker mb-1">Workspace</div>
          <h2 className="text-xl font-bold">Fabric migration jobs</h2>
          <p className="mt-1 text-sm text-surface-600">
            {rows.length} pipeline{rows.length === 1 ? '' : 's'} · {reviewed} ready to build
          </p>
        </div>
        <button onClick={startNew} className="btn-primary inline-flex shrink-0 items-center gap-2">
          <PlusCircle size={16} /> New Fabric pipeline
        </button>
      </div>

      <div className="mb-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Stat label="Reviewed" value={String(reviewed)} accent />
        <Stat label="Needs review" value={String(needsReview)} />
        <Stat
          label="With semantic model"
          value={String(rows.filter((r) => r.has_semantic_model).length)}
        />
        <Stat label="With warnings" value={String(rows.filter((r) => r.warning_count > 0).length)} />
      </div>

      <div className="overflow-hidden rounded-xl border border-black/[0.06] shadow-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-black/[0.06] bg-surface-50 text-left text-xs font-bold tracking-wider text-surface-500 uppercase">
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Pipeline</th>
              <th className="px-4 py-3">Artifacts</th>
              <th className="px-4 py-3">Semantic model</th>
              <th className="px-4 py-3">Uploaded</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 && (
              <tr>
                <td colSpan={6} className="px-4 py-10 text-center text-surface-500">
                  <Inbox className="mx-auto mb-2 h-6 w-6" strokeWidth={1.8} />
                  No Fabric pipelines uploaded yet.
                </td>
              </tr>
            )}
            {rows.map((job) => (
              <tr
                key={job.id}
                className="cursor-pointer border-b border-black/[0.04] last:border-0 hover:bg-surface-50"
                onClick={() => openJob(job)}
              >
                <td className="px-4 py-3">
                  <StatusBadge job={job} />
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2 font-semibold">
                    <Cloud className="h-4 w-4 shrink-0 text-brand-blue" strokeWidth={1.8} />
                    {job.name ?? 'Untitled pipeline'}
                  </div>
                  <div className="font-mono text-[11px] text-surface-400">{job.id.slice(0, 8)}</div>
                </td>
                <td className="px-4 py-3 text-surface-600">
                  {job.reviewed_count}/{job.buildable_count} reviewed · {job.artifact_count} total
                </td>
                <td className="px-4 py-3 text-surface-600">{job.has_semantic_model ? 'Yes' : 'No'}</td>
                <td className="px-4 py-3 text-surface-600">{fmtTime(job.uploaded_at)}</td>
                <td className="px-4 py-3 text-right">
                  <button
                    type="button"
                    className="rounded-md bg-brand px-2 py-1 text-xs font-semibold text-white hover:bg-brand-dark"
                    onClick={(e) => {
                      e.stopPropagation()
                      openJob(job)
                    }}
                  >
                    Open
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}
