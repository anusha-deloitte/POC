import { create } from 'zustand'

/** A separate step machine from ./wizard.ts's WizardStep — the Fabric
 * migration flow (WS1-WS5) is a parallel top-level route (/app/fabric), not
 * a branch of the existing PBI-conversion wizard, so it gets its own store
 * rather than extending WizardStep's fixed union. */
export type FabricStep = 'upload' | 'review' | 'build' | 'export'

export const FABRIC_STEP_ORDER: FabricStep[] = ['upload', 'review', 'build', 'export']

interface FabricWizardState {
  step: FabricStep
  pipelineId: string | null
  connectionId: string | null
  hasUnsavedChanges: boolean
  unsavedContext: string | null
  setStep: (s: FabricStep) => void
  setPipeline: (id: string) => void
  setConnection: (id: string) => void
  resume: (pipelineId: string | null, step: FabricStep) => void
  setUnsavedChanges: (dirty: boolean, context?: string | null) => void
  confirmDiscardChanges: () => boolean
  reset: () => void
}

const LAST_CONNECTION_KEY = 'pbic.fabric_connection_id'

export const useFabricWizard = create<FabricWizardState>()((set, get) => ({
  step: 'upload',
  pipelineId: null,
  connectionId: localStorage.getItem(LAST_CONNECTION_KEY),
  hasUnsavedChanges: false,
  unsavedContext: null,
  setStep: (step) =>
    set((state) => {
      if (state.step === step) return state
      if (state.hasUnsavedChanges) {
        const prompt = `You have unsaved ${state.unsavedContext ?? 'changes'}. Leave this step and discard them?`
        if (!window.confirm(prompt)) return state
      }
      return { ...state, step, hasUnsavedChanges: false, unsavedContext: null }
    }),
  setPipeline: (pipelineId) =>
    set({ pipelineId, step: 'review', hasUnsavedChanges: false, unsavedContext: null }),
  setConnection: (connectionId) => {
    localStorage.setItem(LAST_CONNECTION_KEY, connectionId)
    set({ connectionId })
  },
  resume: (pipelineId, step) =>
    set({ pipelineId, step, hasUnsavedChanges: false, unsavedContext: null }),
  setUnsavedChanges: (hasUnsavedChanges, unsavedContext = null) =>
    set({ hasUnsavedChanges, unsavedContext }),
  confirmDiscardChanges: (): boolean => {
    const state = get()
    if (!state.hasUnsavedChanges) return true
    const prompt = `You have unsaved ${state.unsavedContext ?? 'changes'}. Discard and continue?`
    const confirmed = window.confirm(prompt)
    if (confirmed) set({ hasUnsavedChanges: false, unsavedContext: null })
    return confirmed
  },
  reset: () =>
    set({ step: 'upload', pipelineId: null, hasUnsavedChanges: false, unsavedContext: null }),
}))
