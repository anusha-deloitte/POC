import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from app.api.auth import router as auth_router
from app.api.client_logs import router as client_logs_router
from app.api.connections import router as connections_router
from app.api.conversions import router as conversions_router
from app.api.dashboards import router as dashboards_router
from app.api.deps import get_snowflake_session_manager
from app.api.explain import router as explain_router
from app.api.fabric_pipeline import router as fabric_pipeline_router
from app.api.governance import router as governance_router
from app.api.published_dashboards import admin_router as dashboard_publications_router
from app.api.published_dashboards import router as published_dashboards_router
from app.api.semantic_deploy import router as semantic_deploy_router
from app.api.source_connections import router as source_connections_router
from app.core.config import get_settings
from app.core.logging import configure_logging, get_logger, log_event

configure_logging(get_settings().log_dir, get_settings().log_level)
_request_log = get_logger("request")


@asynccontextmanager
async def lifespan(_app: FastAPI):
    yield
    get_snowflake_session_manager().close_all()

app = FastAPI(
    title="PBI Converter",
    description="Agentic Power BI (.pbip) to React dashboard converter",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:8080"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def log_requests(request: Request, call_next):
    # request/response bodies are never logged here (by design — several
    # routes, e.g. /connections, carry credentials in the body).
    request_id = uuid.uuid4().hex[:12]
    request.state.request_id = request_id
    started = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception as exc:  # noqa: BLE001 - log then re-raise for FastAPI's own handling
        log_event(
            _request_log,
            "error",
            "request_failed",
            request_id=request_id,
            method=request.method,
            path=request.url.path,
            error=str(exc),
            elapsed_ms=round((time.perf_counter() - started) * 1000),
        )
        raise
    log_event(
        _request_log,
        "info",
        "request",
        request_id=request_id,
        method=request.method,
        path=request.url.path,
        status=response.status_code,
        elapsed_ms=round((time.perf_counter() - started) * 1000),
    )
    response.headers["X-Request-Id"] = request_id
    return response

app.include_router(auth_router)
app.include_router(client_logs_router)
app.include_router(conversions_router)
app.include_router(connections_router)
app.include_router(governance_router)
app.include_router(dashboards_router)
app.include_router(semantic_deploy_router)
app.include_router(explain_router)
app.include_router(source_connections_router)
app.include_router(published_dashboards_router)
app.include_router(dashboard_publications_router)
app.include_router(fabric_pipeline_router)


@app.get("/healthz")
def healthz() -> dict:
    return {"status": "ok"}
