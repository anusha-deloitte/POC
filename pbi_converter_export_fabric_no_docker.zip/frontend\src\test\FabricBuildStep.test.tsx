import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { FabricBuildStep } from '../steps/fabric/FabricBuildStep'
import { useFabricWizard } from '../store/fabricWizard'

function renderStep() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <FabricBuildStep />
    </QueryClientProvider>,
  )
}

const plan = {
  schemas: ['TGT__BRONZE'],
  warnings: [],
  items: [
    {
      layer: 'bronze',
      object_kind: 'dynamic_table',
      object_name: 'BRONZE_ORDERS',
      schema_name: 'TGT__BRONZE',
      depends_on: [],
      notes: ["unresolved source 'Files/raw/*.csv'; bind it via source_bindings"],
      ddl: ['CREATE OR REPLACE DYNAMIC TABLE ...'],
    },
  ],
}

const executeResult = {
  plan,
  created: [],
  skipped: ['BRONZE_ORDERS'],
  fidelity: null,
}

describe('FabricBuildStep', () => {
  afterEach(() => vi.restoreAllMocks())

  it('shows skipped items with guidance after executing a build with an unresolved source', async () => {
    useFabricWizard.getState().reset()
    useFabricWizard.getState().setPipeline('p1')
    useFabricWizard.getState().setConnection('conn-1')

    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.includes('/connections')) return new Response(JSON.stringify([{ id: 'conn-1', name: 'My conn' }]))
        if (url.includes('/execute-build') && init?.method === 'POST') {
          return new Response(JSON.stringify(executeResult))
        }
        return new Response(JSON.stringify({}), { status: 404 })
      }),
    )

    renderStep()
    const user = userEvent.setup()
    await user.click(screen.getByRole('button', { name: /execute build/i }))

    await waitFor(() => expect(screen.getByText(/Skipped \(not built\)/i)).toBeInTheDocument())
    expect(screen.getByText(/Skipped \(not built\): BRONZE_ORDERS/)).toBeInTheDocument()
    expect(screen.getByText(/couldn't be resolved to a real Snowflake table/i)).toBeInTheDocument()
  })

  it('auto-fills a source binding row for an unresolved source and sends it on re-execute', async () => {
    useFabricWizard.getState().reset()
    useFabricWizard.getState().setPipeline('p1')
    useFabricWizard.getState().setConnection('conn-1')

    const bodies: Record<string, unknown>[] = []
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.includes('/connections')) return new Response(JSON.stringify([{ id: 'conn-1', name: 'My conn' }]))
        if (url.includes('/execute-build') && init?.method === 'POST') {
          bodies.push(JSON.parse(String(init.body)))
          return new Response(JSON.stringify(executeResult))
        }
        return new Response(JSON.stringify({}), { status: 404 })
      }),
    )

    renderStep()
    const user = userEvent.setup()
    await user.click(screen.getByRole('button', { name: /execute build/i }))
    await waitFor(() => expect(screen.getByText(/Skipped \(not built\)/i)).toBeInTheDocument())

    // the unresolved source from the plan's notes is auto-added as a row
    const pathInput = screen.getByLabelText('Source path 1') as HTMLInputElement
    expect(pathInput.value).toBe('Files/raw/*.csv')
    expect(bodies[0]).toEqual({ connection_id: 'conn-1', source_bindings: {} })

    await user.type(screen.getByLabelText(/Snowflake table for Files\/raw/), '"DB"."RAW"."ORDERS_CSV"')
    await user.click(screen.getByRole('button', { name: /execute build/i }))

    await waitFor(() => expect(bodies).toHaveLength(2))
    expect(bodies[1]).toEqual({
      connection_id: 'conn-1',
      source_bindings: { 'Files/raw/*.csv': '"DB"."RAW"."ORDERS_CSV"' },
    })
  })
})
