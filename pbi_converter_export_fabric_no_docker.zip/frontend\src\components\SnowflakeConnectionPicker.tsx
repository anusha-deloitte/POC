import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { AlertTriangle, CheckCircle2, Database, Snowflake, Trash2 } from 'lucide-react'
import { useEffect, useState } from 'react'
import { api } from '../api/client'
import type { AuthMethod, ConnectionProfile, ConnectionTestResult, NewConnection } from '../api/types'

const AUTH_LABELS: Record<AuthMethod, string> = {
  key_pair: 'Key pair (JWT) — recommended',
  external_browser: 'External browser (SSO)',
  password: 'Username & password',
  oauth_client_credentials: 'OAuth client credentials',
  pat: 'Programmatic access token',
}

interface SourceType {
  id: string
  label: string
  available: boolean
}

/** Shared "pick or create a Snowflake connection" panel — used by the
 * PBI-conversion wizard's ConnectStep (as its TARGET panel) and the Fabric
 * migration wizard's Build step, so both flows offer the same connection
 * establishment experience rather than one being a bare <select>. */
export function SnowflakeConnectionPicker({
  selected,
  onSelect,
  setUnsavedChanges,
  readyMessage = 'Connection ready.',
}: {
  selected: string | null
  onSelect: (id: string) => void
  setUnsavedChanges: (dirty: boolean, context?: string | null) => void
  readyMessage?: string
}) {
  const queryClient = useQueryClient()
  const [showNew, setShowNew] = useState(false)

  const existing = useQuery({ queryKey: ['connections'], queryFn: api.listConnections })
  const remove = useMutation({
    mutationFn: (id: string) => api.deleteConnection(id),
    onSuccess: async (_d, id) => {
      if (selected === id) onSelect('')
      await queryClient.invalidateQueries({ queryKey: ['connections'] })
    },
  })
  const noConnections = existing.data !== undefined && existing.data.length === 0
  const showFormNow = showNew || noConnections

  return (
    <div
      data-testid="target-panel"
      className="flex flex-col rounded-2xl border border-black/[0.08] bg-white shadow-card"
    >
      <div className="flex items-center gap-3 rounded-t-2xl border-b border-black/[0.06] bg-gradient-to-r from-brand-blue/10 to-transparent px-5 py-4">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-blue/10">
          <Snowflake className="h-5 w-5 text-brand-blue" strokeWidth={1.8} />
        </span>
        <div className="min-w-0">
          <div className="text-[10px] font-bold tracking-wider text-brand-blue uppercase">
            Snowflake connection
          </div>
          <h3 className="truncate font-bold">Where this runs</h3>
        </div>
      </div>

      <div className="flex-1 p-5">
        {existing.isLoading && <p className="text-sm text-surface-500">Loading connections…</p>}

        {existing.data && existing.data.length > 0 && !showFormNow && (
          <div className="space-y-2">
            {existing.data.map((c) => (
              <ConnectionRow
                key={c.id}
                c={c}
                checked={selected === c.id}
                onPick={() => onSelect(c.id)}
                onDelete={() => remove.mutate(c.id)}
                deleting={remove.isPending}
              />
            ))}
            <div className="pt-1">
              <button
                type="button"
                onClick={() => setShowNew(true)}
                className="text-xs font-semibold text-brand-dark underline"
              >
                + New Snowflake connection
              </button>
            </div>
            {remove.isError && (
              <p role="alert" className="text-xs text-brand-red">
                {remove.error.message}
              </p>
            )}
          </div>
        )}

        {showFormNow && (
          <NewConnectionForm
            setUnsavedChanges={setUnsavedChanges}
            onBack={noConnections ? undefined : () => setShowNew(false)}
            onDone={(id) => {
              onSelect(id)
              setShowNew(false)
            }}
          />
        )}

        {selected && !showFormNow && (
          <p className="mt-3 flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
            <CheckCircle2 className="h-3.5 w-3.5" /> {readyMessage}
          </p>
        )}
      </div>
    </div>
  )
}

function ConnectionRow({
  c,
  checked,
  onPick,
  onDelete,
  deleting,
}: {
  c: ConnectionProfile
  checked: boolean
  onPick: () => void
  onDelete: () => void
  deleting: boolean
}) {
  const queryClient = useQueryClient()
  const usesBrowser = c.auth_method === 'external_browser'
  const session = useQuery({
    queryKey: ['connection-session', c.id],
    queryFn: () => api.connectionSession(c.id),
    enabled: usesBrowser,
  })
  const authenticate = useMutation({
    mutationFn: () => api.testConnection(c.id),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['connection-session', c.id] })
    },
  })
  const ready = !usesBrowser || session.data?.authenticated === true

  return (
    <label className="flex items-center gap-3 rounded-xl border border-black/[0.08] p-3 text-sm transition-colors has-[:checked]:border-brand has-[:checked]:bg-brand/5">
      <input
        type="radio"
        name="target-connection"
        checked={checked}
        disabled={!ready}
        onChange={onPick}
      />
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2">
          <span className="truncate font-semibold">{c.name}</span>
          <span className="badge-blue shrink-0">Snowflake</span>
        </span>
        <span className="block truncate text-xs text-surface-500">
          {c.account}
          {c.database ? ` · ${c.database}` : ''}
          {c.schema_name ? ` · ${c.schema_name}` : ''}
        </span>
        {usesBrowser && !ready && (
          <>
            <button
              type="button"
              className="mt-2 text-xs font-semibold text-brand-dark underline"
              disabled={authenticate.isPending}
              onClick={(event) => {
                event.preventDefault()
                authenticate.mutate()
              }}
            >
              {authenticate.isPending ? 'Complete sign-in in your browser…' : 'Authenticate'}
            </button>
            {authenticate.data && !authenticate.data.ok && (
              <span role="alert" className="mt-1 block text-xs text-brand-red">
                Snowflake could not start browser sign-in: {authenticate.data.error}
              </span>
            )}
            {authenticate.isError && (
              <span role="alert" className="mt-1 block text-xs text-brand-red">
                Authentication request failed: {authenticate.error.message}
              </span>
            )}
          </>
        )}
      </span>
      <button
        type="button"
        aria-label={`Delete ${c.name}`}
        className="rounded-lg p-1.5 text-surface-400 hover:bg-brand-red/10 hover:text-brand-red"
        disabled={deleting}
        onClick={(e) => {
          e.preventDefault()
          onDelete()
        }}
      >
        <Trash2 className="h-3.5 w-3.5" strokeWidth={2} />
      </button>
    </label>
  )
}

function NewConnectionForm({
  onBack,
  onDone,
  setUnsavedChanges,
}: {
  onBack?: () => void
  onDone: (id: string) => void
  setUnsavedChanges: (dirty: boolean, context?: string | null) => void
}) {
  const queryClient = useQueryClient()
  const [sourceType, setSourceType] = useState('snowflake')
  const [form, setForm] = useState<NewConnection>({
    name: '',
    account: '',
    user: '',
    auth_method: 'key_pair',
    database: '',
    schema: '',
  })
  const [testResult, setTestResult] = useState<ConnectionTestResult | null>(null)
  const [createdId, setCreatedId] = useState<string | null>(null)

  const sourceTypes = useQuery({
    queryKey: ['source-types'],
    queryFn: async (): Promise<SourceType[]> => {
      const res = await fetch('/api/v1/connections/source-types')
      if (!res.ok) return [{ id: 'snowflake', label: 'Snowflake', available: true }]
      return res.json()
    },
  })

  const create = useMutation({
    mutationFn: (spec: NewConnection) => api.createConnection(spec),
    onSuccess: (profile) => {
      setCreatedId(profile.id)
      void queryClient.invalidateQueries({ queryKey: ['connections'] })
      test.mutate(profile.id)
    },
  })
  const test = useMutation({
    mutationFn: (id: string) => api.testConnection(id),
    onSuccess: setTestResult,
  })

  const set = (patch: Partial<NewConnection>) => setForm((f) => ({ ...f, ...patch }))
  const chosen = sourceTypes.data?.find((s) => s.id === sourceType)
  const unavailable = chosen ? !chosen.available : false

  useEffect(() => {
    const hasManualInput =
      !!form.name ||
      !!form.account ||
      !!form.user ||
      !!form.database ||
      !!form.schema ||
      !!form.role ||
      !!form.warehouse ||
      !!form.password ||
      !!form.private_key_pem ||
      !!form.private_key_passphrase ||
      !!form.oauth_client_id ||
      !!form.oauth_client_secret ||
      !!form.oauth_token_url ||
      !!form.pat_token
    setUnsavedChanges(hasManualInput, hasManualInput ? 'connection form edits' : null)
    return () => setUnsavedChanges(false, null)
  }, [form, setUnsavedChanges])

  return (
    <div className="card p-6">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-sm font-bold">
          <Database className="h-4 w-4 text-brand-dark" strokeWidth={1.8} />
          New connection
        </h3>
        {onBack && (
          <button onClick={onBack} className="text-xs font-semibold text-surface-500 hover:text-surface-800">
            ← Back to existing connections
          </button>
        )}
      </div>

      <form
        className="grid grid-cols-2 gap-4"
        onSubmit={(e) => {
          e.preventDefault()
          create.mutate(form)
        }}
      >
        <Field label="Data source" wide>
          <select
            value={sourceType}
            onChange={(e) => setSourceType(e.target.value)}
            className="input"
          >
            {(sourceTypes.data ?? []).map((s) => (
              <option key={s.id} value={s.id}>
                {s.label}
                {s.available ? '' : ' — coming soon'}
              </option>
            ))}
          </select>
        </Field>

        {unavailable && (
          <div className="col-span-2 rounded-xl border border-brand-amber/25 bg-brand-amber/5 p-3 text-sm text-surface-700">
            <strong className="text-brand-amber">{chosen?.label}</strong> support is on the
            roadmap — the connector framework is source-agnostic. For this workspace, use
            Snowflake.
          </div>
        )}

        {!unavailable && (
          <>
            <Field label="Connection name">
              <input required value={form.name} onChange={(e) => set({ name: e.target.value })} className="input" />
            </Field>
            <Field label="Account identifier">
              <input
                required
                placeholder="orgname-account"
                value={form.account}
                onChange={(e) => set({ account: e.target.value })}
                className="input"
              />
            </Field>
            <Field label="User">
              <input required value={form.user} onChange={(e) => set({ user: e.target.value })} className="input" />
            </Field>
            <Field label="Default database">
              <input
                required
                value={form.database}
                onChange={(e) => set({ database: e.target.value })}
                className="input"
              />
            </Field>
            <Field label="Default schema">
              <input
                required
                value={form.schema}
                onChange={(e) => set({ schema: e.target.value })}
                className="input"
              />
            </Field>
            <Field label="Authentication">
              <select
                value={form.auth_method}
                onChange={(e) => set({ auth_method: e.target.value as AuthMethod })}
                className="input"
              >
                {Object.entries(AUTH_LABELS).map(([v, label]) => (
                  <option key={v} value={v}>
                    {label}
                  </option>
                ))}
              </select>
              {form.auth_method === 'external_browser' && (
                <span className="mt-1 block text-xs text-surface-500">
                  Requires federated SSO to be configured for this Snowflake account.
                </span>
              )}
            </Field>

            {form.auth_method === 'password' && (
              <Field label="Password">
                <input
                  required
                  type="password"
                  value={form.password ?? ''}
                  onChange={(e) => set({ password: e.target.value })}
                  className="input"
                />
              </Field>
            )}
            {form.auth_method === 'key_pair' && (
              <>
                <Field label="Private key (PEM)" wide>
                  <textarea
                    required
                    rows={4}
                    value={form.private_key_pem ?? ''}
                    onChange={(e) => set({ private_key_pem: e.target.value })}
                    className="input font-mono text-xs"
                  />
                </Field>
                <Field label="Key passphrase (optional)">
                  <input
                    type="password"
                    value={form.private_key_passphrase ?? ''}
                    onChange={(e) => set({ private_key_passphrase: e.target.value })}
                    className="input"
                  />
                </Field>
              </>
            )}
            {form.auth_method === 'oauth_client_credentials' && (
              <>
                <Field label="Client ID">
                  <input
                    required
                    value={form.oauth_client_id ?? ''}
                    onChange={(e) => set({ oauth_client_id: e.target.value })}
                    className="input"
                  />
                </Field>
                <Field label="Client secret">
                  <input
                    required
                    type="password"
                    value={form.oauth_client_secret ?? ''}
                    onChange={(e) => set({ oauth_client_secret: e.target.value })}
                    className="input"
                  />
                </Field>
                <Field label="Token URL" wide>
                  <input
                    required
                    value={form.oauth_token_url ?? ''}
                    onChange={(e) => set({ oauth_token_url: e.target.value })}
                    className="input"
                  />
                </Field>
              </>
            )}
            {form.auth_method === 'pat' && (
              <Field label="Access token">
                <input
                  required
                  type="password"
                  value={form.pat_token ?? ''}
                  onChange={(e) => set({ pat_token: e.target.value })}
                  className="input"
                />
              </Field>
            )}

            <Field label="Role (optional)">
              <input value={form.role ?? ''} onChange={(e) => set({ role: e.target.value })} className="input" />
            </Field>
            <Field label="Warehouse (optional)">
              <input
                value={form.warehouse ?? ''}
                onChange={(e) => set({ warehouse: e.target.value })}
                className="input"
              />
            </Field>

            <div className="col-span-2 flex items-center gap-3">
              <button type="submit" disabled={create.isPending || test.isPending} className="btn-primary">
                {create.isPending || test.isPending
                  ? form.auth_method === 'external_browser'
                    ? 'Complete sign-in in your browser…'
                    : 'Testing…'
                  : form.auth_method === 'external_browser'
                    ? 'Save & authenticate'
                    : 'Save & test connection'}
              </button>
              {createdId && testResult && (
                <span
                  role="status"
                  className={`text-sm font-medium ${testResult.ok ? 'text-brand-dark' : 'text-brand-amber'}`}
                >
                  {testResult.ok
                    ? `Connected in ${testResult.latency_ms} ms (${testResult.warehouse ?? 'no warehouse'})`
                    : `Warning: saved, but probe failed: ${testResult.error}`}
                </span>
              )}
              {createdId && test.isError && (
                <span role="status" className="text-sm text-brand-amber">
                  Warning: saved, but probe failed: {test.error.message}
                </span>
              )}
            </div>
            {create.isError && (
              <div
                role="alert"
                className="col-span-2 rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red"
              >
                <div className="flex items-start gap-2">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.8} />
                  <div>
                    <div className="font-semibold">Blocking error: connection was not saved.</div>
                    <p className="mt-1">{create.error.message}</p>
                    <p className="mt-1 text-xs text-surface-600">
                      Review account, auth method, and required credentials, then retry.
                    </p>
                  </div>
                </div>
              </div>
            )}
            {createdId &&
              (form.auth_method !== 'external_browser' || testResult?.ok) && (
              <button type="button" onClick={() => onDone(createdId)} className="btn-secondary col-span-2">
                Continue with this connection →
              </button>
              )}
          </>
        )}
      </form>
    </div>
  )
}

function Field({
  label,
  children,
  wide,
}: {
  label: string
  children: React.ReactNode
  wide?: boolean
}) {
  return (
    <label className={`flex flex-col gap-1 text-sm ${wide ? 'col-span-2' : ''}`}>
      <span className="font-semibold text-surface-700">{label}</span>
      {children}
    </label>
  )
}
