"""WS2 tier 3: LLM-assisted, execution-validated translation for cells
tier 1/tier 2 can't reach -- same propose/execute/validate/retry shape as
agents/tier2.py, tested the same way (fake LLM client + fake cursor)."""

from app.agents.fabric_tier3 import propose_and_validate


class _FakeCursor:
    def __init__(self, fail_sql_substrings: set[str] | None = None):
        self.executed: list[str] = []
        self._fail = fail_sql_substrings or set()

    def execute(self, sql):
        self.executed.append(sql)
        if any(bad in sql for bad in self._fail):
            raise ValueError("simulated execution failure")

    def fetchall(self):
        return [(1,)]


class TestProposeAndValidate:
    def test_accepts_first_valid_select(self):
        class FakeLLM:
            def chat(self, messages, **kwargs):
                return '{"sql": "SELECT * FROM (SELECT 1) LATERAL FLATTEN(input => x)"}'

        cur = _FakeCursor()
        result = propose_and_validate(4, "df = df.withColumn('results', explode('results'))", "unsupported expression for column 'results'", cur, client=FakeLLM())
        assert result.accepted
        assert result.attempts == 1
        assert result.sql and "FLATTEN" in result.sql

    def test_rejects_non_select_then_accepts(self):
        responses = iter(['{"sql": "DROP TABLE x"}', '{"sql": "SELECT 1"}'])

        class FakeLLM:
            def chat(self, messages, **kwargs):
                return next(responses)

        cur = _FakeCursor()
        result = propose_and_validate(0, "some code", "reason", cur, client=FakeLLM())
        assert result.accepted
        assert result.attempts == 2
        assert any("rejected non-SELECT" in t for t in result.trace)

    def test_execution_error_feeds_retry(self):
        responses = iter(['{"sql": "SELECT bad_col"}', '{"sql": "SELECT 1"}'])

        class FakeLLM:
            def chat(self, messages, **kwargs):
                return next(responses)

        cur = _FakeCursor(fail_sql_substrings={"bad_col"})
        result = propose_and_validate(0, "some code", "reason", cur, client=FakeLLM())
        assert result.accepted
        assert result.attempts == 2
        assert any("execution failed" in t for t in result.trace)

    def test_model_declares_impossible(self):
        class FakeLLM:
            def chat(self, messages, **kwargs):
                return '{"error": "needs real data to know the schema"}'

        cur = _FakeCursor()
        result = propose_and_validate(0, "some code", "reason", cur, client=FakeLLM())
        assert not result.accepted
        assert result.sql is None
        assert result.attempts == 1

    def test_exhausts_attempts_and_gives_up(self):
        class FakeLLM:
            def chat(self, messages, **kwargs):
                return '{"sql": "SELECT bad_col"}'

        cur = _FakeCursor(fail_sql_substrings={"bad_col"})
        result = propose_and_validate(0, "some code", "reason", cur, client=FakeLLM())
        assert not result.accepted
        assert result.attempts == 3

    def test_unparseable_response_retries_then_gives_up(self):
        class FakeLLM:
            def chat(self, messages, **kwargs):
                return "not json at all"

        cur = _FakeCursor()
        result = propose_and_validate(0, "some code", "reason", cur, client=FakeLLM())
        assert not result.accepted
        assert any("unparseable" in t for t in result.trace)

    def test_no_horizon_client_configured(self, monkeypatch):
        import app.services.horizon_client as hc

        monkeypatch.setattr(hc, "build_client_from_settings", lambda: None)
        cur = _FakeCursor()
        result = propose_and_validate(0, "some code", "reason", cur, client=None)
        assert not result.accepted
        assert result.attempts == 0
        assert "not configured" in result.trace[0]
