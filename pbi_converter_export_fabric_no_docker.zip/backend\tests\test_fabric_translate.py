"""WS2: Fabric notebook/script -> Snowflake SQL translation engine."""

from pathlib import Path

import pytest

from app.services.fabric_notebooks import FabricArtifact, NotebookCell
from app.services.fabric_translate import (
    TranslationTier,
    translate_notebook,
    translate_sql_artifact,
)

_CMS_SAMPLE = (
    Path.home()
    / "OneDrive - Deloitte (O365D)"
    / "Desktop"
    / "Repositories"
    / "fabric-samples-healthcare"
    / "analytics-bi-directlake-starschema"
)


def _artifact(cells: list[tuple[str, str]]) -> FabricArtifact:
    return FabricArtifact(
        id="a1",
        relative_path="nb.ipynb",
        kind="notebook",
        cells=[
            NotebookCell(index=i, cell_type=ct, source=src) for i, (ct, src) in enumerate(cells)
        ],
    )


class TestSqlTier:
    def test_spark_sql_literal_extracted_and_transpiled(self):
        artifact = _artifact(
            [
                ("code", "df = spark.sql(\"SELECT DISTINCT Year FROM bronze_table\")\ndisplay(df)"),
                ("code", "df.write.mode('overwrite').saveAsTable('dim_year')"),
            ]
        )
        result = translate_notebook(artifact)
        dataframe_cells = [c for c in result.cells if c.tier == TranslationTier.DATAFRAME]
        assert len(dataframe_cells) == 1
        stmt = dataframe_cells[0].statements[0]
        assert stmt.target_table == "dim_year"
        assert "SELECT" in stmt.sql.upper()
        assert "bronze_table".upper() in stmt.sql.upper()

    def test_window_function_and_group_by_transpile_cleanly(self):
        sql = (
            "SELECT Brnd_Name, MAX(Year) AS Max_Year, "
            "row_number() OVER (ORDER BY Brnd_Name ASC) AS drug_key "
            "FROM cms_provider_drug_costs GROUP BY Brnd_Name"
        )
        artifact = _artifact([("code", f"dim_drug_df = spark.sql('''{sql}''')")])
        result = translate_notebook(artifact)
        # untouched spark.sql frame with no further chain -> no saveAsTable
        # in this cell, so nothing emitted yet (no error either)
        assert all(c.tier != TranslationTier.UNHANDLED for c in result.cells)

    def test_tsql_if_not_exists_sysobjects_normalized(self):
        artifact = FabricArtifact(
            id="a2",
            relative_path="scripts/create.sql",
            kind="sql",
            sql_text=(
                "IF NOT EXISTS (SELECT * FROM sysobjects WHERE name = 'provider_dim' AND xtype = 'U') "
                "BEGIN CREATE TABLE provider_dim (id INT, name VARCHAR(100)) END"
            ),
        )
        result = translate_sql_artifact(artifact, source_kind="tsql")
        assert result.cells[0].tier == TranslationTier.SQL
        sql = result.cells[0].statements[0].sql.upper()
        assert "CREATE TABLE IF NOT EXISTS" in sql
        assert "SYSOBJECTS" not in sql

    def test_create_procedure_wrapper_stripped_to_inner_statements(self):
        """Regression: a whole-.sql-file artifact wrapped in CREATE PROCEDURE
        ... AS BEGIN ... END can't be parsed by sqlglot as one statement --
        it silently falls back to treating the body as an opaque blob
        (missing the proc name entirely, per a real reproduction), which
        previously got accepted as a "successful" transpile and executed
        against Snowflake verbatim, causing a live SQL compilation error."""
        artifact = FabricArtifact(
            id="a5",
            relative_path="scripts/usp_CreateAndPopulateDimTables.sql",
            kind="sql",
            sql_text=(
                "CREATE PROCEDURE [dbo].[usp_CreateAndPopulateDimTables]\n"
                "AS\n"
                "BEGIN\n"
                "    -- Step 1: Create Tables\n"
                "    CREATE TABLE dim_x (id INT, name VARCHAR(50));\n"
                "    INSERT INTO dim_x SELECT id, name FROM staging_x;\n"
                "END\n"
            ),
        )
        result = translate_sql_artifact(artifact, source_kind="tsql")
        assert result.cells[0].tier == TranslationTier.SQL
        sql = result.cells[0].statements[0].sql.upper()
        assert "CREATE PROCEDURE" not in sql  # wrapper stripped, not re-emitted garbled
        assert "CREATE TABLE DIM_X" in sql
        assert "INSERT INTO DIM_X" in sql

    def test_command_fallback_treated_as_failed_transpile(self):
        """A statement sqlglot can't really parse (falls back to a generic
        Command node whose .sql() just re-emits something close to the
        original, untranspiled text) must not be silently accepted as a
        successful translation -- that garbage would otherwise get executed
        against Snowflake verbatim."""
        artifact = FabricArtifact(
            id="a6",
            relative_path="scripts/weird_bulk.sql",
            kind="sql",
            sql_text="EXEC sp_configure 'show advanced options', 1",
        )
        result = translate_sql_artifact(artifact, source_kind="tsql")
        assert result.cells[0].tier == TranslationTier.UNHANDLED
        assert result.cells[0].statements[0].note

    def test_plain_insert_select_sproc_body_transpiles(self):
        artifact = FabricArtifact(
            id="a3",
            relative_path="scripts/load_provider.sql",
            kind="sql",
            sql_text="INSERT INTO gold.provider_dim SELECT id, name FROM silver.provider WHERE active = 1",
        )
        result = translate_sql_artifact(artifact, source_kind="tsql")
        assert result.cells[0].tier == TranslationTier.SQL
        assert "INSERT INTO" in result.cells[0].statements[0].sql.upper()

    def test_unparseable_sql_falls_back_with_note(self):
        artifact = FabricArtifact(
            id="a4", relative_path="scripts/weird.sql", kind="sql", sql_text="THIS IS NOT ; VALID SQL ((("
        )
        result = translate_sql_artifact(artifact, source_kind="tsql")
        assert result.cells[0].tier == TranslationTier.UNHANDLED
        assert result.cells[0].statements[0].note


class TestExternalIngestion:
    def test_http_download_cell_classified_and_skipped(self):
        artifact = _artifact(
            [("code", "import requests\nr = requests.get('https://example.com/data.csv')\nopen('f.csv','wb').write(r.content)")]
        )
        result = translate_notebook(artifact)
        assert result.cells[0].tier == TranslationTier.EXTERNAL_INGESTION


class TestIPythonMagics:
    @pytest.mark.parametrize(
        "source",
        [
            "%pip install semantic-link==0.12.1 semantic-link-labs==0.9.10",
            "%load_ext autoreload",
            "%%capture\nsome_setup_call()",
            "%%time\nx = 1",
            "!pip install requests",
        ],
    )
    def test_magic_and_shell_escape_cells_are_noop_not_unhandled(self, source):
        artifact = _artifact([("code", source)])
        result = translate_notebook(artifact)
        assert result.cells[0].tier == TranslationTier.NOOP


class TestDataFrameTier:
    def test_cast_concat_and_drop(self):
        cells = [
            (
                "code",
                "df = spark.read.format('csv').option('header','true').load('Files/cms_raw/*.csv')"
                ".withColumn('file_path', input_file_name())",
            ),
            (
                "code",
                "df = df.withColumn('Tot_Drug_Cst', df.Tot_Drug_Cst.cast(DecimalType(10,2))) \\\n"
                "        .withColumn('Prscrbr_City_State', concat(df.Prscrbr_City, lit(', '), df.Prscrbr_State)) \\\n"
                "        .drop('file_path')",
            ),
            ("code", "df.write.mode('overwrite').saveAsTable('cms_provider_drug_costs')"),
        ]
        result = translate_notebook(_artifact(cells))
        df_cells = [c for c in result.cells if c.tier == TranslationTier.DATAFRAME]
        assert len(df_cells) == 1
        sql = df_cells[0].statements[0].sql
        assert df_cells[0].statements[0].target_table == "cms_provider_drug_costs"
        # file_path was only ever a virtual (withColumn-added) column in this
        # chain -- it was never part of the real source's `*`, so dropping it
        # just means "don't add it": no EXCLUDE needed, and it never appears.
        assert "EXCLUDE" not in sql
        assert '"file_path"' not in sql
        assert "REPLACE" in sql
        assert 'CAST("Tot_Drug_Cst" AS NUMBER(10,2)) AS "Tot_Drug_Cst"' in sql
        assert 'CONCAT("Prscrbr_City", \', \', "Prscrbr_State") AS "Prscrbr_City_State"' in sql
        assert "{{source: Files/cms_raw/*.csv}}" in sql

    def test_filename_derived_year_udf_idiom(self):
        cells = [
            ("code", "source_dir = 'Files/cms_raw'"),
            (
                "code",
                "import os\nfrom urllib.parse import urlparse\n"
                "def extract_year_from_file_name(path):\n"
                "    parsed_url = urlparse(path)\n"
                "    file_name_with_extension = os.path.basename(parsed_url.path)\n"
                "    file_name, extension = os.path.splitext(file_name_with_extension)\n"
                "    return int(file_name)\n",
            ),
            (
                "code",
                "from pyspark.sql.functions import udf\nfrom pyspark.sql.types import IntegerType\n"
                "extract_year_from_file_name_udf = udf(extract_year_from_file_name, IntegerType())",
            ),
            (
                "code",
                "df = spark.read.format('csv').load(source_dir + '/*.csv')"
                ".withColumn('file_path', input_file_name())",
            ),
            ("code", "df = df.withColumn('Year', extract_year_from_file_name_udf(df['file_path']))"),
            ("code", "df.write.mode('overwrite').saveAsTable('cms_data')"),
        ]
        result = translate_notebook(_artifact(cells))
        df_cells = [c for c in result.cells if c.tier == TranslationTier.DATAFRAME]
        assert len(df_cells) == 1
        sql = df_cells[0].statements[0].sql
        assert "REGEXP_SUBSTR" in sql
        assert "METADATA$FILENAME" in sql
        assert "{{source: Files/cms_raw/*.csv}}" in sql

    def test_unsupported_join_falls_to_unhandled(self):
        cells = [
            ("code", "a = spark.sql('SELECT * FROM t1')"),
            ("code", "b = a.join(other_df, 'id')"),
            ("code", "b.write.saveAsTable('joined')"),
        ]
        result = translate_notebook(_artifact(cells))
        assert any(c.tier == TranslationTier.UNHANDLED for c in result.cells)

    def test_non_literal_with_column_name_falls_to_unhandled(self):
        cells = [
            ("code", "a = spark.sql('SELECT * FROM t1')"),
            ("code", "col_name = 'x'\nb = a.withColumn(col_name, lit(1))"),
            ("code", "b.write.saveAsTable('t2')"),
        ]
        result = translate_notebook(_artifact(cells))
        assert any(c.tier == TranslationTier.UNHANDLED for c in result.cells)


@pytest.mark.skipif(not _CMS_SAMPLE.is_dir(), reason="external reference fixture not present")
class TestRealCmsSample:
    def _load(self, name: str) -> FabricArtifact:
        from app.services.fabric_notebooks import _parse_notebook

        warnings: list[str] = []
        cells = _parse_notebook(_CMS_SAMPLE / name, warnings)
        assert not warnings
        return FabricArtifact(id=name, relative_path=name, kind="notebook", cells=cells)

    def test_gold_star_schema_notebook_all_sql_transpiles(self):
        artifact = self._load("03-CreateCMSStarSchemaTables.ipynb")
        result = translate_notebook(artifact)
        assert not any(c.tier == TranslationTier.UNHANDLED for c in result.cells)
        save_cells = [c for c in result.cells if c.tier == TranslationTier.DATAFRAME]
        target_tables = {s.target_table for c in save_cells for s in c.statements}
        assert target_tables == {
            "cms_provider_dim_year",
            "cms_provider_dim_geography",
            "cms_provider_dim_provider",
            "cms_provider_dim_drug",
            "cms_provider_drug_costs_star",
        }

    def test_silver_layer_notebook_dataframe_chain_translates(self):
        artifact = self._load("02-CreateCMSDataTable.ipynb")
        result = translate_notebook(artifact)
        save_cells = [c for c in result.cells if c.tier == TranslationTier.DATAFRAME]
        assert len(save_cells) == 1
        stmt = save_cells[0].statements[0]
        assert stmt.target_table == "cms_provider_drug_costs"
        assert "REGEXP_SUBSTR" in stmt.sql
        assert "METADATA$FILENAME" in stmt.sql
        # file_path was only a virtual (withColumn-added) column feeding the
        # Year expression -- METADATA$FILENAME is inlined directly wherever
        # it's referenced, and dropping it afterwards needs no EXCLUDE since
        # it was never part of the real source's `*`.
        assert "EXCLUDE" not in stmt.sql
        assert '"file_path"' not in stmt.sql

    def test_sproc_scripts_transpile(self):
        for name in ("01_CMS_provider_dimensions_SPROC.sql", "02_CMS_provider_fact_SPROC.sql"):
            text = (_CMS_SAMPLE / "scripts" / name).read_text(encoding="utf-8")
            artifact = FabricArtifact(id=name, relative_path=f"scripts/{name}", kind="sql", sql_text=text)
            result = translate_sql_artifact(artifact, source_kind="tsql")
            assert result.cells[0].statements[0].sql.strip()
