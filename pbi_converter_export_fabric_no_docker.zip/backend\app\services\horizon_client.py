"""Client for Elevance Health's internal "Horizon" LLM gateway.

Not OpenAI-SDK-compatible: OAuth2 client-credentials auth against a JSON
token endpoint, then POST /v2/text/chats with the model tier chosen via
`provider`/`qos`/`reasoning` query params (no `model` field in the body).
Response shape is `{"message": {"role": ..., "content": ...}}`.

Credentials and the bearer token are never logged: every log call here goes
through log_event(), and `client_secret`/`token`-shaped keys are redacted
there regardless (backend/app/core/logging.py's _SECRET_KEYS).
"""

from __future__ import annotations

import base64
import time
from dataclasses import dataclass
from threading import Lock
from typing import Any

import httpx

from app.core.logging import get_logger, log_event

_logger = get_logger("horizon")

# refresh this many seconds before the token actually expires
_TOKEN_EXPIRY_MARGIN_SECONDS = 60


class HorizonError(Exception):
    pass


@dataclass
class _CachedToken:
    access_token: str
    expires_at: float  # time.monotonic() deadline


class _RateLimiter:
    """Caps calls to N per rolling `per_seconds` window; blocks (sleeps) past it."""

    def __init__(self, max_requests: int, per_seconds: float = 60.0):
        self._max = max_requests
        self._window = per_seconds
        self._timestamps: list[float] = []
        self._lock = Lock()

    def acquire(self) -> None:
        with self._lock:
            now = time.monotonic()
            self._timestamps = [t for t in self._timestamps if now - t < self._window]
            if len(self._timestamps) >= self._max:
                wait = self._window - (now - self._timestamps[0])
                if wait > 0:
                    time.sleep(wait)
                now = time.monotonic()
                self._timestamps = [t for t in self._timestamps if now - t < self._window]
            self._timestamps.append(now)


def image_content_part(image_bytes: bytes, mime: str = "image/png") -> dict:
    return {
        "type": "image",
        "image": {
            "type": "base64",
            "format": mime,
            "data": base64.b64encode(image_bytes).decode(),
        },
    }


def text_content_part(text: str) -> dict:
    return {"type": "text", "text": text}


class HorizonClient:
    """One instance per process is fine — token and rate-limit state are shared."""

    def __init__(
        self,
        base_url: str,
        client_id: str,
        client_secret: str,
        default_qos: str = "accurate",
        max_requests_per_minute: int = 15,
        timeout: float = 60.0,
        verify: bool = True,
    ):
        self._base_url = base_url.rstrip("/")
        self._client_id = client_id
        self._client_secret = client_secret
        self.default_qos = default_qos
        if not verify:
            # explicit, opt-in only (PBIC_HORIZON_VERIFY_SSL=false) — disables
            # TLS certificate AND hostname verification for every request,
            # including the ones carrying client_secret/bearer tokens. Logged
            # loudly on purpose so this is never a silent downgrade.
            log_event(
                _logger,
                "warning",
                "horizon_tls_verification_disabled",
                base_url=self._base_url,
            )
        self._http = httpx.Client(timeout=timeout, verify=verify)
        self._token: _CachedToken | None = None
        self._token_lock = Lock()
        self._limiter = _RateLimiter(max_requests_per_minute)

    def _get_token(self) -> str:
        with self._token_lock:
            if self._token is not None and time.monotonic() < self._token.expires_at:
                return self._token.access_token
            resp = self._http.post(
                f"{self._base_url}/v2/oauth2/token",
                json={
                    "client_id": self._client_id,
                    "client_secret": self._client_secret,
                    "grant_type": "client_credentials",
                },
                headers={"Content-Type": "application/json"},
            )
            resp.raise_for_status()
            body = resp.json()
            expires_in = int(body.get("expires_in", 300))
            self._token = _CachedToken(
                access_token=body["access_token"],
                expires_at=time.monotonic() + max(0, expires_in - _TOKEN_EXPIRY_MARGIN_SECONDS),
            )
            log_event(_logger, "info", "horizon_token_refreshed", expires_in=expires_in)
            return self._token.access_token

    def chat(
        self,
        messages: list[dict[str, Any]],
        qos: str | None = None,
        reasoning: bool = False,
        max_retries: int = 3,
    ) -> str:
        """Sends `messages` (OpenAI-style role/content list; content may be a
        string or a list of text/image content parts) and returns the reply text."""
        params = {
            "provider": "openai",
            "qos": qos or self.default_qos,
            "reasoning": "true" if reasoning else "false",
        }
        body = {"Messages": messages, "stream": False}
        last_error: Exception | None = None

        for attempt in range(1, max_retries + 1):
            self._limiter.acquire()
            token = self._get_token()
            started = time.perf_counter()
            try:
                resp = self._http.post(
                    f"{self._base_url}/v2/text/chats",
                    params=params,
                    json=body,
                    headers={
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/json",
                    },
                )
            except httpx.HTTPError as e:
                last_error = e
                log_event(
                    _logger, "error", "horizon_chat_failed", attempt=attempt, error=str(e)
                )
                if attempt < max_retries:
                    time.sleep(1.5 * attempt)
                    continue
                raise HorizonError(f"Horizon chat request failed: {e}") from e

            elapsed_ms = round((time.perf_counter() - started) * 1000)
            if resp.status_code == 429:
                retry_after = float(resp.headers.get("Retry-After", 2 * attempt))
                log_event(
                    _logger,
                    "warning",
                    "horizon_rate_limited",
                    attempt=attempt,
                    retry_after=retry_after,
                )
                if attempt < max_retries:
                    time.sleep(retry_after)
                    continue
                raise HorizonError("Horizon chat failed: rate limited after retries")

            if resp.status_code >= 500 and attempt < max_retries:
                log_event(
                    _logger,
                    "warning",
                    "horizon_server_error_retrying",
                    status=resp.status_code,
                    attempt=attempt,
                )
                time.sleep(1.5 * attempt)
                continue

            try:
                resp.raise_for_status()
            except httpx.HTTPStatusError as e:
                log_event(
                    _logger,
                    "error",
                    "horizon_chat_failed",
                    status=resp.status_code,
                    attempt=attempt,
                    elapsed_ms=elapsed_ms,
                )
                raise HorizonError(f"Horizon chat failed: {e}") from e

            data = resp.json()
            content = data.get("message", {}).get("content", "")
            log_event(
                _logger,
                "info",
                "horizon_chat",
                qos=params["qos"],
                reasoning=params["reasoning"],
                attempt=attempt,
                elapsed_ms=elapsed_ms,
            )
            return content or ""

        raise HorizonError(f"Horizon chat failed after {max_retries} attempts: {last_error}")

    def close(self) -> None:
        self._http.close()


def build_client_from_settings() -> HorizonClient | None:
    """Returns None (LLM features disabled) if credentials aren't configured."""
    from app.core.config import get_settings

    s = get_settings()
    if not (s.horizon_client_id and s.horizon_client_secret):
        return None
    return HorizonClient(
        base_url=s.horizon_base_url,
        client_id=s.horizon_client_id,
        client_secret=s.horizon_client_secret,
        default_qos=s.horizon_qos,
        max_requests_per_minute=s.horizon_max_requests_per_minute,
        verify=s.horizon_verify_ssl,
    )
