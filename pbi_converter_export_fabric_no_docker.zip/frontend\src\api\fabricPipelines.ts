import { handle, readErrorDetail } from './client'
import { reportClientError } from './errorReporting'

const BASE = '/api/v1/fabric-pipelines'

export type FabricArtifactKind = 'notebook' | 'sql' | 'pbip' | 'other'
export type FabricLayer = 'bronze' | 'silver' | 'gold' | 'skip'

export interface NotebookCell {
  index: number
  cell_type: 'code' | 'markdown' | 'raw'
  source: string
}

export interface FabricArtifact {
  id: string
  relative_path: string
  kind: FabricArtifactKind
  size_bytes: number
  cells: NotebookCell[]
  sql_text: string | null
  layer: FabricLayer
  schedule: string
  notes: string
  reviewed: boolean
}

export interface FabricPipeline {
  id: string
  has_semantic_model: boolean
  artifacts: FabricArtifact[]
  warnings: string[]
}

export interface FabricPipelineJob {
  id: string
  name: string | null
  artifact_count: number
  buildable_count: number
  reviewed_count: number
  has_semantic_model: boolean
  warning_count: number
  uploaded_at: number
}

export type TranslationTier = 'sql' | 'dataframe' | 'external_ingestion' | 'unhandled' | 'noop'

export interface TranslatedStatement {
  target_table: string | null
  sql: string
  note: string
}

export interface CellResult {
  cell_index: number
  tier: TranslationTier
  statements: TranslatedStatement[]
  reason: string
}

export interface ArtifactTranslation {
  artifact_id: string
  cells: CellResult[]
}

export type BuildObjectKind = 'transient_table' | 'dynamic_table' | 'task_proc'

export interface BuildPlanItem {
  artifact_id: string
  artifact_path: string
  layer: string
  schema_name: string
  object_kind: BuildObjectKind
  object_name: string
  ddl: string[]
  depends_on: string[]
  notes: string[]
}

export interface BuildPlan {
  schemas: string[]
  items: BuildPlanItem[]
  warnings: string[]
}

export type FidelityMismatchKind = 'missing_in_snowflake' | 'type_mismatch'

export interface FidelityMismatch {
  column: string
  kind: FidelityMismatchKind
  expected_type: string | null
  actual_type: string | null
}

export interface TableFidelityResult {
  table: string
  matched: boolean
  mismatches: FidelityMismatch[]
}

export interface FidelityReport {
  results: TableFidelityResult[]
  skipped_tables: string[]
}

export interface ExecuteBuildResult {
  plan: BuildPlan
  created: string[]
  skipped: string[]
  fidelity: FidelityReport | null
}

export type ConnectivityMode = 'import' | 'directQuery'

export interface ExportPbipResult {
  blob: Blob
  repointedTables: string[]
}

export interface Tier3Result {
  cell_index: number
  sql: string | null
  accepted: boolean
  attempts: number
  trace: string[]
}

export const fabricPipelinesApi = {
  upload(file: File, pipelineId?: string): Promise<FabricPipeline> {
    const form = new FormData()
    form.append('file', file)
    if (pipelineId) form.append('conversion_id', pipelineId)
    return fetch(BASE, { method: 'POST', body: form }).then((r) => handle<FabricPipeline>(r))
  },

  get(pipelineId: string): Promise<FabricPipeline> {
    return fetch(`${BASE}/${pipelineId}`).then((r) => handle<FabricPipeline>(r))
  },

  listJobs(): Promise<FabricPipelineJob[]> {
    return fetch(`${BASE}/jobs`).then((r) => handle<FabricPipelineJob[]>(r))
  },

  updateArtifact(
    pipelineId: string,
    artifactId: string,
    patch: Partial<Pick<FabricArtifact, 'layer' | 'schedule' | 'notes' | 'reviewed'>>,
  ): Promise<FabricPipeline> {
    return fetch(`${BASE}/${pipelineId}/artifacts/${artifactId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    }).then((r) => handle<FabricPipeline>(r))
  },

  previewTranslation(pipelineId: string, artifactId: string): Promise<ArtifactTranslation> {
    return fetch(`${BASE}/${pipelineId}/artifacts/${artifactId}/translation`).then((r) =>
      handle<ArtifactTranslation>(r),
    )
  },

  previewBuildPlan(
    pipelineId: string,
    connectionId: string,
    sourceBindings?: Record<string, string>,
  ): Promise<BuildPlan> {
    return fetch(`${BASE}/${pipelineId}/build-plan`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ connection_id: connectionId, source_bindings: sourceBindings ?? {} }),
    }).then((r) => handle<BuildPlan>(r))
  },

  executeBuild(
    pipelineId: string,
    connectionId: string,
    sourceBindings?: Record<string, string>,
  ): Promise<ExecuteBuildResult> {
    return fetch(`${BASE}/${pipelineId}/execute-build`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ connection_id: connectionId, source_bindings: sourceBindings ?? {} }),
    }).then((r) => handle<ExecuteBuildResult>(r))
  },

  async exportPbip(
    pipelineId: string,
    connectionId: string,
    mode: ConnectivityMode,
    sourceBindings?: Record<string, string>,
  ): Promise<ExportPbipResult> {
    const response = await fetch(`${BASE}/${pipelineId}/export-pbip`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        connection_id: connectionId,
        mode,
        source_bindings: sourceBindings ?? {},
      }),
    })
    if (!response.ok) {
      const message = await readErrorDetail(response)
      reportClientError({ message, path: response.url, status: response.status, context: 'export-pbip' })
      throw new Error(message)
    }
    // read the header before consuming the body — a Response's headers stay
    // readable after .blob(), but there's no ambiguity risk being explicit here.
    const repointedTables = (response.headers.get('X-Repointed-Tables') ?? '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
    const blob = await response.blob()
    return { blob, repointedTables }
  },

  runTier3(
    pipelineId: string,
    artifactId: string,
    cellIndex: number,
    connectionId: string,
  ): Promise<Tier3Result> {
    return fetch(`${BASE}/${pipelineId}/artifacts/${artifactId}/cells/${cellIndex}/tier3`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ connection_id: connectionId }),
    }).then((r) => handle<Tier3Result>(r))
  },
}
