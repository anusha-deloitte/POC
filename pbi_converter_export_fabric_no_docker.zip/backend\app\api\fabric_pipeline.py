"""WS1: Fabric artifact ingestion + human layer-tagging review."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, Form, HTTPException, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel

from app.agents.fabric_tier3 import propose_and_validate as tier3_propose_and_validate
from app.api.deps import (
    get_connection_store,
    get_fabric_pipeline_store,
    get_ingest_service,
    require_token,
)
from app.core.config import get_settings
from app.services.connections import ConnectionStore
from app.services.fabric_build import BuildPlan, execute_build_plan, plan_build
from app.services.fabric_fidelity import FidelityReport, compare_schema, describe_built_tables
from app.services.fabric_notebooks import (
    FabricPipeline,
    FabricPipelineError,
    FabricPipelineStore,
    Layer,
)
from app.services.fabric_translate import (
    ArtifactTranslation,
    translate_notebook,
    translate_sql_artifact,
)
from app.services.ingest import IngestError, IngestService
from app.services.pbip_writer import PbipWriteError, repoint_pbip_project, zip_directory

router = APIRouter(
    prefix="/api/v1/fabric-pipelines",
    tags=["fabric-pipeline"],
    dependencies=[Depends(require_token)],
)


@router.post("", status_code=201)
async def upload_fabric_artifacts(
    file: UploadFile,
    store: Annotated[FabricPipelineStore, Depends(get_fabric_pipeline_store)],
    conversion_id: Annotated[str | None, Form()] = None,
) -> FabricPipeline:
    if not (file.filename or "").endswith(".zip"):
        raise HTTPException(422, "upload a .zip of the Fabric workspace export")
    max_bytes = get_settings().max_upload_bytes
    fd, tmp_name = tempfile.mkstemp(suffix=".zip")
    try:
        with os.fdopen(fd, "wb") as tmp:
            written = 0
            while chunk := await file.read(1024 * 1024):
                written += len(chunk)
                if written > max_bytes:
                    raise HTTPException(413, "upload exceeds size limit")
                tmp.write(chunk)
        try:
            return store.ingest_zip(Path(tmp_name), conversion_id=conversion_id)
        except FabricPipelineError as e:
            raise HTTPException(422, str(e)) from e
        except ValueError as e:
            raise HTTPException(404, "conversion not found") from e
    finally:
        os.unlink(tmp_name)


@router.get("/jobs")
def list_fabric_jobs(
    store: Annotated[FabricPipelineStore, Depends(get_fabric_pipeline_store)],
) -> list[dict]:
    """Every uploaded Fabric export, newest first -- the equivalent of
    /api/v1/conversions/jobs for this flow, since the wizard itself has no
    way to resume a pipeline once you navigate away (its id only ever lived
    in the frontend's in-memory store)."""
    return store.list_pipelines()


@router.get("/{conversion_id}")
def get_fabric_pipeline(
    conversion_id: str,
    store: Annotated[FabricPipelineStore, Depends(get_fabric_pipeline_store)],
) -> FabricPipeline:
    try:
        return store.load(conversion_id)
    except (FabricPipelineError, ValueError) as e:
        raise HTTPException(404, "fabric pipeline not found") from e


class ArtifactReviewUpdate(BaseModel):
    layer: Literal["bronze", "silver", "gold", "skip"] | None = None
    schedule: str | None = None
    notes: str | None = None
    reviewed: bool | None = None


@router.patch("/{conversion_id}/artifacts/{artifact_id}")
def update_artifact_review(
    conversion_id: str,
    artifact_id: str,
    req: ArtifactReviewUpdate,
    store: Annotated[FabricPipelineStore, Depends(get_fabric_pipeline_store)],
) -> FabricPipeline:
    layer: Layer | None = req.layer
    try:
        return store.update_artifact(
            conversion_id,
            artifact_id,
            layer=layer,
            schedule=req.schedule,
            notes=req.notes,
            reviewed=req.reviewed,
        )
    except (FabricPipelineError, ValueError) as e:
        raise HTTPException(404, str(e)) from e


@router.get("/{conversion_id}/artifacts/{artifact_id}/translation")
def preview_artifact_translation(
    conversion_id: str,
    artifact_id: str,
    store: Annotated[FabricPipelineStore, Depends(get_fabric_pipeline_store)],
) -> ArtifactTranslation:
    """WS2 preview: best-effort Snowflake SQL for one notebook/script artifact,
    for human review alongside the layer-tagging grid. Doesn't persist or
    execute anything (that's WS3) -- recomputed fresh on every call."""
    try:
        pipeline = store.load(conversion_id)
    except (FabricPipelineError, ValueError) as e:
        raise HTTPException(404, "fabric pipeline not found") from e
    artifact = next((a for a in pipeline.artifacts if a.id == artifact_id), None)
    if artifact is None:
        raise HTTPException(404, "unknown artifact")
    if artifact.kind == "notebook":
        return translate_notebook(artifact)
    if artifact.kind == "sql":
        return translate_sql_artifact(artifact, source_kind="tsql")
    detail = f"artifact kind {artifact.kind!r} is not a transform, nothing to translate"
    raise HTTPException(422, detail)


class BuildPlanRequest(BaseModel):
    connection_id: str
    source_bindings: dict[str, str] = {}


def _translations_for(pipeline: FabricPipeline) -> dict[str, ArtifactTranslation]:
    translations: dict[str, ArtifactTranslation] = {}
    for artifact in pipeline.artifacts:
        if not artifact.reviewed or artifact.layer == "skip":
            continue
        if artifact.kind == "notebook":
            translations[artifact.id] = translate_notebook(artifact)
        elif artifact.kind == "sql":
            translations[artifact.id] = translate_sql_artifact(artifact, source_kind="tsql")
    return translations


def _resolve_profile(connections: ConnectionStore, connection_id: str):
    try:
        profile = connections.get(connection_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e
    if not profile.database or not profile.schema_name:
        raise HTTPException(422, "connection profile is missing a database/schema")
    return profile


@router.post("/{conversion_id}/build-plan")
def preview_build_plan(
    conversion_id: str,
    req: BuildPlanRequest,
    store: Annotated[FabricPipelineStore, Depends(get_fabric_pipeline_store)],
    connections: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> BuildPlan:
    """WS3 preview: the dependency-ordered Snowflake DDL plan (schemas,
    TRANSIENT tables/Dynamic Tables, stored-proc + Task pairs) that would be
    built from every reviewed, non-skip artifact. Nothing is executed here --
    the Snowflake objects land in the connection profile's own database, per
    decision #13, one schema per medallion layer."""
    try:
        pipeline = store.load(conversion_id)
    except (FabricPipelineError, ValueError) as e:
        raise HTTPException(404, "fabric pipeline not found") from e
    profile = _resolve_profile(connections, req.connection_id)

    # only opens a (read-only DESCRIBE TABLE) connection when there's an
    # external source actually bound -- previewing an unbound plan stays
    # pure computation, no live Snowflake dependency.
    cursor = None
    if req.source_bindings:
        cursor = connections.session_manager.open_cursor(
            req.connection_id, query_tag=f"pbic:fabric-build-preview:{conversion_id}"
        )
    try:
        return plan_build(
            pipeline,
            _translations_for(pipeline),
            target_database=profile.database,
            target_schema=profile.schema_name,
            warehouse=profile.warehouse or "COMPUTE_WH",
            source_bindings=req.source_bindings,
            sf_cursor=cursor,
        )
    finally:
        if cursor is not None:
            cursor.close()


class ExecuteBuildResult(BaseModel):
    plan: BuildPlan
    created: list[str]
    skipped: list[str] = []
    fidelity: FidelityReport | None = None


@router.post("/{conversion_id}/execute-build")
def execute_build(
    conversion_id: str,
    req: BuildPlanRequest,
    store: Annotated[FabricPipelineStore, Depends(get_fabric_pipeline_store)],
    connections: Annotated[ConnectionStore, Depends(get_connection_store)],
    ingest: Annotated[IngestService, Depends(get_ingest_service)],
) -> ExecuteBuildResult:
    """WS3 + WS4: actually build the plan's objects in Snowflake, then (if a
    semantic model was uploaded alongside the Fabric artifacts) run the
    schema/fidelity gate against what actually got created -- block/report
    mismatches rather than silently letting WS5 repoint a report at
    something that doesn't match its model."""
    try:
        pipeline = store.load(conversion_id)
    except (FabricPipelineError, ValueError) as e:
        raise HTTPException(404, "fabric pipeline not found") from e
    profile = _resolve_profile(connections, req.connection_id)

    cursor = connections.session_manager.open_cursor(
        req.connection_id, query_tag=f"pbic:fabric-build:{conversion_id}"
    )
    try:
        plan = plan_build(
            pipeline,
            _translations_for(pipeline),
            target_database=profile.database,
            target_schema=profile.schema_name,
            warehouse=profile.warehouse or "COMPUTE_WH",
            source_bindings=req.source_bindings,
            sf_cursor=cursor,
        )
        created, skipped = execute_build_plan(plan, cursor)

        fidelity = None
        if pipeline.has_semantic_model:
            try:
                bundle = ingest.load_bundle(conversion_id)
            except (IngestError, ValueError):
                bundle = None
            if bundle is not None:
                actual_columns = describe_built_tables(plan, cursor, profile.database, set(skipped))
                fidelity = compare_schema(bundle.model, actual_columns)
    finally:
        cursor.close()  # releases the per-connection session lock (see SnowflakeSessionManager)

    return ExecuteBuildResult(plan=plan, created=created, skipped=skipped, fidelity=fidelity)


class ExportPbipRequest(BaseModel):
    connection_id: str
    mode: Literal["import", "directQuery"] = "directQuery"  # decision #11: default DirectQuery
    source_bindings: dict[str, str] = {}


@router.post("/{conversion_id}/export-pbip")
def export_pbip(
    conversion_id: str,
    req: ExportPbipRequest,
    store: Annotated[FabricPipelineStore, Depends(get_fabric_pipeline_store)],
    connections: Annotated[ConnectionStore, Depends(get_connection_store)],
    ingest: Annotated[IngestService, Depends(get_ingest_service)],
) -> Response:
    """WS5: repoint the real .pbip project's data source (M expression +
    connectivity mode) at the new Snowflake gold-layer objects and return a
    downloadable zip -- mirrors the existing /dashboard/export shape.

    Expects execute-build to have already run (this DESCRIBEs the already-
    built objects; it doesn't build anything itself). Only gold-layer tables
    that both match a model table by name and pass the WS4 fidelity gate get
    repointed -- a mismatched table is left pointing at its original Fabric
    source rather than silently bound to something that doesn't match."""
    try:
        pipeline = store.load(conversion_id)
    except (FabricPipelineError, ValueError) as e:
        raise HTTPException(404, "fabric pipeline not found") from e
    if not pipeline.has_semantic_model:
        raise HTTPException(
            422, "no .pbip project was uploaded with this Fabric pipeline -- nothing to repoint"
        )
    profile = _resolve_profile(connections, req.connection_id)

    plan = plan_build(
        pipeline,
        _translations_for(pipeline),
        target_database=profile.database,
        target_schema=profile.schema_name,
        warehouse=profile.warehouse or "COMPUTE_WH",
        source_bindings=req.source_bindings,
    )
    gold_items = [
        item
        for item in plan.items
        if item.layer == "gold" and item.object_kind in ("transient_table", "dynamic_table")
    ]
    if not gold_items:
        raise HTTPException(422, "no reviewed gold-layer tables to repoint")

    cursor = connections.session_manager.open_cursor(
        req.connection_id, query_tag=f"pbic:fabric-export:{conversion_id}"
    )
    try:
        actual_columns = describe_built_tables(plan, cursor, profile.database)
    finally:
        cursor.close()

    try:
        bundle = ingest.load_bundle(conversion_id)
    except (IngestError, ValueError) as e:
        raise HTTPException(404, "semantic model not found for this conversion") from e
    fidelity = compare_schema(bundle.model, actual_columns)
    matched_tables = {r.table for r in fidelity.results if r.matched}

    # match by name case-insensitively (Snowflake object names are always
    # uppercased -- see BuildPlanItem.object_name -- while PBI table names
    # are typically PascalCase); table_targets keys are the model's own
    # original-cased names, since that's what the .pbip project's own TMDL/
    # bim files are keyed by.
    model_tables_by_upper = {t.name.upper(): t.name for t in bundle.model.tables}
    table_targets: dict[str, str] = {}
    for item in gold_items:
        model_table_name = model_tables_by_upper.get(item.object_name.upper())
        if model_table_name is not None and model_table_name in matched_tables:
            table_targets[model_table_name] = item.object_name
    if not table_targets:
        raise HTTPException(
            422, "no gold-layer table both matches a model table and passes the fidelity gate"
        )

    conversion_dir = store.conversion_dir(conversion_id)
    try:
        repointed = repoint_pbip_project(
            conversion_dir / "fabric_source",
            conversion_dir / "pbip_export",
            table_targets,
            mode=req.mode,
            account=profile.account,
            warehouse=profile.warehouse or "COMPUTE_WH",
            database=profile.database,
            schema=profile.schema_name,
        )
    except PbipWriteError as e:
        raise HTTPException(422, str(e)) from e

    payload = zip_directory(conversion_dir / "pbip_export")
    headers = {
        "Content-Disposition": 'attachment; filename="repointed_pbip.zip"',
        "X-Repointed-Tables": ",".join(repointed),
    }
    return Response(content=payload, media_type="application/zip", headers=headers)


class Tier3Request(BaseModel):
    connection_id: str


class Tier3Response(BaseModel):
    cell_index: int
    sql: str | None
    accepted: bool
    attempts: int
    trace: list[str]


@router.post("/{conversion_id}/artifacts/{artifact_id}/cells/{cell_index}/tier3")
def run_tier3(
    conversion_id: str,
    artifact_id: str,
    cell_index: int,
    req: Tier3Request,
    store: Annotated[FabricPipelineStore, Depends(get_fabric_pipeline_store)],
    connections: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> Tier3Response:
    """WS2 tier 3: for a cell tier 1/tier 2 couldn't translate, ask the
    Horizon LLM gateway for Snowflake SQL and validate it by executing
    against your live connection before accepting -- never ships an
    unverified guess."""
    try:
        pipeline = store.load(conversion_id)
    except (FabricPipelineError, ValueError) as e:
        raise HTTPException(404, "fabric pipeline not found") from e
    artifact = next((a for a in pipeline.artifacts if a.id == artifact_id), None)
    if artifact is None:
        raise HTTPException(404, "unknown artifact")
    if artifact.kind != "notebook":
        raise HTTPException(422, "tier 3 only applies to notebook cells")
    cell = next((c for c in artifact.cells if c.index == cell_index), None)
    if cell is None:
        raise HTTPException(404, "unknown cell index")

    translation = translate_notebook(artifact)
    cell_result = next((c for c in translation.cells if c.cell_index == cell_index), None)
    default_reason = "not translated by static rules"
    reason = cell_result.reason if cell_result and cell_result.reason else default_reason

    _resolve_profile(connections, req.connection_id)
    cursor = connections.session_manager.open_cursor(
        req.connection_id, query_tag=f"pbic:fabric-tier3:{conversion_id}"
    )
    try:
        result = tier3_propose_and_validate(cell_index, cell.source, reason, cursor)
    finally:
        cursor.close()

    return Tier3Response(
        cell_index=result.cell_index,
        sql=result.sql,
        accepted=result.accepted,
        attempts=result.attempts,
        trace=result.trace,
    )
