"""WS5: minimal TMDL/.bim writer -- repoints one table's partition at a new
Snowflake object + sets the connectivity mode, leaving everything else in
the project's TMDL/model.bim files untouched.

Scope (per decision #10's risk note): this is NOT a general-purpose TMDL/TMSL
serializer capable of reconstructing an entire semantic model from the IR --
`parsers/tmdl.py`'s tokenizer already does the hard, general problem for
*reading*. Writing back only ever needs to touch one thing (the migrated
table's own partition: its M expression + connectivity mode), so this does a
surgical, line-range replacement of just that block, preserving every other
line/byte of the original project exactly as Power BI Desktop wrote it --
much lower risk than reconstructing the whole file from the IR.
"""

from __future__ import annotations

import io
import json
import re
import shutil
import zipfile
from pathlib import Path
from typing import Literal

from app.parsers.bundle import find_pbip
from app.parsers.pbir import PbirParseError, resolve_dataset_reference
from app.services.migration import _SNOWFLAKE_M_TEMPLATE

ConnectivityMode = Literal["import", "directQuery"]

_PARTITION_HEADER_RE = re.compile(r"^(\t*)partition\s+(\S.*)$")
_TABLE_HEADER_RE = re.compile(r"^table\s+(?:'([^']+)'|(\S+))\s*$")


class PbipWriteError(Exception):
    pass


def _line_indent(line: str) -> int:
    return len(line) - len(line.lstrip("\t"))


def build_snowflake_m_expression(
    *, account: str, warehouse: str, database: str, schema: str, object_name: str
) -> str:
    return _SNOWFLAKE_M_TEMPLATE.format(
        account=account,
        warehouse=warehouse,
        database=database.upper(),
        schema=schema.upper(),
        object_name=object_name.upper(),
        kind="Table",
    )


def rewrite_tmdl_table_partition(
    table_tmdl_text: str,
    m_expression: str,
    mode: ConnectivityMode,
    *,
    table_name: str | None = None,
) -> str:
    """Replace a table's partition block with one pointing at `m_expression`,
    in the given connectivity mode. Everything before/after the partition
    block (columns, measures, hierarchies, annotations) is left byte-for-byte
    untouched.

    A `.tmdl` file normally holds exactly one table (Power BI Desktop's own
    convention), but `parsers/tmdl.py` reads *all* `.tmdl` files under
    `definition/` regardless of layout, so a hand-authored or test-fixture
    file can legally hold more than one `table` declaration. When
    `table_name` is given, the partition search is scoped to that table's own
    line range so a multi-table file doesn't get the wrong partition rewritten.
    """
    ends_with_newline = table_tmdl_text.endswith("\n")
    lines = table_tmdl_text.splitlines()

    search_start, search_end = 0, len(lines)
    if table_name is not None:
        for i, line in enumerate(lines):
            m = _TABLE_HEADER_RE.match(line)
            if m and (m.group(1) or m.group(2)) == table_name:
                search_start = i + 1
                for j in range(search_start, len(lines)):
                    if _TABLE_HEADER_RE.match(lines[j]):
                        search_end = j
                        break
                break
        else:
            raise PbipWriteError(f"table {table_name!r} not found in this .tmdl file")

    start = None
    indent = 0
    partition_name = "Partition"
    for i in range(search_start, search_end):
        m = _PARTITION_HEADER_RE.match(lines[i])
        if m:
            start = i
            indent = len(m.group(1))
            partition_name = m.group(2).split(" = ", 1)[0].strip()
            break
    if start is None:
        raise PbipWriteError("no partition declaration found in table TMDL")

    end = search_end
    for j in range(start + 1, search_end):
        if not lines[j].strip():
            continue
        if _line_indent(lines[j]) <= indent:
            end = j
            break

    base_indent = "\t" * indent
    body_indent = "\t" * (indent + 2)
    new_block = [
        f"{base_indent}partition {partition_name} = m",
        f"{base_indent}\tmode: {mode}",
        f"{base_indent}\tsource =",
    ]
    new_block.extend(f"{body_indent}{ln}" for ln in m_expression.strip("\n").splitlines())

    lines[start:end] = new_block
    return "\n".join(lines) + ("\n" if ends_with_newline else "")


def _find_table_tmdl_file(definition_dir: Path, table_name: str) -> Path | None:
    """A .tmdl file normally lives one-per-table under definition/tables/
    (Power BI Desktop's own convention), but parsers/tmdl.py reads every
    .tmdl file under definition/ regardless of layout -- searched the same
    way here, direct filename match first as a fast path."""
    direct = definition_dir / "tables" / f"{table_name}.tmdl"
    if direct.is_file():
        return direct
    name_re = re.compile(r"^table\s+(?:'([^']+)'|(\S+))\s*$", re.MULTILINE)
    for path in sorted(definition_dir.rglob("*.tmdl")):
        for m in name_re.finditer(path.read_text(encoding="utf-8")):
            if (m.group(1) or m.group(2)) == table_name:
                return path
    return None


def rewrite_bim_table_partition(doc: dict, table_name: str, m_expression: str, mode: str) -> bool:
    """Mutates `doc` in place. Returns whether the table was found."""
    model = doc.get("model")
    if not isinstance(model, dict):
        raise PbipWriteError("model.bim: no top-level 'model' object")
    for table in model.get("tables", []):
        if table.get("name") == table_name:
            partitions = table.get("partitions") or []
            if not partitions:
                raise PbipWriteError(f"table {table_name!r} has no partitions in model.bim")
            partitions[0]["mode"] = mode
            partitions[0]["source"] = {
                "type": "m",
                "expression": m_expression.strip("\n").splitlines(),
            }
            return True
    return False


def repoint_pbip_project(
    source_root: Path,
    dest_root: Path,
    table_targets: dict[str, str],
    *,
    mode: ConnectivityMode,
    account: str,
    warehouse: str,
    database: str,
    schema: str,
) -> list[str]:
    """Copy `source_root`'s .pbip project to `dest_root`, then repoint every
    table in `table_targets` (model table name -> Snowflake gold object bare
    name) at its new Snowflake object. Returns the table names actually
    repointed (a table_targets entry with no matching table in the project
    is silently skipped, not an error -- WS4's fidelity gate is what decides
    which tables are safe to repoint in the first place)."""
    if dest_root.exists():
        shutil.rmtree(dest_root)
    shutil.copytree(source_root, dest_root)

    pbip_file = find_pbip(dest_root)
    pbip = json.loads(pbip_file.read_text(encoding="utf-8"))
    report_rel = next(
        (a["report"]["path"] for a in pbip.get("artifacts", []) if "report" in a), None
    )
    if not report_rel:
        raise PbipWriteError(f"{pbip_file}: no report artifact declared")
    report_dir = (pbip_file.parent / report_rel).resolve()
    try:
        model_dir = resolve_dataset_reference(report_dir)
    except PbirParseError as e:
        raise PbipWriteError(str(e)) from e

    repointed: list[str] = []
    definition_dir = model_dir / "definition"
    bim_file = model_dir / "model.bim"

    if definition_dir.is_dir():
        for table_name, object_name in table_targets.items():
            path = _find_table_tmdl_file(definition_dir, table_name)
            if path is None:
                continue
            m_expr = build_snowflake_m_expression(
                account=account, warehouse=warehouse, database=database, schema=schema,
                object_name=object_name,
            )
            path.write_text(
                rewrite_tmdl_table_partition(
                    path.read_text(encoding="utf-8"), m_expr, mode, table_name=table_name
                ),
                encoding="utf-8",
            )
            repointed.append(table_name)
    elif bim_file.is_file():
        doc = json.loads(bim_file.read_text(encoding="utf-8-sig"))
        for table_name, object_name in table_targets.items():
            m_expr = build_snowflake_m_expression(
                account=account, warehouse=warehouse, database=database, schema=schema,
                object_name=object_name,
            )
            if rewrite_bim_table_partition(doc, table_name, m_expr, mode):
                repointed.append(table_name)
        bim_file.write_text(json.dumps(doc, indent=2), encoding="utf-8")
    else:
        raise PbipWriteError(f"no TMDL definition/ folder or model.bim in {model_dir}")

    return repointed


def zip_directory(root: Path) -> bytes:
    """Re-zip a folder tree in-memory, mirroring services/export.py's shape
    for the existing /dashboard/export React-project download."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(root.rglob("*")):
            if path.is_file():
                zf.write(path, path.relative_to(root))
    return buf.getvalue()
