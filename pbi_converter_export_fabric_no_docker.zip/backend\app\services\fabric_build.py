"""WS3: Snowflake object build + scheduling.

Turns a reviewed FabricPipeline (WS1) plus its per-artifact translations
(WS2) into a dependency-ordered plan of Snowflake DDL: schemas per medallion
layer (decision #13), TRANSIENT tables/Dynamic Tables for declarative
(DataFrame-derived) layers, and stored-proc + Task pairs for imperative
(whole .sql script) layers, chained bronze->silver->gold via real referenced
dependencies rather than a naive positional layer order.

Every object this module creates is TRANSIENT (decision #8) -- this applies
only to the Fabric pipeline's own objects, not the existing source-database
migration paths in object_migration.py/migration.py, which are unchanged.

Scope note: dependency inference and predecessor-task chaining use bare
(schema-stripped) table names throughout, matching decision #13's flat,
per-layer naming convention. This module does NOT rewrite schema/db
qualifiers *inside* an imperative .sql script's own statement text (that
would need the same live-introspected schema_map + requalify machinery
object_migration.py uses against a real source connection, which doesn't
apply to an uploaded, disconnected Fabric script) -- an artifact whose
imperative SQL references another schema by name is flagged with a note
for human review rather than silently rewritten.
"""

from __future__ import annotations

import re
from typing import Literal

import sqlglot
from pydantic import BaseModel, Field

from app.services.fabric_notebooks import FabricPipeline
from app.services.fabric_translate import ArtifactTranslation, TranslationTier
from app.services.migration import _qident

ObjectKind = Literal["transient_table", "dynamic_table", "task_proc"]

_SOURCE_TOKEN_RE = re.compile(r"\{\{source:\s*(.*?)\s*\}\}")


def _layer_schema(target_schema: str, layer: str) -> str:
    return f"{target_schema}__{layer}".upper()


def _sanitize_ident(name: str) -> str:
    """Best-effort: strip anything that isn't a legal unquoted SQL identifier
    character, for deriving object names from file paths / free text."""
    cleaned = re.sub(r"[^A-Za-z0-9_]+", "_", name).strip("_")
    return cleaned or "OBJECT"


def _bare_table_name(qualified: str) -> str:
    return _sanitize_ident(qualified.rsplit(".", 1)[-1]).upper()


class BuildPlanItem(BaseModel):
    artifact_id: str
    artifact_path: str
    layer: str
    schema_name: str
    object_kind: ObjectKind
    object_name: str  # table name, or task name for task_proc items
    ddl: list[str] = Field(default_factory=list)  # statements to execute, in order
    depends_on: list[str] = Field(default_factory=list)  # other items' object_name values
    notes: list[str] = Field(default_factory=list)


class BuildPlan(BaseModel):
    schemas: list[str] = Field(default_factory=list)
    items: list[BuildPlanItem] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


# -- cadence text -> Dynamic Table TARGET_LAG / Task cron -------------------

_CADENCE_LAG = {"hourly": "1 hour", "daily": "24 hours", "weekly": "7 days"}
_CADENCE_CRON = {"hourly": "0 * * * *", "daily": "0 2 * * *", "weekly": "0 2 * * 0"}
_CRON_LOOKS_LIKE_RE = re.compile(r"^(\S+\s+){4}\S+$")
_DAILY_AT_RE = re.compile(r"daily\s+(\d{1,2}):(\d{2})", re.IGNORECASE)


def _cadence_to_target_lag(schedule: str) -> tuple[str, str | None]:
    """-> (TARGET_LAG value, warning-if-any). Dynamic Tables take a max-
    staleness duration, not a clock time, so an exact time-of-day in the
    human's schedule text can't be honored exactly -- surfaced as a note
    rather than silently dropped."""
    s = schedule.strip().lower()
    if _DAILY_AT_RE.search(s):
        note = (
            f"schedule {schedule!r} requested a specific time of day; Dynamic Tables' "
            "TARGET_LAG is a max-staleness duration, not a clock time -- using 24 hours"
        )
        return "24 hours", note
    for key, lag in _CADENCE_LAG.items():
        if key in s:
            return lag, None
    if not s:
        return "1 hour", None
    return "1 hour", f"unrecognized schedule {schedule!r}; defaulted TARGET_LAG to 1 hour"


def _cadence_to_cron(schedule: str) -> tuple[str, str | None]:
    s = schedule.strip()
    if _CRON_LOOKS_LIKE_RE.match(s):
        return s, None
    low = s.lower()
    m = _DAILY_AT_RE.search(low)
    if m:
        hour, minute = int(m.group(1)), int(m.group(2))
        return f"{minute} {hour} * * *", None
    for key, cron in _CADENCE_CRON.items():
        if key in low:
            return cron, None
    if not s:
        return "0 2 * * *", None
    return "0 2 * * *", f"unrecognized schedule {schedule!r}; defaulted to daily at 02:00 UTC"


def _written_bare_tables(sql: str) -> set[str]:
    """Bare table names a (resolvable) SQL statement CREATEs/INSERTs/MERGEs into."""
    try:
        written: set[str] = set()
        for stmt in sqlglot.parse(sql, read="snowflake"):
            if stmt is None:
                continue
            target = None
            if isinstance(stmt, sqlglot.exp.Create | sqlglot.exp.Insert | sqlglot.exp.Merge):
                target = stmt.this
            if target is not None:
                table = target.find(sqlglot.exp.Table)
                if table is not None:
                    written.add(_bare_table_name(table.name))
        return written
    except Exception:  # noqa: BLE001 - dependency inference is best-effort only
        return set()


class _BuiltObject:
    __slots__ = ("schema_name", "layer", "owner_object_name")

    def __init__(self, schema_name: str, layer: str, owner_object_name: str):
        self.schema_name = schema_name
        self.layer = layer
        self.owner_object_name = owner_object_name


class _PlanBuilder:
    def __init__(
        self,
        target_database: str,
        target_schema: str,
        warehouse: str,
        source_bindings: dict[str, str],
        sf_cursor=None,
    ):
        self.target_database = target_database
        self.target_schema = target_schema
        self.warehouse = warehouse
        self.source_bindings = source_bindings
        self.sf_cursor = sf_cursor
        self.warnings: list[str] = []
        # bare table name (upper) -> the item that owns/produces it
        self.built: dict[str, _BuiltObject] = {}
        # qualified external table name -> {UPPER(col): real_col}, from a
        # live DESCRIBE TABLE -- cached so each distinct bound table is only
        # ever introspected once per plan_build() call.
        self._column_case_cache: dict[str, dict[str, str]] = {}

    def _real_column_casing(self, qualified_table: str) -> dict[str, str]:
        """A human-supplied source_bindings target's real column casing is
        whatever they happened to load it with -- which routinely disagrees
        with the exact case the original notebook/script literally wrote
        (e.g. a plain `CREATE TABLE ... USING TEMPLATE` case-folds everything
        to uppercase). Rather than crash the first time those two disagree,
        DESCRIBE the bound table once and let callers auto-correct any
        quoted reference to whatever case Snowflake actually has."""
        if qualified_table in self._column_case_cache:
            return self._column_case_cache[qualified_table]
        columns: dict[str, str] = {}
        if self.sf_cursor is not None:
            try:
                self.sf_cursor.execute(f"DESCRIBE TABLE {qualified_table}")
                columns = {row[0].upper(): row[0] for row in self.sf_cursor.fetchall()}
            except Exception:  # noqa: BLE001 - best-effort; no cursor/table -> no correction
                columns = {}
        self._column_case_cache[qualified_table] = columns
        return columns

    def _fq(self, schema: str, name: str) -> str:
        return f"{_qident(self.target_database)}.{_qident(schema)}.{_qident(name)}"

    def _register_pass(self, reviewed: list, translations: dict[str, ArtifactTranslation]) -> None:
        """Pass 1: learn every table this pipeline will produce -- both
        declarative (saveAsTable) targets and imperative (CREATE/INSERT)
        write-targets -- before resolving any cross-artifact references,
        so dependency detection doesn't depend on artifact upload order."""
        for artifact in reviewed:
            translation = translations.get(artifact.id)
            if translation is None:
                continue
            schema_name = _layer_schema(self.target_schema, artifact.layer)
            for cell in translation.cells:
                if cell.tier == TranslationTier.DATAFRAME:
                    for stmt in cell.statements:
                        if stmt.target_table:
                            name = _bare_table_name(stmt.target_table)
                            self.built[name] = _BuiltObject(schema_name, artifact.layer, name)
                elif cell.tier == TranslationTier.SQL:
                    base_name = _artifact_base_name(artifact.relative_path)
                    task_name = f"{base_name}_TASK"
                    for stmt in cell.statements:
                        for table in _written_bare_tables(stmt.sql):
                            self.built[table] = _BuiltObject(schema_name, artifact.layer, task_name)

    def _resolve_source_tokens(self, sql: str) -> tuple[str, list[str], list[str]]:
        """-> (resolved sql, depends_on object names, notes)."""
        deps: list[str] = []
        notes: list[str] = []
        bound_tables: set[str] = set()

        def _replace(m: re.Match) -> str:
            token = m.group(1)
            bound = self.source_bindings.get(token)
            if bound:
                bound_tables.add(bound)
                return bound
            # {{source: ...}} tokens always come from a DataFrame read call's
            # resolved path/table literal (see _process_read_chain) -- never a
            # dotted SQL identifier -- so a bare sanitize here, NOT
            # _bare_table_name's "keep only the part after the last dot"
            # (that's for schema.table references; on a file path/glob like
            # "Files/cms_raw/*.csv" the last dot is the extension, and
            # rsplit-on-dot would collapse the whole path down to "CSV").
            key = _sanitize_ident(token).upper()
            hit = self.built.get(key)
            if hit:
                deps.append(hit.owner_object_name)
                return self._fq(hit.schema_name, key)
            notes.append(
                f"unresolved source {token!r}; bind it via source_bindings once the "
                "matching raw/bronze table's real name in Snowflake is known"
            )
            return f"/* UNRESOLVED SOURCE: {token} */ {_qident(key)}"

        resolved = _SOURCE_TOKEN_RE.sub(_replace, sql)
        if bound_tables and "METADATA$FILENAME" in resolved:
            # METADATA$FILENAME (tier2's translation of input_file_name())
            # only resolves when Snowflake is scanning a stage directly --
            # a source_bindings target is, by definition, a plain table the
            # human pointed at manually, which has no such file-lineage
            # metadata. Fall back to a real "file_path" column instead --
            # the human is expected to have populated one when loading that
            # table (mirroring the original notebook's own withColumn name).
            resolved = resolved.replace("METADATA$FILENAME", _qident("file_path"))
        if bound_tables:
            case_map: dict[str, str] = {}
            for table in bound_tables:
                case_map.update(self._real_column_casing(table))
            if case_map:
                # a source_bindings target's real column casing is whatever
                # the human happened to load it with, which routinely
                # disagrees with the exact case the original notebook
                # literally wrote (tier2 always quotes with that literal
                # case) -- auto-correct every quoted reference here instead
                # of letting it crash the first time the two disagree.
                def _fix_case(m: re.Match) -> str:
                    real = case_map.get(m.group(1).upper())
                    return f'"{real}"' if real else m.group(0)

                resolved = re.sub(r'"([^"]+)"', _fix_case, resolved)
        return resolved, deps, notes

    def _qualify_known_tables(self, sql: str) -> tuple[str, list[str], list[str]]:
        """Rewrite any *bare* (unqualified) table reference that matches
        something else this pipeline builds into its fully-qualified name --
        covers a spark.sql(...)-sourced frame's subquery, which embeds the
        original bare table name directly rather than via a {{source: ...}}
        token. Already-qualified references (`schema.table`) are left alone
        (flagged separately) -- rewriting those would need the same
        schema_map/requalify machinery object_migration.py uses against a
        live-introspected source, out of scope for a disconnected script.

        A bare reference that matches neither a CTE defined in the same
        statement nor anything this pipeline builds (a typo, or a table
        whose artifact got skipped/removed after this one was written) is
        reported via the same 'unresolved source' note vocabulary
        _resolve_source_tokens uses -- so it's picked up by the same
        cascading-skip logic in _blocked_object_names() and the same
        source-bindings UI, rather than silently shipping broken DDL that
        only fails once it hits Snowflake."""
        deps: list[str] = []
        notes: list[str] = []
        seen_unresolved: set[str] = set()
        try:
            out_stmts = []
            for stmt in sqlglot.parse(sql, read="snowflake"):
                if stmt is None:
                    continue
                cte_names = {c.alias_or_name.upper() for c in stmt.find_all(sqlglot.exp.CTE)}
                for t in stmt.find_all(sqlglot.exp.Table):
                    if t.args.get("db") or t.args.get("catalog"):
                        continue
                    key = _bare_table_name(t.name)
                    if key in cte_names:
                        continue
                    hit = self.built.get(key)
                    if hit:
                        t.set("this", sqlglot.exp.to_identifier(key, quoted=True))
                        t.set("db", sqlglot.exp.to_identifier(hit.schema_name, quoted=True))
                        t.set(
                            "catalog", sqlglot.exp.to_identifier(self.target_database, quoted=True)
                        )
                        deps.append(hit.owner_object_name)
                    elif t.name not in seen_unresolved:
                        seen_unresolved.add(t.name)
                        notes.append(
                            f"unresolved source {t.name!r}; this pipeline doesn't build a table "
                            "by that name (typo, or its artifact was skipped/removed) -- bind it "
                            "via source_bindings if it's meant to be an external table, or "
                            "fix/remove this reference"
                        )
                # T-SQL is case-insensitive, so a SPROC script never quotes its
                # column references -- but every column tier2 (fabric_translate.py)
                # produces IS quoted, exact original case (see _Frame.emit_select()).
                # Snowflake folds an unquoted reference to uppercase for matching,
                # which then can't find a quoted mixed-case column (e.g. a SPROC
                # script's bare `Year` fails against a notebook-produced table's
                # real `"Year"` column -- error: invalid identifier 'YEAR').
                # Quoting every bare column reference (and select-list alias) here,
                # preserving its existing text, aligns this tier with tier2's
                # convention so Snowflake does the same exact-case match everywhere.
                for col in stmt.find_all(sqlglot.exp.Column):
                    ident = col.this
                    if isinstance(ident, sqlglot.exp.Identifier) and not ident.args.get("quoted"):
                        ident.set("quoted", True)
                for alias in stmt.find_all(sqlglot.exp.Alias):
                    ident = alias.args.get("alias")
                    if isinstance(ident, sqlglot.exp.Identifier) and not ident.args.get("quoted"):
                        ident.set("quoted", True)
                out_stmts.append(stmt.sql(dialect="snowflake"))
            return (";\n".join(out_stmts) if out_stmts else sql), deps, notes
        except Exception:  # noqa: BLE001 - qualification is best-effort only
            return sql, deps, notes

    def build(
        self, pipeline: FabricPipeline, translations: dict[str, ArtifactTranslation]
    ) -> BuildPlan:
        reviewed = [a for a in pipeline.artifacts if a.reviewed and a.layer != "skip"]
        self._register_pass(reviewed, translations)

        items: list[BuildPlanItem] = []
        for artifact in reviewed:
            translation = translations.get(artifact.id)
            if translation is None:
                self.warnings.append(f"{artifact.relative_path}: no translation available, skipped")
                continue
            schema_name = _layer_schema(self.target_schema, artifact.layer)

            for cell in translation.cells:
                if cell.tier == TranslationTier.DATAFRAME:
                    for stmt in cell.statements:
                        if stmt.target_table:
                            items.append(self._build_declarative_item(artifact, schema_name, stmt))

            sql_statements = [
                stmt.sql
                for cell in translation.cells
                if cell.tier == TranslationTier.SQL
                for stmt in cell.statements
            ]
            if sql_statements:
                items.append(self._build_imperative_item(artifact, schema_name, sql_statements))

            for cell in translation.cells:
                if cell.tier == TranslationTier.UNHANDLED:
                    self.warnings.append(
                        f"{artifact.relative_path} cell {cell.cell_index}: not translated "
                        f"({cell.reason}) -- needs manual SQL or tier-3 assistance before "
                        "WS3 can build it"
                    )

        self._link_task_predecessors(items)
        ordered = _topological_sort(items, self.warnings)
        schemas = sorted({_layer_schema(self.target_schema, a.layer) for a in reviewed})
        return BuildPlan(schemas=schemas, items=ordered, warnings=self.warnings)

    def _build_declarative_item(self, artifact, schema_name: str, stmt) -> BuildPlanItem:
        table_name = _bare_table_name(stmt.target_table)
        resolved_sql, deps, notes = self._resolve_source_tokens(stmt.sql)
        if stmt.note:
            notes.append(stmt.note)
        # a spark.sql(...)-sourced frame embeds its table reference directly
        # in the SQL text (no {{source: ...}} placeholder) -- qualify + track those too.
        resolved_sql, extra_deps, extra_notes = self._qualify_known_tables(resolved_sql)
        deps.extend(d for d in extra_deps if d != table_name)
        notes.extend(extra_notes)

        fq = self._fq(schema_name, table_name)
        if artifact.schedule.strip():
            lag, lag_note = _cadence_to_target_lag(artifact.schedule)
            if lag_note:
                notes.append(lag_note)
            ddl = [
                f"CREATE OR REPLACE TRANSIENT DYNAMIC TABLE {fq}\n"
                f"TARGET_LAG = '{lag}' WAREHOUSE = {_qident(self.warehouse)}\n"
                f"AS\n{resolved_sql}"
            ]
            kind: ObjectKind = "dynamic_table"
        else:
            ddl = [f"CREATE OR REPLACE TRANSIENT TABLE {fq}\nAS\n{resolved_sql}"]
            kind = "transient_table"

        return BuildPlanItem(
            artifact_id=artifact.id,
            artifact_path=artifact.relative_path,
            layer=artifact.layer,
            schema_name=schema_name,
            object_kind=kind,
            object_name=table_name,
            ddl=ddl,
            depends_on=sorted(set(deps)),
            notes=notes,
        )

    def _build_imperative_item(
        self, artifact, schema_name: str, sql_statements: list[str]
    ) -> BuildPlanItem:
        base_name = _artifact_base_name(artifact.relative_path)
        proc_name, task_name = f"{base_name}_PROC", f"{base_name}_TASK"

        deps: set[str] = set()
        resolved_statements: list[str] = []
        notes: list[str] = []
        cross_schema_refs: set[str] = set()
        for sql in sql_statements:
            resolved_sql, tok_deps, tok_notes = self._resolve_source_tokens(sql)
            deps.update(d for d in tok_deps if d != task_name)
            notes.extend(tok_notes)
            resolved_sql, extra_deps, extra_notes = self._qualify_known_tables(resolved_sql)
            deps.update(d for d in extra_deps if d != task_name)
            notes.extend(extra_notes)
            resolved_statements.append(resolved_sql.rstrip().rstrip(";"))
            for t in re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\.[A-Za-z_][A-Za-z0-9_]*\b", sql):
                cross_schema_refs.add(t)

        if cross_schema_refs:
            notes.append(
                "this script references schema-qualified names "
                f"({', '.join(sorted(cross_schema_refs))}) that are NOT rewritten to this "
                "pipeline's bronze/silver/gold schemas -- confirm/edit manually before running"
            )

        proc_fq = self._fq(schema_name, proc_name)
        task_fq = self._fq(schema_name, task_name)
        body = ";\n  ".join(resolved_statements)
        proc_ddl = (
            f"CREATE OR REPLACE PROCEDURE {proc_fq}()\n"
            "RETURNS VARCHAR\nLANGUAGE SQL\nAS\n$$\nBEGIN\n"
            f"  {body};\n  RETURN 'ok';\nEND;\n$$"
        )

        cron, cron_note = _cadence_to_cron(artifact.schedule)
        if cron_note:
            notes.append(cron_note)
        # predecessor AFTER wiring is filled in by _link_task_predecessors,
        # once every item (and its object_kind) is known.
        task_ddl_template = (
            f"CREATE OR REPLACE TASK {task_fq}\n"
            f"WAREHOUSE = {_qident(self.warehouse)}\n"
            "{after_clause}"
            f"SCHEDULE = 'USING CRON {cron} UTC'\n"
            f"AS CALL {proc_fq}()"
        )

        return BuildPlanItem(
            artifact_id=artifact.id,
            artifact_path=artifact.relative_path,
            layer=artifact.layer,
            schema_name=schema_name,
            object_kind="task_proc",
            object_name=task_name,
            ddl=[proc_ddl, task_ddl_template],
            depends_on=sorted(deps),
            notes=notes,
        )

    def _link_task_predecessors(self, items: list[BuildPlanItem]) -> None:
        """Dynamic Tables get dependency-aware scheduling "for free" from
        Snowflake itself (decision #9) -- only Task-based (imperative) items
        need an explicit AFTER predecessor, and only on other Task-based
        items (a Task can't formally depend on a Dynamic Table's refresh)."""
        by_name = {item.object_name: item for item in items}
        for item in items:
            if item.object_kind != "task_proc":
                continue
            predecessors = sorted(
                dep
                for dep in item.depends_on
                if by_name.get(dep) is not None and by_name[dep].object_kind == "task_proc"
            )
            after_clause = ""
            if predecessors:
                preds_fq = ", ".join(self._fq(by_name[p].schema_name, p) for p in predecessors)
                after_clause = f"AFTER {preds_fq}\n"
            item.ddl[1] = item.ddl[1].format(after_clause=after_clause)


def _artifact_base_name(relative_path: str) -> str:
    stem = relative_path.rsplit("/", 1)[-1].rsplit(".", 1)[0]
    return _sanitize_ident(stem).upper()


def _topological_sort(items: list[BuildPlanItem], warnings: list[str]) -> list[BuildPlanItem]:
    by_name = {item.object_name: item for item in items}
    visited: set[str] = set()
    ordering: list[BuildPlanItem] = []
    in_progress: set[str] = set()

    def visit(item: BuildPlanItem) -> None:
        if item.object_name in visited:
            return
        if item.object_name in in_progress:
            warnings.append(
                f"dependency cycle detected involving {item.object_name}; "
                "build order not guaranteed"
            )
            return
        in_progress.add(item.object_name)
        for dep in item.depends_on:
            dep_item = by_name.get(dep)
            if dep_item is not None:
                visit(dep_item)
        in_progress.discard(item.object_name)
        visited.add(item.object_name)
        ordering.append(item)

    for item in items:
        visit(item)
    return ordering


def plan_build(
    pipeline: FabricPipeline,
    translations: dict[str, ArtifactTranslation],
    *,
    target_database: str,
    target_schema: str,
    warehouse: str,
    source_bindings: dict[str, str] | None = None,
    sf_cursor=None,
) -> BuildPlan:
    """`sf_cursor`, when given, lets an item bound via source_bindings be
    checked against Snowflake's real column casing for that table (a
    single DESCRIBE TABLE per distinct bound table) -- optional so plan
    preview/tests can still run as pure computation with no live
    connection, at the cost of not catching a case mismatch until the
    generated DDL actually executes."""
    builder = _PlanBuilder(
        target_database, target_schema, warehouse, source_bindings or {}, sf_cursor
    )
    return builder.build(pipeline, translations)


def _blocked_object_names(plan: BuildPlan) -> set[str]:
    """Objects that must not be executed: one with an unresolved source
    (flagged in its own notes, e.g. a raw file path with no source_binding
    and no matching built table), plus anything that transitively depends
    on one -- a dependent's CREATE would only fail too, since the table it
    reads from was never actually created."""
    blocked = {
        item.object_name for item in plan.items if any("unresolved source" in n for n in item.notes)
    }
    changed = True
    while changed:
        changed = False
        for item in plan.items:
            if item.object_name in blocked:
                continue
            if any(dep in blocked for dep in item.depends_on):
                blocked.add(item.object_name)
                changed = True
    return blocked


def execute_build_plan(plan: BuildPlan, sf_cursor) -> tuple[list[str], list[str]]:
    """Run the plan's DDL against a live Snowflake cursor, in dependency
    order. Returns (created, skipped) -- an item with an unresolved source,
    or a dependency on one, is never executed: Snowflake would only reject
    it with an opaque compilation error for an object this app already knew
    it couldn't resolve, so it's skipped up front and reported instead of
    crashing the whole request."""
    for schema in plan.schemas:
        sf_cursor.execute(f"CREATE SCHEMA IF NOT EXISTS {_qident(schema)}")

    blocked = _blocked_object_names(plan)
    created: list[str] = []
    skipped: list[str] = []
    for item in plan.items:
        if item.object_name in blocked:
            skipped.append(item.object_name)
            continue
        for stmt in item.ddl:
            sf_cursor.execute(stmt)
        created.append(item.object_name)
    return created, skipped
