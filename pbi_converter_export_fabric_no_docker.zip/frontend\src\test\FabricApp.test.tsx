import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { act, render, screen } from '@testing-library/react'
import { beforeEach, describe, expect, it } from 'vitest'
import FabricApp from '../FabricApp'
import { useFabricWizard } from '../store/fabricWizard'

function renderApp() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <FabricApp />
    </QueryClientProvider>,
  )
}

describe('FabricApp wizard shell', () => {
  beforeEach(() => useFabricWizard.getState().reset())

  it('starts on the upload step', () => {
    renderApp()
    expect(screen.getByText(/Upload your Fabric workspace export/)).toBeInTheDocument()
  })

  it('moves to review step after a pipeline is set', () => {
    renderApp()
    act(() => useFabricWizard.getState().setPipeline('pipeline-1'))
    expect(useFabricWizard.getState().step).toBe('review')
  })

  it('setStep navigates between steps', () => {
    renderApp()
    act(() => {
      useFabricWizard.getState().setPipeline('pipeline-1')
      useFabricWizard.getState().setStep('export')
    })
    expect(screen.getByText(/Repoint the report/)).toBeInTheDocument()
  })
})

describe('fabricWizard store', () => {
  beforeEach(() => useFabricWizard.getState().reset())

  it('reset clears pipeline id and returns to upload', () => {
    useFabricWizard.getState().setPipeline('x')
    useFabricWizard.getState().reset()
    const s = useFabricWizard.getState()
    expect(s.step).toBe('upload')
    expect(s.pipelineId).toBeNull()
  })

  it('setStep is blocked when there are unsaved changes and the user cancels', () => {
    useFabricWizard.getState().setPipeline('x')
    useFabricWizard.getState().setUnsavedChanges(true, 'test edits')
    const originalConfirm = window.confirm
    window.confirm = () => false
    useFabricWizard.getState().setStep('build')
    expect(useFabricWizard.getState().step).toBe('review')
    window.confirm = originalConfirm
  })
})
