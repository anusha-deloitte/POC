"""TMSL (`model.bim`) parser -> PBI-IR SemanticModel.

TMSL is the Analysis Services Tabular Object Model serialized as JSON (see
https://learn.microsoft.com/en-us/analysis-services/tmsl/tabular-model-scripting-language-tmsl-reference).
It represents the exact same object model TMDL does, just as one JSON tree
instead of TMDL's indentation-based text format — this module targets the
same IR classes `tmdl.py` produces (`app/ir/model.py`) so every downstream
compiler/consumer works unchanged regardless of which format the model.bim
or definition/ folder happened to use.

A `model.bim` from a Direct-Lake-hosted report has partitions shaped as
`entityPartitionSource` (a reference to a Fabric Lakehouse entity — no M
query at all) rather than the usual `"m"` source. There's no M expression to
preserve in that case, so those partitions are mapped to `source_type =
"directlake"` with an empty expression; `services/migration.py`'s
`rewrite_bundle_to_snowflake()` only requires `table.partitions` to be
non-empty (it overwrites `partitions[0].expression` unconditionally), so this
placeholder is sufficient for the repoint step to work unchanged.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from app.ir.model import (
    Column,
    DataType,
    Hierarchy,
    HierarchyLevel,
    Measure,
    Partition,
    PartitionMode,
    Relationship,
    Role,
    SemanticModel,
    SummarizeBy,
    Table,
)

_AUTO_DATE_PREFIXES = ("LocalDateTable_", "DateTableTemplate_")


class BimParseError(Exception):
    pass


def _text(value: Any) -> str:
    """TMSL scripts (M/DAX) are sometimes an array of lines, sometimes one string."""
    if value is None:
        return ""
    if isinstance(value, list):
        return "\n".join(str(v) for v in value)
    return str(value)


def _annotations(obj: dict) -> dict[str, str]:
    return {a["name"]: _text(a.get("value")) for a in obj.get("annotations", []) if a.get("name")}


def _to_data_type(v: str | None) -> DataType:
    if not v:
        return DataType.UNKNOWN
    try:
        return DataType(v[0].lower() + v[1:]) if v[0].isupper() else DataType(v)
    except ValueError:
        return DataType.UNKNOWN


def _to_summarize(v: str | None) -> SummarizeBy:
    if not v:
        return SummarizeBy.DEFAULT
    try:
        return SummarizeBy(v[0].lower() + v[1:]) if v and v[0].isupper() else SummarizeBy(v)
    except ValueError:
        return SummarizeBy.DEFAULT


def _map_column(c: dict) -> Column:
    return Column(
        name=c["name"],
        data_type=_to_data_type(c.get("dataType")),
        source_column=c.get("sourceColumn"),
        format_string=c.get("formatString"),
        summarize_by=_to_summarize(c.get("summarizeBy")),
        sort_by_column=c.get("sortByColumn"),
        is_hidden=bool(c.get("isHidden", False)),
        is_key=bool(c.get("isKey", False)),
        description=c.get("description"),
        expression=_text(c["expression"]) if c.get("type") == "calculated" else None,
        lineage_tag=c.get("lineageTag"),
        annotations=_annotations(c),
    )


def _map_measure(m: dict) -> Measure:
    return Measure(
        name=m["name"],
        expression=_text(m.get("expression")),
        format_string=m.get("formatString"),
        display_folder=m.get("displayFolder"),
        is_hidden=bool(m.get("isHidden", False)),
        description=m.get("description"),
        lineage_tag=m.get("lineageTag"),
        annotations=_annotations(m),
    )


def _map_hierarchy(h: dict) -> Hierarchy:
    levels = [
        HierarchyLevel(
            name=lvl["name"],
            column=lvl.get("column", lvl["name"]),
            ordinal=int(lvl.get("ordinal", 0)),
        )
        for lvl in h.get("levels", [])
    ]
    return Hierarchy(
        name=h["name"],
        levels=sorted(levels, key=lambda x: x.ordinal),
        is_hidden=bool(h.get("isHidden", False)),
        lineage_tag=h.get("lineageTag"),
    )


_MODE_MAP = {
    "import": PartitionMode.IMPORT,
    "directquery": PartitionMode.DIRECT_QUERY,
    "dual": PartitionMode.DUAL,
}


def _map_partition(p: dict) -> Partition:
    mode = _MODE_MAP.get(str(p.get("mode", "")).lower(), PartitionMode.UNKNOWN)
    source = p.get("source") or {}
    source_kind = str(source.get("type", "")).lower()
    if source_kind == "entitypartitionsource":
        # Direct-Lake: a Fabric Lakehouse entity reference, no M query to carry
        # over — WS5's repoint step synthesizes a fresh Snowflake M partition
        # from scratch for these, same as it does for every other migrated table.
        return Partition(name=p["name"], mode=mode, source_type="directlake", expression="")
    if source_kind == "calculated":
        return Partition(
            name=p["name"],
            mode=mode,
            source_type="calculated",
            expression=_text(source.get("expression")),
        )
    if source_kind == "query":
        return Partition(
            name=p["name"], mode=mode, source_type="query", expression=_text(source.get("query"))
        )
    # default/"m": the vast majority of import/DirectQuery partitions
    return Partition(
        name=p["name"], mode=mode, source_type="m", expression=_text(source.get("expression"))
    )


def _map_table(t: dict) -> Table:
    name = t["name"]
    return Table(
        name=name,
        columns=[_map_column(c) for c in t.get("columns", [])],
        measures=[_map_measure(m) for m in t.get("measures", [])],
        hierarchies=[_map_hierarchy(h) for h in t.get("hierarchies", [])],
        partitions=[_map_partition(p) for p in t.get("partitions", [])],
        is_hidden=bool(t.get("isHidden", False)),
        description=t.get("description"),
        lineage_tag=t.get("lineageTag"),
        is_auto_date_table=name.startswith(_AUTO_DATE_PREFIXES),
        annotations=_annotations(t),
    )


_CROSS_FILTER_MAP = {
    "onedirection": "singleDirection",
    "singledirection": "singleDirection",
    "bothdirections": "bothDirections",
    "automatic": "singleDirection",
}


def _map_relationship(r: dict) -> Relationship:
    cf = _CROSS_FILTER_MAP.get(
        str(r.get("crossFilteringBehavior", "")).lower(), "singleDirection"
    )
    return Relationship(
        name=r.get("name") or f"{r['fromTable']}_{r['toTable']}",
        from_table=r["fromTable"],
        from_column=r["fromColumn"],
        to_table=r["toTable"],
        to_column=r["toColumn"],
        from_cardinality=str(r.get("fromCardinality", "many")).lower(),
        to_cardinality=str(r.get("toCardinality", "one")).lower(),
        cross_filtering_behavior=cf,
        is_active=bool(r.get("isActive", True)),
        security_filtering_behavior=r.get("securityFilteringBehavior"),
    )


def _map_role(r: dict) -> Role:
    perms: dict[str, str] = {}
    for tp in r.get("tablePermissions", []):
        expr = tp.get("filterExpression")
        if expr:
            perms[tp["name"]] = _text(expr)
    return Role(
        name=r["name"],
        model_permission=r.get("modelPermission", "read"),
        table_permissions=perms,
    )


def parse_bim_dict(doc: dict) -> SemanticModel:
    model_json = doc.get("model")
    if not isinstance(model_json, dict):
        raise BimParseError("model.bim: no top-level 'model' object")

    model = SemanticModel(
        name=doc.get("name") or "Model",
        culture=model_json.get("culture"),
        annotations=_annotations(model_json),
    )
    for t in model_json.get("tables", []):
        model.tables.append(_map_table(t))
    for r in model_json.get("relationships", []):
        model.relationships.append(_map_relationship(r))
    for role in model_json.get("roles", []):
        model.roles.append(_map_role(role))
    for expr in model_json.get("expressions", []):
        model.expressions[expr["name"]] = _text(expr.get("expression"))
    return model


def parse_bim_file(path: Path) -> SemanticModel:
    if not path.is_file():
        raise BimParseError(f"not a file: {path}")
    try:
        doc = json.loads(path.read_text(encoding="utf-8-sig"))
    except ValueError as e:
        raise BimParseError(f"{path}: invalid JSON ({e})") from e
    try:
        return parse_bim_dict(doc)
    except KeyError as e:
        raise BimParseError(f"{path}: missing required TMSL field {e}") from e
