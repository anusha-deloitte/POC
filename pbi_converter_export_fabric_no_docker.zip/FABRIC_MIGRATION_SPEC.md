# Fabric → Snowflake Migration Pipeline — Spec

**How to use this document**: this is written for a fresh Claude Code session with
no memory of the conversation that produced it. It should be opened with the
working directory set to `pbi_converter_export_fabric_no_docker` (this folder).
Read this whole file before writing any code. Where it says "verify first,"
actually verify — don't assume the note is still accurate.

## 0. What this app is, today

`pbi_converter_export_fabric_no_docker` is a copy of a working PBI → React
converter (`pbi_converter_export_no_docker`, sibling folder on Desktop). Today
it: parses a `.pbip` project (PBIR pages/visuals + TMDL semantic model),
compiles DAX measures to SQL against a **live Snowflake connection**, migrates
base tables from Postgres/SQL Server/MySQL/Oracle into Snowflake when the
report was born elsewhere, deploys a governed Snowflake Semantic View, and
renders a spec-driven React dashboard that queries a backend API (the backend
holds the Snowflake connection; the browser never sees it). See:

- `backend/app/services/connections.py` — Snowflake connection profiles (Fernet-encrypted secrets)
- `backend/app/services/migration.py` / `object_migration.py` — source DB → Snowflake table/view/proc migration, incl. T-SQL → Snowflake transpilation via `sqlglot`
- `backend/app/runtime/engine.py` — DAX-derived QuerySpec → SQL compiler
- `backend/app/api/dashboards.py` — the batch query API the React app calls
- `backend/app/parsers/{tmdl,pbir,bundle}.py` — **read-only** PBIP parsing
- `backend/app/services/export.py` — exports a standalone React project (zip)
- `frontend/src/dashboard/` — the spec-driven renderer

This spec adds a **new capability**: taking Power BI reports that today sit on
top of Microsoft Fabric (bronze/silver/gold medallion layers built by Fabric
notebooks, with Power BI in DirectQuery/Direct Lake mode against Fabric's gold
layer) and re-platforming them onto Snowflake, so Fabric is removed from the
picture entirely — while extending/aligning this existing codebase rather than
building something new.

## 1. Decisions already made (do not re-litigate these)

1. **Scope of "new app"**: extend this folder (`pbi_converter_export_fabric_no_docker`)
   in place. Not a new/third repo.
2. **Baseline sync**: this folder has drifted behind `pbi_converter_export_no_docker`
   (the "original") since it was copied. Before any Fabric work, **re-sync this
   folder to the original's current state** (see Workstream 0 — this is not
   optional and not small).
3. **Deployment model**: single-user **native desktop app** on each analyst's
   own Windows machine (not a shared hosted service). This is why the original
   moved to `start.ps1`/`stop.ps1` + process-local Snowflake sessions, and why
   Snowflake **external-browser SSO** auth makes sense (backend and browser
   share a machine).
4. **Docker**: drop it. Remove `docker-compose*.yml` and both `Dockerfile`s
   from this folder; native `start.ps1`/`stop.ps1` becomes the only run path,
   matching the original.
5. **Fabric authentication**: **not needed**. Fabric notebooks/SQL scripts are
   ingested as uploaded artifacts (a zip), never via a live Fabric connection
   or the Fabric REST API. No Entra ID / Fabric auth work in this phase.
6. **Snowflake auth**: port the original's `EXTERNAL_BROWSER` auth method
   (already built there — `backend/app/services/connections.py` has
   `AuthMethod.EXTERNAL_BROWSER` → `authenticator="externalbrowser"`) into this
   folder as part of the re-sync. Existing methods (password, key-pair, OAuth
   client-credentials, PAT) stay.
7. **What gets built in Snowflake**: the Fabric notebooks'/scripts' bronze→
   silver→gold transform logic gets translated and executed **directly against
   Snowflake's own raw data** (raw already lives in Snowflake — confirmed by
   the user), producing the same tables Fabric would have produced. This is
   new work, but it is an **extension of the existing migration/transpile
   machinery** in `object_migration.py`, not a parallel system — see
   Workstream 3.
8. **Object type**: everything this new pipeline creates in Snowflake
   (bronze/silver/gold tables, and any Dynamic Tables) must be **TRANSIENT**.
   This applies **only to objects created by this new Fabric pipeline** — the
   existing Postgres/SQL Server/MySQL/Oracle migration paths are unchanged
   (they keep creating permanent tables) unless told otherwise.
9. **Refresh**: scheduled/incremental refresh **is** in scope for this phase
   (not deferred) — Snowflake Tasks and/or Dynamic Tables, created as
   TRANSIENT, mirroring whatever cadence the Fabric pipeline ran on.
   **`CREATE ... TRANSIENT DYNAMIC TABLE` is confirmed real, documented,
   generally-available Snowflake syntax** (verified against Snowflake's own
   docs — see [CREATE DYNAMIC
   TABLE](https://docs.snowflake.com/en/sql-reference/sql/create-dynamic-table),
   [Dynamic tables](https://docs.snowflake.com/en/user-guide/dynamic-tables-about));
   this is no longer an open design question. The only remaining check is a
   deployment-time one, not a design gap: confirm Dynamic Tables are enabled
   on the specific target account before the first real run (some Snowflake
   features roll out gradually per account/region), and fall back to a
   TRANSIENT base table refreshed by a scheduled Task running
   `CREATE OR REPLACE TRANSIENT TABLE ... AS SELECT` if not.
   - **Considered and rejected: dropping Dynamic Tables entirely in favor of
     Task+CTAS everywhere** (simpler — one mechanism instead of two, since
     Task+CTAS is already needed for imperative layers anyway). Rejected
     because Dynamic Tables give incremental refresh (only recomputed rows,
     not a full rebuild every cycle) and automatic dependency-aware
     scheduling across the bronze→silver→gold chain "for free" — real
     operational value at production scale, not just implementation
     convenience. Keep the two-path design: Dynamic Table for single-SELECT
     layers, Task+stored-proc for imperative ones (already reflected in WS3).
10. **PBI output — the big one**: two things must both be delivered:
    - (a) **Repoint the customer's actual existing report file in place** —
      same visuals, same pages, same layout, only the data source changes
      from Fabric to the new Snowflake gold-layer tables/views. This is why
      visual fidelity is a non-issue here: nothing about the visual layer is
      regenerated.
    - (b) Additionally, produce a **downloadable project file** (mirroring the
      existing `/dashboard/export` "download a zip" pattern) that the user can
      import into Power BI Desktop (or a remote/PBI-service viewer) to check
      the repointed visuals and connection settings.
    - **Verify first / risk**: this app's parsers (`backend/app/parsers/`) are
      currently **read-only**. There is no TMDL/PBIR writer today. Building one
      (even a minimal one that only rewrites the M partition expression + the
      Direct-Lake-mode flag) is new, nontrivial engineering — budget for it
      accordingly, don't treat it as "just like export.py."
    - **`.pbip` vs `.pbix`**: `.pbip` is a plain-text project (PBIR + TMDL) —
      safe to read and write. `.pbix` is a compiled, undocumented binary format
      (its internal data model is not a public spec) — there is no reliable
      in-house way to hand-author or patch one. **`.pbip` is the real,
      supported output** (Power BI Desktop opens `.pbip` projects natively
      since the format shipped out of preview); `.pbix` production stays a
      stretch goal only achievable via a third-party tool (e.g. the
      open-source `pbi-tools` project) or by scripting Power BI Desktop
      itself, and is not committed to.
    - **How customers get us a `.pbip` in the first place — resolved**: Power
      BI Desktop's *File → Save As → Power BI Project (.pbip)* is a manual,
      local, one-time conversion the customer does themselves (Fabric/the
      Service never does this automatically) — **document this as a required
      manual step in the app's user-facing docs/upload-step copy.** It's
      reversible (Microsoft's own FAQ confirms a `.pbip` can be Saved-As back
      to `.pbix`), so it's a safe, non-destructive ask.
    - **The `.bim`-instead-of-TMDL trap — resolved, and better than first
      thought**: for a model that's Direct-Lake/Fabric-hosted, that manual
      Save-As frequently produces a legacy `model.bim` (TMSL) file instead of
      TMDL folders, which this app's parser (`backend/app/parsers/tmdl.py`)
      does not read — `backend/app/parsers/bundle.py` already detects this
      exact case today and raises a pointed error (`"semantic model uses TMSL
      (model.bim); re-save with the TMDL preview feature enabled"`) rather
      than failing silently.
      - **Chosen approach (primary): write our own `.bim`/TMSL parser in pure
        Python.** TMSL is not a proprietary/undocumented format — it's a
        published, documented Microsoft JSON schema (the Analysis Services
        Tabular Object Model, serialized as JSON — see [TMSL
        Reference](https://learn.microsoft.com/en-us/analysis-services/tmsl/tabular-model-scripting-language-tmsl-reference)
        and [Object Definitions in
        TMSL](https://learn.microsoft.com/en-us/analysis-services/tmsl/tmsl-reference-tabular-objects)).
        It represents the *exact same* object model TMDL does (tables,
        columns, measures, relationships, expressions/M partitions) — just as
        one JSON tree instead of TMDL's indentation-based text format. Build
        `backend/app/parsers/bim.py`: a JSON→IR mapper from `model.bim`'s
        TMSL structure (`model.tables[].columns[]`, `model.tables[].measures[]`,
        `model.relationships[]`, `model.expressions[]`, etc.) into the *exact
        same* IR classes `tmdl.py` already produces (`SemanticModel`, `Table`,
        `Column`, `Measure`, `Relationship` in `app/ir/model.py`) — likely
        **less** code than `tmdl.py`, since JSON parsing needs no custom
        grammar. Wire it into `bundle.py`'s `load_pbip()`: where it currently
        raises on finding `model.bim`, instead route to `parse_bim_file()`
        when `definition/` is absent but `model.bim` is present.
        - **Why this beats the alternatives below**: no live Fabric
          connection/auth needed (unlike the `sempy_labs` notebook route), no
          AGPL dependency or .NET runtime (unlike `pbi-tools`), no extra step
          for the customer beyond the Save-As they'd do anyway, and it's a
          natural extension of the existing parsers module.
        - **Verify first** (not yet done — no live Direct-Lake `model.bim`
          sample was available to test against): confirm the TMSL schema's
          coverage of every construct our IR needs (time-intelligence
          measures, calculation groups, RLS roles, hierarchies — `tmdl.py`
          already handles these per `app/ir/model.py`'s `Role`/`Hierarchy`
          classes, so the TMSL mapper needs equivalent coverage, not fewer
          features). Get a real `model.bim` from an actual Direct-Lake Save-As
          as the first test fixture before considering this done.
        - **Related, smaller risk worth checking alongside this**: PBI
          Desktop has a *separate* preview toggle for the report side (PBIR
          vs. the older single-file report format), independent of the
          model's TMDL/TMSL toggle — `backend/app/parsers/pbir.py` only reads
          the PBIR folder format today, with no legacy-format detection or
          error message the way `bundle.py` has for `.bim`. Confirm a
          Direct-Lake Save-As also yields PBIR for the report side; if not,
          that needs the same kind of explicit-detection treatment `.bim` just
          got, not a silent failure.
      - **Fallback path (already built, keep as a secondary route)**: for
        cases where there's no local `.bim`/`.pbix` to read at all (the report
        was never opened in Desktop, only ever lives in the Fabric service),
        [`fabric_extraction_toolkit/extract_pbip_from_fabric.ipynb`](fabric_extraction_toolkit/extract_pbip_from_fabric.ipynb)
        remains available: run inside the customer's own already-authenticated
        Fabric notebook, it calls `sempy_labs.get_semantic_model_definition()`
        / `get_item_definition()` to pull TMDL + PBIR directly from Fabric's
        REST API (server-side TMSL→TMDL conversion, no auth work on our side).
        Still unverified against a live tenant — see its own markdown cells
        for the specific spots to check on first run.
      - **Dropped**: `pbi-tools` (AGPL-3.0-licensed; the only version with TMDL
        support post-dates its relicense from more permissive terms, so there
        is no way to get its TMDL conversion without taking on AGPL). The
        pure-Python TMSL parser above solves the same problem without that
        cost, so this option is not pursued.
    - **Resolved**: if a customer genuinely cannot produce a `.pbip`/`.bim`
      either way (model isn't Fabric-hosted, and it's never been opened in
      Desktop), that customer is **out of scope for this phase** — no
      speculative `.pbix`-input parsing gets built against a hypothetical
      need. See §5.
11. **Connectivity mode (Import vs DirectQuery) for the repointed report**:
    expose this as a **user-facing dropdown** in the wizard (don't hard-code
    it) — mirrors the existing `mode: "live" | "accelerated"` selector already
    used elsewhere in this app (`ConvertRequest`/`ReimagineRequest` in
    `backend/app/api/dashboards.py`). **Default to DirectQuery** — it's the
    closest behavioral match to how Direct Lake worked against Fabric (live,
    no staleness), at the cost of per-interaction Snowflake load. Let the user
    override to Import per conversion.
12. **Stop-script bug**: `stop.ps1` (original folder) uses `taskkill /F /T
    /PID` against the top-level PID recorded by `start.ps1`, which should in
    principle kill the whole process tree (including uvicorn's `--reload`
    child). The user reports stale backend processes surviving anyway. This
    is in scope as **part of the re-sync workstream** (Workstream 0) — don't
    guess at the cause from this document; actually run `start.ps1` /
    `stop.ps1` in this folder after the re-sync, inspect what's left with
    `Get-Process`/`Get-NetTCPConnection -LocalPort 8000,5173`, and fix from an
    observed repro. A likely-robust fallback if PID-tree-kill keeps being
    unreliable: kill by the ports the app is known to bind (8000/5173) instead
    of relying on the recorded PID tree at all.
13. **Where bronze/silver/gold objects live in Snowflake**: inside whichever
    database the customer's existing Snowflake connection profile already
    points to (`ConnectionStore` — same account/database/warehouse used
    everywhere else in this app; no separate connection or account for this
    pipeline). Within that database, one schema per medallion layer, named by
    extending the *existing* convention already in
    `object_migration.py`'s `map_schema()` (which derives related schema names
    by suffixing the customer's configured target schema):
    - `<target_schema>__BRONZE`
    - `<target_schema>__SILVER`
    - `<target_schema>__GOLD`

    Table names within each schema keep the names the Fabric
    notebooks/scripts used for that object (e.g. `cms_provider_dim_drug`),
    since decision #10's schema/fidelity gate (WS4) needs those names to match
    what the PBI semantic model expects — don't introduce a separate internal
    naming scheme that then needs remapping back.

## 2. Target architecture (after this work)

```
[Fabric notebooks/.sql, uploaded as a zip]      [Snowflake — raw data already present]
              |                                              |
              v                                              |
      classify + translate  ------------------------------>  build bronze/silver/gold
      (sqlglot spark/tsql        (TRANSIENT tables/           as TRANSIENT objects,
       dialects; DataFrame-       Dynamic Tables; scheduled    scheduled refresh
       cell rule-based rewrite;   via Snowflake Tasks)         (Tasks / Dynamic Tables)
       LLM-assisted fallback,
       execution-validated)
              |
              v
   schema/fidelity gate: created gold objects' table/column
   names & grain vs. what the PBI semantic model expects
              |
              v
   repoint the real .pbip project's data source (M expression +
   Direct-Lake-mode flag) at the new Snowflake objects
   (Import or DirectQuery, user-selected, default DirectQuery)
              |
              v
   [.pbip download] --(open in PBI Desktop)--> same visuals, Snowflake-backed
              |
              v
   [existing React-conversion pipeline runs unchanged from here —
    it already assumes a Snowflake-sourced PBI report]
```

Everything below "schema/fidelity gate" onward for the *React* dashboard path
is **already built** and should not need changes — that's the value of this
being additive to the existing app rather than a rewrite.

## 3. Workstreams

### WS0 — Baseline re-sync (do this first, before any Fabric-specific code)

Bring this folder up to the original's current state. This is a real merge
task, not a copy-paste:

- Port: `EXTERNAL_BROWSER` Snowflake auth (`services/connections.py`),
  structured logging + secret redaction (`core/logging.py`), client-side
  error reporting (`api/client_logs.py`, `frontend/src/api/errorReporting.ts`),
  published-dashboard sharing tokens (`services/dashboard_tokens.py`,
  `api/published_dashboards.py`), process-local Snowflake session pooling
  (`services/snowflake_sessions.py`), the Horizon LLM gateway client
  (`services/horizon_client.py` — **confirmed in scope, pull it in**), and
  `start.ps1`/`stop.ps1`.
- Remove: `docker-compose.yml`, `docker-compose.local.yml`,
  `backend/Dockerfile`, `frontend/Dockerfile`, `.dockerignore`.
- Diff every other changed file this spec's own investigation found
  (`agents/pipeline.py`, `agents/tier2.py`, `agents/visual_compare.py`,
  `api/connections.py`, `api/dashboards.py`, `api/deps.py`, `api/governance.py`,
  `api/semantic_deploy.py`, `core/config.py`, `main.py`, `services/export.py`,
  `services/ingest.py`, `services/migration.py`, `services/object_migration.py`,
  and the corresponding frontend files under `frontend/src/`) and reconcile —
  don't assume the list above is exhaustive; re-run a recursive diff between
  the two folders (excluding `node_modules`, `.venv`, caches, build output) as
  the actual source of truth at the time this work starts, since more drift
  may have accumulated.
- Fix the `stop.ps1` stale-process bug (see decision #12) as part of this
  workstream, from an actual observed repro in this folder post-sync.

### WS1 — Fabric artifact ingestion

- New store (`backend/app/services/fabric_notebooks.py` or similar): accepts a
  **single zip** (reuse `safe_extract_zip()` from `services/ingest.py`
  verbatim — it's already generic, not PBIP-specific) containing whatever mix
  of `.ipynb`, `.sql`, `.pbip` (with either TMDL or `model.bim` inside —
  both now supported, see decision #10), and other reference files (docs,
  images, `.pbix`) the customer's Fabric workspace export has. Don't require a
  fixed folder layout.
- Classify by file type: `.ipynb` → parsed notebook cells (code + markdown,
  in order); `.sql` → raw script text; `.pbip` → run through the existing
  `load_pbip()`, now `.bim`-aware per decision #10's `bim.py` parser;
  everything else → recorded as ignored reference material, shown to the
  user, not parsed.
- **Layer tagging (bronze/silver/gold/skip) is a human step**, not inferred —
  filename conventions won't generalize across customers. After upload, show
  a review grid (one row per discovered notebook/script) with an editable
  layer dropdown (pre-filled with a best-effort guess) and a schedule field.
  This mirrors the existing "parse deterministically, human confirms" pattern
  already used for fix/override review elsewhere in this app.
- Store as `fabric_pipeline.json` per conversion, next to the existing
  `bundle.json`.
- The upload UI's instructions/copy should point customers at
  `fabric_extraction_toolkit/extract_pbip_from_fabric.ipynb` (decision #10) as
  how to get a real `.pbip` into the zip if their model is Fabric-hosted —
  don't make them discover Save-As's `.bim` trap on their own.

### WS2 — Translation engine

Validated against a real sample already (see §4) — build in this priority
order, cheapest/lowest-risk first:

1. **SQL-expressible cells** (`spark.sql("...")` string literals, or whole
   `.sql` files): extract and run through `sqlglot` with `read="spark"` (add
   `"fabric": "spark"` to the `_SRC_DIALECT` map in `object_migration.py`) or
   `read="tsql"` for T-SQL scripts, emitting `dialect="snowflake"`. This is
   the same pipeline `transpile_view_definition()`/`transpile_procedure()`
   already run for SQL Server — extend, don't duplicate.
   - T-SQL stored procs commonly wrap DDL in
     `IF NOT EXISTS (SELECT * FROM sysobjects WHERE ...) BEGIN CREATE TABLE
     ... END` — normalize this idiom to a plain
     `CREATE TABLE IF NOT EXISTS ...` (Snowflake supports that directly),
     don't try to make sqlglot parse the T-SQL control flow.
2. **DataFrame-API cells that are expression-only** (chains of
   `.withColumn()`/`.cast()`/`concat()`/dropped columns, no custom UDFs and no
   joins/aggregations expressed imperatively): build a small rule-based
   rewriter that turns the chain into a single `SELECT` list. Watch for
   filename-derived columns via a custom UDF — Snowflake's `METADATA$FILENAME`
   pseudocolumn + `REGEXP_SUBSTR` is very often the direct native equivalent
   (validated in the sample below).
3. **Everything else** (genuine imperative logic, custom UDFs beyond simple
   patterns, ML scoring, etc.): LLM-assisted candidate translation,
   execution-validated before acceptance — reuse the existing tier-2 pattern
   (`app/agents/tier2.py`, `app/validation/harness.py`) already built for DAX
   measures the deterministic compiler can't reach. Surface anything that
   doesn't validate cleanly through the existing overrides/apply-fixes review
   UI pattern rather than silently accepting a guess.
4. **External-ingestion cells** (e.g. downloading files from a public HTTP API
   into Fabric's Files area): these are not transforms — do not attempt to
   translate them. They map conceptually to however raw data already lands in
   Snowflake (out of scope here, per decision #7 — raw is assumed present).

### WS3 — Snowflake object build + scheduling

- Objects land in `<target_schema>__BRONZE` / `__SILVER` / `__GOLD` within the
  customer's configured Snowflake database, per decision #13 — create these
  schemas if absent (`CREATE SCHEMA IF NOT EXISTS ...`, same as
  `migrate_tables()` already does for its own target schema).
- Materialize each layer as a **TRANSIENT** Snowflake object: `CREATE
  TRANSIENT TABLE ... AS SELECT` for one-shot layers, `CREATE OR REPLACE
  TRANSIENT DYNAMIC TABLE ... TARGET_LAG = '...' WAREHOUSE = ...` where a
  single declarative SELECT is enough (reuse the existing indexed-view →
  Dynamic Table pattern in `object_migration.py`, adding the `TRANSIENT`
  keyword).
- For multi-step/imperative layers: a Snowflake stored procedure, invoked by a
  scheduled **Task** (`CREATE TASK ... SCHEDULE = 'USING CRON ...' AS CALL
  ...()`), chained bronze→silver→gold via `AFTER <parent_task>`. This
  completes the "schedule as a TASK" idea `object_migration.py` already
  comments on for the SQL Server proc-migration path but never implements.
- Cadence: captured as metadata at upload/review time (WS1), since it isn't
  present in the notebook/script itself.

### WS4 — Schema/fidelity gate

- After the objects above are built, diff their columns (name, type, grain)
  against what the PBI semantic model expects (already parsed via
  `backend/app/parsers` from the `.pbip`, if provided in the WS1 upload).
  Block/report mismatches rather than silently binding something wrong.

### WS5 — PBI repoint + downloadable project

- Build a minimal TMDL writer (net-new — see decision #10's risk note): given
  a parsed `.pbip` project, rewrite each table's data-source partition to
  point at the new Snowflake gold-layer objects, and set the connectivity
  mode (Import/DirectQuery, per the user-facing dropdown in decision #11).
  The M-expression template for Snowflake already exists —
  `_SNOWFLAKE_M_TEMPLATE` in `backend/app/services/migration.py` — reuse it as
  the starting point, extended to also handle a Direct-Lake-mode partition
  needing conversion to Import/DirectQuery mode (that conversion is new: today
  `rewrite_bundle_to_snowflake()` only ever rewrites this app's own internal
  `bundle.json`, never a real `.pbip` file on disk).
- Serve a **download endpoint** (`GET .../fabric-pipeline/{id}/export-pbip` or
  similar), mirroring the existing `GET /dashboard/export` React-zip download
  in shape: re-zip the repointed `.pbip` project folder and return it.
- `.pbix` production: treat as a separate, later spike (see decision #10) —
  don't block this workstream's completion on it.

### WS6 — Downstream (unchanged)

Once a report is Snowflake-native (whether via this new pipeline or the
existing Postgres/SQL Server migration path), the existing conversion →
React-dashboard flow (`SemanticEngine`, `/dashboard/query`, the React
renderer, `export.py`) needs **no changes**. Confirm this remains true as
integration testing proceeds — it's the whole reason this is additive rather
than a rewrite, and any code path that turns out to need touching here is a
sign of an over-tight coupling worth reconsidering.

## 4. Reference fixture — already validated, use it to test WS2

`C:\Users\nukaditya\OneDrive - Deloitte (O365D)\Desktop\Repositories\fabric-samples-healthcare\analytics-bi-directlake-starschema`
— Microsoft's public CMS Medicare Part D sample, same bronze/silver/gold shape
as the real target. Already empirically tested against this exact codebase's
`sqlglot` dependency (see `backend/.venv`, sqlglot 30.18.0 confirmed installed):

- `03-CreateCMSStarSchemaTables.ipynb` (the actual gold/star-schema layer) —
  **all 5** `spark.sql(...)` cells parse with `read="spark"` and re-emit
  cleanly with `dialect="snowflake"`, including window functions, multi-way
  joins, and `IS NOT DISTINCT FROM` null-safe joins. Zero manual fixes needed.
- `02-CreateCMSDataTable.ipynb` (silver layer) — DataFrame-API only, but
  shallow: casts, `concat`, a dropped column, and one custom UDF (extracts a
  year from the source filename) that has a clean native Snowflake
  replacement (`METADATA$FILENAME` + `REGEXP_SUBSTR`), confirmed to parse as
  valid Snowflake SQL once hand-translated.
- `01-DownloadCMSDataCsvFiles.ipynb` — external HTTP ingestion, not a
  transform; skip per WS2 point 4.
- `scripts/01_CMS_provider_dimensions_SPROC.sql` /
  `02_CMS_provider_fact_SPROC.sql` — an *alternate*, already-plain-SQL version
  of the same gold layer (Fabric Warehouse path). The `INSERT INTO ... SELECT`
  bodies parse and transpile cleanly with `read="tsql"`; the wrapping
  `CREATE PROCEDURE ... BEGIN IF NOT EXISTS(sysobjects) ... END` does not
  parse as one unit (expected — T-SQL control flow), confirming the
  extract-the-statements-not-the-wrapper approach `transpile_procedure()`
  already uses is the right one.
- Only ships a `.pbix`, not a `.pbip` — a good real-world candidate for
  testing the `.bim` path (decision #10): opening this in Power BI Desktop and
  doing Save-As → Power BI Project would be a reasonable first real `model.bim`
  sample to validate `bim.py` against, if/when this specific report is opened
  locally. If the model here isn't actually Direct-Lake/Fabric-hosted, Save-As
  may just produce TMDL directly (nothing to test); the `extract_pbip_from_
  fabric.ipynb` notebook route only applies if the model genuinely lives in a
  Fabric workspace, which this static fixture alone doesn't establish either
  way.

## 5. Explicit non-goals for this phase

- No live Fabric connection, Fabric REST API integration, or Fabric auth of
  any kind.
- No `.pbix` binary generation as a committed deliverable (stretch-goal only).
- No changes to the existing Postgres/SQL Server/MySQL/Oracle migration paths
  or their object types (they stay permanent tables).
- No multi-user/hosted deployment concerns (single-user native app only).
- No numeric dual-run-parity gate is *required* for this phase (the schema
  gate in WS4 is required; add numeric parity later only if asked — the
  existing `validation/harness.py` machinery would make this cheap to add).
- No support for a customer whose report has never been opened in Power BI
  Desktop and doesn't live in a Fabric workspace either — there is no route to
  a `.pbip`/`.bim` for that case (decision #10), and building speculative
  `.pbix`-input parsing against a hypothetical need is out of scope.
- No dropping Dynamic Tables in favor of a single Task+CTAS mechanism
  everywhere — considered under decision #9 and kept as the two-path design.

## 6. Verification checklist for whoever builds this

Every decision above is final — nothing here is "should we," only "confirm
this specific technical fact before relying on it," each already called out
inline at the relevant decision. Consolidated here so nothing gets missed:

1. **TMSL schema coverage** (decision #10): get a real `model.bim` from an
   actual Direct-Lake Save-As and confirm `bim.py`'s mapping covers every IR
   construct `tmdl.py` handles — time-intelligence measures, calculation
   groups, RLS roles, hierarchies — not just the common case.
2. **PBIR vs. legacy report format** (decision #10): confirm a Direct-Lake
   Save-As also yields the PBIR folder format for the report side, not the
   older single-file format `pbir.py` doesn't handle.
3. **`extract_pbip_from_fabric.ipynb` against a live tenant** (decision #10):
   unverified — check the exact `format` string Fabric's API accepts for
   Report items, and whether `definition.pbir`/`definition.pbism` come back
   as part of the API response or need the notebook's fallback synthesis.
4. **Dynamic Tables enabled on the target account** (decision #9): a
   deployment-time check, not a design question — confirm before the first
   real WS3 run, fall back to Task+CTAS per-account if not enabled.
5. **`stop.ps1` stale-process repro** (decision #12): run `start.ps1` /
   `stop.ps1` in this folder post-re-sync, observe what actually survives with
   `Get-Process`/`Get-NetTCPConnection -LocalPort 8000,5173`, fix from that
   observation rather than the hypothesis in decision #12.
6. **WS6 truly needs no changes**: confirm as integration testing proceeds
   that the existing `SemanticEngine`/`/dashboard/query`/React-renderer path
   really does need zero modification once a report is Snowflake-native via
   this new pipeline — if something there turns out to need touching, that's
   a signal to reconsider the coupling, not just patch around it.
