import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { AlertTriangle, ChevronRight, FileCode2, FileSpreadsheet, FileText, Sparkles } from 'lucide-react'
import { useEffect, useState } from 'react'
import {
  fabricPipelinesApi,
  type ArtifactTranslation,
  type CellResult,
  type FabricArtifact,
  type FabricLayer,
  type Tier3Result,
} from '../../api/fabricPipelines'
import { useFabricWizard } from '../../store/fabricWizard'

const LAYER_LABEL: Record<FabricLayer, string> = {
  bronze: 'Bronze',
  silver: 'Silver',
  gold: 'Gold',
  skip: 'Skip',
}

const KIND_ICON = { notebook: FileCode2, sql: FileText, pbip: FileSpreadsheet, other: FileText }

const TIER_BADGE: Record<string, string> = {
  sql: 'badge-green',
  dataframe: 'badge-green',
  external_ingestion: 'badge-blue',
  unhandled: 'badge-amber',
  noop: 'badge-blue',
}

function Tier3Panel({
  pipelineId,
  artifactId,
  cell,
}: {
  pipelineId: string
  artifactId: string
  cell: CellResult
}) {
  const connectionId = useFabricWizard((s) => s.connectionId)
  const [result, setResult] = useState<Tier3Result | null>(null)
  const runTier3 = useMutation({
    mutationFn: () =>
      fabricPipelinesApi.runTier3(pipelineId, artifactId, cell.cell_index, connectionId!),
    onSuccess: setResult,
  })

  if (!connectionId) {
    return (
      <p className="mt-1.5 text-[11px] text-surface-500">
        Set a Snowflake connection on the Build step to try tier-3 (LLM) translation for this cell.
      </p>
    )
  }

  return (
    <div className="mt-1.5">
      <button
        className="btn-secondary flex items-center gap-1.5 !px-2.5 !py-1 !text-xs"
        disabled={runTier3.isPending}
        onClick={() => runTier3.mutate()}
      >
        <Sparkles className="h-3 w-3" strokeWidth={1.8} />
        {runTier3.isPending ? 'Asking the LLM…' : 'Try tier 3 (LLM)'}
      </button>
      {runTier3.isError && (
        <p role="alert" className="mt-1 text-[11px] text-brand-red">
          {runTier3.error.message}
        </p>
      )}
      {result && (
        <div className="mt-1.5">
          {result.accepted ? (
            <>
              <p className="text-[11px] font-semibold text-brand-dark">
                Accepted after {result.attempts} attempt{result.attempts === 1 ? '' : 's'} —
                executed successfully against your connection.
              </p>
              <pre className="mt-1 overflow-x-auto rounded bg-surface-900 p-2 text-[11px] text-surface-100">
                {result.sql}
              </pre>
            </>
          ) : (
            <p className="text-[11px] text-brand-amber">
              Not accepted: {result.trace[result.trace.length - 1] ?? 'no reason given'}
            </p>
          )}
        </div>
      )}
    </div>
  )
}

function TranslationPreview({ pipelineId, artifactId }: { pipelineId: string; artifactId: string }) {
  const query = useQuery({
    queryKey: ['fabric-translation', pipelineId, artifactId],
    queryFn: () => fabricPipelinesApi.previewTranslation(pipelineId, artifactId),
  })

  if (query.isLoading) return <p className="p-3 text-xs text-surface-500">Translating…</p>
  if (query.isError)
    return (
      <p className="p-3 text-xs text-brand-red" role="alert">
        {query.error.message}
      </p>
    )
  const translation = query.data as ArtifactTranslation
  if (translation.cells.length === 0)
    return <p className="p-3 text-xs text-surface-500">Nothing to translate in this artifact.</p>

  return (
    <div className="space-y-2 border-t border-surface-200 bg-surface-50 p-3">
      {translation.cells.map((cell) => (
        <div key={cell.cell_index} className="rounded-lg border border-surface-200 bg-white p-2">
          <div className="mb-1 flex items-center gap-2 text-[11px]">
            <span className="font-mono text-surface-500">cell {cell.cell_index}</span>
            <span className={TIER_BADGE[cell.tier] ?? 'badge-blue'}>{cell.tier}</span>
            {cell.reason && <span className="text-surface-500">{cell.reason}</span>}
          </div>
          {cell.statements.map((stmt, i) => (
            <div key={i} className="mt-1">
              {stmt.target_table && (
                <div className="text-[11px] font-semibold text-surface-600">
                  → {stmt.target_table}
                </div>
              )}
              <pre className="mt-1 overflow-x-auto rounded bg-surface-900 p-2 text-[11px] text-surface-100">
                {stmt.sql}
              </pre>
              {stmt.note && <p className="mt-1 text-[11px] text-brand-amber">{stmt.note}</p>}
            </div>
          ))}
          {cell.tier === 'unhandled' && (
            <Tier3Panel pipelineId={pipelineId} artifactId={artifactId} cell={cell} />
          )}
        </div>
      ))}
    </div>
  )
}

function ArtifactRow({
  pipelineId,
  artifact,
  onUpdate,
}: {
  pipelineId: string
  artifact: FabricArtifact
  onUpdate: (patch: Partial<Pick<FabricArtifact, 'layer' | 'schedule' | 'reviewed'>>) => void
}) {
  const [expanded, setExpanded] = useState(false)
  const Icon = KIND_ICON[artifact.kind]
  const editable = artifact.kind === 'notebook' || artifact.kind === 'sql'

  return (
    <>
      <tr
        data-testid={`artifact-row-${artifact.id}`}
        className={`border-b border-surface-200 align-top ${!artifact.reviewed && editable ? 'bg-brand-amber/5' : ''}`}
      >
        <td className="py-2 pr-2">
          {editable && (
            <button
              onClick={() => setExpanded((v) => !v)}
              aria-label={expanded ? 'Collapse translation preview' : 'Expand translation preview'}
              className="flex h-6 w-6 items-center justify-center rounded text-surface-500 hover:bg-surface-100"
            >
              <ChevronRight
                className={`h-4 w-4 transition-transform ${expanded ? 'rotate-90' : ''}`}
                strokeWidth={1.8}
              />
            </button>
          )}
        </td>
        <td className="py-2 pr-3">
          <div className="flex items-center gap-2">
            <Icon className="h-4 w-4 shrink-0 text-surface-500" strokeWidth={1.8} />
            <span className="font-mono text-xs">{artifact.relative_path}</span>
          </div>
        </td>
        <td className="py-2 pr-3 text-xs text-surface-600">{artifact.kind}</td>
        <td className="py-2 pr-3">
          {editable ? (
            <select
              aria-label={`Layer for ${artifact.relative_path}`}
              className="input py-1 text-xs"
              value={artifact.layer}
              onChange={(e) => onUpdate({ layer: e.target.value as FabricLayer })}
            >
              {(Object.keys(LAYER_LABEL) as FabricLayer[]).map((l) => (
                <option key={l} value={l}>
                  {LAYER_LABEL[l]}
                </option>
              ))}
            </select>
          ) : (
            <span className="text-xs text-surface-400">n/a</span>
          )}
        </td>
        <td className="py-2 pr-3">
          {editable ? (
            <input
              aria-label={`Schedule for ${artifact.relative_path}`}
              className="input py-1 text-xs"
              placeholder="e.g. daily 02:00"
              value={artifact.schedule}
              onChange={(e) => onUpdate({ schedule: e.target.value })}
            />
          ) : (
            <span className="text-xs text-surface-400">n/a</span>
          )}
        </td>
        <td className="py-2 pr-3">
          {editable && (
            <label className="flex items-center gap-1.5 text-xs">
              <input
                type="checkbox"
                aria-label={`Reviewed: ${artifact.relative_path}`}
                checked={artifact.reviewed}
                onChange={(e) => onUpdate({ reviewed: e.target.checked })}
              />
              Reviewed
            </label>
          )}
        </td>
      </tr>
      {expanded && editable && (
        <tr>
          <td colSpan={6} className="p-0">
            <TranslationPreview pipelineId={pipelineId} artifactId={artifact.id} />
          </td>
        </tr>
      )}
    </>
  )
}

export function FabricReviewStep() {
  const pipelineId = useFabricWizard((s) => s.pipelineId)
  const setStep = useFabricWizard((s) => s.setStep)
  const setUnsavedChanges = useFabricWizard((s) => s.setUnsavedChanges)
  const qc = useQueryClient()

  const query = useQuery({
    queryKey: ['fabric-pipeline', pipelineId],
    queryFn: () => fabricPipelinesApi.get(pipelineId!),
    enabled: pipelineId !== null,
  })

  const update = useMutation({
    mutationFn: ({
      artifactId,
      patch,
    }: {
      artifactId: string
      patch: Partial<Pick<FabricArtifact, 'layer' | 'schedule' | 'reviewed'>>
    }) => fabricPipelinesApi.updateArtifact(pipelineId!, artifactId, patch),
    onSuccess: (pipeline) => qc.setQueryData(['fabric-pipeline', pipelineId], pipeline),
  })

  const pipeline = query.data
  const reviewedCount = pipeline?.artifacts.filter((a) => a.reviewed && a.layer !== 'skip').length ?? 0
  const unreviewedTransforms =
    pipeline?.artifacts.filter(
      (a) => (a.kind === 'notebook' || a.kind === 'sql') && a.layer !== 'skip' && !a.reviewed,
    ).length ?? 0

  useEffect(() => {
    const dirty = unreviewedTransforms > 0
    setUnsavedChanges(dirty, dirty ? 'artifact review' : null)
    return () => setUnsavedChanges(false, null)
  }, [unreviewedTransforms, setUnsavedChanges])

  if (!pipelineId) return null

  return (
    <section>
      <div className="mb-6 overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div className="kicker mb-1">Step 2 · Review</div>
        <h2 className="text-xl font-bold">Confirm layer tagging &amp; schedules</h2>
        <p className="mt-1 max-w-2xl text-sm text-surface-600">
          Bronze/silver/gold is a best-effort guess, not an inference you can trust — confirm or
          correct each transform before anything gets built in Snowflake. Expand a row to preview
          its translated SQL.
        </p>
      </div>

      {query.isLoading && <p className="text-sm text-surface-500">Loading…</p>}
      {query.isError && (
        <div role="alert" className="rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
          {query.error.message}
        </div>
      )}

      {pipeline && (
        <>
          {pipeline.warnings.length > 0 && (
            <div role="status" className="mb-4 rounded-xl border border-brand-amber/25 bg-brand-amber/10 p-3 text-xs text-brand-amber">
              <div className="mb-1 flex items-center gap-1.5 font-semibold">
                <AlertTriangle className="h-3.5 w-3.5" strokeWidth={1.8} />
                {pipeline.warnings.length} warning{pipeline.warnings.length === 1 ? '' : 's'}
              </div>
              <ul className="list-inside list-disc space-y-0.5">
                {pipeline.warnings.map((w, i) => (
                  <li key={i}>{w}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="card overflow-x-auto p-0">
            <table className="w-full text-left text-xs">
              <thead className="border-b border-surface-200 bg-surface-50 text-[11px] font-semibold text-surface-500 uppercase">
                <tr>
                  <th className="w-8 py-2" />
                  <th className="py-2 pr-3">Path</th>
                  <th className="py-2 pr-3">Kind</th>
                  <th className="py-2 pr-3">Layer</th>
                  <th className="py-2 pr-3">Schedule</th>
                  <th className="py-2 pr-3">Reviewed</th>
                </tr>
              </thead>
              <tbody>
                {pipeline.artifacts.map((artifact) => (
                  <ArtifactRow
                    key={artifact.id}
                    pipelineId={pipelineId}
                    artifact={artifact}
                    onUpdate={(patch) => update.mutate({ artifactId: artifact.id, patch })}
                  />
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-6 flex items-center justify-between">
            <p className="text-xs text-surface-500">
              {reviewedCount} artifact{reviewedCount === 1 ? '' : 's'} ready to build
              {unreviewedTransforms > 0 &&
                ` · ${unreviewedTransforms} transform${unreviewedTransforms === 1 ? '' : 's'} still unreviewed`}
            </p>
            <button
              className="btn-primary"
              disabled={reviewedCount === 0}
              onClick={() => setStep('build')}
            >
              Continue to build plan
            </button>
          </div>
        </>
      )}
    </section>
  )
}
