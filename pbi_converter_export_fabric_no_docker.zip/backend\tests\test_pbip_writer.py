"""WS5: TMDL/.bim partition writer -- repoint a table's data source."""

import json
from pathlib import Path

import pytest

from app.services.pbip_writer import (
    PbipWriteError,
    build_snowflake_m_expression,
    repoint_pbip_project,
    rewrite_bim_table_partition,
    rewrite_tmdl_table_partition,
)

FIXTURE_ROOT = Path(__file__).resolve().parents[2] / "fixtures" / "contoso_sales"
SALES_TMDL_PATH = FIXTURE_ROOT / "Contoso Sales.SemanticModel" / "definition" / "tables" / "Sales.tmdl"

NEW_M = build_snowflake_m_expression(
    account="acme-xy12345",
    warehouse="WH",
    database="mydb",
    schema="tgt__gold",
    object_name="fact_sales_gold",
)


class TestBuildSnowflakeMExpression:
    def test_uppercases_object_identifiers(self):
        assert 'Name="MYDB", Kind="Database"' in NEW_M
        assert 'Name="TGT__GOLD", Kind="Schema"' in NEW_M
        assert 'Name="FACT_SALES_GOLD", Kind="Table"' in NEW_M
        assert 'Snowflake.Databases("acme-xy12345", "WH")' in NEW_M


class TestRewriteTmdlTablePartition:
    def test_real_fixture_partition_rewritten_rest_untouched(self):
        original = SALES_TMDL_PATH.read_text(encoding="utf-8")
        rewritten = rewrite_tmdl_table_partition(original, NEW_M, "directQuery")

        assert "partition Sales = m" in rewritten
        assert "mode: directQuery" in rewritten
        assert "FACT_SALES_GOLD" in rewritten
        assert "FACT_SALES" not in rewritten.replace("FACT_SALES_GOLD", "")  # old object gone

        original_lines = original.splitlines()
        rewritten_lines = rewritten.splitlines()
        # everything before the partition (columns) is byte-for-byte identical
        partition_idx = next(i for i, ln in enumerate(original_lines) if ln.startswith("\tpartition"))
        assert rewritten_lines[:partition_idx] == original_lines[:partition_idx]
        # the trailing annotation after the partition survives too
        assert "annotation PBI_ResultType = Table" in rewritten

    def test_missing_partition_raises(self):
        with pytest.raises(PbipWriteError):
            rewrite_tmdl_table_partition("table X\n\tcolumn Y\n\t\tdataType: string\n", NEW_M, "import")

    def test_preserves_trailing_newline_state(self):
        text = "table X\n\tpartition X = m\n\t\tmode: import\n\t\tsource =\n\t\t\told\n"
        rewritten = rewrite_tmdl_table_partition(text, NEW_M, "import")
        assert rewritten.endswith("\n")
        no_newline = text.rstrip("\n")
        assert not rewrite_tmdl_table_partition(no_newline, NEW_M, "import").endswith("\n")


class TestRewriteBimTablePartition:
    def test_replaces_partition_and_mode(self):
        doc = {
            "model": {
                "tables": [
                    {
                        "name": "Sales",
                        "partitions": [
                            {"name": "Sales", "mode": "directQuery", "source": {"type": "entityPartitionSource"}}
                        ],
                    }
                ]
            }
        }
        found = rewrite_bim_table_partition(doc, "Sales", NEW_M, "import")
        assert found
        part = doc["model"]["tables"][0]["partitions"][0]
        assert part["mode"] == "import"
        assert part["source"]["type"] == "m"
        assert any("FACT_SALES_GOLD" in line for line in part["source"]["expression"])

    def test_unknown_table_returns_false(self):
        doc = {"model": {"tables": []}}
        assert rewrite_bim_table_partition(doc, "Nope", NEW_M, "import") is False

    def test_no_partitions_raises(self):
        doc = {"model": {"tables": [{"name": "Sales", "partitions": []}]}}
        with pytest.raises(PbipWriteError):
            rewrite_bim_table_partition(doc, "Sales", NEW_M, "import")


class TestRepointPbipProject:
    def test_repoints_matching_table_leaves_others_untouched(self, tmp_path):
        dest = tmp_path / "repointed"
        repointed = repoint_pbip_project(
            FIXTURE_ROOT,
            dest,
            {"Sales": "fact_sales_gold", "NoSuchTable": "whatever"},
            mode="directQuery",
            account="acme-xy12345",
            warehouse="WH",
            database="mydb",
            schema="tgt__gold",
        )
        assert repointed == ["Sales"]

        rewritten_sales = (
            dest / "Contoso Sales.SemanticModel" / "definition" / "tables" / "Sales.tmdl"
        ).read_text(encoding="utf-8")
        assert "FACT_SALES_GOLD" in rewritten_sales
        assert "mode: directQuery" in rewritten_sales

        untouched_customer_original = (
            FIXTURE_ROOT
            / "Contoso Sales.SemanticModel"
            / "definition"
            / "tables"
            / "Customer.tmdl"
        ).read_text(encoding="utf-8")
        untouched_customer_copy = (
            dest / "Contoso Sales.SemanticModel" / "definition" / "tables" / "Customer.tmdl"
        ).read_text(encoding="utf-8")
        assert untouched_customer_original == untouched_customer_copy

    def test_original_project_never_mutated(self, tmp_path):
        original_before = SALES_TMDL_PATH.read_text(encoding="utf-8")
        repoint_pbip_project(
            FIXTURE_ROOT,
            tmp_path / "repointed",
            {"Sales": "fact_sales_gold"},
            mode="import",
            account="acme-xy12345",
            warehouse="WH",
            database="mydb",
            schema="tgt__gold",
        )
        assert SALES_TMDL_PATH.read_text(encoding="utf-8") == original_before

    def test_bim_project_repointed(self, tmp_path):
        source = tmp_path / "src"
        report_dir = source / "Contoso.Report"
        model_dir = source / "Contoso.SemanticModel"
        (report_dir / "definition").mkdir(parents=True)
        (report_dir / "definition.pbir").write_text(
            json.dumps({"datasetReference": {"byPath": {"path": "../Contoso.SemanticModel"}}}),
            encoding="utf-8",
        )
        model_dir.mkdir(parents=True)
        (model_dir / "model.bim").write_text(
            json.dumps(
                {
                    "model": {
                        "tables": [
                            {
                                "name": "Sales",
                                "partitions": [
                                    {
                                        "name": "Sales",
                                        "mode": "directQuery",
                                        "source": {"type": "entityPartitionSource"},
                                    }
                                ],
                            }
                        ]
                    }
                }
            ),
            encoding="utf-8",
        )
        (source / "Contoso.pbip").write_text(
            json.dumps({"version": "1.0", "artifacts": [{"report": {"path": "Contoso.Report"}}]}),
            encoding="utf-8",
        )

        dest = tmp_path / "repointed"
        repointed = repoint_pbip_project(
            source,
            dest,
            {"Sales": "fact_sales_gold"},
            mode="import",
            account="acme-xy12345",
            warehouse="WH",
            database="mydb",
            schema="tgt__gold",
        )
        assert repointed == ["Sales"]
        doc = json.loads((dest / "Contoso.SemanticModel" / "model.bim").read_text(encoding="utf-8"))
        part = doc["model"]["tables"][0]["partitions"][0]
        assert part["mode"] == "import"
        assert "FACT_SALES_GOLD" in "\n".join(part["source"]["expression"])
