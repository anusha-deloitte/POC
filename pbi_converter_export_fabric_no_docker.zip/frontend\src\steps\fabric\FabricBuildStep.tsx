import { useMutation } from '@tanstack/react-query'
import { AlertTriangle, CheckCircle2, Trash2, XCircle } from 'lucide-react'
import { useState } from 'react'
import { fabricPipelinesApi, type BuildPlan, type ExecuteBuildResult } from '../../api/fabricPipelines'
import { SnowflakeConnectionPicker } from '../../components/SnowflakeConnectionPicker'
import { useFabricWizard } from '../../store/fabricWizard'

interface BindingRow {
  path: string
  table: string
}

const UNRESOLVED_SOURCE_RE = /unresolved source '([^']*)'/

function unresolvedSourcePaths(plan: BuildPlan): string[] {
  const found = new Set<string>()
  for (const item of plan.items) {
    for (const note of item.notes) {
      const m = UNRESOLVED_SOURCE_RE.exec(note)
      if (m) found.add(m[1])
    }
  }
  return [...found]
}

function bindingRowsToRecord(rows: BindingRow[]): Record<string, string> {
  return Object.fromEntries(
    rows
      .filter((r) => r.path.trim() && r.table.trim())
      .map((r) => [r.path.trim(), r.table.trim()]),
  )
}

function SourceBindingsPanel({
  rows,
  onUpdate,
  onRemove,
  onAdd,
}: {
  rows: BindingRow[]
  onUpdate: (i: number, patch: Partial<BindingRow>) => void
  onRemove: (i: number) => void
  onAdd: () => void
}) {
  return (
    <div className="card mt-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-sm font-bold">Source bindings</div>
        <button type="button" className="btn-secondary text-xs" onClick={onAdd}>
          + Add mapping
        </button>
      </div>
      <p className="text-xs text-surface-600">
        Map each raw Fabric file path to the real Snowflake table you've already loaded it into.
        Re-run "Preview build plan" after filling these in to confirm they resolve.
      </p>
      {rows.length === 0 ? (
        <p className="text-xs text-surface-500">No unresolved sources detected yet.</p>
      ) : (
        <div className="space-y-2">
          {rows.map((row, i) => (
            <div key={i} className="flex items-center gap-2">
              <input
                aria-label={`Source path ${i + 1}`}
                className="input flex-1 font-mono text-xs"
                placeholder="Files/cms_raw/*.csv"
                value={row.path}
                onChange={(e) => onUpdate(i, { path: e.target.value })}
              />
              <span className="text-surface-400">&rarr;</span>
              <input
                aria-label={`Snowflake table for ${row.path || `mapping ${i + 1}`}`}
                className="input flex-1 font-mono text-xs"
                placeholder='"DB"."SCHEMA"."TABLE"'
                value={row.table}
                onChange={(e) => onUpdate(i, { table: e.target.value })}
              />
              <button
                type="button"
                aria-label={`Remove mapping ${i + 1}`}
                className="text-surface-400 hover:text-brand-red"
                onClick={() => onRemove(i)}
              >
                <Trash2 className="h-4 w-4" strokeWidth={1.8} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function BuildPlanView({ plan }: { plan: BuildPlan }) {
  return (
    <div className="card mt-4 space-y-3">
      <div className="text-sm font-bold">
        Build plan · {plan.items.length} object{plan.items.length === 1 ? '' : 's'} across{' '}
        {plan.schemas.length} schema{plan.schemas.length === 1 ? '' : 's'}
      </div>
      {plan.warnings.length > 0 && (
        <div role="status" className="rounded-lg border border-brand-amber/25 bg-brand-amber/10 p-2 text-xs text-brand-amber">
          <ul className="list-inside list-disc space-y-0.5">
            {plan.warnings.map((w, i) => (
              <li key={i}>{w}</li>
            ))}
          </ul>
        </div>
      )}
      <div className="space-y-2">
        {plan.items.map((item) => (
          <details key={item.object_name} className="rounded-lg border border-surface-200">
            <summary className="flex cursor-pointer items-center gap-2 p-2 text-xs">
              <span className="badge-blue">{item.layer}</span>
              <span className="font-mono font-semibold">{item.object_name}</span>
              <span className="text-surface-500">
                {item.object_kind.replace('_', ' ')} · {item.schema_name}
              </span>
              {item.depends_on.length > 0 && (
                <span className="text-surface-400">← {item.depends_on.join(', ')}</span>
              )}
            </summary>
            <div className="space-y-2 border-t border-surface-200 bg-surface-50 p-2">
              {item.notes.map((n, i) => (
                <p key={i} className="text-[11px] text-brand-amber">
                  {n}
                </p>
              ))}
              {item.ddl.map((stmt, i) => (
                <pre key={i} className="overflow-x-auto rounded bg-surface-900 p-2 text-[11px] text-surface-100">
                  {stmt}
                </pre>
              ))}
            </div>
          </details>
        ))}
      </div>
    </div>
  )
}

function FidelityView({ result }: { result: ExecuteBuildResult }) {
  if (!result.fidelity)
    return (
      <p className="mt-4 text-xs text-surface-500">
        No .pbip project was uploaded with this pipeline, so there's nothing to gate against.
      </p>
    )
  const { results, skipped_tables } = result.fidelity
  return (
    <div className="card mt-4 space-y-2">
      <div className="text-sm font-bold">Schema/fidelity gate</div>
      {results.map((r) => (
        <div
          key={r.table}
          className={`flex items-start gap-2 rounded-lg border p-2 text-xs ${
            r.matched ? 'border-brand/20 bg-brand/5' : 'border-brand-red/20 bg-brand-red/5'
          }`}
        >
          {r.matched ? (
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-brand-dark" strokeWidth={1.8} />
          ) : (
            <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-brand-red" strokeWidth={1.8} />
          )}
          <div>
            <div className="font-semibold">{r.table}</div>
            {r.mismatches.map((m, i) => (
              <p key={i} className="text-surface-600">
                {m.column}:{' '}
                {m.kind === 'missing_in_snowflake'
                  ? 'column not found in the built table'
                  : `expected ${m.expected_type}, got ${m.actual_type}`}
              </p>
            ))}
          </div>
        </div>
      ))}
      {skipped_tables.length > 0 && (
        <p className="text-[11px] text-surface-500">
          Not checked (no matching built table): {skipped_tables.join(', ')}
        </p>
      )}
    </div>
  )
}

export function FabricBuildStep() {
  const pipelineId = useFabricWizard((s) => s.pipelineId)
  const connectionId = useFabricWizard((s) => s.connectionId)
  const setConnection = useFabricWizard((s) => s.setConnection)
  const setUnsavedChanges = useFabricWizard((s) => s.setUnsavedChanges)
  const setStep = useFabricWizard((s) => s.setStep)
  const [plan, setPlan] = useState<BuildPlan | null>(null)
  const [executeResult, setExecuteResult] = useState<ExecuteBuildResult | null>(null)
  const [bindingRows, setBindingRows] = useState<BindingRow[]>([])

  function mergeUnresolvedIntoBindings(p: BuildPlan) {
    setBindingRows((prev) => {
      const existingPaths = new Set(prev.map((r) => r.path))
      const additions = unresolvedSourcePaths(p)
        .filter((path) => !existingPaths.has(path))
        .map((path) => ({ path, table: '' }))
      return additions.length ? [...prev, ...additions] : prev
    })
  }

  const sourceBindings = bindingRowsToRecord(bindingRows)

  const previewPlan = useMutation({
    mutationFn: () => fabricPipelinesApi.previewBuildPlan(pipelineId!, connectionId!, sourceBindings),
    onSuccess: (p) => {
      setPlan(p)
      mergeUnresolvedIntoBindings(p)
    },
  })
  const executeBuild = useMutation({
    mutationFn: () => fabricPipelinesApi.executeBuild(pipelineId!, connectionId!, sourceBindings),
    onSuccess: (result) => {
      setPlan(result.plan)
      setExecuteResult(result)
      mergeUnresolvedIntoBindings(result.plan)
    },
  })

  if (!pipelineId) return null

  return (
    <section>
      <div className="mb-6 overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div className="kicker mb-1">Step 3 · Build</div>
        <h2 className="text-xl font-bold">Build the Snowflake objects</h2>
        <p className="mt-1 max-w-2xl text-sm text-surface-600">
          Preview the dependency-ordered DDL first, then execute it against your Snowflake
          connection. Everything created is TRANSIENT. Executing also runs the schema/fidelity
          gate if a semantic model was uploaded.
        </p>
      </div>

      <div className="mb-6 max-w-lg">
        <SnowflakeConnectionPicker
          selected={connectionId}
          onSelect={setConnection}
          setUnsavedChanges={setUnsavedChanges}
          readyMessage="Connection ready — this pipeline's Snowflake objects will be built here."
        />
      </div>

      <SourceBindingsPanel
        rows={bindingRows}
        onUpdate={(i, patch) =>
          setBindingRows((prev) => prev.map((r, idx) => (idx === i ? { ...r, ...patch } : r)))
        }
        onRemove={(i) => setBindingRows((prev) => prev.filter((_, idx) => idx !== i))}
        onAdd={() => setBindingRows((prev) => [...prev, { path: '', table: '' }])}
      />

      <div className="mt-4 flex gap-3">
        <button
          className="btn-secondary"
          disabled={!connectionId || previewPlan.isPending}
          onClick={() => previewPlan.mutate()}
        >
          {previewPlan.isPending ? 'Planning…' : 'Preview build plan'}
        </button>
        <button
          className="btn-primary"
          disabled={!connectionId || executeBuild.isPending}
          onClick={() => executeBuild.mutate()}
        >
          {executeBuild.isPending ? 'Building…' : 'Execute build'}
        </button>
      </div>

      {(previewPlan.isError || executeBuild.isError) && (
        <div role="alert" className="mt-4 rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
          <div className="flex items-start gap-2">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.8} />
            <p>{(previewPlan.error ?? executeBuild.error)?.message}</p>
          </div>
        </div>
      )}

      {plan && <BuildPlanView plan={plan} />}
      {executeResult && (
        <>
          <p className="mt-4 text-xs text-surface-600">
            Created: {executeResult.created.join(', ') || '(nothing)'}
          </p>
          {executeResult.skipped.length > 0 && (
            <div
              role="status"
              className="mt-3 rounded-xl border border-brand-amber/25 bg-brand-amber/10 p-3 text-xs text-brand-amber"
            >
              <div className="flex items-start gap-2">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.8} />
                <div>
                  <p className="font-semibold">
                    Skipped (not built): {executeResult.skipped.join(', ')}
                  </p>
                  <p className="mt-1 text-surface-600">
                    These reference a source that couldn't be resolved to a real Snowflake table
                    — fill in its Snowflake table name in "Source bindings" above and click
                    "Execute build" again.
                  </p>
                </div>
              </div>
            </div>
          )}
          <FidelityView result={executeResult} />
          <div className="mt-6 flex justify-end">
            <button className="btn-primary" onClick={() => setStep('export')}>
              Continue to export
            </button>
          </div>
        </>
      )}
    </section>
  )
}
