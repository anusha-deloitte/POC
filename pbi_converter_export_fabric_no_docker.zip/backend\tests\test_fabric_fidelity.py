"""WS4: schema/fidelity gate -- diff built Snowflake columns vs. the PBI model."""

from app.ir.model import Column, DataType, SemanticModel, Table
from app.services.fabric_build import BuildPlan, BuildPlanItem
from app.services.fabric_fidelity import compare_schema, describe_built_tables


def _model() -> SemanticModel:
    sales = Table(
        name="Sales",
        columns=[
            Column(name="OrderId", data_type=DataType.INT64, source_column="ORDER_ID"),
            Column(name="Amount", data_type=DataType.DECIMAL, source_column="AMOUNT"),
            Column(name="OrderDate", data_type=DataType.DATE, source_column="ORDER_DATE"),
            Column(name="Margin", data_type=DataType.DOUBLE, expression="[Amount] * 0.1"),
        ],
    )
    unbuilt = Table(name="Currency", columns=[Column(name="Code", data_type=DataType.STRING)])
    return SemanticModel(tables=[sales, unbuilt])


class TestCompareSchema:
    def test_fully_matching_table(self):
        model = _model()
        actual = {
            "Sales": [
                ("ORDER_ID", "NUMBER(38,0)"),
                ("AMOUNT", "NUMBER(10,2)"),
                ("ORDER_DATE", "DATE"),
            ]
        }
        report = compare_schema(model, actual)
        assert report.ok
        sales_result = next(r for r in report.results if r.table == "Sales")
        assert sales_result.matched
        assert sales_result.mismatches == []

    def test_calculated_column_not_checked_against_physical_source(self):
        model = _model()
        actual = {
            "Sales": [
                ("ORDER_ID", "NUMBER(38,0)"),
                ("AMOUNT", "NUMBER(10,2)"),
                ("ORDER_DATE", "DATE"),
                # note: no "MARGIN" column at all -- and that's fine, it's calculated
            ]
        }
        report = compare_schema(model, actual)
        assert report.ok

    def test_missing_column_blocks(self):
        model = _model()
        actual = {"Sales": [("ORDER_ID", "NUMBER(38,0)"), ("AMOUNT", "NUMBER(10,2)")]}
        report = compare_schema(model, actual)
        assert not report.ok
        sales_result = next(r for r in report.results if r.table == "Sales")
        assert not sales_result.matched
        assert sales_result.mismatches[0].kind == "missing_in_snowflake"
        assert sales_result.mismatches[0].column == "OrderDate"

    def test_type_mismatch_blocks(self):
        model = _model()
        actual = {
            "Sales": [
                ("ORDER_ID", "NUMBER(38,0)"),
                ("AMOUNT", "NUMBER(10,2)"),
                ("ORDER_DATE", "VARCHAR(16777216)"),  # wrong: model expects DATE
            ]
        }
        report = compare_schema(model, actual)
        assert not report.ok
        mismatch = next(
            m
            for r in report.results
            for m in r.mismatches
            if r.table == "Sales" and m.column == "OrderDate"
        )
        assert mismatch.kind == "type_mismatch"
        assert mismatch.expected_type == "date"
        assert mismatch.actual_type == "VARCHAR(16777216)"

    def test_model_table_with_no_snowflake_counterpart_is_skipped_not_blocking(self):
        model = _model()
        actual = {"Sales": [("ORDER_ID", "NUMBER(38,0)"), ("AMOUNT", "NUMBER(10,2)"), ("ORDER_DATE", "DATE")]}
        report = compare_schema(model, actual)
        assert report.ok
        assert "Currency" in report.skipped_tables

    def test_case_insensitive_table_and_column_matching(self):
        model = _model()
        actual = {"sales": [("order_id", "NUMBER"), ("amount", "NUMBER(10,2)"), ("order_date", "DATE")]}
        report = compare_schema(model, actual)
        assert report.ok


class _FakeCursor:
    def __init__(self, describe_rows):
        self.describe_rows = describe_rows
        self.executed: list[str] = []

    def execute(self, sql):
        self.executed.append(sql)

    def fetchall(self):
        for fq_fragment, rows in self.describe_rows.items():
            if fq_fragment in self.executed[-1]:
                return rows
        return []


class TestDescribeBuiltTables:
    def test_describes_declarative_tables_and_skips_task_proc(self):
        plan = BuildPlan(
            schemas=["TGT__GOLD"],
            items=[
                BuildPlanItem(
                    artifact_id="a",
                    artifact_path="a.ipynb",
                    layer="gold",
                    schema_name="TGT__GOLD",
                    object_kind="transient_table",
                    object_name="SALES",
                    ddl=["CREATE ..."],
                ),
                BuildPlanItem(
                    artifact_id="b",
                    artifact_path="b.sql",
                    layer="gold",
                    schema_name="TGT__GOLD",
                    object_kind="task_proc",
                    object_name="SOME_TASK",
                    ddl=["CREATE PROC ...", "CREATE TASK ..."],
                ),
            ],
        )
        cursor = _FakeCursor({'"SALES"': [("ORDER_ID", "NUMBER(38,0)"), ("AMOUNT", "NUMBER(10,2)")]})
        result = describe_built_tables(plan, cursor, target_database="MYDB")
        assert list(result.keys()) == ["SALES"]
        assert result["SALES"] == [("ORDER_ID", "NUMBER(38,0)"), ("AMOUNT", "NUMBER(10,2)")]
        assert cursor.executed == ['DESCRIBE TABLE "MYDB"."TGT__GOLD"."SALES"']
