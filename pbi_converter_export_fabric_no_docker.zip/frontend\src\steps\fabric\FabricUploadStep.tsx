import { useMutation } from '@tanstack/react-query'
import { AlertTriangle, FileArchive, ShieldCheck, Sparkles, UploadCloud } from 'lucide-react'
import { useCallback, useState } from 'react'
import { fabricPipelinesApi } from '../../api/fabricPipelines'
import { useFabricWizard } from '../../store/fabricWizard'

export function FabricUploadStep() {
  const setPipeline = useFabricWizard((s) => s.setPipeline)
  const [dragOver, setDragOver] = useState(false)

  const upload = useMutation({
    mutationFn: (file: File) => fabricPipelinesApi.upload(file),
    onSuccess: (pipeline) => setPipeline(pipeline.id),
  })

  const onFile = useCallback(
    (file: File | undefined) => {
      if (file) upload.mutate(file)
    },
    [upload],
  )

  return (
    <section>
      <div className="mb-6 overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div className="kicker mb-1">Step 1 · Ingest</div>
        <h2 className="text-xl font-bold">Upload your Fabric workspace export</h2>
        <p className="mt-1 max-w-2xl text-sm text-surface-600">
          Zip whatever your Fabric workspace export contains — notebooks (<code className="rounded bg-surface-100 px-1 font-mono text-[12px]">.ipynb</code>),
          Warehouse scripts (<code className="rounded bg-surface-100 px-1 font-mono text-[12px]">.sql</code>), and
          optionally the report's <code className="rounded bg-surface-100 px-1 font-mono text-[12px]">.pbip</code> project
          (TMDL or legacy <code className="rounded bg-surface-100 px-1 font-mono text-[12px]">model.bim</code> — both
          read). No fixed folder layout required; nothing in the archive is executed at upload time.
        </p>
        <p className="mt-2 max-w-2xl text-xs text-surface-500">
          If your model is Fabric/Direct-Lake-hosted and you haven't saved a local .pbip yet, use{' '}
          <code className="rounded bg-surface-100 px-1 font-mono text-[11px]">
            fabric_extraction_toolkit/extract_pbip_from_fabric.ipynb
          </code>{' '}
          from inside your Fabric workspace to pull one down first.
        </p>
      </div>

      <label
        data-drag={dragOver}
        onDragOver={(e) => {
          e.preventDefault()
          setDragOver(true)
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault()
          setDragOver(false)
          onFile(e.dataTransfer.files[0])
        }}
        className="flex h-56 cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-surface-400 bg-surface-50/80 transition-all data-[drag=true]:border-brand data-[drag=true]:bg-brand/5 data-[drag=true]:shadow-glow"
      >
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand/10">
          {upload.isPending ? (
            <Sparkles className="h-6 w-6 animate-pulse text-brand-dark" strokeWidth={1.8} />
          ) : (
            <UploadCloud className="h-6 w-6 text-brand-dark" strokeWidth={1.8} />
          )}
        </span>
        <span className="text-sm font-semibold text-surface-800">
          {upload.isPending ? 'Classifying your artifacts…' : 'Drop .zip here or click to browse'}
        </span>
        <span className="text-xs text-surface-500">zip-slip &amp; zip-bomb protected</span>
        <input
          type="file"
          accept=".zip"
          className="hidden"
          onChange={(e) => onFile(e.target.files?.[0])}
        />
      </label>

      {upload.isError && (
        <div role="alert" className="mt-4 rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
          <div className="flex items-start gap-2">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.8} />
            <div>
              <div className="font-semibold">Blocking error: upload failed.</div>
              <p className="mt-1">{upload.error.message}</p>
            </div>
          </div>
        </div>
      )}

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="card flex items-start gap-3">
          <FileArchive className="mt-0.5 h-5 w-5 text-brand-dark" strokeWidth={1.8} />
          <div>
            <div className="text-sm font-bold">What we classify</div>
            <p className="text-xs text-surface-600">
              Notebooks and scripts by file type; a .pbip's semantic model, if present, is parsed
              for the schema/fidelity gate later. Everything else is recorded as reference material,
              not parsed.
            </p>
          </div>
        </div>
        <div className="card flex items-start gap-3">
          <ShieldCheck className="mt-0.5 h-5 w-5 text-brand-dark" strokeWidth={1.8} />
          <div>
            <div className="text-sm font-bold">Human confirms, not the parser</div>
            <p className="text-xs text-surface-600">
              Bronze/silver/gold layer tagging is a best-effort pre-fill only — you'll confirm or
              correct it on the next step before anything gets built in Snowflake.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
