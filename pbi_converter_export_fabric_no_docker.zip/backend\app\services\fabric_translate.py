"""WS2: Fabric notebook/script -> Snowflake SQL translation.

Priority order (cheapest/lowest-risk first, per the migration spec):
  1. SQL-expressible cells (`spark.sql("...")` literals, whole `.sql` files)
     -> sqlglot, read=spark/tsql, dialect=snowflake.
  2. DataFrame-API cells that are expression-only (chains of `.withColumn()`/
     `.cast()`/`concat()`/dropped columns, no joins/aggregations/custom UDFs
     beyond the filename-derived-column idiom) -> a small rule-based rewriter
     that walks the cell's Python AST and emits a `SELECT * EXCLUDE (...)
     REPLACE (...), <new col> AS ...` against the resolved source.
  3. everything else -> not attempted here; surfaced as `unhandled` for the
     LLM-assisted, execution-validated tier (see agents/fabric_tier3.py),
     same shape as agents/tier2.py's DAX fallback.
  4. external-ingestion cells (downloading files into Files/) are not
     transforms at all -> classified and left untranslated, per spec.

This only produces SQL for human review — it does not execute or materialize
anything (that's WS3's job, and decision #8's TRANSIENT-object requirement
applies to what WS3 builds from this output, not to this module).

Grounded against the migration spec's own validated reference sample
(fabric-samples-healthcare/analytics-bi-directlake-starschema): tier 1 covers
its 03-CreateCMSStarSchemaTables.ipynb cleanly (5 spark.sql cells, including
window functions and multi-way joins); tier 2 covers its
02-CreateCMSDataTable.ipynb (casts, concat, a dropped column, and the
filename-derived-year custom UDF -> METADATA$FILENAME + REGEXP_SUBSTR).
"""

from __future__ import annotations

import ast
import re
from enum import StrEnum
from typing import Literal

import sqlglot
from pydantic import BaseModel, Field

from app.services.fabric_notebooks import FabricArtifact
from app.services.object_migration import extract_procedure_body

_SPARK_SQL_METHOD = "sql"
_WRITE_ROOT_METHODS = {"write", "writeTo"}
_SAVE_METHODS = {"saveAsTable", "save", "insertInto"}
_NOOP_CHAIN_METHODS = {"mode", "format", "option", "options", "partitionBy", "bucketBy"}

_READ_ROOT_METHODS = {"read", "readStream", "table"}
_READ_SOURCE_METHODS = {"load", "csv", "parquet", "json", "table"}  # bear the actual path/table arg
_READ_CONFIG_METHODS = {"format", "option", "options"}  # configure how, not where, from

_SPARK_TYPE_MAP = {
    "IntegerType": "INTEGER",
    "LongType": "BIGINT",
    "ShortType": "SMALLINT",
    "ByteType": "SMALLINT",
    "DoubleType": "DOUBLE",
    "FloatType": "FLOAT",
    "StringType": "VARCHAR",
    "BooleanType": "BOOLEAN",
    "DateType": "DATE",
    "TimestampType": "TIMESTAMP_NTZ",
    "BinaryType": "BINARY",
}

_COL_ACCESSOR_NAMES = {"col"}
_LIT_NAMES = {"lit"}
_CONCAT_NAMES = {"concat"}
_FILENAME_NAMES = {"input_file_name"}
_REGEXP_EXTRACT_NAMES = {"regexp_extract"}

_BIN_OP_SQL = {ast.Add: "+", ast.Sub: "-", ast.Mult: "*", ast.Div: "/"}

# heuristic signature for the "extract a numeric token from a file path" UDF
# idiom the reference sample uses (os.path.basename/splitext or urlparse over
# a path, cast to int) -> a native METADATA$FILENAME + REGEXP_SUBSTR
# equivalent (decision validated in the spec's own reference sample).
_FILENAME_UDF_HINTS = ("os.path", "basename", "splitext", "urlparse", "path.split")


class TranslationTier(StrEnum):
    SQL = "sql"
    DATAFRAME = "dataframe"
    EXTERNAL_INGESTION = "external_ingestion"
    UNHANDLED = "unhandled"
    NOOP = "noop"


class TranslatedStatement(BaseModel):
    target_table: str | None = None
    sql: str
    note: str = ""


class CellResult(BaseModel):
    cell_index: int
    tier: TranslationTier
    statements: list[TranslatedStatement] = Field(default_factory=list)
    reason: str = ""


class ArtifactTranslation(BaseModel):
    artifact_id: str
    cells: list[CellResult] = Field(default_factory=list)


def _qident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _sql_literal(value: object) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)):
        return str(value)
    return "'" + str(value).replace("'", "''") + "'"


def _string_const(node: ast.AST | None) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


class _Frame:
    def __init__(self, source: str):
        self.source = source
        self.new: dict[str, str] = {}
        self.replaced: dict[str, str] = {}
        self.dropped: set[str] = set()
        self.explicit: list[str] | None = None
        self.tainted = False
        self.taint_reason = ""

    def clone(self) -> _Frame:
        f = _Frame(self.source)
        f.new = dict(self.new)
        f.replaced = dict(self.replaced)
        f.dropped = set(self.dropped)
        f.explicit = list(self.explicit) if self.explicit is not None else None
        f.tainted = self.tainted
        f.taint_reason = self.taint_reason
        return f

    def taint(self, reason: str) -> None:
        if not self.tainted:
            self.tainted = True
            self.taint_reason = reason

    def emit_select(self) -> str:
        if self.explicit is not None:
            cols = ", ".join(_qident(c) for c in self.explicit)
            return f"SELECT {cols}\nFROM {self.source}"
        if not self.new and not self.replaced and not self.dropped:
            return f"SELECT *\nFROM {self.source}"
        parts = ["*"]
        if self.dropped:
            parts.append("EXCLUDE (" + ", ".join(_qident(c) for c in sorted(self.dropped)) + ")")
        if self.replaced:
            repl = ", ".join(f"{expr} AS {_qident(n)}" for n, expr in self.replaced.items())
            parts.append(f"REPLACE ({repl})")
        select_list = " ".join(parts)
        if self.new:
            new_cols = ", ".join(f"{expr} AS {_qident(n)}" for n, expr in self.new.items())
            select_list += ", " + new_cols
        return f"SELECT {select_list}\nFROM {self.source}"


class _NotebookAnalyzer:
    def __init__(self):
        self.string_vars: dict[str, str] = {}
        self.udf_vars: dict[str, str] = {}  # udf variable name -> underlying function name
        self.udf_bodies: dict[str, str] = {}  # function name -> source text (for the idiom check)
        self.frames: dict[str, _Frame] = {}

    # -- literal/path resolution (compile-time constant folding only) --

    def _resolve_literal(self, node: ast.AST) -> str | None:
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        if isinstance(node, ast.Name) and node.id in self.string_vars:
            return self.string_vars[node.id]
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            left = self._resolve_literal(node.left)
            right = self._resolve_literal(node.right)
            if left is not None and right is not None:
                return left + right
        return None

    # -- expression evaluation: python AST -> Snowflake SQL expression text --

    def _is_frame_ref(self, node: ast.AST, frame_var: str) -> bool:
        return isinstance(node, ast.Name) and node.id == frame_var

    def _eval_expr(self, node: ast.AST, frame_var: str, frame: _Frame) -> str | None:
        if isinstance(node, ast.Constant):
            return _sql_literal(node.value)

        if isinstance(node, ast.Attribute) and self._is_frame_ref(node.value, frame_var):
            return self._column_ref(node.attr, frame)

        if isinstance(node, ast.Subscript) and self._is_frame_ref(node.value, frame_var):
            key = _string_const(node.slice) or _string_const(getattr(node.slice, "value", None))
            if key is not None:
                return self._column_ref(key, frame)
            return None

        if isinstance(node, ast.BinOp) and type(node.op) in _BIN_OP_SQL:
            left = self._eval_expr(node.left, frame_var, frame)
            right = self._eval_expr(node.right, frame_var, frame)
            if left is not None and right is not None:
                return f"({left} {_BIN_OP_SQL[type(node.op)]} {right})"
            return None

        if isinstance(node, ast.Call):
            return self._eval_call(node, frame_var, frame)

        return None

    def _column_ref(self, name: str, frame: _Frame) -> str:
        if name in frame.new:
            return frame.new[name]
        if name in frame.replaced:
            return frame.replaced[name]
        return _qident(name)

    def _call_name(self, call: ast.Call) -> str | None:
        func = call.func
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            return func.attr
        return None

    def _eval_call(self, call: ast.Call, frame_var: str, frame: _Frame) -> str | None:
        name = self._call_name(call)
        if name is None:
            return None

        # <expr>.cast(<SparkType>(...))
        if name == "cast" and isinstance(call.func, ast.Attribute):
            inner = self._eval_expr(call.func.value, frame_var, frame)
            sf_type = self._eval_spark_type(call.args[0]) if call.args else None
            if inner is not None and sf_type is not None:
                return f"CAST({inner} AS {sf_type})"
            return None

        if name in _COL_ACCESSOR_NAMES and call.args:
            key = _string_const(call.args[0])
            if key is not None:
                return self._column_ref(key, frame)
            return None

        if name in _LIT_NAMES and call.args:
            arg = call.args[0]
            if isinstance(arg, ast.Constant):
                return _sql_literal(arg.value)
            return None

        if name in _CONCAT_NAMES:
            parts = [self._eval_expr(a, frame_var, frame) for a in call.args]
            if all(p is not None for p in parts):
                return "CONCAT(" + ", ".join(parts) + ")"
            return None

        if name in _FILENAME_NAMES:
            return "METADATA$FILENAME"

        if name in _REGEXP_EXTRACT_NAMES and len(call.args) >= 2:
            subject = self._eval_expr(call.args[0], frame_var, frame)
            pattern = _string_const(call.args[1])
            group_arg = call.args[2] if len(call.args) > 2 else None
            group = group_arg.value if isinstance(group_arg, ast.Constant) else 0
            if subject is not None and pattern is not None:
                pat_literal = _sql_literal(pattern)
                if int(group) <= 0:
                    return f"REGEXP_SUBSTR({subject}, {pat_literal})"
                return f"REGEXP_SUBSTR({subject}, {pat_literal}, 1, 1, 'e', {int(group)})"
            return None

        if isinstance(call.func, ast.Name) and call.func.id in self.udf_vars:
            return self._eval_udf_call(call, frame_var, frame)

        return None

    def _eval_spark_type(self, node: ast.AST) -> str | None:
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            type_name = node.func.id
            if type_name == "DecimalType":
                if len(node.args) >= 2:
                    p = node.args[0].value if isinstance(node.args[0], ast.Constant) else 38
                    s = node.args[1].value if isinstance(node.args[1], ast.Constant) else 10
                    return f"NUMBER({p},{s})"
                return "NUMBER(38,10)"
            return _SPARK_TYPE_MAP.get(type_name)
        return None

    def _eval_udf_call(self, call: ast.Call, frame_var: str, frame: _Frame) -> str | None:
        assert isinstance(call.func, ast.Name)
        func_name = self.udf_vars[call.func.id]
        body = self.udf_bodies.get(func_name, "")
        if not any(hint in body for hint in _FILENAME_UDF_HINTS):
            return None  # not the recognized idiom -> unsupported, falls to tier 3
        if not call.args:
            return None
        # translate whatever expression was passed in, then apply the
        # filename-token extraction over it (usually METADATA$FILENAME, but
        # kept general in case it's applied to an already-derived column).
        inner = self._eval_expr(call.args[0], frame_var, frame)
        if inner is None:
            return None
        return f"CAST(REGEXP_SUBSTR({inner}, '[0-9]{{4}}') AS INTEGER)"

    # -- statement-level chain walking --

    def _base_and_chain(self, node: ast.AST) -> tuple[ast.AST, list[ast.Call]]:
        """Unwind a fluent call chain into (base expr, [calls in left-to-right
        invocation order]). Walks through bare attribute hops too (e.g.
        `df.write.mode(...).saveAsTable(...)`'s `.write` has no call of its
        own), collecting only the actual Call nodes into `chain`."""
        chain: list[ast.Call] = []
        cur = node
        while True:
            if isinstance(cur, ast.Call) and isinstance(cur.func, ast.Attribute):
                chain.append(cur)
                cur = cur.func.value
            elif isinstance(cur, ast.Attribute):
                cur = cur.value
            else:
                break
        chain.reverse()
        return cur, chain

    def _process_read_chain(self, chain: list[ast.Call]) -> str | None:
        """spark.read.format(...).option(...).load(<path>) / spark.table(<name>)
        -> resolved source literal."""
        for call in chain:
            assert isinstance(call.func, ast.Attribute)
            method = call.func.attr
            if method in _READ_SOURCE_METHODS and call.args:
                lit = self._resolve_literal(call.args[0])
                if lit is not None:
                    return lit
        return None

    def _apply_with_column(self, frame: _Frame, frame_var: str, call: ast.Call) -> None:
        if len(call.args) < 2:
            frame.taint("withColumn without a literal name + expression")
            return
        name = _string_const(call.args[0])
        if name is None:
            frame.taint("withColumn name is not a literal")
            return
        expr = self._eval_expr(call.args[1], frame_var, frame)
        if expr is None:
            frame.taint(f"unsupported expression for column {name!r}")
            return
        self_ref = self._references_own_name(call.args[1], frame_var, name)
        if name in frame.dropped:
            frame.dropped.discard(name)
        if name in frame.new:
            frame.new[name] = expr
        elif name in frame.replaced or self_ref:
            frame.replaced[name] = expr
        else:
            frame.new[name] = expr

    def _references_own_name(self, node: ast.AST, frame_var: str, name: str) -> bool:
        for sub in ast.walk(node):
            if isinstance(sub, ast.Attribute) and sub.attr == name and self._is_frame_ref(
                sub.value, frame_var
            ):
                return True
            if isinstance(sub, ast.Subscript) and self._is_frame_ref(sub.value, frame_var):
                key = _string_const(sub.slice) or _string_const(getattr(sub.slice, "value", None))
                if key == name:
                    return True
            is_col_call = isinstance(sub, ast.Call) and sub.args
            if is_col_call and self._call_name(sub) in _COL_ACCESSOR_NAMES:
                if _string_const(sub.args[0]) == name:
                    return True
        return False

    def _apply_with_column_renamed(self, frame: _Frame, call: ast.Call) -> None:
        if len(call.args) < 2:
            frame.taint("withColumnRenamed without 2 literal args")
            return
        old, new = _string_const(call.args[0]), _string_const(call.args[1])
        if old is None or new is None:
            frame.taint("withColumnRenamed args not literals")
            return
        if old in frame.new:
            frame.new[new] = frame.new.pop(old)
        elif old in frame.replaced:
            frame.new[new] = frame.replaced.pop(old)
            frame.dropped.add(old)
        else:
            frame.new[new] = _qident(old)
            frame.dropped.add(old)

    def _apply_drop(self, frame: _Frame, call: ast.Call) -> None:
        for arg in call.args:
            col = _string_const(arg)
            if col is None:
                frame.taint("drop() with a non-literal argument")
                return
            # a column this same chain added via withColumn (frame.new) was
            # never part of the source's `*` in the first place -- dropping
            # it just means "don't add it", not "EXCLUDE it from `*`". Check
            # membership BEFORE popping: the old code popped unconditionally
            # first, which made the "still in frame.new" check below always
            # false and wrongly EXCLUDEd every purely-virtual dropped column
            # too (e.g. a `withColumn("file_path", input_file_name())` added
            # then `.drop("file_path")`-ed later in the same chain).
            if col in frame.new:
                del frame.new[col]
            elif col in frame.replaced:
                del frame.replaced[col]
                frame.dropped.add(col)
            else:
                frame.dropped.add(col)

    def _apply_select(self, frame: _Frame, call: ast.Call) -> None:
        cols = [_string_const(a) for a in call.args]
        if any(c is None for c in cols):
            frame.taint("select() with a non-literal column expression")
            return
        frame.explicit = cols  # type: ignore[assignment]
        frame.new.clear()
        frame.replaced.clear()
        frame.dropped.clear()

    def _apply_chain_ops(self, frame: _Frame, frame_var: str, chain: list[ast.Call]) -> None:
        for call in chain:
            assert isinstance(call.func, ast.Attribute)
            method = call.func.attr
            if (
                method in _NOOP_CHAIN_METHODS
                or method in _READ_SOURCE_METHODS
                or method in _READ_CONFIG_METHODS
                or method in _READ_ROOT_METHODS
            ):
                continue
            if method == "withColumn":
                self._apply_with_column(frame, frame_var, call)
            elif method == "withColumnRenamed":
                self._apply_with_column_renamed(frame, call)
            elif method == "drop":
                self._apply_drop(frame, call)
            elif method == "select":
                self._apply_select(frame, call)
            elif method in ("display",):
                continue
            else:
                frame.taint(f"unsupported DataFrame method .{method}()")
            if frame.tainted:
                return

    def visit_assign(self, stmt: ast.Assign) -> tuple[str, str | None]:
        """Returns (kind, save_table_name_if_any) for a top-level assignment."""
        if len(stmt.targets) != 1 or not isinstance(stmt.targets[0], ast.Name):
            return "skip", None
        target = stmt.targets[0].id
        value = stmt.value

        # simple string variable, e.g. source_dir = "Files/cms_raw"
        lit = self._resolve_literal(value) if isinstance(value, (ast.Constant, ast.BinOp)) else None
        if lit is not None and isinstance(value, ast.Constant):
            self.string_vars[target] = lit
            return "skip", None

        # udf_var = udf(some_function, IntegerType())
        if (
            isinstance(value, ast.Call)
            and isinstance(value.func, ast.Name)
            and value.func.id == "udf"
            and value.args
            and isinstance(value.args[0], ast.Name)
        ):
            self.udf_vars[target] = value.args[0].id
            return "skip", None

        base, chain = self._base_and_chain(value)

        # <var> = spark.sql(<literal>)[.<further chain>]
        is_spark_sql = isinstance(base, ast.Name) and base.id == "spark" and chain
        if is_spark_sql and chain[0].func.attr == "sql":
            sql_call = chain[0]
            sql_text = _string_const(sql_call.args[0]) if sql_call.args else None
            if sql_text is not None:
                frame = _Frame(source="(" + sql_text.strip().rstrip(";") + ")")
                self._apply_chain_ops(frame, target, chain[1:])
                self.frames[target] = frame
                return "sql_frame", None
            return "skip", None

        if isinstance(base, ast.Name) and base.id in self.frames:
            frame = self.frames[base.id].clone()
            self._apply_chain_ops(frame, base.id, chain)
            self.frames[target] = frame
            return "frame", None

        if isinstance(base, ast.Name) and base.id in ("spark",):
            source = self._process_read_chain(chain)
            if source is not None:
                frame = _Frame(source=f"{{{{source: {source}}}}}")
                self._apply_chain_ops(frame, target, chain)
                self.frames[target] = frame
                return "frame", None

        return "skip", None

    def visit_expr_statement(self, stmt: ast.Expr) -> tuple[str, str] | None:
        """`<frame>.write...saveAsTable(<literal>)` as a bare expression statement."""
        base, chain = self._base_and_chain(stmt.value)
        if not (isinstance(base, ast.Name) and base.id in self.frames):
            return None
        save_name = None
        for call in chain:
            assert isinstance(call.func, ast.Attribute)
            if call.func.attr in _SAVE_METHODS and call.args:
                save_name = _string_const(call.args[0])
        if save_name is not None:
            return base.id, save_name
        return None


def _translate_sql_text_cell(
    cell_index: int, body: str, source_kind: Literal["spark", "tsql"]
) -> CellResult:
    stmt = _transpile_sql(body, source_kind)
    tier = TranslationTier.SQL if not stmt.note else TranslationTier.UNHANDLED
    return CellResult(cell_index=cell_index, tier=tier, statements=[stmt], reason=stmt.note)


def translate_notebook(artifact: FabricArtifact) -> ArtifactTranslation:
    analyzer = _NotebookAnalyzer()
    results: list[CellResult] = []

    for cell in artifact.cells:
        if cell.cell_type != "code":
            continue
        stripped = cell.source.strip()
        if not stripped:
            continue

        try:
            tree = ast.parse(cell.source)
        except SyntaxError:
            # e.g. a %%sql / %%pyspark cell-magic header line
            first_line = stripped.splitlines()[0].strip().lower()
            if first_line in ("%%sql", "%sql"):
                body = stripped.split("\n", 1)[1] if "\n" in stripped else ""
                results.append(_translate_sql_text_cell(cell.index, body, "spark"))
            elif first_line.startswith(("%", "!")):
                # IPython line/cell magics (%pip install, %load_ext, %%capture,
                # %%time, %config, ...) and shell escapes (!pip install ...)
                # aren't transforms at all -- nothing to translate, and
                # nothing for tier 3 to help with either.
                results.append(CellResult(cell_index=cell.index, tier=TranslationTier.NOOP))
            else:
                results.append(
                    CellResult(
                        cell_index=cell.index,
                        tier=TranslationTier.UNHANDLED,
                        reason="not parseable as Python",
                    )
                )
            continue

        if _looks_external_ingestion(cell.source):
            results.append(
                CellResult(
                    cell_index=cell.index,
                    tier=TranslationTier.EXTERNAL_INGESTION,
                    reason="external HTTP/file download, not a transform",
                )
            )
            continue

        cell_statements: list[TranslatedStatement] = []
        cell_tainted_reason: str | None = None
        saw_anything = False

        for node in tree.body:
            if isinstance(node, ast.FunctionDef):
                analyzer.udf_bodies[node.name] = ast.unparse(node)
                continue
            if isinstance(node, ast.ImportFrom | ast.Import):
                continue
            if isinstance(node, ast.Assign):
                kind, _ = analyzer.visit_assign(node)
                if kind in ("frame", "sql_frame"):
                    saw_anything = True
                    target = node.targets[0].id  # type: ignore[union-attr]
                    frame = analyzer.frames[target]
                    if frame.tainted and cell_tainted_reason is None:
                        cell_tainted_reason = frame.taint_reason
            elif isinstance(node, ast.Expr):
                save = analyzer.visit_expr_statement(node)
                if save is not None:
                    saw_anything = True
                    frame_var, table_name = save
                    frame = analyzer.frames[frame_var]
                    if frame.tainted:
                        cell_tainted_reason = frame.taint_reason
                    else:
                        cell_statements.append(
                            TranslatedStatement(target_table=table_name, sql=frame.emit_select())
                        )

        if cell_statements:
            results.append(
                CellResult(
                    cell_index=cell.index,
                    tier=TranslationTier.DATAFRAME,
                    statements=cell_statements,
                )
            )
        elif cell_tainted_reason:
            results.append(
                CellResult(
                    cell_index=cell.index,
                    tier=TranslationTier.UNHANDLED,
                    reason=cell_tainted_reason,
                )
            )
        elif not saw_anything:
            sql_statements = _extract_spark_sql_literals(tree)
            if sql_statements:
                results.append(
                    CellResult(
                        cell_index=cell.index,
                        tier=TranslationTier.SQL,
                        statements=[_transpile_sql(s, "spark") for s in sql_statements],
                    )
                )
            else:
                results.append(CellResult(cell_index=cell.index, tier=TranslationTier.NOOP))

    return ArtifactTranslation(artifact_id=artifact.id, cells=results)


def _extract_spark_sql_literals(tree: ast.Module) -> list[str]:
    found: list[str] = []
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == _SPARK_SQL_METHOD
            and node.args
        ):
            lit = _string_const(node.args[0])
            if lit is not None:
                found.append(lit)
    return found


_EXTERNAL_INGESTION_HINTS = (
    "requests.get(",
    "requests.post(",
    "urllib.request",
    "urlretrieve",
    "wget.download",
)


def _looks_external_ingestion(source: str) -> bool:
    return any(hint in source for hint in _EXTERNAL_INGESTION_HINTS)


# ---------------------------------------------------------------------------
# tier 1: standalone SQL (spark.sql literals and whole .sql script files)
# ---------------------------------------------------------------------------

_TSQL_IF_NOT_EXISTS_CREATE_RE = re.compile(
    r"IF\s+NOT\s+EXISTS\s*\(\s*SELECT\s+.*?\bFROM\s+sysobjects\b.*?\)\s*"
    r"BEGIN\s*(CREATE\s+TABLE\b.*?)\s*END",
    re.IGNORECASE | re.DOTALL,
)


def _normalize_tsql_control_flow(sql: str) -> str:
    """`IF NOT EXISTS (SELECT * FROM sysobjects WHERE ...) BEGIN CREATE TABLE
    ... END` -> a plain `CREATE TABLE IF NOT EXISTS ...` (Snowflake supports
    that directly; no need to make sqlglot parse the T-SQL control flow)."""

    def _replace(m: re.Match) -> str:
        create_stmt = m.group(1)
        return re.sub(
            r"^CREATE\s+TABLE\b",
            "CREATE TABLE IF NOT EXISTS",
            create_stmt,
            count=1,
            flags=re.IGNORECASE,
        )

    return _TSQL_IF_NOT_EXISTS_CREATE_RE.sub(_replace, sql)


def _transpile_sql(sql: str, source_kind: Literal["spark", "tsql"]) -> TranslatedStatement:
    body = sql
    if source_kind == "tsql":
        # a whole-.sql-file artifact wrapped in CREATE PROC(EDURE) ... AS
        # [BEGIN] ... [END] can't be parsed by sqlglot as one statement (it
        # falls back to a Command node rather than raising -- see below) --
        # extract the inner statements the same way object_migration.py's
        # transpile_procedure() already does for live-introspected procs.
        extracted = extract_procedure_body(sql)
        body = extracted[1] if extracted is not None else sql
        body = _normalize_tsql_control_flow(body)
    try:
        statements = sqlglot.parse(body, read=source_kind)
        real_statements = [s for s in statements if s is not None]
        if not real_statements:
            raise ValueError("no statements parsed")
        # sqlglot doesn't always raise when it can't fully parse a statement --
        # unsupported syntax (BULK INSERT, OPENROWSET, ...) falls back to a
        # generic Command node whose .sql() re-emits something close to the
        # original (untranspiled) text. Executing that against Snowflake
        # verbatim is exactly the "silently accept a guess" WS2 is designed
        # to avoid, so a Command fallback is treated as a failed transpile,
        # not a successful one.
        if any(isinstance(s, sqlglot.exp.Command) for s in real_statements):
            raise ValueError(
                "sqlglot could not fully parse this statement (fell back to a "
                "raw passthrough) -- likely unsupported T-SQL syntax such as "
                "BULK INSERT/OPENROWSET"
            )
        out = ";\n".join(s.sql(dialect="snowflake") for s in real_statements)
        if not out.strip():
            raise ValueError("no statements parsed")
        return TranslatedStatement(sql=out)
    except Exception as e:  # noqa: BLE001 - any sqlglot parse/transpile failure
        note = f"transpile failed ({e}); original text kept for review"
        return TranslatedStatement(sql=sql, note=note)


def translate_sql_artifact(
    artifact: FabricArtifact, source_kind: Literal["spark", "tsql"] = "tsql"
) -> ArtifactTranslation:
    """For kind == "sql" whole-file artifacts (Fabric Warehouse .sql scripts)."""
    text = artifact.sql_text or ""
    if not text.strip():
        return ArtifactTranslation(artifact_id=artifact.id, cells=[])
    result = _transpile_sql(text, source_kind)
    tier = TranslationTier.SQL if not result.note else TranslationTier.UNHANDLED
    return ArtifactTranslation(
        artifact_id=artifact.id,
        cells=[CellResult(cell_index=0, tier=tier, statements=[result], reason=result.note)],
    )
