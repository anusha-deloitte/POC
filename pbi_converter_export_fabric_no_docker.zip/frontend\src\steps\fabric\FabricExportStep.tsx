import { useMutation } from '@tanstack/react-query'
import { AlertTriangle, CheckCircle2, Download } from 'lucide-react'
import { useState } from 'react'
import { fabricPipelinesApi, type ConnectivityMode } from '../../api/fabricPipelines'
import { useFabricWizard } from '../../store/fabricWizard'

export function FabricExportStep() {
  const pipelineId = useFabricWizard((s) => s.pipelineId)
  const connectionId = useFabricWizard((s) => s.connectionId)
  // decision #11: DirectQuery is the closest behavioral match to how Direct
  // Lake worked against Fabric (live, no staleness) -- default, user-overridable.
  const [mode, setMode] = useState<ConnectivityMode>('directQuery')

  const exportPbip = useMutation({
    mutationFn: () => fabricPipelinesApi.exportPbip(pipelineId!, connectionId!, mode),
    onSuccess: ({ blob }) => {
      const href = URL.createObjectURL(blob)
      const anchor = document.createElement('a')
      anchor.href = href
      anchor.download = 'repointed_pbip.zip'
      anchor.click()
      URL.revokeObjectURL(href)
    },
  })

  if (!pipelineId) return null

  return (
    <section>
      <div className="mb-6 overflow-hidden rounded-2xl border border-black/[0.08] bg-gradient-to-br from-white via-[#F5F7FA] to-[#EEF1F5] p-6">
        <div className="kicker mb-1">Step 4 · Export</div>
        <h2 className="text-xl font-bold">Repoint the report &amp; download</h2>
        <p className="mt-1 max-w-2xl text-sm text-surface-600">
          Only gold-layer tables that both match a model table by name and pass the schema/fidelity
          gate get repointed — a mismatched table is left pointing at its original Fabric source
          rather than silently bound to something wrong. Execute build must have already run.
        </p>
      </div>

      <fieldset className="mb-4 max-w-md">
        <legend className="text-sm font-semibold text-surface-700">Connectivity mode</legend>
        <div className="mt-1.5 flex gap-1 rounded-lg border border-surface-300 bg-white p-0.5 text-xs">
          <button
            data-active={mode === 'directQuery'}
            onClick={() => setMode('directQuery')}
            className="flex-1 rounded-md px-3 py-1.5 font-medium text-surface-600 data-[active=true]:bg-brand data-[active=true]:text-white"
          >
            DirectQuery
          </button>
          <button
            data-active={mode === 'import'}
            onClick={() => setMode('import')}
            className="flex-1 rounded-md px-3 py-1.5 font-medium text-surface-600 data-[active=true]:bg-brand data-[active=true]:text-white"
          >
            Import
          </button>
        </div>
        <p className="mt-1.5 text-xs text-surface-500">
          {mode === 'directQuery'
            ? 'Live query against Snowflake on every interaction — no staleness, closest match to Direct Lake.'
            : 'Data is loaded into the model at refresh time — faster interactions, at the cost of freshness.'}
        </p>
      </fieldset>

      <button
        className="btn-primary flex items-center gap-2"
        disabled={!connectionId || exportPbip.isPending}
        onClick={() => exportPbip.mutate()}
      >
        <Download className="h-4 w-4" strokeWidth={1.8} />
        {exportPbip.isPending ? 'Repointing…' : 'Export .pbip'}
      </button>

      {exportPbip.isError && (
        <div role="alert" className="mt-4 rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
          <div className="flex items-start gap-2">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.8} />
            <p>{exportPbip.error.message}</p>
          </div>
        </div>
      )}

      {exportPbip.isSuccess && (
        <div role="status" className="mt-4 rounded-xl border border-brand/20 bg-brand/5 p-3 text-sm text-brand-dark">
          <div className="flex items-start gap-2">
            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" strokeWidth={1.8} />
            <div>
              <div className="font-semibold">Downloaded.</div>
              <p className="mt-1 text-xs text-surface-600">
                Repointed: {exportPbip.data.repointedTables.join(', ') || '(none)'}. Open the .pbip
                in Power BI Desktop to check the repointed visuals and connection settings.
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
