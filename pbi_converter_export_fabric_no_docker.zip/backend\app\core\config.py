from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

_DEFAULT_STORAGE = Path.home() / ".pbic" / "storage"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="PBIC_", env_file=".env", extra="ignore")

    storage_dir: Path = _DEFAULT_STORAGE
    max_upload_bytes: int = 1024 * 1024 * 1024  # raw .zip upload cap (1 GB)
    # PBIP/PBIR content (JSON/TMDL text) compresses well, so the unpacked
    # archive can be considerably larger than the raw upload; zip-bomb guards.
    max_uncompressed_bytes: int = 4 * 1024 * 1024 * 1024  # 4 GB
    max_zip_members: int = 20_000
    # Fernet key for connection-secret encryption; generated on first run in dev
    secrets_key_file: Path = _DEFAULT_STORAGE / ".secrets.key"
    api_token: str = ""  # empty = auth disabled (local dev only)
    dashboard_token_ttl_seconds: int = 30 * 24 * 3600
    # Elevance Health "Horizon" LLM gateway (OAuth2 client-credentials).
    # Empty client id/secret = LLM features disabled, same as the old openai_api_key gate.
    horizon_base_url: str = "https://api.horizon.elevancehealth.com"
    horizon_client_id: str = ""
    horizon_client_secret: str = ""
    horizon_qos: str = "accurate"  # accurate | cheap
    horizon_governance_qos: str = "cheap"  # governance calls are low-stakes text Q&A
    horizon_max_requests_per_minute: int = 15
    # SECURITY: false disables TLS certificate AND hostname verification for
    # every Horizon request (including the ones carrying client_secret/bearer
    # tokens). Only for environments with a corporate TLS-inspecting proxy
    # that a proper CA bundle isn't available for. Logged loudly when active.
    horizon_verify_ssl: bool = True
    database_url: str = "postgresql://pbic:pbic@localhost:5432/pbic"
    log_level: str = "INFO"
    # SQL text is useful for troubleshooting but may embed literal filter
    # values a user picked (business data, not credentials); off switch here.
    log_sql_text: bool = True

    @property
    def log_dir(self) -> Path:
        return self.storage_dir / "logs"


@lru_cache
def get_settings() -> Settings:
    return Settings()
