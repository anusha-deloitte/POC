import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter, Route, Routes } from 'react-router-dom'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { FabricJobs } from '../pages/FabricJobs'
import { useFabricWizard } from '../store/fabricWizard'

function renderPage() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <MemoryRouter initialEntries={['/app/fabric-jobs']}>
        <Routes>
          <Route path="/app/fabric-jobs" element={<FabricJobs />} />
          <Route path="/app/fabric" element={<div>Fabric wizard</div>} />
        </Routes>
      </MemoryRouter>
    </QueryClientProvider>,
  )
}

const jobs = [
  {
    id: 'aaaaaaaa-1111-2222-3333-444444444444',
    name: 'fabric-samples-healthcare',
    artifact_count: 10,
    buildable_count: 4,
    reviewed_count: 4,
    has_semantic_model: true,
    warning_count: 0,
    uploaded_at: 1_700_000_000,
  },
  {
    id: 'bbbbbbbb-1111-2222-3333-444444444444',
    name: null,
    artifact_count: 3,
    buildable_count: 2,
    reviewed_count: 0,
    has_semantic_model: false,
    warning_count: 1,
    uploaded_at: 1_700_000_500,
  },
]

describe('FabricJobs', () => {
  afterEach(() => vi.restoreAllMocks())

  it('lists uploaded pipelines with review status', async () => {
    useFabricWizard.getState().reset()
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        if (url.endsWith('/fabric-pipelines/jobs')) return new Response(JSON.stringify(jobs))
        return new Response(JSON.stringify({}), { status: 404 })
      }),
    )

    renderPage()

    await waitFor(() => expect(screen.getByText('fabric-samples-healthcare')).toBeInTheDocument())
    expect(screen.getByText('Untitled pipeline')).toBeInTheDocument()
    // "Reviewed"/"Needs review" each appear twice (a summary stat card and
    // the per-row status badge) -- just confirm both states are present.
    expect(screen.getAllByText('Reviewed').length).toBeGreaterThan(0)
    expect(screen.getAllByText('Needs review').length).toBeGreaterThan(0)
    expect(screen.getByText('4/4 reviewed · 10 total')).toBeInTheDocument()
  })

  it('opens a job by resuming the fabric wizard at the review step', async () => {
    useFabricWizard.getState().reset()
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        if (url.endsWith('/fabric-pipelines/jobs')) return new Response(JSON.stringify(jobs))
        return new Response(JSON.stringify({}), { status: 404 })
      }),
    )

    renderPage()
    const user = userEvent.setup()
    await waitFor(() => expect(screen.getByText('fabric-samples-healthcare')).toBeInTheDocument())

    await user.click(screen.getAllByRole('button', { name: /open/i })[0])

    await waitFor(() => expect(screen.getByText('Fabric wizard')).toBeInTheDocument())
    expect(useFabricWizard.getState().pipelineId).toBe(jobs[0].id)
    expect(useFabricWizard.getState().step).toBe('review')
  })

  it('shows an empty state when there are no pipelines yet', async () => {
    useFabricWizard.getState().reset()
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        if (url.endsWith('/fabric-pipelines/jobs')) return new Response(JSON.stringify([]))
        return new Response(JSON.stringify({}), { status: 404 })
      }),
    )

    renderPage()
    await waitFor(() =>
      expect(screen.getByText(/no fabric pipelines uploaded yet/i)).toBeInTheDocument(),
    )
  })
})
