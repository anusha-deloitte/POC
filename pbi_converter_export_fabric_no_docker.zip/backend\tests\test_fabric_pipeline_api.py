"""WS1 API: upload -> classify -> review-grid endpoints."""

import io
import json
import zipfile

import pytest
from fastapi.testclient import TestClient

from app.api.deps import get_connection_store, get_fabric_pipeline_store, get_ingest_service
from app.main import app
from app.services.connections import AuthMethod, ConnectionStore, SnowflakeProfileIn
from app.services.fabric_notebooks import FabricPipelineStore
from app.services.ingest import IngestService
from app.services.snowflake_sessions import SnowflakeSessionManager


def _zip_bytes(files: dict[str, str]) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        for name, content in files.items():
            zf.writestr(name, content)
    return buf.getvalue()


NOTEBOOK = json.dumps(
    {
        "cells": [{"cell_type": "code", "source": ["spark.sql('SELECT 1')"]}],
        "metadata": {},
        "nbformat": 4,
        "nbformat_minor": 5,
    }
)


class _FakeSnowflakeCursor:
    def __init__(self):
        self.executed: list[str] = []

    def execute(self, sql, params=None):
        self.executed.append(sql)
        return self

    def fetchall(self):
        # DESCRIBE TABLE ...."SALES" -> two columns
        if self.executed and '"SALES"' in self.executed[-1]:
            return [("ORDER_ID", "NUMBER(38,0)", None), ("AMOUNT", "NUMBER(10,2)", None)]
        return []

    def fetchone(self):
        return None

    def close(self):
        pass


class _FakeSnowflakeConnection:
    closed = False

    def cursor(self):
        return _FakeSnowflakeCursor()

    def is_closed(self):
        return self.closed

    def close(self):
        self.closed = True


@pytest.fixture()
def client(tmp_path):
    store = FabricPipelineStore(tmp_path / "storage")
    connections = ConnectionStore(tmp_path / "storage", tmp_path / "storage" / ".key")
    ingest = IngestService(tmp_path / "storage")
    session_manager = SnowflakeSessionManager(
        connections, connect=lambda **kwargs: _FakeSnowflakeConnection()
    )
    connections._session_manager = session_manager
    app.dependency_overrides[get_fabric_pipeline_store] = lambda: store
    app.dependency_overrides[get_connection_store] = lambda: connections
    app.dependency_overrides[get_ingest_service] = lambda: ingest
    with TestClient(app) as c:
        c.connections = connections
        c.ingest = ingest
        yield c
    session_manager.close_all()
    app.dependency_overrides.clear()


class TestUploadAndReview:
    def test_upload_classifies_and_returns_pipeline(self, client):
        payload = _zip_bytes(
            {
                "notebooks/03-BuildGoldStarSchema.ipynb": NOTEBOOK,
                "scripts/load.sql": "SELECT 1",
            }
        )
        resp = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        )
        assert resp.status_code == 201, resp.text
        body = resp.json()
        assert body["has_semantic_model"] is False
        assert len(body["artifacts"]) == 2

    def test_upload_rejects_non_zip(self, client):
        resp = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("notes.txt", b"hello", "text/plain")},
        )
        assert resp.status_code == 422

    def test_get_pipeline_after_upload(self, client):
        payload = _zip_bytes({"notebooks/a.ipynb": NOTEBOOK})
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()

        resp = client.get(f"/api/v1/fabric-pipelines/{upload['id']}")
        assert resp.status_code == 200
        assert resp.json()["id"] == upload["id"]

    def test_get_unknown_pipeline_404s(self, client):
        resp = client.get("/api/v1/fabric-pipelines/00000000-0000-0000-0000-000000000000")
        assert resp.status_code == 404

    def test_patch_artifact_review(self, client):
        payload = _zip_bytes({"notebooks/a.ipynb": NOTEBOOK})
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()
        artifact_id = upload["artifacts"][0]["id"]

        resp = client.patch(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{artifact_id}",
            json={"layer": "silver", "schedule": "hourly", "reviewed": True},
        )
        assert resp.status_code == 200
        artifact = next(a for a in resp.json()["artifacts"] if a["id"] == artifact_id)
        assert artifact["layer"] == "silver"
        assert artifact["schedule"] == "hourly"
        assert artifact["reviewed"] is True

    def test_patch_unknown_artifact_404s(self, client):
        payload = _zip_bytes({"notebooks/a.ipynb": NOTEBOOK})
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()
        resp = client.patch(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/nope",
            json={"reviewed": True},
        )
        assert resp.status_code == 404

    def test_translation_preview_for_notebook(self, client):
        payload = _zip_bytes({"notebooks/a.ipynb": NOTEBOOK})
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()
        artifact_id = upload["artifacts"][0]["id"]

        resp = client.get(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{artifact_id}/translation"
        )
        assert resp.status_code == 200, resp.text
        body = resp.json()
        assert body["cells"][0]["tier"] == "sql"
        assert "SELECT 1" in body["cells"][0]["statements"][0]["sql"].upper()

    def test_translation_preview_for_pbip_artifact_422s(self, client):
        payload = _zip_bytes(
            {
                "Contoso.Report/definition.pbir": json.dumps(
                    {"datasetReference": {"byPath": {"path": "../Contoso.SemanticModel"}}}
                ),
                "Contoso.Report/definition/report.json": "{}",
                "Contoso.SemanticModel/definition/model.tmdl": "model Model\n",
                "Contoso.pbip": json.dumps(
                    {"version": "1.0", "artifacts": [{"report": {"path": "Contoso.Report"}}]}
                ),
            }
        )
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()
        pbip_artifact = next(a for a in upload["artifacts"] if a["kind"] == "pbip")

        resp = client.get(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{pbip_artifact['id']}/translation"
        )
        assert resp.status_code == 422


class TestListJobs:
    def test_lists_uploaded_pipelines_newest_first(self, client):
        first = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", _zip_bytes({"notebooks/a.ipynb": NOTEBOOK}), "application/zip")},
        ).json()
        second = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", _zip_bytes({"scripts/b.sql": "SELECT 1"}), "application/zip")},
        ).json()

        resp = client.get("/api/v1/fabric-pipelines/jobs")
        assert resp.status_code == 200, resp.text
        ids = [j["id"] for j in resp.json()]
        assert ids.index(second["id"]) < ids.index(first["id"])

    def test_job_summary_reflects_review_progress(self, client):
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", _zip_bytes({"notebooks/a.ipynb": NOTEBOOK}), "application/zip")},
        ).json()
        artifact_id = upload["artifacts"][0]["id"]
        client.patch(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{artifact_id}",
            json={"layer": "silver", "reviewed": True},
        )

        job = next(j for j in client.get("/api/v1/fabric-pipelines/jobs").json() if j["id"] == upload["id"])
        assert job["artifact_count"] == 1
        assert job["buildable_count"] == 1
        assert job["reviewed_count"] == 1
        assert job["has_semantic_model"] is False

    def test_jobs_route_does_not_get_shadowed_by_conversion_id_route(self, client):
        # "jobs" must not be swallowed as a {conversion_id} path param --
        # this route has to be declared before it in the router.
        resp = client.get("/api/v1/fabric-pipelines/jobs")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)


class TestBuildPlanPreview:
    def _connection_id(self, client) -> str:
        profile = client.connections.create(
            SnowflakeProfileIn(
                name="test",
                account="acme-xy12345",
                user="svc",
                auth_method=AuthMethod.PASSWORD,
                password="secret",
                database="MYDB",
                schema="TGT",
                warehouse="WH",
            )
        )
        return profile.id

    def test_build_plan_for_reviewed_artifacts(self, client):
        payload = _zip_bytes({"notebooks/bronze.ipynb": NOTEBOOK})
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()
        artifact_id = upload["artifacts"][0]["id"]
        client.patch(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{artifact_id}",
            json={"layer": "bronze", "reviewed": True},
        )

        resp = client.post(
            f"/api/v1/fabric-pipelines/{upload['id']}/build-plan",
            json={"connection_id": self._connection_id(client)},
        )
        assert resp.status_code == 200, resp.text
        body = resp.json()
        assert body["schemas"] == ["TGT__BRONZE"]

    def test_build_plan_unknown_connection_404s(self, client):
        payload = _zip_bytes({"notebooks/a.ipynb": NOTEBOOK})
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()
        resp = client.post(
            f"/api/v1/fabric-pipelines/{upload['id']}/build-plan",
            json={"connection_id": "00000000-0000-0000-0000-000000000000"},
        )
        assert resp.status_code == 404


_SALES_TMDL = """model Model

table Sales
\tcolumn OrderId
\t\tdataType: int64
\t\tsourceColumn: ORDER_ID

\tcolumn Amount
\t\tdataType: decimal
\t\tsourceColumn: AMOUNT

\tpartition Sales = m
\t\tmode: directQuery
\t\tsource =
\t\t\t\tlet
\t\t\t\t    Source = Fabric.Lakehouse()
\t\t\t\tin
\t\t\t\t    Source
"""

SALES_NOTEBOOK = json.dumps(
    {
        "cells": [{"cell_type": "code", "source": ["x = spark.sql('SELECT 1')\nx.write.saveAsTable('sales')"]}],
        "metadata": {},
        "nbformat": 4,
        "nbformat_minor": 5,
    }
)


class TestExecuteBuild:
    def _upload_with_pbip_and_notebook(self, client) -> dict:
        payload = _zip_bytes(
            {
                "notebooks/gold.ipynb": SALES_NOTEBOOK,
                "Contoso.Report/definition.pbir": json.dumps(
                    {"datasetReference": {"byPath": {"path": "../Contoso.SemanticModel"}}}
                ),
                "Contoso.Report/definition/report.json": "{}",
                "Contoso.SemanticModel/definition/model.tmdl": _SALES_TMDL,
                "Contoso.pbip": json.dumps(
                    {"version": "1.0", "artifacts": [{"report": {"path": "Contoso.Report"}}]}
                ),
            }
        )
        return client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()

    def _connection_id(self, client) -> str:
        profile = client.connections.create(
            SnowflakeProfileIn(
                name="test",
                account="acme-xy12345",
                user="svc",
                auth_method=AuthMethod.PASSWORD,
                password="secret",
                database="MYDB",
                schema="TGT",
                warehouse="WH",
            )
        )
        return profile.id

    def test_execute_build_runs_ddl_and_gates_fidelity(self, client):
        upload = self._upload_with_pbip_and_notebook(client)
        assert upload["has_semantic_model"] is True
        notebook_artifact = next(a for a in upload["artifacts"] if a["kind"] == "notebook")
        client.patch(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{notebook_artifact['id']}",
            json={"layer": "gold", "reviewed": True},
        )

        resp = client.post(
            f"/api/v1/fabric-pipelines/{upload['id']}/execute-build",
            json={"connection_id": self._connection_id(client)},
        )
        assert resp.status_code == 200, resp.text
        body = resp.json()
        assert body["created"] == ["SALES"]
        assert body["fidelity"] is not None
        assert body["fidelity"]["results"][0]["table"] == "Sales"
        assert body["fidelity"]["results"][0]["matched"] is True

    def test_execute_build_without_semantic_model_skips_fidelity(self, client):
        payload = _zip_bytes({"notebooks/gold.ipynb": SALES_NOTEBOOK})
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()
        artifact_id = upload["artifacts"][0]["id"]
        client.patch(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{artifact_id}",
            json={"layer": "gold", "reviewed": True},
        )
        resp = client.post(
            f"/api/v1/fabric-pipelines/{upload['id']}/execute-build",
            json={"connection_id": self._connection_id(client)},
        )
        assert resp.status_code == 200, resp.text
        assert resp.json()["fidelity"] is None


class TestExportPbip:
    def _upload_with_pbip_and_notebook(self, client) -> dict:
        payload = _zip_bytes(
            {
                "notebooks/gold.ipynb": SALES_NOTEBOOK,
                "Contoso.Report/definition.pbir": json.dumps(
                    {"datasetReference": {"byPath": {"path": "../Contoso.SemanticModel"}}}
                ),
                "Contoso.Report/definition/report.json": "{}",
                "Contoso.SemanticModel/definition/model.tmdl": _SALES_TMDL,
                "Contoso.pbip": json.dumps(
                    {"version": "1.0", "artifacts": [{"report": {"path": "Contoso.Report"}}]}
                ),
            }
        )
        return client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()

    def _connection_id(self, client) -> str:
        profile = client.connections.create(
            SnowflakeProfileIn(
                name="test",
                account="acme-xy12345",
                user="svc",
                auth_method=AuthMethod.PASSWORD,
                password="secret",
                database="MYDB",
                schema="TGT",
                warehouse="WH",
            )
        )
        return profile.id

    def _review_and_export(self, client, mode=None) -> "TestClient":
        upload = self._upload_with_pbip_and_notebook(client)
        notebook_artifact = next(a for a in upload["artifacts"] if a["kind"] == "notebook")
        client.patch(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{notebook_artifact['id']}",
            json={"layer": "gold", "reviewed": True},
        )
        body = {"connection_id": self._connection_id(client)}
        if mode:
            body["mode"] = mode
        return client.post(f"/api/v1/fabric-pipelines/{upload['id']}/export-pbip", json=body)

    def test_export_repoints_matched_table_and_returns_zip(self, client):
        resp = self._review_and_export(client)
        assert resp.status_code == 200, resp.text
        assert resp.headers["content-type"] == "application/zip"
        assert resp.headers["x-repointed-tables"] == "Sales"

        archive = zipfile.ZipFile(io.BytesIO(resp.content))
        model_text = archive.read("Contoso.SemanticModel/definition/model.tmdl").decode("utf-8")
        assert "SALES" in model_text  # new Snowflake object name
        assert "mode: directQuery" in model_text  # decision #11 default
        assert 'Snowflake.Databases("acme-xy12345", "WH")' in model_text

    def test_export_respects_import_mode_override(self, client):
        resp = self._review_and_export(client, mode="import")
        assert resp.status_code == 200, resp.text
        archive = zipfile.ZipFile(io.BytesIO(resp.content))
        model_text = archive.read("Contoso.SemanticModel/definition/model.tmdl").decode("utf-8")
        assert "mode: import" in model_text

    def test_export_without_semantic_model_422s(self, client):
        payload = _zip_bytes({"notebooks/gold.ipynb": SALES_NOTEBOOK})
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()
        artifact_id = upload["artifacts"][0]["id"]
        client.patch(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{artifact_id}",
            json={"layer": "gold", "reviewed": True},
        )
        resp = client.post(
            f"/api/v1/fabric-pipelines/{upload['id']}/export-pbip",
            json={"connection_id": self._connection_id(client)},
        )
        assert resp.status_code == 422

    def test_export_original_upload_never_mutated(self, client):
        upload = self._upload_with_pbip_and_notebook(client)
        notebook_artifact = next(a for a in upload["artifacts"] if a["kind"] == "notebook")
        client.patch(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{notebook_artifact['id']}",
            json={"layer": "gold", "reviewed": True},
        )
        resp = client.post(
            f"/api/v1/fabric-pipelines/{upload['id']}/export-pbip",
            json={"connection_id": self._connection_id(client)},
        )
        assert resp.status_code == 200, resp.text

        source_model = (
            client.ingest.conversion_dir(upload["id"])
            / "fabric_source"
            / "Contoso.SemanticModel"
            / "definition"
            / "model.tmdl"
        ).read_text(encoding="utf-8")
        assert "Fabric.Lakehouse()" in source_model  # original Fabric source, untouched
        assert "Snowflake.Databases" not in source_model


class TestTier3:
    def _connection_id(self, client) -> str:
        profile = client.connections.create(
            SnowflakeProfileIn(
                name="test",
                account="acme-xy12345",
                user="svc",
                auth_method=AuthMethod.PASSWORD,
                password="secret",
                database="MYDB",
                schema="TGT",
                warehouse="WH",
            )
        )
        return profile.id

    def test_tier3_without_horizon_credentials_reports_not_configured(self, client, monkeypatch):
        import app.services.horizon_client as hc

        monkeypatch.setattr(hc, "build_client_from_settings", lambda: None)

        payload = _zip_bytes(
            {"notebooks/a.ipynb": json.dumps({
                "cells": [{"cell_type": "code", "source": ["df = df.withColumn('r', explode('r'))"]}],
                "metadata": {}, "nbformat": 4, "nbformat_minor": 5,
            })}
        )
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()
        artifact_id = upload["artifacts"][0]["id"]

        resp = client.post(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{artifact_id}/cells/0/tier3",
            json={"connection_id": self._connection_id(client)},
        )
        assert resp.status_code == 200, resp.text
        body = resp.json()
        assert body["accepted"] is False
        assert "not configured" in body["trace"][0]

    def test_tier3_unknown_cell_404s(self, client):
        payload = _zip_bytes({"notebooks/a.ipynb": NOTEBOOK})
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()
        artifact_id = upload["artifacts"][0]["id"]
        resp = client.post(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{artifact_id}/cells/99/tier3",
            json={"connection_id": self._connection_id(client)},
        )
        assert resp.status_code == 404

    def test_tier3_non_notebook_artifact_422s(self, client):
        payload = _zip_bytes({"scripts/a.sql": "SELECT 1"})
        upload = client.post(
            "/api/v1/fabric-pipelines",
            files={"file": ("export.zip", payload, "application/zip")},
        ).json()
        artifact_id = upload["artifacts"][0]["id"]
        resp = client.post(
            f"/api/v1/fabric-pipelines/{upload['id']}/artifacts/{artifact_id}/cells/0/tier3",
            json={"connection_id": self._connection_id(client)},
        )
        assert resp.status_code == 422
