"""Fabric artifact ingestion (WS1): a single zip of whatever a Fabric workspace
export contains (.ipynb notebooks, .sql scripts, a .pbip project, and anything
else) classified by file type and staged for the human "which layer is this"
review step.

Layer tagging (bronze/silver/gold/skip) is deliberately NOT inferred with any
confidence — filename conventions don't generalize across customers. The
`_guess_layer()` heuristic below only pre-fills an editable dropdown; every
artifact starts unreviewed and the caller (the review-grid UI) is expected to
confirm or correct it before WS3 builds anything in Snowflake from it.
"""

from __future__ import annotations

import json
import shutil
import uuid
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field

from app.ir.report import ReportBundle
from app.parsers.bim import BimParseError
from app.parsers.bundle import find_pbip, load_pbip
from app.parsers.pbir import PbirParseError, resolve_dataset_reference
from app.parsers.tmdl import TmdlParseError
from app.services.ingest import IngestError, safe_extract_zip

_IGNORED_DIR_NAMES = {".pbi", ".git", "__pycache__"}

Layer = Literal["bronze", "silver", "gold", "skip"]
ArtifactKind = Literal["notebook", "sql", "pbip", "other"]

_GOLD_HINTS = ("gold", "star", "starschema", "mart", "fact", "dim", "dimension")
_SILVER_HINTS = ("silver", "clean", "stage", "staging", "curated", "transform")
_BRONZE_HINTS = ("bronze", "landing", "raw")


def _guess_layer(relative_path: str) -> Layer:
    lower = relative_path.lower()
    if any(h in lower for h in _GOLD_HINTS):
        return "gold"
    if any(h in lower for h in _SILVER_HINTS):
        return "silver"
    if any(h in lower for h in _BRONZE_HINTS):
        return "bronze"
    return "skip"


class NotebookCell(BaseModel):
    index: int
    cell_type: Literal["code", "markdown", "raw"]
    source: str


class FabricArtifact(BaseModel):
    id: str
    relative_path: str
    kind: ArtifactKind
    size_bytes: int = 0
    cells: list[NotebookCell] = Field(default_factory=list)  # kind == "notebook"
    sql_text: str | None = None  # kind == "sql"
    layer: Layer = "skip"
    schedule: str = ""  # human-entered cadence, e.g. "daily 02:00" or a cron string
    notes: str = ""
    reviewed: bool = False


class FabricPipeline(BaseModel):
    id: str
    has_semantic_model: bool = False
    artifacts: list[FabricArtifact] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class FabricPipelineError(Exception):
    pass


def _parse_notebook(path: Path, warnings: list[str]) -> list[NotebookCell]:
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except ValueError as e:
        warnings.append(f"{path.name}: not valid .ipynb JSON ({e})")
        return []
    cells: list[NotebookCell] = []
    for i, cell in enumerate(doc.get("cells", [])):
        source = cell.get("source", "")
        text = "".join(source) if isinstance(source, list) else str(source)
        cell_type = cell.get("cell_type", "code")
        if cell_type not in ("code", "markdown", "raw"):
            cell_type = "code"
        cells.append(NotebookCell(index=i, cell_type=cell_type, source=text))
    return cells


def classify_directory(root: Path) -> tuple[list[FabricArtifact], ReportBundle | None, list[str]]:
    """Walk an extracted Fabric-export folder, classifying every file.

    Returns (artifacts, bundle-if-a-.pbip-was-found-and-parsed, warnings).
    A .pbip that fails to parse is recorded as an artifact with a warning
    rather than aborting the whole upload — the notebooks/scripts are still
    useful on their own even if the report project can't be loaded yet.
    """
    artifacts: list[FabricArtifact] = []
    warnings: list[str] = []
    bundle: ReportBundle | None = None

    pbip_file: Path | None = None
    try:
        pbip_file = find_pbip(root)
    except PbirParseError:
        pbip_file = None

    all_files = sorted(p for p in root.rglob("*") if p.is_file())
    # everything under the .pbip project's own report/model folder trees
    # belongs to the single "pbip" artifact as a unit, not as individual
    # "other" files — excluded from the per-file sweep below by directory,
    # not just the .pbip file itself.
    pbip_excluded_dirs: list[Path] = []
    if pbip_file is not None:
        pbip_excluded_dirs.append(pbip_file)
        try:
            pbip_json = json.loads(pbip_file.read_text(encoding="utf-8"))
            report_rel = next(
                (a["report"]["path"] for a in pbip_json.get("artifacts", []) if "report" in a),
                None,
            )
            if report_rel:
                report_dir = (pbip_file.parent / report_rel).resolve()
                pbip_excluded_dirs.append(report_dir)
                pbip_excluded_dirs.append(resolve_dataset_reference(report_dir))
        except (ValueError, PbirParseError, OSError):
            pass  # best-effort exclusion only; load_pbip() below reports the real error

        try:
            bundle = load_pbip(root)
        except (PbirParseError, TmdlParseError, BimParseError, FileNotFoundError) as e:
            warnings.append(f"{pbip_file.name}: could not parse .pbip project ({e})")
        artifacts.append(
            FabricArtifact(
                id=str(uuid.uuid4()),
                relative_path=str(pbip_file.relative_to(root)),
                kind="pbip",
                size_bytes=pbip_file.stat().st_size,
                layer="skip",
            )
        )

    def _under_pbip_project(path: Path) -> bool:
        return any(path == d or d in path.parents for d in pbip_excluded_dirs)

    for path in all_files:
        if _under_pbip_project(path):
            continue
        if any(part in _IGNORED_DIR_NAMES for part in path.parts):
            continue
        rel = str(path.relative_to(root))
        suffix = path.suffix.lower()
        if suffix == ".ipynb":
            artifacts.append(
                FabricArtifact(
                    id=str(uuid.uuid4()),
                    relative_path=rel,
                    kind="notebook",
                    size_bytes=path.stat().st_size,
                    cells=_parse_notebook(path, warnings),
                    layer=_guess_layer(rel),
                )
            )
        elif suffix == ".sql":
            artifacts.append(
                FabricArtifact(
                    id=str(uuid.uuid4()),
                    relative_path=rel,
                    kind="sql",
                    size_bytes=path.stat().st_size,
                    sql_text=path.read_text(encoding="utf-8", errors="replace"),
                    layer=_guess_layer(rel),
                )
            )
        elif suffix == ".pbip":
            # a second/unrelated .pbip elsewhere in the archive — find_pbip()
            # only picked the first one; record the rest as reference-only.
            artifacts.append(
                FabricArtifact(
                    id=str(uuid.uuid4()),
                    relative_path=rel,
                    kind="other",
                    size_bytes=path.stat().st_size,
                    layer="skip",
                    notes="additional .pbip found alongside the primary one; not parsed",
                )
            )
        else:
            artifacts.append(
                FabricArtifact(
                    id=str(uuid.uuid4()),
                    relative_path=rel,
                    kind="other",
                    size_bytes=path.stat().st_size,
                    layer="skip",
                )
            )

    return artifacts, bundle, warnings


class FabricPipelineStore:
    """Persists fabric_pipeline.json next to bundle.json in a conversion's
    storage folder, per decision #13 of the migration spec."""

    def __init__(self, storage_dir: Path):
        self.storage_dir = storage_dir
        storage_dir.mkdir(parents=True, exist_ok=True)

    def conversion_dir(self, conversion_id: str) -> Path:
        return self.storage_dir / str(uuid.UUID(conversion_id))

    def _pipeline_file(self, conversion_id: str) -> Path:
        return self.conversion_dir(conversion_id) / "fabric_pipeline.json"

    def ingest_zip(self, archive: Path, conversion_id: str | None = None) -> FabricPipeline:
        """Extract + classify. If `conversion_id` is given it must already
        exist (attaches to a conversion created by the regular .pbip upload
        flow); otherwise a fresh conversion folder is created for this upload,
        which is the path used when the .pbip itself travels inside the
        Fabric zip."""
        if conversion_id is not None:
            root = self.conversion_dir(conversion_id)
            if not root.is_dir():
                raise FabricPipelineError(f"unknown conversion: {conversion_id}")
        else:
            conversion_id = str(uuid.uuid4())
            root = self.storage_dir / conversion_id
            root.mkdir(parents=True)

        fabric_src = root / "fabric_source"
        try:
            safe_extract_zip(archive, fabric_src)
            artifacts, bundle, warnings = classify_directory(fabric_src)
        except (IngestError, PbirParseError, TmdlParseError, BimParseError):
            if not (root / "bundle.json").is_file():
                shutil.rmtree(root, ignore_errors=True)
            raise

        bundle_file = root / "bundle.json"
        if bundle is not None and not bundle_file.is_file():
            bundle_file.write_text(bundle.model_dump_json(indent=2), encoding="utf-8")

        pipeline = FabricPipeline(
            id=conversion_id,
            has_semantic_model=bundle_file.is_file(),
            artifacts=artifacts,
            warnings=warnings,
        )
        self._pipeline_file(conversion_id).write_text(
            pipeline.model_dump_json(indent=2), encoding="utf-8"
        )
        return pipeline

    def load(self, conversion_id: str) -> FabricPipeline:
        f = self._pipeline_file(conversion_id)
        if not f.is_file():
            raise FabricPipelineError(f"no fabric pipeline for conversion: {conversion_id}")
        return FabricPipeline.model_validate_json(f.read_text(encoding="utf-8"))

    def list_pipelines(self) -> list[dict]:
        """Every uploaded Fabric export, newest first -- a directory scan
        keyed on fabric_pipeline.json's presence (mirrors IngestService's
        own list_jobs(): no separate index, the filesystem is the index).
        A Fabric pipeline's own conversion dir may or may not also hold a
        bundle.json (see ingest_zip's docstring), so this can't reuse
        list_jobs()'s bundle.json-keyed scan. Conversion dirs are named by
        a random uuid4, not a sortable timestamp, so "newest" is sorted by
        fabric_pipeline.json's own mtime after the fact, not by dir name."""
        pipelines: list[dict] = []
        for d in self.storage_dir.iterdir():
            f = d / "fabric_pipeline.json"
            if not f.is_file():
                continue
            try:
                pipeline = FabricPipeline.model_validate_json(f.read_text(encoding="utf-8"))
            except ValueError:
                continue
            name = next(
                (
                    Path(a.relative_path).stem
                    for a in pipeline.artifacts
                    if a.kind == "pbip"
                ),
                None,
            )
            if name is None and pipeline.artifacts:
                first = pipeline.artifacts[0].relative_path.replace("\\", "/")
                name = first.split("/", 1)[0] if "/" in first else None
            pipelines.append(
                {
                    "id": pipeline.id,
                    "name": name,
                    "artifact_count": len(pipeline.artifacts),
                    "buildable_count": sum(
                        1 for a in pipeline.artifacts if a.layer != "skip"
                    ),
                    "reviewed_count": sum(
                        1
                        for a in pipeline.artifacts
                        if a.reviewed and a.layer != "skip"
                    ),
                    "has_semantic_model": pipeline.has_semantic_model,
                    "warning_count": len(pipeline.warnings),
                    "uploaded_at": f.stat().st_mtime,
                }
            )
        pipelines.sort(key=lambda p: p["uploaded_at"], reverse=True)
        return pipelines

    def update_artifact(
        self,
        conversion_id: str,
        artifact_id: str,
        *,
        layer: Layer | None = None,
        schedule: str | None = None,
        notes: str | None = None,
        reviewed: bool | None = None,
    ) -> FabricPipeline:
        pipeline = self.load(conversion_id)
        for artifact in pipeline.artifacts:
            if artifact.id == artifact_id:
                if layer is not None:
                    artifact.layer = layer
                if schedule is not None:
                    artifact.schedule = schedule
                if notes is not None:
                    artifact.notes = notes
                if reviewed is not None:
                    artifact.reviewed = reviewed
                break
        else:
            raise FabricPipelineError(f"unknown artifact: {artifact_id}")
        self._pipeline_file(conversion_id).write_text(
            pipeline.model_dump_json(indent=2), encoding="utf-8"
        )
        return pipeline
