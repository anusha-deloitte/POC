"""WS1: Fabric artifact ingestion (zip upload -> classified review grid)."""

import json
import zipfile
from pathlib import Path

import pytest

from app.services.fabric_notebooks import (
    FabricPipelineError,
    FabricPipelineStore,
    _guess_layer,
    classify_directory,
)

# Real Microsoft public sample referenced by the migration spec (§4) — used
# only as an optional, best-effort smoke test; skipped when not present on
# this machine so the suite stays portable/CI-friendly.
_CMS_SAMPLE = (
    Path.home()
    / "OneDrive - Deloitte (O365D)"
    / "Desktop"
    / "Repositories"
    / "fabric-samples-healthcare"
    / "analytics-bi-directlake-starschema"
)


def _notebook(cells: list[tuple[str, str]]) -> str:
    return json.dumps(
        {
            "cells": [
                {"cell_type": ct, "source": src.splitlines(keepends=True)} for ct, src in cells
            ],
            "metadata": {},
            "nbformat": 4,
            "nbformat_minor": 5,
        }
    )


def _write_zip(tmp_path: Path, files: dict[str, str]) -> Path:
    archive = tmp_path / "fabric_export.zip"
    with zipfile.ZipFile(archive, "w") as zf:
        for name, content in files.items():
            zf.writestr(name, content)
    return archive


MIXED_ZIP_FILES = {
    "notebooks/01-DownloadCsvFiles.ipynb": _notebook(
        [("markdown", "# Download"), ("code", "import requests\nrequests.get('https://example.com')")]
    ),
    "notebooks/02-BuildGoldStarSchema.ipynb": _notebook(
        [("code", "df = spark.sql('SELECT * FROM bronze.orders')")]
    ),
    "scripts/01_provider_dim_SPROC.sql": (
        "CREATE PROCEDURE dbo.usp_load_provider_dim AS\nBEGIN\n"
        "  INSERT INTO gold.provider_dim SELECT * FROM silver.provider;\nEND"
    ),
    "docs/Readme.md": "# Fabric workspace export\nSee notebooks/ for the pipeline.",
    "reference/screenshot.png": "not-a-real-png",
}


class TestGuessLayer:
    @pytest.mark.parametrize(
        ("path", "expected"),
        [
            ("notebooks/03-CreateStarSchema.ipynb", "gold"),
            ("scripts/gold_fact_load.sql", "gold"),
            ("notebooks/02-SilverCleanup.ipynb", "silver"),
            ("notebooks/staging_transform.ipynb", "silver"),
            ("notebooks/bronze_landing.ipynb", "bronze"),
            ("notebooks/01-DownloadCsvFiles.ipynb", "skip"),
            ("docs/Readme.md", "skip"),
        ],
    )
    def test_hints(self, path, expected):
        assert _guess_layer(path) == expected


class TestClassifyDirectory:
    def test_classifies_mixed_export(self, tmp_path):
        root = tmp_path / "extracted"
        for rel, content in MIXED_ZIP_FILES.items():
            p = root / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content, encoding="utf-8")

        artifacts, bundle, warnings = classify_directory(root)
        assert bundle is None
        assert warnings == []

        by_path = {a.relative_path.replace("\\", "/"): a for a in artifacts}
        assert len(artifacts) == 5

        dl = by_path["notebooks/01-DownloadCsvFiles.ipynb"]
        assert dl.kind == "notebook"
        assert dl.layer == "skip"
        assert len(dl.cells) == 2
        assert dl.cells[0].cell_type == "markdown"
        assert dl.cells[1].cell_type == "code"
        assert "requests.get" in dl.cells[1].source

        gold_nb = by_path["notebooks/02-BuildGoldStarSchema.ipynb"]
        assert gold_nb.layer == "gold"

        sproc = by_path["scripts/01_provider_dim_SPROC.sql"]
        assert sproc.kind == "sql"
        assert "CREATE PROCEDURE" in sproc.sql_text
        assert sproc.layer == "gold"  # filename contains "dim"

        readme = by_path["docs/Readme.md"]
        assert readme.kind == "other"
        assert readme.sql_text is None
        assert readme.cells == []

        png = by_path["reference/screenshot.png"]
        assert png.kind == "other"

    def test_malformed_notebook_records_warning_not_error(self, tmp_path):
        root = tmp_path / "extracted"
        root.mkdir()
        (root / "broken.ipynb").write_text("{not json", encoding="utf-8")

        artifacts, bundle, warnings = classify_directory(root)
        assert len(artifacts) == 1
        assert artifacts[0].kind == "notebook"
        assert artifacts[0].cells == []
        assert any("not valid" in w for w in warnings)

    def test_pbip_project_excluded_from_per_file_sweep(self, tmp_path):
        """A .pbip project bundled in the zip is one artifact, not one per
        underlying report.json/definition.pbir/tmdl file."""
        root = tmp_path / "extracted"
        report_dir = root / "Contoso.Report"
        model_dir = root / "Contoso.SemanticModel"
        (report_dir / "definition").mkdir(parents=True)
        (report_dir / "definition" / "report.json").write_text("{}", encoding="utf-8")
        (report_dir / "definition.pbir").write_text(
            json.dumps({"datasetReference": {"byPath": {"path": "../Contoso.SemanticModel"}}}),
            encoding="utf-8",
        )
        (model_dir / "definition").mkdir(parents=True)
        (model_dir / "definition" / "model.tmdl").write_text(
            "model Model\n\ntable Sales\n\tcolumn Amount\n\t\tdataType: double\n",
            encoding="utf-8",
        )
        (root / "Contoso.pbip").write_text(
            json.dumps({"version": "1.0", "artifacts": [{"report": {"path": "Contoso.Report"}}]}),
            encoding="utf-8",
        )

        artifacts, bundle, warnings = classify_directory(root)
        assert warnings == []
        assert bundle is not None
        assert bundle.model.table("Sales") is not None
        assert len(artifacts) == 1
        assert artifacts[0].kind == "pbip"


class TestFabricPipelineStore:
    def test_ingest_zip_creates_new_conversion(self, tmp_path):
        store = FabricPipelineStore(tmp_path / "storage")
        archive = _write_zip(tmp_path, MIXED_ZIP_FILES)

        pipeline = store.ingest_zip(archive)
        assert not pipeline.has_semantic_model
        assert len(pipeline.artifacts) == 5

        loaded = store.load(pipeline.id)
        assert loaded.id == pipeline.id
        assert len(loaded.artifacts) == 5

    def test_ingest_zip_with_pbip_writes_bundle_json(self, tmp_path):
        files = dict(MIXED_ZIP_FILES)
        files["Contoso.Report/definition.pbir"] = json.dumps(
            {"datasetReference": {"byPath": {"path": "../Contoso.SemanticModel"}}}
        )
        files["Contoso.Report/definition/report.json"] = "{}"
        files["Contoso.SemanticModel/definition/model.tmdl"] = "model Model\n"
        files["Contoso.pbip"] = json.dumps(
            {"version": "1.0", "artifacts": [{"report": {"path": "Contoso.Report"}}]}
        )
        archive = _write_zip(tmp_path, files)

        store = FabricPipelineStore(tmp_path / "storage")
        pipeline = store.ingest_zip(archive)
        assert pipeline.has_semantic_model
        bundle_file = store.conversion_dir(pipeline.id) / "bundle.json"
        assert bundle_file.is_file()

    def test_update_artifact_review(self, tmp_path):
        store = FabricPipelineStore(tmp_path / "storage")
        archive = _write_zip(tmp_path, MIXED_ZIP_FILES)
        pipeline = store.ingest_zip(archive)
        artifact_id = pipeline.artifacts[0].id

        updated = store.update_artifact(
            pipeline.id, artifact_id, layer="bronze", schedule="daily 02:00", reviewed=True
        )
        target = next(a for a in updated.artifacts if a.id == artifact_id)
        assert target.layer == "bronze"
        assert target.schedule == "daily 02:00"
        assert target.reviewed is True

        # persisted, not just in-memory
        reloaded = store.load(pipeline.id)
        assert next(a for a in reloaded.artifacts if a.id == artifact_id).layer == "bronze"

    def test_update_unknown_artifact_raises(self, tmp_path):
        store = FabricPipelineStore(tmp_path / "storage")
        archive = _write_zip(tmp_path, MIXED_ZIP_FILES)
        pipeline = store.ingest_zip(archive)
        with pytest.raises(FabricPipelineError):
            store.update_artifact(pipeline.id, "nonexistent", reviewed=True)

    def test_load_unknown_conversion_raises(self, tmp_path):
        store = FabricPipelineStore(tmp_path / "storage")
        with pytest.raises(FabricPipelineError):
            store.load("00000000-0000-0000-0000-000000000000")

    def test_attach_to_existing_conversion(self, tmp_path):
        from app.services.ingest import IngestService

        ingest = IngestService(tmp_path / "storage")
        stored = ingest.ingest_folder(
            Path(__file__).resolve().parents[2] / "fixtures" / "contoso_sales"
        )

        store = FabricPipelineStore(tmp_path / "storage")
        archive = _write_zip(tmp_path, MIXED_ZIP_FILES)
        pipeline = store.ingest_zip(archive, conversion_id=stored.id)

        assert pipeline.id == stored.id
        assert (store.conversion_dir(stored.id) / "bundle.json").is_file()


@pytest.mark.skipif(not _CMS_SAMPLE.is_dir(), reason="external reference fixture not present")
class TestRealCmsSample:
    """Best-effort smoke test against the spec's own validated reference
    sample (§4) — exercises classify_directory against real Fabric notebook
    JSON shapes, not just hand-built fixtures."""

    def test_classifies_real_sample(self, tmp_path):
        root = tmp_path / "cms"
        root.mkdir()
        for name in (
            "01-DownloadCMSDataCsvFiles.ipynb",
            "02-CreateCMSDataTable.ipynb",
            "03-CreateCMSStarSchemaTables.ipynb",
        ):
            (root / name).write_bytes((_CMS_SAMPLE / name).read_bytes())
        scripts_dir = root / "scripts"
        scripts_dir.mkdir()
        for name in ("01_CMS_provider_dimensions_SPROC.sql", "02_CMS_provider_fact_SPROC.sql"):
            (scripts_dir / name).write_bytes((_CMS_SAMPLE / "scripts" / name).read_bytes())

        artifacts, bundle, warnings = classify_directory(root)
        assert bundle is None
        assert warnings == []
        by_path = {a.relative_path.replace("\\", "/"): a for a in artifacts}
        assert len(by_path["01-DownloadCMSDataCsvFiles.ipynb"].cells) > 0
        assert by_path["03-CreateCMSStarSchemaTables.ipynb"].layer == "gold"
        assert "spark.sql" in by_path["02-CreateCMSDataTable.ipynb"].cells[0].source or any(
            "spark.sql" in c.source for c in by_path["02-CreateCMSDataTable.ipynb"].cells
        )
        assert (
            "CREATE PROCEDURE"
            in by_path["scripts/01_CMS_provider_dimensions_SPROC.sql"].sql_text.upper()
        )
