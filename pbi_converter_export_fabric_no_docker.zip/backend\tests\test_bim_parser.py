"""TMSL (model.bim) parser -> same IR shape as tmdl.py produces."""

import json

import pytest

from app.ir.model import DataType, PartitionMode, SummarizeBy
from app.parsers.bim import BimParseError, parse_bim_dict, parse_bim_file

SAMPLE = {
    "name": "Sales Model",
    "model": {
        "culture": "en-US",
        "annotations": [{"name": "PBI_QueryOrder", "value": "[\"Sales\"]"}],
        "tables": [
            {
                "name": "Sales",
                "lineageTag": "tbl-sales",
                "columns": [
                    {
                        "name": "OrderDate",
                        "dataType": "dateTime",
                        "sourceColumn": "OrderDate",
                        "summarizeBy": "None",
                        "isKey": False,
                        "lineageTag": "col-date",
                    },
                    {
                        "name": "Amount",
                        "dataType": "double",
                        "sourceColumn": "Amount",
                        "summarizeBy": "Sum",
                    },
                    {
                        "name": "Margin Pct",
                        "dataType": "double",
                        "type": "calculated",
                        "expression": ["DIVIDE(", "  [Amount] - [Cost],", "  [Amount]", ")"],
                        "isHidden": True,
                    },
                ],
                "measures": [
                    {
                        "name": "Total Sales",
                        "expression": "SUM(Sales[Amount])",
                        "formatString": "$#,0",
                        "displayFolder": "Core",
                        "lineageTag": "meas-total",
                    }
                ],
                "hierarchies": [
                    {
                        "name": "Calendar",
                        "levels": [
                            {"name": "Year", "column": "OrderDate", "ordinal": 0},
                            {"name": "Month", "column": "OrderDate", "ordinal": 1},
                        ],
                    }
                ],
                "partitions": [
                    {
                        "name": "Sales-Partition",
                        "mode": "import",
                        "source": {
                            "type": "m",
                            "expression": ["let", "  Source = Fabric.Lakehouse()", "in", "  Source"],
                        },
                    }
                ],
            },
            {
                "name": "Product",
                "columns": [
                    {"name": "ProductKey", "dataType": "int64", "isKey": True},
                    {"name": "ProductName", "dataType": "string"},
                ],
                "partitions": [
                    {
                        "name": "Product-Partition",
                        "mode": "directQuery",
                        "source": {
                            "type": "entityPartitionSource",
                            "entityName": "dim_product",
                            "schemaName": "dbo",
                            "expressionSource": "DatabaseQuery",
                        },
                    }
                ],
            },
            {"name": "LocalDateTable_abc123", "columns": [{"name": "Date", "dataType": "dateTime"}]},
        ],
        "relationships": [
            {
                "name": "rel1",
                "fromTable": "Sales",
                "fromColumn": "ProductKey",
                "toTable": "Product",
                "toColumn": "ProductKey",
                "fromCardinality": "many",
                "toCardinality": "one",
                "crossFilteringBehavior": "OneDirection",
                "isActive": True,
            }
        ],
        "roles": [
            {
                "name": "Regional Manager",
                "modelPermission": "read",
                "tablePermissions": [
                    {"name": "Sales", "filterExpression": "Sales[Region] = \"West\""}
                ],
            }
        ],
        "expressions": [
            {"name": "DatabaseQuery", "kind": "m", "expression": "let\n  Source = 1\nin\n  Source"}
        ],
    },
}


class TestParseBimDict:
    def test_model_level_fields(self):
        model = parse_bim_dict(SAMPLE)
        assert model.name == "Sales Model"
        assert model.culture == "en-US"
        assert model.annotations["PBI_QueryOrder"] == '["Sales"]'

    def test_columns(self):
        model = parse_bim_dict(SAMPLE)
        sales = model.table("Sales")
        assert sales is not None
        order_date = sales.column("OrderDate")
        assert order_date.data_type == DataType.DATETIME
        assert order_date.summarize_by == SummarizeBy.NONE
        assert order_date.lineage_tag == "col-date"
        amount = sales.column("Amount")
        assert amount.summarize_by == SummarizeBy.SUM
        assert not amount.is_calculated

    def test_calculated_column_joins_multiline_expression(self):
        model = parse_bim_dict(SAMPLE)
        col = model.table("Sales").column("Margin Pct")
        assert col.is_calculated
        assert col.expression == "DIVIDE(\n  [Amount] - [Cost],\n  [Amount]\n)"
        assert col.is_hidden

    def test_measures(self):
        model = parse_bim_dict(SAMPLE)
        measure = model.table("Sales").measure("Total Sales")
        assert measure.expression == "SUM(Sales[Amount])"
        assert measure.format_string == "$#,0"
        assert measure.display_folder == "Core"

    def test_hierarchy_levels_sorted_by_ordinal(self):
        model = parse_bim_dict(SAMPLE)
        h = model.table("Sales").hierarchies[0]
        assert [lvl.name for lvl in h.levels] == ["Year", "Month"]

    def test_m_partition_joins_multiline_expression(self):
        model = parse_bim_dict(SAMPLE)
        part = model.table("Sales").partitions[0]
        assert part.mode == PartitionMode.IMPORT
        assert part.source_type == "m"
        assert "Fabric.Lakehouse()" in part.expression

    def test_direct_lake_entity_partition_has_no_m_expression(self):
        model = parse_bim_dict(SAMPLE)
        part = model.table("Product").partitions[0]
        assert part.mode == PartitionMode.DIRECT_QUERY
        assert part.source_type == "directlake"
        assert part.expression == ""

    def test_auto_date_table_flagged(self):
        model = parse_bim_dict(SAMPLE)
        assert model.table("LocalDateTable_abc123").is_auto_date_table

    def test_relationship_cross_filter_normalized(self):
        model = parse_bim_dict(SAMPLE)
        rel = model.relationships[0]
        assert rel.from_table == "Sales"
        assert rel.to_table == "Product"
        assert rel.cross_filtering_behavior == "singleDirection"
        assert rel.is_active

    def test_role_table_permission(self):
        model = parse_bim_dict(SAMPLE)
        role = model.roles[0]
        assert role.name == "Regional Manager"
        assert role.table_permissions["Sales"] == 'Sales[Region] = "West"'

    def test_shared_expression(self):
        model = parse_bim_dict(SAMPLE)
        assert "Source = 1" in model.expressions["DatabaseQuery"]

    def test_missing_model_key_raises(self):
        with pytest.raises(BimParseError):
            parse_bim_dict({"name": "x"})


class TestParseBimFile:
    def test_reads_and_parses(self, tmp_path):
        p = tmp_path / "model.bim"
        p.write_text(json.dumps(SAMPLE), encoding="utf-8")
        model = parse_bim_file(p)
        assert model.name == "Sales Model"

    def test_missing_file_raises(self, tmp_path):
        with pytest.raises(BimParseError):
            parse_bim_file(tmp_path / "nope.bim")

    def test_invalid_json_raises(self, tmp_path):
        p = tmp_path / "model.bim"
        p.write_text("{not json", encoding="utf-8")
        with pytest.raises(BimParseError):
            parse_bim_file(p)


class TestLoadPbipWithBim:
    """End-to-end: a .pbip whose semantic model was Saved-As with the legacy
    TMSL toggle (model.bim instead of a TMDL definition/ folder) should load
    through the same load_pbip() entry point as a TMDL-based project."""

    def _build_project(self, tmp_path):
        root = tmp_path / "proj"
        report_dir = root / "Contoso.Report"
        model_dir = root / "Contoso.SemanticModel"
        (report_dir / "definition").mkdir(parents=True)
        (report_dir / "definition.pbir").write_text(
            json.dumps({"datasetReference": {"byPath": {"path": "../Contoso.SemanticModel"}}}),
            encoding="utf-8",
        )
        model_dir.mkdir(parents=True)
        (model_dir / "model.bim").write_text(json.dumps(SAMPLE), encoding="utf-8")
        (root / "Contoso.pbip").write_text(
            json.dumps(
                {
                    "version": "1.0",
                    "artifacts": [{"report": {"path": "Contoso.Report"}}],
                }
            ),
            encoding="utf-8",
        )
        return root

    def test_load_pbip_routes_to_bim_parser(self, tmp_path):
        from app.parsers.bundle import load_pbip

        root = self._build_project(tmp_path)
        bundle = load_pbip(root)
        assert bundle.model.name == "Sales Model"
        assert bundle.model.table("Product") is not None
