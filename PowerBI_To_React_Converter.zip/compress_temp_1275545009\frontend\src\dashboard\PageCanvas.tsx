import { useLayoutEffect, useMemo, useRef, useState } from 'react'
import { DataPointContext, type DataPoint } from './dataPoint'
import {
  alignButtonRows,
  canvasScale,
  CanvasScaleContext,
  emptyResult,
  groupNotices,
  hasData,
  isEffectivelyHidden,
  noDataLabel,
  placeNotices,
  resolveFit,
  titleFromResult,
  unavailableReason,
  zRanks,
  type FitMode,
  type VisibilityOverrides,
} from './canvas'
import { isVisualActive, toggleSelection, type VisualInteractionState } from './interactions'
import { fontCss } from './pbi/fonts'
import { withAlpha } from './pbi/literal'
import { CHROME_TYPES, pageBackground, resolveVisual, usePbiTheme } from './pbi/resolve'
import type { FilterClause, InteractionState, PageSpec, VisualResult, VisualSpec } from './types'
import { BulletChart } from './visuals/BulletChart'
import { CardVisual } from './visuals/CardVisual'
import { ChartVisual } from './visuals/ChartVisual'
import { ButtonVisual, ImageVisual, ShapeVisual } from './visuals/ChromeVisuals'
import { ComboVisual } from './visuals/ComboVisual'
import { DecompositionTree } from './visuals/DecompositionTree'
import { GaugeVisual } from './visuals/GaugeVisual'
import { HeatmapMatrix } from './visuals/HeatmapMatrix'
import { MatrixDrillScope } from './MatrixDrillScope'
import { KpiCardVisual } from './visuals/KpiCardVisual'
import { MapVisual } from './visuals/MapVisual'
import { NavigatorVisual } from './visuals/NavigatorVisual'
import { ScatterVisual } from './visuals/ScatterVisual'
import { SlicerVisual } from './visuals/SlicerVisual'
import { TableVisual } from './visuals/TableVisual'
import { TextboxVisual } from './visuals/TextboxVisual'

export {
  alignButtonRows,
  applySlicerChange,
  withSlicerDefaults,
  canvasScale,
  emptyResult,
  groupNotices,
  isEffectivelyHidden,
  noDataLabel,
  placeNotices,
  queryVisualNames,
  titleFromResult,
  unavailableReason,
} from './canvas'

const CHART_TYPES = new Set([
  'donutChart',
  'pieChart',
  'barChart',
  'clusteredBarChart',
  'columnChart',
  'clusteredColumnChart',
  'hundredPercentStackedBarChart',
  'hundredPercentStackedColumnChart',
  'lineChart',
  'areaChart',
  'waterfallChart',
])

type Values = (string | number)[]

function VisualBody({
  spec,
  data,
  titleText,
  slicerState,
  interactionState,
  onSlicerChange,
  onSelect,
  onAction,
  actionDisabled,
  textOffsetPx,
  pageName,
  filters,
}: {
  spec: VisualSpec
  data?: VisualResult
  pageName: string
  filters: FilterClause[]
  titleText?: string
  slicerState: Record<string, Values>
  interactionState: InteractionState
  onSlicerChange: (spec: VisualSpec, values: Values) => void
  onSelect: (spec: VisualSpec, values: Values) => void
  onAction?: (spec: VisualSpec) => void
  actionDisabled: boolean
  textOffsetPx: number
}) {
  const type = spec.visual_type
  if (type === 'visualGroup') return null
  if (type === 'actionButton')
    return (
      <ButtonVisual
        spec={spec}
        text={titleText}
        disabled={actionDisabled}
        textOffsetPx={textOffsetPx}
        onClick={spec.action && onAction ? () => onAction(spec) : undefined}
      />
    )
  if (type === 'shape' || type === 'basicShape') return <ShapeVisual spec={spec} />
  if (type === 'image') return <ImageVisual spec={spec} />
  if (type === 'bookmarkNavigator' || type === 'pageNavigator') return <NavigatorVisual spec={spec} />
  if (type === 'textbox') return <TextboxVisual spec={spec} />
  // untranslated / unsupported-type panes keep their chrome and renderer over an empty result
  const result = data ?? (hasData(spec) ? emptyResult(spec) : undefined)
  if (!spec.supported && !spec.pbir)
    return (
      <div className="flex h-full items-center justify-center p-2 text-center">
        <span className="rounded bg-amber-50 px-2 py-1 text-[10px] text-amber-700">
          Unsupported: {spec.unsupported_reason}
        </span>
      </div>
    )
  if (spec.data_status === 'unsupported_type') return <div className="h-full w-full" />
  if (type === 'kpiCard') return <KpiCardVisual spec={spec} data={result} />
  if (type === 'card') return <CardVisual spec={spec} data={result} />
  if (type === 'slicer')
    return (
      <SlicerVisual
        spec={spec}
        data={result}
        selected={slicerState[spec.name] ?? []}
        onChange={(values) => onSlicerChange(spec, values)}
      />
    )
  if (type === 'pivotTable' || type === 'tableEx') {
    const table = <TableVisual spec={spec} data={result} onSelect={(values) => onSelect(spec, values)} />
    return spec.hierarchy?.expand_rows ? (
      <MatrixDrillScope page={pageName} visual={spec.name} filters={filters}>
        {table}
      </MatrixDrillScope>
    ) : (
      table
    )
  }
  if (type === 'scatterChart')
    return <ScatterVisual spec={spec} data={result} onSelect={(values) => onSelect(spec, values)} />
  if (type === 'lineClusteredColumnComboChart') return <ComboVisual spec={spec} data={result} />
  if (type === 'gauge') return <GaugeVisual spec={spec} data={result} />
  if (type === 'bulletChart') return <BulletChart spec={spec} data={result} />
  if (type === 'heatmapMatrix')
    return <HeatmapMatrix spec={spec} data={result} onSelect={(values) => onSelect(spec, values)} />
  if (type === 'filledMap')
    return (
      <MapVisual
        spec={spec}
        data={result}
        selected={interactionState.selections[spec.name] ?? []}
        onSelect={(values) => onSelect(spec, values)}
      />
    )
  if (type === 'decompositionTreeVisual')
    return <DecompositionTree spec={spec} data={result} onSelect={(values) => onSelect(spec, values)} />
  if (CHART_TYPES.has(type))
    return <ChartVisual spec={spec} data={result} onSelect={(values) => onSelect(spec, values)} />
  return <div className="p-2 text-xs text-surface-400">{type}</div>
}

/** The nearest ancestor that scrolls (or the parent): its width is what the page fits to. */
function scrollParent(el: HTMLElement): HTMLElement {
  let node: HTMLElement | null = el.parentElement
  while (node) {
    const overflow = getComputedStyle(node).overflowX
    if (overflow === 'auto' || overflow === 'scroll') return node
    node = node.parentElement
  }
  return el.parentElement ?? el
}

export function PageCanvas({
  page,
  results,
  slicerState,
  onSlicerChange,
  interactionState,
  onInteractionChange,
  visualInteractions,
  annotations = true,
  fit = 'auto',
  verticalAlignment = 'Top',
  overrides = {},
  onAction,
  actionDisabled,
  filtersByVisual,
  onDrillMenu,
  onTooltip,
}: {
  page: PageSpec
  results: Record<string, VisualResult>
  slicerState: Record<string, Values>
  onSlicerChange: (spec: VisualSpec, values: Values) => void
  interactionState?: InteractionState
  onInteractionChange?: (next: InteractionState) => void
  visualInteractions?: Record<string, VisualInteractionState>
  /** false during pixel-true capture: hides Studio-only badges (≈ / fallback) */
  annotations?: boolean
  fit?: FitMode | 'auto'
  verticalAlignment?: string
  /** bookmark visibility overrides */
  overrides?: VisibilityOverrides
  onAction?: (spec: VisualSpec) => void
  actionDisabled?: (spec: VisualSpec) => boolean
  /** the slicer / cross filters in force per visual (used by matrix drill rows) */
  filtersByVisual?: Record<string, FilterClause[]>
  /** right-click on a data point; returns true when a menu opened (the browser menu is then
   * suppressed) */
  onDrillMenu?: (visual: VisualSpec, point: DataPoint, at: { x: number; y: number }) => boolean
  /** hover: the data point under the pointer, null when it leaves */
  onTooltip?: (visual: VisualSpec, point: DataPoint | null, at: { x: number; y: number }) => void
}) {
  const pointRef = useRef<Record<string, DataPoint | null>>({})
  const mouse = useRef({ x: 0, y: 0 })
  const outer = useRef<HTMLDivElement>(null)
  const [box, setBox] = useState({ w: 0, h: 0 })
  const theme = usePbiTheme()
  const currentInteraction = interactionState ?? { selections: {}, hoveredVisual: null, activeBookmark: null }
  const pbi = page.visuals.some((v) => v.pbir)
  const mode = resolveFit(fit, page.display_option)

  const emitSelect = (spec: VisualSpec, values: Values) => {
    if (!onInteractionChange) return
    onInteractionChange(toggleSelection(currentInteraction, spec, values))
  }

  useLayoutEffect(() => {
    const el = outer.current
    if (!el) return
    const parent = scrollParent(el)
    const measure = () => setBox({ w: parent.clientWidth || el.clientWidth, h: parent.clientHeight })
    measure()
    // observe the scrolling ancestor, not the canvas (the canvas' own size depends on the scale)
    const ro = new ResizeObserver(measure)
    ro.observe(parent)
    return () => ro.disconnect()
  }, [page.name])

  const scale = box.w > 0 ? canvasScale(mode, box.w, mode === 'FitToPage' ? box.h : 0, page.width, page.height) : 1
  const byName = useMemo(() => new Map(page.visuals.map((v) => [v.name, v])), [page.visuals])
  const ranks = useMemo(() => zRanks(page.visuals), [page.visuals])
  const buttonOffsets = useMemo(() => alignButtonRows(page.visuals), [page.visuals])
  const visible = page.visuals.filter((v) => !isEffectivelyHidden(v, overrides, byName))
  const notices = useMemo(
    () => placeNotices(groupNotices(visible, results)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [page.visuals, results, overrides],
  )
  const background = pbi ? pageBackground(page, theme) : undefined
  const scaledHeight = page.height * scale
  const offsetY =
    verticalAlignment === 'Middle' && box.h > scaledHeight && mode !== 'FitToWidth'
      ? (box.h - scaledHeight) / 2
      : 0

  return (
    <CanvasScaleContext.Provider value={scale}>
      <div ref={outer} className="w-full" style={{ overflow: 'hidden' }}>
        <div
          data-testid="page-canvas"
          data-scale={scale.toFixed(4)}
          className={`relative origin-top-left ${pbi ? '' : 'bg-[#0d1a3a]/[.03]'}`}
          style={{
            width: page.width,
            height: page.height,
            transform: `scale(${scale})`,
            marginBottom: page.height * (scale - 1),
            marginTop: offsetY,
            background,
          }}
        >
          {[...visible]
            .sort((a, b) => a.z - b.z)
            .map((v) => {
              const view = visualInteractions?.[v.name]
              const isActive = view?.active ?? isVisualActive(v, currentInteraction)
              const isFiltered = view?.filtered ?? false
              const isHighlighted = view?.highlighted ?? false
              const result = results[v.name]
              const isChrome = CHROME_TYPES.has(v.visual_type)
              const disabled = actionDisabled?.(v) ?? false
              const groupLike = v.visual_type === 'visualGroup'
              const style = v.pbir ? resolveVisual(v, theme) : null
              const titleText = style
                ? (titleFromResult(results[`${v.name}#title`]) ??
                  (v.visual_type === 'actionButton' ? undefined : style.title.text) ??
                  v.title ??
                  undefined)
                : (v.title ?? undefined)
              const showTitle = style
                ? style.title.show && !!titleText && !isChrome
                : !!v.title && v.visual_type !== 'card' && v.visual_type !== 'slicer'
              const buttonText =
                v.visual_type === 'actionButton' ? titleFromResult(results[`${v.name}#title`]) : undefined

              // legacy container styling (visuals without PBIR)
              const bg = v.options?.container_background as { color?: string; transparency?: number } | undefined
              const border = v.options?.container_border as { show?: boolean; color?: string; radius?: number } | undefined
              const containerStyle: React.CSSProperties = {
                left: v.x,
                top: v.y,
                width: v.width,
                height: v.height,
                zIndex: ranks.get(v.name) ?? 1,
                pointerEvents: groupLike || (disabled && !!v.action) ? 'none' : undefined,
              }
              if (style) {
                if (style.container.showBackground)
                  containerStyle.background =
                    style.container.alpha >= 1
                      ? style.container.background
                      : withAlpha(style.container.background, style.container.alpha)
                if (style.container.border.show) {
                  containerStyle.border = `${style.container.border.width}px solid ${style.container.border.color}`
                  containerStyle.borderRadius = style.container.border.radius
                }
                containerStyle.padding = isChrome
                  ? 0
                  : `${style.container.padding.top}px ${style.container.padding.right}px ${style.container.padding.bottom}px ${style.container.padding.left}px`
                containerStyle.boxSizing = 'border-box'
              } else {
                if (bg?.color) {
                  const alpha = 1 - (bg.transparency ?? 0) / 100
                  containerStyle.backgroundColor = alpha >= 1 ? bg.color : withAlpha(bg.color, alpha)
                }
                if (border?.color) containerStyle.borderColor = border.color
                if (border?.radius !== undefined) containerStyle.borderRadius = border.radius
                if (border?.show === false) containerStyle.border = 'none'
              }
              const clickable = !!v.action && !disabled && v.visual_type !== 'actionButton'
              const notice = !isChrome ? unavailableReason(v, result) : null
              return (
                <div
                  key={v.name}
                  data-testid={`visual-${v.name}`}
                  data-visual-type={v.visual_type}
                  className={
                    style || v.visual_type === 'textbox'
                      ? 'absolute'
                      : `absolute rounded-md border bg-white shadow-sm transition ${
                          isActive
                            ? 'border-brand ring-2 ring-brand/30'
                            : isFiltered
                              ? 'border-sky-400 ring-1 ring-sky-300/70'
                              : isHighlighted
                                ? 'border-brand-blue/50 ring-1 ring-brand-blue/20'
                                : 'border-surface-300'
                        }`
                  }
                  style={{ ...containerStyle, cursor: clickable ? 'pointer' : undefined }}
                  onClick={clickable ? () => onAction?.(v) : undefined}
                  onMouseMove={(e) => {
                    mouse.current = { x: e.clientX, y: e.clientY }
                  }}
                  onMouseEnter={() => {
                    // visuals without categories use the whole container as the data point
                    if (!v.dim_keys.length && !isChrome) onTooltip?.(v, {}, mouse.current)
                  }}
                  onMouseLeave={() => {
                    pointRef.current[v.name] = null
                    onTooltip?.(v, null, mouse.current)
                  }}
                  onContextMenu={(e) => {
                    if (!onDrillMenu || isChrome) return
                    const point = v.dim_keys.length ? pointRef.current[v.name] : {}
                    if (!point) return
                    if (onDrillMenu(v, point, { x: e.clientX, y: e.clientY })) e.preventDefault()
                  }}
                >
                  {showTitle && (
                    <div
                      data-testid={`title-${v.name}`}
                      className="flex items-center gap-1 truncate"
                      style={
                        style
                          ? {
                              ...fontCss(style.title.font),
                              color: style.title.color,
                              textAlign: style.title.align,
                              background: style.title.background,
                              justifyContent:
                                style.title.align === 'center' ? 'center' : style.title.align === 'right' ? 'flex-end' : 'flex-start',
                            }
                          : { fontSize: 11, fontWeight: 600, padding: '4px 8px 0' }
                      }
                    >
                      <span className="truncate">{titleText}</span>
                      {annotations && v.substituted_as && (
                        <span
                          title={`Rendered as ${v.substituted_as} (nearest equivalent)`}
                          className="shrink-0 rounded bg-brand-blue/10 px-1 text-[8px] font-normal text-brand-blue"
                        >
                          ≈ {v.substituted_as}
                        </span>
                      )}
                      {annotations && result?.execution_path === 'compatibility' && (
                        <span
                          title={result?.fallback_reason ?? 'compatibility fallback'}
                          className="shrink-0 rounded bg-amber-50 px-1 text-[8px] font-normal text-amber-700"
                        >
                          fallback
                        </span>
                      )}
                    </div>
                  )}
                  <div
                    style={{
                      height: showTitle
                        ? `calc(100% - ${style ? Math.ceil(style.title.font.sizePx * 1.4) : 20}px)`
                        : '100%',
                    }}
                  >
                    <DataPointContext.Provider
                      value={(p) => {
                        pointRef.current[v.name] = p
                        onTooltip?.(v, p, mouse.current)
                      }}
                    >
                    <VisualBody
                      spec={v}
                      data={result}
                      titleText={buttonText}
                      slicerState={slicerState}
                      interactionState={currentInteraction}
                      onSlicerChange={onSlicerChange}
                      onSelect={emitSelect}
                      onAction={onAction}
                      actionDisabled={disabled}
                      textOffsetPx={buttonOffsets[v.name] ?? 0}
                      pageName={page.name}
                      filters={filtersByVisual?.[v.name] ?? []}
                    />
                    </DataPointContext.Provider>
                  </div>
                  {notice && annotations && (
                    <span
                      data-testid={`inline-notice-${v.name}`}
                      className="absolute right-1 bottom-1 rounded bg-amber-50 px-1 text-[9px] text-amber-700"
                    >
                      {noDataLabel(v, result)}
                    </span>
                  )}
                </div>
              )
            })}
          {/* one info symbol per stack of overlapping visuals without data, in its own top layer */}
          <div data-testid="notice-layer" className="pointer-events-none absolute inset-0" style={{ zIndex: page.visuals.length + 1 }}>
            {notices.map((n) => (
              <span
                key={n.visuals.join('|')}
                data-testid="data-notice"
                title={n.reason}
                aria-label={n.reason}
                className="pointer-events-auto absolute flex items-center gap-1 rounded-full bg-white/90 px-1 text-[10px] text-surface-600 shadow-sm"
                style={{ left: n.x, top: n.y, width: n.width, height: 18, overflow: 'hidden' }}
              >
                <span aria-hidden>ⓘ</span>
                {!n.compact && <span className="truncate">{n.reason}</span>}
              </span>
            ))}
          </div>
        </div>
      </div>
    </CanvasScaleContext.Provider>
  )
}

export function slicersToFilters(page: PageSpec, slicerState: Record<string, Values>): FilterClause[] {
  const filters: FilterClause[] = []
  for (const v of page.visuals) {
    const sel = slicerState[v.name]
    if (!sel || !sel.length) continue
    if (v.visual_type === 'slicer' && v.slicer_target) {
      filters.push({
        table: v.slicer_target.table,
        column: v.slicer_target.column,
        values: sel,
        source: 'slicer',
        params: { slicer: v.name },
      })
    } else if (v.visual_type === 'filledMap' && v.dim_keys.length) {
      // map state click cross-filters on its category dimension (PBI parity)
      const [table, column] = v.dim_keys[0].split('.')
      filters.push({ table, column, values: sel, source: 'cross_filter' })
    }
  }
  return filters
}
