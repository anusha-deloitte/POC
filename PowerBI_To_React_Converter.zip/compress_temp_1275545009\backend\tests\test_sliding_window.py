"""DATESBETWEEN windows whose bounds read the query's filter context (phase 06.5)."""

from __future__ import annotations

from datetime import date

import pytest

from app.dax.compiler import DaxUnsupported
from app.runtime.engine import DimensionRef, FilterClause, MeasureRefSpec, QueryPlanError, QuerySpec
from tests.duck import DuckWorld

ROLL = (
    "VAR _end = MAX(D[Dt]) VAR _start = EDATE(_end, -2) "
    "RETURN CALCULATE(SUM(F[Amt]), ALL(D), DATESBETWEEN(D[Dt], _start, _end))"
)


def months(year: int, upto: int = 12):
    return [date(year, m, 1) for m in range(1, upto + 1)]


def world(extra: dict[str, str] | None = None) -> DuckWorld:
    d_rows = [(d,) for d in months(2023)] + [(d,) for d in months(2024, 6)]
    f_rows = []
    for m in range(1, 13):
        f_rows += [(date(2023, m, 1), 1, 1000.0 * m), (date(2023, m, 1), 2, 1.0)]
    for m in range(1, 7):
        f_rows += [(date(2024, m, 1), 1, float(2 ** (m - 1))), (date(2024, m, 1), 2, 100.0)]
    return DuckWorld(
        {
            "D": (["Dt"], d_rows),
            "Cat": (["Id", "Label"], [(1, "c1"), (2, "c2")]),
            "F": (["Dt", "CatId", "Amt"], f_rows),
        },
        rels=[("F", "Dt", "D", "Dt"), ("F", "CatId", "Cat", "Id")],
        measures={
            "Roll3": ROLL,
            "Roll3 PY": "CALCULATE([Roll3], SAMEPERIODLASTYEAR(D[Dt]))",
            **(extra or {}),
        },
        measure_table="F",
    )


def pick(*days: date) -> list[FilterClause]:
    return [FilterClause(table="D", column="Dt", op="in", values=[d.isoformat() for d in days])]


def test_card_window_reads_the_slicer():
    w = world()
    # slicer on June 2024 -> April..June 2024 = 8 + 16 + 32 per category + 100 * 3 for c2
    assert w.value("Roll3", filters=pick(date(2024, 6, 1))) == (8 + 16 + 32) + 300.0
    # several months selected: MAX is the latest one (April) -> Feb..Apr
    assert w.value("Roll3", filters=pick(date(2024, 3, 1), date(2024, 4, 1))) == (2 + 4 + 8) + 300.0


def test_card_without_filters_uses_the_latest_date():
    w = world()
    assert w.value("Roll3") == (8 + 16 + 32) + 300.0


def test_no_single_period_selected_is_blank_with_selectedvalue():
    w = world(
        {
            "Sel": "VAR _end = SELECTEDVALUE(D[Dt]) VAR _start = EDATE(_end, -2) "
            "RETURN CALCULATE(SUM(F[Amt]), ALL(D), DATESBETWEEN(D[Dt], _start, _end))"
        }
    )
    assert w.value("Sel", filters=pick(date(2024, 6, 1))) == (8 + 16 + 32) + 300.0
    assert w.value("Sel", filters=pick(date(2024, 5, 1), date(2024, 6, 1))) is None


def test_window_grouped_by_another_table():
    w = world()
    rows = w.run(
        QuerySpec(
            dimensions=[DimensionRef(table="Cat", column="Label")],
            measures=[MeasureRefSpec(name="Roll3")],
            filters=pick(date(2024, 6, 1)),
        )
    )
    assert rows == [("c1", 56.0), ("c2", 300.0)]


def test_rows_of_a_grouped_visual_are_filtered():
    w = world()
    rows = w.run(
        QuerySpec(
            dimensions=[DimensionRef(table="Cat", column="Label")],
            measures=[MeasureRefSpec(name="Roll3")],
            filters=[
                *pick(date(2024, 6, 1)),
                FilterClause(table="Cat", column="Label", values=["c2"]),
            ],
        )
    )
    assert rows == [("c2", 300.0)]


def test_py_window_reads_the_shifted_dates():
    w = world()
    # June 2024 selected -> bounds read June 2023 -> April..June 2023 for both categories
    expected = (4000 + 5000 + 6000) + 3.0
    assert w.value("Roll3 PY", filters=pick(date(2024, 6, 1))) == expected


def test_date_table_on_the_axis_is_refused():
    w = world()
    with pytest.raises(QueryPlanError, match="rows/axis"):
        w.run(
            QuerySpec(
                dimensions=[DimensionRef(table="D", column="Dt")],
                measures=[MeasureRefSpec(name="Roll3")],
            )
        )


def test_window_without_all_is_refused():
    w = world(
        {
            "NoAll": "VAR _end = MAX(D[Dt]) "
            "RETURN CALCULATE(SUM(F[Amt]), DATESBETWEEN(D[Dt], EDATE(_end, -2), _end))"
        }
    )
    with pytest.raises((DaxUnsupported, QueryPlanError), match=r"ALL\(D\)"):
        w.value("NoAll")


def test_date_table_cross_filtered_by_another_table_is_refused():
    w = DuckWorld(
        {
            "D": (["Dt", "Fy"], [(date(2024, 1, 1), 1), (date(2024, 2, 1), 1)]),
            "Fy": (["Fy", "Name"], [(1, "x")]),
            "F": (["Dt", "Amt"], [(date(2024, 1, 1), 1.0), (date(2024, 2, 1), 2.0)]),
        },
        rels=[("F", "Dt", "D", "Dt"), ("D", "Fy", "Fy", "Fy")],
        measures={"Roll": ROLL},
        measure_table="F",
    )
    with pytest.raises(QueryPlanError, match="cross-filtered by Fy"):
        w.value("Roll", filters=[FilterClause(table="Fy", column="Name", values=["x"])])


def test_window_inside_calculate_all_of_another_table():
    w = world({"AllCat": "CALCULATE([Roll3], ALL(Cat))"})
    assert w.value("AllCat", filters=pick(date(2024, 6, 1))) == (8 + 16 + 32) + 300.0


def test_nested_window_inner_bounds_see_the_outer_window():
    outer = (
        "CALCULATE([Roll3], ALL(D), DATESBETWEEN(D[Dt], DATE(2024, 2, 1), DATE(2024, 4, 1)))"
    )
    w = world({"Outer": outer})
    # inner bounds read D inside the outer window: end = April, start = February
    assert w.value("Outer", filters=pick(date(2024, 6, 1))) == (2 + 4 + 8) + 300.0


def test_startofyear_bound():
    w = world(
        {
            "YtdWin": "VAR _end = MAX(D[Dt]) VAR _start = STARTOFYEAR(D[Dt]) "
            "RETURN CALCULATE(SUM(F[Amt]), ALL(D), DATESBETWEEN(D[Dt], _start, _end))"
        }
    )
    got = w.value("YtdWin", filters=pick(date(2024, 3, 1)))
    assert got == (1 + 2 + 4) + 300.0


def test_blank_arithmetic_around_a_window():
    w = world(
        {
            "OneMinus": "1 - BLANK()",
            "OneMinusValue": "1 - [Roll3]",
        }
    )
    assert w.value("OneMinus") == 1
    assert w.value("OneMinusValue", filters=pick(date(2024, 6, 1))) == 1 - 356.0
