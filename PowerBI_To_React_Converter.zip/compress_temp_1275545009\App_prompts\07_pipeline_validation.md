# Phase 07 - Conversion pipeline and validation

## Purpose
Make Convert robust and transparent: case check + pre-flight before validation, a safe AI repair order
(rewrite into tier-1 DAX before whole-model SQL), dependency-aware tier-2, a slicer value check, a
per-measure compilation audit log, faster validation, and data-visual scores that static visuals can't hide.

## Current target state
`agents/pipeline.py::run_conversion` (bind -> compile -> validate -> repair rounds with OpenAI tier-2 for every
parked measure -> probes -> persist `conversion_run.json`). `validation/harness.py` validates each visual
sequentially. No compilation log.

## Required behaviour

### 1. ConversionRun / persistence
Add `preflight: dict | None` (PreflightReport.summary()) and `llm_provider: str | None` (phase 03) and persist both in
`conversion_run.json`. `prior = _load_existing_run(root)` is read at the start (also for non-resume runs).
`_save_bundle(bundle, root)` rewrites `bundle.json` when it exists (every later compile reads it).

### 2. Run order (`run_conversion(..., ai_scope="visuals", llm_provider=None)`)
1. `_drop_other_provider_ai` + the Horizon-credentials notice (phase 03).
2. `binding_map = build_bundle_binding_map(bundle)` (+ "Snowflake target overridden" event when an override is set; phase 05).
   Migration (existing) also rebuilds with `build_bundle_binding_map`.
3. Compilation audit: `compilation_log = CompilationLogger(root); compilation_log.initialize_for_conversion(id)`; compile
   through `_compile_with_overrides(..., compilation_log=...)` -> `compile_dashboard(..., compilation_log=...)`;
   attach `compilation_audit = compilation_log.summary()` to the compile event; the engine gets `logger=compilation_log`.
4. On the validation cursor, before validating:
   - case check (`audit_stage(cursor, "setup", "identifier_case_check")`, `_apply_identifier_case`): emit
     `case_summary_message`; when changed, save the bundle and rebuild bindings + engine (the compiled spec doesn't depend
     on physical names);
   - pre-flight (`audit_stage(cursor, "setup", "access_preflight")`): `run.preflight = summary()`, emit event `preflight`
     with message/role/warehouse/targets, persist the run;
   - slicer value check (section 5).
5. `query_results: dict = {}` shared by validation, every repair round and the probes (`CachingCursor`).
6. Validation: `run_validation(spec, engine, cursor, bundle=bundle, result_cache=query_results,
   manual_sql=_manual_sql(run, spec, engine, root))` (section 7).
7. Repair loop (section 3).
8. `_backfill_audit_sql(run, compilation_log, engine)`: for translated measures (tier >= 0) no visual query exercised,
   build a standalone card query (`QuerySpec(measures=[name])`, `sql_context="audit_backfill:standalone_measure"`) so the
   audit has SQL for every translation (nothing executed; plan errors land on the record); emit "audit: generated
   standalone SQL for N measures not used by any converted visual".
9. Probes inside `audit_stage(cursor2, "probe")` with `CachingCursor(cursor2, query_results)`.

### 3. Repair loop (per round)
- `in_visuals = _visual_measures(bundle)` (measures a visual field projects); `rejected` (attempted and not accepted;
  never retried in the run) and `rewritten` sets.
- Undefined measures: `tier2.undefined_measures(model)` -> `{undefined name: [measures using it]}` ([X] that is neither a
  measure, nor a column of any table, nor a string literal the expression names; case-insensitive). Emit once: "the
  uploaded model references measures it does not define: [X] (used by [a], [b] and N more); ...".
- `ai_scope == "visuals"`: parked measures not used by a visual are listed once ("N untranslated measures are not used by
  any visual; they are left for review instead of AI translation") and not sent. `ai_scope="all"` sends them too.
- Candidates = parked, not accepted, not rejected, not rewritten, in scope.
- If an LLM client exists and the pre-flight is blocking: emit "skipping AI translation of N measures: no Snowflake table is
  reachable, so no proposal could be validated" and skip.
- Otherwise, for each candidate in dependency order (`_tier2_order`: dependencies before dependants, DFS over
  `dependency_closure`, sorted start):
  1. its closure references an undefined name -> rejected, event "[m]: not sent to AI — it references [X], which is not
     defined in the uploaded model";
  2. its closure reads a table the pre-flight found unreachable (`_unreachable_tables`: schema error, or listed but this
     exact name not found) -> rejected, "[m]: not sent to AI — it reads T, which the Snowflake session cannot reach (see pre-flight)";
  3. a dependency was rejected -> rejected, "[m]: skipped AI translation — depends on [d], which could not be translated";
  4. it now compiles in tier-1 (a dependency was rewritten) -> "[m]: now compiles in tier-1 (a dependency was rewritten)";
  5. AI DAX rewrite (`tier2.propose_dax_rewrite`, under `llm_call_context("ai_llm_rewrite:<m>")`, log to
     `tier2_llm.jsonl`) with the gate `_rewrite_gate` (section 4). Accepted -> store
     `DaxRewrite(expression, original=effective_dax, gates, created_at, provider=run.llm_provider)` in
     `model.dax_rewrites`, save the bundle, emit "[m]: AI rewrite accepted after N attempt(s) — compiled by tier-1; shown as
     'AI-rewritten DAX' in Review" (trace, gates, dax).
  6. Rejected and the closure uses filter-context functions (`tier2.CONTEXT_FUNCS`: SELECTEDVALUE, ISFILTERED,
     ISCROSSFILTERED, HASONEVALUE, HASONEFILTER, ISINSCOPE, ALLSELECTED, VALUES, FILTERS, DATESBETWEEN, DATESINPERIOD,
     DATESYTD/MTD/QTD, TOTALYTD/MTD/QTD, DATEADD, SAMEPERIODLASTYEAR, PARALLELPERIOD, PREVIOUSMONTH/YEAR/QUARTER,
     STARTOFYEAR/MONTH, ENDOFYEAR/MONTH, FIRSTDATE, LASTDATE, USERPRINCIPALNAME) -> rejected: "...not sent for a
     whole-model SQL value because it reads the filter context (F, G), which such a value would ignore".
  7. Else whole-model SQL (`propose_and_validate`, under `audit_stage(cursor, "ai_check", "ai_sql_check:<m>")` and
     `llm_call_context("ai_llm_sql:<m>")`) with `dependency_sql=_dependency_sql(...)`: accepted tier-2 SQL of
     dependencies, else their tier-1 SQL built as standalone card queries (`sql_context="tier2_dependency_context"`,
     cached per run). Not accepted -> rejected.
  - Any `LlmError` -> "[m]: AI translation unavailable — measure parked, needs assistance" (error[:300]); the run continues.
  - AI wording uses the client's `label` ("Cortex (model)") or "AI".
- After a round: recompile with the logger, rebuild the engine, re-validate with the shared cache and `_manual_sql(quiet=True)`;
  recompute `parked` from `spec.measure_tiers`. If the round is rejected (score regressed - existing rule), also revert
  that round's AI DAX rewrites, save, and emit "round N: reverted K AI DAX rewrites from the rejected round".

### 4. Rewrite gate and rewrite proposal (`agents/tier2.py`)
4.1 `_rewrite_gate(bundle, candidate_model, binding_map, measure, cursor, tier2_sql) -> int`: compile every visual whose
fields project the measure with `compile_visual` (production path) on the candidate model; queue its query and, when it has
dimensions, its totals query (no dims, no sort); stop after 12 visuals; if none, run the measure alone. Execute all inside
`audit_stage(cursor, "ai_check", "ai_rewrite_gate:<m>")`; raise on the first failure; return the count.
4.2 `propose_dax_rewrite(model, measure, tier1_error, execute_gate, client, log_path=None) -> RewriteResult
{measure, expression, accepted, attempts, trace, gates}`. System prompt (keep the rules):
"You rewrite one Power BI DAX measure into an equivalent DAX measure that uses only the tier-1 subset below, so a
deterministic compiler can translate it to SQL that follows slicers, filters and the visual's rows exactly as Power BI
does. Rules: Output ONLY {"dax": "<body>"}; same value in EVERY filter context; only listed tables/columns/measures (exact
names); may inline referenced measures or reference them; keep every filter, table and column the original uses; if no
exact rewrite exists return {"error": "reason"}." followed by a description of the tier-1 subset (the constructs of phase 06
6.4-6.5 as supported, TOPN/GROUPBY/CURRENTGROUP/RANKX/CALCULATETABLE-with-filters/CONCATENATEX/GENERATE/PATH/`/`-inside-IFERROR
as not supported - keep this list in sync with what your compiler supports).
User context: measure + table + effective DAX, "Tier-1 compiler error for it: ...", referenced measures' DAX (closure, max 25,
20,000 chars), tables of the reference closure and their relationship neighbours with columns, relationships with flags.
Gates, in order, each failure retried with a corrective message (max 3 attempts, every attempt logged with mode
`dax_rewrite`): parses; references only model objects (`_unknown_objects`); keeps every table and column the original reads
through its closure (`reference_closure`); tier-1 compiles it on a deep copy of the model with the rewrite; `execute_gate`
succeeds. `gates` lists: "parses; references only model objects", "keeps all C columns / T tables the original reads",
"compiles in tier-1 (follows slicers and visual rows)", "executed for N visual and totals queries".
Also export `context_functions`, `reference_closure`, `dependency_closure` (nearest first, max 25), `measure_references`,
`undefined_measures`, `expected_result` (phase 03).

### 5. Slicer value check (`validation/value_check.py`, `pipeline._value_check`)
`value_assumptions(model)`: `(table, column) -> compared literals` for every IFERROR measure relying on VALUE of a slicer
selection (phase 06 6.8). `value_check_sql`: distinct non-blank values of T[c] that are neither numbers nor a compared
literal (case-insensitive). `run_value_check` -> `[{table, column, literals, offending, error}]`, inside
`audit_stage(cursor, "validation", "slicer_value_check")`. Events (stage `validate`, informational, never a failure):
error -> "could not check the values of T[c]: ..."; offending -> "T[c] has values that make VALUE() fail in Power BI
(neither numbers nor 'a', 'b'): 'x', 'y'. % Change (IFERROR) measures return their fallback (BLANK) for them, exactly like
Power BI. Measures using the same window without IFERROR show an error in Power BI for such a selection; the dashboard
shows a value"; else "T[c] holds only numbers and 'a', 'b': IFERROR measures using it translate exactly".

### 6. Compilation audit log (`services/compilation_logger.py`)
6.1 `DaxCompilationRecord` fields: model_table, measure_name, dax_expression, dax_complexity_score, compiler_type
(`tier0|tier1|tier2|parked|manual_sql`), compilation_status (`success|failed`), compilation_error,
compilation_duration_ms, dax_leaves, generated_sql, sql_samples (per-query context snapshots), sql_complexity, sql_error,
validation_attempted, validation_passed, validation_error, timestamp; `overall_status` = broken if failed, degraded if
validated and failed, else working; `to_dict()` adds overall_status.
6.2 Complexity: DAX `min(len/1000, 0.3) + 0.08 per occurrence of CALCULATE|SUMX|AVERAGEX|MINX|MAXX|FILTER|DATESINPERIOD +
min(unclosed paren depth/10, 0.2)`, capped at 1, rounded 3; SQL `min(len/3000,0.3) + min(JOIN/10,0.2) + min(GROUP BY/5,0.2)
+ min(CASE/5,0.15) + min(WITH/3,0.15)`.
6.3 `CompilationLogger(root)`: `initialize_for_conversion(id)` -> fresh `<root>/compilation_logs/<id>_compilation.jsonl`;
`start_record`, `finish_record(record, compiled, duration_ms)`, `fail_record(record, error, compiler_type, duration_ms)`
append `compilation_record` lines (via `append_jsonl`); `annotate_tier(measure, type)` (`compilation_tier_patch`; called by
`compile_dashboard` since only it knows a DaxUnsupported measure ended tier2 or parked); `annotate_sql(measure, sql, error,
context)` (`compilation_sql_patch`; called by the engine's `_annotate_sql` after each `build_sql` for every named measure);
`annotate_validation` (`compilation_validation_patch`); `summary()` -> `{total, working, degraded, broken,
percentage_working, by_compiler_type, avg_dax_complexity, avg_sql_complexity}`; `measures_without_sql()` (skip `__` names).
`MeasureCompiler(model, logger=None)` records every measure compilation.
6.4 `load_compilation_log(path) -> (records, summary)`: primary records with patches merged; `summarize_records`.
`build_audit_xlsx(records, summary, id)` (openpyxl; sheets Summary, Queries (measure -> DAX -> SQL), Measures) and
`build_audit_json(...)` (versioned document, same data).
6.5 `GET /api/v1/conversions/{id}/compilation-logs` -> `{logs, summary, sample_failures (first 10 broken)}`; 404 "no compilation
logs found; run the conversion first" when the file is missing. (DAX Audit endpoints and UI are phase 08.)

### 7. Validation (`validation/harness.py`)
7.1 `STATIC_VISUAL_TYPES = {actionButton, shape, basicShape, image, visualGroup, textbox, bookmarkNavigator, pageNavigator}`;
page/report summaries add `data_visuals_total`, `data_visuals_passed`, `data_score` (mean over non-static visuals, 1.0 if none).
7.2 `VisualScore.rechecked_at: float | None`, `VisualScore.sql_override: bool`.
7.3 `validate_visual(page, vs, main_sql=None)`: with `main_sql` on an untranslated pane, the `compile` check is SKIPPED
("<reason>; pane uses edited SQL") and the edited SQL runs instead (labelled with `remember_sql_context`); with `main_sql` a
`columns` check requires every key the renderer reads (`dim_keys, column_keys, series_keys, measure_keys`) - failure lists
the missing ones - and `totals` is SKIPPED ("edited SQL: grand-total reconciliation applies to generated SQL only").
Visual-level measure filters also skip totals ("visual-level measure filter: rows are a subset, no grand total to match").
7.4 Every `build_sql` passes a `sql_context`: `visual:<page>/<visual>:main|totals|slicer_domain`, `probe:<page>/<measure>:total|partition`.
7.5 `run_validation(..., result_cache=None, manual_sql=None)`: validate `with_default_filters(spec)` (phase 10 adds the
report/page default filters; until then make it the identity), prefetch, wrap the cursor in `CachingCursor`, pass the edited SQL
only for untranslated panes.
7.6 `_manual_sql(run, spec, engine, root, quiet=False)`: hand-edited SQL from `sql_overrides.json` (phase 08) for untranslated
panes, rendered with only the default report/page filters; render errors -> event "edited SQL of 'X' could not be rendered:
..."; emit "N untranslated pane(s) are validated with their edited SQL" (not when quiet).
7.7 Drift check (`validation/drift.py`): exact names, `quote_ident(database)`; case-only differences reported as "S.T: letter
case differs from Snowflake (S2.T2); quoted names are case-sensitive"; rename checks use `column_case`.

### 8. AI rewrites API and Review panel
- `GET /dashboard/dax-rewrites` -> `{rewrites: {measure: DaxRewrite}}` (sorted).
- `DELETE /dashboard/dax-rewrites/{measure}` -> `{reverted, remaining}`; 404 "no AI rewrite for measure 'X'"; saves the bundle and
  clears the result cache.
- `steps/AiRewrites.tsx` (Review step, `data-testid="ai-rewrites"`, renders nothing when there are no rewrites): heading
  "AI-rewritten DAX (N)"; text "These measures were rewritten by AI into DAX the deterministic compiler supports, so they follow
  slicers and the visual's rows. Each rewrite compiled and ran against Snowflake for every visual using it; equality with Power
  BI's numbers is not proven. Revert any you don't trust."; per measure: "[name]" + badge "AI-rewritten DAX", a "Revert" button
  (DELETE, then invalidate `['dax-rewrites', id]`), "Original" and "Rewrite" DAX side by side, the gates as a bullet list;
  revert errors in `role="alert"`.

## Files
Create: `backend/app/services/compilation_logger.py`, `backend/app/validation/value_check.py`, `frontend/src/steps/AiRewrites.tsx`.
Modify: `agents/pipeline.py`, `agents/tier2.py`, `validation/harness.py`, `validation/drift.py`, `runtime/dashboard.py`
(`compile_dashboard(..., compilation_log=None)`), `dax/compiler.py` (logger), `runtime/engine.py` (`_annotate_sql`),
`api/conversions.py`, `api/dashboards.py`, `steps/ReviewStep.tsx`.

## Tests
- `tests/test_ai_rewrite.py` (fake client + DuckDB/fake cursor): accepted rewrite stored with gates and provider, compiles at
  tier-1, survives recompile; rewrite dropping a column rejected; unknown object rejected; tier-1 failure retried; gate failure
  retried; context-function measures never sent to whole-model SQL; revert endpoint; provider switch drops AI rewrites;
  rejected round reverts its rewrites; undefined-measure and unreachable-table skips; dependency order.
- `tests/test_compilation_logger.py`: records, patches merged, summary numbers, complexity scores, xlsx/json builders,
  `measures_without_sql`, compilation-logs endpoint (404 before a run).
- harness: static visuals excluded from data_score; edited SQL `columns` check; totals skipped for edited SQL and measure
  filters; CachingCursor re-raises cached failures; prefetch parallel results identical.
- value check: events for offending / clean / error.
- frontend: AiRewrites lists and reverts.

## Done criteria
A Convert run on a fixture shows preflight + case events, AI order respected with a fake client, compilation log written;
all tests pass.
 