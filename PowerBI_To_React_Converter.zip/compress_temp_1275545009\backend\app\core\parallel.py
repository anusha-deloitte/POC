"""Bounded parallel execution of independent queries.

Only query execution is parallel (each query uses its own cursor of the same connection); the DAX
compiler is not thread-safe and always runs on the calling thread.
"""

from __future__ import annotations

import os
from collections.abc import Callable, Sequence
from concurrent.futures import ThreadPoolExecutor
from typing import TypeVar

T = TypeVar("T")
R = TypeVar("R")


def _read_max_parallel() -> int:
    try:
        return max(1, int(os.environ.get("PBIC_MAX_PARALLEL_QUERIES") or 8))
    except ValueError:
        return 8


MAX_PARALLEL_QUERIES = _read_max_parallel()


def run_parallel(
    fn: Callable[[T], R], items: Sequence[T], max_workers: int | None = None
) -> list[R]:
    """Apply `fn` to every item; results come back in input order. A single item (or a bound of
    one) runs inline, anything else on up to `min(max, len(items))` worker threads."""
    items = list(items)
    workers = min(max_workers or MAX_PARALLEL_QUERIES, len(items))
    if workers <= 1:
        return [fn(item) for item in items]
    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="pbic-q") as pool:
        return list(pool.map(fn, items))
