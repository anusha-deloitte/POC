# Removes the auto-start task created by install-autostart.ps1.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$folder = Split-Path -Leaf $root
$name = "PBI Standalone Dashboard - $folder"
if (Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue) {
    Unregister-ScheduledTask -TaskName $name -Confirm:$false
    Write-Host "Removed '$name'."
} else {
    Write-Host "'$name' was not installed."
}
