<#
.SYNOPSIS
  Stops the API/web processes of this checkout (started by start.ps1 or by hand).
#>
[CmdletBinding()]
param(
    [int]$ApiPort = 8000,
    [int]$WebPort = 5173
)

$root = $PSScriptRoot
$pidFile = Join-Path $root '.dev-pids.json'
$backendPath = (Join-Path $root 'backend')
$frontendPath = (Join-Path $root 'frontend')
$names = @('uv.exe', 'uvicorn.exe', 'python.exe', 'node.exe', 'cmd.exe', 'npm.cmd')

function Get-ProcTable {
    $t = @{}
    Get-CimInstance Win32_Process | ForEach-Object { $t[[int]$_.ProcessId] = $_ }
    return $t
}

function Get-PortOwners {
    param([int[]]$Ports)
    $ids = @()
    foreach ($p in $Ports) {
        $conns = Get-NetTCPConnection -State Listen -LocalPort $p -ErrorAction SilentlyContinue
        foreach ($c in @($conns)) { if ($c) { $ids += [int]$c.OwningProcess } }
    }
    return $ids | Where-Object { $_ -gt 0 } | Select-Object -Unique
}

$table = Get-ProcTable
$kill = New-Object System.Collections.Generic.HashSet[int]
$seeds = New-Object System.Collections.Generic.List[int]

if (Test-Path $pidFile) {
    try {
        $pids = Get-Content $pidFile -Raw | ConvertFrom-Json
        foreach ($id in @($pids.api, $pids.web)) {
            if ($id -and $table.ContainsKey([int]$id)) { $seeds.Add([int]$id) }
        }
    } catch { }
}
foreach ($id in (Get-PortOwners -Ports @($ApiPort, $WebPort))) { $seeds.Add([int]$id) }
foreach ($proc in $table.Values) {
    if ($names -contains $proc.Name -and $proc.CommandLine) {
        if ($proc.CommandLine.Contains($backendPath) -or $proc.CommandLine.Contains($frontendPath)) {
            $seeds.Add([int]$proc.ProcessId)
        }
    }
}

function Add-Descendants {
    param([int]$ProcId, [bool]$IsRoot)
    if (-not $kill.Add($ProcId) -and -not $IsRoot) { return }
    foreach ($child in $table.Values) {
        if ([int]$child.ParentProcessId -eq $ProcId -and $names -contains $child.Name -and -not $kill.Contains([int]$child.ProcessId)) {
            Add-Descendants -ProcId ([int]$child.ProcessId) -IsRoot $false
        }
    }
}

foreach ($seed in ($seeds | Select-Object -Unique)) {
    Add-Descendants -ProcId $seed -IsRoot $true
    $cur = $seed
    for ($i = 0; $i -lt 8; $i++) {
        if (-not $table.ContainsKey($cur)) { break }
        $parent = [int]$table[$cur].ParentProcessId
        if (-not $table.ContainsKey($parent) -or $names -notcontains $table[$parent].Name) { break }
        [void]$kill.Add($parent)
        $cur = $parent
    }
}

$kill.Remove($PID) | Out-Null
foreach ($id in $kill) {
    Stop-Process -Id $id -Force -ErrorAction SilentlyContinue
}
Remove-Item $pidFile -ErrorAction SilentlyContinue

$deadline = (Get-Date).AddSeconds(10)
do {
    $held = @(Get-PortOwners -Ports @($ApiPort, $WebPort))
    if ($held.Count -eq 0) { break }
    Start-Sleep -Milliseconds 500
} while ((Get-Date) -lt $deadline)

if ($held.Count -gt 0) {
    foreach ($id in $held) {
        $p = Get-CimInstance Win32_Process -Filter "ProcessId=$id" -ErrorAction SilentlyContinue
        Write-Warning "Port still held by pid $id ($($p.Name)): $($p.CommandLine)"
    }
    exit 1
}
Write-Host "Ports $ApiPort and $WebPort are free." -ForegroundColor Green
