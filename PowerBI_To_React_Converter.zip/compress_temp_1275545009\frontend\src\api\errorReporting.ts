/** Forwards a failed API call's details to the backend so it lands in the
 * same durable, redacted log files instead of vanishing on page refresh.
 * Fire-and-forget: must never throw or block the caller. */
export function reportClientError(info: {
  message: string
  path: string
  method?: string
  status?: number
  context?: string
  conversionId?: string
}): void {
  try {
    void fetch('/api/v1/client-logs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: info.message.slice(0, 2000),
        path: info.path.slice(0, 500),
        method: info.method,
        status: info.status,
        context: info.context?.slice(0, 200),
        conversion_id: info.conversionId,
      }),
      keepalive: true,
    }).catch(() => {})
  } catch {
    /* logging must never break the caller */
  }
}
