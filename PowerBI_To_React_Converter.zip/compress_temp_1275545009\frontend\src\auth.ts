export interface User {
  id: string
  email: string
  name: string
  is_admin: boolean
}

const TOKEN_KEY = 'pbic.token'
const USER_KEY = 'pbic.user'

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY)
}

export function getUser(): User | null {
  const raw = localStorage.getItem(USER_KEY)
  return raw ? (JSON.parse(raw) as User) : null
}

export function setSession(token: string, user: User): void {
  localStorage.setItem(TOKEN_KEY, token)
  localStorage.setItem(USER_KEY, JSON.stringify(user))
}

export function clearSession(): void {
  localStorage.removeItem(TOKEN_KEY)
  localStorage.removeItem(USER_KEY)
}

export const API_UNREACHABLE =
  'The API server is not reachable. Start it with ./start.ps1 (see logs/api.err.log).'

async function authRequest(
  path: string,
  payload: Record<string, unknown>,
  fallback: string,
): Promise<{ token: string; user: User }> {
  let res: Response
  try {
    res = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
  } catch {
    throw new Error(API_UNREACHABLE)
  }
  const text = await res.text()
  let body: { detail?: unknown; token?: string; user?: User } | null = null
  try {
    body = text ? JSON.parse(text) : null
  } catch {
    body = null
  }
  if (!res.ok) {
    if (body?.detail) {
      throw new Error(typeof body.detail === 'string' ? body.detail : JSON.stringify(body.detail))
    }
    if (res.status >= 500 && !body) throw new Error(API_UNREACHABLE)
    throw new Error(fallback)
  }
  if (!body?.token || !body.user) throw new Error(API_UNREACHABLE)
  return { token: body.token, user: body.user }
}

export async function login(email: string, password: string): Promise<User> {
  const body = await authRequest('/api/auth/login', { email, password }, 'login failed')
  setSession(body.token, body.user)
  return body.user
}

export async function signup(email: string, password: string, name: string): Promise<User> {
  const body = await authRequest('/api/auth/signup', { email, password, name }, 'signup failed')
  setSession(body.token, body.user)
  return body.user
}

export async function validateSession(): Promise<User | null> {
  const token = getToken()
  if (!token) return null
  const res = await fetch('/api/auth/me', { headers: { Authorization: `Bearer ${token}` } })
  if (!res.ok) {
    clearSession()
    return null
  }
  return res.json()
}
