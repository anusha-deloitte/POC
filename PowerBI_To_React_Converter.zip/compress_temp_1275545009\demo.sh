#!/usr/bin/env bash
# One-command demo startup: backend + frontend, key sourced, health-checked.
set -euo pipefail
cd "$(dirname "$0")"

API_PORT="${API_PORT:-8123}"
WEB_PORT="${WEB_PORT:-5173}"
ENV_FILE="${PBIC_ENV_FILE:-$(dirname "$0")/backend/.env}"

echo "── PBI Converter demo ──────────────────────────────"

if [ -f "$ENV_FILE" ] && grep -q '^PBIC_HORIZON_CLIENT_ID=.\+' "$ENV_FILE"; then
  echo "✓ Horizon credentials found (Horizon AI available; Snowflake Cortex is the default tier-2 provider)"
else
  echo "! No Horizon credentials in $ENV_FILE — Horizon AI is off; tier-2 uses Snowflake Cortex (role needs SNOWFLAKE.CORTEX_USER)"
fi

pkill -f "uvicorn app.main:app" 2>/dev/null || true
sleep 1

echo "→ starting API on :$API_PORT"
(cd backend && .venv/bin/uvicorn app.main:app --port "$API_PORT" >/tmp/pbic-api.log 2>&1 &)

for _ in $(seq 1 20); do
  if curl -sf "localhost:$API_PORT/healthz" >/dev/null 2>&1; then break; fi
  sleep 0.5
done
curl -sf "localhost:$API_PORT/healthz" >/dev/null || { echo "✗ API failed to start (see /tmp/pbic-api.log)"; exit 1; }
echo "✓ API healthy"

CONN=$(curl -s "localhost:$API_PORT/api/v1/connections" | python3 -c "
import json,sys
try:
    conns = json.load(sys.stdin)
    print(next((c['id'] for c in conns if c['name']=='finops-snowflake'), conns[0]['id'] if conns else ''))
except Exception: print('')")
[ -n "$CONN" ] && echo "✓ Snowflake profile ready ($CONN)" || echo "! No connection profile — add one in the Connect step"

if ! curl -sf "localhost:$WEB_PORT" >/dev/null 2>&1; then
  echo "→ starting web on :$WEB_PORT"
  (cd frontend && PBIC_API_URL="http://localhost:$API_PORT" nohup npm run dev >/tmp/pbic-web.log 2>&1 &)
  for _ in $(seq 1 30); do
    if curl -sf "localhost:$WEB_PORT" >/dev/null 2>&1; then break; fi
    sleep 0.5
  done
fi
curl -sf "localhost:$WEB_PORT" >/dev/null && echo "✓ Web ready" || { echo "✗ Web failed (see /tmp/pbic-web.log)"; exit 1; }

echo ""
echo "  Studio:     http://localhost:$WEB_PORT"
echo "  API docs:   http://localhost:$API_PORT/docs"
echo "  Demo asset: MedicalCostCommandCenter.zip (repo root — drop it on the Upload step)"
echo "────────────────────────────────────────────────────"
