import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import type { AuthMethod } from '../../api/types'
import { AUTH_LABELS } from '../../components/snowflakeAuth'
import { MfaPasscodePrompt } from '../../components/MfaPasscodePrompt'
import type { DashboardApiConfig } from '../api'
import {
  SnowflakeAuthRequired,
  standaloneApi,
  type ConnectionPublic,
  type ConnectionSettings,
  type SecretField,
  type SessionStatus,
} from './standaloneApi'

const SECRET_FIELDS: Record<AuthMethod, { field: SecretField; label: string; multiline?: boolean }[]> = {
  password: [{ field: 'password', label: 'Password' }],
  key_pair: [
    { field: 'private_key_pem', label: 'Private key (PEM)', multiline: true },
    { field: 'private_key_passphrase', label: 'Private key passphrase' },
  ],
  oauth_client_credentials: [{ field: 'oauth_client_secret', label: 'OAuth client secret' }],
  pat: [{ field: 'pat_token', label: 'Programmatic access token' }],
  external_browser: [],
}

const IDENTITY: { key: keyof ConnectionSettings; label: string }[] = [
  { key: 'account', label: 'Account' },
  { key: 'user', label: 'User' },
]
const TARGETS: { key: keyof ConnectionSettings; label: string }[] = [
  { key: 'role', label: 'Role' },
  { key: 'warehouse', label: 'Warehouse' },
  { key: 'database', label: 'Database' },
  { key: 'schema', label: 'Schema' },
]

function Form({
  config,
  connection,
  session,
  onSignedIn,
  onClose,
  onForgot,
}: {
  config: DashboardApiConfig
  connection: ConnectionPublic
  session?: SessionStatus
  onSignedIn: () => void
  onClose: () => void
  onForgot: () => void
}) {
  const [values, setValues] = useState<ConnectionSettings>({
    account: connection.account ?? '',
    user: connection.user ?? '',
    auth_method: connection.auth_method ?? 'external_browser',
    role: connection.role ?? '',
    warehouse: connection.warehouse ?? '',
    database: connection.database ?? '',
    schema: connection.schema ?? '',
    oauth_client_id: connection.oauth_client_id ?? '',
    oauth_token_url: connection.oauth_token_url ?? '',
  })
  const [secrets, setSecrets] = useState<Partial<Record<SecretField, string>>>({})
  const [remember, setRemember] = useState(!!connection.remember)
  const [passcode, setPasscode] = useState('')
  const [mfa, setMfa] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const saved = new Set(connection.saved_secrets ?? [])
  const method = values.auth_method
  const set = (key: keyof ConnectionSettings, v: string) => setValues((p) => ({ ...p, [key]: v }))

  const signIn = useMutation({
    mutationFn: async (code?: string) => {
      setError(null)
      if (code === undefined) {
        await standaloneApi.saveConnection(config, {
          ...values,
          secrets: Object.fromEntries(Object.entries(secrets).filter(([, v]) => v)),
          remember,
        })
        setSecrets({})
      }
      return standaloneApi.authenticate(config, code ?? (passcode || undefined))
    },
    onSuccess: (result) => {
      if (result.ok) {
        setMfa(false)
        setPasscode('')
        onSignedIn()
        onClose()
        return
      }
      setMfa(!!result.mfa_required)
      setError(result.error ?? 'Snowflake authentication failed')
    },
    onError: (e) => {
      if (e instanceof SnowflakeAuthRequired && e.mfaRequired) setMfa(true)
      setError(e.message)
    },
  })
  const forget = useMutation({
    mutationFn: () => standaloneApi.forgetSecrets(config),
    onSuccess: () => {
      setRemember(false)
      onForgot()
    },
  })

  const browser = method === 'external_browser'
  const valid = !!(values.account && values.user && values.warehouse)

  return (
    <form
      className="space-y-3 text-xs"
      onSubmit={(e) => {
        e.preventDefault()
        if (valid && !signIn.isPending) signIn.mutate(undefined)
      }}
    >
      {connection.load_error && (
        <p role="alert" className="rounded-lg bg-brand-amber/10 p-2 text-brand-amber">
          {connection.load_error}
        </p>
      )}
      <div className="grid grid-cols-2 gap-3">
        {IDENTITY.map(({ key, label }) => (
          <label key={key} className="block">
            <span className="mb-1 block font-semibold">{label}</span>
            <input className="input" value={values[key]} onChange={(e) => set(key, e.target.value)} />
          </label>
        ))}
        <label className="col-span-2 block">
          <span className="mb-1 block font-semibold">Authentication method</span>
          <select
            className="input"
            value={method}
            onChange={(e) => {
              set('auth_method', e.target.value)
              setSecrets({})
            }}
          >
            {Object.entries(AUTH_LABELS).map(([v, label]) => (
              <option key={v} value={v}>
                {label}
              </option>
            ))}
          </select>
        </label>
        {TARGETS.map(({ key, label }) => (
          <label key={key} className="block">
            <span className="mb-1 block font-semibold">{label}</span>
            <input className="input" value={values[key]} onChange={(e) => set(key, e.target.value)} />
          </label>
        ))}
        {method === 'oauth_client_credentials' && (
          <>
            <label className="block">
              <span className="mb-1 block font-semibold">OAuth client ID</span>
              <input
                className="input"
                value={values.oauth_client_id}
                onChange={(e) => set('oauth_client_id', e.target.value)}
              />
            </label>
            <label className="block">
              <span className="mb-1 block font-semibold">OAuth token URL</span>
              <input
                className="input"
                value={values.oauth_token_url}
                onChange={(e) => set('oauth_token_url', e.target.value)}
              />
            </label>
          </>
        )}
        {SECRET_FIELDS[method].map(({ field, label, multiline }) => (
          <label key={field} className="col-span-2 block">
            <span className="mb-1 block font-semibold">
              {label}
              {saved.has(field) && (
                <span data-testid={`saved-${field}`} className="ml-2 font-normal text-brand-dark">
                  saved
                </span>
              )}
            </span>
            {multiline ? (
              <textarea
                className="input font-mono"
                rows={4}
                autoComplete="off"
                placeholder={saved.has(field) ? 'saved - leave empty to keep' : ''}
                value={secrets[field] ?? ''}
                onChange={(e) => setSecrets((p) => ({ ...p, [field]: e.target.value }))}
              />
            ) : (
              <input
                className="input"
                type="password"
                autoComplete="off"
                placeholder={saved.has(field) ? 'saved - leave empty to keep' : ''}
                value={secrets[field] ?? ''}
                onChange={(e) => setSecrets((p) => ({ ...p, [field]: e.target.value }))}
              />
            )}
          </label>
        ))}
      </div>
      {method === 'password' && (
        <label className="block">
          <span className="mb-1 block font-semibold">MFA code (optional)</span>
          <input
            className="input !w-32"
            inputMode="numeric"
            maxLength={8}
            autoComplete="one-time-code"
            value={passcode}
            onChange={(e) => setPasscode(e.target.value.replace(/\D/g, ''))}
          />
        </label>
      )}
      {!browser && (
        <label className="flex items-center gap-2">
          <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
          Remember on this computer
        </label>
      )}
      {mfa && (
        <MfaPasscodePrompt
          required
          pending={signIn.isPending}
          error={error ?? undefined}
          onSubmit={(code) => signIn.mutate(code)}
        />
      )}
      {error && !mfa && (
        <p role="alert" className="text-brand-red">
          {error}
        </p>
      )}
      {browser && signIn.isPending && (
        <p data-testid="sso-wait" className="text-surface-700">
          Complete sign-in in the browser…
          {session?.sso_url && (
            <>
              {' '}
              <a
                href={session.sso_url}
                target="_blank"
                rel="noreferrer"
                className="font-semibold text-brand-dark underline"
              >
                Open the sign-in page
              </a>
            </>
          )}
        </p>
      )}
      <div className="flex items-center gap-2 pt-1">
        <button type="submit" className="btn-primary" disabled={!valid || signIn.isPending}>
          {browser ? 'Save & authenticate' : 'Save & sign in'}
        </button>
        {(saved.size > 0 || connection.remember) && (
          <button
            type="button"
            className="text-xs text-brand-red underline"
            disabled={forget.isPending}
            onClick={() => forget.mutate()}
          >
            Forget saved credentials
          </button>
        )}
        <button type="button" className="ml-auto text-xs text-surface-500 underline" onClick={onClose}>
          Close
        </button>
      </div>
    </form>
  )
}

export function ConnectionPanel({
  config,
  open,
  session,
  onClose,
  onSignedIn,
}: {
  config: DashboardApiConfig
  open: boolean
  session?: SessionStatus
  onClose: () => void
  onSignedIn: () => void
}) {
  const qc = useQueryClient()
  const connection = useQuery({
    queryKey: ['standalone-connection'],
    queryFn: () => standaloneApi.connection(config),
    enabled: open,
    gcTime: 0,
  })
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Connection settings"
        className="max-h-full w-full max-w-lg overflow-auto rounded-xl bg-white p-5 shadow-xl"
      >
        <h2 className="mb-3 text-sm font-bold text-surface-900">Snowflake connection</h2>
        {connection.isLoading && <p className="text-xs text-surface-500">Loading…</p>}
        {connection.isError && (
          <p role="alert" className="text-xs text-brand-red">
            {connection.error.message}
          </p>
        )}
        {connection.data && (
          <Form
            config={config}
            connection={connection.data}
            session={session}
            onSignedIn={onSignedIn}
            onClose={onClose}
            onForgot={() => qc.invalidateQueries({ queryKey: ['standalone-connection'] })}
          />
        )}
      </div>
    </div>
  )
}
