# {{REPORT_TITLE}} - standalone dashboard

A copy of the converted Power BI report that runs on your own Windows machine, without the
converter. It shows live data from Snowflake, signed in as you.

## Requirements

- Windows 64-bit
- Python {{PYTHON}} (64-bit) from https://www.python.org/downloads/ (the app's libraries are in `vendor/`, built for this version)
- A Snowflake account you can sign in to, with a role that can read the report's tables

## Start and stop

```powershell
.\start.ps1            # starts the service and opens http://127.0.0.1:8765/
.\start.ps1 -Port 9000 # another port
.\stop.ps1             # stops the service
```

If PowerShell refuses to run the scripts: `powershell -ExecutionPolicy Bypass -File .\start.ps1`.

## Signing in

The first time (or whenever the session expires) the page asks you to sign in to Snowflake. Open
**Connection settings** to change the account, user, role, warehouse or sign-in method:
password (with an MFA code if your account needs one), key pair, OAuth client credentials,
programmatic access token, or browser single sign-on.

Secrets you type are kept in memory only. Tick **Remember on this computer** to save them
encrypted (`data/secrets.enc`); the key is stored in the Windows Credential Manager, so the file
alone is useless. **Forget saved credentials** removes both.

## Start with Windows

```powershell
.\install-autostart.ps1    # starts the service when you sign in (per-user task, no admin rights)
.\uninstall-autostart.ps1  # removes it
```

## Contents

| Path | What it is |
| --- | --- |
| `app/` | the built dashboard (React) and the report's images |
| `service/` | the local query service (FastAPI) |
| `vendor/` | the service's Python libraries |
| `data/spec.json` | the compiled report: pages, visuals, formatting |
| `data/templates/` | one SQL template per data query |
| `data/manifest.json` | which template answers which visual |
| `data/connection.json` | non-secret connection settings |
| `data/token.txt` | the token the page uses to talk to the local service |
| `COVERAGE.md` | what each page honours and its limits |
| `logs/` | service logs (created on first start) |

## How queries work

Each visual's query was generated when the package was exported. The SQL has a slot wherever a
filter on a column can go. When you click a slicer, a bar or a Filters-pane card, the page sends
the filters and the service fills those slots and runs the SQL on Snowflake. The report's logic
is fixed at export time; the data is live. Export again to pick up changes to the report.

## Security

- The service listens on `127.0.0.1` only and every API call needs the token in `data/token.txt`.
  Do not share this folder with anyone who should not see the data: the token and any remembered
  credentials stay with this computer.
- Queries run with your own Snowflake user and role; nothing is sent anywhere else.
- Packages contain no passwords or keys; `data/connection.json` has settings only.
