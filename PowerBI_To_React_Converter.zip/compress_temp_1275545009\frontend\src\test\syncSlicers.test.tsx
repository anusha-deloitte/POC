import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { DashboardApp } from '../dashboard/DashboardApp'
import type { DashboardSpec, FilterCard, VisualSpec } from '../dashboard/types'

const pbir = (hidden = false) => ({
  objects: {}, container_objects: {}, fields: [], sort: [], is_hidden: hidden, self_hidden: hidden,
})

function slicer(name: string, column: string, group?: string, hidden = false): VisualSpec {
  return {
    name, visual_type: 'slicer', x: 0, y: 0, width: 160, height: 60, z: 1, supported: true,
    dim_keys: [`Customer.${column}`], column_keys: [], series_keys: [], measure_keys: [], measure_roles: {},
    measure_formats: {}, static_content: {}, sort: [], data_status: 'ok',
    slicer_target: { table: 'Customer', column },
    query: { dimensions: [{ table: 'Customer', column }], measures: [], filters: [], sort: [] },
    sync_group: group ? { name: group, filter_changes: true, field_changes: true } : null,
    pbir: pbir(hidden),
  } as VisualSpec
}

const cardVisual = (name: string): VisualSpec =>
  ({
    name, visual_type: 'card', x: 200, y: 0, width: 160, height: 60, z: 2, supported: true,
    dim_keys: [], column_keys: [], series_keys: [], measure_keys: ['M'], measure_roles: {}, measure_formats: {},
    static_content: {}, sort: [], data_status: 'ok',
    query: { dimensions: [], measures: [{ name: 'M' }], filters: [], sort: [] }, pbir: pbir(),
  }) as VisualSpec

const regionCard: FilterCard = {
  name: 'region', scope: 'report', table: 'Customer', column: 'Region', display_name: 'Region', data_type: 'string',
  kind: 'basic', default: { join: 'and', conditions: [{ op: 'in', values: ['EU'], params: {} }] },
  require_single: false, hidden: false, locked: false, supported: true,
}

function makeSpec(): DashboardSpec {
  const page = (name: string, visuals: VisualSpec[]) => ({
    name, display_name: name.toUpperCase(), width: 800, height: 400, ordinal: 0, visuals, filters: [],
  })
  return {
    report_name: 'r',
    pages: [
      page('p1', [slicer('sync1', 'Country', 'G'), slicer('solo', 'City'), cardVisual('card1')]),
      page('p2', [slicer('sync2', 'Country', 'G'), slicer('hidden', 'Country', 'G', true), cardVisual('card2')]),
    ],
    warnings: [], measure_tiers: { M: 0 }, theme: { data_colors: [], text_classes: {} },
    interaction_graph: { nodes: [], edges: [], sync_groups: { G: ['sync1', 'sync2', 'hidden'] } },
    bookmarks: [
      { name: 'withFilters', display_name: 'Filtered view', state: {
        page_name: null, visibility: {}, targets: [],
        filter_values: { report: { region: null }, slicers: { sync1: ['DE'] } },
      } },
      { name: 'dataOff', display_name: 'Data off', state: { page_name: null, visibility: {}, targets: [] } },
    ],
    drill_through: [], report_filters: [regionCard], allow_change_filter_types: true,
  } as unknown as DashboardSpec
}

type Query = { visual: string; page: string; filters: { table: string; column: string; values: unknown[]; source?: string }[] }
let queries: Query[][] = []

function renderApp() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <DashboardApp conversionId="c1" connectionId="conn" />
    </QueryClientProvider>,
  )
}

const lastQueries = () => queries[queries.length - 1] ?? []
const filtersOf = (visual: string) => lastQueries().find((q) => q.visual === visual)?.filters ?? []
const columnsOf = (visual: string) => filtersOf(visual).map((f) => `${f.column}=${JSON.stringify(f.values)}`)

describe('Filters pane and synced slicers in the dashboard', () => {
  beforeEach(() => {
    queries = []
    class RO {
      observe() {}
      disconnect() {}
      unobserve() {}
    }
    vi.stubGlobal('ResizeObserver', RO)
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        const u = String(url)
        if (u.endsWith('/dashboard/spec')) return new Response(JSON.stringify(makeSpec()))
        if (u.endsWith('/dashboard/query')) {
          const body = JSON.parse(String(init?.body))
          queries.push(body.queries)
          const results = body.queries.map((q: Query) => ({
            visual: q.visual,
            columns: q.visual.startsWith('sync') || q.visual === 'hidden' ? ['Customer.Country'] : q.visual === 'solo' ? ['Customer.City'] : ['M'],
            rows: q.visual === 'solo' ? [['Oslo'], ['Rome']] : q.visual.startsWith('card') ? [[1]] : [['US'], ['DE']],
            warnings: [], elapsed_ms: 1, cached: false,
          }))
          return new Response(JSON.stringify({ results }))
        }
        if (u.includes('/filter-values'))
          return new Response(JSON.stringify({ values: ['EU', 'NA'], truncated: false }))
        return new Response(JSON.stringify({ available: false, status: 'none' }))
      }),
    )
  })
  afterEach(() => vi.restoreAllMocks())

  it('the canvas column shares one row with the pane, in a fixed-height studio layout', async () => {
    renderApp()
    const column = await screen.findByTestId('canvas-column')
    const tab = await screen.findByTestId('filters-tab')
    expect(column.parentElement).toBe(tab.parentElement)
    expect(column.className).toContain('overflow-auto')
    const root = screen.getByTestId('dashboard-root')
    expect(root.className).toContain('h-screen')
    expect(root.className).toContain('overflow-hidden')
    expect(column.parentElement!.className).toContain('min-h-0')
  })

  it('the pane defaults reach every query, slicers included', async () => {
    renderApp()
    await waitFor(() => expect(queries.length).toBeGreaterThan(0))
    for (const visual of ['sync1', 'solo', 'card1'])
      expect(columnsOf(visual)).toContain('Region=["EU"]')
    expect(filtersOf('card1')[0].source).toBe('report_filter')
  })

  it('user values in the pane change every query', async () => {
    renderApp()
    await userEvent.click(await screen.findByTestId('filters-tab'))
    await userEvent.click(screen.getByLabelText('Clear Region'))
    await waitFor(() => expect(columnsOf('card1')).not.toContain('Region=["EU"]'))
    expect(columnsOf('solo')).not.toContain('Region=["EU"]')
    await userEvent.click(screen.getByRole('button', { name: 'Reset to default' }))
    await waitFor(() => expect(columnsOf('card1')).toContain('Region=["EU"]'))
  })

  it('a synced selection follows to another page, including hidden synced slicers', async () => {
    renderApp()
    const combo = await screen.findByRole('combobox', { name: 'Country' })
    await waitFor(() => expect(within(combo).getByRole('option', { name: 'US' })).toBeTruthy())
    await userEvent.selectOptions(combo, 'US')
    await waitFor(() => expect(columnsOf('card1')).toContain('Country=["US"]'))
    await userEvent.click(screen.getByRole('button', { name: 'P2' }))
    await waitFor(() => expect(queries.some((q) => q.some((x) => x.visual === 'card2'))).toBe(true))
    // visible AND hidden synced slicers of page 2 carry the group's selection
    const countryFilters = filtersOf('card2').filter((f) => f.column === 'Country')
    expect(countryFilters.length).toBeGreaterThanOrEqual(1)
    expect(countryFilters.every((f) => JSON.stringify(f.values) === '["US"]')).toBe(true)
    expect(((await screen.findByRole('combobox', { name: 'Country' })) as HTMLSelectElement).value).toBe('US')
  })

  it('an unsynced slicer keeps page-local state that resets on a page change', async () => {
    renderApp()
    const city = await screen.findByRole('combobox', { name: 'City' })
    await waitFor(() => expect(within(city).getByRole('option', { name: 'Oslo' })).toBeTruthy())
    await userEvent.selectOptions(city, 'Oslo')
    await waitFor(() => expect(columnsOf('card1')).toContain('City=["Oslo"]'))
    await userEvent.click(screen.getByRole('button', { name: 'P2' }))
    await userEvent.click(screen.getByRole('button', { name: 'P1' }))
    await waitFor(() => expect(columnsOf('card1')).not.toContain('City=["Oslo"]'))
  })

  it('clearing a synced slicer clears the group', async () => {
    renderApp()
    const combo = await screen.findByRole('combobox', { name: 'Country' })
    await waitFor(() => expect(within(combo).getByRole('option', { name: 'US' })).toBeTruthy())
    await userEvent.selectOptions(combo, 'US')
    await waitFor(() => expect(columnsOf('card1')).toContain('Country=["US"]'))
    await userEvent.selectOptions(combo, 'All')
    await waitFor(() => expect(columnsOf('card1').some((c) => c.startsWith('Country='))).toBe(false))
    await userEvent.click(screen.getByRole('button', { name: 'P2' }))
    await waitFor(() => expect(queries.some((q) => q.some((x) => x.visual === 'card2'))).toBe(true))
    expect(filtersOf('card2').some((f) => f.column === 'Country')).toBe(false)
  })

  it('a bookmark with filter state restores the pane and the synced slicers', async () => {
    renderApp()
    await screen.findByRole('combobox', { name: 'Country' })
    await userEvent.click(screen.getByRole('button', { name: 'Bookmarks' }))
    await userEvent.click(screen.getByRole('menuitem', { name: 'Filtered view' }))
    await waitFor(() => expect(columnsOf('card1')).toContain('Country=["DE"]'))
    expect(columnsOf('card1')).not.toContain('Region=["EU"]') // the report card was cleared to (All)
  })

  it('a bookmark captured with Data off leaves the filters as they are', async () => {
    renderApp()
    const combo = await screen.findByRole('combobox', { name: 'Country' })
    await waitFor(() => expect(within(combo).getByRole('option', { name: 'US' })).toBeTruthy())
    await userEvent.selectOptions(combo, 'US')
    await waitFor(() => expect(columnsOf('card1')).toContain('Country=["US"]'))
    await userEvent.click(screen.getByRole('button', { name: 'Bookmarks' }))
    await userEvent.click(screen.getByRole('menuitem', { name: 'Data off' }))
    await new Promise((r) => setTimeout(r, 30))
    expect(columnsOf('card1')).toContain('Country=["US"]')
    expect(columnsOf('card1')).toContain('Region=["EU"]')
  })
})
