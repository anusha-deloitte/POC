import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { auditApi, type QueryAuditParams } from '../api/client'
import type { NoSqlPane, QueryFilter, QueryRecord, QueryStatus } from '../api/types'
import { useWizard } from '../store/wizard'
import { RecheckButton } from './RecheckButton'
import { SqlEditor } from './SqlEditor'

const KIND_OPTIONS: [string, string][] = [
  ['dashboard', 'Dashboard'],
  ['totals', 'Totals'],
  ['drill', 'Drill'],
  ['conversion', 'Conversion checks'],
  ['setup', 'Setup'],
  ['all', 'All'],
]
const CONVERSION_KINDS = ['validation', 'probe', 'ai_check', 'ai_llm']

const STATUS_LABEL: Record<QueryStatus, string> = {
  ok: 'OK',
  empty: '0 rows',
  error: 'Error',
  plan_error: 'Not built',
  cached: 'Cached',
}
const STATUS_BADGE: Record<QueryStatus, string> = {
  ok: 'badge-green',
  empty: 'badge-amber',
  error: 'badge-red',
  plan_error: 'badge-red',
  cached: 'badge-blue',
}

export function kindCount(kinds: Record<string, number>, kind: string): number {
  if (kind === 'all') return Object.values(kinds).reduce((a, b) => a + b, 0)
  if (kind === 'conversion') return CONVERSION_KINDS.reduce((a, k) => a + (kinds[k] ?? 0), 0)
  return kinds[kind] ?? 0
}

/** Why a record's SQL can't be edited, or null when it is a pane's main query. */
export function editBlockedReason(r: QueryRecord): string | null {
  if (r.kind === 'setup') return 'Setup queries are not a pane’s query, so they can’t be edited.'
  if (['probe', 'ai_check', 'ai_llm'].includes(r.kind) || (r.kind === 'validation' && r.check !== 'main'))
    return 'This query belongs to the conversion run’s checks, not to a pane, so it can’t be edited.'
  const main =
    (r.kind === 'dashboard' && r.attempt !== 'fallback') || (r.kind === 'validation' && r.check === 'main')
  if (!main || !r.page || !r.visual)
    return 'Only a pane’s main query can be edited; open the pane in the Dashboard view or its “main” check.'
  return null
}

export function filterText(f: QueryFilter): string {
  const values = f.values.map((v) => (v === null ? 'NULL' : String(v))).join(', ')
  return `${f.table}.${f.column} ${f.op} ${values}${f.source ? ` [${f.source}]` : ''}`
}

export function matchesQuerySearch(r: QueryRecord, needle: string): boolean {
  const n = needle.trim().toLowerCase()
  if (!n) return true
  const hay = [
    r.page, r.page_name, r.pane, r.visual, r.check, r.query_id, r.sql, r.compat_sql, r.error,
    r.warehouse, r.role, r.kind,
    ...(r.tables ?? []).flatMap((t) => [t.model_table, t.physical]),
    ...(r.measures ?? []),
    ...[...(r.visual_filters ?? []), ...(r.request_filters ?? [])].flatMap((f) => [f.table, f.column]),
  ]
  return hay.filter(Boolean).join(' ').toLowerCase().includes(n)
}

function Card({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl border border-black/[0.06] bg-white p-3">
      <div className="text-[10px] font-bold tracking-wider text-surface-500 uppercase">{label}</div>
      <div className="mt-1 text-base font-bold">{value}</div>
    </div>
  )
}

function SqlBlock({ label, sql }: { label: string; sql: string }) {
  return (
    <div className="mt-2">
      <div className="flex items-center gap-2 font-semibold">
        {label}
        <button
          type="button"
          className="text-[11px] font-normal text-brand-blue underline"
          onClick={() => void navigator.clipboard?.writeText(sql)}
        >
          Copy
        </button>
      </div>
      <pre className="mt-1 max-h-48 overflow-auto rounded-lg bg-white p-2 whitespace-pre-wrap">{sql}</pre>
    </div>
  )
}

function FilterList({ title, filters }: { title: string; filters?: QueryFilter[] }) {
  if (!filters || filters.length === 0) return null
  return (
    <div className="mt-2">
      <div className="font-semibold">{title}</div>
      <ul className="mt-1 ml-4 list-disc">
        {filters.map((f, i) => (
          <li key={i}>{filterText(f)}</li>
        ))}
      </ul>
    </div>
  )
}

function History({ record }: { record: QueryRecord }) {
  const conversionId = useWizard((s) => s.conversionId)!
  const history = useQuery({
    queryKey: ['query-history', conversionId, record.page, record.visual],
    queryFn: () =>
      auditApi.queryAudit(conversionId, { history_for: `${record.page}/${record.visual}` }),
  })
  return (
    <div data-testid="query-history" className="mt-2 rounded-lg bg-white p-2">
      {history.isLoading && <p>Loading history…</p>}
      {history.data?.records.map((h, i) => (
        <div key={i} className="flex gap-3 border-t border-surface-100 py-0.5 first:border-t-0">
          <span className={STATUS_BADGE[h.status]}>{STATUS_LABEL[h.status]}</span>
          <span>{h.elapsed_ms ?? '—'} ms</span>
          <span>{h.row_count ?? '—'} rows</span>
          <span className="text-surface-500">{h.source}</span>
          {h.error && <span className="text-brand-red">{h.error}</span>}
        </div>
      ))}
    </div>
  )
}

function Detail({
  record,
  onEdit,
  onOpenMeasure,
}: {
  record: QueryRecord
  onEdit: (r: QueryRecord) => void
  onOpenMeasure?: (m: string) => void
}) {
  const [history, setHistory] = useState(false)
  const blocked = editBlockedReason(record)
  const canRecheck = !!record.page && !!record.visual && ['dashboard', 'validation'].includes(record.kind)
  return (
    <div data-testid="query-detail" className="bg-surface-50 px-4 py-3 text-xs">
      {record.drill && (
        <p>
          Drill step: {record.drill.direction} to {record.drill.level} (level {record.drill.level_index + 1})
        </p>
      )}
      {record.error && (
        <p className="text-brand-red">
          {record.status === 'plan_error' ? 'Not built: ' : ''}
          {record.error}
        </p>
      )}
      {record.fallback_reason && <p>Fallback: {record.fallback_reason}</p>}
      {record.sql ? (
        <SqlBlock label="SQL" sql={record.sql} />
      ) : (
        record.status !== 'plan_error' && (
          <p className="mt-2 text-surface-500">
            {record.sql_logged === false ? 'SQL logging is off for this run.' : 'No SQL recorded.'}
          </p>
        )
      )}
      {record.compat_sql && record.compat_sql !== record.sql && (
        <SqlBlock label="Fallback SQL" sql={record.compat_sql} />
      )}
      <div className="mt-2 flex flex-wrap items-center gap-2">
        {blocked === null ? (
          <button type="button" className="btn-secondary !px-2 !py-0.5 !text-xs" onClick={() => onEdit(record)}>
            Edit SQL
          </button>
        ) : (
          <span className="text-surface-500">{blocked}</span>
        )}
        {canRecheck && <RecheckButton page={record.page!} visual={record.visual!} />}
      </div>
      <FilterList title="Filters from slicers and cross-filters" filters={record.request_filters} />
      <FilterList title="Filters on this visual" filters={record.visual_filters} />
      {record.unapplied_filters && record.unapplied_filters.length > 0 && (
        <p className="mt-2 text-brand-amber">
          Filters not applied to the edited SQL: {record.unapplied_filters.join(', ')}
        </p>
      )}
      {record.tables && record.tables.length > 0 && (
        <div className="mt-2">
          <div className="font-semibold">Tables read</div>
          <ul className="mt-1 ml-4 list-disc">
            {record.tables.map((t) => (
              <li key={t.model_table}>
                {t.model_table} → {t.physical}
              </li>
            ))}
          </ul>
        </div>
      )}
      {record.measures && record.measures.length > 0 && (
        <div className="mt-2">
          <div className="font-semibold">Measures</div>
          <ul className="mt-1 ml-4 list-disc">
            {record.measures.map((m) => (
              <li key={m}>
                [{m}]{' '}
                {onOpenMeasure && (
                  <button type="button" className="text-brand-blue underline" onClick={() => onOpenMeasure(m)}>
                    Open in DAX Audit
                  </button>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
      <p className="mt-2 text-surface-600">
        {[record.warehouse, record.role, record.connection_name].filter(Boolean).join(' · ') ||
          'No warehouse / role recorded'}
      </p>
      {record.query_id && (
        <p className="mt-1">
          Snowflake query ID: <code>{record.query_id}</code>{' '}
          <button
            type="button"
            className="text-brand-blue underline"
            onClick={() =>
              void navigator.clipboard?.writeText(
                `SELECT * FROM TABLE(INFORMATION_SCHEMA.QUERY_HISTORY()) WHERE QUERY_ID = '${record.query_id}'`,
              )
            }
          >
            Copy history lookup
          </button>
        </p>
      )}
      {record.page && record.visual && (
        <button
          type="button"
          className="mt-2 text-brand-blue underline"
          onClick={() => setHistory(!history)}
        >
          {history ? 'Hide run history' : 'Show run history'}
        </button>
      )}
      {history && <History record={record} />}
    </div>
  )
}

function NoSqlPanes({ onOpenMeasure }: { onOpenMeasure?: (m: string) => void }) {
  const conversionId = useWizard((s) => s.conversionId)!
  const panes = useQuery({
    queryKey: ['no-sql-panes', conversionId],
    queryFn: () => auditApi.noSqlPanes(conversionId),
  })
  const [search, setSearch] = useState('')
  const [page, setPage] = useState('all')
  const [editing, setEditing] = useState<string | null>(null)
  const [openDax, setOpenDax] = useState<string | null>(null)
  const list = panes.data?.panes ?? []
  const pages = [...new Map(list.map((p) => [p.page, p.page_name])).entries()]
  const rows = list.filter(
    (p) =>
      (page === 'all' || p.page === page) &&
      `${p.pane} ${p.visual_type} ${p.measure ?? ''} ${p.reason ?? ''} ${p.page_name}`
        .toLowerCase()
        .includes(search.trim().toLowerCase()),
  )
  const key = (p: NoSqlPane) => `${p.page}/${p.visual}`

  return (
    <div data-testid="no-sql-panes">
      <p className="mb-3 text-xs text-surface-600">
        Panes the converter could not translate to SQL. Write the SQL yourself with Edit SQL, or fix
        the measure in the DAX Audit.
      </p>
      <div className="mb-3 flex gap-2">
        <input
          className="input !w-64"
          placeholder="Search panes…"
          aria-label="Search panes"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select aria-label="Page" className="input !w-48" value={page} onChange={(e) => setPage(e.target.value)}>
          <option value="all">All pages</option>
          {pages.map(([id, name]) => (
            <option key={id} value={id}>
              {name}
            </option>
          ))}
        </select>
      </div>
      {panes.isLoading && <p className="text-sm text-surface-500">Loading…</p>}
      {panes.isSuccess && rows.length === 0 && (
        <p className="text-sm text-surface-600">Every pane has generated SQL.</p>
      )}
      {rows.length > 0 && (
        <table className="w-full text-xs">
          <thead className="bg-surface-100 text-left">
            <tr>
              <th className="px-3 py-1.5">Page</th>
              <th className="px-2 py-1.5">Pane</th>
              <th className="px-2 py-1.5">Visual type</th>
              <th className="px-2 py-1.5">Untranslated measure</th>
              <th className="px-2 py-1.5">Reason</th>
              <th className="px-2 py-1.5" />
            </tr>
          </thead>
          <tbody>
            {rows.map((p) => (
              <NoSqlRow
                key={key(p)}
                pane={p}
                editing={editing === key(p)}
                dax={openDax === key(p)}
                onEdit={() => setEditing(editing === key(p) ? null : key(p))}
                onDax={() => setOpenDax(openDax === key(p) ? null : key(p))}
                onOpenMeasure={onOpenMeasure}
              />
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}

function NoSqlRow({
  pane,
  editing,
  dax,
  onEdit,
  onDax,
  onOpenMeasure,
}: {
  pane: NoSqlPane
  editing: boolean
  dax: boolean
  onEdit: () => void
  onDax: () => void
  onOpenMeasure?: (m: string) => void
}) {
  return (
    <>
      <tr className="border-t border-surface-100 align-top">
        <td className="px-3 py-1.5">{pane.page_name}</td>
        <td className="px-2 py-1.5 font-semibold">
          {pane.pane}
          {pane.manual_sql && <span className="badge-blue ml-1">Edited SQL</span>}
        </td>
        <td className="px-2 py-1.5 text-surface-600">{pane.visual_type}</td>
        <td className="px-2 py-1.5">{pane.measure ? `[${pane.measure}]` : '—'}</td>
        <td className="px-2 py-1.5 text-surface-600">{pane.reason}</td>
        <td className="px-2 py-1.5">
          <div className="flex flex-wrap items-center gap-1">
            <button type="button" className="btn-secondary !px-2 !py-0.5 !text-[11px]" onClick={onEdit}>
              Edit SQL
            </button>
            <RecheckButton page={pane.page} visual={pane.visual} compact />
            <button type="button" className="btn-secondary !px-2 !py-0.5 !text-[11px]" onClick={onDax}>
              {dax ? 'Hide DAX' : 'Show DAX'}
            </button>
            {pane.measure && onOpenMeasure && (
              <button
                type="button"
                className="text-brand-blue underline"
                onClick={() => onOpenMeasure(pane.measure!)}
              >
                DAX Audit
              </button>
            )}
          </div>
        </td>
      </tr>
      {editing && (
        <tr>
          <td colSpan={6} className="px-3 py-2">
            <SqlEditor page={pane.page} visual={pane.visual} onClose={onEdit} />
          </td>
        </tr>
      )}
      {dax && (
        <tr>
          <td colSpan={6} className="px-3 py-2">
            <PaneDax page={pane.page} visual={pane.visual} />
          </td>
        </tr>
      )}
    </>
  )
}

function PaneDax({ page, visual }: { page: string; visual: string }) {
  const conversionId = useWizard((s) => s.conversionId)!
  const detail = useQuery({
    queryKey: ['no-sql-pane', conversionId, page, visual],
    queryFn: () => auditApi.noSqlPane(conversionId, page, visual),
  })
  if (detail.isLoading) return <p className="text-xs text-surface-500">Loading…</p>
  if (detail.isError)
    return (
      <p role="alert" className="text-xs text-brand-red">
        {detail.error.message}
      </p>
    )
  const d = detail.data!
  return (
    <div data-testid="no-sql-pane-dax" className="rounded-xl bg-surface-50 p-3 text-xs">
      <div className="font-semibold">Visual DAX query (without slicer selections)</div>
      {d.dax_query ? (
        <pre className="mt-1 max-h-56 overflow-auto rounded-lg bg-white p-2 whitespace-pre-wrap">{d.dax_query}</pre>
      ) : (
        <p className="text-surface-600">{d.dax_query_error ?? 'No DAX query available.'}</p>
      )}
      {d.measures.map((m) => (
        <div key={m.name} className="mt-3">
          <div className="font-semibold">
            [{m.name}] <span className="font-normal text-surface-500">({m.table})</span>
          </div>
          <pre className="mt-1 overflow-auto rounded-lg bg-white p-2 whitespace-pre-wrap">{m.dax}</pre>
          {m.error && (
            <p className="mt-1">
              <span className="font-semibold">Why it wasn’t translated:</span> {m.error}
            </p>
          )}
          {m.rewrite && (
            <>
              <div className="mt-1 font-semibold">Accepted AI rewrite</div>
              <pre className="mt-1 overflow-auto rounded-lg bg-white p-2 whitespace-pre-wrap">{m.rewrite}</pre>
            </>
          )}
          {m.dependencies.length > 0 && (
            <ul className="mt-1 ml-4 list-disc">
              {m.dependencies.map((dep) => (
                <li key={dep.name}>
                  [{dep.name}]{' '}
                  <span className={dep.translated ? 'badge-green' : 'badge-red'}>
                    {dep.translated ? 'Translated' : 'Not translated'}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      ))}
    </div>
  )
}

export function QueryAudit({
  initialSearch = '',
  onOpenMeasure,
}: {
  initialSearch?: string
  onOpenMeasure?: (measure: string) => void
}) {
  const conversionId = useWizard((s) => s.conversionId)!
  const [view, setView] = useState<'queries' | 'no-sql'>('queries')
  const [kind, setKind] = useState('dashboard')
  const [source, setSource] = useState('all')
  const [page, setPage] = useState('')
  const [status, setStatus] = useState('all')
  const [search, setSearch] = useState(initialSearch)
  const [expanded, setExpanded] = useState<string | null>(null)
  const [editing, setEditing] = useState<QueryRecord | null>(null)

  const params: QueryAuditParams = { kind, source, page: page || undefined }
  const audit = useQuery({
    queryKey: ['query-audit', conversionId, kind, source, page],
    queryFn: () => auditApi.queryAudit(conversionId, params),
  })
  const summary = audit.data?.summary
  const records = useMemo(
    () =>
      (audit.data?.records ?? []).filter(
        (r) => (status === 'all' || r.status === status) && matchesQuerySearch(r, search),
      ),
    [audit.data, status, search],
  )
  const pages = useMemo(
    () => [...new Map((audit.data?.records ?? []).filter((r) => r.page).map((r) => [r.page!, r.page_name ?? r.page!])).entries()],
    [audit.data],
  )
  const exportParams: QueryAuditParams = {
    ...params,
    status: status === 'all' ? undefined : status,
    search: search.trim() || undefined,
  }
  const rowKey = (r: QueryRecord, i: number) =>
    `${r.kind}|${r.page}|${r.visual}|${r.check}|${r.attempt}|${i}`

  return (
    <div data-testid="query-audit" className="mb-6">
      <div className="mb-4 inline-flex gap-1 rounded-xl border border-black/[0.06] bg-surface-50 p-1">
        {(
          [
            ['queries', 'Queries'],
            ['no-sql', 'No SQL generated'],
          ] as const
        ).map(([value, label]) => (
          <button
            key={value}
            type="button"
            data-active={view === value}
            onClick={() => setView(value)}
            className="rounded-lg px-3 py-1.5 text-xs font-semibold text-surface-600 data-[active=true]:bg-brand/10 data-[active=true]:text-brand-dark"
          >
            {label}
          </button>
        ))}
      </div>

      {view === 'no-sql' && <NoSqlPanes onOpenMeasure={onOpenMeasure} />}

      {view === 'queries' && (
        <>
          {audit.isError && (
            <p role="alert" className="text-sm text-brand-red">
              {audit.error.message}
            </p>
          )}
          {summary && (
            <div className="mb-3 grid grid-cols-2 gap-2 md:grid-cols-5">
              <Card label="Queries" value={summary.total} />
              <Card label="Panes" value={summary.panes} />
              <Card label="OK" value={summary.ok} />
              <Card label="0 rows" value={summary.empty} />
              <Card label="Errors" value={summary.error} />
              <Card label="Not built" value={summary.plan_error} />
              <Card label="Cache hits" value={summary.cached} />
              <Card label="Slowest" value={summary.slowest_ms != null ? `${summary.slowest_ms} ms` : '—'} />
              <Card label="Average" value={summary.avg_ms != null ? `${summary.avg_ms} ms` : '—'} />
              <Card
                label="Warehouse / role"
                value={
                  [summary.warehouses.join(', '), summary.roles.join(', ')].filter(Boolean).join(' / ') || '—'
                }
              />
            </div>
          )}
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <select
              aria-label="Query kind"
              className="input !w-56"
              value={kind}
              onChange={(e) => setKind(e.target.value)}
            >
              {KIND_OPTIONS.map(([value, label]) => (
                <option key={value} value={value}>
                  {label} ({summary ? kindCount(summary.kinds, value) : 0})
                </option>
              ))}
            </select>
            <input
              className="input !w-56"
              placeholder="Search queries…"
              aria-label="Search queries"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <select aria-label="Page" className="input !w-44" value={page} onChange={(e) => setPage(e.target.value)}>
              <option value="">All pages</option>
              {pages.map(([id, name]) => (
                <option key={id} value={id}>
                  {name}
                </option>
              ))}
            </select>
            <select aria-label="Status" className="input !w-36" value={status} onChange={(e) => setStatus(e.target.value)}>
              <option value="all">All statuses</option>
              <option value="ok">OK</option>
              <option value="empty">0 rows</option>
              <option value="error">Error</option>
              <option value="plan_error">Not built</option>
              <option value="cached">Cached</option>
            </select>
            <select aria-label="Source" className="input !w-44" value={source} onChange={(e) => setSource(e.target.value)}>
              <option value="all">Editor + published</option>
              <option value="editor">Editor</option>
              <option value="published">Published</option>
            </select>
            <a className="btn-secondary !text-xs" href={auditApi.queryAuditExportUrl(conversionId, 'xlsx', exportParams)}>
              Download Excel
            </a>
            <a className="btn-secondary !text-xs" href={auditApi.queryAuditExportUrl(conversionId, 'json', exportParams)}>
              Download JSON
            </a>
          </div>

          {summary && summary.sql_logging === false && (
            <p className="mb-3 rounded-lg bg-brand-amber/10 p-2 text-xs text-brand-amber">
              SQL logging is off, so query text isn’t recorded. Turn on SQL logging to see the SQL of
              each query.
            </p>
          )}
          {audit.isSuccess && audit.data.records.length === 0 && (
            <p className="text-sm text-surface-600">
              No queries logged yet. Open the dashboard preview or run Convert, and every query sent
              to Snowflake appears here.
            </p>
          )}

          {records.length > 0 && (
            <table className="w-full text-xs">
              <thead className="bg-surface-100 text-left">
                <tr>
                  <th className="px-3 py-1.5">Page</th>
                  <th className="px-2 py-1.5">Pane</th>
                  <th className="px-2 py-1.5">Check</th>
                  <th className="px-2 py-1.5">Status</th>
                  <th className="px-2 py-1.5">Rows</th>
                  <th className="px-2 py-1.5">Time</th>
                  <th className="px-2 py-1.5">Warehouse / role</th>
                </tr>
              </thead>
              <tbody>
                {records.map((r, i) => {
                  const key = rowKey(r, i)
                  return (
                    <RecordRow
                      key={key}
                      record={r}
                      open={expanded === key}
                      onToggle={() => setExpanded(expanded === key ? null : key)}
                      onEdit={setEditing}
                      onOpenMeasure={onOpenMeasure}
                    />
                  )
                })}
              </tbody>
            </table>
          )}
          {editing && editing.page && editing.visual && (
            <div className="mt-4">
              <SqlEditor page={editing.page} visual={editing.visual} onClose={() => setEditing(null)} />
            </div>
          )}
        </>
      )}
    </div>
  )
}

function RecordRow({
  record,
  open,
  onToggle,
  onEdit,
  onOpenMeasure,
}: {
  record: QueryRecord
  open: boolean
  onToggle: () => void
  onEdit: (r: QueryRecord) => void
  onOpenMeasure?: (m: string) => void
}) {
  return (
    <>
      <tr className="cursor-pointer border-t border-surface-100 hover:bg-surface-100/60" onClick={onToggle}>
        <td className="px-3 py-1.5">{record.page_name ?? '—'}</td>
        <td className="px-2 py-1.5 font-semibold">
          {record.pane}
          {record.sql_override && <span className="badge-blue ml-1">Edited SQL</span>}
          {record.attempt === 'fallback' && <span className="badge-amber ml-1">Fallback</span>}
        </td>
        <td className="px-2 py-1.5 text-surface-600">{record.check ?? record.kind}</td>
        <td className="px-2 py-1.5">
          <span className={STATUS_BADGE[record.status]}>{STATUS_LABEL[record.status]}</span>
        </td>
        <td className="px-2 py-1.5">{record.row_count ?? '—'}</td>
        <td className="px-2 py-1.5">{record.elapsed_ms != null ? `${record.elapsed_ms} ms` : '—'}</td>
        <td className="px-2 py-1.5 text-surface-600">
          {[record.warehouse, record.role].filter(Boolean).join(' / ') || '—'}
        </td>
      </tr>
      {open && (
        <tr>
          <td colSpan={7}>
            <Detail record={record} onEdit={onEdit} onOpenMeasure={onOpenMeasure} />
          </td>
        </tr>
      )}
    </>
  )
}
