import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { MfaPasscodePrompt } from '../components/MfaPasscodePrompt'
import { ConnectStep } from '../steps/ConnectStep'
import { useWizard } from '../store/wizard'

function renderStep() {
  const qc = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  })
  return render(
    <QueryClientProvider client={qc}>
      <ConnectStep />
    </QueryClientProvider>,
  )
}

const base = { id: 'p1', name: 'demo', account: 'a', user: 'u', auth_method: 'password' }

interface Mock {
  profile: Record<string, unknown>
  session: Record<string, unknown>
  testBodies: Array<Record<string, unknown>>
  patches: Array<Record<string, unknown>>
  testResult?: Record<string, unknown>
}

function stubApi(m: Mock) {
  vi.stubGlobal(
    'fetch',
    vi.fn(async (url: string, init?: RequestInit) => {
      if (url.endsWith('/connections') && !init?.method)
        return new Response(JSON.stringify([m.profile]))
      if (url.includes('/connections/p1/session')) return new Response(JSON.stringify(m.session))
      if (url.endsWith('/connections/p1') && init?.method === 'PATCH') {
        const body = JSON.parse(String(init.body))
        m.patches.push(body)
        m.profile = { ...m.profile, ...body }
        return new Response(JSON.stringify(m.profile))
      }
      if (url.endsWith('/connections/p1/test') && init?.method === 'POST') {
        m.testBodies.push(init.body ? JSON.parse(String(init.body)) : {})
        return new Response(JSON.stringify(m.testResult ?? { ok: true, latency_ms: 5 }))
      }
      if (url.endsWith('/source-types'))
        return new Response(
          JSON.stringify([{ id: 'snowflake', label: 'Snowflake', available: true }]),
        )
      return new Response(JSON.stringify([]))
    }),
  )
}

describe('MfaPasscodePrompt', () => {
  it('submits only valid 6-8 digit codes, strips non-digits and clears', async () => {
    const onSubmit = vi.fn()
    render(<MfaPasscodePrompt pending={false} onSubmit={onSubmit} />)
    const user = userEvent.setup()
    const input = screen.getByLabelText('MFA code')
    expect(screen.getByTestId('mfa-prompt')).toHaveTextContent(/Snowflake requires MFA/)
    await user.type(input, '12ab34')
    expect(input).toHaveValue('1234')
    await user.keyboard('{Enter}')
    expect(onSubmit).not.toHaveBeenCalled()
    await user.type(input, '56')
    await user.keyboard('{Enter}')
    expect(onSubmit).toHaveBeenCalledWith('123456')
    expect(input).toHaveValue('')
  })

  it('shows pending text, error alert and cancel', async () => {
    const onCancel = vi.fn()
    render(
      <MfaPasscodePrompt
        required={false}
        pending
        error="bad code"
        onSubmit={() => {}}
        onCancel={onCancel}
      />,
    )
    expect(screen.getByRole('button', { name: 'Signing in…' })).toBeDisabled()
    expect(screen.getByRole('alert')).toHaveTextContent('bad code')
    await userEvent.setup().click(screen.getByRole('button', { name: 'Cancel' }))
    expect(onCancel).toHaveBeenCalled()
  })
})

describe('ConnectStep sessions (phase 02)', () => {
  beforeEach(() => useWizard.getState().reset())
  afterEach(() => vi.restoreAllMocks())

  it('shows the active session status line with warehouse and role', async () => {
    stubApi({
      profile: { ...base, warehouse: 'WH', role: 'ANALYST', auth_method: 'key_pair' },
      session: { authenticated: true, verified: true, checked_at: 1_700_000_000, settings_error: null },
      testBodies: [],
      patches: [],
    })
    renderStep()
    await waitFor(() =>
      expect(screen.getByTestId('session-status')).toHaveTextContent(/Session active · checked/),
    )
    expect(screen.getByText(/WH WH · role ANALYST/)).toBeInTheDocument()
  })

  it('shows expired and MFA status texts', async () => {
    stubApi({
      profile: { ...base, warehouse: 'WH' },
      session: { authenticated: false, expired: true, mfa_enforced: true, mfa_required: true },
      testBodies: [],
      patches: [],
    })
    renderStep()
    await waitFor(() =>
      expect(screen.getByTestId('session-status')).toHaveTextContent(
        'Session expired — enter your MFA code to sign in again',
      ),
    )
    expect(screen.getByTestId('mfa-prompt')).toHaveTextContent(/requires MFA/)
  })

  it('forces the editor open when the warehouse is missing and Save PATCHes', async () => {
    const m: Mock = {
      profile: { ...base, warehouse: '', auth_method: 'key_pair' },
      session: { authenticated: false },
      testBodies: [],
      patches: [],
    }
    stubApi(m)
    renderStep()
    const user = userEvent.setup()
    await screen.findByText(/Warehouse required — set it/)
    const save = screen.getByRole('button', { name: 'Save' })
    expect(save).toBeDisabled()
    await user.type(screen.getByLabelText('Warehouse'), 'COMPUTE_WH')
    await user.click(save)
    await waitFor(() => expect(m.patches).toEqual([{ warehouse: 'COMPUTE_WH', role: null }]))
    await waitFor(() => expect(m.testBodies.length).toBe(1))
  })

  it('submits the MFA code and sends force when re-entering', async () => {
    const m: Mock = {
      profile: { ...base, warehouse: 'WH' },
      session: { authenticated: false, mfa_required: true },
      testBodies: [],
      patches: [],
    }
    stubApi(m)
    renderStep()
    const user = userEvent.setup()
    await user.type(await screen.findByLabelText('MFA code'), '123456')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))
    await waitFor(() => expect(m.testBodies).toEqual([{ passcode: '123456' }]))
  })

  it('re-enter MFA code sends force: true when signed in', async () => {
    const m: Mock = {
      profile: { ...base, warehouse: 'WH' },
      session: { authenticated: true, verified: true, checked_at: 1_700_000_000 },
      testBodies: [],
      patches: [],
    }
    stubApi(m)
    renderStep()
    const user = userEvent.setup()
    await user.click(await screen.findByText('Re-enter MFA code'))
    await user.type(screen.getByLabelText('MFA code'), '654321')
    await user.click(screen.getByRole('button', { name: 'Sign in' }))
    await waitFor(() => expect(m.testBodies).toEqual([{ passcode: '654321', force: true }]))
  })

  it('shows the SSO link while a browser sign-in is pending', async () => {
    const m: Mock = {
      profile: { ...base, warehouse: 'WH', auth_method: 'external_browser' },
      session: { authenticated: false, sso_url: 'https://sso.example/login' },
      testBodies: [],
      patches: [],
    }
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.endsWith('/connections') && !init?.method)
          return new Response(JSON.stringify([m.profile]))
        if (url.includes('/connections/p1/session')) return new Response(JSON.stringify(m.session))
        if (url.endsWith('/connections/p1/test')) return new Promise<Response>(() => {})
        return new Response(JSON.stringify([]))
      }),
    )
    renderStep()
    const user = userEvent.setup()
    await user.click(await screen.findByRole('button', { name: 'Authenticate' }))
    const link = await screen.findByText(/Browser didn.t open\? Click here to sign in/)
    expect(link).toHaveAttribute('href', 'https://sso.example/login')
  })
})
