"""Compilation audit log, harness additions and the slicer value check (phase 07)."""

from __future__ import annotations

import io
import json

import pytest
from fastapi.testclient import TestClient

from app.dax.compiler import MeasureCompiler
from app.runtime.dashboard import VisualSpec, compile_dashboard
from app.runtime.engine import DimensionRef, MeasureFilter, MeasureRefSpec, QuerySpec
from app.services.compilation_logger import (
    CompilationLogger,
    build_audit_json,
    build_audit_xlsx,
    dax_complexity,
    load_compilation_log,
    sql_complexity,
    summarize_records,
)
from app.validation.harness import (
    CachingCursor,
    CheckStatus,
    STATIC_VISUAL_TYPES,
    ValidationHarness,
    run_validation,
)
from app.validation.value_check import run_value_check, value_assumptions, value_check_sql
from tests.duck import DuckWorld
from tests.fakes import DuckCursor
from tests.test_ai_rewrite import HARD, make_bundle, make_world


def logged_world(tmp_path):
    w = make_world({"Plain": "[Total] * 2"})
    log = CompilationLogger(tmp_path)
    log.initialize_for_conversion("cid")
    comp = MeasureCompiler(w.model, logger=log)
    for name in ("Total", "Hard", "Plain"):
        try:
            comp.compile_measure(name)
        except Exception:  # noqa: BLE001 - Hard fails by design
            pass
    return w, log


def test_records_for_every_compilation(tmp_path):
    w, log = logged_world(tmp_path)
    by = {r["measure_name"]: r for r in log.records()}
    assert by["Total"]["compiler_type"] == "tier1" and by["Total"]["overall_status"] == "working"
    assert by["Hard"]["compilation_status"] == "failed"
    assert by["Hard"]["compiler_type"] == "parked" and by["Hard"]["overall_status"] == "broken"
    assert by["Total"]["dax_leaves"][0]["sql"].startswith("SUM(")
    assert by["Plain"]["model_table"] == "Sales"


def test_patches_are_merged_and_summary_numbers(tmp_path):
    w, log = logged_world(tmp_path)
    log.annotate_tier("Hard", "tier2")
    log.annotate_sql("Total", 'SELECT SUM("Sales"."Amount")', None, "visual:p/v:main")
    log.annotate_validation("Plain", False, "boom")
    log.annotate_validation("Total", True)
    path = log.path
    records, summary = load_compilation_log(path)
    by = {r["measure_name"]: r for r in records}
    assert by["Hard"]["compiler_type"] == "tier2" and by["Hard"]["overall_status"] == "working"
    assert by["Total"]["generated_sql"].startswith("SELECT SUM")
    assert by["Total"]["sql_samples"][0]["context"] == "visual:p/v:main"
    assert by["Plain"]["overall_status"] == "degraded" and by["Plain"]["validation_error"] == "boom"
    assert summary["total"] == 3 and summary["working"] == 2 and summary["degraded"] == 1
    assert summary["broken"] == 0 and summary["percentage_working"] == pytest.approx(66.7)
    assert summary["by_compiler_type"] == {"tier1": 2, "tier2": 1}
    live = log.summary()
    assert live["total"] == 3 and live["degraded"] == 1


def test_measures_without_sql_skips_failures_and_internal_names(tmp_path):
    w, log = logged_world(tmp_path)
    log.annotate_sql("Total", "SELECT 1", None, None)
    assert log.measures_without_sql() == ["Plain"]


def test_complexity_scores():
    assert dax_complexity("SUM(T[a])") == 0.109  # 9/1000 + paren depth 1 / 10
    heavy = dax_complexity(
        "CALCULATE(SUMX(FILTER(T, T[a] > 1), T[b]), DATESINPERIOD(D[d], 1, -1, MONTH))"
    )
    assert heavy == pytest.approx(0.078 + 4 * 0.08 + 0.2, abs=0.005)
    assert dax_complexity("x" * 5000) == 0.3
    assert dax_complexity("CALCULATE(" * 20 + ")" * 20) <= 1.0
    assert sql_complexity("SELECT 1") == 0.003
    big = (
        "WITH a AS (SELECT 1) " + "JOIN x " * 12 + "GROUP BY a " * 6 + "CASE " * 6
        + "WITH " * 4 + "y" * 9000
    )  # fmt: skip
    assert sql_complexity(big) == pytest.approx(0.3 + 0.2 + 0.2 + 0.15 + 0.15, abs=1e-3)


def test_xlsx_and_json_builders(tmp_path):
    from openpyxl import load_workbook

    w, log = logged_world(tmp_path)
    log.annotate_sql("Total", 'SELECT SUM("x")', None, None)
    records, summary = load_compilation_log(log.path)
    data = build_audit_xlsx(records, summary, "cid")
    wb = load_workbook(io.BytesIO(data))
    assert wb.sheetnames == ["Summary", "Queries", "Measures"]
    queries = [[c.value for c in row] for row in wb["Queries"].iter_rows()]
    assert queries[0][:3] == ["Measure", "Table", "Compiler"]
    assert any(r[0] == "Total" and r[4] == 'SELECT SUM("x")' for r in queries)
    doc = build_audit_json(records, summary, "cid")
    assert doc["kind"] == "dax_compilation_audit" and doc["conversion_id"] == "cid"
    assert doc["schema_version"] and len(doc["records"]) == 3
    assert summarize_records([])["percentage_working"] == 0.0


def test_initialize_starts_a_fresh_file(tmp_path):
    log = CompilationLogger(tmp_path)
    p1 = log.initialize_for_conversion("a")
    log.annotate_tier("x", "tier2")
    p2 = log.initialize_for_conversion("a")
    assert p1 == p2 and p2.read_text() == ""


def test_compile_dashboard_annotates_tier2_and_parked(tmp_path):
    w = make_world()
    bundle = make_bundle(w, ["Total", "Hard"])
    log = CompilationLogger(tmp_path)
    log.initialize_for_conversion("cid")
    compile_dashboard(bundle, tier2_sql={"Hard": "SELECT 1"}, compilation_log=log)
    recs = {r["measure_name"]: r for r in log.records()}
    assert recs["Hard"]["compiler_type"] == "tier2"
    log2 = CompilationLogger(tmp_path)
    log2.initialize_for_conversion("cid2")
    compile_dashboard(bundle, compilation_log=log2)
    assert {r["measure_name"]: r for r in log2.records()}["Hard"]["compiler_type"] == "parked"


def test_engine_annotates_sql_for_named_measures(tmp_path):
    w, log = logged_world(tmp_path)
    from app.runtime.engine import SemanticEngine

    engine = SemanticEngine(w.model, w.bindings, logger=log)
    sql, _ = engine.build_sql(QuerySpec(measures=[MeasureRefSpec(name="Plain")]), sql_context="visual:p/v:main")
    rec = {r["measure_name"]: r for r in log.records()}["Plain"]
    assert rec["generated_sql"] == sql and rec["sql_samples"][0]["context"] == "visual:p/v:main"
    assert rec["sql_complexity"] is not None


@pytest.fixture()
def api(tmp_path, monkeypatch, contoso_pbip):
    from app.api.deps import get_ingest_service
    from app.main import app
    from app.services.ingest import IngestService

    svc = IngestService(tmp_path / "storage")
    app.dependency_overrides[get_ingest_service] = lambda: svc
    with TestClient(app) as c:
        yield c, svc
    app.dependency_overrides.clear()


def test_compilation_logs_endpoint(api, contoso_pbip):
    c, svc = api
    stored = svc.ingest_folder(contoso_pbip)
    url = f"/api/v1/conversions/{stored.id}/compilation-logs"
    before = c.get(url)
    assert before.status_code == 404 and "run the conversion first" in before.text
    w, log = logged_world(svc.conversion_dir(stored.id))
    log.initialize_for_conversion(stored.id)
    comp = MeasureCompiler(w.model, logger=log)
    comp.compile_measure("Total")
    try:
        comp.compile_measure("Hard")
    except Exception:  # noqa: BLE001
        pass
    body = c.get(url).json()
    assert body["summary"]["total"] == 2 and body["summary"]["broken"] == 1
    assert [r["measure_name"] for r in body["sample_failures"]] == ["Hard"]
    assert {r["measure_name"] for r in body["logs"]} == {"Total", "Hard"}


# ------------------------------------------------------------------ harness


def spec_with(w, visuals):
    from app.ir.report import Page, Report, ReportBundle

    bundle = ReportBundle(
        source_path="x", model=w.model, report=Report(pages=[Page(name="p", display_name="P", visuals=visuals)])
    )
    return compile_dashboard(bundle)[0]


def test_static_visuals_do_not_hide_a_failing_data_pane():
    from app.ir.report import Visual, VisualField, VisualPosition

    w = make_world()
    pos = VisualPosition(x=0, y=0, width=1, height=1)
    visuals = [
        Visual(name="txt", visual_type="textbox", position=pos),
        Visual(name="btn", visual_type="actionButton", position=pos),
        Visual(
            name="bad",
            visual_type="card",
            position=pos,
            fields=[VisualField(role="Values", table="Sales", name="Hard", is_measure=True)],
        ),
    ]
    spec = spec_with(w, visuals)
    report = run_validation(spec, w.engine(), DuckCursor(w))
    s = report.summary()
    assert "actionButton" in STATIC_VISUAL_TYPES
    assert s["visuals_total"] == 3 and s["data_visuals_total"] == 1
    assert s["data_visuals_passed"] == 0 and s["data_score"] < s["overall_score"]
    assert s["pages_data"]["P"] == s["data_score"]


def test_edited_sql_columns_check_and_totals_skipped():
    from app.ir.report import Visual, VisualField, VisualPosition

    w = make_world()
    pos = VisualPosition(x=0, y=0, width=1, height=1)
    visual = Visual(
        name="v",
        visual_type="clusteredColumnChart",
        position=pos,
        fields=[
            VisualField(role="Category", table="Dim", name="Name"),
            VisualField(role="Y", table="Sales", name="Hard", is_measure=True),
        ],
    )
    spec = spec_with(w, [visual])
    vs = spec.pages[0].visuals[0]
    assert vs.data_status == "untranslated" and vs.draft_query is not None
    harness = ValidationHarness(w.engine(), DuckCursor(w))
    ok_sql = 'SELECT \'a\' AS "Dim.Name", 1.5 AS "Hard"'
    good = harness.validate_visual("p", vs, main_sql=ok_sql)
    names = {c.name: c for c in good.checks}
    assert names["compile"].status == CheckStatus.SKIPPED and "pane uses edited SQL" in names["compile"].detail
    assert names["columns"].status == CheckStatus.PASSED
    assert names["totals"].status == CheckStatus.SKIPPED and "edited SQL" in names["totals"].detail
    assert good.sql_override is True
    bad = harness.validate_visual("p", vs, main_sql="SELECT 1 AS \"Hard\"")
    columns = next(c for c in bad.checks if c.name == "columns")
    assert columns.status == CheckStatus.FAILED and "Dim.Name" in columns.detail


def test_measure_filter_skips_totals_and_totals_still_run_otherwise():
    w = DuckWorld(
        {"F": (["K", "Amt"], [(1, 10.0), (2, 3.0)]), "D": (["Id", "Name"], [(1, "a"), (2, "b")])},
        rels=[("F", "K", "D", "Id")],
        measures={"Total": "SUM(F[Amt])"},
    )
    vs = VisualSpec(
        name="v", visual_type="clusteredColumnChart", x=0, y=0, width=1, height=1,
        query=QuerySpec(
            dimensions=[DimensionRef(table="D", column="Name")],
            measures=[MeasureRefSpec(name="Total")],
            measure_filters=[MeasureFilter(measure="Total", op="gt", values=[5])],
        ),
        dim_keys=["D.Name"], measure_keys=["Total"],
    )  # fmt: skip
    harness = ValidationHarness(w.engine(), DuckCursor(w))
    score = harness.validate_visual("p", vs)
    totals = next(c for c in score.checks if c.name == "totals")
    assert totals.status == CheckStatus.SKIPPED and "measure filter" in totals.detail
    plain = vs.model_copy(deep=True)
    plain.query.measure_filters = []
    again = harness.validate_visual("p", plain)
    assert next(c for c in again.checks if c.name == "totals").status == CheckStatus.PASSED


def test_caching_cursor_reraises_cached_failures_once_executed():
    calls = []

    class C:
        description = [("x",)]

        def execute(self, sql, *a):
            calls.append(sql)
            if "bad" in sql:
                raise RuntimeError("nope")

        def fetchall(self):
            return [(1,)]

    cache: dict = {}
    cur = CachingCursor(C(), cache)
    for _ in range(3):
        with pytest.raises(RuntimeError):
            cur.execute("bad")
    assert calls == ["bad"]


# ------------------------------------------------------------------ slicer value check


def value_world():
    return DuckWorld(
        {"Sel": (["Text"], [("10",), ("All",), ("abc",), ("x y",), (None,)])},
        measures={
            "Val": 'VAR s = TRIM(SELECTEDVALUE(Sel[Text])) RETURN IF(s = "All", 0, IFERROR(VALUE(s), -1))'
        },
    )


def test_value_assumptions_and_sql():
    w = value_world()
    assert value_assumptions(w.model) == {("Sel", "Text"): ("All",)}
    sql = value_check_sql("DB.PUBLIC.SEL", "Sel", "Text", ("All",))
    assert "UPPER(TRIM(" in sql and "NOT IN (UPPER('All'))" in sql and "IS NOT NULL" in sql


def test_value_check_reports_offending_values():
    w = value_world()
    result = run_value_check(w.engine(), w.model, DuckCursor(w))
    assert result == [
        {"table": "Sel", "column": "Text", "literals": ["All"], "offending": ["abc", "x y"], "error": None}
    ]


def test_value_check_clean_and_error_events(tmp_path):
    from app.agents.pipeline import ConversionRun, _value_check

    w = DuckWorld(
        {"Sel": (["Text"], [("10",), ("All",)])},
        measures={
            "Val": 'VAR s = TRIM(SELECTEDVALUE(Sel[Text])) RETURN IF(s = "All", 0, IFERROR(VALUE(s), -1))'
        },
    )
    bundle = make_bundle(w, [])
    run = ConversionRun(conversion_id="c")
    _value_check(run, w.engine(), bundle, DuckCursor(w))
    assert run.events[-1]["message"] == (
        "Sel[Text] holds only numbers and 'All': IFERROR measures using it translate exactly"
    )
    run2 = ConversionRun(conversion_id="c")
    _value_check(run2, w.engine(), bundle, DuckCursor(w, fail_when=lambda sql, n: "TRY_CAST" in sql))
    assert run2.events[-1]["message"].startswith("could not check the values of Sel[Text]:")
    bad = value_world()
    run3 = ConversionRun(conversion_id="c")
    _value_check(run3, bad.engine(), make_bundle(bad, []), DuckCursor(bad))
    msg = run3.events[-1]["message"]
    assert msg.startswith("Sel[Text] has values that make VALUE() fail in Power BI (neither numbers nor 'All'):")
    assert "'abc', 'x y'" in msg and "exactly like Power BI" in msg


def test_unused_imports_guard():
    assert json and HARD
