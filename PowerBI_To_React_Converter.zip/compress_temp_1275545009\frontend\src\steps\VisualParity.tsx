import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Eye, FileUp, History, ImageUp, Loader2, ScanSearch } from 'lucide-react'
import { useState } from 'react'
import { parityApi } from '../api/client'
import type { ParityPage, ReferenceUploadResult } from '../api/types'
import { SearchableSelect } from '../components/SearchableSelect'
import { fetchDashboardSpec } from '../dashboard/api'
import type { PageSpec } from '../dashboard/types'
import { ComparisonDetail, SimilarityBadge } from '../dashboard/parity/ComparisonDetail'
import { PageHistory } from '../dashboard/parity/PageHistory'
import { useApplyFixes } from '../dashboard/parity/useApplyFixes'
import { useParityRunner } from '../dashboard/parity/useParityRunner'

/** AI vision review: PBI PDF export (or screenshot) vs the converted render. */
export function VisualParity({
  conversionId,
  connectionId,
}: {
  conversionId: string
  connectionId?: string | null
}) {
  const qc = useQueryClient()
  // fall back to the first registered warehouse profile
  const conns = useQuery({
    queryKey: ['connections'],
    queryFn: async (): Promise<{ id: string }[]> => {
      const res = await fetch('/api/v1/connections')
      if (!res.ok) throw new Error('failed to load connections')
      return res.json()
    },
    enabled: !connectionId,
  })
  const effectiveConn = connectionId ?? conns.data?.[0]?.id
  const [pageName, setPageName] = useState<string>()
  const [refFile, setRefFile] = useState<File>()
  const [uploadingPdf, setUploadingPdf] = useState(false)
  const [matchByContent, setMatchByContent] = useState(false)
  const [upload, setUpload] = useState<ReferenceUploadResult | null>(null)
  const [running, setRunning] = useState(false)
  const [progress, setProgress] = useState('')
  const [error, setError] = useState('')
  const [showHistory, setShowHistory] = useState(false)

  const runner = useParityRunner({ conversionId, connectionId: effectiveConn })
  const fixes = useApplyFixes(conversionId, pageName)

  const spec = useQuery({
    queryKey: ['dash-spec', conversionId],
    queryFn: () => fetchDashboardSpec(conversionId),
  })
  const stored = useQuery({
    queryKey: ['visual-compare', conversionId],
    queryFn: () => parityApi.list(conversionId),
  })
  const refs = useQuery({
    queryKey: ['visual-compare-refs', conversionId],
    queryFn: () => parityApi.references(conversionId),
  })

  const pages = spec.data?.pages ?? []
  const page: PageSpec | undefined = pages.find((p) => p.name === pageName) ?? pages[0]
  const refReady = new Set(
    (refs.data?.pages ?? []).filter((p) => p.has_reference).map((p) => p.page),
  )
  const pageHasReference = !!page && (refReady.has(page.name) || !!refFile)

  const uploadPdf = async (file: File) => {
    setUploadingPdf(true)
    setError('')
    setUpload(null)
    try {
      const body = await parityApi.uploadReferencePdf(conversionId, file, matchByContent)
      setUpload(body)
      await Promise.all([
        qc.invalidateQueries({ queryKey: ['visual-compare-refs', conversionId] }),
        qc.invalidateQueries({ queryKey: ['visual-compare', conversionId] }),
      ])
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setUploadingPdf(false)
    }
  }

  const runOne = async () => {
    if (!page || !effectiveConn) return
    setRunning(true)
    setError('')
    try {
      await runner.comparePage(page, { manualRef: refFile, onStage: setProgress })
      await qc.invalidateQueries({ queryKey: ['visual-compare', conversionId] })
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setProgress('')
      setRunning(false)
    }
  }

  const remainingWithRefs = pages.filter((p) => refReady.has(p.name))
  const runAll = async () => {
    setError('')
    setRunning(true)
    try {
      for (const p of remainingWithRefs) {
        setPageName(p.name)
        setProgress(`Comparing ${p.display_name}…`)
        try {
          await runner.comparePage(p, { onStage: (m) => setProgress(`${p.display_name}: ${m}`) })
        } catch (e) {
          setError(`${p.display_name}: ${(e as Error).message}`)
          break
        }
      }
    } finally {
      setProgress('')
      setRunning(false)
    }
    await qc.invalidateQueries({ queryKey: ['visual-compare', conversionId] })
  }

  const result: ParityPage | undefined = stored.data?.pages.find((p) => p.page === page?.name)

  const applyFixes = async (findingIds: string[]) => {
    if (!page) return
    setError('')
    const appliedCount = await fixes.applyFixes(findingIds)
    // a fix landed: re-render + re-capture + re-compare so the side-by-side
    // image, similarity and findings visibly reflect the change
    if (appliedCount > 0 && effectiveConn && (refReady.has(page.name) || refFile)) {
      setRunning(true)
      setProgress('Fix applied — re-rendering and re-comparing…')
      try {
        await runner.comparePage(page.name, { manualRef: refFile })
        await qc.invalidateQueries({ queryKey: ['visual-compare', conversionId] })
      } catch (e) {
        setError(`fix applied, but re-compare failed: ${(e as Error).message}`)
      } finally {
        setProgress('')
        setRunning(false)
      }
    }
  }
  const shownError = error || fixes.error

  return (
    <div className="card mt-6 p-0">
      <div className="flex items-center justify-between border-b border-surface-300 px-5 py-4">
        <div>
          <h3 className="flex items-center gap-2 text-sm font-bold">
            <ScanSearch size={16} strokeWidth={1.8} className="text-brand-dark" />
            Visual parity review
            <span className="badge-blue">AI vision</span>
          </h3>
          <p className="mt-0.5 text-xs text-surface-600">
            Export the original report to PDF in Power BI (File → Export → PDF) and upload it
            once — every page is matched automatically. GPT-4o then compares each converted page
            against the original and reports series, layout, color and formatting differences the
            numeric checks can't see.
          </p>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-3 px-5 py-4">
        <label className="btn-primary flex cursor-pointer items-center gap-2 !text-xs">
          {uploadingPdf ? (
            <>
              <Loader2 size={14} className="animate-spin" /> Splitting pages…
            </>
          ) : (
            <>
              <FileUp size={14} strokeWidth={1.8} /> Upload PBI PDF export
            </>
          )}
          <input
            type="file"
            accept="application/pdf"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && uploadPdf(e.target.files[0])}
          />
        </label>

        {refReady.size > 0 && (
          <span className="badge-green">
            {refReady.size}/{pages.length} references ready
          </span>
        )}

        <button
          className="btn-secondary flex items-center gap-2 !text-xs"
          disabled={running || uploadingPdf || remainingWithRefs.length === 0 || !effectiveConn}
          onClick={runAll}
        >
          <Eye size={14} strokeWidth={1.8} /> Compare all pages
        </button>

        {progress && (
          <span className="flex items-center gap-1.5 text-xs text-surface-600">
            <Loader2 size={12} className="animate-spin" /> {progress}
          </span>
        )}
        <label className="flex items-center gap-1.5 text-xs text-surface-700">
          <input
            type="checkbox"
            checked={matchByContent}
            onChange={(e) => setMatchByContent(e.target.checked)}
          />
          Match pages by content
        </label>
        {shownError && <span className="text-xs text-brand-red">{shownError}</span>}
      </div>

      {upload && (
        <div data-testid="upload-result" className="border-t border-surface-200 px-5 py-3 text-xs">
          <div className="mb-2 flex flex-wrap items-center gap-2 text-surface-700">
            <span className={upload.mode === 'content' ? 'badge-blue' : 'badge-green'}>
              {upload.mode === 'content' ? 'matched by content' : 'matched by page order'}
            </span>
            <span>
              {upload.pdf_pages} PDF pages · {upload.report_pages} report pages ·{' '}
              {upload.references_stored.length} references stored
            </span>
            {upload.superseded_comparisons > 0 && (
              <span className="badge-amber">
                {upload.superseded_comparisons} earlier comparison
                {upload.superseded_comparisons === 1 ? '' : 's'} superseded
              </span>
            )}
          </div>
          {upload.warnings.length > 0 && (
            <ul className="mb-2 list-disc pl-5 text-brand-amber">
              {upload.warnings.map((w, i) => (
                <li key={i}>{w}</li>
              ))}
            </ul>
          )}
          {upload.matches.length > 0 && (
            <table className="w-full max-w-2xl text-left">
              <thead>
                <tr className="border-b border-surface-300 text-[10px] tracking-wide text-surface-500 uppercase">
                  <th className="py-1 pr-3">PDF page</th>
                  <th className="py-1 pr-3">Report page</th>
                  <th className="py-1">Match</th>
                </tr>
              </thead>
              <tbody>
                {upload.matches.map((m) => (
                  <tr key={m.pdf_page} className="border-b border-surface-200">
                    <td className="py-1 pr-3">{m.pdf_page}</td>
                    <td className="py-1 pr-3 font-semibold">
                      {m.page ? m.display_name : <span className="text-surface-500">not matched</span>}
                    </td>
                    <td className="py-1">
                      {m.page && (
                        <span className={m.confident ? 'badge-green' : 'badge-amber'}>
                          {Math.round(m.score * 100)}%{m.confident ? '' : ' · low confidence'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      <div className="flex flex-wrap items-center gap-3 border-t border-surface-200 px-5 py-3">
        <SearchableSelect
          ariaLabel="Page"
          itemLabel="pages"
          className="!w-56"
          value={page?.name ?? null}
          onChange={setPageName}
          options={pages.map((p) => ({
            value: p.name,
            label: `${p.display_name}${refReady.has(p.name) ? ' ✓' : ''}`,
          }))}
        />

        <label className="btn-secondary flex cursor-pointer items-center gap-2 !text-xs">
          <ImageUp size={14} strokeWidth={1.8} />
          {refFile ? refFile.name : 'Screenshot instead…'}
          <input
            type="file"
            accept="image/png,image/jpeg"
            className="hidden"
            onChange={(e) => setRefFile(e.target.files?.[0])}
          />
        </label>

        <button
          className="btn-secondary flex items-center gap-2 !text-xs"
          disabled={!pageHasReference || !page || running || !effectiveConn}
          onClick={runOne}
        >
          {running && !progress ? (
            <>
              <Loader2 size={14} className="animate-spin" /> Comparing…
            </>
          ) : (
            <>
              <Eye size={14} strokeWidth={1.8} /> Compare this page
            </>
          )}
        </button>

        {!pageHasReference && page && (
          <span className="text-xs text-surface-500">
            no reference for this page yet — upload the PDF or a screenshot
          </span>
        )}
      </div>

      {result && page && (
        <div className="border-t border-surface-300 px-5 py-4">
          <ComparisonDetail
            conversionId={conversionId}
            comparison={result.similarity === null ? null : result}
            values={result.values}
            applying={fixes.applying}
            onApplyFixes={applyFixes}
          />
          <div className="mt-4">
            <button
              className="flex items-center gap-1.5 text-xs font-semibold text-brand-dark"
              onClick={() => setShowHistory((v) => !v)}
            >
              <History size={13} strokeWidth={1.8} /> {showHistory ? 'Hide run history' : 'Run history'}
            </button>
            {showHistory && (
              <div className="mt-2">
                <PageHistory conversionId={conversionId} page={page.name} />
              </div>
            )}
          </div>
        </div>
      )}

      {/* summary strip when several pages have been compared */}
      {(stored.data?.pages.length ?? 0) > 1 && (
        <div className="flex flex-wrap gap-2 border-t border-surface-200 px-5 py-3">
          {stored.data!.pages.map((p) => (
            <button
              key={p.page}
              onClick={() => setPageName(p.page)}
              className="flex items-center gap-2 rounded-lg border border-surface-300 px-2.5 py-1.5 text-xs hover:bg-surface-100"
            >
              <span className="font-semibold">{p.display_name}</span>
              <SimilarityBadge value={p.similarity} />
            </button>
          ))}
        </div>
      )}

      {/* offscreen render target (captured at native PBI page size) */}
      {runner.captureHost}
    </div>
  )
}
