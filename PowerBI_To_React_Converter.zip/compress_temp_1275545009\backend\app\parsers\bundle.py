"""Load a complete .pbip folder into a ReportBundle (model + report)."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

from app.ir.report import ReportBundle
from app.parsers.pbir import (
    PbirParseError,
    RemoteModelRef,
    merge_report_measures,
    parse_report_definition,
    read_dataset_reference,
)
from app.parsers.tmdl import TmdlParseError, parse_tmdl_folder
from app.parsers.tmsl import load_tmsl, write_tmdl_from_tmsl

EXPORT_HINT = (
    "Export it over the workspace XMLA endpoint (Tabular Editor: File > Save to Folder with "
    "TMDL serialization, or SSMS: Script Database as > CREATE To > File) and add the exported "
    "folder or .bim/.xmla file to this zip next to the .pbip."
)

_MODEL_SUFFIXES = (".SemanticModel", ".Dataset")


def find_pbip(root: Path) -> Path:
    candidates = sorted(root.rglob("*.pbip"))
    if not candidates:
        raise PbirParseError(f"no .pbip file under {root}")
    return candidates[0]


@dataclass
class _ModelSource:
    kind: str  # "tmdl" | "tmsl"
    path: Path  # tmdl: the definition/ folder; tmsl: the .bim/.xmla file
    names: list[str] = field(default_factory=list)

    def label(self, root: Path) -> str:
        return _rel(self.path, root)


def _rel(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError:
        return str(path)


def _strip_model_suffix(name: str) -> str:
    for suffix in _MODEL_SUFFIXES:
        if name.endswith(suffix):
            return name[: -len(suffix)]
    return name


def _tmdl_database_name(definition: Path) -> str | None:
    db_file = definition / "database.tmdl"
    if not db_file.is_file():
        return None
    for line in db_file.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if line.startswith("database"):
            name = line[len("database") :].strip().strip("'")
            return name or None
    return None


def _find_model_sources(root: Path) -> tuple[list[_ModelSource], list[str]]:
    sources: list[_ModelSource] = []
    skipped: list[str] = []
    for model_file in sorted(root.rglob("model.tmdl")):
        definition = model_file.parent
        names = [_strip_model_suffix(definition.parent.name)]
        db_name = _tmdl_database_name(definition)
        if db_name:
            names.append(db_name)
        sources.append(_ModelSource("tmdl", definition, names))
    for pattern in ("*.bim", "*.xmla"):
        for tmsl_file in sorted(root.rglob(pattern)):
            try:
                db = load_tmsl(tmsl_file)
            except TmdlParseError:
                skipped.append(_rel(tmsl_file, root))
                continue
            names = [tmsl_file.stem]
            if tmsl_file.stem == "model":
                names.append(_strip_model_suffix(tmsl_file.parent.name))
            if db.get("name"):
                names.append(str(db["name"]))
            sources.append(_ModelSource("tmsl", tmsl_file, names))
    return sources, skipped


def _pick_model_source(remote: RemoteModelRef, root: Path) -> _ModelSource:
    sources, skipped = _find_model_sources(root)
    if not sources:
        unreadable = f" Unreadable model files: {', '.join(skipped)}" if skipped else ""
        raise PbirParseError(
            f"this report is live-connected (byConnection) to the {remote.describe()} and the "
            f"upload contains no semantic model definition. {EXPORT_HINT}{unreadable}"
        )
    if len(sources) == 1:
        return sources[0]
    wanted = {x.casefold() for x in (remote.model_name, remote.model_id) if x}
    matched = [s for s in sources if wanted & {n.casefold() for n in s.names}]
    if len({s.kind for s in matched}) > 1:
        matched = [s for s in matched if s.kind == "tmdl"]
    if len(matched) == 1:
        return matched[0]
    listing = ", ".join(s.label(root) for s in sources)
    raise PbirParseError(
        f"this report is live-connected (byConnection) to the {remote.describe()}; the upload "
        f"contains several semantic models ({listing}) and none could be matched unambiguously. "
        "Keep only the export of that model in the zip."
    )


def _tmsl_to_definition(tmsl_file: Path, generated_dir: Path | None) -> Path:
    """Convert a TMSL file to a TMDL definition/ folder and return that folder."""
    db = load_tmsl(tmsl_file)
    stem = tmsl_file.stem
    local_model_folder = tmsl_file.parent.name.endswith(_MODEL_SUFFIXES)
    if stem == "model" and local_model_folder:
        stem = _strip_model_suffix(tmsl_file.parent.name)
    if generated_dir is not None:
        target = generated_dir / f"{stem}.SemanticModel" / "definition"
    elif local_model_folder:
        target = tmsl_file.parent / "definition"
    else:
        target = tmsl_file.parent / f"{stem}.SemanticModel" / "definition"
    if target.exists() and any(target.iterdir()):
        raise PbirParseError(f"cannot convert TMSL model: {target} already exists and is not empty")
    write_tmdl_from_tmsl(db, target)
    return target


def load_pbip(root: Path, generated_dir: Path | None = None) -> ReportBundle:
    """`root` is a folder containing X.pbip + X.Report/ + X.SemanticModel/.

    `generated_dir`: where a TMSL model is converted to TMDL (never into the upload)."""
    pbip_file = find_pbip(root)
    pbip = json.loads(pbip_file.read_text(encoding="utf-8"))

    report_rel = None
    for artifact in pbip.get("artifacts", []):
        if "report" in artifact:
            report_rel = artifact["report"].get("path")
            break
    if not report_rel:
        raise PbirParseError(f"{pbip_file}: no report artifact declared")

    report_dir = (pbip_file.parent / report_rel).resolve()
    if not report_dir.is_dir():
        raise PbirParseError(f"report folder not found: {report_dir}")

    warnings: list[str] = []
    ref = read_dataset_reference(report_dir)
    definition: Path
    if isinstance(ref, RemoteModelRef):
        source = _pick_model_source(ref, root)
        converted = source.kind == "tmsl"
        definition = (
            _tmsl_to_definition(source.path, generated_dir) if converted else source.path
        )
        warnings.append(
            f"report was live-connected to the {ref.describe()}; rebound to the uploaded model "
            f"{_rel(source.path.parent if source.kind == 'tmdl' else source.path, root)}"
            + (" (TMSL converted to TMDL)" if converted else "")
        )
    else:
        model_dir = ref
        definition = model_dir / "definition"
        if not definition.is_dir():
            bim = model_dir / "model.bim"
            if bim.is_file():
                definition = _tmsl_to_definition(bim, generated_dir)
                warnings.append(
                    "semantic model was TMSL (model.bim); converted to TMDL at "
                    f"{_rel(definition, root)}"
                )
            else:
                raise PbirParseError(f"no TMDL definition/ folder in {model_dir}")

    model = parse_tmdl_folder(definition)
    report, report_warnings = parse_report_definition(report_dir)
    warnings.extend(report_warnings)
    warnings.extend(merge_report_measures(model, report))
    return ReportBundle(
        source_path=str(root),
        model=model,
        report=report,
        warnings=warnings,
    )
