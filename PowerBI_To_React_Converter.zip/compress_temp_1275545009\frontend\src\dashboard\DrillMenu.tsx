import { useEffect, useRef, useState } from 'react'
import type { PageSpec } from './types'

/** Power BI's context menu at the pointer: "Drill through ›" opens a submenu listing the target
 * pages. Escape or an outside click closes it; choosing a page drills. */
export function DrillMenu({
  at,
  targets,
  onDrill,
  onClose,
}: {
  at: { x: number; y: number }
  targets: PageSpec[]
  onDrill: (page: PageSpec) => void
  onClose: () => void
}) {
  const [open, setOpen] = useState(false)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const key = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    const away = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose()
    }
    document.addEventListener('keydown', key)
    document.addEventListener('mousedown', away)
    return () => {
      document.removeEventListener('keydown', key)
      document.removeEventListener('mousedown', away)
    }
  }, [onClose])

  return (
    <div
      ref={ref}
      role="menu"
      data-testid="drill-menu"
      className="fixed z-[1000] min-w-44 rounded-lg border border-surface-300 bg-white py-1 text-xs shadow-xl"
      style={{ left: at.x, top: at.y }}
    >
      <button
        type="button"
        role="menuitem"
        aria-haspopup="menu"
        aria-expanded={open}
        className="flex w-full items-center justify-between px-3 py-1.5 text-left hover:bg-surface-100"
        onClick={() => setOpen(true)}
        onMouseEnter={() => setOpen(true)}
      >
        <span>Drill through</span>
        <span aria-hidden>›</span>
      </button>
      {open && (
        <div
          role="menu"
          aria-label="Drill through"
          className="absolute top-0 left-full ml-0.5 min-w-40 rounded-lg border border-surface-300 bg-white py-1 shadow-xl"
        >
          {targets.map((p) => (
            <button
              key={p.name}
              type="button"
              role="menuitem"
              className="block w-full px-3 py-1.5 text-left hover:bg-surface-100"
              onClick={() => onDrill(p)}
            >
              {p.display_name}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
