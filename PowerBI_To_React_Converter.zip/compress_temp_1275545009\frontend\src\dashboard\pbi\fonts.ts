import { lit, litNumber, litString, type Node } from './literal'

export interface FontSpec {
  family: string
  sizePx: number
  weight: number
}

export const ptToPx = (pt: number): number => (pt * 4) / 3

/** `'12'`, `12`, `'24pt'`, `'16px'` -> pixels (a bare number is points). */
export function fontSizePx(value: string | number | undefined | null): number | undefined {
  if (value === undefined || value === null || value === '') return undefined
  if (typeof value === 'number') return ptToPx(value)
  const m = /^\s*(-?\d+(?:\.\d+)?)\s*(pt|px)?\s*$/i.exec(value)
  if (!m) return undefined
  const n = Number(m[1])
  return m[2]?.toLowerCase() === 'px' ? n : ptToPx(n)
}

const WEIGHTS: [RegExp, number][] = [
  [/\b(extra ?bold|black|heavy)\b/i, 800],
  [/\b(semi ?bold|demi ?bold)\b/i, 600],
  [/\bbold\b/i, 700],
  [/\b(semi ?light|light)\b/i, 300],
]

/** `"'Segoe UI Bold', wf_segoe-ui_bold, helvetica"`, `"Segoe (Bold)"`, `"Calibri"` -> family + weight. */
export function parseFontFamily(raw: string | undefined | null): { family: string; weight?: number } {
  if (!raw) return { family: '' }
  const first = raw.split(',')[0].trim().replace(/^['"]|['"]$/g, '')
  let weight: number | undefined
  let family = first
  const paren = /\(([^)]*)\)\s*$/.exec(first)
  if (paren) {
    family = first.replace(paren[0], '').trim()
    for (const [re, w] of WEIGHTS) if (re.test(paren[1])) weight = w
  } else {
    for (const [re, w] of WEIGHTS) {
      if (re.test(first)) {
        weight = w
        family = first.replace(re, '').replace(/\s+/g, ' ').trim()
        break
      }
    }
  }
  return weight === undefined ? { family } : { family, weight }
}

/** A font from a family node and a size node, with defaults in points. */
export function font(
  familyNode: Node,
  sizeNode: Node,
  defaultPt: number,
  defaultWeight = 400,
  defaultFamily = 'Segoe UI',
): FontSpec {
  const parsed = parseFontFamily(litString(familyNode))
  const sizeRaw = lit(sizeNode)
  const px =
    fontSizePx(typeof sizeRaw === 'number' || typeof sizeRaw === 'string' ? sizeRaw : undefined) ??
    (litNumber(sizeNode) !== undefined ? ptToPx(litNumber(sizeNode)!) : ptToPx(defaultPt))
  return {
    family: parsed.family || defaultFamily,
    sizePx: px,
    weight: parsed.weight ?? defaultWeight,
  }
}

export function fontCss(f: FontSpec): { fontFamily: string; fontSize: string; fontWeight: number } {
  return {
    fontFamily: `'${f.family}', 'Segoe UI', sans-serif`,
    fontSize: `${f.sizePx}px`,
    fontWeight: f.weight,
  }
}
