import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import type { QueryRecord } from '../api/types'
import { QueryAudit, editBlockedReason, kindCount, matchesQuerySearch } from '../steps/QueryAudit'
import { useWizard } from '../store/wizard'

function wrap(ui: React.ReactElement) {
  const qc = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  })
  return render(<QueryClientProvider client={qc}>{ui}</QueryClientProvider>)
}

const rec = (over: Partial<QueryRecord>): QueryRecord => ({
  kind: 'dashboard',
  page: 'p1',
  page_name: 'Overview',
  visual: 'v1',
  pane: 'Sales by category',
  check: 'main',
  attempt: 'primary',
  status: 'ok',
  source: 'editor',
  elapsed_ms: 120,
  row_count: 5,
  warehouse: 'WH',
  role: 'ANALYST',
  sql_logged: true,
  ...over,
})

const summary = (over = {}) => ({
  total: 3,
  panes: 3,
  ok: 1,
  empty: 1,
  error: 1,
  plan_error: 0,
  cached: 0,
  slowest_ms: 900,
  slowest_pane: 'Revenue',
  avg_ms: 400,
  warehouses: ['WH'],
  roles: ['ANALYST'],
  sql_logging: true,
  events_read: 3,
  events_cap: 20000,
  kinds: { dashboard: 3, totals: 1, setup: 2, validation: 4 },
  ...over,
})

const RECORDS: QueryRecord[] = [
  rec({
    sql: 'SELECT 1 FROM sales',
    query_id: 'qid-77',
    tables: [{ model_table: 'Sales', physical: 'DB.PUBLIC.SALES' }],
    request_filters: [
      { table: 'Customer', column: 'Country', op: 'in', values: ['US', null], source: 'slicer' },
    ],
    visual_filters: [{ table: 'Date', column: 'Year', op: 'gte', values: [2020], source: 'visual' }],
    measures: ['Total Sales'],
  }),
  rec({ visual: 'v2', pane: 'Revenue', status: 'empty', row_count: 0, elapsed_ms: 900 }),
  rec({
    visual: 'v3',
    pane: 'Margin',
    status: 'error',
    error: 'SQL compilation error',
    sql: 'SELECT bad',
    row_count: null,
  }),
]

let calls: string[] = []

function mockFetch(overrides: Record<string, unknown> = {}) {
  calls = []
  vi.stubGlobal(
    'fetch',
    vi.fn(async (url: string) => {
      calls.push(String(url))
      for (const [key, value] of Object.entries(overrides)) {
        if (String(url).includes(key)) return new Response(JSON.stringify(value))
      }
      if (String(url).includes('/query-audit'))
        return new Response(JSON.stringify({ records: RECORDS, summary: summary() }))
      return new Response(JSON.stringify({}))
    }),
  )
}

describe('QueryAudit', () => {
  beforeEach(() => {
    useWizard.getState().reset()
    useWizard.setState({ conversionId: 'c1', connectionId: 'conn-1' })
    Element.prototype.scrollIntoView = vi.fn()
  })
  afterEach(() => vi.restoreAllMocks())

  it('shows the summary cards and one row per pane', async () => {
    mockFetch()
    wrap(<QueryAudit />)
    expect(await screen.findByText('Sales by category')).toBeTruthy()
    expect(screen.getByText('Revenue')).toBeTruthy()
    expect(screen.getByText('Margin')).toBeTruthy()
    for (const label of ['Queries', 'Panes', 'OK', '0 rows', 'Errors', 'Not built', 'Cache hits', 'Slowest', 'Average', 'Warehouse / role'])
      expect(screen.getAllByText(label).length).toBeGreaterThan(0)
    expect(screen.getByText('900 ms', { selector: 'div' })).toBeTruthy()
    expect(screen.getByText('WH / ANALYST', { selector: 'div' })).toBeTruthy()
  })

  it('filters by status and search', async () => {
    mockFetch()
    wrap(<QueryAudit />)
    await screen.findByText('Margin')
    await userEvent.selectOptions(screen.getByLabelText('Status'), 'error')
    expect(screen.queryByText('Revenue')).toBeNull()
    expect(screen.getByText('Margin')).toBeTruthy()
    await userEvent.selectOptions(screen.getByLabelText('Status'), 'all')
    await userEvent.type(screen.getByLabelText('Search queries'), 'qid-77')
    expect(screen.getByText('Sales by category')).toBeTruthy()
    expect(screen.queryByText('Margin')).toBeNull()
  })

  it('expands a row into its detail', async () => {
    mockFetch()
    wrap(<QueryAudit />)
    await userEvent.click(await screen.findByText('Sales by category'))
    const detail = await screen.findByTestId('query-detail')
    const d = within(detail)
    expect(d.getByText('SELECT 1 FROM sales')).toBeTruthy()
    expect(d.getByText('Sales → DB.PUBLIC.SALES')).toBeTruthy()
    expect(d.getByText('Customer.Country in US, NULL [slicer]')).toBeTruthy()
    expect(d.getByText('Date.Year gte 2020 [visual]')).toBeTruthy()
    expect(d.getByText('qid-77')).toBeTruthy()
    expect(d.getByText('WH · ANALYST')).toBeTruthy()
    expect(d.getByRole('button', { name: 'Edit SQL' })).toBeTruthy()
    expect(d.getByRole('button', { name: 'Re-check this pane' })).toBeTruthy()
    expect(d.getByRole('button', { name: 'Copy history lookup' })).toBeTruthy()
  })

  it('shows run history for a pane', async () => {
    mockFetch({ history_for: { records: [rec({ status: 'error', error: 'old failure' })], summary: summary() } })
    wrap(<QueryAudit />)
    await userEvent.click(await screen.findByText('Sales by category'))
    await userEvent.click(await screen.findByRole('button', { name: 'Show run history' }))
    const history = await screen.findByTestId('query-history')
    expect(await within(history).findByText('old failure')).toBeTruthy()
    expect(calls.some((c) => c.includes('history_for=p1%2Fv1'))).toBe(true)
  })

  it('explains not-built panes and links to the DAX Audit', async () => {
    const onOpenMeasure = vi.fn()
    mockFetch({
      '/query-audit': {
        records: [
          rec({
            status: 'plan_error',
            attempt: 'plan',
            pane: 'Orders',
            error: 'measure [Orders] needs tier-2',
            measures: ['Orders'],
            row_count: null,
          }),
        ],
        summary: summary({ plan_error: 1, ok: 0, total: 1 }),
      },
    })
    wrap(<QueryAudit onOpenMeasure={onOpenMeasure} />)
    await userEvent.click(await screen.findByText('Orders'))
    expect(await screen.findByText(/Not built: measure \[Orders\] needs tier-2/)).toBeTruthy()
    await userEvent.click(screen.getByRole('button', { name: 'Open in DAX Audit' }))
    expect(onOpenMeasure).toHaveBeenCalledWith('Orders')
  })

  it('exports with the current filters and kind', async () => {
    mockFetch()
    wrap(<QueryAudit />)
    await screen.findByText('Margin')
    await userEvent.selectOptions(screen.getByLabelText('Status'), 'error')
    await userEvent.type(screen.getByLabelText('Search queries'), 'bad')
    const excel = screen.getByRole('link', { name: 'Download Excel' }) as HTMLAnchorElement
    const json = screen.getByRole('link', { name: 'Download JSON' }) as HTMLAnchorElement
    expect(excel.href).toContain('/dashboard/query-audit/export?')
    expect(excel.href).toContain('format=xlsx')
    expect(excel.href).toContain('status=error')
    expect(excel.href).toContain('search=bad')
    expect(excel.href).toContain('kind=dashboard')
    expect(json.href).toContain('format=json')
    await userEvent.selectOptions(screen.getByLabelText('Query kind'), 'setup')
    await waitFor(() => expect(calls.some((c) => c.includes('kind=setup'))).toBe(true))
    expect((screen.getByRole('link', { name: 'Download JSON' }) as HTMLAnchorElement).href).toContain('kind=setup')
  })

  it('lists kinds with counts', async () => {
    mockFetch()
    wrap(<QueryAudit />)
    await screen.findByText('Margin')
    const options = within(screen.getByLabelText('Query kind')).getAllByRole('option')
    expect(options.map((o) => o.textContent)).toEqual([
      'Dashboard (3)',
      'Totals (1)',
      'Drill (0)',
      'Conversion checks (4)',
      'Setup (2)',
      'All (10)',
    ])
    expect(kindCount({ validation: 1, probe: 2, ai_llm: 3 }, 'conversion')).toBe(6)
  })

  it('says when SQL logging is off', async () => {
    mockFetch({
      '/query-audit': {
        records: [rec({ sql_logged: false })],
        summary: summary({ sql_logging: false }),
      },
    })
    wrap(<QueryAudit />)
    expect(await screen.findByText(/SQL logging is off/)).toBeTruthy()
    await userEvent.click(screen.getByText('Sales by category'))
    expect(screen.getByText('SQL logging is off for this run.')).toBeTruthy()
  })

  it('explains an empty log', async () => {
    mockFetch({ '/query-audit': { records: [], summary: summary({ total: 0 }) } })
    wrap(<QueryAudit />)
    expect(await screen.findByText(/No queries logged yet/)).toBeTruthy()
  })

  it('shows drill steps', async () => {
    mockFetch({
      '/query-audit': {
        records: [
          rec({
            kind: 'drill',
            pane: 'Drill pane',
            drill: { direction: 'down', level: 'Product.Category', level_index: 0 },
          }),
        ],
        summary: summary(),
      },
    })
    wrap(<QueryAudit />)
    await userEvent.click(await screen.findByText('Drill pane'))
    expect(screen.getByText(/Drill step: down to Product.Category/)).toBeTruthy()
  })

  it('offers Edit SQL only for a pane’s main query', () => {
    expect(editBlockedReason(rec({}))).toBeNull()
    expect(editBlockedReason(rec({ kind: 'validation', check: 'main' }))).toBeNull()
    expect(editBlockedReason(rec({ kind: 'setup', page: null, visual: null }))).toBe(
      'Setup queries are not a pane’s query, so they can’t be edited.',
    )
    expect(editBlockedReason(rec({ kind: 'validation', check: 'totals' }))).toBe(
      'This query belongs to the conversion run’s checks, not to a pane, so it can’t be edited.',
    )
    expect(editBlockedReason(rec({ kind: 'totals' }))).toBe(
      'Only a pane’s main query can be edited; open the pane in the Dashboard view or its “main” check.',
    )
  })

  it('renders the matching explanation in the detail panel', async () => {
    mockFetch({
      '/query-audit': {
        records: [rec({ kind: 'setup', page: null, visual: null, page_name: null, pane: 'Identifier case check' })],
        summary: summary(),
      },
    })
    wrap(<QueryAudit />)
    await userEvent.click(await screen.findByText('Identifier case check'))
    expect(screen.getByText('Setup queries are not a pane’s query, so they can’t be edited.')).toBeTruthy()
    expect(screen.queryByRole('button', { name: 'Edit SQL' })).toBeNull()
  })

  it('searches every field', () => {
    const r = RECORDS[0]
    for (const needle of ['overview', 'sales by', 'sales', 'db.public.sales', 'qid-77', 'country', 'total sales'])
      expect(matchesQuerySearch(r, needle)).toBe(true)
    expect(matchesQuerySearch(r, 'nothing like this')).toBe(false)
  })

  it('has a No SQL generated tab that works even when nothing ran', async () => {
    mockFetch({
      '/query-audit': { records: [], summary: summary({ total: 0 }) },
      '/no-sql-panes/p1/v9': {
        page: 'p1',
        visual: 'v9',
        pane: 'Orders pane',
        dax_query: 'EVALUATE ROW("x", 1)',
        dax_query_error: null,
        measures: [
          {
            name: 'Orders',
            table: 'Sales',
            dax: 'FOOBAR(1)',
            rewrite: 'FOOBAR(2)',
            error: 'function FOOBAR not in tier-1 set',
            dependencies: [
              { name: 'A', table: 'Sales', dax: '1', rewrite: null, translated: true },
              { name: 'B', table: 'Sales', dax: '2', rewrite: null, translated: false },
            ],
          },
        ],
      },
      '/no-sql-panes': {
        panes: [
          {
            page: 'p1',
            page_name: 'Overview',
            visual: 'v9',
            pane: 'Orders pane',
            visual_type: 'card',
            measure: 'Orders',
            reason: 'measure [Orders] needs tier-2',
            expected_columns: ['Orders'],
            manual_sql: false,
            saved_at: null,
          },
        ],
      },
    })
    const onOpenMeasure = vi.fn()
    wrap(<QueryAudit onOpenMeasure={onOpenMeasure} />)
    await userEvent.click(await screen.findByRole('button', { name: 'No SQL generated' }))
    const panel = await screen.findByTestId('no-sql-panes')
    expect(await within(panel).findByText('Orders pane')).toBeTruthy()
    expect(within(panel).getByText('measure [Orders] needs tier-2')).toBeTruthy()
    expect(within(panel).getByRole('button', { name: 'Edit SQL' })).toBeTruthy()
    expect(within(panel).getByRole('button', { name: 'Re-check' })).toBeTruthy()
    await userEvent.type(screen.getByLabelText('Search panes'), 'zzz')
    expect(within(panel).getByText('Every pane has generated SQL.')).toBeTruthy()
    await userEvent.clear(screen.getByLabelText('Search panes'))
    await userEvent.click(within(panel).getByRole('button', { name: 'Show DAX' }))
    const dax = await screen.findByTestId('no-sql-pane-dax')
    expect(within(dax).getByText('Visual DAX query (without slicer selections)')).toBeTruthy()
    expect(within(dax).getByText(/Why it wasn’t translated/)).toBeTruthy()
    expect(within(dax).getByText('Accepted AI rewrite')).toBeTruthy()
    expect(within(dax).getByText('Translated')).toBeTruthy()
    expect(within(dax).getByText('Not translated')).toBeTruthy()
    await userEvent.click(within(panel).getByRole('button', { name: 'DAX Audit' }))
    expect(onOpenMeasure).toHaveBeenCalledWith('Orders')
  })
})
