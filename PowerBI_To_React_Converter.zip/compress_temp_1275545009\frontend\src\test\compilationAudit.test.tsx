import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { CompilationAudit, tierLabel } from '../steps/CompilationAudit'
import { useWizard } from '../store/wizard'

function wrap(ui: React.ReactElement) {
  const qc = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  })
  return render(<QueryClientProvider client={qc}>{ui}</QueryClientProvider>)
}

const record = (name: string, over = {}) => ({
  measure_name: name,
  model_table: 'Sales',
  dax_expression: `SUM(${name})`,
  compiler_type: 'tier1',
  compilation_status: 'success',
  overall_status: 'working',
  dax_complexity_score: 0.2,
  sql_complexity: 0.1,
  generated_sql: `SELECT ${name}`,
  ...over,
})

const AUDIT = {
  records: [
    record('Total Sales'),
    record('Total Sales LY', { compiler_type: 'tier2' }),
    record('Orders', {
      compiler_type: 'parked',
      compilation_status: 'failed',
      overall_status: 'broken',
      compilation_error: 'function FOOBAR not in tier-1 set',
      generated_sql: null,
    }),
    record('Margin', { overall_status: 'degraded', validation_error: 'empty result' }),
  ],
  summary: {
    total: 4,
    working: 2,
    degraded: 1,
    broken: 1,
    percentage_working: 50,
    by_compiler_type: { tier1: 2, tier2: 1, parked: 1 },
    avg_dax_complexity: 0.2,
    avg_sql_complexity: 0.1,
  },
}

const okCheck = (over = {}) => ({
  ok: true,
  measure: 'Orders',
  measure_run: { sql: 'SELECT 1', value: 42, query_id: 'q', error: null },
  pane_runs: [{ page: 'p', visual: 'v', pane: 'Orders card', rows: 1, query_id: 'q', error: null }],
  panes_not_run: 0,
  null_comparison_warnings: ['`col = NULL` is never true: use `col IS NULL`'],
  newly_translated: ['Orders'],
  still_untranslated_measures: ['Orders LY'],
  fixed_panes: [{ page: 'p', visual: 'v', pane: 'Orders card' }],
  still_untranslated: [],
  not_applicable: [{ page: 'p', visual: 'w', pane: 'Orders by month' }],
  ...over,
})

let requests: { url: string; method: string; body?: string }[] = []

function mockApi(check: () => unknown = () => okCheck(), fixes: Record<string, unknown> = {}) {
  requests = []
  vi.stubGlobal(
    'fetch',
    vi.fn(async (url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET'
      requests.push({ url: String(url), method, body: init?.body as string | undefined })
      const u = String(url)
      if (u.includes('/measure-sql/test')) return new Response(JSON.stringify(check()))
      if (u.includes('/measure-sql') && method === 'PUT')
        return new Response(JSON.stringify({ fix: {} }))
      if (u.includes('/measure-sql') && method === 'DELETE')
        return new Response(JSON.stringify({ reverted: 'Orders', remaining: [] }))
      if (u.includes('/measure-sql')) return new Response(JSON.stringify({ fixes }))
      if (u.includes('/compilation-audit')) return new Response(JSON.stringify(AUDIT))
      return new Response(JSON.stringify({}))
    }),
  )
}

describe('CompilationAudit', () => {
  beforeEach(() => {
    useWizard.getState().reset()
    useWizard.setState({ conversionId: 'c1', connectionId: 'conn-1' })
  })
  afterEach(() => vi.restoreAllMocks())

  it('shows the summary cards, breakdown and one row per measure', async () => {
    mockApi()
    wrap(<CompilationAudit />)
    expect(await screen.findByText('[Total Sales]')).toBeTruthy()
    for (const label of ['Success rate', 'Total measures', 'Working', 'Degraded', 'Broken', 'Avg DAX complexity', 'Avg SQL complexity'])
      expect(screen.getAllByText(label).length).toBeGreaterThan(0)
    expect(screen.getByText('50%')).toBeTruthy()
    const breakdown = screen.getByTestId('compilation-breakdown')
    expect(breakdown.textContent).toContain('Tier 2 (AI): 1')
    expect(breakdown.textContent).toContain('Parked: 1')
    expect(screen.getAllByTestId('audit-row')).toHaveLength(4)
    expect(screen.getByText('Broken', { selector: 'span' })).toBeTruthy()
    expect(screen.getByText('Degraded', { selector: 'span' })).toBeTruthy()
  })

  it('filters by name, table, status and exact match', async () => {
    mockApi()
    wrap(<CompilationAudit />)
    await screen.findByText('[Orders]')
    const box = screen.getByLabelText('Filter by measure or table')
    await userEvent.type(box, 'total sales')
    expect(screen.getAllByTestId('audit-row')).toHaveLength(2)
    await userEvent.click(screen.getByLabelText('Exact match'))
    expect(screen.getAllByTestId('audit-row')).toHaveLength(1)
    await userEvent.clear(box)
    await userEvent.type(box, 'sales')
    expect(screen.queryAllByTestId('audit-row')).toHaveLength(0) // exact: no measure is "sales"
    await userEvent.click(screen.getByLabelText('Exact match'))
    expect(screen.getAllByTestId('audit-row')).toHaveLength(4) // the table matches all
    await userEvent.clear(box)
    await userEvent.selectOptions(screen.getByLabelText('Status'), 'broken')
    expect(screen.getAllByTestId('audit-row')).toHaveLength(1)
  })

  it('opens with an exact match when asked to (from a query-audit measure link)', async () => {
    mockApi()
    wrap(<CompilationAudit initialSearch="Total Sales" initialExact />)
    await screen.findByText('[Total Sales]')
    expect(screen.getAllByTestId('audit-row')).toHaveLength(1)
    expect((screen.getByLabelText('Exact match') as HTMLInputElement).checked).toBe(true)
  })

  it('expands a row into errors, DAX and SQL, and links to the queries', async () => {
    mockApi()
    const onOpenQueries = vi.fn()
    wrap(<CompilationAudit onOpenQueries={onOpenQueries} />)
    await userEvent.click(await screen.findByText('[Orders]'))
    const detail = await screen.findByTestId('audit-detail')
    expect(within(detail).getByText(/Compile error: function FOOBAR/)).toBeTruthy()
    expect(within(detail).getByText('SUM(Orders)')).toBeTruthy()
    await userEvent.click(
      within(detail).getByRole('button', {
        name: 'Open the Snowflake query audit on the panes using this measure',
      }),
    )
    expect(onOpenQueries).toHaveBeenCalledWith('Orders')
  })

  it('links the downloads', async () => {
    mockApi()
    wrap(<CompilationAudit />)
    await screen.findByText('[Orders]')
    expect((screen.getByRole('link', { name: 'Download Excel' }) as HTMLAnchorElement).href).toContain(
      '/compilation-audit/export?format=xlsx',
    )
    expect((screen.getByRole('link', { name: 'Download JSON' }) as HTMLAnchorElement).href).toContain(
      'format=json',
    )
  })

  it('labels every tier', () => {
    expect(['tier0', 'tier1', 'tier2', 'parked', 'manual_sql'].map(tierLabel)).toEqual([
      'Tier 0',
      'Tier 1',
      'Tier 2 (AI)',
      'Parked',
      'Manual SQL',
    ])
  })
})

describe('MeasureSqlFix (in the DAX Audit)', () => {
  beforeEach(() => {
    useWizard.getState().reset()
    useWizard.setState({ conversionId: 'c1', connectionId: 'conn-1' })
  })
  afterEach(() => vi.restoreAllMocks())

  async function openFix() {
    await userEvent.click(await screen.findByText('[Orders]'))
    await userEvent.click(await screen.findByRole('button', { name: 'Fix measure' }))
    return screen.getByLabelText('Measure SQL') as HTMLTextAreaElement
  }

  it('checks on Snowflake then saves exactly the checked text', async () => {
    mockApi()
    wrap(<CompilationAudit />)
    const box = await openFix()
    const save = () => screen.getByRole('button', { name: 'Save' }) as HTMLButtonElement
    expect(save().disabled).toBe(true)
    await userEvent.type(box, 'SELECT 42')
    expect(save().disabled).toBe(true) // not checked yet
    await userEvent.click(screen.getByRole('button', { name: 'Check on Snowflake' }))
    const result = await screen.findByTestId('measure-sql-result')
    expect(result.textContent).toContain('Returned 42')
    expect(result.textContent).toContain('Fixed panes: Orders card')
    expect(result.textContent).toContain('Measures still not translated: Orders LY')
    expect(result.textContent).toContain('Not applicable (group by rows): Orders by month')
    expect(result.textContent).toContain('IS NULL')
    await waitFor(() => expect(save().disabled).toBe(false))
    await userEvent.type(box, ' ')
    expect(save().disabled).toBe(true) // text changed after the check
    await userEvent.click(screen.getByRole('button', { name: 'Check on Snowflake' }))
    await waitFor(() => expect(save().disabled).toBe(false))
    await userEvent.click(save())
    await waitFor(() => expect(requests.some((r) => r.method === 'PUT')).toBe(true))
    const put = requests.find((r) => r.method === 'PUT')!
    expect(JSON.parse(put.body!)).toEqual({ measure: 'Orders', sql: 'SELECT 42 ' })
  })

  it('a failed check blocks saving and shows why', async () => {
    mockApi(() =>
      okCheck({
        ok: false,
        measure_run: { sql: 'x', value: null, query_id: null, error: 'must return a number or text (got date)' },
        pane_runs: [],
        fixed_panes: [],
      }),
    )
    wrap(<CompilationAudit />)
    const box = await openFix()
    await userEvent.type(box, 'SELECT CURRENT_DATE')
    await userEvent.click(screen.getByRole('button', { name: 'Check on Snowflake' }))
    expect((await screen.findByTestId('measure-sql-result')).textContent).toContain(
      'must return a number or text (got date)',
    )
    expect((screen.getByRole('button', { name: 'Save' }) as HTMLButtonElement).disabled).toBe(true)
  })

  it('accepts text values', async () => {
    mockApi(() =>
      okCheck({ measure_run: { sql: 'x', value: 'high', query_id: 'q', error: null } }),
    )
    wrap(<CompilationAudit />)
    const box = await openFix()
    await userEvent.type(box, "SELECT 'high'")
    await userEvent.click(screen.getByRole('button', { name: 'Check on Snowflake' }))
    expect((await screen.findByTestId('measure-sql-result')).textContent).toContain('Returned high')
    await waitFor(() =>
      expect((screen.getByRole('button', { name: 'Save' }) as HTMLButtonElement).disabled).toBe(false),
    )
  })

  it('needs a connection to check', async () => {
    useWizard.setState({ connectionId: null })
    mockApi()
    wrap(<CompilationAudit />)
    await openFix()
    expect(screen.getByText('Select a Snowflake connection to check.')).toBeTruthy()
    expect((screen.getByRole('button', { name: 'Check on Snowflake' }) as HTMLButtonElement).disabled).toBe(true)
  })

  it('edits and reverts an existing fix', async () => {
    mockApi(() => okCheck(), { Orders: { sql: 'SELECT 7', original: 'FOOBAR(1)' } })
    wrap(<CompilationAudit />)
    await userEvent.click(await screen.findByText('[Orders]'))
    await userEvent.click(await screen.findByRole('button', { name: 'Edit measure SQL' }))
    expect((screen.getByLabelText('Measure SQL') as HTMLTextAreaElement).value).toBe('SELECT 7')
    await userEvent.click(screen.getByRole('button', { name: 'Revert' }))
    await waitFor(() => expect(requests.some((r) => r.method === 'DELETE')).toBe(true))
    expect(requests.find((r) => r.method === 'DELETE')!.url).toContain('/measure-sql/Orders')
  })
})
