"""Pre-flight: is any bound Snowflake object reachable with this role/warehouse?

Runs in seconds before a long conversion so an unreachable target is reported early.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from app.binding.case_check import _checkable
from app.binding.resolver import BindingMap, quote_ident, sql_string


class PreflightTarget(BaseModel):
    database: str
    schema_name: str
    tables: list[str] = Field(default_factory=list)
    found: list[str] = Field(default_factory=list)
    case_mismatch: list[str] = Field(default_factory=list)
    error: str | None = None
    listed: int = 0

    @property
    def unreachable(self) -> bool:
        return bool(self.error) or bool(self.listed > 0 and self.tables and not self.found)


class PreflightReport(BaseModel):
    role: str | None = None
    warehouse: str | None = None
    session_error: str | None = None
    targets: list[PreflightTarget] = Field(default_factory=list)

    @property
    def bound(self) -> int:
        return sum(len(t.tables) for t in self.targets)

    @property
    def accessible(self) -> int:
        return sum(len(t.found) for t in self.targets)

    @property
    def blocking(self) -> bool:
        return bool(self.targets) and all(t.unreachable for t in self.targets)

    def message(self) -> str:
        who = f"role {self.role} / warehouse {self.warehouse}"
        if self.blocking:
            reasons = []
            for t in self.targets:
                why = t.error or (
                    f"none of the {len(t.tables)} bound tables exists with this exact spelling "
                    f"({len(t.case_mismatch)} differ only in letter case)"
                )
                reasons.append(f"{t.database}.{t.schema_name}: {why}")
            return (
                f"no bound Snowflake object is reachable with {who} ({'; '.join(reasons)}). "
                "Pick a role with access or set a database/schema override, then convert again"
            )
        return f"{self.accessible}/{self.bound} bound tables reachable with {who}"

    def summary(self) -> dict[str, Any]:
        data = self.model_dump()
        data["targets"] = [
            {**t.model_dump(), "unreachable": t.unreachable} for t in self.targets
        ]
        data.update(bound=self.bound, accessible=self.accessible, blocking=self.blocking)
        return data


def run_preflight(binding_map: BindingMap, cursor: Any) -> PreflightReport:
    """Never raises: every failure is recorded on the report."""
    report = PreflightReport()
    try:
        cursor.execute("select current_role(), current_warehouse()")
        row = cursor.fetchone()
        if row:
            report.role, report.warehouse = row[0], row[1]
    except Exception as e:  # noqa: BLE001
        report.session_error = str(e)[:300]

    groups: dict[tuple[str, str], list[str]] = {}
    for b in binding_map.bindings.values():
        if _checkable(b):
            groups.setdefault((b.database or "", b.schema_name or ""), []).append(
                b.object_name or ""
            )
    for (db, schema), tables in groups.items():
        target = PreflightTarget(database=db, schema_name=schema, tables=tables)
        try:
            cursor.execute(
                f"select table_schema, table_name from {quote_ident(db)}.INFORMATION_SCHEMA.TABLES "  # noqa: S608
                f"where upper(table_schema) = upper({sql_string(schema)})"
            )
            rows = [(str(r[0]), str(r[1])) for r in cursor.fetchall()]
            target.listed = len(rows)
            exact = {(s, t) for s, t in rows}
            folded = {(s.upper(), t.upper()): (s, t) for s, t in rows}
            for t in tables:
                if (schema, t) in exact:
                    target.found.append(t)
                elif (schema.upper(), t.upper()) in folded:
                    s2, t2 = folded[(schema.upper(), t.upper())]
                    target.case_mismatch.append(f"{schema}.{t} (Snowflake: {s2}.{t2})")
        except Exception as e:  # noqa: BLE001
            lines = [ln for ln in str(e).strip().splitlines() if ln.strip()]
            target.error = (lines[-1] if lines else str(e))[:300]
        report.targets.append(target)
    return report
