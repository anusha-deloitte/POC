import * as echarts from 'echarts'
import { describe, expect, it } from 'vitest'
import { buildTheme, resolveVisual } from '../dashboard/pbi/resolve'
import type { VisualResult, VisualSpec } from '../dashboard/types'
import { autoDisplayUnits, categoryGeometry, fitLabel, pbiChartOption } from '../dashboard/visuals/pbiChart'

const L = (v: string) => ({ expr: { Literal: { Value: v } } })
const solid = (hex: string) => ({ solid: { color: L(`'${hex}'`) } })

function spec(over: Partial<VisualSpec> & { objects?: object } = {}): VisualSpec {
  const { objects, ...rest } = over
  return {
    name: 'v',
    visual_type: 'clusteredColumnChart',
    x: 0, y: 0, width: 400, height: 300, z: 1, supported: true,
    dim_keys: ['Product.Category'], column_keys: [], series_keys: [], measure_keys: ['Sales'],
    measure_roles: {}, measure_formats: {}, static_content: {}, sort: [],
    pbir: {
      objects: (objects ?? {}) as Record<string, unknown>,
      // no padding, no title: the plot is exactly width x height
      container_objects: {
        padding: [{ properties: { top: L('0D'), right: L('0D'), bottom: L('0D'), left: L('0D') } }],
        title: [{ properties: { show: L('false') } }],
      },
      fields: [], sort: [], is_hidden: false,
    },
    ...rest,
  } as VisualSpec
}

const result = (columns: string[], rows: (string | number | null)[][], totals?: VisualResult['totals']): VisualResult => ({
  visual: 'v', columns, rows, warnings: [], elapsed_ms: 0, cached: false, totals,
})

const theme = buildTheme(undefined)

// jsdom has no canvas: zrender measures text through getContext('2d')
HTMLCanvasElement.prototype.getContext = (() => ({
  measureText: (t: string) => ({ width: t.length * 6 }),
  font: '',
})) as never

function render(s: VisualSpec, data: VisualResult) {
  const st = resolveVisual(s, theme)
  const option = pbiChartOption(s, data, st, 1)
  const chart = echarts.init(null as never, null as never, { ssr: true, renderer: 'svg', width: s.width, height: s.height })
  chart.setOption(option)
  const svg = chart.renderToSVGString()
  const bars = [...svg.matchAll(/<path d="M([\d.-]+) ([\d.-]+)l([\d.-]+) 0l0 (-?[\d.-]+)[^>]*ecmeta_ssr_type="chart"/g)].map((m) => ({
    x: Number(m[1]), bottom: Number(m[2]), width: Number(m[3]), height: -Number(m[4]),
  }))
  return { option: option as Record<string, any>, svg, bars, st }
}

describe('fitLabel', () => {
  it('wraps at spaces, ends with an ellipsis and gives up below ~3 characters', () => {
    expect(fitLabel('Portfolio 12', 71, 18.67)).toBe('Portf…\n12')
    expect(fitLabel('Portfolio 12', 150, 18.67)).toBe('Portfolio 12')
    expect(fitLabel('Portfolio 12', 110, 18.67)).toBe('Portfolio\n12')
    expect(fitLabel('Alpha and Beta Gamma Portfolio', 110, 18.67)).toBe('Alpha and\nBeta Gamm…')
    expect(fitLabel('Portfolio 12', 20, 18.67)).toBe('')
  })
})

describe('column chart geometry', () => {
  const cols = ['Product.Category', 'Sales']

  it('measures-only charts stack their measures in one placeholder category', () => {
    const s = spec({ visual_type: 'columnChart', dim_keys: [], measure_keys: ['A', 'B'] })
    const { bars, option } = render(s, result(['A', 'B'], [[60, 40]]))
    expect(option.xAxis[0].data).toEqual([''])
    expect(bars).toHaveLength(2)
    expect(bars[0].x).toBe(bars[1].x)
    // the second segment sits on top of the first
    expect(bars[1].bottom).toBeCloseTo(bars[0].bottom - bars[0].height, 0)
  })

  it('with a minimum category width a single category slot is max(min width, plot/3)', () => {
    const objects = { categoryAxis: [{ properties: { preferredCategoryWidth: L('30D') } }] }
    const s = spec({ objects })
    const st = resolveVisual(s, theme)
    const axis = 400 - 44 - 8
    expect(categoryGeometry(1, axis, st, 1, false).slotPx).toBeCloseTo(axis / 3)
    const { bars } = render(s, result(cols, [['A', 100]]))
    expect(bars[0].width).toBeCloseTo((axis / 3) * 0.8, 0)
    const wide = spec({ objects: { categoryAxis: [{ properties: { preferredCategoryWidth: L('200D') } }] } })
    expect(render(wide, result(cols, [['A', 100]])).bars[0].width).toBeCloseTo(160, 0)
  })

  it('series share the slot', () => {
    const objects = { categoryAxis: [{ properties: { preferredCategoryWidth: L('30D') } }] }
    const s = spec({ objects, measure_keys: ['A', 'B'] })
    const { bars } = render(s, result(['Product.Category', 'A', 'B'], [['x', 5, 7]]))
    expect(bars).toHaveLength(2)
    expect(bars[0].width).toBeCloseTo((((400 - 44 - 8) / 3) * 0.8) / 2, 0)
  })

  it('without a preferred width a lone bar is capped at 18% of the axis', () => {
    const { bars } = render(spec(), result(cols, [['A', 100]]))
    expect(bars[0].width).toBeCloseTo((400 - 44 - 8) * 0.18, 0)
  })

  it('a preferred category width drives scrolling', () => {
    const objects = { categoryAxis: [{ properties: { preferredCategoryWidth: L('100D') } }] }
    const rows = ['a', 'b', 'c', 'd', 'e', 'f'].map((c) => [c, 10] as (string | number)[])
    const { option } = render(spec({ objects }), result(cols, rows))
    expect(option.dataZoom).toHaveLength(2)
    expect(option.dataZoom[0]).toMatchObject({ type: 'slider', zoomLock: true })
    expect(option.dataZoom[1]).toMatchObject({ type: 'inside' })
    expect(option.xAxis[0].axisLabel.rotate).toBe(90) // labels go 90 once the axis scrolls
    const none = render(spec(), result(cols, rows.slice(0, 3))).option
    expect(none.dataZoom).toBeUndefined()
  })

  it('hidden axes hide their labels and keep one shared baseline', () => {
    const objects = {
      categoryAxis: [{ properties: { show: L('false') } }],
      valueAxis: [{ properties: { show: L('false') } }],
    }
    const a = render(spec({ objects }), result(cols, [['Short', 50], ['B', 100]]))
    const b = render(spec({ objects }), result(cols, [['A very very long category label', 50], ['B', 100]]))
    expect(a.option.xAxis[0].axisLabel.show).toBe(false)
    expect(a.option.yAxis.axisLabel.show).toBe(false)
    expect(a.bars.map((x) => x.bottom)).toEqual(b.bars.map((x) => x.bottom))
  })

  it('outside labels with no value axis leave headroom: the tallest bar draws at 0.885', () => {
    const objects = {
      valueAxis: [{ properties: { show: L('false') } }],
      labels: [{ properties: { show: L('true') } }],
    }
    const { bars, option } = render(spec({ objects }), result(cols, [['A', 50], ['B', 100]]))
    const plot = 300 - option.grid.top - option.grid.bottom
    const tallest = Math.max(...bars.map((x) => x.height))
    expect(tallest / plot).toBeCloseTo(0.885, 2)
  })

  it('45 degree labels widen the left margin by the first label overhang', () => {
    const rows = [['Alpha Beta Gamma Delta', 5], ['Epsilon Zeta Eta Theta', 6], ['Iota Kappa Lambda', 7],
      ['Omicron Pi Rho', 8], ['Sigma Tau Upsilon', 9]] as (string | number)[][] // prettier-ignore
    const { option } = render(spec({ width: 300 }), result(cols, rows))
    expect(option.xAxis[0].axisLabel.rotate).toBe(45)
    expect(option.grid.left).toBeGreaterThan(8)
    const flat = render(spec(), result(cols, [['A', 1]])).option
    expect(flat.grid.left).toBe(8)
  })

  it('nested category axes fit their outer labels per group', () => {
    const objects = { categoryAxis: [{ properties: { concatenateLabels: L('false') } }] }
    const s = spec({ objects, dim_keys: ['Product.Group', 'Product.Category'] })
    const data = result(['Product.Group', 'Product.Category', 'Sales'], [
      ['Portfolio 12', 'A', 1], ['Portfolio 12', 'B', 2], ['Other', 'C', 3],
    ]) // prettier-ignore
    const { option, st } = render(s, data)
    expect(option.xAxis).toHaveLength(2)
    expect(option.xAxis[0].data).toEqual(['A', 'B', 'C']) // inner labels
    const outer = option.xAxis[1]
    const px = st.categoryAxis.font.sizePx
    expect(outer.axisLabel.lineHeight).toBe(Math.round(px * 1.25))
    expect(option.grid.bottom).toBeGreaterThanOrEqual(Math.ceil(px * 1.25 * 2) + 6)
    // one outer label per group, shown at the group's first index
    expect([0, 1, 2].filter((i) => outer.axisLabel.interval(i))).toEqual([0, 2])
    expect(outer.axisLabel.formatter('Other', 2)).toBe(fitLabel('Other', option.xAxis[0].axisLabel.formatter ? 1e3 : 0, px) || 'Other')
    expect(option.xAxis[0].axisLabel.rotate).toBe(90) // nested axes go 90 degrees
  })

  it('horizontal bars reserve right room for value labels', () => {
    const base = spec({ visual_type: 'clusteredBarChart' })
    const labelled = spec({ visual_type: 'clusteredBarChart', objects: { labels: [{ properties: { show: L('true') } }] } })
    const rows = [['A', 1234567], ['B', 7654321]] as (string | number)[][]
    const a = render(base, result(cols, rows)).option.grid.right
    const b = render(labelled, result(cols, rows)).option.grid.right
    expect(b).toBeGreaterThan(a)
  })

  it('auto data-label units choose one unit for the whole visual', () => {
    expect(autoDisplayUnits([1500, 2500000, null])).toBe(1e6)
    expect(autoDisplayUnits([12, 999])).toBe(1)
    const s = spec({ objects: { labels: [{ properties: { show: L('true') } }] } })
    const { option } = render(s, result(cols, [['A', 1500], ['B', 2500000]]))
    const fmt = option.series[0].label.formatter
    expect(fmt({ dataIndex: 0 })).toBe('0.00M')
    expect(fmt({ dataIndex: 1 })).toBe('2.50M')
  })

  it('"show as % of grand total" divides by the totals', () => {
    const s = spec({ measure_show_as: { Sales: 'percent_of_grand_total' }, objects: { labels: [{ properties: { show: L('true') } }] } })
    const data = result(cols, [['A', 25], ['B', 75]], { columns: ['Sales'], row: [100] })
    const { option } = render(s, data)
    expect(option.series[0].data).toEqual([0.25, 0.75])
    expect(option.series[0].label.formatter({ dataIndex: 0 })).toBe('25.00%')
  })

  it('blank spacer measures draw nothing', () => {
    const s = spec({ measure_keys: ['Sales', 'Spacer'] })
    const { option } = render(s, result(['Product.Category', 'Sales', 'Spacer'], [['A', 5, null], ['B', 7, null]]))
    expect(option.series).toHaveLength(1)
  })
})

describe('100% stacked and colours', () => {
  const s = spec({
    visual_type: 'hundredPercentStackedColumnChart',
    series_keys: ['Customer.Country'],
    dim_keys: ['Product.Category', 'Customer.Country'],
    pbir: {
      objects: {
        dataPoint: [{ selector: { metadata: 'Sales.Sales' }, properties: { fill: solid('#112233') } }],
        labels: [{ properties: { show: L('true'), enableValueDataLabel: L('false'), enableDetailDataLabel: L('true'), detailContentType: L("'Percent of total'") } }],
      },
      container_objects: {
        padding: [{ properties: { top: L('0D'), right: L('0D'), bottom: L('0D'), left: L('0D') } }],
        title: [{ properties: { show: L('false') } }],
      },
      fields: [{ role: 'Y', name: 'Sales', is_measure: true, query_ref: 'Sales.Sales' }],
      sort: [], is_hidden: false,
    },
  })
  const data = result(['Product.Category', 'Customer.Country', 'Sales'], [
    ['A', 'DE', 30], ['A', 'US', 10], ['B', 'DE', 5], ['B', 'US', 15],
  ]) // prettier-ignore

  it('normalises each category and shows detail percent labels', () => {
    const { option, bars } = render(s, data)
    expect(option.series).toHaveLength(2)
    expect(option.series[0].data).toEqual([75, 25])
    expect(option.series[1].data).toEqual([25, 75])
    expect(option.yAxis.max).toBe(100)
    const tops = [bars[0], bars[2]].map((b) => Math.round(b.bottom - b.height - 0))
    expect(bars.length).toBe(4)
    // both categories fill the same plot height once stacked
    const columnTop = (idx: number[]) => Math.min(...idx.map((i) => bars[i].bottom - bars[i].height))
    expect(columnTop([0, 2])).toBeCloseTo(columnTop([1, 3]), 0)
    expect(tops).toBeTruthy()
    expect(option.series[0].label.formatter({ dataIndex: 0, value: 75 })).toBe('75%')
  })

  it('per-measure colours come from metadata selectors; others take the palette', () => {
    const { option, st } = render(s, data)
    // series are Country values, so the measure colour applies to the (single) measure key only
    expect(option.series[0].itemStyle.color).toBe(st.palette[0])
    expect(option.series[1].itemStyle.color).toBe(st.palette[1])
    const measureSeries = render(
      spec({ visual_type: 'columnChart', pbir: s.pbir }),
      result(['Product.Category', 'Sales'], [['A', 1]]),
    ).option
    expect(measureSeries.series[0].itemStyle.color).toBe('#112233')
  })
})

describe('pie and donut', () => {
  const base = (objects: object = {}) =>
    spec({ visual_type: 'pieChart', width: 400, height: 300, objects, dim_keys: ['Product.Category'] })
  const cols = ['Product.Category', 'Sales']

  it('drops BLANK and zero slices; explicit colours win, the palette goes to the rest in order', () => {
    const fields = [{ role: 'Category', table: 'Product', name: 'Category', is_measure: false, query_ref: 'Product.Category' }]
    const entity = (v: string) => ({
      data: [{ scopeId: { Comparison: { ComparisonKind: 0,
        Left: { Column: { Expression: { SourceRef: { Entity: 'Product' } }, Property: 'Category' } },
        Right: { Literal: { Value: `'${v}'` } } } } }],
    })
    const s = base({ dataPoint: [{ selector: entity('B'), properties: { fill: solid('#AA0000') } }] })
    s.pbir!.fields = fields
    const { option, st } = render(s, result(cols, [['A', 10], ['B', 20], ['C', 0], ['D', null], ['E', 30]]))
    const data = option.series[0].data as { name: string; itemStyle: { color: string } }[]
    expect(data.map((d) => d.name)).toEqual(['A', 'B', 'E'])
    expect(data.map((d) => d.itemStyle.color)).toEqual([st.palette[0], '#AA0000', st.palette[1]])
  })

  it('sizes the pie so outside labels and a right legend fit', () => {
    const plain = render(base(), result(cols, [['A', 1], ['B', 2]])).option.series[0]
    const labelled = render(
      base({ labels: [{ properties: { show: L('true') } }], legend: [{ properties: { show: L('true'), position: L("'Right'") } }] }),
      result(cols, [['A', 1], ['B', 2]]),
    ).option.series[0]
    expect(labelled.radius[1]).toBeLessThan(plain.radius[1])
    expect(labelled.center[0]).toBeLessThan(plain.center[0])
    expect(labelled.avoidLabelOverlap).toBe(true)
  })

  it('labels are one line unless labelContentLayout says otherwise', () => {
    const rows = [['A', 1234], ['B', 2234]] as (string | number)[][]
    const one = render(base({ labels: [{ properties: { show: L('true') } }] }), result(cols, rows)).option.series[0].label
    const two = render(base({ labels: [{ properties: { show: L('true'), labelContentLayout: L("'TwoLines'") } }] }), result(cols, rows)).option.series[0].label
    expect(one.formatter({ value: 1234, percent: 35 })).not.toContain('\n')
    expect(two.formatter({ value: 1234, percent: 35 })).toContain('\n')
  })

  it('a donut ring follows innerRadiusRatio', () => {
    const s = spec({ visual_type: 'donutChart', objects: { slices: [{ properties: { innerRadiusRatio: L('60D') } }] } })
    const series = render(s, result(cols, [['A', 1], ['B', 2]])).option.series[0]
    expect(series.radius[0] / series.radius[1]).toBeCloseTo(0.6)
  })
})
