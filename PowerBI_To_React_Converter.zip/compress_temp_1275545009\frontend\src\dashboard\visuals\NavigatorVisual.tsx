import { useReportActions } from '../reportContext'
import type { VisualSpec } from '../types'
import { resolveButton } from '../pbi/chrome'
import { fontCss } from '../pbi/fonts'
import { usePbiTheme } from '../pbi/resolve'

/** Bookmark / page navigator: one button per bookmark (by display name) or per visible page. */
export function NavigatorVisual({ spec }: { spec: VisualSpec }) {
  const actions = useReportActions()
  const theme = usePbiTheme()
  const style = resolveButton(spec, theme)
  const items =
    spec.visual_type === 'bookmarkNavigator'
      ? actions.bookmarks.map((b) => ({
          key: b.name,
          label: b.display_name ?? b.name,
          active: false,
          run: () => actions.applyBookmark(b),
        }))
      : actions.pages
          .filter((p) => !p.is_hidden)
          .map((p) => ({
            key: p.name,
            label: p.display_name,
            active: p.name === actions.currentPage,
            run: () => actions.goToPage(p.name),
          }))
  return (
    <div data-testid={`navigator-${spec.name}`} className="flex h-full w-full items-stretch gap-1 overflow-hidden">
      {items.map((item) => (
        <button
          key={item.key}
          type="button"
          onClick={item.run}
          data-active={item.active}
          className="flex-1 truncate px-2"
          style={{
            ...fontCss(style.text.font),
            color: style.text.color,
            background: item.active ? (style.fill ?? '#F3F2F1') : (style.fill ?? 'transparent'),
            border: style.outline ? `${style.outline.weightPx}px solid ${style.outline.color}` : 'none',
            fontWeight: item.active ? 700 : style.text.font.weight,
          }}
        >
          {item.label}
        </button>
      ))}
    </div>
  )
}
