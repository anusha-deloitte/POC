"""Snowflake query audit: which SQL ran on Snowflake for which pane.

Events are `dashboard_query` JSON lines in `<conversion>/events.jsonl`, written best-effort (never
break a query). Connections used by the conversion pipeline are wrapped in `AuditedConnection` so
every real `execute` produces one event; live dashboard queries write their own richer records.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager, nullcontext
from pathlib import Path
from typing import Any

from app.core.logging import append_jsonl

SCHEMA_VERSION = "1.1"
MAX_EVENTS = 20000
MAX_HISTORY = 50
TITLE_SUFFIX = "#title"
STATUSES = ("ok", "empty", "error", "plan_error", "cached")
KINDS = ("dashboard", "totals", "drill", "validation", "probe", "ai_check", "ai_llm", "setup")
KIND_GROUPS = {"conversion": ("validation", "probe", "ai_check", "ai_llm")}
LABELS = {
    "ai_llm_rewrite": "AI model call (DAX rewrite)",
    "ai_llm_sql": "AI model call (SQL translation)",
    "ai_llm_preflight": "Cortex preflight",
    "identifier_case_check": "Identifier case check",
    "access_preflight": "Access preflight",
    "slicer_value_check": "Slicer value check",
}

_SQL_FIELDS = ("sql", "compat_sql", "totals_sql")


def write_query_event(path: Path, record: dict[str, Any]) -> None:
    """Append one `dashboard_query` event; SQL text only when `log_sql_text` is on."""
    try:
        from app.core.config import get_settings

        rec = dict(record)
        if get_settings().log_sql_text:
            rec["sql_logged"] = True
        else:
            for key in _SQL_FIELDS:
                rec.pop(key, None)
            rec["sql_logged"] = False
        append_jsonl(path, "dashboard_query", **rec)
    except Exception:  # noqa: BLE001, S110 - auditing must never break a query
        pass


# ------------------------------------------------------------------ SQL context registry

_CONTEXT_LIMIT = 20000
_contexts: dict[str, str] = {}
_contexts_lock = threading.Lock()


def remember_sql_context(sql: str, context: str | None) -> None:
    if not context:
        return
    with _contexts_lock:
        if len(_contexts) >= _CONTEXT_LIMIT:
            _contexts.clear()
        _contexts[sql] = context


def sql_context_for(sql: str) -> str | None:
    with _contexts_lock:
        return _contexts.get(sql)


def parse_context(context: str | None) -> tuple[str | None, str | None, str | None]:
    """(page, visual-or-measure, check) of an audit context label."""
    if not context:
        return None, None, None
    head, _, rest = context.partition(":")
    if head in LABELS and not rest:
        return None, None, head
    if head in ("visual", "probe") and rest:
        target, _, check = rest.partition(":")
        page, _, name = target.partition("/")
        return page or None, name or None, check or head
    if head in ("ai_rewrite_gate", "ai_sql_check", "ai_llm_rewrite", "ai_llm_sql") and rest:
        return None, rest, head
    if head in ("parity_expected", "parity_actual") and rest:
        page, _, name = rest.partition("/")
        return page or None, name or None, head
    return None, None, context


# ------------------------------------------------------------------ audited connections


class AuditedCursor:
    def __init__(self, cursor: Any, connection: AuditedConnection):
        self._cursor = cursor
        self.connection = connection

    def __getattr__(self, name: str) -> Any:
        return getattr(self._cursor, name)

    def execute(self, sql: str, *args: Any, **kwargs: Any):
        conn = self.connection
        started = time.perf_counter()
        error: str | None = None
        try:
            return self._cursor.execute(sql, *args, **kwargs)
        except Exception as e:
            error = str(e)
            raise
        finally:
            conn._record(self._cursor, sql, started, error)

    def close(self) -> None:
        self._cursor.close()


class AuditedConnection:
    """A connection whose cursors write one audit event per real `execute`."""

    def __init__(
        self,
        conn: Any,
        events_path: Path,
        *,
        conversion_id: str,
        connection_id: str | None = None,
        profile: dict | None = None,
        kind: str = "validation",
        source: str = "conversion",
        extra: dict | None = None,
    ):
        self._conn = conn
        self.events_path = Path(events_path)
        self.conversion_id = conversion_id
        self.connection_id = connection_id
        self.profile = profile or {}
        self.kind = kind
        self.context: str | None = None
        self.source = source
        self.extra = extra or {}

    def __getattr__(self, name: str) -> Any:
        return getattr(self._conn, name)

    def cursor(self, *args: Any, **kwargs: Any) -> AuditedCursor:
        return AuditedCursor(self._conn.cursor(*args, **kwargs), self)

    def close(self) -> None:
        self._conn.close()

    @contextmanager
    def stage(self, kind: str, context: str | None = None) -> Iterator[None]:
        prev = (self.kind, self.context)
        self.kind, self.context = kind, context
        try:
            yield
        finally:
            self.kind, self.context = prev

    def _record(self, cursor: Any, sql: str, started: float, error: str | None) -> None:
        context = self.context or sql_context_for(sql)
        page, visual, check = parse_context(context)
        rowcount = getattr(cursor, "rowcount", None)
        row_count = rowcount if isinstance(rowcount, int) and rowcount >= 0 else None
        status = "error" if error else ("empty" if rowcount == 0 else "ok")
        record = {
            "conversion_id": self.conversion_id,
            "connection_id": self.connection_id,
            "source": self.source,
            "runtime": "snowflake",
            **self.profile,
            **self.extra,
            "kind": self.kind,
            "context": context,
            "page": page,
            "visual": visual,
            "check": check,
            "attempt": "primary",
            "status": status,
            "elapsed_ms": round((time.perf_counter() - started) * 1000),
            "row_count": row_count,
            "error": error,
            "query_id": getattr(cursor, "sfqid", None),
            "sql": sql,
        }
        write_query_event(self.events_path, record)


def audit_stage(cursor_or_conn: Any, kind: str, context: str | None = None):
    """Switch the audited connection behind a cursor to (kind, context) for a `with` block;
    a no-op for plain cursors/connections."""
    conn = getattr(cursor_or_conn, "connection", cursor_or_conn)
    if isinstance(conn, AuditedConnection):
        return conn.stage(kind, context)
    return nullcontext()


# ------------------------------------------------------------------ reading

_CHUNK = 64 * 1024


def read_query_events(path: Path, limit: int = MAX_EVENTS) -> list[dict[str, Any]]:
    """`dashboard_query` events, newest first, read backwards in 64 KiB chunks (capped)."""
    import json

    path = Path(path)
    if not path.is_file():
        return []
    events: list[dict[str, Any]] = []
    with path.open("rb") as f:
        f.seek(0, 2)
        pos = f.tell()
        tail = b""
        while pos > 0 and len(events) < limit:
            step = min(_CHUNK, pos)
            pos -= step
            f.seek(pos)
            buf = f.read(step) + tail
            lines = buf.split(b"\n")
            tail = lines[0] if pos > 0 else b""
            chunk = lines[1:] if pos > 0 else lines
            for raw in reversed(chunk):
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    ev = json.loads(raw)
                except ValueError:
                    continue
                if ev.get("event") == "dashboard_query":
                    events.append(ev)
                    if len(events) >= limit:
                        break
    return events


def _pane_index(spec: Any) -> dict[tuple[str, str], tuple[str, Any]]:
    index: dict[tuple[str, str], tuple[str, Any]] = {}
    for p in getattr(spec, "pages", []) or []:
        for v in p.visuals:
            index[(p.name, v.name)] = (p.display_name, v)
    return index


def _pane_name(visual: Any, latest_title: str | None) -> str:
    if visual is None:
        return ""
    return visual.title or latest_title or f"{visual.visual_type} {visual.name}"


def _kind_matches(kind: str, wanted: str | None) -> bool:
    if not wanted or wanted == "all":
        return True
    if wanted in KIND_GROUPS:
        return kind in KIND_GROUPS[wanted]
    return kind == wanted


def _label_for(rec: dict[str, Any]) -> str | None:
    kind, check, visual = rec.get("kind"), rec.get("check"), rec.get("visual")
    if kind == "setup":
        return LABELS.get(check or "", check)
    if kind == "probe" and visual:
        return f"Filter probe: [{visual}]"
    if kind == "ai_check" and not rec.get("page"):
        return f"AI check: [{visual}]" if visual else "AI check"
    if kind == "ai_llm":
        base = LABELS.get(check or "", "AI model call")
        return f"{base} [{visual}]" if visual else base
    return None


def load_query_audit(
    path: Path,
    spec: Any,
    *,
    source: str = "all",
    page: str | None = None,
    history_for: str | None = None,
    kind: str = "dashboard",
    limit: int = MAX_EVENTS,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """(records, summary): the latest run per (kind, page, visual, check, attempt), or one pane's
    history (newest first, at most MAX_HISTORY runs)."""
    events = read_query_events(path, limit)
    panes = _pane_index(spec)
    titles: dict[tuple[str, str], str] = {}
    for ev in events:  # newest first: the first title value seen is the latest
        tv = ev.get("title_value")
        if tv and ev.get("page") and ev.get("visual"):
            titles.setdefault((ev["page"], str(ev["visual"]).removesuffix(TITLE_SUFFIX)), str(tv))

    def enrich(ev: dict[str, Any]) -> dict[str, Any]:
        rec = {k: v for k, v in ev.items() if k != "event"}
        legacy = "status" not in ev
        if legacy:
            rec["status"] = "error" if ev.get("error") else "ok"
        rec["legacy"] = legacy
        rec.setdefault("kind", "dashboard")
        rec.setdefault("attempt", "primary")
        rec.setdefault("source", "editor")
        visual = rec.get("visual")
        is_title = bool(visual and str(visual).endswith(TITLE_SUFFIX))
        base = str(visual).removesuffix(TITLE_SUFFIX) if visual else None
        entry = panes.get((rec.get("page") or "", base or ""))
        rec["page_name"] = entry[0] if entry else rec.get("page")
        label = _label_for(rec)
        if label is not None:
            pane = label
        elif entry is not None:
            pane = _pane_name(entry[1], titles.get((rec.get("page") or "", base or "")))
        else:
            pane = base or ""
        if is_title and label is None:
            pane += " (title measure)"
        rec["pane"] = pane
        if not rec.get("check"):
            rec["check"] = "main" if rec["kind"] in ("dashboard", "validation") else rec["kind"]
        return rec

    wanted_source = source if source in ("editor", "published") else None
    rows: list[dict[str, Any]] = []
    if history_for:
        hp, _, hv = history_for.partition("/")
        for ev in events:
            if ev.get("page") != hp or str(ev.get("visual", "")).removesuffix(TITLE_SUFFIX) != hv:
                continue
            if wanted_source and ev.get("source", "editor") != wanted_source:
                continue
            rows.append(enrich(ev))
            if len(rows) >= MAX_HISTORY:
                break
        return rows, _summary(rows, len(events), limit, {})

    latest: dict[tuple, dict[str, Any]] = {}
    kinds: dict[str, int] = {}
    for ev in events:
        if wanted_source and ev.get("source", "editor") != wanted_source:
            continue
        if page and ev.get("page") != page:
            continue
        rec = enrich(ev)
        key = (rec["kind"], rec.get("page"), rec.get("visual"), rec.get("check"), rec["attempt"])
        if key in latest:
            continue
        latest[key] = rec
        kinds[rec["kind"]] = kinds.get(rec["kind"], 0) + 1
    rows = [r for r in latest.values() if _kind_matches(r["kind"], kind)]
    rows.sort(
        key=lambda r: (
            str(r.get("page_name") or ""),
            str(r.get("pane") or ""),
            str(r.get("check") or ""),
            0 if r.get("attempt") == "primary" else 1,
        )
    )
    return rows, _summary(rows, len(events), limit, kinds)


def _summary(rows: list[dict], events_read: int, cap: int, kinds: dict[str, int]) -> dict[str, Any]:
    by_status = {s: 0 for s in STATUSES}
    for r in rows:
        status = r.get("status", "ok")
        by_status[status] = by_status.get(status, 0) + 1
    timed = [r for r in rows if r.get("status") != "cached" and r.get("elapsed_ms") is not None]
    slowest = max(timed, key=lambda r: r["elapsed_ms"], default=None)
    return {
        "total": len(rows),
        "panes": len({(r.get("page"), r.get("visual")) for r in rows}),
        **by_status,
        "slowest_ms": slowest["elapsed_ms"] if slowest else None,
        "slowest_pane": slowest.get("pane") if slowest else None,
        "avg_ms": round(sum(r["elapsed_ms"] for r in timed) / len(timed)) if timed else None,
        "warehouses": sorted({r["warehouse"] for r in rows if r.get("warehouse")}),
        "roles": sorted({r["role"] for r in rows if r.get("role")}),
        "sql_logging": any(r.get("sql_logged") for r in rows) if rows else None,
        "events_read": events_read,
        "events_cap": cap,
        "kinds": kinds,
    }


_SEARCH_FIELDS = (
    "page", "page_name", "pane", "visual", "check", "query_id", "sql", "compat_sql", "error",
    "warehouse", "role", "kind", "execution_path",
)  # fmt: skip


def matches_query_search(rec: dict[str, Any], needle: str) -> bool:
    needle = (needle or "").strip().casefold()
    if not needle:
        return True
    hay: list[str] = [str(rec.get(k) or "") for k in _SEARCH_FIELDS]
    for t in rec.get("tables") or []:
        hay.extend([str(t.get("model_table", "")), str(t.get("physical", ""))])
    for f in (rec.get("visual_filters") or []) + (rec.get("request_filters") or []):
        hay.extend([str(f.get("table", "")), str(f.get("column", ""))])
    hay.extend(str(m) for m in rec.get("measures") or [])
    return needle in " ".join(hay).casefold()


def filter_records(
    rows: list[dict[str, Any]], status: str | None = None, search: str | None = None
) -> list[dict[str, Any]]:
    out = rows
    if status and status != "all":
        out = [r for r in out if r.get("status") == status]
    if search:
        out = [r for r in out if matches_query_search(r, search)]
    return out


# ------------------------------------------------------------------ exports


def filter_text(f: dict[str, Any]) -> str:
    values = ", ".join("NULL" if v is None else str(v) for v in f.get("values") or [])
    src = f" [{f['source']}]" if f.get("source") else ""
    return f"{f.get('table')}.{f.get('column')} {f.get('op', 'in')} {values}{src}"


def build_query_audit_json(rows: list[dict], summary: dict, conversion_id: str) -> dict[str, Any]:
    return {
        "schema_version": SCHEMA_VERSION,
        "kind": "snowflake_query_audit",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "conversion_id": conversion_id,
        "summary": summary,
        "records": rows,
    }


_FILTER_LABELS = {
    "slicer": "Slicer",
    "cross_filter": "Cross filter",
    "page_filter": "Page filter",
    "report_filter": "Report filter",
    "drillthrough": "Drill-through",
    "tooltip": "Tooltip",
}


def build_query_audit_xlsx(rows: list[dict], summary: dict, conversion_id: str) -> bytes:
    import io

    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill

    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws.append(["Conversion", conversion_id])
    for key in ("total", "panes", "ok", "empty", "error", "plan_error", "cached", "slowest_ms",
                "slowest_pane", "avg_ms", "events_read"):  # fmt: skip
        ws.append([key.replace("_", " ").capitalize(), summary.get(key)])
    ws.append(["Warehouses", ", ".join(summary.get("warehouses") or [])])
    ws.append(["Roles", ", ".join(summary.get("roles") or [])])
    ws.column_dimensions["A"].width = 24
    ws.column_dimensions["B"].width = 40

    queries = wb.create_sheet("Queries")
    queries.append([
        "Kind", "Page", "Pane", "Check", "Attempt", "Status", "Source", "Rows", "Elapsed ms",
        "Warehouse", "Role", "Connection", "Query ID", "Path", "Tables", "Request filters",
        "Visual filters", "Error", "SQL",
    ])  # fmt: skip
    for c in queries[1]:
        c.font = Font(bold=True)
    colours = {"ok": "C6EFCE", "empty": "FFEB9C", "error": "FFC7CE", "plan_error": "FFC7CE",
               "cached": "DDEBF7"}  # fmt: skip
    for r in rows:
        logged = r.get("sql_logged", True)
        queries.append([
            r.get("kind"), r.get("page_name"), r.get("pane"), r.get("check"), r.get("attempt"),
            r.get("status"), r.get("source"), r.get("row_count"), r.get("elapsed_ms"),
            r.get("warehouse"), r.get("role"), r.get("connection_name"), r.get("query_id"),
            r.get("execution_path"),
            "\n".join(f"{t.get('model_table')} -> {t.get('physical')}"
                      for t in r.get("tables") or []),
            "\n".join(filter_text(f) for f in r.get("request_filters") or []),
            "\n".join(filter_text(f) for f in r.get("visual_filters") or []),
            r.get("error"),
            r.get("sql") if r.get("sql") else ("" if logged else "SQL logging is off"),
        ])  # fmt: skip
        fill = colours.get(r.get("status") or "")
        if fill:
            queries.cell(row=queries.max_row, column=6).fill = PatternFill("solid", fgColor=fill)
    for row in queries.iter_rows(min_row=2):
        for cell in row[14:19]:
            cell.alignment = Alignment(wrap_text=True, vertical="top")
    widths = (11, 20, 28, 14, 10, 11, 10, 8, 11, 16, 14, 18, 38, 16, 36, 40, 40, 40, 90)
    for col, width in zip("ABCDEFGHIJKLMNOPQRS", widths, strict=True):
        queries.column_dimensions[col].width = width

    filters = wb.create_sheet("Filters")
    filters.append(["Page", "Pane", "Scope", "Table", "Column", "Operator", "Values", "Source"])
    for c in filters[1]:
        c.font = Font(bold=True)
    for r in rows:
        for scope, key in (("Request", "request_filters"), ("Visual", "visual_filters")):
            for f in r.get(key) or []:
                filters.append([
                    r.get("page_name"), r.get("pane"), scope, f.get("table"), f.get("column"),
                    f.get("op", "in"),
                    ", ".join("NULL" if v is None else str(v) for v in f.get("values") or []),
                    _FILTER_LABELS.get(f.get("source") or "", f.get("source") or ""),
                ])  # fmt: skip
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
