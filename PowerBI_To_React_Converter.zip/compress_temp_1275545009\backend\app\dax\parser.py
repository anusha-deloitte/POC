"""DAX expression parser (Lark) -> typed AST.

Covers the Tier-0/1 surface: literals, column/measure refs, arithmetic,
comparison, IN, table constructors, function calls, VAR/RETURN, table refs.
Anything outside the grammar raises DaxParseError -> caller routes the measure to Tier 2 (LLM)
or the human queue; we never guess.

Parsing is cached (memory + disk, typed JSON - never pickle) because the same measure text is
parsed many times per conversion and Earley parsing is slow.
"""

from __future__ import annotations

import hashlib
import json
import os
import tempfile
import threading
from dataclasses import dataclass, fields, is_dataclass
from pathlib import Path
from typing import Any

from lark import Lark, Token, Transformer, v_args
from lark.exceptions import LarkError

_GRAMMAR = r"""
?start: expr

?expr: var_expr | or_expr

var_expr: (VAR NAME "=" or_expr)+ RETURN or_expr

?or_expr: and_expr (OR_OP and_expr)*
?and_expr: not_expr (AND_OP not_expr)*
?not_expr: NOT_OP not_expr -> not_op
         | comparison

?comparison: concat
           | concat CMP_OP concat -> cmp
           | concat IN_KW concat  -> in_op
?concat: additive (CONCAT_OP additive)*
?additive: multiplicative ((ADD_OP | SUB_OP) multiplicative)*
?multiplicative: unary ((MUL_OP | DIV_OP) unary)*
?unary: SUB_OP unary -> neg
      | atom

?atom: NUMBER                     -> number
     | STRING                     -> string
     | TRUE_LIT                   -> true_lit
     | FALSE_LIT                  -> false_lit
     | BLANK_CALL                 -> blank
     | table_ctor
     | func_call
     | column_ref
     | measure_ref
     | table_ref
     | var_ref
     | "(" expr ")"

table_ctor: "{" [expr ("," expr)*] "}"

func_call: FUNC_NAME "(" [expr ("," expr)*] ")"

column_ref: TABLE_IDENT "[" COL_NAME "]"
measure_ref: "[" COL_NAME "]"
table_ref: TABLE_IDENT
var_ref: NAME

TABLE_IDENT: /'(?:[^']|'')+'/ | /(?!(?:VAR|RETURN|NOT|TRUE|FALSE|IN)\b)[A-Za-z_][A-Za-z0-9_.]*(?=\s*\[)/
FUNC_NAME: /(?!(?:VAR|RETURN|NOT|TRUE|FALSE|IN)\b)[A-Za-z_][A-Za-z0-9_.]*(?=\s*\()/
NAME: /(?!(?:VAR|RETURN|NOT|TRUE|FALSE|IN)\b)[A-Za-z_][A-Za-z0-9_]*/
COL_NAME: /[^\]]+/
NUMBER: /\d+(\.\d+)?([eE][+-]?\d+)?/
STRING: /"(?:[^"]|"")*"/
VAR: /VAR\b/i
RETURN: /RETURN\b/i
NOT_OP: /NOT\b/i
IN_KW: /IN\b/i
TRUE_LIT: /TRUE\b(\s*\(\s*\))?/i
FALSE_LIT: /FALSE\b(\s*\(\s*\))?/i
BLANK_CALL: /BLANK\s*\(\s*\)/i
OR_OP: "||"
AND_OP: "&&"
CONCAT_OP: /&(?!&)/
CMP_OP: "<=" | ">=" | "<>" | "==" | "=" | "<" | ">"
ADD_OP: "+"
SUB_OP: "-"
MUL_OP: "*"
DIV_OP: "/"

%import common.WS
%ignore WS
%ignore /\/\/[^\n]*/
%ignore /\/\*(.|\n)*?\*\//
"""

_AST_VERSION = "ast-v1"
GRAMMAR_VERSION = hashlib.sha256((_GRAMMAR + "|" + _AST_VERSION).encode()).hexdigest()[:16]


class DaxParseError(Exception):
    pass


# ---------- AST ----------


@dataclass(frozen=True)
class Num:
    value: float


@dataclass(frozen=True)
class Str:
    value: str


@dataclass(frozen=True)
class Bool:
    value: bool


@dataclass(frozen=True)
class Blank:
    pass


@dataclass(frozen=True)
class ColumnRef:
    table: str
    column: str


@dataclass(frozen=True)
class MeasureRef:
    name: str


@dataclass(frozen=True)
class TableRef:
    name: str


@dataclass(frozen=True)
class VarRef:
    name: str


@dataclass(frozen=True)
class FuncCall:
    name: str  # uppercased
    args: tuple


@dataclass(frozen=True)
class BinOp:
    op: str
    left: object
    right: object


@dataclass(frozen=True)
class UnaryOp:
    op: str
    operand: object


@dataclass(frozen=True)
class VarExpr:
    bindings: tuple[tuple[str, object], ...]
    body: object


@dataclass(frozen=True)
class TableCtor:
    values: tuple


_NODE_TYPES = {
    c.__name__: c
    for c in (
        Num, Str, Bool, Blank, ColumnRef, MeasureRef, TableRef, VarRef,
        FuncCall, BinOp, UnaryOp, VarExpr, TableCtor,
    )
}  # fmt: skip


def _unquote_table(name: str) -> str:
    return name[1:-1].replace("''", "'") if name.startswith("'") else name


@v_args(inline=True)
class _ToAst(Transformer):
    def number(self, tok: Token):
        return Num(float(tok))

    def string(self, tok: Token):
        return Str(str(tok)[1:-1].replace('""', '"'))

    def true_lit(self, _tok):
        return Bool(True)

    def false_lit(self, _tok):
        return Bool(False)

    def blank(self, _tok):
        return Blank()

    def column_ref(self, table: Token, col: Token):
        return ColumnRef(_unquote_table(str(table)), str(col).strip())

    def measure_ref(self, col: Token):
        return MeasureRef(str(col).strip())

    def table_ref(self, tok: Token):
        return TableRef(_unquote_table(str(tok)))

    def var_ref(self, tok: Token):
        return VarRef(str(tok))

    def table_ctor(self, *values):
        return TableCtor(tuple(v for v in values if v is not None))

    def func_call(self, name: Token, *args):
        items = tuple(a for a in args if a is not None)
        if str(name).upper() == "BLANK" and not items:
            return Blank()
        return FuncCall(str(name).upper(), items)

    def not_op(self, _op, operand):
        return UnaryOp("NOT", operand)

    def neg(self, _op, operand):
        return UnaryOp("-", operand)

    def cmp(self, left, op, right):
        sym = str(op)
        return BinOp("=" if sym == "==" else sym, left, right)

    def in_op(self, left, _kw, right):
        return BinOp("IN", left, right)

    def additive(self, first, *rest):
        node = first
        for i in range(0, len(rest), 2):
            node = BinOp(str(rest[i]), node, rest[i + 1])
        return node

    def concat(self, first, *rest):
        node = first
        for i in range(0, len(rest), 2):
            node = BinOp("&", node, rest[i + 1])
        return node

    def multiplicative(self, first, *rest):
        node = first
        for i in range(0, len(rest), 2):
            node = BinOp(str(rest[i]), node, rest[i + 1])
        return node

    def or_expr(self, first, *rest):
        node = first
        for i in range(0, len(rest), 2):
            node = BinOp("||", node, rest[i + 1])
        return node

    def and_expr(self, first, *rest):
        node = first
        for i in range(0, len(rest), 2):
            node = BinOp("&&", node, rest[i + 1])
        return node

    def var_expr(self, *items):
        bindings = []
        i = 0
        while i < len(items):
            tok = items[i]
            if isinstance(tok, Token) and tok.type == "VAR":
                bindings.append((str(items[i + 1]), items[i + 2]))
                i += 3
            elif isinstance(tok, Token) and tok.type == "RETURN":
                return VarExpr(tuple(bindings), items[i + 1])
            else:
                i += 1
        raise DaxParseError("VAR expression without RETURN")


_parser = Lark(_GRAMMAR, parser="earley", maybe_placeholders=False)
_transformer = _ToAst()


# ---------- comments ----------


def strip_comments(text: str) -> str:
    """Remove `//`, `--` (to end of line) and `/* */` outside string literals (`""` escape),
    quoted names (`''` escape) and `[...]` brackets."""
    out: list[str] = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch == '"':
            j = i + 1
            while j < n:
                if text[j] == '"':
                    if j + 1 < n and text[j + 1] == '"':
                        j += 2
                        continue
                    break
                j += 1
            out.append(text[i : j + 1])
            i = j + 1
        elif ch == "'":
            j = i + 1
            while j < n:
                if text[j] == "'":
                    if j + 1 < n and text[j + 1] == "'":
                        j += 2
                        continue
                    break
                j += 1
            out.append(text[i : j + 1])
            i = j + 1
        elif ch == "[":
            j = text.find("]", i)
            j = n - 1 if j < 0 else j
            out.append(text[i : j + 1])
            i = j + 1
        elif text.startswith("//", i) or text.startswith("--", i):
            j = text.find("\n", i)
            i = n if j < 0 else j
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            i = n if j < 0 else j + 2
            out.append(" ")
        else:
            out.append(ch)
            i += 1
    return "".join(out)


# ---------- typed-JSON (de)serialization of the AST ----------


class _CacheMiss(Exception):
    pass


def _encode(node: Any) -> Any:
    if is_dataclass(node) and not isinstance(node, type):
        return {"t": type(node).__name__, "f": {f.name: _encode(getattr(node, f.name)) for f in fields(node)}}
    if isinstance(node, tuple):
        return {"t": "tuple", "v": [_encode(x) for x in node]}
    if isinstance(node, bool | int | float | str) or node is None:
        return node
    raise TypeError(f"cannot encode {type(node).__name__}")


def _decode(data: Any) -> Any:
    if isinstance(data, dict):
        kind = data.get("t")
        if kind == "tuple":
            return tuple(_decode(x) for x in data.get("v", []))
        cls = _NODE_TYPES.get(kind) if isinstance(kind, str) else None
        if cls is None:
            raise _CacheMiss(f"unknown node type {kind!r}")
        raw = data.get("f")
        names = {f.name for f in fields(cls)}
        if not isinstance(raw, dict) or set(raw) != names:
            raise _CacheMiss("malformed node")
        return cls(**{k: _decode(v) for k, v in raw.items()})
    if isinstance(data, list):
        raise _CacheMiss("unexpected list")
    return data


# ---------- cache ----------

_MAX_MEMORY_ENTRIES = 50_000
_memory: dict[str, tuple[str, Any]] = {}  # text -> ("ast", node) | ("error", message)
_memory_lock = threading.Lock()
_cache_dir_override: Path | None = None
_cache_disabled = False


def set_parse_cache_dir(path: Path | str | None, disabled: bool = False) -> None:
    """Tests isolate or disable the disk cache; always clears the in-memory cache."""
    global _cache_dir_override, _cache_disabled
    _cache_dir_override = Path(path) if path is not None else None
    _cache_disabled = disabled
    clear_memory_cache()


def clear_memory_cache() -> None:
    with _memory_lock:
        _memory.clear()


def _cache_root() -> Path | None:
    if _cache_disabled:
        return None
    if _cache_dir_override is not None:
        return _cache_dir_override
    try:
        from app.core.config import get_settings

        return get_settings().storage_dir.parent / "cache" / "dax"
    except Exception:  # noqa: BLE001 - the cache is an optimisation only
        return None


def _key(text: str) -> str:
    return hashlib.sha256((GRAMMAR_VERSION + "\0" + text).encode()).hexdigest()


def _disk_path(text: str) -> Path | None:
    root = _cache_root()
    if root is None:
        return None
    k = _key(text)
    return root / k[:2] / f"{k}.json"


def _disk_read(text: str) -> tuple[str, Any] | None:
    path = _disk_path(text)
    if path is None or not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if data.get("grammar") != GRAMMAR_VERSION or data.get("text") != text:
            return None
        if "error" in data:
            return ("error", str(data["error"]))
        return ("ast", _decode(data["ast"]))
    except (OSError, ValueError, KeyError, TypeError, AttributeError, _CacheMiss):
        return None


def _disk_write(text: str, entry: tuple[str, Any]) -> None:
    path = _disk_path(text)
    if path is None:
        return
    payload: dict[str, Any] = {"grammar": GRAMMAR_VERSION, "text": text}
    if entry[0] == "error":
        payload["error"] = entry[1]
    else:
        payload["ast"] = _encode(entry[1])
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f)
        os.replace(tmp, path)
    except (OSError, TypeError):
        return


def _remember(text: str, entry: tuple[str, Any]) -> None:
    with _memory_lock:
        if len(_memory) >= _MAX_MEMORY_ENTRIES:
            _memory.clear()
        _memory[text] = entry


def parse_dax_uncached(expression: str):
    try:
        return _transformer.transform(_parser.parse(strip_comments(expression).strip()))
    except LarkError as e:
        raise DaxParseError(f"cannot parse DAX: {e}") from e


def _lookup_cached(text: str) -> tuple[str, Any] | None:
    with _memory_lock:
        hit = _memory.get(text)
    if hit is not None:
        return hit
    hit = _disk_read(text)
    if hit is not None:
        _remember(text, hit)
    return hit


def parse_dax(expression: str):
    text = expression
    hit = _lookup_cached(text)
    if hit is None:
        try:
            hit = ("ast", parse_dax_uncached(text))
        except DaxParseError as e:
            hit = ("error", str(e))
        _remember(text, hit)
        _disk_write(text, hit)
    if hit[0] == "error":
        raise DaxParseError(hit[1])
    return hit[1]


def warm_parse_cache(expressions) -> int:
    """Parse each distinct uncached text once; returns how many were parsed."""
    parsed = 0
    for text in dict.fromkeys(expressions):
        if _lookup_cached(text) is not None:
            continue
        try:
            parse_dax(text)
        except DaxParseError:
            pass
        parsed += 1
    return parsed
