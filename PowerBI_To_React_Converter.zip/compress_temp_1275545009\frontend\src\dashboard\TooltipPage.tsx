import { useQuery } from '@tanstack/react-query'
import { useMemo } from 'react'
import { fetchVisualData, type DashboardApiConfig } from './api'
import { queryVisualNames } from './canvas'
import { paneClauses, type PaneState } from './filtersPaneState'
import { PageCanvas } from './PageCanvas'
import type { DashboardSpec, FilterClause, PageSpec } from './types'

/** A report-page tooltip: the Tooltip page drawn at its own size next to the pointer (kept inside
 * the viewport), queried with the report cards + its own cards + the data point's context. The
 * parent supplies the theme / report contexts so images and fonts match the report. */
export function TooltipPage({
  spec,
  page,
  context,
  paneState,
  at,
  conversionId,
  connectionId,
  apiConfig,
}: {
  spec: DashboardSpec
  page: PageSpec
  context: FilterClause[]
  paneState: PaneState
  at: { x: number; y: number }
  conversionId: string
  connectionId: string
  apiConfig?: DashboardApiConfig
}) {
  const clauses = useMemo(
    () => [...paneClauses(spec, page, paneState), ...context],
    [spec, page, paneState, context],
  )
  const names = queryVisualNames(page)
  const filtersByVisual = useMemo(
    () => Object.fromEntries(names.map((n) => [n, clauses])),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [clauses, page.name],
  )
  const data = useQuery({
    queryKey: ['dash-tooltip', conversionId, page.name, clauses],
    queryFn: () =>
      fetchVisualData(conversionId, connectionId, page.name, names, filtersByVisual, 'live', undefined, apiConfig),
    staleTime: 5 * 60_000,
  })
  const margin = 12
  const left = Math.max(margin, Math.min(at.x + margin, window.innerWidth - page.width - margin))
  const top = Math.max(margin, Math.min(at.y + margin, window.innerHeight - page.height - margin))
  return (
    <div
      role="tooltip"
      data-testid="tooltip-page"
      className="pointer-events-none fixed z-[1100] overflow-hidden rounded-lg border border-surface-300 bg-white shadow-xl"
      style={{ left, top, width: page.width, height: page.height }}
    >
      <PageCanvas
        page={page}
        results={data.data ?? {}}
        slicerState={{}}
        onSlicerChange={() => undefined}
        fit="ActualSize"
        annotations={false}
      />
    </div>
  )
}
