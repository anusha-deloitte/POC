"""Power BI Filters-pane cards: report ("Filters on all pages") and page ("Filters on this page")
filters turned into engine filters, applied everywhere by default (hidden and locked included).

Re-exported by `runtime/dashboard.py`.
"""

from __future__ import annotations

import itertools
from typing import Any, Literal

from pydantic import BaseModel, Field

from app.ir.report import Filter, ReportBundle
from app.parsers.pbir import _field_ref
from app.runtime import sql_render as sr
from app.runtime.engine import DimensionRef, FilterClause, QuerySpec

ENGINE_FILTER_OPS = frozenset(
    {
        "in", "not_in", "eq", "neq", "gt", "gte", "lt", "lte", "contains", "not_contains",
        "starts_with", "not_starts_with", "is_blank", "is_not_blank", "is_empty", "is_not_empty",
        "topn", "relative", "between_dates",
    }
)  # fmt: skip


class FilterCondition(BaseModel):
    op: str
    values: list = Field(default_factory=list)
    params: dict = Field(default_factory=dict)


class FilterDefault(BaseModel):
    join: Literal["and", "or"] = "and"
    conditions: list[FilterCondition] = Field(default_factory=list)


class FilterCard(BaseModel):
    name: str
    scope: Literal["report", "page"]
    table: str | None = None
    column: str | None = None
    display_name: str = ""
    data_type: str | None = None
    kind: Literal["basic", "advanced", "topn", "relative"] = "basic"
    default: FilterDefault | None = None  # None = "(All)"
    require_single: bool = False
    hidden: bool = False
    locked: bool = False
    supported: bool = True
    reason: str | None = None


class _Refused(Exception):
    """A saved filter this converter can't reproduce; the message is the card's reason."""


# ---------------------------------------------------------------- conditions

_NEGATE = {
    "eq": "neq",
    "in": "not_in",
    "contains": "not_contains",
    "starts_with": "not_starts_with",
}
_COMPARISON = {0: "eq", 1: "gt", 2: "gte", 3: "lt", 4: "lte"}


def _literal(node: Any) -> Any:
    from app.runtime.pbir_passthrough import _decode

    raw = (node or {}).get("Literal", {}).get("Value") if isinstance(node, dict) else None
    return _decode(raw) if raw is not None else None


def _target(expr: Any) -> tuple[str, str] | None:
    """("Measure" | "Column", name) of a condition expression."""
    if isinstance(expr, dict):
        for kind in ("Measure", "Column"):
            if kind in expr and isinstance(expr[kind], dict) and expr[kind].get("Property"):
                return kind, expr[kind]["Property"]
    return None


def _condition_to_filter(cond: dict) -> tuple[str, None, str, str, list] | None:
    """`(kind, None, name, op, values)` of one PBIR condition (the table comes from the card's
    field), or None when it can't be expressed."""
    if not isinstance(cond, dict):
        return None
    if "Not" in cond:
        inner = _condition_to_filter((cond["Not"] or {}).get("Expression") or {})
        if inner is None or inner[3] not in _NEGATE:
            return None
        kind, _, name, op, values = inner
        return kind, None, name, _NEGATE[op], values
    for key, op in (("Contains", "contains"), ("StartsWith", "starts_with")):
        if key in cond:
            node = cond[key]
            target = _target(node.get("Left"))
            value = _literal(node.get("Right"))
            if target is None or value is None:
                return None
            return target[0], None, target[1], op, [value]
    if "In" in cond:
        node = cond["In"]
        exprs = node.get("Expressions") or []
        if len(exprs) != 1 or "Values" not in node:  # no Values = a Top N subquery
            return None
        target = _target(exprs[0])
        if target is None:
            return None
        values = []
        for tup in node["Values"] or []:
            for item in tup:
                values.append(_literal(item))
        return target[0], None, target[1], "in", values
    if "Comparison" in cond:
        node = cond["Comparison"]
        op = _COMPARISON.get(node.get("ComparisonKind"))
        target = _target(node.get("Left"))
        right = node.get("Right")
        if op is None or target is None or not isinstance(right, dict) or "Literal" not in right:
            return None
        return target[0], None, target[1], op, [_literal(right)]
    return None


def _kind_of(f: Filter) -> str:
    return {
        "Categorical": "basic",
        "Advanced": "advanced",
        "TopN": "topn",
        "RelativeDate": "relative",
        "RelativeTime": "relative",
    }.get(f.filter_type, "advanced")


def _where_conditions(f: Filter) -> list[dict]:
    return [
        w.get("Condition") or {}
        for w in ((f.definition or {}).get("Where") or [])
        if isinstance(w, dict)
    ]


def _condition_default(cond: dict, f: Filter) -> FilterDefault:
    """A basic / advanced card's saved condition (an And/Or of two = one join, two conditions)."""
    for key, join in (("And", "and"), ("Or", "or")):
        if key in cond:
            parts = [cond[key].get("Left") or {}, cond[key].get("Right") or {}]
            out = []
            for part in parts:
                one = _condition_to_filter(part)
                if one is None:
                    raise _Refused("filter condition shape not supported")
                out.append(one)
            return FilterDefault(
                join=join, conditions=[FilterCondition(op=o[3], values=o[4]) for o in out]
            )
    one = _condition_to_filter(cond)
    if one is None:
        raise _Refused("filter condition shape not supported")
    return FilterDefault(conditions=[FilterCondition(op=one[3], values=one[4])])


def _card_default(f: Filter) -> FilterDefault | None:
    conditions = _where_conditions(f)
    if not conditions:
        return None
    merged: list[FilterCondition] = []
    join = "and"
    for cond in conditions:
        d = _condition_default(cond, f)
        if len(conditions) > 1 and d.join == "or":
            raise _Refused("filter condition shape not supported")
        join = d.join
        merged.extend(d.conditions)
    for c in merged:
        if c.op not in ENGINE_FILTER_OPS:
            raise _Refused(f"operator {c.op} not supported")
    return FilterDefault(join=join, conditions=merged)  # type: ignore[arg-type]


# ---------------------------------------------------------------- Top N


def _topn_default(f: Filter, compiler: Any = None) -> FilterDefault:
    query = None
    for src in (f.definition or {}).get("From") or []:
        sub = ((src or {}).get("Expression") or {}).get("Subquery")
        if isinstance(sub, dict) and isinstance(sub.get("Query"), dict):
            query = sub["Query"]
            break
    if query is None:
        raise _Refused("Top N definition not recognised")
    n = query.get("Top")
    order = (query.get("OrderBy") or [None])[0]
    if isinstance(n, bool) or not isinstance(n, int) or n < 1 or not isinstance(order, dict):
        raise _Refused("Top N definition not recognised")
    table, name, is_measure, extras = _field_ref(order.get("Expression") or {})
    if not name:
        raise _Refused("Top N definition not recognised")
    params: dict[str, Any] = {
        "n": n,
        "direction": "bottom" if order.get("Direction") == 1 else "top",
    }
    if is_measure:
        params["measure"] = name
        if compiler is not None:
            try:
                compiler.compile_measure(name)
            except Exception as e:  # noqa: BLE001 - DaxUnsupported and friends
                raise _Refused(
                    f"Top N 'By value' measure [{name}] could not be translated: {e}"
                ) from e
    else:
        if not table:
            raise _Refused("Top N definition not recognised")
        params.update(table=table, column=name, aggregate=extras.get("aggregate"))
    return FilterDefault(conditions=[FilterCondition(op="topn", params=params)])


# ---------------------------------------------------------------- relative date / time

_UNIT_CODE = {"day": 0, "week": 1, "month": 2, "year": 3, "minute": 6, "hour": 7}
_NOW: dict = {"Now": {}}


def _add(expr: dict, amount: int, unit: str) -> dict:
    return {"DateAdd": {"Expression": expr, "Amount": amount, "TimeUnit": _UNIT_CODE[unit]}}


def _span(expr: dict, unit: str) -> dict:
    return {"DateSpan": {"Expression": expr, "TimeUnit": _UNIT_CODE[unit]}}


def relative_bounds(ui: dict) -> tuple[dict, dict]:
    """The PBIR (lower, upper) bound trees of a relative card UI
    `{direction: last|next|this, n, unit, calendar, include_today}`."""
    direction, unit = ui["direction"], ui["unit"]
    n = int(ui.get("n", 1))
    if direction == "this":
        return _span(_NOW, unit), _span(_NOW, unit)
    if unit in ("minute", "hour"):
        if direction == "last":
            return _add(_NOW, -n, unit), _NOW
        return _NOW, _add(_NOW, n, unit)
    if ui.get("calendar") and unit != "day":
        if direction == "last":
            return _span(_add(_NOW, -n, unit), unit), _span(_add(_NOW, -1, unit), unit)
        return _span(_add(_NOW, 1, unit), unit), _span(_add(_NOW, n, unit), unit)
    include = bool(ui.get("include_today"))
    if direction == "last":
        if include:
            return _span(_add(_add(_NOW, 1, "day"), -n, unit), "day"), _span(_NOW, "day")
        return _span(_add(_NOW, -n, unit), "day"), _span(_add(_NOW, -1, "day"), "day")
    if include:
        return _span(_NOW, "day"), _span(_add(_add(_NOW, -1, "day"), n, unit), "day")
    return _span(_add(_NOW, 1, "day"), "day"), _span(_add(_NOW, n, unit), "day")


def _amounts(tree: Any, out: set[int]) -> None:
    if isinstance(tree, dict):
        node = tree.get("DateAdd")
        if isinstance(node, dict) and isinstance(node.get("Amount"), int):
            out.add(abs(node["Amount"]))
        for v in tree.values():
            _amounts(v, out)


def _recognise_relative(params: dict) -> dict | None:
    """A UI setting that reproduces the bounds exactly (None: the filter still applies, the card
    just can't show it)."""
    lower, upper = params.get("lower"), params.get("upper")
    amounts: set[int] = {1}
    _amounts(lower, amounts)
    _amounts(upper, amounts)
    for direction, unit, calendar, include in itertools.product(
        ("this", "last", "next"), _UNIT_CODE, (False, True), (False, True)
    ):
        for n in sorted(amounts):
            ui = {"direction": direction, "n": n, "unit": unit, "calendar": calendar,
                  "include_today": include}  # fmt: skip
            try:
                if relative_bounds(ui) == (lower, upper):
                    return ui
            except (KeyError, ValueError):
                continue
    return None


def _relative_default(f: Filter) -> FilterDefault:
    conditions = _where_conditions(f)
    between = (conditions[0] if conditions else {}).get("Between")
    if not isinstance(between, dict):
        raise _Refused("filter condition shape not supported")
    lower, upper = between.get("LowerBound"), between.get("UpperBound")
    params: dict[str, Any] = {
        "lower": lower,
        "upper": upper,
        "time": f.filter_type == "RelativeTime",
    }
    try:
        sr.relative_sql("c", params, "CURRENT_DATE()", "CURRENT_TIMESTAMP()")
    except sr.TemplateError as e:
        raise _Refused(str(e)) from e
    ui = _recognise_relative(params)
    if ui is not None:
        params["ui"] = ui
    return FilterDefault(conditions=[FilterCondition(op="relative", params=params)])


# ---------------------------------------------------------------- cards


def filter_card(f: Filter, bundle: ReportBundle, compiler: Any = None) -> FilterCard | None:
    """One Filters-pane card; None for a drill-through filter (that is the "Drill through" well)."""
    if f.how_created == "Drillthrough":
        return None
    column_name = f.field_name or ""
    card = FilterCard(
        name=f.name or f"{f.field_table}.{column_name}",
        scope=f.scope.value,  # type: ignore[arg-type]
        table=f.field_table,
        column=f.field_name,
        display_name=f.display_name or column_name,
        kind=_kind_of(f),  # type: ignore[arg-type]
        require_single=f.require_single,
        hidden=f.is_hidden,
        locked=f.is_locked,
    )

    def refuse(reason: str) -> FilterCard:
        card.supported, card.reason, card.default = False, reason, None
        return card

    if not f.field_name:
        return refuse("filter field not recognised")
    if f.field_is_measure:
        return refuse("filters on a measure are not supported in the Filters pane")
    table = bundle.model.table(f.field_table or "")
    col = table.column(f.field_name) if table else None
    if col is None:
        return refuse(f"column {f.field_table}[{f.field_name}] not found in the model")
    card.data_type = col.data_type.value
    try:
        if card.kind == "topn":
            card.default = _topn_default(f, compiler)
        elif card.kind == "relative":
            card.default = _relative_default(f)
        else:
            card.default = _card_default(f)
    except _Refused as e:
        return refuse(str(e))
    return card


def ordered_cards(
    filters: list[Filter],
    sort_order: str | None,
    bundle: ReportBundle,
    warnings: list[str],
    scope: str,
    compiler: Any = None,
) -> list[FilterCard]:
    """Cards in the Filters pane's order: Ascending / Descending by title, else by `ordinal`
    (None last) then authoring order. An unsupported card with a saved condition is reported."""
    pairs: list[tuple[int, Filter, FilterCard]] = []
    for i, f in enumerate(filters):
        card = filter_card(f, bundle, compiler)
        if card is None:
            continue
        pairs.append((i, f, card))
        if not card.supported and (f.definition or {}).get("Where"):
            warnings.append(f"{scope} filter '{card.display_name}' not applied: {card.reason}")
    if sort_order in ("Ascending", "Descending"):
        pairs.sort(key=lambda p: p[2].display_name.casefold(), reverse=sort_order == "Descending")
    else:
        pairs.sort(key=lambda p: (p[1].ordinal is None, p[1].ordinal or 0, p[0]))
    return [c for _, _, c in pairs]


def card_clauses(card: FilterCard) -> list[FilterClause]:
    """Engine filters of a card's saved default ([] for an unsupported card or "(All)")."""
    if not card.supported or card.default is None or not card.table or not card.column:
        return []
    source = f"{card.scope}_filter"
    clauses = [
        FilterClause(
            table=card.table,
            column=card.column,
            op=c.op,
            values=list(c.values),
            params=dict(c.params),
            source=source,
        )
        for c in card.default.conditions
    ]
    if card.default.join == "or" and len(clauses) > 1:
        return [
            FilterClause(
                table=card.table, column=card.column, op="or", clauses=clauses, source=source
            )
        ]
    return clauses


def default_filter_clauses(spec: Any, page: Any) -> list[FilterClause]:
    """Report cards + the page's cards (hidden and locked included)."""
    out: list[FilterClause] = []
    for card in [*getattr(spec, "report_filters", []), *getattr(page, "filters", [])]:
        out.extend(card_clauses(card))
    return out


def with_default_filters(spec: Any) -> Any:
    """The spec validated, probed and re-checked: every visual's query, draft query and title
    query carry its page's default filters (the spec itself when nothing applies)."""
    per_page = {p.name: default_filter_clauses(spec, p) for p in spec.pages}
    if not any(per_page.values()):
        return spec
    out = spec.model_copy(deep=True)
    for page in out.pages:
        defaults = per_page.get(page.name) or []
        for vs in page.visuals:
            for attr in ("query", "draft_query", "title_query"):
                q = getattr(vs, attr, None)
                if q is not None:
                    q.filters = [*q.filters, *(c.model_copy(deep=True) for c in defaults)]
    return out


def filter_values_query(table: str, column: str, search: str | None, limit: int) -> QuerySpec:
    """Distinct values of a column for a card: sorted, `limit + 1` rows (to detect truncation),
    never cross-filtered (Power BI behaviour)."""
    filters = []
    if search:
        filters.append(FilterClause(table=table, column=column, op="contains", values=[search]))
    return QuerySpec(
        dimensions=[DimensionRef(table=table, column=column)],
        filters=filters,
        sort=[{"key": f"{table}.{column}", "direction": "Ascending"}],
        limit=limit + 1,
    )


# ---------------------------------------------------------------- bookmarks


def _synthetic_filter(card: FilterCard, item: dict, scope: str) -> Filter:
    return Filter(
        name=card.name,
        scope=scope,  # type: ignore[arg-type]
        field_table=card.table,
        field_name=card.column,
        filter_type=item.get("type") or {
            "basic": "Categorical",
            "advanced": "Advanced",
            "topn": "TopN",
            "relative": "RelativeDate",
        }[card.kind],
        definition=item.get("filter") or {},
    )  # fmt: skip


def _restore(
    cards: list[FilterCard], captured: dict, scope: str, compiler: Any, bundle: Any
) -> dict:
    out: dict[str, Any] = {}
    by_name = {c.name: c for c in cards}
    by_field = {f"{c.table}.{c.column}": c for c in cards}
    for key, item in (captured or {}).items():
        card = by_name.get(key) or by_field.get(key)
        if card is None or not card.supported or card.locked or card.hidden:
            continue
        f = _synthetic_filter(card, item or {}, scope)
        try:
            if card.kind == "topn":
                default = _topn_default(f, compiler)
            elif card.kind == "relative":
                default = _relative_default(f)
            else:
                default = _card_default(f)
        except _Refused:
            continue
        out[card.name] = default.model_dump() if default else None
    return out


def bookmark_filter_values(
    bookmark: Any, spec: Any, bundle: Any = None, compiler: Any = None
) -> Any:
    """`state.filters` -> `state.filter_values = {report: {card: FilterDefault|null}, pages:
    {page: {card: ...}}, slicers: {visual: [values]}}` (only supported, unlocked cards the spec
    shows; a slicer's In condition -> its values, else none). `filters` is removed; bookmarks
    without filters are unchanged."""
    state = dict(bookmark.state or {})
    captured = state.get("filters")
    if not isinstance(captured, dict):
        return bookmark
    pages: dict[str, Any] = {}
    page_by_name = {p.name: p for p in spec.pages}
    for section, items in (captured.get("pages") or {}).items():
        page = page_by_name.get(section)
        if page is not None:
            pages[section] = _restore(list(page.filters), items, "page", compiler, bundle)
    slicers: dict[str, list] = {}
    for visual, flt in (captured.get("slicers") or {}).items():
        values: list = []
        if isinstance(flt, dict):
            for where in flt.get("Where") or []:
                one = _condition_to_filter((where or {}).get("Condition") or {})
                if one is not None and one[3] == "in":
                    values.extend(v for v in one[4] if v is not None)
        slicers[visual] = values
    state.pop("filters", None)
    state["filter_values"] = {
        "report": _restore(
            list(spec.report_filters), captured.get("report") or {}, "report", compiler, bundle
        ),
        "pages": pages,
        "slicers": slicers,
    }
    return bookmark.model_copy(update={"state": state})
