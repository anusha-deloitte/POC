"""Per-measure compilation audit log.

Every measure compilation, tier decision, generated SQL and validation outcome is appended as one
JSON line under `<conversion>/compilation_logs/<conversion_id>_compilation.jsonl`. Primary
`compilation_record` lines are patched by later `compilation_*_patch` lines (tier, SQL,
validation) when the log is loaded, so the file is append-only.
"""

from __future__ import annotations

import io
import json
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from app.core.logging import append_jsonl

COMPILER_TYPES = ("tier0", "tier1", "tier2", "parked", "manual_sql")
AUDIT_SCHEMA_VERSION = "1.0"

_DAX_HEAVY = re.compile(
    r"\b(CALCULATE|SUMX|AVERAGEX|MINX|MAXX|FILTER|DATESINPERIOD)\b", re.IGNORECASE
)


def dax_complexity(dax: str) -> float:
    """min(len/1000, 0.3) + 0.08 per heavy construct + min(max paren depth/10, 0.2), capped at 1."""
    depth = deepest = 0
    for ch in dax or "":
        if ch == "(":
            depth += 1
            deepest = max(deepest, depth)
        elif ch == ")":
            depth = max(0, depth - 1)
    score = (
        min(len(dax or "") / 1000, 0.3)
        + 0.08 * len(_DAX_HEAVY.findall(dax or ""))
        + min(deepest / 10, 0.2)
    )
    return round(min(score, 1.0), 3)


def sql_complexity(sql: str) -> float:
    """min(len/3000,.3) + min(JOIN/10,.2) + min(GROUP BY/5,.2) + min(CASE/5,.15) + min(WITH/3,.15)."""  # noqa: E501
    text = sql or ""

    def count(pattern: str) -> int:
        return len(re.findall(pattern, text, re.IGNORECASE))

    score = (
        min(len(text) / 3000, 0.3)
        + min(count(r"\bJOIN\b") / 10, 0.2)
        + min(count(r"\bGROUP\s+BY\b") / 5, 0.2)
        + min(count(r"\bCASE\b") / 5, 0.15)
        + min(count(r"\bWITH\b") / 3, 0.15)
    )
    return round(min(score, 1.0), 3)


@dataclass
class DaxCompilationRecord:
    model_table: str
    measure_name: str
    dax_expression: str
    dax_complexity_score: float = 0.0
    compiler_type: str = "tier1"
    compilation_status: str = "success"  # success | failed
    compilation_error: str | None = None
    compilation_duration_ms: float = 0.0
    dax_leaves: list[dict] = field(default_factory=list)
    generated_sql: str | None = None
    sql_samples: list[dict] = field(default_factory=list)
    sql_complexity: float | None = None
    sql_error: str | None = None
    validation_attempted: bool = False
    validation_passed: bool | None = None
    validation_error: str | None = None
    timestamp: float = field(default_factory=time.time)

    @property
    def overall_status(self) -> str:
        if self.compilation_status == "failed":
            return "broken"
        if self.validation_attempted and not self.validation_passed:
            return "degraded"
        return "working"

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["overall_status"] = self.overall_status
        return data


def _leaf_summary(compiled: Any) -> list[dict]:
    out = []
    for alias, leaf in getattr(compiled, "leaves", {}).items():
        ctx = leaf.ctx
        shift = ctx.time_shift
        out.append(
            {
                "alias": alias,
                "sql": leaf.sql,
                "tables": sorted(leaf.tables),
                "filters": [p.sql for p in ctx.filters],
                "clears": sorted(str(c) for c in ctx.clears),
                "time_shift": shift.kind if shift else None,
                "grouped": leaf.grouped is not None,
            }
        )
    return out


def summarize_records(records: list[dict]) -> dict[str, Any]:
    total = len(records)
    status = {"working": 0, "degraded": 0, "broken": 0}
    by_type: dict[str, int] = {}
    dax_scores: list[float] = []
    sql_scores: list[float] = []
    for r in records:
        status[r.get("overall_status", "working")] = status.get(r.get("overall_status", "working"), 0) + 1  # noqa: E501
        by_type[r.get("compiler_type", "tier1")] = by_type.get(r.get("compiler_type", "tier1"), 0) + 1  # noqa: E501
        if r.get("dax_complexity_score") is not None:
            dax_scores.append(float(r["dax_complexity_score"]))
        if r.get("sql_complexity") is not None:
            sql_scores.append(float(r["sql_complexity"]))
    return {
        "total": total,
        "working": status["working"],
        "degraded": status["degraded"],
        "broken": status["broken"],
        "percentage_working": round(100 * status["working"] / total, 1) if total else 0.0,
        "by_compiler_type": by_type,
        "avg_dax_complexity": round(sum(dax_scores) / len(dax_scores), 3) if dax_scores else 0.0,
        "avg_sql_complexity": round(sum(sql_scores) / len(sql_scores), 3) if sql_scores else 0.0,
    }


class CompilationLogger:
    def __init__(self, root: Path):
        self.root = Path(root)
        self.path: Path | None = None
        self._records: dict[str, DaxCompilationRecord] = {}

    # ---- lifecycle ----

    def initialize_for_conversion(self, conversion_id: str) -> Path:
        """Start a fresh log for this run (an earlier run's file is replaced)."""
        directory = self.root / "compilation_logs"
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / f"{conversion_id}_compilation.jsonl"
        self.path.write_text("", encoding="utf-8")
        self._records = {}
        return self.path

    def _append(self, event: str, **fields: Any) -> None:
        if self.path is None:
            return
        try:
            append_jsonl(self.path, event, **fields)
        except OSError:  # logging is best effort and never breaks a conversion
            return

    # ---- compilation ----

    def start_record(self, model_table: str, measure_name: str, dax: str) -> DaxCompilationRecord:
        return DaxCompilationRecord(
            model_table=model_table,
            measure_name=measure_name,
            dax_expression=dax,
            dax_complexity_score=dax_complexity(dax),
        )

    def finish_record(
        self, record: DaxCompilationRecord, compiled: Any, duration_ms: float
    ) -> DaxCompilationRecord:
        record.compilation_status = "success"
        tier = getattr(compiled, "tier", 1)
        record.compiler_type = "manual_sql" if tier == 3 else f"tier{tier}"
        record.compilation_duration_ms = round(duration_ms, 2)
        record.dax_leaves = _leaf_summary(compiled)
        self._store(record)
        return record

    def fail_record(
        self, record: DaxCompilationRecord, error: str, compiler_type: str, duration_ms: float
    ) -> DaxCompilationRecord:
        record.compilation_status = "failed"
        record.compilation_error = str(error)[:1000]
        record.compiler_type = compiler_type
        record.compilation_duration_ms = round(duration_ms, 2)
        self._store(record)
        return record

    def _store(self, record: DaxCompilationRecord) -> None:
        self._records[record.measure_name] = record
        self._append("compilation_record", **record.to_dict())

    # ---- patches ----

    def annotate_tier(self, measure: str, compiler_type: str) -> None:
        rec = self._records.get(measure)
        if rec is None:
            return
        rec.compiler_type = compiler_type
        if compiler_type in ("tier2", "manual_sql"):
            rec.compilation_status = "success"
            rec.compilation_error = None
        self._append("compilation_tier_patch", measure_name=measure, compiler_type=compiler_type)

    def annotate_sql(
        self, measure: str, sql: str | None, error: str | None = None, context: str | None = None
    ) -> None:
        rec = self._records.get(measure)
        if rec is None:
            return
        if sql:
            if rec.generated_sql is None:
                rec.generated_sql = sql
            rec.sql_complexity = sql_complexity(rec.generated_sql)
        if error:
            rec.sql_error = str(error)[:500]
        rec.sql_samples.append({"context": context, "sql": sql, "error": error})
        self._append(
            "compilation_sql_patch",
            measure_name=measure,
            sql=sql,
            sql_error=rec.sql_error,
            context=context,
            sql_complexity=rec.sql_complexity,
        )

    def annotate_validation(self, measure: str, passed: bool, error: str | None = None) -> None:
        rec = self._records.get(measure)
        if rec is None:
            return
        rec.validation_attempted = True
        rec.validation_passed = passed
        rec.validation_error = error
        self._append(
            "compilation_validation_patch",
            measure_name=measure,
            validation_passed=passed,
            validation_error=error,
        )

    # ---- reading ----

    def records(self) -> list[dict]:
        return [r.to_dict() for r in self._records.values()]

    def summary(self) -> dict[str, Any]:
        return summarize_records(self.records())

    def measures_without_sql(self) -> list[str]:
        """Translated measures (not failed, not internal `__` helpers) that have no SQL yet."""
        return [
            name
            for name, rec in self._records.items()
            if not name.startswith("__")
            and rec.compilation_status == "success"
            and rec.generated_sql is None
        ]


def load_compilation_log(path: Path) -> tuple[list[dict], dict[str, Any]]:
    """Primary records with the tier/SQL/validation patches merged, plus their summary."""
    records: dict[str, dict] = {}
    order: list[str] = []
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except ValueError:
            continue
        kind = event.get("event")
        name = event.get("measure_name")
        if kind == "compilation_record":
            rec = {k: v for k, v in event.items() if k not in ("event", "ts")}
            if name not in records:
                order.append(name)
            records[name] = rec
        elif name in records:
            rec = records[name]
            if kind == "compilation_tier_patch":
                rec["compiler_type"] = event.get("compiler_type", rec.get("compiler_type"))
                if rec["compiler_type"] in ("tier2", "manual_sql"):
                    rec["compilation_status"] = "success"
                    rec["compilation_error"] = None
            elif kind == "compilation_sql_patch":
                if event.get("sql") and not rec.get("generated_sql"):
                    rec["generated_sql"] = event["sql"]
                if rec.get("generated_sql"):
                    rec["sql_complexity"] = sql_complexity(rec["generated_sql"])
                if event.get("sql_error"):
                    rec["sql_error"] = event["sql_error"]
                rec.setdefault("sql_samples", []).append(
                    {"context": event.get("context"), "sql": event.get("sql"),
                     "error": event.get("sql_error")}
                )  # fmt: skip
            elif kind == "compilation_validation_patch":
                rec["validation_attempted"] = True
                rec["validation_passed"] = event.get("validation_passed")
                rec["validation_error"] = event.get("validation_error")
            rec["overall_status"] = _overall(rec)
    for rec in records.values():
        rec["overall_status"] = _overall(rec)
    merged = [records[n] for n in order]
    return merged, summarize_records(merged)


def _overall(rec: dict) -> str:
    if rec.get("compilation_status") == "failed":
        return "broken"
    if rec.get("validation_attempted") and not rec.get("validation_passed"):
        return "degraded"
    return "working"


def build_audit_json(records: list[dict], summary: dict, conversion_id: str) -> dict[str, Any]:
    return {
        "schema_version": AUDIT_SCHEMA_VERSION,
        "kind": "dax_compilation_audit",
        "generated_at": time.time(),
        "conversion_id": conversion_id,
        "summary": summary,
        "records": records,
    }


def build_audit_xlsx(records: list[dict], summary: dict, conversion_id: str) -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill

    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws.append(["Conversion", conversion_id])
    for key in ("total", "working", "degraded", "broken", "percentage_working",
                "avg_dax_complexity", "avg_sql_complexity"):  # fmt: skip
        ws.append([key.replace("_", " ").capitalize(), summary.get(key)])
    ws.append([])
    ws.append(["Compiler type", "Measures"])
    for kind, n in sorted(summary.get("by_compiler_type", {}).items()):
        ws.append([kind, n])
    ws.column_dimensions["A"].width = 28

    queries = wb.create_sheet("Queries")
    queries.append(["Measure", "Table", "Compiler", "DAX", "SQL", "SQL error"])
    for r in records:
        queries.append(
            [
                r.get("measure_name"), r.get("model_table"), r.get("compiler_type"),
                r.get("dax_expression"), r.get("generated_sql") or "(none)", r.get("sql_error"),
            ]
        )  # fmt: skip
    for col, width in zip("ABCDEF", (30, 22, 12, 60, 80, 40), strict=True):
        queries.column_dimensions[col].width = width
    for row in queries.iter_rows(min_row=2):
        for cell in row[3:5]:
            cell.alignment = Alignment(wrap_text=True, vertical="top")

    measures = wb.create_sheet("Measures")
    headers = [
        "Measure", "Table", "Status", "Compiler", "Compilation", "Error", "DAX complexity",
        "SQL complexity", "Validated", "Validation passed", "Validation error", "Duration ms",
    ]  # fmt: skip
    measures.append(headers)
    colours = {"working": "C6EFCE", "degraded": "FFEB9C", "broken": "FFC7CE"}
    for r in records:
        measures.append(
            [
                r.get("measure_name"), r.get("model_table"), r.get("overall_status"),
                r.get("compiler_type"), r.get("compilation_status"), r.get("compilation_error"),
                r.get("dax_complexity_score"), r.get("sql_complexity"),
                r.get("validation_attempted"), r.get("validation_passed"),
                r.get("validation_error"), r.get("compilation_duration_ms"),
            ]
        )  # fmt: skip
        fill = PatternFill("solid", fgColor=colours.get(r.get("overall_status", ""), "FFFFFF"))
        measures.cell(row=measures.max_row, column=3).fill = fill
    for cell in measures[1]:
        cell.font = Font(bold=True)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
