"""Provider selection for tier-2 AI: Snowflake Cortex (default) or the Horizon gateway."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, Literal

from app.core.config import get_settings

Provider = Literal["cortex", "horizon"]


def resolve_provider(requested: str | None) -> str:
    return requested or get_settings().llm_provider


def build_llm_client(provider: str, cursor_factory: Callable[[], Any]):
    """The chat client for `provider`; None means AI is off (Horizon without credentials)."""
    if provider == "cortex":
        from app.services.cortex_client import build_cortex_client

        return build_cortex_client(cursor_factory)
    from app.services.horizon_client import build_client_from_settings

    return build_client_from_settings()


def describe_providers() -> dict[str, Any]:
    s = get_settings()
    return {
        "default": s.llm_provider,
        "cortex": {"model": s.cortex_model},
        "horizon": {"configured": bool(s.horizon_client_id and s.horizon_client_secret)},
    }
