from __future__ import annotations

import json
from pathlib import Path

from app.binding.m_parser import (
    m_string,
    parse_m_binding,
    resolve_parameter,
    snowflake_source_args,
    translate_m_expression,
)
from app.binding.resolver import build_binding_map
from app.ir.model import Column, Measure, Partition, SemanticModel, Table
from app.parsers.pbir import (
    merge_report_measures,
    parse_bookmarks,
    parse_interaction_graph,
    parse_report_definition,
)
from app.parsers.tmdl import parse_tmdl_source

# ----------------------------------------------------------------------- model lookups


def _model():
    return SemanticModel(
        tables=[
            Table(
                name="Sales",
                columns=[Column(name="Amount"), Column(name="amount2"), Column(name="AMOUNT2")],
                measures=[Measure(name="Total", expression="1"), Measure(name="total", expression="2")],
            ),
            Table(name="Dim", measures=[Measure(name="Only One", expression="3")]),
        ]
    )


def test_case_insensitive_lookups_and_ambiguity():
    m = _model()
    assert m.table("sales").name == "Sales"
    assert m.table("SALES").name == "Sales"
    sales = m.table("Sales")
    assert sales.column("amount").name == "Amount"
    assert sales.column("AMOUNT2").name == "AMOUNT2"  # exact wins
    assert sales.column("Amount2") is None  # ambiguous (amount2 / AMOUNT2)
    assert sales.measure("Total").expression == "1"  # exact first
    assert sales.measure("TOTAL") is None  # ambiguous
    assert m.find_measure("only one")[1].name == "Only One"
    assert m.find_measure("total")[1].expression == "2"
    assert m.find_measure("TOTAL") is None


def test_effective_dax_prefers_rewrite():
    from app.ir.model import DaxRewrite

    m = _model()
    meas = m.table("Sales").measure("Total")
    assert m.effective_dax(meas) == "1"
    m.dax_rewrites["Total"] = DaxRewrite(expression="9", original="1")
    assert m.effective_dax(meas) == "9"


def test_tmdl_sort_by_column_is_unquoted():
    nodes = parse_tmdl_source(
        "table T\n\tcolumn M\n\t\tdataType: string\n\t\tsortByColumn: 'Paid Year Month Nbr'\n"
    )
    from app.parsers.tmdl import _map_table

    assert _map_table(nodes[0]).column("M").sort_by_column == "Paid Year Month Nbr"


# ----------------------------------------------------------------------- M parser

SF = (
    'let\n  Source = Snowflake.Databases("srv.snowflakecomputing.com", "WH_X", [Role = R]),\n'
    '  Db = Source{[Name = %s, Kind = "Database"]}[Data],\n'
    '  Sch = Db{[Name = "PUB", Kind = "Schema"]}[Data],\n'
    '  Obj = Sch{[Name = "MEMBER""S", Kind = "Table"]}[Data]\nin\n  Obj'
)


def test_m_string_decoding_and_double_quote_escape():
    assert m_string('"MEMBER""S"') == 'MEMBER"S'
    assert m_string('#"Param Name"') == "Param Name"
    b = parse_m_binding(SF % '"DB1"')
    assert (b.database, b.schema, b.object_name) == ("DB1", "PUB", 'MEMBER"S')


def test_quoted_parameter_reference_and_triple_quoted_warning():
    exprs = {
        "Param Name": '"DB_A" meta [IsParameterQuery=true]',
        "U01": '"""U01_DB""" meta [IsParameterQuery=true]',
    }
    b = parse_m_binding(SF % '#"Param Name"', exprs)
    assert b.database == "DB_A" and not b.unresolved_params
    b2 = parse_m_binding(SF % "U01", exprs)
    assert b2.database == "U01_DB"
    assert b2.warnings == ['parameter «U01» is "U01_DB": surrounding double quotes removed, using U01_DB']
    warnings: list[str] = []
    assert resolve_parameter('#"U01"', exprs, warnings) == "U01_DB" and warnings


def test_unresolved_parameters_detail_and_resolver_warnings():
    model = SemanticModel(
        tables=[
            Table(
                name="T",
                partitions=[Partition(name="p", source_type="m", expression=SF % "Missing")],
            ),
            Table(
                name="U",
                partitions=[Partition(name="p", source_type="m", expression=SF % "U01")],
            ),
        ],
        expressions={"U01": '"""U01_DB""" meta [IsParameterQuery=true]'},
    )
    bm = build_binding_map(model)
    assert "parameter(s) not found in the model: «Missing»" in bm.bindings["T"].detail
    assert any(w.startswith("U: parameter «U01»") for w in bm.warnings)


def test_native_query_second_argument_with_commas_and_brackets():
    m = (
        'let Source = Value.NativeQuery(Snowflake.Databases("a","b"){[Name="D"]}[Data], '
        '"select a, ""b"" from t#(lf)where x = [1]", null, [EnableFolding=true]) in Source'
    )
    b = parse_m_binding(m)
    assert b.native_query == 'select a, "b" from t\nwhere x = [1]'


def test_snowflake_source_args_literals_and_parameters():
    assert snowflake_source_args(SF % '"D"') == ("srv.snowflakecomputing.com", "WH_X")
    m = 'Snowflake.Databases(Srv, #"Wh Name", [Role="R"])'
    exprs = {"Srv": '"s.example" meta [x=1]', "Wh Name": '"WH2" meta [x=1]'}
    assert snowflake_source_args(m, exprs) == ("s.example", "WH2")
    assert snowflake_source_args("Sql.Database(1,2)") == (None, None)


def test_add_column_translations():
    cases = {
        "[A]": '"A"',
        "12": "12",
        '"it\'s"': "'it''s'",
        "Number.ToText([N])": 'CAST("N" AS VARCHAR)',
        'Date.ToText([D], "yyyy-MM")': "TO_CHAR(\"D\", 'yyyy-MM')",
        "[A] + [B] * 2": '"A" + "B" * 2',
        '[First] & " " & [Last]': "\"First\" || ' ' || \"Last\"",
        'if [S] = "x" then "yes" else "no"': "CASE WHEN \"S\" = 'x' THEN 'yes' ELSE 'no' END",
        'if [S] = "x" or [S] <> "y" then 1 else 0': (
            "CASE WHEN \"S\" = 'x' OR \"S\" <> 'y' THEN 1 ELSE 0 END"
        ),
        'if [A] = "p" then "a" else if [A] = "q" then "b" else "c"': (
            "CASE WHEN \"A\" = 'p' THEN 'a' ELSE CASE WHEN \"A\" = 'q' THEN 'b' ELSE 'c' END END"
        ),
    }
    for src, sql in cases.items():
        assert translate_m_expression(src) == sql, src
    assert translate_m_expression("List.Sum([A])") is None
    assert translate_m_expression("[A] + List.Sum([B])") is None


def test_add_column_flows_into_binding_and_untranslatable_skipped():
    src = (
        'let Source = Snowflake.Databases("a","b"),\n D = Source{[Name="DB",Kind="Database"]}[Data],\n'
        ' S = D{[Name="PUB",Kind="Schema"]}[Data],\n T = S{[Name="T",Kind="Table"]}[Data],\n'
        ' A = Table.AddColumn(T, "Full", each [F] & "-" & [L]),\n'
        ' B = Table.AddColumn(A, "Bad", each List.Sum({1,2}))\nin B'
    )
    b = parse_m_binding(src)
    assert b.computed_columns == {"Full": "\"F\" || '-' || \"L\""}
    model = SemanticModel(
        tables=[Table(name="T", partitions=[Partition(name="p", source_type="m", expression=src)])]
    )
    assert build_binding_map(model).bindings["T"].computed_columns == b.computed_columns


# ----------------------------------------------------------------------- PBIR


def _write(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data), encoding="utf-8")


def _lit(v: str) -> dict:
    return {"expr": {"Literal": {"Value": v}}}


def _report(tmp_path: Path) -> Path:
    rd = tmp_path / "R.Report"
    d = rd / "definition"
    _write(
        d / "report.json",
        {"objects": {"section": [{"properties": {"verticalAlignment": _lit("'Middle'")}}]}},
    )
    _write(d / "pages" / "pages.json", {"pageOrder": ["p1", "p2"]})
    _write(
        d / "pages" / "p1" / "page.json",
        {
            "name": "p1",
            "displayName": "One",
            "displayOption": "FitToWidth",
            "visualInteractions": [
                {"source": "a", "target": "b", "type": "NoFilter"},
                {"source": "a", "target": "c", "type": "HighlightFilter"},
                {"source": "b", "target": "c", "type": "DataFilter"},
                {"source": "b", "target": "a", "type": "Weird"},
            ],
        },
    )
    _write(d / "pages" / "p2" / "page.json", {"name": "p2", "displayName": "Two"})

    col = lambda t, c: {"Column": {"Expression": {"SourceRef": {"Entity": t}}, "Property": c}}  # noqa: E731
    meas = lambda t, c: {"Measure": {"Expression": {"SourceRef": {"Entity": t}}, "Property": c}}  # noqa: E731
    pct_inner = meas("Sales", "Total")
    visuals = {
        "grp": {
            "name": "grp",
            "position": {"x": 100, "y": 50, "width": 300, "height": 300, "z": 5},
            "visualGroup": {"displayName": "G", "objects": {"background": []}},
            "isHidden": True,
        },
        "child": {
            "name": "child",
            "parentGroupName": "grp",
            "position": {"x": 10, "y": 20, "width": 50, "height": 50, "z": 3},
            "visual": {
                "visualType": "card",
                "query": {
                    "queryState": {
                        "Values": {
                            "projections": [
                                {"field": col("Sales", "Amount"), "nativeQueryRef": "Groups1"},
                                {
                                    "field": {
                                        "Aggregation": {"Expression": col("Sales", "Amount"), "Function": 0}
                                    },
                                    "nativeQueryRef": "Sum of Amount",
                                },
                                {
                                    "field": {
                                        "Arithmetic": {
                                            "Left": pct_inner,
                                            "Right": {"ScopedEval": {"Expression": pct_inner, "Scope": []}},
                                            "Operator": 3,
                                        }
                                    },
                                    "queryRef": "x",
                                },
                                {"field": col("Date", "Day"), "active": False, "displayName": "Day!"},
                            ]
                        }
                    }
                },
                "visualContainerObjects": {
                    "visualLink": [
                        {"properties": {"show": _lit("false"), "type": _lit("'WebUrl'"), "webUrl": _lit("'http://x'")}},
                        {"properties": {"type": _lit("'PageNavigation'")}},
                        {
                            "properties": {
                                "type": _lit("'Drillthrough'"),
                                "drillthroughSection": _lit("'p2'"),
                                "tooltip": _lit("'Go'"),
                            }
                        },
                    ]
                },
            },
        },
        "orphan": {
            "name": "orphan",
            "parentGroupName": "nope",
            "position": {"x": 1, "y": 2, "width": 3, "height": 4, "z": 1},
            "visual": {"visualType": "textbox"},
        },
    }
    for name, v in visuals.items():
        _write(d / "pages" / "p1" / "visuals" / name / "visual.json", v)
    _write(
        d / "reportExtensions.json",
        {
            "entities": [
                {"name": "Sales", "measures": [{"name": "Ext", "expression": "1+1", "formatString": "0"}]},
                {"name": "Nope", "measures": [{"name": "Lost", "expression": "2"}]},
            ]
        },
    )
    b = d / "bookmarks"
    _write(b / "bookmarks.json", {"items": [{"name": "b2"}, {"name": "grpb", "children": [{"name": "b1"}]}]})
    _write(
        b / "b1.bookmark.json",
        {
            "name": "b1",
            "displayName": "First",
            "explorationState": {
                "activeSection": "p2",
                "sections": {
                    "p2": {
                        "visualContainers": {"v1": {"singleVisual": {"display": {"mode": "hidden"}}}},
                        "visualContainerGroups": {"g1": {"isHidden": True}},
                    }
                },
            },
            "options": {"applyOnlyToTargetVisuals": True, "targetVisualNames": ["v1"]},
        },
    )
    _write(
        b / "b2.bookmark.json",
        {
            "name": "b2",
            "displayName": "Second",
            "explorationState": {"activeSection": "p2", "sections": {"p2": {"visualContainers": {"v9": {"singleVisual": {"display": {"mode": "hidden"}}}}}}},
            "options": {"suppressActiveSection": True, "suppressDisplay": True, "targetVisualNames": ["v1"]},
        },
    )
    _write(b / "zz.bookmark.json", {"name": "zz", "displayName": "Z", "explorationState": {"activeSection": "unknown"}})
    return rd


def test_pbir_projection_names_active_show_as_groups_and_actions(tmp_path):
    report, warnings = parse_report_definition(_report(tmp_path))
    page = report.page("p1")
    assert page.display_option == "FitToWidth" and report.vertical_alignment == "Middle"
    v = {x.name: x for x in page.visuals}

    fields = v["child"].fields
    assert fields[0].display_name == "Amount"  # nativeQueryRef "Groups1" is internal
    assert fields[1].display_name == "Sum of Amount" and fields[1].aggregate == "Sum"
    assert fields[2].show_as == "percent_of_grand_total" and fields[2].name == "Total"
    assert fields[2].is_measure
    assert fields[3].active is False and fields[3].display_name == "Day!"
    assert fields[0].active is True

    assert v["grp"].visual_type == "visualGroup" and v["grp"].title == "G"
    assert (v["child"].position.x, v["child"].position.y) == (110, 70)
    assert v["child"].position.z == 5 + 3 / 100000
    assert v["child"].is_hidden is True and v["child"].self_hidden is False
    assert v["child"].parent_group == "grp"
    assert v["orphan"].parent_group is None

    # first enabled action with a target: Drillthrough; WebUrl hidden, PageNavigation missing target
    assert v["child"].action == {"type": "Drillthrough", "page": "p2", "tooltip": "Go"}
    assert warnings == []


def test_pbir_report_measures_merge(tmp_path):
    report, _ = parse_report_definition(_report(tmp_path))
    model = SemanticModel(tables=[Table(name="Sales", measures=[Measure(name="Total", expression="1")])])
    warnings = merge_report_measures(model, report)
    ext = model.table("Sales").measure("Ext")
    assert ext is not None and ext.is_report_level and ext.format_string == "0"
    assert warnings == ["report measure [Lost] targets unknown table 'Nope'; skipped"]
    assert merge_report_measures(model, report)[0].startswith("report measure [Lost]")
    assert len(model.table("Sales").measures) == 2  # not duplicated


def test_pbir_bookmarks(tmp_path):
    rd = _report(tmp_path)
    report, _ = parse_report_definition(rd)
    assert [b.name for b in report.bookmarks] == ["b2", "b1", "zz"]
    b2, b1, zz = report.bookmarks
    assert b1.display_name == "First" and b1.state["page_name"] == "p2"
    assert b1.state["visibility"] == {"v1": "hidden", "g1": "hidden"}
    assert b1.state["targets"] == ["v1"]
    # suppressActiveSection / suppressDisplay; targets only when applyOnlyToTargetVisuals
    assert b2.state == {
        "page_name": None,
        "visibility": {},
        "targets": [],
        "filters": {"report": {}, "pages": {}, "slicers": {}},  # phase 10: Data is on
    }
    assert zz.state["page_name"] is None  # unknown page
    assert parse_bookmarks(tmp_path / "none", report.pages) == []


def test_pbir_interaction_edges(tmp_path):
    rd = _report(tmp_path)
    graph = parse_interaction_graph([rd / "definition" / "pages" / "p1", rd / "definition" / "pages" / "p2"])
    modes = {(e.from_visual, e.to_visual): e.mode.value for e in graph.edges}
    assert modes == {("a", "b"): "none", ("a", "c"): "highlight", ("b", "c"): "filter"}
    assert graph.nodes == ["a", "b", "c"]
