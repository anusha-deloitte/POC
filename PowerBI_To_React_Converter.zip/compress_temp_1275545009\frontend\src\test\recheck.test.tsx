import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { RecheckButton, friendlyAuthMessage } from '../steps/RecheckButton'
import { useWizard } from '../store/wizard'

function wrap(ui: React.ReactElement) {
  const qc = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  })
  return render(<QueryClientProvider client={qc}>{ui}</QueryClientProvider>)
}

const result = {
  visual: {
    visual: 'v1',
    page: 'p1',
    status: 'passed',
    score: 1,
    checks: [
      { name: 'compile', status: 'passed', detail: '' },
      { name: 'execute', status: 'passed', detail: '5 rows' },
    ],
    rechecked_at: 1,
    sql_override: false,
  },
  previous_status: 'failed',
  summary: {
    overall_score: 1,
    previous_overall_score: 0.5,
    visuals_passed: 1,
    visuals_total: 1,
  },
  used_edited_sql: false,
}

describe('RecheckButton', () => {
  beforeEach(() => {
    useWizard.getState().reset()
    useWizard.setState({ conversionId: 'c1', connectionId: 'conn-1' })
  })
  afterEach(() => vi.restoreAllMocks())

  it('posts the pane and shows the score change', async () => {
    const fetchMock = vi.fn(async () => new Response(JSON.stringify(result)))
    vi.stubGlobal('fetch', fetchMock)
    wrap(<RecheckButton page="p1" visual="v1" />)
    await userEvent.click(screen.getByRole('button', { name: 'Re-check this pane' }))
    const out = await screen.findByTestId('recheck-result')
    expect(out.textContent).toContain('Passed')
    expect(out.textContent).toContain('was failed')
    expect(out.textContent).toContain('score 50% → 100%')
    expect(out.textContent).toContain('compile')
    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit]
    expect(url).toContain('/conversions/c1/dashboard/recheck')
    expect(JSON.parse(init.body as string)).toEqual({
      page: 'p1',
      visual: 'v1',
      connection_id: 'conn-1',
    })
  })

  it('mentions edited SQL', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(JSON.stringify({ ...result, used_edited_sql: true }))),
    )
    wrap(<RecheckButton page="p1" visual="v1" />)
    await userEvent.click(screen.getByRole('button', { name: 'Re-check this pane' }))
    expect((await screen.findByTestId('recheck-result')).textContent).toContain('edited SQL')
  })

  it('is disabled without a connection', () => {
    useWizard.setState({ connectionId: null })
    wrap(<RecheckButton page="p1" visual="v1" />)
    const button = screen.getByRole('button', { name: 'Re-check this pane' }) as HTMLButtonElement
    expect(button.disabled).toBe(true)
    expect(button.title).toBe('Connect to Snowflake first')
    expect(screen.getByText('Connect to Snowflake first')).toBeTruthy()
  })

  it('has a compact variant', () => {
    wrap(<RecheckButton page="p1" visual="v1" compact />)
    expect(screen.getByRole('button', { name: 'Re-check' })).toBeTruthy()
  })

  it('shows the sign-in message on an authentication error', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(
        async () =>
          new Response(
            JSON.stringify({
              detail: {
                code: 'snowflake_authentication_required',
                message: 'Sign in to Snowflake to continue.',
              },
            }),
            { status: 409, headers: { 'content-type': 'application/json' } },
          ),
      ),
    )
    wrap(<RecheckButton page="p1" visual="v1" />)
    await userEvent.click(screen.getByRole('button', { name: 'Re-check this pane' }))
    const alert = await screen.findByRole('alert')
    expect(alert.textContent).toBe('Sign in to Snowflake to continue.')
  })

  it('shows other errors verbatim', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(
        async () =>
          new Response(JSON.stringify({ detail: 'no conversion run yet; POST /convert first' }), {
            status: 404,
            headers: { 'content-type': 'application/json' },
          }),
      ),
    )
    wrap(<RecheckButton page="p1" visual="v1" />)
    await userEvent.click(screen.getByRole('button', { name: 'Re-check this pane' }))
    await waitFor(() =>
      expect(screen.getByRole('alert').textContent).toBe('no conversion run yet; POST /convert first'),
    )
  })

  it('recognises authentication messages', () => {
    expect(friendlyAuthMessage('plain failure')).toBeNull()
    expect(friendlyAuthMessage('Snowflake authentication failed')).toBe(
      'Sign in to Snowflake again, then re-check.',
    )
  })
})
