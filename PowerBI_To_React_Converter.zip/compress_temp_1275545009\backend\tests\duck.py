"""DuckDB test world: build a tiny model + data, run engine SQL through the extract path.

Generated Snowflake SQL -> `runtime/accelerate.to_duckdb_sql` -> DuckDB. Every DAX behaviour in
phase 06 is proven on hand-computed numbers.
"""

from __future__ import annotations

from typing import Any

import duckdb

from app.binding.resolver import BindingMap, build_binding_map
from app.ir.model import (
    Column,
    DataType,
    Measure,
    Partition,
    Relationship,
    SemanticModel,
    SummarizeBy,
    Table,
)
from app.runtime.accelerate import to_duckdb_sql
from app.runtime.engine import QuerySpec, SemanticEngine


def snowflake_m(database: str, schema: str, obj: str) -> str:
    """The Power Query a Snowflake-bound table carries (resolves to database.schema.object)."""
    return "\n".join(
        [
            'let Source = Snowflake.Databases("srv.snowflakecomputing.com", "WH"),',
            f' D = Source{{[Name="{database}",Kind="Database"]}}[Data],',
            f' S = D{{[Name="{schema}",Kind="Schema"]}}[Data],',
            f' T = S{{[Name="{obj}",Kind="Table"]}}[Data]',
            "in T",
        ]
    )


def _dtype(values: list[Any]) -> DataType:
    for v in values:
        if v is None:
            continue
        if isinstance(v, bool):
            return DataType.BOOLEAN
        if isinstance(v, int):
            return DataType.INT64
        if isinstance(v, float):
            return DataType.DOUBLE
        if hasattr(v, "year") and hasattr(v, "hour"):
            return DataType.DATETIME
        if hasattr(v, "year"):
            return DataType.DATE
        return DataType.STRING
    return DataType.STRING


class DuckWorld:
    """tables: name -> (columns, rows). rels: (many_table, many_col, one_table, one_col[, kwargs])."""

    def __init__(
        self,
        tables: dict[str, tuple[list[str], list[tuple]]],
        rels: list[tuple] | None = None,
        measures: dict[str, str] | None = None,
        measure_table: str | None = None,
        calc_columns: dict[str, dict[str, str]] | None = None,
        sort_by: dict[tuple[str, str], str] | None = None,
        types: dict[tuple[str, str], str] | None = None,
    ):
        self.con = duckdb.connect(":memory:")
        self._adhoc = 0
        model_tables: list[Table] = []
        for name, (cols, rows) in tables.items():
            col_defs = []
            forced = {
                "double": DataType.DOUBLE,
                "int": DataType.INT64,
                "string": DataType.STRING,
                "date": DataType.DATE,
            }
            for i, c in enumerate(cols):
                override = (types or {}).get((name, c))
                col_defs.append(
                    Column(
                        name=c,
                        data_type=forced[override] if override else _dtype([r[i] for r in rows]),
                        summarize_by=SummarizeBy.NONE,
                        sort_by_column=(sort_by or {}).get((name, c)),
                    )
                )
            for cc, expr in ((calc_columns or {}).get(name, {})).items():
                col_defs.append(Column(name=cc, expression=expr, data_type=DataType.UNKNOWN))
            model_tables.append(
                Table(
                    name=name,
                    columns=col_defs,
                    partitions=[
                        Partition(name="p", source_type="m", expression=snowflake_m("DB", "PUBLIC", name.upper()))
                    ],
                )
            )
            local = f"x_{name.lower()}"
            sql_types = {
                DataType.INT64: "BIGINT",
                DataType.DOUBLE: "DOUBLE",
                DataType.BOOLEAN: "BOOLEAN",
                DataType.DATE: "DATE",
                DataType.DATETIME: "TIMESTAMP",
            }
            quoted = ", ".join(
                f'"{c}" {sql_types.get(col_defs[i].data_type, "VARCHAR")}'
                for i, c in enumerate(cols)
            )
            self.con.execute(f'CREATE TABLE "{local}" ({quoted})')
            if rows:
                marks = ", ".join("?" for _ in cols)
                self.con.executemany(f'INSERT INTO "{local}" VALUES ({marks})', rows)
        owner = measure_table or next(iter(tables))
        for mname, expr in (measures or {}).items():
            next(t for t in model_tables if t.name == owner).measures.append(
                Measure(name=mname, expression=expr)
            )
        relationships = []
        for i, rel in enumerate(rels or []):
            ft, fc, tt, tc = rel[:4]
            extra = rel[4] if len(rel) > 4 else {}
            relationships.append(
                Relationship(
                    name=f"r{i}",
                    from_table=ft,
                    from_column=fc,
                    to_table=tt,
                    to_column=tc,
                    **extra,
                )
            )
        self.model = SemanticModel(tables=model_tables, relationships=relationships)
        self.bindings: BindingMap = build_binding_map(self.model)

    def engine(self, tier2_sql: dict[str, str] | None = None) -> SemanticEngine:
        return SemanticEngine(self.model, self.bindings, tier2_sql=tier2_sql)

    def sql(self, spec: QuerySpec) -> tuple[str, list[str]]:
        return self.engine().build_sql(spec)

    def run(self, spec: QuerySpec) -> list[tuple]:
        sql, _ = self.engine().build_sql(spec)
        return self.con.execute(to_duckdb_sql(sql, self.bindings)).fetchall()

    def run_full(self, spec: QuerySpec) -> tuple[list[tuple], list[str], str]:
        sql, warnings = self.engine().build_sql(spec)
        rows = self.con.execute(to_duckdb_sql(sql, self.bindings)).fetchall()
        return rows, warnings, sql

    def value(self, measure_or_expr: str, **spec_kwargs) -> Any:
        """Card value of a measure name (or an expression compiled as an ad-hoc measure)."""
        from app.runtime.engine import MeasureRefSpec

        name = measure_or_expr
        if name not in {m.name for t in self.model.tables for m in t.measures}:
            self._adhoc += 1
            name = f"__adhoc{self._adhoc}"
            self.model.tables[0].measures.append(Measure(name=name, expression=measure_or_expr))
        rows = self.run(QuerySpec(measures=[MeasureRefSpec(name=name)], **spec_kwargs))
        return rows[0][0] if rows else None
