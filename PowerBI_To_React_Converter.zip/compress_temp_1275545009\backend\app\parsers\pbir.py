"""PBIR (enhanced report format) parser -> PBI-IR Report.

Reads the `definition/` folder of a *.Report: report.json, pages/, visuals/.
Unknown properties are tolerated (PBIR is a preview format); anything we
cannot interpret lands in `warnings` rather than failing the conversion.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

from app.ir.model import Measure, SemanticModel
from app.ir.report import (
    Bookmark,
    DrillthroughField,
    Filter,
    FilterPane,
    FilterScope,
    InteractionEdge,
    InteractionGraph,
    InteractionMode,
    Page,
    Report,
    SyncGroup,
    Visual,
    VisualField,
    VisualPosition,
    VisualTooltip,
)


class PbirParseError(Exception):
    pass


@dataclass
class RemoteModelRef:
    """A report live-connected (byConnection) to a semantic model in the service."""

    connection_string: str = ""
    workspace: str | None = None
    model_name: str | None = None
    model_id: str | None = None

    def describe(self) -> str:
        label = self.model_name or self.model_id or "unknown"
        text = f"remote semantic model '{label}'"
        if self.workspace:
            text += f" in workspace '{self.workspace}'"
        return text


def _load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise PbirParseError(f"{path}: invalid JSON: {e}") from e


def _field_ref(field: dict) -> tuple[str | None, str | None, bool, dict]:
    """Extract (table, name, is_measure, extras) from a PBIR field expression."""
    if "Measure" in field:
        m = field["Measure"]
        return (
            m.get("Expression", {}).get("SourceRef", {}).get("Entity"),
            m.get("Property"),
            True,
            {},
        )
    if "Column" in field:
        c = field["Column"]
        return (
            c.get("Expression", {}).get("SourceRef", {}).get("Entity"),
            c.get("Property"),
            False,
            {},
        )
    if "Aggregation" in field:
        agg = field["Aggregation"]
        inner_table, inner_name, _, _ = _field_ref(agg.get("Expression", {}))
        func = _AGG_FUNCTIONS.get(agg.get("Function", -1))
        return inner_table, inner_name, False, {"aggregate": func}
    if "HierarchyLevel" in field:
        hl = field["HierarchyLevel"]
        hierarchy = hl.get("Expression", {}).get("Hierarchy", {})
        table = hierarchy.get("Expression", {}).get("SourceRef", {}).get("Entity")
        return table, hl.get("Level"), False, {
            "is_hierarchy_level": True,
            "hierarchy": hierarchy.get("Hierarchy"),
        }
    if "Arithmetic" in field:
        # "Show value as -> Percent of grand total": Left / ScopedEval(Left) with no scope
        arith = field["Arithmetic"]
        left = arith.get("Left", {})
        scoped = (arith.get("Right") or {}).get("ScopedEval")
        if (
            arith.get("Operator") == 3
            and isinstance(scoped, dict)
            and scoped.get("Expression") == left
            and not scoped.get("Scope")
        ):
            table, name, is_measure, extras = _field_ref(left)
            return table, name, is_measure, {**extras, "show_as": "percent_of_grand_total"}
    return None, None, False, {}


# PBI Aggregation.Function enum
_AGG_FUNCTIONS = {
    0: "Sum",
    1: "Avg",
    2: "DistinctCount",  # PBI's Aggregation.Function 2 counts distinct values
    3: "Min",
    4: "Max",
    5: "Count",
    6: "Median",
    7: "StandardDeviation",
    8: "Variance",
}


def _parse_filter(obj: dict, scope: FilterScope) -> Filter:
    table, name, is_measure, _ = _field_ref(obj.get("field", {}))
    ordinal = obj.get("ordinal")
    return Filter(
        is_locked=bool(obj.get("isLockedInViewMode", False)),
        ordinal=ordinal if isinstance(ordinal, int) and not isinstance(ordinal, bool) else None,
        how_created=obj.get("howCreated"),
        display_name=obj.get("displayName"),
        require_single=(
            _object_literal(obj.get("objects", {}) or {}, "general", "requireSingleSelection")
            is True
        ),
        name=obj.get("name"),
        scope=scope,
        field_table=table,
        field_name=name,
        field_is_measure=is_measure,
        filter_type=obj.get("type", "Categorical"),
        definition=obj.get("filter", {}),
        is_hidden=obj.get("isHiddenInViewMode", False),
    )


def _parse_filter_config(config: dict | None, scope: FilterScope) -> list[Filter]:
    if not config:
        return []
    return [_parse_filter(f, scope) for f in config.get("filters", [])]


def _literal_text(objects: dict, section: str, prop: str) -> str | None:
    """Pull a `Literal` string out of `objects.<section>[0].properties.<prop>`."""
    try:
        raw = objects[section][0]["properties"][prop]["expr"]["Literal"]["Value"]
    except (KeyError, IndexError, TypeError):
        return None
    return raw.strip("'") if isinstance(raw, str) else None


_NUMBER_LITERAL = re.compile(r"^-?\d+(\.\d+)?[DLMdlm]?$")


def _literal_value(prop: Any) -> Any:
    """`{"expr":{"Literal":{"Value": raw}}}` -> python value (None when missing)."""
    try:
        raw = prop["expr"]["Literal"]["Value"]
    except (KeyError, TypeError):
        return None
    if not isinstance(raw, str):
        return raw
    if len(raw) >= 2 and raw[0] == "'" and raw[-1] == "'":
        return raw[1:-1].replace("''", "'")
    if raw == "true":
        return True
    if raw == "false":
        return False
    if _NUMBER_LITERAL.match(raw):
        return float(raw.rstrip("DLMdlm"))
    return raw


def _object_literal(objects: dict, section: str, prop: str) -> Any:
    try:
        return _literal_value(objects[section][0]["properties"][prop])
    except (KeyError, IndexError, TypeError):
        return None


_ACTION_TARGET = {
    "Bookmark": ("bookmark", "bookmark"),
    "PageNavigation": ("navigationSection", "page"),
    "WebUrl": ("webUrl", "url"),
    "Drillthrough": ("drillthroughSection", "page"),
    "Back": (None, None),
}


def _parse_action(container_objects: dict) -> dict | None:
    """First enabled visualLink entry with a usable target: {type, bookmark, page, url, tooltip}."""
    for entry in container_objects.get("visualLink", []) or []:
        props = entry.get("properties", {}) if isinstance(entry, dict) else {}
        if _literal_value(props.get("show")) is False:
            continue
        kind = _literal_value(props.get("type"))
        if kind not in _ACTION_TARGET:
            continue
        source_key, out_key = _ACTION_TARGET[kind]
        action: dict[str, Any] = {"type": kind}
        if source_key:
            target = _literal_value(props.get(source_key))
            if not target:
                continue
            action[out_key] = target
        tooltip = _literal_value(props.get("tooltip"))
        if tooltip:
            action["tooltip"] = tooltip
        return {k: v for k, v in action.items() if v is not None}
    return None


def _literal_or_colour(prop: Any) -> Any:
    """A literal, or the literal inside `{solid: {color: <literal>}}`."""
    if isinstance(prop, dict) and isinstance(prop.get("solid"), dict):
        return _literal_value(prop["solid"].get("color"))
    return _literal_value(prop)


def parse_filter_pane(objects: dict | None) -> FilterPane | None:
    """`objects.outspacePane` (expanded / visible / width + colours) and `objects.filterCard`
    (colours per card state: Available | Applied); None when neither exists."""
    objects = objects or {}
    pane_entries = objects.get("outspacePane") or []
    card_entries = objects.get("filterCard") or []
    if not pane_entries and not card_entries:
        return None
    pane = FilterPane()
    props = (pane_entries[0].get("properties") if pane_entries else None) or {}
    for key, prop in props.items():
        value = _literal_or_colour(prop)
        if key in ("expanded", "visible") and isinstance(value, bool):
            setattr(pane, key, value)
        elif key == "width" and isinstance(value, (int, float)) and not isinstance(value, bool):
            pane.width = float(value)
        elif value is not None:
            pane.colours[key] = value
    cards: dict[str, dict] = {}
    for entry in card_entries:
        state = (entry.get("selector") or {}).get("id") or "Available"
        cards[state] = {
            k: _literal_or_colour(v) for k, v in (entry.get("properties") or {}).items()
        }
    if cards:
        pane.colours["filterCard"] = cards
    return pane


def _parse_tooltip(visual_conf: dict) -> VisualTooltip | None:
    """`visualTooltip` from the container objects, else the visual's objects."""
    for source in (visual_conf.get("visualContainerObjects"), visual_conf.get("objects")):
        for prop in ("show", "type", "section"):
            if _object_literal(source or {}, "visualTooltip", prop) is not None:
                show = _object_literal(source or {}, "visualTooltip", "show")
                kind = _object_literal(source or {}, "visualTooltip", "type")
                section = _object_literal(source or {}, "visualTooltip", "section")
                return VisualTooltip(
                    show=show if isinstance(show, bool) else None,
                    type=str(kind) if kind is not None else None,
                    section=str(section) if section is not None else None,
                )
    return None


def parse_drillthrough(page_json: dict) -> list[DrillthroughField]:
    """`pageBinding.parameters` of a drill-through page; hierarchy levels resolve to their level
    column by name."""
    binding = page_json.get("pageBinding") or {}
    if binding.get("type") != "Drillthrough":
        return []
    fields: list[DrillthroughField] = []
    for param in binding.get("parameters") or []:
        table, name, is_measure, extras = _field_ref(param.get("fieldExpr") or {})
        if not name:
            continue
        fields.append(
            DrillthroughField(
                table=table,
                name=name,
                is_measure=is_measure,
                hierarchy=extras.get("hierarchy"),
                bound_filter=param.get("boundFilter"),
            )
        )
    return fields


def _filter_sort_order(config: dict | None) -> str | None:
    value = (config or {}).get("filterSortOrder")
    return value if isinstance(value, str) else None


def _named_filters(container: dict) -> dict[str, dict]:
    """`{byName: {...}, byExpr: [...]}` -> `{name: {type, filter}}` (byExpr cards are keyed by
    their field: `Table.Column`)."""
    out: dict[str, dict] = {}
    for name, item in ((container or {}).get("byName") or {}).items():
        out[name] = {"type": (item or {}).get("type"), "filter": (item or {}).get("filter")}
    for i, item in enumerate((container or {}).get("byExpr") or []):
        table, column, _, _ = _field_ref((item or {}).get("expression", {}))
        key = f"{table}.{column}" if table and column else f"expr{i}"
        out[key] = {"type": item.get("type"), "filter": item.get("filter")}
    return out


def _bookmark_filters(state: dict) -> dict:
    """Filter state a bookmark captured: report filters, page filters per section and slicer
    selections per visual (None = the slicer was cleared)."""
    pages: dict[str, dict] = {}
    slicers: dict[str, Any] = {}
    for section_name, section in (state.get("sections", {}) or {}).items():
        named = _named_filters(section.get("filters") or {})
        if named:
            pages[section_name] = named
        for vname, vc in (section.get("visualContainers", {}) or {}).items():
            single = vc.get("singleVisual") or {}
            if single.get("visualType") != "slicer":
                continue
            try:
                general = single["objects"]["merge"]["general"][0]
                slicers[vname] = general["properties"]["filter"]["filter"]
            except (KeyError, IndexError, TypeError):
                slicers[vname] = None
    return {
        "report": _named_filters(state.get("filters") or {}),
        "pages": pages,
        "slicers": slicers,
    }


def _projection_display_name(proj: dict, name: str | None, extras: dict) -> str | None:
    explicit = proj.get("displayName")
    if explicit:
        return explicit
    if extras.get("aggregate") or not name:
        return proj.get("nativeQueryRef") or name
    return name


def _parse_visual(vdir: Path, warnings: list[str]) -> Visual | None:
    vjson = vdir / "visual.json"
    if not vjson.is_file():
        warnings.append(f"visual folder without visual.json: {vdir.name}")
        return None
    data = _load_json(vjson)
    visual_conf: dict[str, Any] = data.get("visual", {})
    group_conf: dict[str, Any] = data.get("visualGroup", {}) if not visual_conf else {}
    pos = data.get("position", {})

    fields: list[VisualField] = []
    query_state = visual_conf.get("query", {}).get("queryState", {})
    for role, role_conf in query_state.items():
        for proj in role_conf.get("projections", []):
            table, name, is_measure, extras = _field_ref(proj.get("field", {}))
            fields.append(
                VisualField(
                    role=role,
                    table=table,
                    name=name,
                    is_measure=is_measure,
                    display_name=_projection_display_name(proj, name, extras),
                    query_ref=proj.get("queryRef"),
                    aggregate=extras.get("aggregate"),
                    is_hierarchy_level=extras.get("is_hierarchy_level", False),
                    hierarchy=extras.get("hierarchy"),
                    active=proj.get("active", True) is not False,
                    show_as=extras.get("show_as"),
                )
            )

    sort_defs: list[dict] = []
    for s in visual_conf.get("query", {}).get("sortDefinition", {}).get("sort", []):
        table, name, is_measure, _ = _field_ref(s.get("field", {}))
        sort_defs.append(
            {
                "table": table,
                "field": name,
                "is_measure": is_measure,
                "direction": s.get("direction", "Ascending"),
            }
        )

    container_objects = visual_conf.get("visualContainerObjects", {})
    if group_conf:
        container_objects = group_conf.get("objects", {})
    is_group = bool(group_conf)

    sync = visual_conf.get("syncGroup") or data.get("syncGroup") or {}
    sync_group = (
        SyncGroup(
            name=sync["groupName"],
            field_changes=sync.get("fieldChanges"),
            filter_changes=sync.get("filterChanges"),
        )
        if isinstance(sync, dict) and sync.get("groupName")
        else None
    )
    return Visual(
        sync_group=sync_group,
        tooltip=_parse_tooltip(visual_conf),
        name=data.get("name", vdir.name),
        visual_type="visualGroup" if is_group else visual_conf.get("visualType", "unknown"),
        position=VisualPosition(
            x=pos.get("x", 0),
            y=pos.get("y", 0),
            width=pos.get("width", 0),
            height=pos.get("height", 0),
            z=pos.get("z", 0),
            tab_order=pos.get("tabOrder"),
        ),
        title=(
            group_conf.get("displayName")
            if is_group
            else _literal_text(container_objects, "title", "text")
        ),
        fields=fields,
        filters=_parse_filter_config(visual_conf.get("filterConfig"), FilterScope.VISUAL)
        + _parse_filter_config(data.get("filterConfig"), FilterScope.VISUAL),
        sort=sort_defs,
        formatting=visual_conf.get("objects", {}),
        container_objects=container_objects,
        is_hidden=data.get("isHidden", False),
        self_hidden=data.get("isHidden", False),
        parent_group=data.get("parentGroupName"),
        action=None if is_group else _parse_action(container_objects),
    )


def _apply_group_geometry(visuals: list[Visual]) -> None:
    """Canvas-absolute positions, fractional z and inherited hidden state for grouped visuals."""
    by_name = {v.name: v for v in visuals}
    for v in visuals:
        if v.parent_group and v.parent_group not in by_name:
            v.parent_group = None
    local = {
        v.name: (v.position.x, v.position.y, v.position.z, bool(v.self_hidden)) for v in visuals
    }
    memo: dict[str, tuple[float, float, float, bool]] = {}

    def resolve(name: str, seen: frozenset[str]) -> tuple[float, float, float, bool]:
        if name in memo:
            return memo[name]
        x, y, z, hidden = local[name]
        parent = by_name[name].parent_group
        if parent and parent not in seen and name not in seen:
            px, py, pz, phidden = resolve(parent, seen | {name})
            result = (x + px, y + py, pz + z / 100000, hidden or phidden)
        else:
            result = (x, y, z, hidden)
        memo[name] = result
        return result

    for v in visuals:
        if v.parent_group is None:
            continue
        x, y, z, hidden = resolve(v.name, frozenset())
        v.position.x, v.position.y, v.position.z = x, y, z
        v.is_hidden = hidden


def _parse_page(pdir: Path, ordinal: int, warnings: list[str]) -> Page:
    pj = _load_json(pdir / "page.json")
    visuals: list[Visual] = []
    visuals_dir = pdir / "visuals"
    if visuals_dir.is_dir():
        for vdir in sorted(visuals_dir.iterdir()):
            if vdir.is_dir():
                v = _parse_visual(vdir, warnings)
                if v is not None:
                    visuals.append(v)
    _apply_group_geometry(visuals)
    return Page(
        name=pj.get("name", pdir.name),
        display_name=pj.get("displayName", pdir.name),
        ordinal=ordinal,
        width=pj.get("width", 1280),
        height=pj.get("height", 720),
        visuals=visuals,
        filters=_parse_filter_config(pj.get("filterConfig"), FilterScope.PAGE),
        is_hidden=pj.get("visibility", "AlwaysVisible") == "HiddenInViewMode",
        background=pj.get("objects", {}).get("background", [{}])[0] if pj.get("objects") else {},
        display_option=pj.get("displayOption"),
        filter_pane=parse_filter_pane(pj.get("objects")),
        filter_sort_order=_filter_sort_order(pj.get("filterConfig")),
        page_type=pj.get("type") if isinstance(pj.get("type"), str) else None,
        drillthrough=parse_drillthrough(pj),
    )


_INTERACTION_MODES = {
    "DataFilter": InteractionMode.FILTER,
    "HighlightFilter": InteractionMode.HIGHLIGHT,
    "NoFilter": InteractionMode.NONE,
}


def parse_interaction_graph(page_dirs: list[Path]) -> InteractionGraph:
    """Edges from every page's `visualInteractions`; pairs without an entry keep the default."""
    edges: list[InteractionEdge] = []
    nodes: set[str] = set()
    for pdir in page_dirs:
        page_file = pdir / "page.json"
        if not page_file.is_file():
            continue
        for item in _load_json(page_file).get("visualInteractions", []) or []:
            mode = _INTERACTION_MODES.get(item.get("type"))
            source, target = item.get("source"), item.get("target")
            if mode is None or not source or not target:
                continue
            edges.append(InteractionEdge(from_visual=source, to_visual=target, mode=mode))
            nodes.update((source, target))
    return InteractionGraph(nodes=sorted(nodes), edges=edges)


def parse_bookmarks(definition: Path, pages: list[Page]) -> list[Bookmark]:
    bdir = definition / "bookmarks"
    if not bdir.is_dir():
        return []
    page_names = {p.name for p in pages}

    order: list[str] = []

    def flatten(items: list) -> None:
        for item in items or []:
            if item.get("name"):
                order.append(item["name"])
            flatten(item.get("children", []))

    index = bdir / "bookmarks.json"
    if index.is_file():
        flatten(_load_json(index).get("items", []))
    files = {f.name.removesuffix(".bookmark.json"): f for f in bdir.glob("*.bookmark.json")}
    names = [n for n in dict.fromkeys(order) if n in files]
    names += [n for n in sorted(files) if n not in names]

    out: list[Bookmark] = []
    for name in names:
        data = _load_json(files[name])
        options = data.get("options", {}) or {}
        state = data.get("explorationState", {}) or {}
        active = state.get("activeSection")
        keep_page = active in page_names and not options.get("suppressActiveSection")
        page_name = active if keep_page else None
        visibility: dict[str, str] = {}
        if not options.get("suppressDisplay"):
            for section in (state.get("sections", {}) or {}).values():
                for vname, vc in (section.get("visualContainers", {}) or {}).items():
                    mode = ((vc.get("singleVisual") or {}).get("display") or {}).get("mode")
                    if mode == "hidden":
                        visibility[vname] = "hidden"
                for gname, gc in (section.get("visualContainerGroups", {}) or {}).items():
                    if gc.get("isHidden"):
                        visibility[gname] = "hidden"
        targets = (
            list(options.get("targetVisualNames", []) or [])
            if options.get("applyOnlyToTargetVisuals")
            else []
        )
        bookmark_state: dict[str, Any] = {
            "page_name": page_name,
            "visibility": visibility,
            "targets": targets,
        }
        if not options.get("suppressData"):  # "Data" off keeps the current filters
            bookmark_state["filters"] = _bookmark_filters(state)
        out.append(
            Bookmark(
                name=data.get("name", name),
                display_name=data.get("displayName"),
                state=bookmark_state,
            )
        )
    return out


def _load_custom_theme(report_dir: Path, theme_collection: dict) -> dict:
    """Resolve the customTheme name against StaticResources/RegisteredResources."""
    name = theme_collection.get("customTheme", {}).get("name")
    if not name:
        return {}
    for candidate in (
        report_dir / "StaticResources" / "RegisteredResources" / f"{name}.json",
        report_dir / "StaticResources" / "RegisteredResources" / name,
    ):
        if candidate.is_file():
            try:
                return json.loads(candidate.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                return {}
    return {}


def parse_report_definition(report_dir: Path) -> tuple[Report, list[str]]:
    """Parse `<X>.Report/` (with `definition/` inside) into IR Report + warnings."""
    warnings: list[str] = []
    definition = report_dir / "definition"
    if not definition.is_dir():
        if (report_dir / "report.json").is_file():
            raise PbirParseError(
                "report uses PBIR-Legacy (report.json); re-save with the PBIR "
                "preview feature enabled in Power BI Desktop"
            )
        raise PbirParseError(f"no definition/ folder in {report_dir}")

    rj = _load_json(definition / "report.json") if (definition / "report.json").is_file() else {}

    pages_dir = definition / "pages"
    page_order: list[str] = []
    if (pages_dir / "pages.json").is_file():
        page_order = _load_json(pages_dir / "pages.json").get("pageOrder", [])

    page_dirs = {p.name: p for p in pages_dir.iterdir() if p.is_dir()} if pages_dir.is_dir() else {}
    ordered = [page_dirs[n] for n in page_order if n in page_dirs]
    ordered += [p for n, p in sorted(page_dirs.items()) if n not in set(page_order)]

    pages = [_parse_page(pdir, i, warnings) for i, pdir in enumerate(ordered)]

    # report-level measures (reportExtensions.json), fed into the same DAX path later
    extension_measures: dict[str, list[str]] = {}
    extension_defs: dict[str, list[Measure]] = {}
    ext_file = definition / "reportExtensions.json"
    if ext_file.is_file():
        ext = _load_json(ext_file)
        for entity in ext.get("entities", []):
            entity_name = entity.get("name", "")
            measures = [m for m in entity.get("measures", []) if m.get("name")]
            extension_measures[entity_name] = [m["name"] for m in measures]
            extension_defs[entity_name] = [
                Measure(
                    name=m["name"],
                    expression=m.get("expression", ""),
                    format_string=m.get("formatString"),
                    is_report_level=True,
                )
                for m in measures
            ]

    graph = parse_interaction_graph(ordered)
    sync_groups: dict[str, list[str]] = {}
    for page in pages:
        for visual in page.visuals:
            if visual.sync_group is not None:
                members = sync_groups.setdefault(visual.sync_group.name, [])
                if visual.name not in members:
                    members.append(visual.name)
    graph.sync_groups = sync_groups

    theme_collection = rj.get("themeCollection", {})
    custom_theme = _load_custom_theme(report_dir, theme_collection)
    report = Report(
        name=report_dir.name.removesuffix(".Report"),
        pages=pages,
        filters=_parse_filter_config(rj.get("filterConfig"), FilterScope.REPORT),
        theme={"collection": theme_collection, "custom": custom_theme},
        extension_measures=extension_measures,
        extension_measure_defs=extension_defs,
        bookmarks=parse_bookmarks(definition, pages),
        interaction_graph=graph,
        vertical_alignment=_object_literal(rj.get("objects", {}), "section", "verticalAlignment"),
        filter_pane=parse_filter_pane(rj.get("objects")),
        filter_sort_order=_filter_sort_order(rj.get("filterConfig")),
        allow_change_filter_types=(rj.get("settings", {}) or {}).get("allowChangeFilterTypes", True)
        is not False,
        filters_parsed=True,
        pages_parsed=True,
    )
    return report, warnings


def merge_report_measures(model: SemanticModel, report: Report) -> list[str]:
    """Append report-level measures to their table unless the model already defines the name."""
    warnings: list[str] = []
    for table_name, measures in report.extension_measure_defs.items():
        table = model.table(table_name)
        for measure in measures:
            if table is None:
                warnings.append(
                    f"report measure [{measure.name}] targets unknown table '{table_name}'; skipped"
                )
                continue
            if model.find_measure(measure.name) is not None:
                continue
            table.measures.append(measure)
    return warnings


# ---------------------------------------------------------------- dataset reference


def _split_connection_string(text: str) -> dict[str, str]:
    parts: list[str] = []
    buf: list[str] = []
    quoted = False
    for ch in text:
        if ch == '"':
            quoted = not quoted
            buf.append(ch)
        elif ch == ";" and not quoted:
            parts.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    parts.append("".join(buf))
    out: dict[str, str] = {}
    for part in parts:
        key, sep, value = part.partition("=")
        if not sep:
            continue
        out[key.strip().lower()] = value.strip().strip('"').strip()
    return out


def parse_remote_reference(by_connection: dict) -> RemoteModelRef:
    conn = by_connection.get("connectionString") or ""
    kv = _split_connection_string(conn)
    workspace = None
    source = kv.get("data source", "")
    if source.startswith("powerbi://"):
        segments = [s for s in urlparse(source).path.split("/") if s]
        workspace = unquote(segments[-1]) if segments else None
    return RemoteModelRef(
        connection_string=conn,
        workspace=workspace,
        model_name=kv.get("initial catalog") or by_connection.get("name") or None,
        model_id=kv.get("semanticmodelid") or by_connection.get("pbiModelDatabaseName") or None,
    )


def read_dataset_reference(report_dir: Path) -> Path | RemoteModelRef:
    """byPath -> the model folder; byConnection -> a RemoteModelRef."""
    pbir = report_dir / "definition.pbir"
    if not pbir.is_file():
        raise PbirParseError(f"missing definition.pbir in {report_dir}")
    ref = _load_json(pbir).get("datasetReference", {})
    if "byConnection" in ref:
        return parse_remote_reference(ref["byConnection"] or {})
    by_path = ref.get("byPath", {}).get("path")
    if not by_path:
        raise PbirParseError("definition.pbir has no datasetReference.byPath.path")
    resolved = (report_dir / by_path).resolve()
    if not resolved.is_dir():
        raise PbirParseError(f"semantic model folder not found: {resolved}")
    return resolved


def resolve_dataset_reference(report_dir: Path) -> Path:
    """Follow definition.pbir's datasetReference; byConnection needs an uploaded model."""
    ref = read_dataset_reference(report_dir)
    if isinstance(ref, RemoteModelRef):
        raise PbirParseError(
            f"this report references a {ref.describe()} (byConnection); "
            "include an export of that model in the upload"
        )
    return ref
