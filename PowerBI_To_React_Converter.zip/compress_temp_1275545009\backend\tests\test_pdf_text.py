"""Positioned PDF text extraction and printed-number parsing."""

from __future__ import annotations

import pytest

from app.services import pdf_text as pt
from tests.pdf_helpers import make_pdf


def one_page(runs, w=960, h=540, title=None):
    return make_pdf([{"width": w, "height": h, "runs": runs}], title=title)


def test_extracts_runs_with_positions_and_sizes():
    pdf = one_page([("Total Sales", 50, 40, 14), ("$2.14M", 50, 70, 24), ("(1,234)", 300, 70, 12)])
    (page,) = pt.extract_pages(pdf, with_images=False)
    assert (page.width_pt, page.height_pt) == (960, 540) and page.png is None
    assert page.aspect == pytest.approx(960 / 540)
    texts = [r.text for r in page.runs]
    assert texts == ["Total Sales", "$2.14M", "(1,234)"]
    big = page.runs[1]
    assert big.size == pytest.approx(24, abs=0.1)
    assert 45 <= big.x0 <= 55 and big.x1 > big.x0 and 60 <= big.y0 <= 80 and big.y1 > big.y0
    # origin is top-left: the title is above the value
    assert page.runs[0].y0 < big.y0


def test_runs_far_apart_stay_separate_and_nearby_ones_merge():
    pdf = one_page([("Net", 50, 40, 12), ("Revenue", 78, 40, 12), ("Other", 400, 40, 12)])
    (page,) = pt.extract_pages(pdf, with_images=False)
    assert [r.text for r in page.runs] == ["Net Revenue", "Other"]


def test_different_sizes_do_not_merge_and_truncation_marker_is_removed():
    pdf = one_page([("Big", 50, 40, 24), ("small", 90, 40, 8), ("Long title…", 50, 100, 12)])
    (page,) = pt.extract_pages(pdf, with_images=False)
    assert [r.text for r in page.runs][:2] == ["Big", "small"]
    last = page.runs[-1]
    assert last.text == "Long title" and last.truncated is True


def test_images_and_round_trip():
    pdf = one_page([("Hello", 10, 10, 12)])
    (page,) = pt.extract_pages(pdf)
    assert page.png and page.png[:4] == b"\x89PNG"
    back = pt.PdfPageText.from_dict(page.to_dict())
    assert [r.text for r in back.runs] == ["Hello"] and back.width_pt == 960


def test_errors_and_title():
    with pytest.raises(pt.PdfTextError, match="not a readable PDF"):
        pt.extract_pages(b"nope")
    many = make_pdf([{"width": 100, "height": 100, "runs": []}] * 51)
    with pytest.raises(pt.PdfTextError, match="limit is 50"):
        pt.extract_pages(many, with_images=False)
    assert pt.pdf_title(one_page([], title="Quarterly Report")) == "Quarterly Report"
    assert pt.pdf_title(one_page([])) is None


def test_label_tokens_ignore_numbers_and_short_words():
    assert pt.label_tokens("Total Sales YTD: $2.14M vs Q1 (it's up) R&D") == [
        "total", "sales", "ytd", "it's", "r&d",
    ]  # fmt: skip
    assert pt.label_tokens("Net Revenue 2024") == ["net", "revenue"]
    assert pt.label_tokens("a to of") == []


@pytest.mark.parametrize(
    "text,expected",
    [
        ("$2.14M", True), ("120.20K", True), ("1.19%", True), ("(1,234)", True), ("-5", True),
        ("0.00T", True), ("1.2bn", True), ("18.52 %", True),
        ("Total", False), ("Q1", False), ("$", False), ("", False), ("2024 Sales", False),
    ],
)  # fmt: skip
def test_is_numeric_text(text, expected):
    assert pt.is_numeric_text(text) is expected


def vals(text):
    return [(n.value, n.decimals, n.percent) for n in pt.parse_numbers(text)]


def test_parse_numbers_formats():
    assert vals("$2.14M") == [(2_140_000.0, 2, False)]
    assert vals("120.20K") == [(120_200.0, 2, False)]
    assert vals("1.19%") == [(1.19, 2, True)]
    assert vals("18.52 %") == [(18.52, 2, True)]
    assert vals("0.00T") == [(0.0, 2, False)]
    assert vals("1.5bn") == [(1.5e9, 1, False)]
    assert vals("1,234,567") == [(1234567.0, 0, False)]
    assert vals("(1,234)") == [(-1234.0, 0, False)]
    assert vals("-$5.5M") == [(-5_500_000.0, 1, False)]
    assert vals("$-5") == [(-5.0, 0, False)]


def test_signs_must_touch_the_number_and_bracketed_percents_stay_positive():
    assert [n.value for n in pt.parse_numbers("Package - 200")] == [200.0]
    assert [n.value for n in pt.parse_numbers("Q1-2024")] == [1.0, 2024.0]
    assert vals("9.99K (19.06%)") == [(9990.0, 2, False), (19.06, 2, True)]


def test_tolerance_and_matching():
    n = pt.parse_numbers("$2.14M")[0]
    assert n.currency == "$" and n.tolerance == pytest.approx(5_000.0)
    assert n.matches(2_143_000) and not n.matches(2_146_000)
    p = pt.parse_numbers("12%")[0]
    assert p.matches(12.4) and not p.matches(12.6)
    big = pt.parse_numbers("1,234")[0]
    assert big.matches(1234.4) and not big.matches(1235)
