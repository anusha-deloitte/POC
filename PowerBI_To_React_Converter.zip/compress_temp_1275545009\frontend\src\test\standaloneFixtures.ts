import type { DashboardSpec, FilterCard, PageSpec, VisualSpec } from '../dashboard/types'

const pbir = () => ({ objects: {}, container_objects: {}, fields: [], sort: [], is_hidden: false, self_hidden: false })

export const cardVisual = (name = 'kpi'): VisualSpec =>
  ({
    name, visual_type: 'card', x: 0, y: 0, width: 200, height: 80, z: 1, supported: true,
    dim_keys: [], column_keys: [], series_keys: [], measure_keys: ['M'], measure_roles: {}, measure_formats: {},
    static_content: {}, sort: [], data_status: 'ok',
    query: { dimensions: [], measures: [{ name: 'M' }], filters: [], sort: [] }, pbir: pbir(),
  }) as VisualSpec

export const filterCard = (name: string, over: Partial<FilterCard> = {}): FilterCard => ({
  name, scope: 'page', table: 'Customer', column: 'Country', display_name: name, data_type: 'string',
  kind: 'basic', default: null, require_single: false, hidden: false, locked: false, supported: true,
  ...over,
})

export function standaloneSpec(pages: Partial<PageSpec>[] = [], over: Partial<DashboardSpec> = {}): DashboardSpec {
  const defs: Partial<PageSpec>[] = pages.length
    ? pages
    : [
        { name: 'p1', display_name: 'Overview' },
        { name: 'p2', display_name: 'Details' },
        { name: 'p3', display_name: 'Secret', is_hidden: true },
      ]
  return {
    report_name: 'Sales report',
    pages: defs.map(
      (p, i) =>
        ({ width: 1280, height: 720, ordinal: i, visuals: [cardVisual()], filters: [], ...p }) as PageSpec,
    ),
    warnings: [], measure_tiers: { M: 0 },
    theme: { data_colors: [], text_classes: {} },
    interaction_graph: { nodes: [], edges: [], sync_groups: {} },
    bookmarks: [], drill_through: [], report_filters: [],
    ...over,
  } as DashboardSpec
}

export const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })

export class FakeResizeObserver {
  observe() {}
  disconnect() {}
  unobserve() {}
}

export const cardResults = (visual = 'kpi') => ({
  results: [
    {
      visual, columns: ['M'], rows: [[42]], sql: '', warnings: [], error: null, elapsed_ms: 1, cached: false,
      execution_tier: 1, trace_codes: [], execution_path: 'compatibility', fallback_reason: null,
    },
  ],
})
