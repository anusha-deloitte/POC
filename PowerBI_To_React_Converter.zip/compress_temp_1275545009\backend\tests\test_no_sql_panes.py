"""Phase 08: panes with no generated SQL (listing, detail, edits, validation)."""

from __future__ import annotations

import pytest

from tests.phase08 import BAR, CARD, LINE, PAGE, World
from tests.test_api import client  # noqa: F401


@pytest.fixture()
def world(client, contoso_pbip, monkeypatch):  # noqa: F811
    w = World(client, contoso_pbip, monkeypatch)
    w.responder = lambda sql: (["Total Sales"], [(42.0,)])
    return w


def test_lists_untranslated_panes_only(world):
    assert world.get("no-sql-panes").json() == {"panes": []}
    world.park_measure(dax="FOOBAR(1)")
    panes = world.get("no-sql-panes").json()["panes"]
    by = {p["visual"]: p for p in panes}
    assert {CARD, BAR, LINE} <= set(by)
    card = by[CARD]
    assert card["measure"] == "Total Sales" and card["page"] == PAGE
    assert card["page_name"] and card["visual_type"] == "card"
    assert card["expected_columns"] == ["Total Sales"] and card["manual_sql"] is False
    assert "needs tier-2" in card["reason"] and card["saved_at"] is None
    assert by[BAR]["expected_columns"] == ["Product.Category", "Total Sales"]


def test_saved_sql_marks_the_pane_and_makes_its_query(world):
    world.park_measure(dax="FOOBAR(1)")
    world.client.put(
        world.url("sql-overrides"),
        json={"page": PAGE, "visual": CARD, "sql": 'SELECT 5 AS "Total Sales"'},
    )
    card = next(p for p in world.get("no-sql-panes").json()["panes"] if p["visual"] == CARD)
    assert card["manual_sql"] is True and card["saved_at"]
    result = world.query(CARD).json()["results"][0]
    assert result["sql"] == 'SELECT 5 AS "Total Sales"' and result["error"] is None


def test_editor_offers_the_category_tables(world):
    world.park_measure(dax="FOOBAR(1)")
    editor = world.get("sql-editor", page=PAGE, visual=BAR).json()
    tables = {t["table"] for t in editor["filter_tables"]}
    assert {"Product", "Customer"} <= tables
    assert editor["base_sql"] is None and editor["base_error"]


def test_draft_query_is_kept_on_the_untranslated_spec(world):
    world.park_measure(dax="FOOBAR(1)")
    spec = world.get("spec").json()
    bar = next(v for p in spec["pages"] for v in p["visuals"] if v["name"] == BAR)
    assert bar["supported"] is False and bar["query"] is None
    assert bar["draft_query"]["dimensions"][0]["column"] == "Category"
    assert bar["draft_query"]["measures"][0]["name"] == "Total Sales"


def test_pane_details_show_the_dax_and_dependencies(world):
    world.park_measure(dax="FOOBAR([Total Quantity])")
    r = world.get(f"no-sql-panes/{PAGE}/{BAR}")
    assert r.status_code == 200, r.text
    body = r.json()
    assert "EVALUATE" in body["dax_query"] and "SUMMARIZECOLUMNS" in body["dax_query"]
    assert "'Product'[Category]" in body["dax_query"] and body["dax_query_error"] is None
    (measure,) = body["measures"]
    assert measure["name"] == "Total Sales" and measure["table"] == "Sales"
    assert measure["dax"] == "FOOBAR([Total Quantity])" and "FOOBAR" in measure["error"]
    assert measure["rewrite"] is None
    deps = {d["name"]: d for d in measure["dependencies"]}
    assert deps["Total Quantity"]["translated"] is True


def test_accepted_rewrite_is_shown(world):
    from app.ir.model import DaxRewrite

    world.park_measure(dax="FOOBAR(1)")
    world.edit_bundle(
        lambda b: b.model.dax_rewrites.update(
            {"Total Sales": DaxRewrite(expression="FOOBAR(2)", original="FOOBAR(1)")}
        )
    )
    measure = world.get(f"no-sql-panes/{PAGE}/{CARD}").json()["measures"][0]
    assert measure["rewrite"] == "FOOBAR(2)"


def test_rejects_translated_and_unknown_panes(world):
    r = world.get(f"no-sql-panes/{PAGE}/{CARD}")
    assert r.status_code == 422 and "this pane has generated SQL" in r.text
    assert world.get(f"no-sql-panes/{PAGE}/nope").status_code == 404


def test_edited_sql_is_validated_for_untranslated_panes_only(world):
    from app.validation.harness import run_validation

    world.park_measure(dax="FOOBAR(1)")
    world.client.put(
        world.url("sql-overrides"),
        json={"page": PAGE, "visual": CARD, "sql": 'SELECT 9 AS "Total Sales"'},
    )
    spec, _, engine = __import__("app.api.dashboards", fromlist=["_load"])._load(world.cid)
    from tests.phase08 import FakeConn

    cursor = FakeConn(world.responder, world.executed).cursor()
    manual = {(PAGE, CARD): 'SELECT 9 AS "Total Sales"', (PAGE, BAR): "SELECT 1"}
    report = run_validation(spec, engine, cursor, manual_sql=manual)
    scores = {v.visual: v for p in report.pages for v in p.visuals}
    assert scores[CARD].sql_override is True and scores[CARD].status.value == "passed"
    assert scores[BAR].sql_override is True  # untranslated too
    assert scores["slicer01aaaabbbbcccc"].sql_override is False
    assert 'SELECT 9 AS "Total Sales"' in world.executed
