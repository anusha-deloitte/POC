import { useState } from 'react'

const PASSCODE_RE = /^\d{6,8}$/

interface Props {
  required?: boolean
  label?: string
  pending: boolean
  error?: string
  onSubmit: (code: string) => void
  onCancel?: () => void
}

export function MfaPasscodePrompt({
  required = true,
  label,
  pending,
  error,
  onSubmit,
  onCancel,
}: Props) {
  const [code, setCode] = useState('')
  const valid = PASSCODE_RE.test(code)

  const submit = () => {
    if (!valid || pending) return
    onSubmit(code)
    setCode('')
  }

  return (
    <div
      data-testid="mfa-prompt"
      className={`mt-2 rounded-lg border px-3 py-2 text-xs ${
        required
          ? 'border-brand-amber/40 bg-brand-amber/10 text-surface-800'
          : 'border-surface-300 bg-surface-50 text-surface-700'
      }`}
      onClick={(e) => e.preventDefault()}
    >
      <p className="mb-1.5 font-semibold">
        {label ??
          (required
            ? 'Snowflake requires MFA: enter the current code from your authenticator app.'
            : 'MFA code (if your account requires it)')}
      </p>
      <div className="flex items-center gap-2">
        <input
          type="text"
          inputMode="numeric"
          aria-label="MFA code"
          autoComplete="one-time-code"
          maxLength={8}
          value={code}
          className="input !w-32 !py-1"
          onClick={(e) => e.stopPropagation()}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault()
              e.stopPropagation()
              submit()
            }
          }}
        />
        <button
          type="button"
          className="btn-primary !px-3 !py-1 !text-xs"
          disabled={!valid || pending}
          onClick={(e) => {
            e.preventDefault()
            e.stopPropagation()
            submit()
          }}
        >
          {pending ? 'Signing in…' : 'Sign in'}
        </button>
        {onCancel && (
          <button
            type="button"
            className="text-xs text-surface-500 underline"
            onClick={(e) => {
              e.preventDefault()
              e.stopPropagation()
              onCancel()
            }}
          >
            Cancel
          </button>
        )}
      </div>
      {error && (
        <p role="alert" className="mt-1 text-brand-red">
          {error}
        </p>
      )}
    </div>
  )
}
