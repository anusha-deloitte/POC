import { useQuery } from '@tanstack/react-query'
import { ChevronDown, ChevronRight, ChevronsLeft, ChevronsRight, Eraser, Lock } from 'lucide-react'
import { useState } from 'react'
import { fetchFilterValues, type DashboardApiConfig } from './api'
import {
  BLANK_LABEL,
  basicSelection,
  basicValue,
  cardSummary,
  currentCard,
  formatValue,
  isChecked,
  isModified,
  operatorsFor,
  paneExpanded,
  paneModified,
  paneVisible,
  paneWidth,
  relativeCondition,
  searchCards,
  selectAll,
  setCard,
  toggleValue,
  type CardState,
  type CardValue,
  type PaneState,
} from './filtersPaneState'
import { clauseText } from './drillthrough'
import type { DashboardSpec, FilterCard, FilterClause, FilterCondition, FilterDefault, PageSpec } from './types'

type Colours = Record<string, unknown>
const str = (v: unknown): string | undefined => (typeof v === 'string' ? v : undefined)

function cardColours(spec: DashboardSpec, applied: boolean): Colours {
  const cards = (spec.filter_pane?.colours?.filterCard ?? {}) as Record<string, Colours>
  return cards[applied ? 'Applied' : 'Available'] ?? {}
}

// ---------------------------------------------------------------- editors

function BasicEditor({
  card,
  value,
  onChange,
  load,
}: {
  card: FilterCard
  value: CardValue
  onChange: (v: CardValue) => void
  load: (search: string) => Promise<{ values: (string | number | boolean | null)[]; truncated: boolean }>
}) {
  const [search, setSearch] = useState('')
  const values = useQuery({
    queryKey: ['filter-values', card.table, card.column, search],
    queryFn: () => load(search),
    staleTime: 60_000,
  })
  const sel = basicSelection(value)
  const list = values.data?.values ?? []
  return (
    <div data-testid="basic-editor" className="mt-1">
      <input
        aria-label={`Search ${card.display_name} values`}
        className="mb-1 w-full rounded border border-surface-300 px-1.5 py-0.5 text-xs"
        placeholder="Search"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      {!card.require_single && (
        <label className="flex items-center gap-1.5 py-0.5 text-xs">
          <input
            type="checkbox"
            checked={sel.inverted && sel.values.length === 0}
            onChange={(e) => onChange(basicValue(e.target.checked ? selectAll() : { inverted: false, values: [] }))}
          />
          Select all
        </label>
      )}
      <div data-testid="filter-value-list" className="max-h-40 overflow-y-auto overscroll-contain">
        {values.isLoading && <p className="text-[11px] text-surface-500">Loading values…</p>}
        {values.isError && (
          <p role="alert" className="text-[11px] text-brand-red">
            {values.error.message}
          </p>
        )}
        {list.map((v) => (
          <label key={String(v)} className="flex items-center gap-1.5 py-0.5 text-xs">
            <input
              type={card.require_single ? 'radio' : 'checkbox'}
              name={`single-${card.name}`}
              checked={
                card.require_single
                  ? !sel.inverted && sel.values.some((x) => x === v)
                  : isChecked(sel, v)
              }
              onChange={() => onChange(basicValue(toggleValue(sel, v, card.require_single)))}
            />
            <span className="truncate">{v === null ? BLANK_LABEL : formatValue(v)}</span>
          </label>
        ))}
      </div>
      {values.data?.truncated && (
        <p className="mt-1 text-[11px] text-surface-500">Showing the first 500 values; use search to find others.</p>
      )}
    </div>
  )
}

function AdvancedEditor({
  card,
  value,
  onApply,
}: {
  card: FilterCard
  value: CardValue
  onApply: (v: CardValue) => void
}) {
  const options = operatorsFor(card.data_type)
  const seed = (i: number): FilterCondition =>
    value?.conditions[i] ?? { op: options[0].op, values: [], params: {} }
  const [join, setJoin] = useState<'and' | 'or'>(value?.join ?? 'and')
  const [first, setFirst] = useState<FilterCondition>(seed(0))
  const [second, setSecond] = useState<FilterCondition | null>(value?.conditions[1] ?? null)
  const row = (c: FilterCondition, set: (c: FilterCondition) => void, label: string) => {
    const needs = options.find((o) => o.op === c.op)?.needsValue ?? true
    return (
      <div className="mb-1 flex gap-1">
        <select
          aria-label={`${label} operator`}
          className="rounded border border-surface-300 px-1 py-0.5 text-xs"
          value={c.op}
          onChange={(e) => set({ ...c, op: e.target.value })}
        >
          {options.map((o) => (
            <option key={o.op} value={o.op}>
              {o.label}
            </option>
          ))}
        </select>
        {needs && (
          <input
            aria-label={`${label} value`}
            className="min-w-0 flex-1 rounded border border-surface-300 px-1.5 py-0.5 text-xs"
            value={c.values[0] === undefined || c.values[0] === null ? '' : String(c.values[0])}
            onChange={(e) => set({ ...c, values: [e.target.value] })}
          />
        )}
      </div>
    )
  }
  return (
    <div data-testid="advanced-editor" className="mt-1">
      <div className="text-[11px] text-surface-500">Show items when the value</div>
      {row(first, setFirst, 'First condition')}
      <div className="mb-1 flex gap-3 text-xs">
        {(['and', 'or'] as const).map((j) => (
          <label key={j} className="flex items-center gap-1">
            <input type="radio" name={`join-${card.name}`} checked={join === j} onChange={() => setJoin(j)} />
            {j === 'and' ? 'And' : 'Or'}
          </label>
        ))}
      </div>
      {row(second ?? { op: options[0].op, values: [], params: {} }, setSecond, 'Second condition')}
      <button
        type="button"
        className="mt-1 rounded bg-brand px-2 py-0.5 text-xs font-semibold text-white"
        onClick={() => {
          const numeric = options === operatorsFor('int64')
          const clean = (c: FilterCondition): FilterCondition => ({
            ...c,
            values: c.values.map((v) => (numeric && v !== '' && !Number.isNaN(Number(v)) ? Number(v) : v)),
          })
          const needsValue = (c: FilterCondition) => options.find((o) => o.op === c.op)?.needsValue ?? true
          const active = [first, second].filter((c): c is FilterCondition => !!c && (!needsValue(c) || c.values[0] !== undefined && c.values[0] !== ''))
          onApply(active.length ? { join, conditions: active.map(clean) } : null)
        }}
      >
        Apply filter
      </button>
    </div>
  )
}

function TopNEditor({
  card,
  value,
  measures,
  onApply,
}: {
  card: FilterCard
  value: CardValue
  measures: string[]
  onApply: (v: CardValue) => void
}) {
  const p = value?.conditions[0]?.params ?? {}
  const [direction, setDirection] = useState<string>((p.direction as string) ?? 'top')
  const [n, setN] = useState<number>((p.n as number) ?? 5)
  const [by, setBy] = useState<string>((p.measure as string) ?? measures[0] ?? '')
  return (
    <div data-testid="topn-editor" className="mt-1 space-y-1 text-xs">
      <label className="flex items-center gap-1">
        Show items
        <select aria-label="Show items" className="rounded border border-surface-300 px-1" value={direction} onChange={(e) => setDirection(e.target.value)}>
          <option value="top">Top</option>
          <option value="bottom">Bottom</option>
        </select>
        <input aria-label="N" type="number" min={1} className="w-14 rounded border border-surface-300 px-1" value={n} onChange={(e) => setN(Number(e.target.value))} />
      </label>
      <label className="flex items-center gap-1">
        By value
        <select aria-label="By value" className="min-w-0 flex-1 rounded border border-surface-300 px-1" value={by} onChange={(e) => setBy(e.target.value)}>
          {measures.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>
      </label>
      <button
        type="button"
        className="rounded bg-brand px-2 py-0.5 font-semibold text-white"
        onClick={() =>
          onApply({
            join: 'and',
            conditions: [{ op: 'topn', values: [], params: { n, direction, measure: by } }],
          })
        }
      >
        Apply filter
      </button>
      <span className="hidden">{card.name}</span>
    </div>
  )
}

function RelativeEditor({
  card,
  value,
  onApply,
}: {
  card: FilterCard
  value: CardValue
  onApply: (v: CardValue) => void
}) {
  const ui = (value?.conditions[0]?.params.ui as { direction: string; n: number; unit: string; calendar: boolean; include_today: boolean } | undefined) ?? {
    direction: 'last', n: 1, unit: card.data_type === 'datetime' ? 'day' : 'day', calendar: false, include_today: false,
  } // prettier-ignore
  const time = !!value?.conditions[0]?.params.time
  const [state, setState] = useState(ui)
  const units = time ? ['minute', 'hour', 'day', 'week', 'month', 'year'] : ['day', 'week', 'month', 'year']
  return (
    <div data-testid="relative-editor" className="mt-1 space-y-1 text-xs">
      <div className="flex items-center gap-1">
        <select aria-label="Direction" className="rounded border border-surface-300 px-1" value={state.direction} onChange={(e) => setState({ ...state, direction: e.target.value })}>
          <option value="last">is in the last</option>
          <option value="next">is in the next</option>
          <option value="this">is in this</option>
        </select>
        {state.direction !== 'this' && (
          <input aria-label="Amount" type="number" min={1} className="w-14 rounded border border-surface-300 px-1" value={state.n} onChange={(e) => setState({ ...state, n: Number(e.target.value) })} />
        )}
        <select aria-label="Unit" className="rounded border border-surface-300 px-1" value={state.unit} onChange={(e) => setState({ ...state, unit: e.target.value })}>
          {units.map((u) => (
            <option key={u} value={u}>
              {u}s
            </option>
          ))}
        </select>
      </div>
      <label className="flex items-center gap-1">
        <input type="checkbox" checked={state.calendar} onChange={(e) => setState({ ...state, calendar: e.target.checked })} />
        Calendar
      </label>
      <label className="flex items-center gap-1">
        <input type="checkbox" checked={state.include_today} onChange={(e) => setState({ ...state, include_today: e.target.checked })} />
        Include today
      </label>
      <button
        type="button"
        className="rounded bg-brand px-2 py-0.5 font-semibold text-white"
        onClick={() =>
          onApply({
            join: 'and',
            conditions: [
              relativeCondition(
                { ...state, direction: state.direction as 'last' | 'next' | 'this' },
                time,
              ),
            ],
          })
        }
      >
        Apply filter
      </button>
    </div>
  )
}

// ---------------------------------------------------------------- one card

function Card({
  card,
  page,
  spec,
  state,
  onChange,
  load,
}: {
  card: FilterCard
  page: PageSpec
  spec: DashboardSpec
  state: PaneState
  onChange: (next: PaneState) => void
  load: (card: FilterCard, search: string) => ReturnType<typeof fetchFilterValues>
}) {
  const [open, setOpen] = useState(false)
  const now = currentCard(card, page.name, state)
  const modified = isModified(card, page.name, state)
  const readOnly = card.locked || !card.supported
  const colours = cardColours(spec, modified)
  const set = (next: CardState) => onChange(setCard(state, card, page.name, next))
  const measures = Object.entries(spec.measure_tiers)
    .filter(([, t]) => t >= 0)
    .map(([m]) => m)
  const canSwitch = spec.allow_change_filter_types !== false && (now.kind === 'basic' || now.kind === 'advanced')
  return (
    <div
      data-testid={`filter-card-${card.name}`}
      className="mb-1 rounded border border-surface-200 px-2 py-1"
      style={{ background: str(colours.backgroundColor), color: str(colours.foregroundColor) }}
    >
      <div className="flex items-center gap-1">
        <button
          type="button"
          aria-expanded={open}
          aria-label={`${card.display_name}`}
          className="flex min-w-0 flex-1 items-center gap-1 text-left"
          onClick={() => setOpen(!open)}
        >
          {open ? <ChevronDown className="h-3 w-3 shrink-0" /> : <ChevronRight className="h-3 w-3 shrink-0" />}
          <span className="truncate text-xs font-semibold">{card.display_name}</span>
        </button>
        {card.locked && <Lock aria-label="Locked" className="h-3 w-3 shrink-0 text-surface-500" />}
        {!readOnly && (
          <button
            type="button"
            aria-label={`Clear ${card.display_name}`}
            title="Clear filter"
            className="shrink-0 text-surface-500 hover:text-surface-800"
            onClick={() => set({ kind: now.kind, value: null })}
          >
            <Eraser className="h-3 w-3" />
          </button>
        )}
      </div>
      <div data-testid="card-summary" className="truncate pl-4 text-[11px] text-surface-600">
        {cardSummary(card, now.value)}
      </div>
      {open && !readOnly && (
        <div className="pl-4">
          {canSwitch && (
            <select
              aria-label="Filter type"
              className="mt-1 rounded border border-surface-300 px-1 text-xs"
              value={now.kind}
              onChange={(e) => set({ kind: e.target.value as 'basic' | 'advanced', value: now.value })}
            >
              <option value="basic">Basic filtering</option>
              <option value="advanced">Advanced filtering</option>
            </select>
          )}
          {now.kind === 'basic' && (
            <BasicEditor card={card} value={now.value} onChange={(v) => set({ kind: 'basic', value: v })} load={(s) => load(card, s)} />
          )}
          {now.kind === 'advanced' && (
            <AdvancedEditor key={JSON.stringify(now.value)} card={card} value={now.value} onApply={(v) => set({ kind: 'advanced', value: v })} />
          )}
          {now.kind === 'topn' && (
            <TopNEditor card={card} value={now.value} measures={measures} onApply={(v) => set({ kind: 'topn', value: v })} />
          )}
          {now.kind === 'relative' && (
            <RelativeEditor card={card} value={now.value} onApply={(v) => set({ kind: 'relative', value: v })} />
          )}
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------- the pane

export function FiltersPane({
  spec,
  page,
  state,
  onChange,
  onReset,
  conversionId,
  connectionId,
  apiConfig,
  drillClauses = [],
}: {
  spec: DashboardSpec
  page: PageSpec
  state: PaneState
  onChange: (next: PaneState) => void
  onReset: () => void
  conversionId: string
  connectionId: string
  apiConfig?: DashboardApiConfig
  /** the drill-through context of this page (read-only) */
  drillClauses?: FilterClause[]
}) {
  const [expanded, setExpanded] = useState(paneExpanded(page, spec))
  const [search, setSearch] = useState('')
  const [closed, setClosed] = useState<Record<string, boolean>>({})
  if (!paneVisible(page, spec)) return null
  const colours = (spec.filter_pane?.colours ?? {}) as Colours
  const style: React.CSSProperties = {
    background: str(colours.backgroundColor),
    color: str(colours.foregroundColor),
    borderColor: str(colours.borderColor),
  }
  const modified = paneModified(spec, page, state)
  if (!expanded)
    return (
      <button
        type="button"
        data-testid="filters-tab"
        aria-label="Open the Filters pane"
        onClick={() => setExpanded(true)}
        className="flex h-full w-7 shrink-0 flex-col items-center gap-2 border-l border-surface-300 bg-surface-50 py-2 text-xs text-surface-700 hover:bg-surface-100"
        style={style}
      >
        <ChevronsLeft className="h-3.5 w-3.5" aria-hidden />
        <span className="[writing-mode:vertical-rl] font-semibold">Filters</span>
        {modified && <span data-testid="pane-dot" aria-label="Filters changed" className="h-2 w-2 rounded-full bg-brand" />}
      </button>
    )

  const load = (card: FilterCard, q: string) =>
    fetchFilterValues(conversionId, connectionId, { page: page.name, table: card.table!, column: card.column!, search: q || undefined }, apiConfig)
  const section = (key: string, title: string, cards: FilterCard[]) => {
    const visible = searchCards(cards, search).filter((c) => !c.hidden)
    if (!cards.length) return null
    return (
      <div key={key} data-testid={`filters-section-${key}`} className="mb-2">
        <button
          type="button"
          aria-expanded={!closed[key]}
          className="flex w-full items-center gap-1 py-1 text-left text-xs font-bold"
          onClick={() => setClosed({ ...closed, [key]: !closed[key] })}
        >
          {closed[key] ? <ChevronRight className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
          {title}
        </button>
        {!closed[key] &&
          visible.map((c) => (
            <Card key={`${c.scope}:${c.name}`} card={c} page={page} spec={spec} state={state} onChange={onChange} load={load} />
          ))}
      </div>
    )
  }
  return (
    <aside
      data-testid="filters-pane"
      className="flex h-full min-h-0 shrink-0 flex-col border-l border-surface-300 bg-surface-50"
      style={{ ...style, width: paneWidth(page, spec) }}
    >
      <div className="flex items-center gap-1 border-b border-surface-200 px-2 py-1.5">
        <span className="text-sm font-bold">Filters</span>
        {modified && <span data-testid="pane-dot" aria-label="Filters changed" className="h-2 w-2 rounded-full bg-brand" />}
        <button type="button" className="ml-auto text-[11px] text-brand-blue underline disabled:opacity-40" disabled={!modified} onClick={onReset}>
          Reset to default
        </button>
        <button type="button" aria-label="Collapse the Filters pane" onClick={() => setExpanded(false)}>
          <ChevronsRight className="h-3.5 w-3.5" />
        </button>
      </div>
      <div className="px-2 py-1">
        <input
          aria-label="Search filters"
          placeholder="Search filters"
          className="w-full rounded border border-surface-300 px-1.5 py-0.5 text-xs"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>
      <div data-testid="filters-scroll" className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-2 pb-2">
        {drillClauses.length > 0 && (
          <div data-testid="filters-section-drill" className="mb-2">
            <div className="py-1 text-xs font-bold">Drill through</div>
            {drillClauses.map((c, i) => (
              <div key={i} className="mb-1 rounded border border-surface-200 px-2 py-1 text-[11px] text-surface-700">
                {clauseText(c)}
              </div>
            ))}
          </div>
        )}
        {section('page', 'Filters on this page', page.filters ?? [])}
        {section('report', 'Filters on all pages', spec.report_filters ?? [])}
      </div>
    </aside>
  )
}

export type { FilterDefault }
