import { reportClientError } from './errorReporting'
import type {
  ConnectionProfile,
  ConnectionSessionStatus,
  ConnectionTestResult,
  ConnectionUpdate,
  ConversionSummary,
  DashboardPublication,
  IssuedDashboardToken,
  CompilationAuditData,
  DaxRewrite,
  MeasureSqlResult,
  NoSqlPane,
  NoSqlPaneDetail,
  QueryAudit,
  RecheckResult,
  SqlEditorInfo,
  SqlTestResult,
  LlmProviders,
  PreflightResult,
  SourceHints,
  NewConnection,
  NewSourceConnection,
  SourceConnectionProfile,
  Batch,
  BatchConfirmRequest,
  BatchReportRow,
  BatchSummary,
  ParityHistory,
  ParityHistoryRunDetail,
  ParityPage,
  ParityValues,
  ParityValuesRequest,
  ParityComparison,
  ReferenceUploadResult,
} from './types'

const BASE = '/api/v1'

export async function readErrorDetail(res: Response): Promise<string> {
  let detail = res.statusText
  const contentType = res.headers.get('content-type') ?? ''

  try {
    if (contentType.includes('application/json')) {
      const body = await res.json()
      return typeof body.detail === 'string' ? body.detail : JSON.stringify(body.detail)
    }

    const text = (await res.text()).trim()
    // proxy/gateway error pages are HTML — show a readable message instead
    if (/<html|<head|<body/i.test(text)) {
      if (res.status === 504)
        return 'The request timed out at the gateway (504). The operation may still be running server-side — check progress or retry shortly.'
      return `${res.status} ${res.statusText || 'gateway error'}`
    }
    if (text) return text
  } catch {
    /* fall back to statusText */
  }

  return detail
}

export async function handle<T>(res: Response): Promise<T> {
  if (!res.ok) {
    const message = await readErrorDetail(res)
    reportClientError({ message, path: res.url, status: res.status })
    throw new Error(message)
  }
  if (res.status === 204) return undefined as T
  return res.json() as Promise<T>
}

function exportDashboard(conversionId: string, connectionId: string): Promise<Blob>
function exportDashboard(conversionId: string, connectionId: string, kind: 'react'): Promise<Blob>
function exportDashboard(
  conversionId: string,
  connectionId: string,
  kind: 'standalone',
): Promise<{ blob: Blob; filename: string }>
async function exportDashboard(
  conversionId: string,
  connectionId: string,
  kind: 'react' | 'standalone' = 'react',
): Promise<Blob | { blob: Blob; filename: string }> {
  const response = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/${kind === 'standalone' ? 'export-standalone' : 'export'}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ connection_id: connectionId }),
    },
  )
  if (!response.ok) {
    const message = await readErrorDetail(response)
    reportClientError({ message, path: response.url, status: response.status, context: 'export' })
    throw new Error(message)
  }
  const blob = await response.blob()
  if (kind === 'react') return blob
  const match = /filename="?([^";]+)"?/i.exec(response.headers.get('content-disposition') ?? '')
  return { blob, filename: match?.[1] ?? 'dashboard-standalone.zip' }
}

export const api = {
  uploadPbip(file: File, name?: string): Promise<ConversionSummary> {
    const form = new FormData()
    form.append('file', file)
    if (name?.trim()) form.append('name', name.trim())
    return fetch(`${BASE}/conversions`, { method: 'POST', body: form }).then((r) =>
      handle<ConversionSummary>(r),
    )
  },
  deleteConversion(id: string): Promise<void> {
    return fetch(`${BASE}/conversions/${id}`, { method: 'DELETE' }).then((r) => handle<void>(r))
  },
  renameJob(id: string, name: string): Promise<{ id: string; name: string }> {
    return fetch(`${BASE}/conversions/${id}/name`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    }).then((r) => handle<{ id: string; name: string }>(r))
  },
  listConversions(): Promise<ConversionSummary[]> {
    return fetch(`${BASE}/conversions`).then((r) => handle<ConversionSummary[]>(r))
  },
  getConversion(id: string): Promise<ConversionSummary> {
    return fetch(`${BASE}/conversions/${id}`).then((r) => handle<ConversionSummary>(r))
  },
  createConnection(spec: NewConnection): Promise<ConnectionProfile> {
    return fetch(`${BASE}/connections`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(spec),
    }).then((r) => handle<ConnectionProfile>(r))
  },
  listConnections(): Promise<ConnectionProfile[]> {
    return fetch(`${BASE}/connections`).then((r) => handle<ConnectionProfile[]>(r))
  },
  deleteConnection(id: string): Promise<void> {
    return fetch(`${BASE}/connections/${id}`, { method: 'DELETE' }).then((r) => handle<void>(r))
  },
  updateConnection(id: string, patch: ConnectionUpdate): Promise<ConnectionProfile> {
    return fetch(`${BASE}/connections/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    }).then((r) => handle<ConnectionProfile>(r))
  },
  testConnection(
    id: string,
    passcode?: string,
    opts?: { force?: boolean },
  ): Promise<ConnectionTestResult> {
    const body: Record<string, unknown> = {}
    if (passcode) body.passcode = passcode
    if (opts?.force) body.force = true
    const hasBody = Object.keys(body).length > 0
    return fetch(`${BASE}/connections/${id}/test`, {
      method: 'POST',
      ...(hasBody
        ? { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
        : {}),
    }).then((r) => handle<ConnectionTestResult>(r))
  },
  connectionSession(id: string, opts?: { verify?: boolean }): Promise<ConnectionSessionStatus> {
    const q = opts?.verify ? '?verify=true' : ''
    return fetch(`${BASE}/connections/${id}/session${q}`).then((r) =>
      handle<ConnectionSessionStatus>(r),
    )
  },
  daxRewrites(conversionId: string): Promise<{ rewrites: Record<string, DaxRewrite> }> {
    return fetch(`${BASE}/conversions/${conversionId}/dashboard/dax-rewrites`).then((r) =>
      handle<{ rewrites: Record<string, DaxRewrite> }>(r),
    )
  },
  revertDaxRewrite(
    conversionId: string,
    measure: string,
  ): Promise<{ reverted: string; remaining: string[] }> {
    return fetch(
      `${BASE}/conversions/${conversionId}/dashboard/dax-rewrites/${encodeURIComponent(measure)}`,
      { method: 'DELETE' },
    ).then((r) => handle<{ reverted: string; remaining: string[] }>(r))
  },
  llmProviders(): Promise<LlmProviders> {
    return fetch(`${BASE}/llm/providers`).then((r) => handle<LlmProviders>(r))
  },
  sourceHints(conversionId: string): Promise<SourceHints> {
    return fetch(`${BASE}/conversions/${conversionId}/source-hints`).then((r) =>
      handle<SourceHints>(r),
    )
  },
  preflight(
    conversionId: string,
    body: {
      connection_id: string
      database_override?: string | null
      schema_override?: string | null
    },
  ): Promise<PreflightResult> {
    return fetch(`${BASE}/conversions/${conversionId}/dashboard/preflight`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }).then((r) => handle<PreflightResult>(r))
  },
  exportDashboard,
  listDashboardPublications(): Promise<DashboardPublication[]> {
    return fetch(`${BASE}/dashboard-publications`).then((response) =>
      handle<DashboardPublication[]>(response),
    )
  },
  rotateDashboardPublication(
    id: string,
    overlapSeconds = 0,
  ): Promise<IssuedDashboardToken> {
    return fetch(`${BASE}/dashboard-publications/${id}/rotate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ overlap_seconds: overlapSeconds }),
    }).then((response) => handle<IssuedDashboardToken>(response))
  },
  revokeDashboardPublication(id: string): Promise<DashboardPublication> {
    return fetch(`${BASE}/dashboard-publications/${id}`, { method: 'DELETE' }).then((response) =>
      handle<DashboardPublication>(response),
    )
  },
  listSourceKinds(): Promise<{ id: string; label: string; available: boolean }[]> {
    return fetch(`${BASE}/source-connections/kinds`).then((r) =>
      handle<{ id: string; label: string; available: boolean }[]>(r),
    )
  },
  createSourceConnection(spec: NewSourceConnection): Promise<SourceConnectionProfile> {
    return fetch(`${BASE}/source-connections`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(spec),
    }).then((r) => handle<SourceConnectionProfile>(r))
  },
  listSourceConnections(): Promise<SourceConnectionProfile[]> {
    return fetch(`${BASE}/source-connections`).then((r) =>
      handle<SourceConnectionProfile[]>(r),
    )
  },
  deleteSourceConnection(id: string): Promise<void> {
    return fetch(`${BASE}/source-connections/${id}`, { method: 'DELETE' }).then((r) =>
      handle<void>(r),
    )
  },
  testSourceConnection(id: string): Promise<{ ok: boolean }> {
    return fetch(`${BASE}/source-connections/${id}/test`, { method: 'POST' }).then((r) =>
      handle<{ ok: boolean }>(r),
    )
  },
  getMigrationResult(conversionId: string): Promise<{ ran: boolean; ok?: boolean; tables?: unknown[] }> {
    return fetch(`${BASE}/conversions/${conversionId}/migration`).then((r) =>
      handle<{ ran: boolean; ok?: boolean; tables?: unknown[] }>(r),
    )
  },
}

export interface QueryAuditParams {
  kind?: string
  source?: string
  page?: string
  history_for?: string
  status?: string
  search?: string
}

function auditQuery(params: QueryAuditParams): string {
  const q = new URLSearchParams()
  for (const [k, v] of Object.entries(params)) if (v) q.set(k, v)
  const text = q.toString()
  return text ? `?${text}` : ''
}

const dashboardUrl = (id: string, path: string) => `${BASE}/conversions/${id}/dashboard/${path}`

function sendJson<T>(method: string, url: string, body: unknown): Promise<T> {
  return fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  }).then((r) => handle<T>(r))
}

export const auditApi = {
  queryAudit(id: string, params: QueryAuditParams = {}): Promise<QueryAudit> {
    return fetch(dashboardUrl(id, `query-audit${auditQuery(params)}`)).then((r) =>
      handle<QueryAudit>(r),
    )
  },
  queryAuditExportUrl(id: string, format: 'xlsx' | 'json', params: QueryAuditParams = {}): string {
    return dashboardUrl(id, `query-audit/export${auditQuery({ ...params, ...{ format } })}`)
  },
  sqlEditor(id: string, page: string, visual: string): Promise<SqlEditorInfo> {
    const q = new URLSearchParams({ page, visual })
    return fetch(dashboardUrl(id, `sql-editor?${q}`)).then((r) => handle<SqlEditorInfo>(r))
  },
  testSql(
    id: string,
    body: { page: string; visual: string; connection_id: string; sql: string; filters?: unknown[] },
  ): Promise<SqlTestResult> {
    return sendJson('POST', dashboardUrl(id, 'sql-overrides/test'), { filters: [], ...body })
  },
  saveSql(id: string, body: { page: string; visual: string; sql: string }) {
    return sendJson<{ override: unknown }>('PUT', dashboardUrl(id, 'sql-overrides'), body)
  },
  deleteSql(id: string, page: string, visual: string): Promise<{ deleted: boolean }> {
    return fetch(
      dashboardUrl(id, `sql-overrides/${encodeURIComponent(page)}/${encodeURIComponent(visual)}`),
      { method: 'DELETE' },
    ).then((r) => handle<{ deleted: boolean }>(r))
  },
  noSqlPanes(id: string): Promise<{ panes: NoSqlPane[] }> {
    return fetch(dashboardUrl(id, 'no-sql-panes')).then((r) => handle<{ panes: NoSqlPane[] }>(r))
  },
  noSqlPane(id: string, page: string, visual: string): Promise<NoSqlPaneDetail> {
    return fetch(
      dashboardUrl(id, `no-sql-panes/${encodeURIComponent(page)}/${encodeURIComponent(visual)}`),
    ).then((r) => handle<NoSqlPaneDetail>(r))
  },
  recheck(
    id: string,
    body: { page: string; visual: string; connection_id: string },
  ): Promise<RecheckResult> {
    return sendJson('POST', dashboardUrl(id, 'recheck'), body)
  },
  compilationAudit(id: string): Promise<CompilationAuditData> {
    return fetch(dashboardUrl(id, 'compilation-audit')).then((r) =>
      handle<CompilationAuditData>(r),
    )
  },
  compilationAuditExportUrl(id: string, format: 'xlsx' | 'json'): string {
    return dashboardUrl(id, `compilation-audit/export?format=${format}`)
  },
  testMeasureSql(
    id: string,
    body: { measure: string; sql: string; connection_id: string },
  ): Promise<MeasureSqlResult> {
    return sendJson('POST', dashboardUrl(id, 'measure-sql/test'), body)
  },
  saveMeasureSql(id: string, body: { measure: string; sql: string }) {
    return sendJson<{ fix: unknown }>('PUT', dashboardUrl(id, 'measure-sql'), body)
  },
  measureSqlFixes(id: string): Promise<{ fixes: Record<string, { sql: string; original: string }> }> {
    return fetch(dashboardUrl(id, 'measure-sql')).then((r) =>
      handle<{ fixes: Record<string, { sql: string; original: string }> }>(r),
    )
  },
  revertMeasureSql(id: string, measure: string): Promise<{ reverted: string; remaining: string[] }> {
    return fetch(dashboardUrl(id, `measure-sql/${encodeURIComponent(measure)}`), {
      method: 'DELETE',
    }).then((r) => handle<{ reverted: string; remaining: string[] }>(r))
  },
}

const compareUrl = (id: string, path = '') => dashboardUrl(id, `visual-compare${path}`)

export type ParitySide = 'reference' | 'rendered'

/** Per-conversion PDF comparison endpoints. */
export const parityApi = {
  list(id: string): Promise<{ pages: ParityPage[] }> {
    return fetch(compareUrl(id)).then((r) => handle<{ pages: ParityPage[] }>(r))
  },
  references(
    id: string,
  ): Promise<{ pages: { page: string; display_name: string; has_reference: boolean }[] }> {
    return fetch(compareUrl(id, '/references')).then((r) =>
      handle<{ pages: { page: string; display_name: string; has_reference: boolean }[] }>(r),
    )
  },
  uploadReferencePdf(id: string, file: File, match = false): Promise<ReferenceUploadResult> {
    const form = new FormData()
    form.append('pdf', file, file.name)
    return fetch(compareUrl(id, `/reference-pdf?match=${match ? 'true' : 'false'}`), {
      method: 'POST',
      body: form,
    }).then((r) => handle<ReferenceUploadResult>(r))
  },
  detectFilters(id: string, page: string, body: unknown): Promise<{ selections: unknown[] }> {
    return sendJson('POST', compareUrl(id, `/${encodeURIComponent(page)}/detect-filters`), body)
  },
  /** Image comparison of one page (rendered capture vs the stored reference). */
  compare(
    id: string,
    page: string,
    form: { rendered: Blob; reference?: File; filters?: unknown; batchId?: string },
  ): Promise<ParityComparison> {
    const data = new FormData()
    if (form.reference) data.append('reference', form.reference, 'reference.png')
    data.append('rendered', form.rendered, 'rendered.png')
    if (form.filters !== undefined) data.append('filters', JSON.stringify(form.filters))
    if (form.batchId) data.append('batch_id', form.batchId)
    return fetch(compareUrl(id, `/${encodeURIComponent(page)}`), {
      method: 'POST',
      body: data,
    }).then((r) => handle<ParityComparison>(r))
  },
  /** Number check of one page (query results vs the numbers printed in the reference PDF). */
  values(id: string, page: string, body: ParityValuesRequest): Promise<ParityValues> {
    return sendJson('POST', compareUrl(id, `/${encodeURIComponent(page)}/values`), body)
  },
  applyFixes(
    id: string,
    page: string,
    findingIds: string[],
  ): Promise<{ applied?: unknown[]; skipped?: { id: string; reason: string }[] }> {
    return sendJson('POST', compareUrl(id, `/${encodeURIComponent(page)}/apply-fixes`), {
      finding_ids: findingIds,
    })
  },
  imageUrl(id: string, page: string, side: ParitySide, version?: string | number): string {
    const q = version === undefined ? '' : `?t=${version}`
    return compareUrl(id, `/${encodeURIComponent(page)}/image/${side}${q}`)
  },
  history(id: string, page: string, batchId?: string): Promise<ParityHistory> {
    const q = batchId ? `?batch_id=${encodeURIComponent(batchId)}` : ''
    return fetch(compareUrl(id, `/${encodeURIComponent(page)}/history${q}`)).then((r) =>
      handle<ParityHistory>(r),
    )
  },
  historyRun(id: string, page: string, runId: string): Promise<ParityHistoryRunDetail> {
    return fetch(
      compareUrl(id, `/${encodeURIComponent(page)}/history/${encodeURIComponent(runId)}`),
    ).then((r) => handle<ParityHistoryRunDetail>(r))
  },
  historyImageUrl(id: string, page: string, runId: string, side: ParitySide): string {
    return compareUrl(
      id,
      `/${encodeURIComponent(page)}/history/${encodeURIComponent(runId)}/image/${side}`,
    )
  },
}

const BATCH = `${BASE}/visual-compare`

/** Multi-PDF batches (not conversion-scoped). */
export const batchApi = {
  create(files: File[]): Promise<Batch> {
    const form = new FormData()
    for (const f of files) form.append('pdfs', f, f.name)
    return fetch(`${BATCH}/batches`, { method: 'POST', body: form }).then((r) => handle<Batch>(r))
  },
  list(): Promise<{ batches: BatchSummary[] }> {
    return fetch(`${BATCH}/batches`).then((r) => handle<{ batches: BatchSummary[] }>(r))
  },
  get(id: string): Promise<Batch> {
    return fetch(`${BATCH}/batches/${id}`).then((r) => handle<Batch>(r))
  },
  pageImageUrl(id: string, pdfIndex: number, pdfPage: number): string {
    return `${BATCH}/batches/${id}/pdfs/${pdfIndex}/pages/${pdfPage}/image`
  },
  remove(id: string): Promise<void> {
    return fetch(`${BATCH}/batches/${id}`, { method: 'DELETE' }).then((r) => handle<void>(r))
  },
  confirm(
    id: string,
    body: BatchConfirmRequest,
  ): Promise<{ stored: number; superseded_comparisons: number; batch: Batch }> {
    return sendJson('POST', `${BATCH}/batches/${id}/confirm`, body)
  },
  reportUrl(id: string, format: 'json' | 'xlsx'): string {
    return `${BATCH}/batches/${id}/report?format=${format}`
  },
  async report(id: string): Promise<BatchReportRow[]> {
    const body = await fetch(batchApi.reportUrl(id, 'json')).then((r) =>
      handle<BatchReportRow[] | { rows: BatchReportRow[] }>(r),
    )
    return Array.isArray(body) ? body : (body.rows ?? [])
  },
}
