"""Sources of the standalone dashboard's local service (shipped as `service/` in the package)."""
