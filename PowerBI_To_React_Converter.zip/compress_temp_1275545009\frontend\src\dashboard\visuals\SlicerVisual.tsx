import { fontCss } from '../pbi/fonts'
import { PBI_DEFAULTS } from '../pbi/defaults'
import { resolveVisual, usePbiTheme } from '../pbi/resolve'
import type { VisualResult, VisualSpec } from '../types'

type Value = string | number

/** The values a slicer lists: the data, plus the current / saved selection even when the data
 * does not (or cannot be loaded) contain it. */
export function slicerOptions(data: VisualResult | undefined, selected: Value[]): Value[] {
  const out: Value[] = []
  for (const row of data?.rows ?? []) {
    const v = row[0]
    if (v !== null && v !== undefined && !out.some((o) => String(o) === String(v))) out.push(v)
  }
  for (const v of selected) if (!out.some((o) => String(o) === String(v))) out.push(v)
  return out
}

export function SlicerVisual({
  spec,
  data,
  selected,
  onChange,
}: {
  spec: VisualSpec
  data?: VisualResult
  selected: Value[]
  onChange: (values: Value[]) => void
}) {
  const theme = usePbiTheme()
  const options = slicerOptions(data, selected)
  const select = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const v = e.target.value
    if (v === '') onChange([])
    else onChange([options.find((o) => String(o) === v) ?? v])
  }
  const value = selected.length ? String(selected[0]) : ''
  const label = spec.title ?? spec.slicer_target?.column ?? 'Filter'

  if (!spec.pbir) {
    return (
      <label className="flex h-full w-full flex-col justify-center gap-0.5 px-1">
        <span className="truncate text-[10px] font-medium uppercase tracking-wide text-surface-500">{label}</span>
        <select
          multiple={false}
          className="w-full rounded border border-surface-400 bg-white px-1.5 py-1 text-xs"
          value={value}
          onChange={select}
        >
          <option value="">All</option>
          {options.map((o) => (
            <option key={String(o)} value={String(o)}>
              {String(o)}
            </option>
          ))}
        </select>
      </label>
    )
  }

  // Power BI dropdown geometry: boxed select opening at the bottom, chevron at the right
  const style = resolveVisual(spec, theme)
  const d = PBI_DEFAULTS.slicer.dropdown
  const containerNamesIt =
    style.title.show && (style.title.text ?? spec.title ?? '').toLowerCase() === (style.slicer.headerText ?? spec.slicer_target?.column ?? '').toLowerCase()
  const showHeader = style.slicer.headerShow && !containerNamesIt
  const header = style.slicer.headerText ?? spec.slicer_target?.column ?? label
  return (
    <div data-testid="pbi-slicer" className="flex h-full w-full flex-col overflow-hidden">
      {showHeader && (
        <div
          data-testid="slicer-header"
          className="truncate"
          style={{ ...fontCss(style.slicer.headerFont), color: style.slicer.itemsColor, paddingLeft: d.textPadLeftPx }}
        >
          {header}
        </div>
      )}
      <div className="relative" style={{ margin: `${showHeader ? d.gapPx / 2 : 0}px ${d.insetPx}px 0 ${d.insetPx}px` }}>
        <select
          aria-label={header}
          value={value}
          onChange={select}
          className="w-full appearance-none bg-transparent outline-none"
          style={{
            ...fontCss(style.slicer.itemsFont),
            color: style.slicer.itemsColor,
            border: `1px solid ${d.borderColor}`,
            paddingTop: d.textPadTopPx,
            paddingBottom: d.textPadTopPx / 2,
            paddingLeft: d.textPadLeftPx,
            paddingRight: d.chevron.w + d.chevron.rightPx * 2,
          }}
        >
          <option value="">All</option>
          {options.map((o) => (
            <option key={String(o)} value={String(o)}>
              {String(o)}
            </option>
          ))}
        </select>
        <svg
          aria-hidden
          width={d.chevron.w}
          height={d.chevron.h}
          viewBox={`0 0 ${d.chevron.w} ${d.chevron.h}`}
          className="pointer-events-none absolute"
          style={{ right: d.chevron.rightPx, top: d.chevron.topPx }}
        >
          <path
            d={`M1 1 L${d.chevron.w / 2} ${d.chevron.h - 1} L${d.chevron.w - 1} 1`}
            fill="none"
            stroke={d.chevron.color}
            strokeWidth={d.chevron.strokePx}
          />
        </svg>
      </div>
    </div>
  )
}
