# Phase 08 - Audits and editing: Snowflake query audit, Edit SQL, Re-check, No SQL generated, Fix measure, DAX Audit

## Purpose
Show exactly which SQL ran on Snowflake for which pane (with filters, warehouse/role, timing, query id), let a reviewer
hand-edit a pane's SQL or a measure's SQL safely, re-check one pane without a full Convert, and see/download the per-measure
compilation audit.

All endpoints below live under `/api/v1/conversions/{conversion_id}/dashboard` (same router and auth as the existing
dashboard endpoints) unless stated otherwise. All filters/columns are exact-case strings.

## 1. Query audit (backend)
### 1.1 Event logging - `services/query_audit.py`
- Events are `dashboard_query` lines in `<conversion>/events.jsonl` (via `append_jsonl`), written best-effort (never break a
  query). `write_query_event(path, record)`: drops `sql`, `compat_sql`, `totals_sql` when `log_sql_text` is off and sets
  `sql_logged`.
- Constants: `SCHEMA_VERSION="1.1"`, `MAX_EVENTS=20000`, `MAX_HISTORY=50`, `TITLE_SUFFIX="#title"`,
  `STATUSES=(ok, empty, error, plan_error, cached)`, `KINDS=(dashboard, totals, drill, validation, probe, ai_check, ai_llm, setup)`,
  `KIND_GROUPS={"conversion": (validation, probe, ai_check, ai_llm)}`; labels: `ai_llm_rewrite` "AI model call (DAX rewrite)",
  `ai_llm_sql` "AI model call (SQL translation)", `identifier_case_check` "Identifier case check", `access_preflight` "Access preflight".
- SQL context registry: `remember_sql_context(sql, context)` (bounded dict, 20,000, under a lock; cleared when full) and
  `sql_context_for(sql)`. The engine calls it in `_annotate_sql` for every `sql_context` passed to `build_sql`.
- `AuditedConnection(conn, events_path, *, conversion_id, connection_id, profile, kind="validation", source="conversion", extra)`
  returns `AuditedCursor`s; every real `execute` writes one event: base fields (conversion_id, connection_id, query_tag, source,
  runtime="snowflake", profile info, extra), `kind`, `context` (stage context or the registered context of the SQL), parsed
  `page/visual/check`, `attempt="primary"`, `status` (error | empty when rowcount == 0 | ok), `elapsed_ms`, `row_count` (rowcount
  when >= 0), `error`, `query_id` (`cursor.sfqid`), `sql`. `stage(kind, context)` context manager temporarily switches kind/context.
- `audit_stage(cursor_or_conn, kind, context=None)`: applies `stage` when the cursor's connection is audited; no-op otherwise.
- `parse_context(context) -> (page, visual, check)`: setup labels -> `(None, None, label)`; `visual:<page>/<visual>[:check]` and
  `probe:<page>/<measure>[:check]` -> page/name/check (check defaults to the head); `ai_rewrite_gate|ai_sql_check|ai_llm_rewrite|ai_llm_sql:<m>`
  -> `(None, m, head)`; `parity_expected|parity_actual:<page>/<visual>`; else `(None, None, context)`.
- Dashboard `_audited(conn, store, connection_id, conversion_id, kind, context=None, extra=None)` wraps a connection with
  `_profile_info` (warehouse, role, connection_name as configured at query time; never secrets).
### 1.2 Live query logging (`run_batch_query`, `drill_query`, totals)
Every attempt of `/query` (and published `/query`) writes a record with: `kind` (dashboard | totals | drill), `page`, `visual`
(`<visual>#title` for title-measure queries), `status` (ok/empty/error/plan_error/cached), `attempt` (primary | fallback | plan),
`source` (editor | published), `runtime`, warehouse/role/connection name, `tables` (`_tables_read`: every bound table whose
qualified name or native query appears in the SQL -> `[{model_table, physical}]`), `visual_filters`, `request_filters`
(slicer/cross filters the visual applied, with `source`; a slicer never filters its own domain), `query_id`, `title_value`
(evaluated measure-driven title text), `execution_path`, `fallback_reason`, `sql`/`compat_sql`/`totals_sql`, `sql_override`,
`unapplied_filters`, `drill` (drill step). The query result cache is keyed on SQL text.
### 1.3 Reading and exports
- `read_query_events(path, limit)`: reads the file backwards in 64 KiB chunks, newest first, only `dashboard_query` events, capped.
- `load_query_audit(path, spec, *, source="all", page=None, history_for=None, kind="dashboard", limit)`: records (fields listed in
  1.2 plus `page_name`, `pane` - readable pane names from the spec: visual title, else the latest title value, else
  `<visual_type> <name>`; setup -> label; probe -> "Filter probe: [m]"; ai_check without page -> "AI check: [m]"; ai_llm -> label +
  "[m]" or "Cortex preflight"; title queries get " (title measure)"; `legacy` when the event has no `status`). Default view = latest
  run per `(kind, page, visual, check, attempt)`; `history_for="<page>/<visual>"` = that pane's runs newest first (max 50). Sort by
  page name, pane, check, primary first. `summary`: total, panes, ok, empty, error, plan_error, cached, slowest_ms, slowest_pane,
  avg_ms (non-cached), warehouses, roles, sql_logging, events_read, events_cap, `kinds` (latest-per-key counts of every kind).
- `build_query_audit_json(rows, summary, id)` -> `{schema_version, kind: "snowflake_query_audit", generated_at, conversion_id,
  summary, records}`; `build_query_audit_xlsx` (openpyxl): sheets Summary, Queries (one column per record field, status-coloured,
  wrapped SQL/filters; filter text `T.C op values [source]`; tables `model -> physical`; "SQL logging is off" when not logged) and
  Filters (one row per request/visual filter with its source label: slicer, cross filter, page filter, report filter).
- Endpoints: `GET /query-audit?source=&page=&history_for=&kind=` -> `{records, summary}`;
  `GET /query-audit/export?format=xlsx|json&source=&page=&status=&search=&kind=` (download, same filters as the screen). 404 for
  unknown conversions.

## 2. Edit SQL (hand-edited pane SQL) - `services/sql_overrides.py`
- Stored in `<conversion>/sql_overrides.json` keyed `"<page>/<visual>"`:
  `{page, visual, sql (trimmed, trailing ; removed), base_sql, saved_at, saved_by}`; atomic writes.
- `validate_sql(sql)`: non-empty; after leading comments must start with SELECT or WITH ("only a SELECT or WITH query can replace a
  pane's SQL"); only one statement (semicolons outside strings/comments -> "only one SQL statement is allowed"); placeholders only
  `{{filters}}` and `{{filters:<Model Table>}}` ("unknown placeholder {{x}}", "{{filters:<table>}} needs a model table name").
- `render(sql, filters, engine) -> (sql, unapplied_tables)`: each filter becomes `engine.filter_predicate(f)` = (quoted table alias,
  predicate spelled exactly like generated SQL); `{{filters}}` = AND of all predicates whose alias appears in the SQL (outside
  placeholders), `{{filters:T}}` only table T's (case-insensitive); nothing -> `1=1`; filters whose alias isn't in the SQL are
  reported, never guessed.
- `null_comparison_warnings(sql)` (outside strings/comments): `NOT IN (NULL)`, `NOT IN (NULL, ...)`, `IN (NULL, ...)`, `<> NULL`/`!= NULL`,
  `= NULL`, each with the fix text (e.g. "`col <> NULL` is never true: use `col IS NOT NULL`"). Edited SQL is never rewritten.
- In `run_batch_query`, `_apply_sql_overrides` replaces the planned MAIN query of an edited visual (also rescues plan errors), rendered
  with the request's slicer/cross filters (and default report/page filters, phase 10), `execution_path="manual_sql"`, no compat
  fallback; title/drill/totals keep generated SQL. Audit records get `sql_override=True` and `unapplied_filters`.
- Endpoints:
  - `GET /sql-editor?page=&visual=` -> `{page, visual, pane, base_sql (visual's own query, no slicers) | base_error, expected_columns
    (dim_keys + column_keys + series_keys + measure_keys, deduped), filter_tables: [{table, alias}] (the visual's dimension tables,
    for untranslated panes the tables of "Table.Column" dim keys, plus every slicer target table on the page), override}`; 404 unknown visual.
  - `POST /sql-overrides/test {page, visual, connection_id, sql, filters: FilterClause[]}`: render (422 on render errors), run on
    Snowflake, return `{rendered_sql, unapplied_filter_tables, has_filters_placeholder, null_comparison_warnings, expected_columns,
    columns, rows (first N preview rows), row_count, elapsed_ms, query_id, error, missing_columns}`; logged as kind `setup`,
    check "sql edit test".
  - `GET /sql-overrides` -> `{overrides: [...]}`; `PUT /sql-overrides {page, visual, sql}` (422 invalid) -> `{override}` (stores the
    current generated SQL as base_sql); `DELETE /sql-overrides/{page}/{visual}` -> `{deleted: true}` or 404 "no edited SQL for this pane".
- Spec: a saved edit sets `VisualSpec.manual_sql` on untranslated panes (applied in the cached compile, keyed on the mtime of
  `sql_overrides.json`), so the front end requests them and `_apply_sql_overrides` runs the edit.

## 3. No SQL generated
- Untranslated panes (`data_status="untranslated"`, `supported=False`, `query=None`) keep `VisualSpec.draft_query` (the query that
  would have run) for display.
- `GET /no-sql-panes` -> `{panes: [{page, page_name, visual, pane, visual_type, measure (from "measure [X] needs tier-2"), reason,
  expected_columns, manual_sql (bool), saved_at}]}`.
- `GET /no-sql-panes/{page}/{visual}` (422 "this pane has generated SQL" for translated panes) -> `{page, visual, pane, dax_query,
  dax_query_error, measures: [{name, table, dax, rewrite, error, dependencies: [{name, table, dax, rewrite, translated}]}]}` for each
  draft measure that doesn't compile (tier-2 SQL counts as translated), dependencies via `dependency_closure`.
- `dax/visual_query.py::visual_dax_query(query, title)`: Performance-Analyzer-style DAX: `// <title>`, `DEFINE VAR __DS0FilterTable
  = TREATAS(...)`/`FILTER(...)` for each visual filter, `EVALUATE SUMMARIZECOLUMNS(<columns>, <filter vars>, "<name>", <measure or
  AGG('T'[c])>)` (measure-value filters via an outer FILTER on the measure), `ORDER BY ...`. Quoting: tables `'...'` with `''`,
  columns `[...]` with `]]`, strings `"..."` with `""`. Aggregates: sum SUM, avg/average AVERAGE, min, max, distinctcount, count/countnonnull
  COUNTA. Slicer selections are not part of it.

## 4. Re-check this pane
`POST /recheck {page, visual, connection_id}` (404 without `conversion_run.json`: "no conversion run yet; POST /convert first"):
validate one pane on an audited connection (`kind=validation`, extra `{recheck: true, sql_override}`) with the default report/page
filters (phase 10); with a saved edit, render it with only those defaults and pass it as `main_sql` (render errors -> a failed
`execute` check "edited SQL: ..."). Set `rechecked_at`; under a file lock replace that pane's entry in `conversion_run.json`'s
fidelity report (`_replace_visual_score`, append if new), recompute the summary merged into the previous summary, write atomically.
Response `{visual: {...score, status, score}, previous_status, summary: {overall_score, previous_overall_score, visuals_passed,
visuals_total}, used_edited_sql}`.

## 5. Fix measure (hand-written measure SQL)
- Stored in `SemanticModel.measure_sql[measure] = ManualMeasureSql` (bundle.json, so every compile uses it).
- Compiler: wherever the measure is referenced without CALCULATE modifiers it emits a native token (tier 3, `compiler_type
  "manual_sql"`); referenced under modifiers -> DaxUnsupported naming the parent. Engine `_native_measure_sql`: renders the SQL with the
  query's filters via `sql_overrides.render` as a scalar subquery; queries with dimensions are refused ("... hand-written SQL ... one
  value per query"). Dependents and panes compile through it.
- `POST /measure-sql/test {measure, sql, connection_id}`: validate (422); compute impact by compiling a candidate bundle with the fix
  (and the spec overrides): `newly_translated`, `still_untranslated_measures`, `fixed_panes`, `still_untranslated` (with reasons),
  `not_applicable` (panes grouping by rows); run the SQL (rendered without filters) on an audited connection (kind `setup`, context
  `measure_sql_test:<m>`): exactly one row with one column, a number or text (dates/bools refused: "must return a number or text (got
  date)"; shape error "must return exactly one row with one column (got N row(s), M column(s))"); then run up to 12 fixed panes' queries.
  `ok` when all succeed; remember `(conversion, measure) -> (sql, checked lines)` in memory. Response `{ok, measure, measure_run {sql,
  value, query_id, error}, pane_runs [{page, visual, pane, rows, query_id, error}], panes_not_run, null_comparison_warnings, ...impact}`.
- `PUT /measure-sql {measure, sql}`: only the exact text of the last passing check, else 409 "run 'Check on Snowflake' on this exact SQL
  before saving"; saves `ManualMeasureSql(sql, original=DAX, saved_at, checked)`, clears the result cache and the remembered check.
- `GET /measure-sql` -> `{fixes}`; `DELETE /measure-sql/{measure}` -> `{reverted, remaining}` or 404.

## 6. DAX Audit
- `GET /compilation-audit` -> records + summary from the compilation log (phase 07), overlaid with the current model
  (`_audit_with_current_model`): measures with hand-written SQL show `compiler_type="manual_sql"`; broken rows are recompiled against
  the current model and shown working when they compile now.
- `GET /compilation-audit/export?format=xlsx|json` (download).

## 7. Frontend (Review step tabs "DAX Audit" and "Snowflake queries")
- `ReviewStep.tsx` adds tabs `['compilation', 'DAX Audit']`, `['queries', 'Snowflake queries', '<n> failed' badge]`, renders
  `AiRewrites` + `CompilationAudit` on the DAX Audit tab and `QueryAudit` on the Snowflake queries tab, with cross-links (a measure link in
  the query audit opens the DAX Audit filtered with exact match; "open the Snowflake query audit on the panes using this measure").
  Migration Health rows get a compact `RecheckButton` (column header sr-only "Re-check") and, when re-checked, a small
  "re-checked[ · edited SQL]" marker with the time in its title. The summary shows "Data visuals passing n/m" (from `data_visuals_*`,
  phase 07) when present, else "Visuals passing". The "Snowflake queries" tab badge = `error + plan_error` from
  `GET /query-audit?source=all`.
- `steps/QueryAudit.tsx`: kind selector (`aria-label="Query kind"`: Dashboard, Totals, Drill, Conversion checks, Setup, All, with
  counts), a "No SQL generated" tab (shown even when nothing ran), summary cards (Queries, Panes, OK, 0 rows, Errors, Not built, Cache hits,
  Slowest, Average, Warehouse / role), search (`matchesQuerySearch`: page, pane, table, measure, SQL, query id...), page filter,
  status filter, source (Editor / Published / Editor + published), "Download Excel" / "Download JSON" (export with the current filters),
  table with Warehouse/role columns; expanded row (`data-testid="query-detail"`): drill step, error ("Not built:" for plan_error), SQL /
  fallback SQL blocks with copy buttons, "Edit SQL" (only for a pane's main query: dashboard rows or validation `main` checks; other
  kinds explain why: "Setup queries are not a pane’s query, so they can’t be edited." / "This query belongs to the conversion run’s checks,
  not to a pane, so it can’t be edited." / "Only a pane’s main query can be edited; open the pane in the Dashboard view or its “main”
  check."), "Re-check this pane", filters from slicers/cross-filters, filters on this visual, tables read, measures (links "Open in
  DAX Audit"), warehouse/role/connection, Snowflake query ID with "Copy history lookup", "Show run history" (`data-testid="query-history"`).
  When SQL logging is off say so; empty log explains how to populate it.
- No SQL generated panel (`data-testid="no-sql-panes"`): search, page filter, table (page, pane, visual type, untranslated measure,
  reason), per pane "Edit SQL", "Re-check", DAX Audit link, and expandable DAX (`data-testid="no-sql-pane-dax"`): "Visual DAX query
  (without slicer selections)", per measure "Why it wasn’t translated", "Accepted AI rewrite", dependencies with Translated / Not
  translated badges.
- `steps/SqlEditor.tsx` (`data-testid="sql-editor"`): textarea `aria-label="Edited SQL"`, generated SQL, expected columns, available
  `{{filters}}` tables; "Run" (disabled without a connection: "Select a Snowflake connection first") shows `TestResult`
  (`data-testid="sql-test-result"`: rows, columns, missing columns, unapplied filter tables, `null-comparison-warnings`); "Save" enabled
  only after a successful run of the exact current text with every expected column ("Run the current SQL successfully first"); "Revert to
  generated SQL" for saved edits; saving/reverting invalidates the spec (manual_sql flags).
- `steps/RecheckButton.tsx` (`data-testid="recheck"`, compact variant "Re-check"): disabled without a connection ("Connect to Snowflake
  first"); "Re-checking…"; result (`data-testid="recheck-result"`) with checks and the score change; refreshes Migration Health; shows the
  sign-in message on 409/authentication errors.
- `steps/CompilationAudit.tsx`: summary cards (Success rate, Total measures, Working, Degraded, Broken, per tier, Avg DAX/SQL
  complexity), compilation breakdown, search "Filter by measure or table…" with an "Exact match" toggle (on when opened from a query-audit
  measure link), status/tier badges (Working, Degraded, Broken, Tier 0/1, Tier 2 (AI), Parked, Manual SQL), Download Excel/JSON, expandable
  rows (compile/SQL/validation errors, DAX expression, generated SQL, leaf aggregates) and `MeasureSqlFix` per measure.
- `steps/MeasureSqlFix.tsx`: "Fix measure" / "Edit measure SQL", textarea `aria-label="Measure SQL"`, "Check on Snowflake" ("Checking…",
  needs a connection: "Select a Snowflake connection to check."), impact lists (fixed panes, "Measures still not translated: ...", not
  applicable panes, null-comparison warnings), Save (only the checked text), Revert.

## Files
Create: `backend/app/services/query_audit.py`, `services/sql_overrides.py`, `dax/visual_query.py`,
`frontend/src/steps/QueryAudit.tsx`, `SqlEditor.tsx`, `RecheckButton.tsx`, `MeasureSqlFix.tsx`, `CompilationAudit.tsx`.
Modify: `api/dashboards.py`, `api/published_dashboards.py` (published `/query` logs `source="published"`), `runtime/engine.py`
(`filter_predicate`, `table_alias`, `_annotate_sql`, native measure SQL), `dax/compiler.py`, `runtime/dashboard.py` (`draft_query`,
`manual_sql`), `steps/ReviewStep.tsx`, `api/types.ts`.

## Tests
Backend: `test_query_audit.py` (audit fields; errors and cache hits; no SQL text when logging is off; latest run per pane with readable
names; legacy events; capped newest-first; xlsx/json exports; totals record; drill logged; audited connection labels each execution;
validation queries audited with their visual; parse_context; 404), `test_sql_overrides.py` (valid/invalid SQL; null warnings; `{{filters}}`
without filters is `1=1`; renders engine predicates; table placeholder and unreferenced tables; edited SQL replaces generated and follows
slicers; test endpoint reports missing columns; editor payload and rejections), `test_recheck.py` (generated SQL updates scorecard; uses
edited SQL; invalid edit fails execute with reason; default page filters applied; 404s), `test_no_sql_panes.py` (lists untranslated
only; editor offers category tables; saved SQL makes the pane query; validate/run_validation/convert/recheck use edited SQL for
untranslated panes only; standalone packages the edited template; draft query kept; pane details DAX; rejects translated panes),
`test_measure_sql.py` (fixed measure + dependents use the SQL; filters reach it; own tier; CALCULATE-modifier parent refused; grouping
refused; check reports impact and runs panes; save requires a passing check of the exact text; revert restores; one-number rule; text
accepted, dates refused; DAX audit shows the fix), `test_dax_visual_query.py` (columns/filters/measures/sort; card; quoting; measure
filters).
Frontend: `queryAudit.test.tsx`, `sqlEditor.test.tsx`, `recheck.test.tsx`, `compilationAudit.test.tsx` with the behaviours above
(summary + rows, status/search filters, expanded detail, not-built panes and DAX Audit link, exports with current filters, SQL logging
off, kind selector passes kind to the export, drill rows, No SQL generated tab, empty log; Save only after a successful run, missing
columns/error block saving, revert; recheck POST + score change, disabled without connection, sign-in message, validation main rows
offer Edit SQL, totals/setup rows explain; exact-match measure links, check-then-save, text values).

## Done criteria
All tests above pass; the Snowflake queries tab shows a run's dashboard queries end to end on a fake connection.
 