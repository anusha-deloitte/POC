import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { DashboardApp } from '../dashboard/DashboardApp'
import { cardResults, FakeResizeObserver, json, standaloneSpec } from './standaloneFixtures'

const config = { baseUrl: '/api/v1/published', token: 'tok', published: true }

interface World {
  signedIn: boolean
  connection: Record<string, unknown>
  session: Record<string, unknown>
  authResult: Record<string, unknown>
  calls: { method: string; path: string; body: Record<string, unknown> | null; auth: string | null }[]
  queryCount: number
}

let world: World

function installFetch() {
  vi.stubGlobal(
    'fetch',
    vi.fn(async (url: string, init?: RequestInit) => {
      const path = String(url).replace(config.baseUrl, '')
      const method = init?.method ?? 'GET'
      const body = init?.body ? JSON.parse(String(init.body)) : null
      const auth = (init?.headers as Record<string, string> | undefined)?.Authorization ?? null
      world.calls.push({ method, path, body, auth })
      if (path === '/dashboard/spec') return json(standaloneSpec())
      if (path === '/dashboard/accelerate') return json({ hydrated: false, available: false })
      if (path === '/dashboard/query') {
        world.queryCount += 1
        if (!world.signedIn)
          return json(
            { detail: { code: 'snowflake_authentication_required', message: 'Sign in to Snowflake', mfa_required: false } },
            409,
          )
        return json(cardResults())
      }
      if (path === '/session') return json({ ...world.session, authenticated: world.signedIn })
      if (path === '/connection' && method === 'GET') return json(world.connection)
      if (path === '/connection' && method === 'PUT') return json({ change: 'reconnect' })
      if (path === '/session/authenticate') {
        if ((world.authResult as { ok: boolean }).ok) world.signedIn = true
        return json(world.authResult)
      }
      if (path === '/connection/secrets') return json({ ok: true })
      return json({}, 404)
    }),
  )
}

function renderStandalone() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <DashboardApp conversionId="standalone" connectionId="standalone" apiConfig={config} variant="standalone" />
    </QueryClientProvider>,
  )
}

const panel = () => screen.findByRole('dialog', { name: 'Connection settings' })

beforeEach(() => {
  world = {
    signedIn: true,
    connection: { account: 'acme', user: 'ann', auth_method: 'password', role: 'R', warehouse: 'WH', database: 'DB', schema: 'S', remember: false, saved_secrets: [] },
    session: { auth_method: 'password', account: 'acme', user: 'ann', role: 'R', warehouse: 'WH', signing_in: false },
    authResult: { ok: true },
    calls: [],
    queryCount: 0,
  }
  vi.stubGlobal('ResizeObserver', FakeResizeObserver)
  installFetch()
})
afterEach(() => vi.restoreAllMocks())

describe('standalone shell', () => {
  it('shows the report with a status bar and page tabs, without converter chrome', async () => {
    renderStandalone()
    const bar = await screen.findByTestId('standalone-topbar')
    expect(within(bar).getByText('Sales report')).toBeTruthy()
    await waitFor(() => expect(screen.getByTestId('snowflake-status').textContent).toBe('Connected · ann · R · WH'))
    const tabs = screen.getByRole('navigation', { name: 'Report pages' })
    expect(within(tabs).getAllByRole('button').map((b) => b.textContent)).toEqual(['Overview', 'Details'])
    expect(screen.queryByText(/Converted from Power BI/)).toBeNull()
    expect(screen.queryByRole('navigation', { name: 'Pages' })).toBeNull()
    // the service has no extract: no Live / Accelerated toggle
    await waitFor(() => expect(world.calls.some((c) => c.path === '/dashboard/accelerate')).toBe(true))
    expect(screen.queryByRole('button', { name: 'Live' })).toBeNull()
    expect(world.calls.every((c) => c.auth === null || c.auth === 'Bearer tok')).toBe(true)
    expect(world.calls.find((c) => c.path === '/session')?.auth).toBe('Bearer tok')
  })

  it('opens the sign-in panel on a 409 and reloads the data after sign-in', async () => {
    world.signedIn = false
    renderStandalone()
    const dialog = await panel()
    await waitFor(() => expect(screen.getByTestId('snowflake-status').textContent).toBe('Snowflake sign-in required'))
    const before = world.queryCount
    await userEvent.type(within(dialog).getByLabelText('Password'), 'pw')
    await userEvent.click(within(dialog).getByRole('button', { name: 'Save & sign in' }))
    await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull())
    const put = world.calls.find((c) => c.method === 'PUT' && c.path === '/connection')!
    expect(put.body).toMatchObject({ account: 'acme', user: 'ann', auth_method: 'password', secrets: { password: 'pw' }, remember: false })
    await waitFor(() => expect(world.queryCount).toBeGreaterThan(before))
    await waitFor(() => expect(screen.getByTestId('snowflake-status').textContent).toMatch(/^Connected/))
  })

  it('opens from the bar and offers every authentication method with its own secret fields', async () => {
    renderStandalone()
    await userEvent.click(await screen.findByRole('button', { name: 'Connection settings' }))
    const dialog = await panel()
    const method = await within(dialog).findByLabelText('Authentication method')
    const expected: Record<string, string[]> = {
      password: ['Password'],
      key_pair: ['Private key (PEM)', 'Private key passphrase'],
      oauth_client_credentials: ['OAuth client ID', 'OAuth token URL', 'OAuth client secret'],
      pat: ['Programmatic access token'],
      external_browser: [],
    }
    const all = ['Password', 'Private key (PEM)', 'Private key passphrase', 'OAuth client secret', 'Programmatic access token', 'OAuth client ID']
    for (const [value, labels] of Object.entries(expected)) {
      await userEvent.selectOptions(method, value)
      for (const label of all) {
        if (labels.includes(label)) expect(within(dialog).getByLabelText(label)).toBeTruthy()
        else expect(within(dialog).queryByLabelText(label)).toBeNull()
      }
      expect(within(dialog).getByRole('button', { name: value === 'external_browser' ? 'Save & authenticate' : 'Save & sign in' })).toBeTruthy()
    }
  })

  it('shows a held secret as saved and never renders its value', async () => {
    world.connection = { ...world.connection, auth_method: 'pat', remember: true, saved_secrets: ['pat_token'], pat_token: 'SHOULD-NOT-APPEAR' }
    renderStandalone()
    await userEvent.click(await screen.findByRole('button', { name: 'Connection settings' }))
    const dialog = await panel()
    expect(await within(dialog).findByTestId('saved-pat_token')).toBeTruthy()
    expect((within(dialog).getByLabelText(/Programmatic access token/) as HTMLInputElement).value).toBe('')
    expect(document.body.innerHTML).not.toContain('SHOULD-NOT-APPEAR')
    await userEvent.click(within(dialog).getByRole('button', { name: 'Save & sign in' }))
    await waitFor(() => expect(world.calls.some((c) => c.method === 'PUT')).toBe(true))
    // empty secret fields keep the held value: nothing is sent
    expect(world.calls.find((c) => c.method === 'PUT')!.body!.secrets).toEqual({})
  })

  it('password logins take the MFA code up front', async () => {
    renderStandalone()
    await userEvent.click(await screen.findByRole('button', { name: 'Connection settings' }))
    const dialog = await panel()
    await userEvent.type(await within(dialog).findByLabelText('MFA code (optional)'), '123456')
    await userEvent.click(within(dialog).getByRole('button', { name: 'Save & sign in' }))
    await waitFor(() => expect(world.calls.find((c) => c.path === '/session/authenticate')?.body).toEqual({ passcode: '123456' }))
  })

  it('asks for the MFA code when the service requires it', async () => {
    world.signedIn = false
    world.authResult = { ok: false, error: 'MFA required', mfa_required: true }
    renderStandalone()
    const dialog = await panel()
    await userEvent.click(await within(dialog).findByRole('button', { name: 'Save & sign in' }))
    const prompt = await within(dialog).findByTestId('mfa-prompt')
    world.authResult = { ok: true }
    await userEvent.type(within(prompt).getByLabelText('MFA code'), '654321')
    await userEvent.click(within(prompt).getByRole('button', { name: 'Sign in' }))
    await waitFor(() => expect(screen.queryByRole('dialog')).toBeNull())
    const auths = world.calls.filter((c) => c.path === '/session/authenticate')
    expect(auths[auths.length - 1].body).toEqual({ passcode: '654321' })
  })

  it('browser SSO waits for the user and links the sign-in page', async () => {
    world.signedIn = false
    world.connection = { ...world.connection, auth_method: 'external_browser' }
    world.session = { ...world.session, auth_method: 'external_browser', signing_in: true, sso_url: 'https://sso.example/login' }
    let release: () => void = () => undefined
    const inner = (globalThis.fetch as unknown as (u: string, i?: RequestInit) => Promise<Response>).bind(globalThis)
    vi.stubGlobal(
      'fetch',
      vi.fn(async (u: string, i?: RequestInit) => {
        if (String(u).endsWith('/session/authenticate')) await new Promise<void>((r) => (release = r))
        return inner(u, i)
      }),
    )
    renderStandalone()
    const dialog = await panel()
    await userEvent.click(await within(dialog).findByRole('button', { name: 'Save & authenticate' }))
    expect(await within(dialog).findByText(/Complete sign-in in the browser/)).toBeTruthy()
    await waitFor(() =>
      expect((within(dialog).getByRole('link', { name: 'Open the sign-in page' }) as HTMLAnchorElement).href).toBe('https://sso.example/login'),
    )
    expect(screen.getByTestId('snowflake-status').textContent).toBe('Signing in to Snowflake…')
    release()
  })

  it('reports an expired session with Sign in again', async () => {
    world.signedIn = false
    world.session = { ...world.session, last_error: 'Snowflake session expired' }
    world.queryCount = 0
    world.connection = { ...world.connection }
    // a data query that does not 409, so only the session status says it is expired
    renderStandalone()
    await waitFor(() => expect(screen.getByTestId('snowflake-status').textContent).toBe('Snowflake session expired'))
  })
})
