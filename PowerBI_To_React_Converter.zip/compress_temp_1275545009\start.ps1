<#
.SYNOPSIS
  One-command setup + run for PBI Converter: installs every backend/frontend
  dependency (uv sync --all-extras --all-groups, npm install), then starts
  both servers as detached background processes.

.PARAMETER SkipInstall
  Skip the dependency-install step and go straight to starting the servers.

.PARAMETER InstallOnly
  Install dependencies only; do not start the servers.

.PARAMETER Reload
  Run uvicorn with --reload (note: a reload signs every Snowflake session out).

.EXAMPLE
  ./start.ps1
.EXAMPLE
  ./start.ps1 -SkipInstall
#>
[CmdletBinding()]
param(
    [switch]$SkipInstall,
    [switch]$InstallOnly,
    [switch]$Reload,
    [int]$ApiPort = 8000,
    [int]$WebPort = 5173
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$backend = Join-Path $root 'backend'
$frontend = Join-Path $root 'frontend'
$logDir = Join-Path $root 'logs'
$pidFile = Join-Path $root '.dev-pids.json'
$venvPython = Join-Path $backend '.venv\Scripts\python.exe'
$stopScript = Join-Path $root 'stop.ps1'

function Test-CommandExists {
    param([string]$Name)
    return $null -ne (Get-Command $Name -ErrorAction SilentlyContinue)
}

function Test-Http {
    param([string]$Url)
    try {
        $req = [System.Net.HttpWebRequest]::Create($Url)
        $req.Proxy = $null
        $req.Timeout = 2000
        $resp = $req.GetResponse()
        $resp.Close()
        return $true
    } catch [System.Net.WebException] {
        # any HTTP status (404, 500, ...) means the server is up; close the error response
        $resp = $_.Exception.Response
        if ($resp) { $resp.Close(); return $true }
        return $false
    } catch {
        return $false
    }
}

function Wait-ForHttp {
    param([string[]]$Urls, [int]$TimeoutSec = 40, $Process = $null)
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        foreach ($u in $Urls) { if (Test-Http $u) { return $true } }
        if ($Process -and $Process.HasExited) { return $false }
        Start-Sleep -Milliseconds 500
    }
    return $false
}

function Show-LogTail {
    param([string]$Path, [int]$Lines = 25)
    if (Test-Path $Path) {
        Write-Host "--- last $Lines lines of $Path ---" -ForegroundColor DarkGray
        Get-Content $Path -Tail $Lines | ForEach-Object { Write-Host $_ }
    }
}

function Quote-Arg {
    param([string]$Value)
    if ($Value -match '[\s&|<>^()"]') { return '"' + $Value.Replace('"', '\"') + '"' }
    return $Value
}

function Start-Detached {
    param([string]$Command, [string[]]$Arguments, [string]$WorkingDirectory, [string]$OutLog, [string]$ErrLog)
    $parts = @((Quote-Arg $Command)) + @($Arguments | ForEach-Object { Quote-Arg $_ })
    $line = ($parts -join ' ') + " 1>`"$OutLog`" 2>`"$ErrLog`" <NUL"
    return Start-Process -FilePath 'cmd.exe' -ArgumentList @('/d', '/s', '/c', "`"$line`"") `
        -WorkingDirectory $WorkingDirectory -WindowStyle Hidden -PassThru
}

function Get-PortOwner {
    param([int]$Port)
    $c = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($c) { return [int]$c.OwningProcess }
    return $null
}

Write-Host "== PBI Converter ==" -ForegroundColor Cyan

if (-not (Test-CommandExists 'uv')) {
    Write-Error "uv is not on PATH. Install it: https://docs.astral.sh/uv/getting-started/installation/"
    exit 1
}
if (-not (Test-CommandExists 'node') -or -not (Test-CommandExists 'npm')) {
    Write-Error "Node.js/npm not found on PATH. Install Node 20+: https://nodejs.org/"
    exit 1
}

if (-not $SkipInstall) {
    try { & $stopScript -ApiPort $ApiPort -WebPort $WebPort | Out-Null } catch { Write-Warning "stop.ps1 reported a problem: $_" }

    Write-Host "-> backend: uv sync --all-extras --all-groups" -ForegroundColor Yellow
    Push-Location $backend
    try {
        if (-not (Test-Path (Join-Path $backend '.venv'))) { uv venv }
        $ok = $false
        for ($attempt = 1; $attempt -le 3 -and -not $ok; $attempt++) {
            uv sync --all-extras --all-groups --system-certs
            if ($LASTEXITCODE -eq 0) { $ok = $true } else {
                Write-Warning "uv sync failed (attempt $attempt/3)"
                Start-Sleep -Seconds (3 * $attempt)
            }
        }
        if (-not $ok) {
            throw "uv sync failed. If the output above says 'Access is denied', a tool that scans backend\.venv (antivirus, OneDrive, indexers) is holding files open; pause it and run ./start.ps1 again."
        }
    } finally {
        Pop-Location
    }
    Write-Host "   note: the 'sources' extra installs pyodbc's Python driver only." -ForegroundColor DarkGray
    Write-Host "   Migrating FROM SQL Server also needs Microsoft's 'ODBC Driver 17/18" -ForegroundColor DarkGray
    Write-Host "   for SQL Server' installed at the OS level -- that part is not on PyPI." -ForegroundColor DarkGray

    Write-Host "-> frontend: npm install" -ForegroundColor Yellow
    Push-Location $frontend
    try {
        npm install
        if ($LASTEXITCODE -ne 0) { throw "npm install failed with exit code $LASTEXITCODE" }
    } finally {
        Pop-Location
    }
    Write-Host "Install complete." -ForegroundColor Green
}

if ($InstallOnly) { exit 0 }

# never `uv run` (re-syncs, fails behind TLS-inspecting proxies) and never uvicorn.exe (uv trampoline breaks under OneDrive paths)
if (-not (Test-Path $venvPython)) {
    Write-Error "backend\.venv is missing; run ./start.ps1 without -SkipInstall first."
    exit 1
}
# Windows PowerShell 5.1 turns a native stderr line into a terminating error under
# $ErrorActionPreference = 'Stop' even with 2>$null, so relax it for this probe only
$previousPreference = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
try { & $venvPython -c "import uvicorn" 2>$null } catch { $global:LASTEXITCODE = 1 }
$uvicornExit = $LASTEXITCODE
$ErrorActionPreference = $previousPreference
if ($uvicornExit -ne 0) {
    Write-Error "uvicorn is not importable from backend\.venv; run ./start.ps1 without -SkipInstall."
    exit 1
}

foreach ($port in @($ApiPort, $WebPort)) {
    if (Get-PortOwner $port) {
        & $stopScript -ApiPort $ApiPort -WebPort $WebPort | Out-Null
        break
    }
}
foreach ($port in @($ApiPort, $WebPort)) {
    $owner = Get-PortOwner $port
    if ($owner) {
        Write-Error "Port $port is in use by pid $owner and could not be freed."
        exit 1
    }
}

New-Item -ItemType Directory -Force -Path $logDir | Out-Null
Write-Host "== starting ==" -ForegroundColor Cyan

$apiOut = Join-Path $logDir 'api.out.log'
$apiErr = Join-Path $logDir 'api.err.log'
$apiArgs = @('-m', 'uvicorn', 'app.main:app', '--host', '127.0.0.1', '--port', "$ApiPort")
if ($Reload) { $apiArgs += '--reload' }
$apiProc = Start-Detached -Command $venvPython -Arguments $apiArgs -WorkingDirectory $backend -OutLog $apiOut -ErrLog $apiErr

Write-Host "-> API starting on :$ApiPort (pid $($apiProc.Id))"
if (-not (Wait-ForHttp -Urls @("http://127.0.0.1:$ApiPort/healthz") -TimeoutSec 120 -Process $apiProc)) {
    Write-Warning "API did not report healthy in time."
    Show-LogTail $apiErr
    & $stopScript -ApiPort $ApiPort -WebPort $WebPort | Out-Null
    exit 1
}

$env:PBIC_API_URL = "http://127.0.0.1:$ApiPort"
$webOut = Join-Path $logDir 'web.out.log'
$webErr = Join-Path $logDir 'web.err.log'
$webProc = Start-Detached -Command 'npm.cmd' -Arguments @('run', 'dev', '--', '--port', "$WebPort") -WorkingDirectory $frontend -OutLog $webOut -ErrLog $webErr

Write-Host "-> Web starting on :$WebPort (pid $($webProc.Id))"
if (-not (Wait-ForHttp -Urls @("http://127.0.0.1:$WebPort", "http://[::1]:$WebPort") -TimeoutSec 60 -Process $webProc)) {
    Write-Warning "Web did not report ready in time."
    Show-LogTail $webErr
}

@{ api = $apiProc.Id; web = $webProc.Id } | ConvertTo-Json | Set-Content -Path $pidFile -Encoding utf8

Write-Host ""
Write-Host "  Studio:   http://localhost:$WebPort" -ForegroundColor Green
Write-Host "  API docs: http://127.0.0.1:$ApiPort/docs" -ForegroundColor Green
Write-Host "  Raw logs: $logDir"
Write-Host "  Stop:     ./stop.ps1"
