import { ChevronDown, Search } from 'lucide-react'
import { useCallback, useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { createPortal } from 'react-dom'

export interface SelectOption {
  value: string
  label: string
}

export interface SearchableSelectProps {
  options: SelectOption[]
  value: string | null | undefined
  onChange: (value: string) => void
  ariaLabel: string
  /** plural noun for the footer: "N of M <itemLabel>" */
  itemLabel?: string
  placeholder?: string
  searchPlaceholder?: string
  disabled?: boolean
  className?: string
}

const ZERO_WIDTH = /[​-‍⁠﻿]/g
const MAX_LIST_HEIGHT = 260
const POPUP_HEIGHT = MAX_LIST_HEIGHT + 90 // list + search box + footer

/** Lower-case, drop zero-width characters, collapse whitespace. */
export function normalizeText(text: string): string {
  return text.replace(ZERO_WIDTH, '').replace(/\s+/g, ' ').trim().toLowerCase()
}

/** Every typed word must appear in the label, in any order. */
export function matchesWords(label: string, query: string): boolean {
  const words = normalizeText(query).split(' ').filter(Boolean)
  if (!words.length) return true
  const hay = normalizeText(label)
  return words.every((w) => hay.includes(w))
}

/** Split a label into plain / matched segments for bolding. */
export function highlightSegments(label: string, query: string): { text: string; hit: boolean }[] {
  const text = label.replace(ZERO_WIDTH, '').replace(/\s+/g, ' ')
  const words = normalizeText(query).split(' ').filter(Boolean)
  if (!words.length) return [{ text, hit: false }]
  const lower = text.toLowerCase()
  const marks = new Array<boolean>(text.length).fill(false)
  for (const w of words) {
    let at = lower.indexOf(w)
    while (at !== -1) {
      for (let i = at; i < at + w.length && i < marks.length; i++) marks[i] = true
      at = lower.indexOf(w, at + 1)
    }
  }
  const out: { text: string; hit: boolean }[] = []
  for (let i = 0; i < text.length; i++) {
    const last = out[out.length - 1]
    if (last && last.hit === marks[i]) last.text += text[i]
    else out.push({ text: text[i], hit: marks[i] })
  }
  return out
}

interface Placement {
  left: number
  width: number
  top?: number
  bottom?: number
  up: boolean
}

export function SearchableSelect({
  options,
  value,
  onChange,
  ariaLabel,
  itemLabel = 'items',
  placeholder = 'Select…',
  searchPlaceholder = 'Type to search…',
  disabled,
  className = '',
}: SearchableSelectProps) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const [active, setActive] = useState(0)
  const [place, setPlace] = useState<Placement | null>(null)
  const buttonRef = useRef<HTMLButtonElement>(null)
  const popupRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const uid = useId()
  const listId = `${uid}-list`

  const filtered = useMemo(() => options.filter((o) => matchesWords(o.label, query)), [options, query])
  const selected = options.find((o) => o.value === value)

  const close = useCallback((refocus = true) => {
    setOpen(false)
    setQuery('')
    if (refocus) buttonRef.current?.focus()
  }, [])

  const reposition = useCallback(() => {
    const btn = buttonRef.current
    if (!btn) return
    const rect = btn.getBoundingClientRect()
    const below = window.innerHeight - rect.bottom
    const above = rect.top
    const up = below < POPUP_HEIGHT && above > below
    setPlace(
      up
        ? { left: rect.left, width: rect.width, bottom: window.innerHeight - rect.top + 4, up }
        : { left: rect.left, width: rect.width, top: rect.bottom + 4, up },
    )
  }, [])

  useLayoutEffect(() => {
    if (!open) return
    reposition()
    // capture: scrolling any ancestor moves the button
    window.addEventListener('scroll', reposition, true)
    window.addEventListener('resize', reposition)
    return () => {
      window.removeEventListener('scroll', reposition, true)
      window.removeEventListener('resize', reposition)
    }
  }, [open, reposition])

  useEffect(() => {
    if (!open) return
    const onDown = (e: MouseEvent) => {
      const t = e.target as Node
      if (buttonRef.current?.contains(t) || popupRef.current?.contains(t)) return
      close(false)
    }
    document.addEventListener('mousedown', onDown)
    return () => document.removeEventListener('mousedown', onDown)
  }, [open, close])

  const placed = place !== null
  useEffect(() => {
    if (open && placed) inputRef.current?.focus()
  }, [open, placed])

  // keep the active row valid and visible
  useEffect(() => {
    setActive((a) => Math.min(a, Math.max(filtered.length - 1, 0)))
  }, [filtered.length])
  useEffect(() => {
    if (!open) return
    const el = popupRef.current?.querySelector<HTMLElement>(`[data-index="${active}"]`)
    el?.scrollIntoView?.({ block: 'nearest' })
  }, [active, open])

  const openList = () => {
    if (disabled) return
    const idx = filtered.findIndex((o) => o.value === value)
    setActive(idx >= 0 ? idx : 0)
    setOpen(true)
  }

  const choose = (opt: SelectOption) => {
    onChange(opt.value)
    close()
  }

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setActive((a) => Math.min(a + 1, Math.max(filtered.length - 1, 0)))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setActive((a) => Math.max(a - 1, 0))
    } else if (e.key === 'Enter') {
      e.preventDefault()
      const opt = filtered[active]
      if (opt) choose(opt)
    } else if (e.key === 'Escape') {
      e.preventDefault()
      e.stopPropagation()
      close()
    } else if (e.key === 'Tab') {
      close(false)
    }
  }

  const optionId = (i: number) => `${uid}-opt-${i}`

  return (
    <>
      <button
        ref={buttonRef}
        type="button"
        role="combobox"
        aria-label={ariaLabel}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={open ? listId : undefined}
        disabled={disabled}
        onClick={() => (open ? close() : openList())}
        onKeyDown={(e) => {
          if (!open && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
            e.preventDefault()
            openList()
          }
        }}
        className={`input flex items-center justify-between gap-2 text-left ${className}`}
      >
        <span className={`min-w-0 flex-1 truncate ${selected ? '' : 'text-surface-400'}`}>
          {selected ? selected.label.replace(ZERO_WIDTH, '') : placeholder}
        </span>
        <ChevronDown size={14} strokeWidth={1.8} className="shrink-0 text-surface-500" />
      </button>

      {open &&
        place &&
        createPortal(
          <div
            ref={popupRef}
            data-testid="searchable-select-popup"
            data-placement={place.up ? 'up' : 'down'}
            style={{
              position: 'fixed',
              left: place.left,
              width: Math.max(place.width, 220),
              top: place.top,
              bottom: place.bottom,
              zIndex: 1000,
            }}
            className="overflow-hidden rounded-lg border border-surface-300 bg-white text-sm shadow-xl"
          >
            <div className="flex items-center gap-2 border-b border-surface-200 px-2.5 py-2">
              <Search size={13} strokeWidth={1.8} className="shrink-0 text-surface-500" />
              <input
                ref={inputRef}
                type="text"
                role="searchbox"
                aria-label={`Search ${itemLabel}`}
                aria-controls={listId}
                aria-activedescendant={filtered.length ? optionId(active) : undefined}
                autoComplete="off"
                spellCheck={false}
                value={query}
                placeholder={searchPlaceholder}
                onChange={(e) => {
                  setQuery(e.target.value)
                  setActive(0)
                }}
                onKeyDown={onKeyDown}
                className="min-w-0 flex-1 bg-transparent text-xs outline-none"
              />
            </div>
            <ul
              id={listId}
              role="listbox"
              aria-label={ariaLabel}
              style={{ maxHeight: MAX_LIST_HEIGHT }}
              className="overflow-y-auto py-1"
            >
              {filtered.map((o, i) => (
                <li
                  key={o.value}
                  id={optionId(i)}
                  role="option"
                  data-index={i}
                  aria-selected={o.value === value}
                  onMouseDown={(e) => e.preventDefault()}
                  onMouseEnter={() => setActive(i)}
                  onClick={() => choose(o)}
                  className={`cursor-pointer px-3 py-1.5 text-xs ${
                    i === active ? 'bg-brand/10' : ''
                  } ${o.value === value ? 'font-semibold text-brand-dark' : 'text-surface-800'}`}
                >
                  {highlightSegments(o.label, query).map((seg, k) =>
                    seg.hit ? (
                      <strong key={k} data-testid="match">
                        {seg.text}
                      </strong>
                    ) : (
                      <span key={k}>{seg.text}</span>
                    ),
                  )}
                </li>
              ))}
              {filtered.length === 0 && (
                <li role="presentation" className="px-3 py-2 text-xs text-surface-500">
                  No {itemLabel} match “{query}”
                </li>
              )}
            </ul>
            <div className="border-t border-surface-200 bg-surface-100 px-3 py-1.5 text-[10px] text-surface-500">
              {filtered.length} of {options.length} {itemLabel}
            </div>
          </div>,
          document.body,
        )}
    </>
  )
}
