export interface SparklineProps {
  /** oldest first; null = no value for that run */
  values: (number | null | undefined)[]
  width?: number
  height?: number
  label?: string
  /** digits for the delta text */
  digits?: number
}

/** Small SVG trend line with a last-value delta ("▲ 3.5" / "▼ 1.2"). */
export function Sparkline({ values, width = 80, height = 22, label = 'trend', digits = 1 }: SparklineProps) {
  const points = values
    .map((v, i) => ({ v: typeof v === 'number' && Number.isFinite(v) ? v : null, i }))
    .filter((p): p is { v: number; i: number } => p.v !== null)

  if (points.length === 0) {
    return (
      <span data-testid="sparkline-empty" className="text-surface-400" aria-label={`${label}: no data`}>
        —
      </span>
    )
  }

  const pad = 3
  const lo = Math.min(...points.map((p) => p.v))
  const hi = Math.max(...points.map((p) => p.v))
  const span = hi - lo || 1
  const n = Math.max(values.length - 1, 1)
  const x = (i: number) => (values.length <= 1 ? width / 2 : pad + (i / n) * (width - pad * 2))
  const y = (v: number) => (hi === lo ? height / 2 : pad + (1 - (v - lo) / span) * (height - pad * 2))

  // break the line at gaps (null values)
  const segments: { v: number; i: number }[][] = []
  let run: { v: number; i: number }[] = []
  values.forEach((raw, i) => {
    if (typeof raw === 'number' && Number.isFinite(raw)) run.push({ v: raw, i })
    else if (run.length) {
      segments.push(run)
      run = []
    }
  })
  if (run.length) segments.push(run)

  const last = points[points.length - 1]
  const prev = points.length > 1 ? points[points.length - 2] : null
  const delta = prev ? last.v - prev.v : null
  const rounded = delta === null ? null : Number(Math.abs(delta).toFixed(digits))
  const arrow = delta === null || rounded === 0 ? null : delta > 0 ? '▲' : '▼'

  return (
    <span className="inline-flex items-center gap-1.5 align-middle" data-testid="sparkline">
      <svg
        role="img"
        aria-label={`${label}: ${points.map((p) => p.v).join(', ')}`}
        width={width}
        height={height}
        viewBox={`0 0 ${width} ${height}`}
        className="text-brand-dark"
      >
        {segments
          .filter((seg) => seg.length > 1)
          .map((seg, k) => (
            <polyline
              key={k}
              fill="none"
              stroke="currentColor"
              strokeWidth={1.5}
              strokeLinejoin="round"
              points={seg.map((p) => `${x(p.i).toFixed(1)},${y(p.v).toFixed(1)}`).join(' ')}
            />
          ))}
        <circle data-testid="sparkline-last" cx={x(last.i)} cy={y(last.v)} r={2.2} fill="currentColor" />
      </svg>
      {arrow && rounded !== null && (
        <span
          data-testid="sparkline-delta"
          className={`text-[11px] font-semibold tabular-nums ${
            arrow === '▲' ? 'text-brand-dark' : 'text-brand-red'
          }`}
        >
          {arrow} {rounded}
        </span>
      )}
    </span>
  )
}
