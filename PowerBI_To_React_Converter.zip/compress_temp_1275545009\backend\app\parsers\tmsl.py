"""TMSL (JSON: model.bim / SSMS .xmla scripts) -> TMDL.

The TMDL parser is the only model reader: a TMSL model is converted into a TMDL
`definition/` folder first, so there is a single code path. Calculation groups,
perspectives, cultures and object-level security are skipped.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from app.parsers.tmdl import TmdlParseError

_IDENT = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")
_UNSAFE_FILE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_CMDS = ("createOrReplace", "create", "alter")


def load_tmsl(path: Path) -> dict:
    """Read a TMSL file and return the database object (with a `model` member)."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (OSError, ValueError) as e:
        raise TmdlParseError(f"cannot read TMSL file: {e}", str(path)) from e
    if not isinstance(data, dict):
        raise TmdlParseError("TMSL root must be a JSON object", str(path))
    for cmd in _CMDS:
        if cmd in data:
            body = data[cmd]
            if isinstance(body, dict) and isinstance(body.get("database"), dict):
                return body["database"]
            raise TmdlParseError(f"TMSL '{cmd}' command has no database object", str(path))
    if isinstance(data.get("model"), dict):
        return data
    if isinstance(data.get("tables"), list):
        return {"name": data.get("name"), "model": data}
    raise TmdlParseError("no TMSL database/model found", str(path))


def _q(name: str) -> str:
    if _IDENT.match(name):
        return name
    return "'" + name.replace("'", "''") + "'"


def _text(value: Any) -> str:
    if isinstance(value, list):
        return "\n".join(str(v) for v in value)
    return "" if value is None else str(value)


def _fenced(prefix: str, indent: int, body: Any) -> list[str]:
    pad = "\t" * indent
    lines = _text(body).splitlines() or [""]
    body = [f"{pad}\t{ln}" if ln.strip() else "" for ln in lines]
    return [f"{pad}{prefix} = ```", *body, f"{pad}\t```"]


def _description(obj: dict, indent: int) -> list[str]:
    desc = obj.get("description")
    if not desc:
        return []
    pad = "\t" * indent
    return [f"{pad}/// {ln.strip()}" for ln in _text(desc).splitlines() if ln.strip()]


def _props(indent: int, items: list[tuple[str, Any]]) -> list[str]:
    pad = "\t" * indent
    out: list[str] = []
    for key, val in items:
        if val is None or val == "":
            continue
        if val is True:
            out.append(f"{pad}{key}")
        elif val is False:
            continue
        else:
            out.append(f"{pad}{key}: {val}")
    return out


def _annotations(obj: dict, indent: int) -> list[str]:
    pad = "\t" * indent
    return [
        f"{pad}annotation {_q(str(a['name']))} = {_text(a.get('value')).replace(chr(10), ' ')}"
        for a in obj.get("annotations", [])
        if a.get("name")
    ]


def _column(col: dict) -> list[str]:
    if col.get("type") == "rowNumber" or str(col.get("name", "")).startswith("RowNumber-"):
        return []
    out = _description(col, 1)
    head = f"column {_q(col['name'])}"
    if col.get("type") == "calculated" and col.get("expression") is not None:
        out += _fenced(head, 1, col["expression"])
    else:
        out.append(f"\t{head}")
    out += _props(
        2,
        [
            ("dataType", col.get("dataType")),
            ("formatString", col.get("formatString")),
            ("lineageTag", col.get("lineageTag")),
            ("sourceColumn", col.get("sourceColumn")),
            ("sortByColumn", _q(col["sortByColumn"]) if col.get("sortByColumn") else None),
            ("summarizeBy", col.get("summarizeBy")),
            ("isHidden", bool(col.get("isHidden"))),
            ("isKey", bool(col.get("isKey"))),
        ],
    )
    out += _annotations(col, 2)
    return out


def _measure(m: dict) -> list[str]:
    out = _description(m, 1)
    out += _fenced(f"measure {_q(m['name'])}", 1, m.get("expression"))
    out += _props(
        2,
        [
            ("formatString", m.get("formatString")),
            ("displayFolder", m.get("displayFolder")),
            ("lineageTag", m.get("lineageTag")),
            ("isHidden", bool(m.get("isHidden"))),
        ],
    )
    out += _annotations(m, 2)
    return out


def _hierarchy(h: dict) -> list[str]:
    out = [f"\thierarchy {_q(h['name'])}"]
    out += _props(2, [("lineageTag", h.get("lineageTag")), ("isHidden", bool(h.get("isHidden")))])
    for lv in h.get("levels", []):
        out.append(f"\t\tlevel {_q(lv.get('name', ''))}")
        out += _props(
            3,
            [
                ("ordinal", lv.get("ordinal", 0)),
                ("column", _q(lv["column"]) if lv.get("column") else None),
            ],
        )
    return out


def _partition(p: dict) -> list[str]:
    source = p.get("source") or {}
    ptype = source.get("type") or "m"
    out = [f"\tpartition {_q(p.get('name', 'Partition'))} = {ptype}"]
    out += _props(2, [("mode", p.get("mode"))])
    body = source.get("expression") if source.get("expression") is not None else source.get("query")
    if body is not None:
        out += _fenced("source", 2, body)
    return out


def _table(t: dict) -> str:
    out = _description(t, 0)
    out.append(f"table {_q(t['name'])}")
    out += _props(1, [("lineageTag", t.get("lineageTag")), ("isHidden", bool(t.get("isHidden")))])
    for c in t.get("columns", []):
        out += _column(c)
    for m in t.get("measures", []):
        out += _measure(m)
    for h in t.get("hierarchies", []):
        out += _hierarchy(h)
    for p in t.get("partitions", []):
        out += _partition(p)
    out += _annotations(t, 1)
    return "\n".join(out) + "\n"


def _relationship(r: dict) -> list[str]:
    name = r.get("name") or f"{r.get('fromTable')}_{r.get('toTable')}"
    out = [f"relationship {_q(name)}"]
    out += _props(
        1,
        [
            ("isActive", None if r.get("isActive", True) else "false"),
            ("crossFilteringBehavior", r.get("crossFilteringBehavior")),
            ("securityFilteringBehavior", r.get("securityFilteringBehavior")),
            ("fromCardinality", r.get("fromCardinality")),
            ("toCardinality", r.get("toCardinality")),
            ("fromColumn", f"{_q(r['fromTable'])}.{_q(r['fromColumn'])}"),
            ("toColumn", f"{_q(r['toTable'])}.{_q(r['toColumn'])}"),
        ],
    )
    return out


def _role(role: dict) -> str:
    out = _description(role, 0)
    out.append(f"role {_q(role['name'])}")
    out += _props(1, [("modelPermission", role.get("modelPermission"))])
    for tp in role.get("tablePermissions", []):
        if tp.get("filterExpression") is not None:
            out += _fenced(f"tablePermission {_q(tp['name'])}", 1, tp["filterExpression"])
        else:
            out.append(f"\ttablePermission {_q(tp['name'])}")
    return "\n".join(out) + "\n"


def _file_name(name: str, used: set[str]) -> str:
    base = _UNSAFE_FILE.sub("_", name) or "_"
    candidate, n = base, 1
    while candidate.casefold() in used:
        n += 1
        candidate = f"{base}_{n}"
    used.add(candidate.casefold())
    return candidate


def write_tmdl_from_tmsl(db: dict, definition_dir: Path) -> None:
    """Write `db` (a TMSL database object) as a TMDL `definition/` folder."""
    model = db.get("model")
    if not isinstance(model, dict):
        raise TmdlParseError("TMSL database has no model object")
    definition_dir = Path(definition_dir)
    (definition_dir / "tables").mkdir(parents=True, exist_ok=True)

    db_name = db.get("name") or model.get("name") or "Model"
    db_lines = [f"database {_q(str(db_name))}"]
    db_lines += _props(1, [("compatibilityLevel", db.get("compatibilityLevel"))])
    (definition_dir / "database.tmdl").write_text("\n".join(db_lines) + "\n", encoding="utf-8")

    model_lines = [f"model {_q(str(model.get('name') or 'Model'))}"]
    model_lines += _props(1, [("culture", model.get("culture"))])
    model_lines += _annotations(model, 1)
    (definition_dir / "model.tmdl").write_text("\n".join(model_lines) + "\n", encoding="utf-8")

    exprs = model.get("expressions") or []
    if exprs:
        lines: list[str] = []
        for e in exprs:
            lines += _fenced(f"expression {_q(e['name'])}", 0, e.get("expression"))
            lines += _props(
                1, [("lineageTag", e.get("lineageTag")), ("queryGroup", e.get("queryGroup"))]
            )
        (definition_dir / "expressions.tmdl").write_text("\n".join(lines) + "\n", encoding="utf-8")

    used: set[str] = set()
    for t in model.get("tables", []):
        fname = _file_name(t["name"], used)
        (definition_dir / "tables" / f"{fname}.tmdl").write_text(_table(t), encoding="utf-8")

    rels = model.get("relationships") or []
    if rels:
        text = "\n".join("\n".join(_relationship(r)) + "\n" for r in rels)
        (definition_dir / "relationships.tmdl").write_text(text, encoding="utf-8")

    roles = model.get("roles") or []
    if roles:
        (definition_dir / "roles").mkdir(exist_ok=True)
        used_roles: set[str] = set()
        for role in roles:
            fname = _file_name(role["name"], used_roles)
            (definition_dir / "roles" / f"{fname}.tmdl").write_text(_role(role), encoding="utf-8")
