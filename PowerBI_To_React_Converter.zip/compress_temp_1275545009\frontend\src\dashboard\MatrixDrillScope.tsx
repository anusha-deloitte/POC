import type { ReactNode } from 'react'
import { MatrixDrillContext, useMatrixDrillState } from './drill'
import { useReport } from './reportContext'
import type { FilterClause } from './types'

/** Gives a collapsed matrix its +/- row expansion (children come from the drill endpoint). */
export function MatrixDrillScope({
  page,
  visual,
  filters,
  children,
}: {
  page: string
  visual: string
  filters: FilterClause[]
  children: ReactNode
}) {
  const { conversionId, connectionId, apiConfig } = useReport()
  const drill = useMatrixDrillState({
    conversionId,
    connectionId: connectionId ?? '',
    page,
    visual,
    filters,
    apiConfig,
  })
  return <MatrixDrillContext.Provider value={drill}>{children}</MatrixDrillContext.Provider>
}
