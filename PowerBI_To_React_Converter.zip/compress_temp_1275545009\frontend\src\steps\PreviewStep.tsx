import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { api } from '../api/client'
import { fetchDashboardSpec } from '../dashboard/api'
import { DashboardApp } from '../dashboard/DashboardApp'
import { useWizard } from '../store/wizard'

const dashboardUrl = (conversionId: string, connectionId: string) =>
  `${window.location.origin}${window.location.pathname}#/dashboard/${conversionId}/${connectionId}`

export function PreviewStep() {
  const queryClient = useQueryClient()
  const conversionId = useWizard((s) => s.conversionId)
  const connectionId = useWizard((s) => s.connectionId)
  const spec = useQuery({
    queryKey: ['dash-spec', conversionId],
    queryFn: () => fetchDashboardSpec(conversionId!),
    enabled: !!conversionId,
  })
  const publications = useQuery({
    queryKey: ['dashboard-publications'],
    queryFn: api.listDashboardPublications,
  })
  const download = useMutation({
    mutationFn: () => api.exportDashboard(conversionId!, connectionId!),
    onSuccess: async (blob) => {
      const href = URL.createObjectURL(blob)
      const anchor = document.createElement('a')
      anchor.href = href
      anchor.download = `${spec.data?.report_name ?? 'dashboard'}-dashboard.zip`
      anchor.click()
      URL.revokeObjectURL(href)
      await queryClient.invalidateQueries({ queryKey: ['dashboard-publications'] })
    },
  })
  const downloadStandalone = useMutation({
    mutationFn: () => api.exportDashboard(conversionId!, connectionId!, 'standalone'),
    onSuccess: ({ blob, filename }) => {
      const href = URL.createObjectURL(blob)
      const anchor = document.createElement('a')
      anchor.href = href
      anchor.download = filename
      anchor.click()
      URL.revokeObjectURL(href)
    },
  })
  const rotate = useMutation({
    mutationFn: (id: string) => api.rotateDashboardPublication(id),
    onSuccess: async (issued) => {
      const config = {
        api_base: '/api/v1/published',
        publication_id: issued.publication.id,
        token: issued.token,
      }
      const href = URL.createObjectURL(
        new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' }),
      )
      const anchor = document.createElement('a')
      anchor.href = href
      anchor.download = 'dashboard-config.json'
      anchor.click()
      URL.revokeObjectURL(href)
      await queryClient.invalidateQueries({ queryKey: ['dashboard-publications'] })
    },
  })
  const revoke = useMutation({
    mutationFn: (id: string) => api.revokeDashboardPublication(id),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['dashboard-publications'] })
    },
  })

  if (!conversionId) return <p className="text-surface-500">No conversion selected.</p>
  if (!connectionId) return <p className="text-surface-500">No Snowflake connection selected.</p>
  if (spec.isLoading) return <p className="text-surface-500">Compiling dashboard…</p>
  if (spec.isError)
    return (
      <div role="alert" className="rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
        {spec.error.message}
      </div>
    )

  return (
    <section className="max-w-none">
      <div className="mb-3 flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">{spec.data!.report_name}</h2>
          <p className="text-xs text-surface-500">Live against Snowflake</p>
        </div>
        <div className="flex items-center gap-2">
          <a
            href={dashboardUrl(conversionId, connectionId)}
            target="_blank"
            rel="noreferrer"
            className="rounded-[10px] border border-brand px-3 py-1.5 text-xs font-semibold text-brand-dark hover:bg-brand/10"
          >
            Open full dashboard ↗
          </a>
          <button
            type="button"
            disabled={download.isPending}
            onClick={() => download.mutate()}
            className="rounded-[10px] bg-brand px-3 py-1.5 text-xs font-semibold text-white hover:bg-brand-dark"
          >
            {download.isPending ? 'Preparing export…' : 'Download React code ⬇'}
          </button>
          <button
            type="button"
            disabled={downloadStandalone.isPending}
            onClick={() => downloadStandalone.mutate()}
            className="rounded-[10px] border border-brand px-3 py-1.5 text-xs font-semibold text-brand-dark hover:bg-brand/10"
          >
            {downloadStandalone.isPending ? 'Preparing package…' : 'Download standalone dashboard ⬇'}
          </button>
        </div>
      </div>
      {(publications.data ?? []).some(
        (publication) =>
          publication.conversion_id === conversionId && publication.revoked_at == null,
      ) && (
        <div className="mb-3 flex flex-wrap items-center gap-2 text-xs text-surface-600">
          {(publications.data ?? [])
            .filter(
              (publication) =>
                publication.conversion_id === conversionId && publication.revoked_at == null,
            )
            .map((publication) => (
              <div key={publication.id} className="flex items-center gap-2 rounded-lg border border-surface-300 px-3 py-2">
                <span>
                  Token {publication.token_fingerprint} · expires{' '}
                  {new Date(publication.expires_at * 1000).toLocaleDateString()}
                </span>
                <button
                  type="button"
                  className="font-semibold text-brand-dark underline"
                  disabled={rotate.isPending}
                  onClick={() => rotate.mutate(publication.id)}
                >
                  Rotate
                </button>
                <button
                  type="button"
                  className="font-semibold text-brand-red underline"
                  disabled={revoke.isPending}
                  onClick={() => revoke.mutate(publication.id)}
                >
                  Revoke
                </button>
              </div>
            ))}
        </div>
      )}
      {downloadStandalone.isError && (
        <div role="alert" className="mb-3 rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
          {downloadStandalone.error.message}
        </div>
      )}
      <DashboardApp conversionId={conversionId} connectionId={connectionId} compact />
    </section>
  )
}
