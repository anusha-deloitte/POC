# Phase 06 - DAX parser, tier-1 compiler and SQL engine

## Purpose
Translate many more real DAX patterns deterministically (tier 1) with Power BI's exact semantics,
and make compilation and execution fast. This is the largest phase: split it into the numbered
sub-steps below and finish each one (tests green) before the next.

## Current target state
`dax/parser.py` (Lark Earley grammar, no `IN`, no table constructors, no comments, no cache);
`dax/compiler.py` (`MeasureCompiler`, ~700 lines: aggregates, CALCULATE with simple filters, DIVIDE, IF,
SWITCH, time intelligence basics); `runtime/engine.py` (`SemanticEngine.build_sql(QuerySpec)` ->
CTE-per-fact SQL, compat path); `semantic/yaml_compiler.py`; `runtime/semantic_view.py`.

## Ground rules for this phase
- Every behaviour below must be proven on DuckDB with hand-computed numbers (generated Snowflake SQL ->
  `runtime/accelerate.to_duckdb_sql` -> DuckDB). Build small in-memory fixtures in each test (model IR + tables).
- "Refused" means: raise `DaxUnsupported` (compile time) or `QueryPlanError` (query time) with a message that
  names the construct and the reason. Never guess a number.
- The compiler is not thread-safe; only query execution is parallel.

## 6.1 Parser (`dax/parser.py`)
- `x IN {a, b, ...}` -> `BinOp("IN", left, TableCtor(values))`; `IN` keyword is case-insensitive and excluded from
  TABLE_IDENT / FUNC_NAME / NAME lookaheads (identifiers that merely start with "In" still parse).
- Table constructor `{v1, v2}` as a primary expression and as a function argument -> `TableCtor(values)`.
- Quoted table names may contain `''` (`'Member''s Data'` -> `Member's Data`).
- `TRUE`, `TRUE()`, `TRUE ( )`, `FALSE...`, `BLANK ( )` all accepted (spaces inside the parentheses);
  `BLANK()` with no args becomes the `Blank` node even when parsed as a function call.
- Comments: `strip_comments(text)` removes `//`, `--` (to end of line) and `/* */` outside string literals
  (`""` escape), quoted names (`''` escape) and `[...]` brackets, before parsing. (`-- x` inside CALCULATE must
  not be read as two minus signs.) The grammar also ignores `/* */`.
- Parse cache: in-memory dict (max 50,000 entries, cleared when full, under a lock) + disk cache under
  `<storage_dir>/../cache/dax/<k[:2]>/<k>.json` with `k = sha256(grammar_version + "\0" + text)`, where
  `grammar_version = sha256(GRAMMAR + "|ast-v1")[:16]`. Files store `{grammar, text, ast | error}` as typed JSON
  (`{"t": ClassName, "f": {...}}`, tuples as `{"t":"tuple","v":[...]}`) - NEVER pickle; unknown type names, a
  different grammar/text, or corrupt files are cache misses. Writes are atomic (temp file + `os.replace`), and
  OSErrors are ignored. Parse errors are cached too and re-raised as new `DaxParseError`s.
  `set_parse_cache_dir(path, disabled=False)` (tests isolate/disable it; also clears memory).
  `warm_parse_cache(expressions)` parses each distinct uncached text once and returns how many were parsed.

## 6.2 Model-level behaviour
- Names resolve case-insensitively (phase 04 `_lookup`); DAX VAR names too (`_var_in`).
- `_exact_columns`: when the parser trims `[Rolling Period ]` but only the untrimmed name exists, use the model's
  exact name.
- `MeasureCompiler.compile_measure(name)` is memoized per compiler instance (successes and failures);
  the memo is invalidated when `model.dax_rewrites` changes. Treat `CompiledMeasure` as read-only.
  Compiling uses `model.effective_dax(measure)`.
- Parallel execution helper `app/core/parallel.py::run_parallel(fn, items, max_workers=None)`:
  `MAX_PARALLEL_QUERIES = max(1, int(env PBIC_MAX_PARALLEL_QUERIES or 8))`; workers = min(max, len(items)); <= 1
  runs inline; `ThreadPoolExecutor(thread_name_prefix="pbic-q")`; results in input order. Each query uses its own
  cursor of the same connection.

## 6.3 Blank and comparison semantics
- DAX `x <> BLANK()` -> `NOT ISBLANK(x)`; `x = BLANK()` / `x == BLANK()` -> `ISBLANK(x)` (either operand order),
  applied as an AST rewrite in the compiler and in `semantic/yaml_compiler.py`.
- DAX `IN` is strict and never BLANK: BLANK entries become `IS NULL`, the IN part is COALESCEd to FALSE, so
  `NOT (x IN {BLANK(), "UNK"})` keeps the rows DAX keeps.
- NULL-safe filter lists `engine.null_safe_in_sql(col, op, values, lit)` used by every filter renderer
  (engine `_filter_sql`, `_measure_filter_sql`, `semantic_view._filter_sql`):
  `not_in [NULL]` -> `col IS NOT NULL`; `not_in [NULL, v]` -> `(col IS NOT NULL AND col != v)`;
  `not_in [NULL, v1, v2]` -> `(col IS NOT NULL AND col NOT IN (v1, v2))`; `in [NULL, ...]` ->
  `(col IS NULL OR col IN (...))`; `eq NULL` -> `IS NULL`; `neq NULL` -> `IS NOT NULL`.
- Blank arithmetic: `+`/`-` with numeric operands use DAX blank arithmetic (`1 - BLANK() = 1`) via COALESCE, only
  when the operand is provably numeric (`_numeric`), never for dates/text.
- `_blank_safe`: DAX compares BLANK as 0/"" (`BLANK = 0` is TRUE) inside IF/SWITCH conditions.
- `&` / CONCATENATE: BLANK concatenates as empty text (`_concat_sql`), not NULL.

## 6.4 Newly supported functions / patterns (tier 1)
- Aggregates/iterators: `DISTINCTCOUNTNOBLANK`, `COUNTX`, `MINX/MAXX/SUMX/AVERAGEX` over `T`, `ALL(T)`,
  `FILTER(T | ALL(T), pred)`; two-level SUMX over `ADDCOLUMNS(SUMMARIZE(T, keys...), "n", CALCULATE(agg(T[c])))`
  with `[n]` (also when the summed column is a key) - directly or through a table VAR. A table VAR is
  materialized where it is defined: a CALCULATE around the iterator does not re-filter it.
- VARs are compiled lazily on first reference (`_Var`); unused (often table-valued) VARs never fail a measure;
  VARs referenced inside a row predicate are allowed only when they are whole-table scalars (`_row_var`).
- CALCULATE filters: `T[c] IN {..}`, `NOT(...)`, `KEEPFILTERS(pred)`, `FILTER(VALUES(T[c]) | DISTINCT(T[c]), pred)`,
  `FILTER(T | ALL(T), pred)`, `ALL(T)`, `ALL(T[c])`, `REMOVEFILTERS`, `ALLEXCEPT`, `TREATAS({literals}, T[c])`,
  `USERELATIONSHIP`. The keep-current-value idiom `T[c] = MAX(T[c])` (also MIN/SELECTEDVALUE/VALUES) inside
  `FILTER(ALL(T), ...)` keeps the current filter on c (`ctx.keeps`).
- Whole-table scalars inside row predicates (e.g. `CALCULATE(MAX(T[c]), ALL(T))`) compile to a scalar-subquery token
  expanded by the engine into an uncorrelated subquery over the table's physical binding. Bare cross-table
  `MAX/MIN("Other"."Col")` in WHERE predicates are rewritten to scalar subqueries (`_rewrite_cross_table_agg`).
- Scalars: `EDATE`, `INT`, `IFERROR(x, alt)` only when x can never raise (`_no_error`: no `/`, no VALUE; SQL raises on
  division by zero and TRY_CAST makes VALUE NULL, so IFERROR around them is refused) - except 6.8.
- `ISFILTERED(T | T[c])` / `ISCROSSFILTERED(...)`: filters added by an enclosing CALCULATE are known at compile time;
  query filters (slicers, visual rows) are resolved per query by the engine (ISF tokens -> TRUE/FALSE): a column is
  filtered when a filter or a dimension of the query is on it; cross-filtered when a query table's filters reach it
  through active relationships (one side reachable, or a bidirectional neighbour).
- `FIRSTNONBLANK(T[c], <constant>)` -> MIN (BLANK if any NULL); `LASTNONBLANK` -> MAX.

## 6.5 Per-query tokens: DATESBETWEEN windows, STARTOFYEAR (`__CTX`/`__ISF` tokens)
- `CALCULATE(m, ALL(D), DATESBETWEEN(D[c], lo, hi))` where lo/hi use `MIN/MAX(D[c])`, `STARTOFYEAR(D[c])`, `EDATE`,
  `SELECTEDVALUE`, `IF`, `VALUE`, `TRIM`: DAX evaluates the bounds in the outer (query) filter context, which only
  the engine knows. The compiler emits tokens; the engine renders each distinct token once as a CTE
  `"__ctxN" AS (SELECT <scalar> AS "v")` read as `(SELECT "v" FROM "__ctxN")`, merging into an existing WITH.
  The scalar is the aggregate over the bound's table filtered by the query's own filters on that table.
- STARTOFYEAR(anchor) -> `(SELECT MIN(c) FROM D WHERE YEAR(c) = YEAR(anchor) AND c <= anchor)`.
- PY variant: under an outer `DATEADD(D[c], n, unit)` / `SAMEPERIODLASTYEAR` with `ALL(D)` the bound reads the query's
  selected dates shifted point-to-point (`c IN (SELECT DATEADD(unit, n, c) FROM D WHERE <query filters on D>)`;
  units day/month/quarter/year).
- Nested windows (a window around measures that are themselves windowed): inner bounds read the date table inside the
  outer window (`CtxToken.window`), and the inner `ALL(D)` drops the incoming outer filters on D (Power BI shifts twice).
- Refused (QueryPlanError) when the date table is on the visual's rows/axis ("date-window bounds read the filter
  context of 'D', which is on this visual's rows/axis ...") or cross-filtered by another table of the query
  ("... which is cross-filtered by X in this query ..."), or when a bound table is filtered by the shifted date table.
  Also refused without `ALL(D)` in the same CALCULATE.

## 6.6 Grouped tables ("cap" measures)
`CALCULATETABLE(SUMMARIZE(T, cols), filters)` -> `GROUPBY(prev, keys..., "n", SUMX(CURRENTGROUP(), x))` levels ->
`CALCULATE(DISTINCTCOUNT(key) | COUNTROWS(...), FILTER(<grouped VAR>, cond))` compiles to a grouped leaf
(`GroupedPlan`; canonical names `k{i}` for SUMMARIZE column i, `g{level}_{n}` for level added columns). The engine
renders nested subqueries carrying the visual's grain: `SELECT DISTINCT <grain>, cols` (the fact = SUMMARIZE's
table, duplicate rows collapse) -> one GROUP BY per level -> `WHERE <cond>` -> the count per grain. The query's
outer context filters the summarized rows. Grouped and pre-grouped leaves are never semantic-view metrics.
Unsupported shapes are refused naming the shape.

## 6.7 TOPN as a CALCULATE filter
`TOPN(n, ADDCOLUMNS(SUMMARIZE(T, D[key]), "x", CALCULATE(agg)), [x], order)` (optionally inside CALCULATETABLE)
-> `TopnPlan` + `__TOPNn__` token expanded FIRST in the engine's `finalize()`: a top-level CTE `"__topnN"`
(`<ranking group SQL> QUALIFY RANK() OVER (ORDER BY x DESC|ASC) <= n`) and the filter
`D.key IN (SELECT key FROM "__topnN")` (NULL-safe: a BLANK key that TOPN kept stays). The CTE must be top level:
Snowflake can't evaluate window-bound scalar subqueries nested inside an IN-subquery ("Unsupported subquery type").
- Ties are kept (RANK). Ranking happens in the context where the table is defined; a CALCULATETABLE around a table
  VAR does NOT re-filter it (VARs are constants), around an inline table it does. Ascending order supported.
- All-ties case: ranked by a measure the key's table can't filter (no active relationship path; BFS over active
  relationships, many->one hops, both ways when bidirectional; refused with USERELATIONSHIP) -> every row ties ->
  `TopnPlan(all_rows=True)` with no QUALIFY; SUMMARIZE may read `FILTER(D, cond)`. A ranking the key CAN filter but
  that doesn't match the supported shape is refused.
- Refused for queries with dimensions (DAX re-ranks per row) and under a time shift.

## 6.8 IFERROR over VALUE(<slicer's selected text>)
When the IFERROR argument is `VALUE` of a slicer's selected text (TRIM / VAR / measure chain down to
`SELECTEDVALUE(T[c])` of a string column), it counts as non-raising. The compiler records
`value_assumptions` (column + the literals compared to it) and compiles the IFERROR to
`IFF(<VALUE would raise>, fallback, x)` where "would raise" = the per-query selection (read with the same bound
tokens) is non-blank, not a number, and not one of the compared literals (DAX text `=` is case-insensitive).
VALUE outside a slicer selection stays refused. (The Convert data check is phase 07.)

## 6.9 Combining subqueries and sort columns (`engine._combine`, `_frame_sql`, `_multi_dimension_sql`)
- Without a frame (several per-fact-table subqueries, e.g. an IF switch over several fact tables): subquery `q_i`
  FULL OUTER JOINs on the COALESCE of the keys of `q0..q_{i-1}` (not q0 alone, which duplicated cells); rows where
  every projected measure is NULL are dropped (SUMMARIZECOLUMNS semantics); `__sort_` columns are COALESCEd across
  subqueries. A single subquery is unchanged.
- With a frame (cell grid = cross join of per-table DISTINCT axes): all-blank cells dropped too.
- Each axis projects its sortByColumn as `MIN(sort) ... GROUP BY <value>` (also in `_multi_dimension_sql`): a sort
  column that isn't 1:1 with its value must not duplicate cells under DISTINCT.
- Table visuals with columns only (no measures): `_multi_dimension_sql` returns the distinct combinations that exist
  in the data, joined along active many->one relationships from the table that reaches every other column's table,
  with filters applied. Single-column slicer domains unchanged.

## 6.10 Visual-level filters and calculated columns
- `MeasureFilter {measure, op: eq|neq|in|not_in|gt|gte|lt|lte, values}` on `QuerySpec.measure_filters`: a visual
  filter on a measure's value ("Filters on this visual"), evaluated per grain row; the measure itself isn't projected.
- Calculated columns compile via the calc-column compiler (including `x IN {"a","b"}`), are projected in the
  physical subquery, can be grouped and distinct-counted. Untranslatable calculated columns are absent from the
  projection; any query referencing one fails at planning time naming the column and reason
  (`_check_untranslated_columns`) instead of Snowflake's opaque "invalid identifier".
- Column-name collisions between a table name and a column name get an internal alias `"__t_<table>"`
  (`_alias_of`, `_dealias` rewrites `"Table".` qualifiers idempotently).
- M renames/added columns: an AddColumn result renamed later is exposed as its expression under the final name;
  computed expressions using post-rename names are rewritten to the physical source columns (`_m_columns`).

## 6.11 QuerySpec / FilterClause (contract shared with phases 08-12)
```
FilterClause {table, column, values: list[str|int|float|bool|None], op="in",
              clauses: list[FilterClause] (operands of op="or"), params: dict, source: str|None}
QuerySpec {dimensions, measures: list[MeasureRefSpec], filters, measure_filters, sort, limit}
MeasureRefSpec {name | table+column+aggregate, alias}; key = alias or name or "agg(T.C)"
```
`source` (slicer | page_filter | report_filter | cross_filter | drillthrough | tooltip) is audit-only: never part
of the SQL; result caches are keyed on SQL. Ops beyond `in/not_in/eq/neq/gt/gte/lt/lte` are phase 10.
`finalize(sql, spec)` order: expand TOPN tokens, then per-query tokens, scalar subqueries, native measure SQL
(phase 08), then de-alias.

## 6.12 yaml_compiler / semantic views
`semantic/yaml_compiler.py` additionally supports: row-context iterators over related tables as correlated
aggregates (`SUMX(FILTER(Line, ...), Line[Amt])` -> `(SELECT SUM(...) FROM line WHERE line.fk = base.pk AND ...)`,
with sources TableRef | FILTER | ALL | RELATEDTABLE, nested), `LOOKUPVALUE`, `CONCATENATEX`, correlated subqueries
along relationship paths (BFS; many->one only for RELATED, both directions for RELATEDTABLE/iterators; only the
outermost WHERE correlates, intermediate hops are JOINs), and scalar functions ALL, AVERAGEX, COUNTX, CONTAINSSTRING,
DAYS, EDATE, EOMONTH, EXACT, FIND, INT, MAXX, MINX, MOD, NOW, POWER, QUOTIENT, REPLACE, REPT, ROUNDDOWN, ROUNDUP,
SEARCH, SELECTEDVALUE, SIGN, TODAY, TRUNC, UNICHAR, XOR, IFF; and the BLANK-comparison rewrite (6.3).
`runtime/semantic_view._filter_sql` uses `null_safe_in_sql` and `eq NULL -> IS NULL`.

## 6.13 Validation speed (`validation/harness.py`)
- `CachingCursor(cursor, cache)`: serves results by SQL text from a shared dict; anything not cached runs on the
  real cursor and is stored; a cached failure re-raises the same error (scores identical to sequential execution).
- `_prefetch`: before validating, build every visual's SQL sequentially, then execute distinct uncached queries up to
  8 at a time on sibling cursors of the same connection (no-op when the cursor can't open siblings, e.g. test fakes).
  The prefetch builds with the same `sql_context` labels as validation (`visual:<page>/<visual>:main`).
- `run_validation(spec, engine, cursor, bundle=None, result_cache=None, manual_sql=None)`: the cache is shared across
  repair rounds and probes of one run, so only visuals whose SQL changed re-execute.

## Files
Modify: `dax/parser.py`, `dax/compiler.py`, `runtime/engine.py`, `runtime/semantic_view.py`,
`semantic/yaml_compiler.py`, `validation/harness.py`, `ir/model.py`.
Create: `app/core/parallel.py`.

## Tests (DuckDB, hand-computed; recreate each list as a test module)
- `test_sliding_window.py`: card; no single period selected -> BLANK; grouped by another table; PY window; date on
  axis refused; requires ALL(D); card without filters; rows of a grouped visual filtered; slicer on the table; ALL
  inside CALCULATE; `1 - BLANK() = 1`; `1 - value`; nested window inner bounds see the outer window.
- `test_tier1_patterns.py`: table constructor as argument; two-level SUMX card and grouped; SUMX over SUMMARIZE with
  the summed column as key; VAR materialized where defined; case-insensitive measure reference; COUNTX; TREATAS
  literals; IFERROR over DIVIDE ok; IFERROR over `/` refused; NOT IN with BLANK; NOT IN keeps blank rows; IN BLANK.
- `test_grouped_measures.py`: members-at-cap card; groups-at-cap card; per visual row; outer context filters the
  summarized rows; combines with other measures; COUNTROWS over the filtered table; unsupported shapes named.
- `test_topn_filter.py`: top item; ties kept; VAR not re-filtered; inline table filters apply; ascending; per-row
  ranking refused; unsupported shapes named; key set is a top-level CTE.
- `test_topn_ties.py`: all-ties keeps every row and FIRSTNONBLANK is the first; unrelated filters/window change
  nothing; BLANK sorts first; a ranking the key can filter is refused.
- `test_iferror_value.py` (compiler part): translates and computes; offending selection returns the fallback; no
  selection takes no fallback; VALUE outside a slicer refused; assumption recorded with compared literals.
- `test_combine_groups.py`, `test_null_filters.py` (rules, rows match Power BI, measure filters, semantic view),
  `test_blank_comparisons.py` (AST rewrite, no `= NULL` in SQL, DuckDB values).
- `test_speed.py`: cached == uncached AST; disk round trip after clearing memory; parse errors cached; corrupt or
  foreign entries ignored; unknown node types never instantiated; warm parses once; memo same result; failures
  memoized; rewrite/revert invalidates memo; run_parallel order preserved and truly parallel; single item inline;
  validation scores identical to sequential; results and errors reused.
- `test_calc_column_in_and_visual_filters.py`: IN in calc columns (case-insensitive, nested in IF, identifiers
  starting with "In"); calc column SQL; IN as CALCULATE filter; projected and grouped; distinct count; measure filter
  keeps matching rows; untranslatable calc column fails with reason; visual measure + column filters; a TOPN visual
  filter is reported not silently ignored; count aggregate code 2 is distinct; sort on an aggregated column targets
  the measure alias.
- `test_dimension_only_tables.py`, `test_owner_availability.py` (ALL+keep idiom, VAR in row filter, context-dependent
  VAR stays unsupported, Not Available rows, ALL ignores month slicer keeps owner).
- Parser: comments removed outside literals; `--` inside CALCULATE isn't negation; spaced constant calls; trailing-space
  column keeps exact name.

## Done criteria
Every list above passes on DuckDB; the target's existing compiler/engine tests still pass; no Snowflake needed.
 