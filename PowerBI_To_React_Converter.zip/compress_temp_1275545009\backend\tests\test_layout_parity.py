"""Phase 09: visual mapping rules, query-side behaviours and the resources endpoint."""

from __future__ import annotations

import pytest

from app.runtime.dashboard import compile_dashboard
from tests.pbir_world import (
    PAGE,
    Report,
    column,
    lit,
    measure,
    projection,
    visual_json,
)
from tests.phase08 import BAR, CARD, FakeConn, World
from tests.test_api import client  # noqa: F401


@pytest.fixture()
def rep(tmp_path):
    return Report(tmp_path)


def _mproj(name: str, table: str = "Sales", **extra):
    return projection(measure(table, name), f"{table}.{name}", name, **extra)


def _cproj(table: str, name: str, **extra):
    return projection(column(table, name), f"{table}.{name}", name, **extra)


def test_chrome_visuals_have_no_query_and_are_drawn(rep):
    for name, vtype in (
        ("shp", "shape"), ("bshp", "basicShape"), ("img", "image"), ("btn", "actionButton"),
        ("bnav", "bookmarkNavigator"), ("pnav", "pageNavigator"),
    ):  # fmt: skip
        rep.add_visual(visual_json(name, vtype))
    _, spec = rep.compile()
    for name in ("shp", "bshp", "img", "btn", "bnav", "pnav"):
        v = rep.visual(spec, name)
        assert v.supported is True and v.query is None and v.data_status == "ok"
        assert v.pbir is not None


def test_unknown_custom_visual_keeps_layout_as_unsupported_type(rep):
    rep.add_visual(visual_json("custom1", "someCustomVisual123", x=40, y=50, width=300, height=120))
    _, spec = rep.compile()
    v = rep.visual(spec, "custom1")
    assert v.data_status == "unsupported_type" and v.supported is False
    assert (v.x, v.y, v.width, v.height) == (40, 50, 300, 120)
    assert v.pbir is not None


def test_kpi_card_is_recognised_by_its_object_signature(rep):
    rep.add_visual(
        visual_json(
            "kpi1",
            "kpiVisualGuid_1234",
            query_state={
                "Actual": {"projections": [_mproj("Total Sales")]},
                "Target": {"projections": [_mproj("Total Quantity")]},
            },
            objects={
                "kpiName": [{"properties": {"text": lit("'Revenue'")}}],
                "actual": [{"properties": {}}],
                "target1": [{"properties": {"decimalPlaces": lit("2L")}}],
            },
        )
    )
    _, spec = rep.compile()
    v = rep.visual(spec, "kpi1")
    assert v.visual_type == "kpiCard" and v.supported is True and v.data_status == "ok"
    assert [m.name for m in v.query.measures] == ["Total Sales", "Total Quantity"]


def test_100_percent_stacked_types_are_supported(rep):
    for name, vtype in (("hs", "hundredPercentStackedBarChart"), ("hc", "hundredPercentStackedColumnChart")):
        rep.add_visual(
            visual_json(
                name, vtype,
                query_state={
                    "Category": {"projections": [_cproj("Product", "Category")]},
                    "Series": {"projections": [_cproj("Customer", "Country")]},
                    "Y": {"projections": [_mproj("Total Sales")]},
                },
            )  # fmt: skip
        )
    _, spec = rep.compile()
    for name in ("hs", "hc"):
        v = rep.visual(spec, name)
        assert v.supported is True and v.query is not None
        assert v.series_keys == ["Customer.Country"]


def test_untranslated_measure_keeps_layout_and_a_draft_query(rep):
    bundle = rep.bundle()
    bundle.model.find_measure("Total Sales")[1].expression = "FOOBAR(1)"
    spec, _ = compile_dashboard(bundle)
    v = rep.visual(spec, CARD)
    assert v.data_status == "untranslated" and v.supported is False and v.query is None
    assert v.draft_query is not None and v.draft_query.measures[0].name == "Total Sales"
    assert (v.x, v.y) == (24, 24) or v.width > 0  # layout kept
    assert v.pbir is not None


def test_inactive_drill_levels_are_not_queried_and_matrix_expands(rep):
    def hier(level: str, active: bool):
        return {
            "field": {"HierarchyLevel": {
                "Expression": {"Hierarchy": {"Expression": {"SourceRef": {"Entity": "Date"}},
                                             "Hierarchy": "Calendar"}},
                "Level": level}},
            "queryRef": f"Date.Calendar.{level}", "nativeQueryRef": level, "active": active,
        }  # fmt: skip

    rep.add_visual(
        visual_json(
            "mx", "pivotTable",
            query_state={
                "Rows": {"projections": [hier("Year", True), hier("Quarter", False), hier("Month", False)]},
                "Values": {"projections": [_mproj("Total Sales")]},
            },
        )  # fmt: skip
    )
    _, spec = rep.compile()
    v = rep.visual(spec, "mx")
    assert [d.column for d in v.query.dimensions] == ["Year"]
    assert v.hierarchy["levels"] == ["Date.Year", "Date.Quarter", "Date.Month"]
    assert v.hierarchy["current_level"] == "Date.Year"
    assert v.hierarchy["expand_rows"] is True
    assert v.hierarchy["drill_enabled"] is True


def test_count_aggregate_code_2_is_a_distinct_count(rep):
    agg = {"Aggregation": {"Expression": column("Sales", "OrderKey"), "Function": 2}}
    rep.add_visual(
        visual_json(
            "orders", "card",
            query_state={"Values": {"projections": [
                {"field": agg, "queryRef": "CountNonNull(Sales.OrderKey)", "nativeQueryRef": "Orders"}]}},
        )  # fmt: skip
    )
    _, spec = rep.compile()
    m = rep.visual(spec, "orders").query.measures[0]
    assert (m.table, m.column, (m.aggregate or "").upper()) == ("Sales", "OrderKey", "DISTINCTCOUNT")


def test_measure_driven_title_becomes_a_title_query(rep):
    rep.add_visual(
        visual_json(
            "t1", "card",
            query_state={"Values": {"projections": [_mproj("Total Quantity")]}},
            container={"title": [{"properties": {"show": lit("true"), "text": {
                "expr": {"Measure": {"Expression": {"SourceRef": {"Entity": "Sales"}},
                                     "Property": "Total Sales"}}}}}]},
        )  # fmt: skip
    )
    rep.add_visual(
        visual_json(
            "b1", "actionButton",
            objects={"text": [{"properties": {"text": {"expr": {"Measure": {
                "Expression": {"SourceRef": {"Entity": "Sales"}}, "Property": "Total Sales"}}}}}]},
        )  # fmt: skip
    )
    _, spec = rep.compile()
    for name in ("t1", "b1"):
        v = rep.visual(spec, name)
        assert [m.name for m in v.title_query.measures] == ["Total Sales"]
    assert rep.visual(spec, "t1").title is None


def test_show_value_as_percent_of_grand_total(rep):
    left = measure("Sales", "Total Sales")
    arith = {"Arithmetic": {"Left": left, "Right": {"ScopedEval": {"Expression": left, "Scope": []}},
                            "Operator": 3}}  # fmt: skip
    rep.add_visual(
        visual_json(
            "pct", "clusteredBarChart",
            query_state={
                "Category": {"projections": [_cproj("Product", "Category")]},
                "Y": {"projections": [{"field": arith, "queryRef": "x", "nativeQueryRef": "Total Sales"}]},
            },
        )  # fmt: skip
    )
    _, spec = rep.compile()
    assert rep.visual(spec, "pct").measure_show_as == {"Total Sales": "percent_of_grand_total"}


def test_visual_filters_become_query_filters_and_force_compatibility(rep):
    in_us = {"Version": 2, "Where": [{"Condition": {"In": {"Values": [[{"Literal": {"Value": "'US'"}}]]}}}]}
    cmp_ = {"Where": [{"Condition": {"Comparison": {"ComparisonKind": 2, "Left": {},
                                                    "Right": {"Literal": {"Value": "3L"}}}}}]}
    measure_cmp = {"Where": [{"Condition": {"Comparison": {"ComparisonKind": 1, "Left": {},
                                                           "Right": {"Literal": {"Value": "100D"}}}}}]}
    topn = {"Version": 2, "Where": []}
    filters = {"filters": [
        {"name": "f1", "field": column("Customer", "Country"), "type": "Categorical", "filter": in_us},
        {"name": "f2", "field": column("Sales", "Quantity"), "type": "Advanced", "filter": cmp_},
        {"name": "f3", "field": measure("Sales", "Total Sales"), "type": "Advanced", "filter": measure_cmp},
        {"name": "f4", "field": column("Product", "Category"), "type": "TopN", "filter": topn},
    ]}  # fmt: skip
    rep.add_visual(
        visual_json(
            "flt", "clusteredBarChart",
            query_state={"Category": {"projections": [_cproj("Product", "Category")]},
                         "Y": {"projections": [_mproj("Total Sales")]}},
            filter_config=filters,
        )  # fmt: skip
    )
    _, spec = rep.compile()
    v = rep.visual(spec, "flt")
    assert [(f.table, f.column, f.op, f.values) for f in v.query.filters] == [
        ("Customer", "Country", "in", ["US"]),
        ("Sales", "Quantity", "gte", [3]),
    ]
    assert [(m.measure, m.op, m.values) for m in v.query.measure_filters] == [
        ("Total Sales", "gt", [100.0])
    ]
    assert v.options["semantic_force_compatibility"] is True
    assert any("flt: TOPN filter on Product.Category was not applied" in w for w in spec.warnings)


def test_sort_maps_to_output_columns_and_drops_unprojected_ones(rep):
    sort = [
        {"field": measure("Sales", "Total Sales"), "direction": "Descending"},
        {"field": column("Customer", "Country"), "direction": "Ascending"},  # not projected
        {"field": column("Product", "Category"), "direction": "Ascending"},
    ]
    rep.add_visual(
        visual_json(
            "srt", "clusteredBarChart",
            query_state={"Category": {"projections": [_cproj("Product", "Category")]},
                         "Y": {"projections": [_mproj("Total Sales")]}},
            sort=sort,
        )  # fmt: skip
    )
    _, spec = rep.compile()
    assert rep.visual(spec, "srt").query.sort == [
        {"key": "Total Sales", "direction": "Descending"},
        {"key": "Product.Category", "direction": "Ascending"},
    ]


def test_sort_on_an_aggregated_column_targets_the_implicit_measure_alias(rep):
    agg = {"Aggregation": {"Expression": column("Sales", "SalesAmount"), "Function": 0}}
    rep.add_visual(
        visual_json(
            "agg", "clusteredBarChart",
            query_state={"Category": {"projections": [_cproj("Product", "Category")]},
                         "Y": {"projections": [{"field": agg, "queryRef": "Sum(Sales.SalesAmount)",
                                                "nativeQueryRef": "Sum of SalesAmount"}]}},
            sort=[{"field": agg, "direction": "Descending"}],
        )  # fmt: skip
    )
    _, spec = rep.compile()
    q = rep.visual(spec, "agg").query
    assert q.sort == [{"key": q.measures[0].key, "direction": "Descending"}]


# ------------------------------------------------------------------ API behaviours


@pytest.fixture()
def world(client, contoso_pbip, monkeypatch):  # noqa: F811
    return World(client, contoso_pbip, monkeypatch)


def test_resources_endpoint_headers_and_rejections(world, tmp_path):
    from tests.pbir_world import Report as R

    # the uploaded conversion has no registered images
    assert world.client.get(world.url("resources/logo.png")).status_code == 404
    for bad in ("..%2F..%2Freport.json", ".hidden.png", "notes.txt"):
        assert world.client.get(world.url(f"resources/{bad}")).status_code == 404
    assert R  # keep import


def test_resources_endpoint_serves_registered_images(client, tmp_path, monkeypatch):  # noqa: F811
    from app.api.deps import get_ingest_service
    from app.main import app
    from tests.pbir_world import Report as R
    from tests.test_api import zip_folder

    monkeypatch.setattr(
        "app.api.dashboards.get_ingest_service", app.dependency_overrides[get_ingest_service]
    )
    rep = R(tmp_path)
    rep.write_resource("logo.png", b"PNGDATA")
    rep.write_resource("evil.txt", b"x")
    upload = client.post(
        "/api/v1/conversions",
        files={"file": ("r.zip", zip_folder(rep.root), "application/zip")},
    )
    cid = upload.json()["id"]
    ok = client.get(f"/api/v1/conversions/{cid}/dashboard/resources/logo.png")
    assert ok.status_code == 200 and ok.content == b"PNGDATA"
    assert ok.headers["content-type"] == "image/png"
    assert ok.headers["cache-control"] == "private, max-age=3600"
    assert ok.headers["x-content-type-options"] == "nosniff"
    assert ok.headers["content-security-policy"] == (
        "default-src 'none'; style-src 'unsafe-inline'; sandbox"
    )
    assert client.get(f"/api/v1/conversions/{cid}/dashboard/resources/evil.txt").status_code == 404
    assert client.get(f"/api/v1/conversions/{cid}/dashboard/resources/missing.png").status_code == 404


def _patch_spec(world, monkeypatch, edit):
    from app.runtime import dashboard as dash

    real = dash.compile_dashboard

    def compiled(*a, **k):
        spec, bm = real(*a, **k)
        edit(spec)
        return spec, bm

    monkeypatch.setattr("app.api.dashboards.compile_dashboard", compiled)
    monkeypatch.setattr("app.api.dashboards._compiled.__wrapped__", None, raising=False)
    from app.api import dashboards

    dashboards._compiled.cache_clear()


def test_title_query_is_returned_as_an_extra_result(world, monkeypatch):
    from app.runtime.engine import MeasureRefSpec, QuerySpec

    def edit(spec):
        v = next(v for p in spec.pages for v in p.visuals if v.name == CARD)
        v.title_query = QuerySpec(measures=[MeasureRefSpec(name="Total Quantity", alias="Total Quantity")])

    _patch_spec(world, monkeypatch, edit)
    r = world.query(CARD)
    names = [x["visual"] for x in r.json()["results"]]
    assert names == [CARD, f"{CARD}#title"]
    title = r.json()["results"][1]
    assert title["error"] is None and "Quantity" in title["sql"]


def test_show_as_adds_the_grand_total(world, monkeypatch):
    def edit(spec):
        v = next(v for p in spec.pages for v in p.visuals if v.name == BAR)
        v.measure_show_as = {"Total Sales": "percent_of_grand_total"}

    _patch_spec(world, monkeypatch, edit)
    world.responder = lambda sql: (["Product.Category", "Total Sales"], [("A", 1.0)]) if "GROUP BY" in sql else (["Total Sales"], [(9.0,)])  # noqa: E501
    out = world.query(BAR).json()["results"][0]
    assert out["totals"] == {"columns": ["Total Sales"], "row": [9.0]}


def test_chrome_visuals_render_from_the_spec_alone(world, monkeypatch):
    from app.runtime.dashboard import VisualSpec

    def edit(spec):
        spec.pages[0].visuals.append(
            VisualSpec(name="btn", visual_type="actionButton", x=0, y=0, width=10, height=10)
        )
        spec.pages[0].visuals.append(
            VisualSpec(name="grp", visual_type="visualGroup", x=0, y=0, width=10, height=10)
        )

    _patch_spec(world, monkeypatch, edit)
    r = world.post(
        "query",
        {
            "connection_id": world.conn_id,
            "queries": [{"page": PAGE, "visual": "btn"}, {"page": PAGE, "visual": "grp"}],
            "execution_tier": "tier_b_compatibility",
        },
    )
    assert [x["error"] for x in r.json()["results"]] == [None, None]
    assert world.executed == []
    assert FakeConn  # keep import


def test_drill_accepts_slicer_filters_and_a_level_key(world, monkeypatch):
    from app.runtime.dashboard import compile_dashboard as real

    def with_hierarchy(*a, **k):
        spec, bm = real(*a, **k)
        v = next(v for p in spec.pages for v in p.visuals if v.name == BAR)
        v.hierarchy = {"levels": ["Product.Category", "Product.Name"], "current_level": "Product.Category"}
        return spec, bm

    monkeypatch.setattr("app.api.dashboards.compile_dashboard", with_hierarchy)
    from app.api import dashboards

    dashboards._compiled.cache_clear()
    r = world.post(
        "query/drill",
        {
            "connection_id": world.conn_id, "page": PAGE, "visual": BAR, "direction": "down",
            "level_key": "Product.Category",
            "filters": [{"table": "Customer", "column": "Country", "values": ["US"]}],
            "parent_filters": [{"table": "Product", "column": "Category", "values": ["Bikes"]}],
        },
    )  # fmt: skip
    assert r.status_code == 200, r.text
    sql = r.json()["sql"]
    assert "'US'" in sql and "'Bikes'" in sql
    assert r.json()["level_key"] == "Product.Name"
