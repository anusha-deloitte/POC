from __future__ import annotations

import io
import json
import zipfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.agents.tier2 import expected_result, propose_and_validate
from app.api.deps import (
    get_connection_store,
    get_dashboard_token_store,
    get_ingest_service,
    get_snowflake_session_manager,
)
from app.binding.resolver import BindingMap, TableBinding
from app.core.config import get_settings
from app.ir.model import Column, Measure, SemanticModel, Table
from app.main import app
from app.services import cortex_client
from app.services.connections import ConnectionStore
from app.services.cortex_client import CortexClient, CortexError, llm_call_context
from app.services.dashboard_tokens import DashboardTokenStore
from app.services.horizon_client import HorizonError
from app.services.ingest import IngestService
from app.services.llm_errors import LlmError
from app.services.snowflake_sessions import SnowflakeSessionManager

# ---------------------------------------------------------------- Cortex client


class FakeCursor:
    def __init__(self, replies, log):
        self.replies = replies
        self.log = log
        self.closed = False
        self.connection = self
        self.row = None

    def execute(self, sql, params=None):
        self.log.append((sql, params))
        reply = self.replies.pop(0)
        if isinstance(reply, Exception):
            raise reply
        self.row = reply
        return self

    def fetchone(self):
        return self.row

    def close(self):
        self.closed = True


def _factory(replies, log):
    return lambda: FakeCursor(replies, log)


def _reply(text):
    return (json.dumps({"choices": [{"messages": text}], "usage": {"total_tokens": 7}}),)


def test_cortex_bind_params_and_json_string_reply(monkeypatch):
    log = []
    client = CortexClient(_factory([_reply("hello")], log), model="m1", temperature=0.2, max_tokens=50)
    msgs = [{"role": "user", "content": "it's 'quoted' ; drop"}]
    assert client.chat(msgs, qos="ignored", reasoning=True) == "hello"
    sql, params = log[0]
    assert sql == "SELECT SNOWFLAKE.CORTEX.COMPLETE(%s, PARSE_JSON(%s), PARSE_JSON(%s))"
    assert params == ("m1", json.dumps(msgs), json.dumps({"temperature": 0.2, "max_tokens": 50}))
    assert client.label == "Cortex (m1)" and client.provider == "cortex"


def test_cortex_dict_reply_and_fallback_shape():
    out = CortexClient(_factory([({"choices": [{"messages": "a"}]},)], []), model="m").chat([])
    assert out == "a"
    alt = ({"choices": [{"message": {"content": "b"}}]},)
    assert CortexClient(_factory([alt], []), model="m").chat([]) == "b"


@pytest.mark.parametrize(
    ("row", "match"),
    [
        (("not json",), "non-JSON"),
        ((json.dumps({"choices": []}),), "no choices"),
        ((json.dumps({"choices": [{"messages": ""}]}),), "empty"),
        (None, "no row"),
    ],
)
def test_cortex_reply_errors(row, match):
    with pytest.raises(CortexError, match=match):
        CortexClient(_factory([row], []), model="m").chat([])


def test_cortex_transient_retry_then_success(monkeypatch):
    sleeps = []
    monkeypatch.setattr(cortex_client.time, "sleep", sleeps.append)
    log = []
    client = CortexClient(
        _factory([RuntimeError("429 too many requests"), _reply("ok")], log), model="m"
    )
    assert client.chat([]) == "ok"
    assert len(log) == 2 and sleeps == [2]


def test_cortex_privilege_error_adds_hint_and_closes_connection():
    cursors = []

    def factory():
        c = FakeCursor([RuntimeError("Unknown function SNOWFLAKE.CORTEX.COMPLETE")], [])
        cursors.append(c)
        return c

    with pytest.raises(CortexError, match="SNOWFLAKE.CORTEX_USER"):
        CortexClient(factory, model="m").chat([])
    assert cursors[0].closed is True


def test_cortex_model_hint():
    err = RuntimeError("model 'x' is not available in this region")
    with pytest.raises(CortexError, match="PBIC_CORTEX_MODEL"):
        CortexClient(_factory([err], []), model="x").chat([])


def test_cortex_preflight_uses_context_and_audit(monkeypatch):
    seen = []

    class Audit:
        def __init__(self, kind, ctx):
            seen.append((kind, ctx))

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    monkeypatch.setattr(cortex_client, "_audit", lambda cursor, ctx: Audit("ai_llm", ctx))
    CortexClient(_factory([_reply("OK"), _reply("x")], []), model="m").preflight()
    client = CortexClient(_factory([_reply("x")], []), model="m")
    with llm_call_context("ai_llm_sql:Margin"):
        client.chat([])
    assert seen == [("ai_llm", "ai_llm_preflight"), ("ai_llm", "ai_llm_sql:Margin")]


def test_llm_error_hierarchy():
    assert issubclass(CortexError, LlmError) and issubclass(HorizonError, LlmError)


# ---------------------------------------------------------------- provider selection


def test_providers_endpoint_and_selection(monkeypatch):
    with TestClient(app) as c:
        body = c.get("/api/v1/llm/providers").json()
    assert body["default"] in ("cortex", "horizon")
    assert "model" in body["cortex"] and isinstance(body["horizon"]["configured"], bool)
    assert "secret" not in json.dumps(body).lower()

    from app.services.llm_provider import build_llm_client, resolve_provider

    assert resolve_provider("horizon") == "horizon"
    assert resolve_provider(None) == get_settings().llm_provider
    assert build_llm_client("cortex", lambda: None).provider == "cortex"
    assert build_llm_client("horizon", lambda: None) is None  # no credentials in tests


# ---------------------------------------------------------------- tier-2


def _model():
    return SemanticModel(
        tables=[
            Table(
                name="Sales",
                columns=[Column(name="Amount"), Column(name="Key")],
                measures=[
                    Measure(name="Total", expression="SUM(Sales[Amount])"),
                    Measure(name="Status", expression='IF([Total] > 10, "High", "Low")'),
                    Measure(name="Ratio", expression="DIVIDE([Total], 2)"),
                ],
            ),
            Table(name="Other", columns=[Column(name="X")]),
        ],
        relationships=[],
    )


def _bindings():
    return BindingMap(
        bindings={
            n: TableBinding(table=n, schema_name="PUBLIC", object_name=n.upper(), status="resolved")
            for n in ("Sales", "Other")
        }
    )


class Chat:
    def __init__(self, replies):
        self.replies = list(replies)
        self.calls = []

    def chat(self, messages, **kw):
        self.calls.append([dict(m) for m in messages])
        return self.replies.pop(0)


class Cur:
    def __init__(self, rows):
        self.rows = list(rows)
        self.executed = []

    def execute(self, sql, *a):
        self.executed.append(sql)
        r = self.rows.pop(0)
        if isinstance(r, Exception):
            raise r
        self._row = r

    def fetchone(self):
        return self._row


def test_expected_result_kinds():
    assert expected_result("SUM(Sales[Amount])").kind == "numeric"
    t = expected_result('VAR x = [Total] RETURN IF(x > 1, "High", IF(x > 0, "Low", BLANK()))')
    assert (t.kind, t.literals) == ("text", ("High", "Low"))
    sw = expected_result('SWITCH(TRUE(), [A] > 1, "a", [B] > 1, "b", "c")')
    assert sw.kind == "text" and sw.literals == ("a", "b", "c")
    assert expected_result('IF([A] > 1, "a", 5)').kind == "numeric"


def test_tier2_text_measure_accepts_only_literals(tmp_path):
    chat = Chat(
        [
            '{"sql": "SELECT \'Medium\' AS RESULT"}',
            '{"sql": "SELECT \'High\' AS RESULT"}',
        ]
    )
    cur = Cur([("Medium",), ("High",)])
    log = tmp_path / "t2.jsonl"
    result = propose_and_validate(
        _model(), _bindings(), "Status", cur, client=chat, log_path=log, dependency_sql={}
    )
    assert result.accepted and result.attempts == 2
    assert "NULL or one of" in chat.calls[0][0]["content"]
    assert "not one of" in chat.calls[1][-1]["content"]
    rows = [json.loads(line) for line in log.read_text(encoding="utf-8").splitlines()]
    assert [r["outcome"] for r in rows] == ["execution_failed", "accepted"]
    assert rows[0]["event"] == "tier2_llm_attempt" and "request_messages" in rows[0]


def test_tier2_numeric_must_parse_and_context_is_scoped():
    chat = Chat(['{"sql": "SELECT \'abc\' AS RESULT"}', '{"sql": "SELECT 5 AS RESULT"}'])
    cur = Cur([("abc",), (5,)])
    result = propose_and_validate(_model(), _bindings(), "Ratio", cur, client=chat)
    assert result.accepted
    ctx = chat.calls[0][1]["content"]
    assert "model table [Sales]" in ctx and "[Other]" not in ctx
    assert "Other measures it references" in ctx and "[Total]" in ctx


def test_tier2_rejections_and_impossible():
    chat = Chat(["no json", '{"sql": "DROP TABLE x"}', '{"error": "nope"}'])
    result = propose_and_validate(_model(), _bindings(), "Ratio", Cur([]), client=chat)
    assert not result.accepted and result.attempts == 3
    assert "declared impossible" in result.trace[-1]


def test_tier2_log_respects_log_llm_text(tmp_path, monkeypatch):
    monkeypatch.setenv("PBIC_LOG_LLM_TEXT", "false")
    get_settings.cache_clear()
    try:
        log = tmp_path / "t2.jsonl"
        chat = Chat(['{"sql": "SELECT 1 AS RESULT"}'])
        propose_and_validate(_model(), _bindings(), "Ratio", Cur([(1,)]), client=chat, log_path=log)
        row = json.loads(log.read_text(encoding="utf-8").splitlines()[0])
        assert row["outcome"] == "accepted"
        assert "request_messages" not in row and "response" not in row and "sql" not in row
    finally:
        monkeypatch.delenv("PBIC_LOG_LLM_TEXT")
        get_settings.cache_clear()


def test_tier2_without_client_reports_unconfigured():
    r = propose_and_validate(_model(), _bindings(), "Ratio", Cur([]), client=None)
    assert r.trace == ["Horizon credentials not configured"]


# ---------------------------------------------------------------- pipeline hooks


def test_provider_switch_drops_ai_work(tmp_path):
    from app.agents.pipeline import ConversionRun, _drop_other_provider_ai
    from app.ir.report import ReportBundle

    bundle = ReportBundle(model=_model(), report=None) if False else None
    model = _model()
    model.__dict__["dax_rewrites"] = {"A": {"source": "ai"}, "B": {"source": "user"}}

    class B:
        pass

    b = B()
    b.model = model
    b.model_dump_json = lambda indent=2: "{}"
    run = ConversionRun(conversion_id="c", tier2_accepted={"m": "select 1"})
    _drop_other_provider_ai(run, b, tmp_path, {"llm_provider": "cortex"}, "cortex")
    assert run.tier2_accepted == {"m": "select 1"}  # same provider: untouched
    _drop_other_provider_ai(run, b, tmp_path, {"stages_complete": {}}, "cortex")  # missing = horizon
    assert run.tier2_accepted == {}
    assert list(model.dax_rewrites) == ["B"]
    assert "AI provider changed from horizon to cortex: 1 AI SQL" in run.events[-1]["message"]
    assert (tmp_path / "bundle.json").is_file()
    assert bundle is None


# ---------------------------------------------------------------- convert endpoint


def _zip(folder: Path) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, f.relative_to(folder))
    return buf.getvalue()


def test_convert_returns_422_cortex_unavailable(tmp_path, contoso_pbip, monkeypatch):
    svc = IngestService(tmp_path / "storage")
    store = ConnectionStore(tmp_path / "storage", tmp_path / "storage" / ".key")

    class Cursor:
        def execute(self, sql, params=None):
            if "CORTEX" in sql:
                raise RuntimeError("Unknown function SNOWFLAKE.CORTEX.COMPLETE")
            return self

        def fetchone(self):
            return ("1",)

        def close(self):
            pass

    class Conn:
        closed = False

        def cursor(self):
            return Cursor()

        def is_closed(self):
            return self.closed

        def close(self):
            self.closed = True

    mgr = SnowflakeSessionManager(store, connect=lambda **kw: Conn())
    store._session_manager = mgr
    tokens = DashboardTokenStore(tmp_path / "storage", default_ttl_seconds=300)
    monkeypatch.setattr("app.api.dashboards.get_ingest_service", lambda: svc)
    app.dependency_overrides[get_ingest_service] = lambda: svc
    app.dependency_overrides[get_connection_store] = lambda: store
    app.dependency_overrides[get_snowflake_session_manager] = lambda: mgr
    app.dependency_overrides[get_dashboard_token_store] = lambda: tokens
    try:
        with TestClient(app) as c:
            cid = c.post(
                "/api/v1/conversions",
                files={"file": ("c.zip", _zip(contoso_pbip), "application/zip")},
            ).json()["id"]
            conn = c.post(
                "/api/v1/connections",
                json={
                    "name": "n",
                    "account": "a",
                    "user": "u",
                    "warehouse": "WH",
                    "auth_method": "password",
                    "password": "pw",
                },
            ).json()
            r = c.post(
                f"/api/v1/conversions/{cid}/dashboard/convert",
                json={"connection_id": conn["id"], "use_llm": True, "llm_provider": "cortex"},
            )
        assert r.status_code == 422, r.text
        detail = r.json()["detail"]
        assert detail["code"] == "cortex_unavailable"
        assert "CORTEX_USER" in detail["message"]
    finally:
        mgr.close_all()
        app.dependency_overrides.clear()
