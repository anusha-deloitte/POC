"""The standalone dashboard package ("Download standalone dashboard"): the built React app, a small
local FastAPI query service, the compiled spec and one SQL template per data query.

Each template is the generated SQL with a slot wherever a filter on a column would go
(`SemanticEngine.build_template`); the service fills them with the request's filters
(`sql_render.render_template`) and runs them on Snowflake with the user's own sign-in.
"""

from __future__ import annotations

import io
import json
import os
import re
import secrets
import sys
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from app.runtime import sql_render as sr
from app.runtime.dashboard import DashboardSpec, PageSpec, VisualSpec
from app.runtime.engine import FilterClause, QueryPlanError, QuerySpec, SemanticEngine
from app.runtime.filter_cards import filter_values_query
from app.services import sql_overrides as sqlo

TITLE_SUFFIX = "#title"
FILTER_VALUES_LIMIT = 500
STATIC_VISUAL_TYPES = {
    "textbox", "shape", "basicShape", "image", "actionButton",
    "visualGroup", "bookmarkNavigator", "pageNavigator",
}  # fmt: skip
SERVICE_FILES = ("main.py", "snowflake_session.py", "manifest.py", "connection_store.py")
SCRIPT_FILES = ("start.ps1", "stop.ps1", "install-autostart.ps1", "uninstall-autostart.ps1")
VENDOR_ROOTS = (
    "fastapi",
    "uvicorn",
    "snowflake-connector-python[secure-local-storage]",
)

Slot = tuple[str, str]


class StandaloneExportError(Exception):
    pass


# ---------------------------------------------------------------------------- slots


def _dedupe(slots: list[Slot]) -> list[Slot]:
    seen: set[Slot] = set()
    out: list[Slot] = []
    for s in slots:
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out


def _query_of(vs: VisualSpec) -> QuerySpec | None:
    return vs.query or vs.draft_query


def filter_card_columns(spec: DashboardSpec, page: PageSpec) -> list[Slot]:
    """Columns of the supported report and page Filters-pane cards (a card can be changed by the
    viewer to any selection, so each column needs a slot)."""
    return _dedupe(
        [
            (c.table, c.column)
            for c in [*spec.report_filters, *page.filters]
            if c.supported and c.table and c.column
        ]
    )


def page_slots(page: PageSpec, extra: list[Slot] | None = None) -> list[Slot]:
    """Every column the front end can send a filter on for this page: each slicer's target
    (synced and hidden slicers are page visuals too), the first category column of every visual
    (cross-filter, map and bookmark selections), plus `extra`."""
    slots: list[Slot] = []
    for vs in page.visuals:
        if vs.slicer_target:
            slots.append((vs.slicer_target["table"], vs.slicer_target["column"]))
        q = _query_of(vs)
        if q is not None and q.dimensions:
            slots.append((q.dimensions[0].table, q.dimensions[0].column))
    slots.extend(extra or [])
    return _dedupe(slots)


def drill_sources(spec: DashboardSpec, target: PageSpec) -> list[tuple[PageSpec, VisualSpec]]:
    """Visuals that can open `target`: for a drill-through page, those using any of its fields;
    for a Tooltip page, those showing it."""
    out: list[tuple[PageSpec, VisualSpec]] = []
    for page in spec.pages:
        if page.name == target.name:
            continue
        for vs in page.visuals:
            if target.page_type == "Tooltip" or (target.page_type or "").lower() == "tooltip":
                if vs.tooltip_page == target.name:
                    out.append((page, vs))
                continue
            for f in target.drillthrough:
                used = vs.measure_keys if f.measure else vs.dim_keys
                if f.key in used:
                    out.append((page, vs))
                    break
    return out


def source_slot_columns(spec: DashboardSpec, page: PageSpec) -> list[Slot]:
    """Columns a drill-through / Tooltip page receives as context filters: the source visuals'
    dimension keys, their visual filters and every slot of the source pages."""
    slots: list[Slot] = []
    for src_page, vs in drill_sources(spec, page):
        q = _query_of(vs)
        if q is not None:
            slots.extend((d.table, d.column) for d in q.dimensions)
            slots.extend((f.table, f.column) for f in q.filters)
        slots.extend(page_slots(src_page, filter_card_columns(spec, src_page)))
    return _dedupe(slots)


def visual_slots(slots: list[Slot], vs: VisualSpec, keep: list[Slot] | None = None) -> list[Slot]:
    """A slicer never filters its own list, except by a Filters-pane card on the same column."""
    own = vs.slicer_target
    if not own:
        return list(slots)
    key = (own["table"], own["column"])
    return [s for s in slots if s != key or s in (keep or [])]


# ---------------------------------------------------------------------------- templates


_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def _safe(name: str) -> str:
    return _UNSAFE.sub("_", name).strip("._") or "x"


def _sample(table: str, column: str) -> FilterClause:
    return FilterClause(table=table, column=column, op="in", values=["x"])


def _check_parse(sql: str, meta: dict) -> str | None:
    """Rendering with no selection and with every usable slot set must parse (Snowflake)."""
    import sqlglot

    blocked = {s for g in meta.get("guards") or [] for s in g["slots"]}
    blocked |= set(meta.get("slot_errors") or {})
    every = [
        _sample(s["table"], s["column"])
        for sid, s in (meta.get("slots") or {}).items()
        if sid not in blocked
    ]
    for label, filters in (("no selection", []), ("every slot set", every)):
        try:
            rendered, _ = sr.render_template(sql, meta, filters)
            sqlglot.parse_one(rendered, read="snowflake")
        except Exception as e:  # noqa: BLE001 - sqlglot / TemplateError
            return f"template does not parse with {label}: {str(e).splitlines()[0][:300]}"
    return None


def edited_template(sql: str, slots: list[Slot], engine: SemanticEngine) -> tuple[str, dict]:
    """A hand-edited query as a template: each `{{filters}}` / `{{filters:T}}` becomes the `{{p:N}}`
    predicates of the slots whose table alias the edited text references."""
    text = sqlo._clean(sql)
    masked = sqlo.mask_sql(text, keep_identifiers=True)
    placeholders = sqlo._placeholders(text)
    chars = list(masked)
    for m in placeholders:
        for k in range(m.start(), m.end()):
            chars[k] = " "
    visible = "".join(chars).lower()

    meta: dict[str, Any] = {
        "preds": [], "blocks": {}, "isf": {}, "slots": {}, "guards": [], "slot_errors": {},
    }  # fmt: skip
    candidates: list[tuple[str, str, str]] = []  # (sid, table, column reference)
    for i, (table, column) in enumerate(slots):
        alias, col = engine.slot_column(table, column)
        if alias.lower() in visible:
            sid = f"s{i}"
            meta["slots"][sid] = {"table": table, "column": column}
            candidates.append((sid, table, col))

    def predicates(table: str | None) -> str:
        chosen = [c for c in candidates if table is None or c[1].lower() == table]
        parts = []
        for sid, _t, col in chosen:
            meta["preds"].append({"slot": sid, "col": col})
            parts.append(f"{{{{p:{len(meta['preds']) - 1}}}}}")
        return " AND ".join(parts) if parts else "1=1"

    out: list[str] = []
    pos = 0
    for m in placeholders:
        out.append(text[pos : m.start()])
        body = m.group(1)
        out.append(
            predicates(None if body == "filters" else body[len("filters:") :].strip().lower())
        )
        pos = m.end()
    out.append(text[pos:])
    return "".join(out), meta


@dataclass
class _Package:
    files: dict[str, str] = field(default_factory=dict)
    queries: dict[str, dict] = field(default_factory=dict)
    drill: dict[str, dict] = field(default_factory=dict)
    filter_values: dict[str, dict] = field(default_factory=dict)
    coverage: list[dict] = field(default_factory=list)


class _Builder:
    def __init__(self, spec: DashboardSpec, engine: SemanticEngine, overrides: dict[str, dict]):
        self.spec = spec
        self.engine = engine
        self.overrides = overrides
        self.pkg = _Package()

    def _path(self, *parts: str, suffix: str) -> str:
        base = "/".join(["data", "templates", *(_safe(p) for p in parts)])
        path, n = f"{base}{suffix}", 1
        while path in self.pkg.files:
            n += 1
            path = f"{base}-{n}{suffix}"
        return path

    def add(self, query: QuerySpec, slots: list[Slot], *parts: str, suffix: str = ".sql") -> dict:
        try:
            sql, meta, warnings = self.engine.build_template(query, slots)
        except QueryPlanError as e:
            return {"kind": "error", "error": str(e)}
        path = self._path(*parts, suffix=suffix)
        self.pkg.files[path] = sql
        entry: dict[str, Any] = {"kind": "sql", "file": path, "meta": meta, "warnings": warnings}
        problem = _check_parse(sql, meta)
        if problem:
            entry["parse_warning"] = problem
        return entry

    def add_edited(self, sql: str, slots: list[Slot], *parts: str) -> dict:
        try:
            text, meta = edited_template(sql, slots, self.engine)
        except Exception as e:  # noqa: BLE001 - a bad edit surfaces per pane
            return {"kind": "error", "error": f"edited SQL: {e}"}
        path = self._path(*parts, suffix=".edited.sql")
        self.pkg.files[path] = text
        entry: dict[str, Any] = {
            "kind": "sql", "file": path, "meta": meta, "warnings": [], "edited": True,
        }  # fmt: skip
        problem = _check_parse(text, meta)
        if problem:
            entry["parse_warning"] = problem
        return entry

    # ------------------------------------------------------------------ per visual

    def _totals_query(self, vs: VisualSpec, q: QuerySpec) -> QuerySpec | None:
        wants = (
            vs.options.get("show_totals") and vs.visual_type in ("pivotTable", "tableEx")
        ) or bool(vs.measure_show_as)
        if not (q.dimensions and q.measures and wants) or q.measure_filters:
            return None
        totals = q.model_copy(deep=True)
        totals.dimensions, totals.sort = [], []
        return totals

    def visual(self, page: PageSpec, vs: VisualSpec, slots: list[Slot], cards: list[Slot]) -> None:
        key = f"{page.name}/{vs.name}"
        mine = visual_slots(slots, vs, keep=cards)
        override = self.overrides.get(sqlo.key_for(page.name, vs.name))
        static = vs.visual_type in STATIC_VISUAL_TYPES
        if static and vs.query is None:
            self.pkg.queries[key] = {"kind": "static"}
        elif override and not static:
            entry = self.add_edited(override["sql"], mine, page.name, vs.name)
            self.pkg.queries[key] = entry
        elif not vs.supported or vs.query is None:
            reason = vs.unsupported_reason or "unsupported visual"
            self.pkg.queries[key] = {"kind": "error", "error": reason}
        else:
            self.pkg.queries[key] = self.add(vs.query, mine, page.name, vs.name)

        q = vs.query
        entry = self.pkg.queries[key]
        if q is not None and entry.get("kind") == "sql":
            totals = self._totals_query(vs, q)
            if totals is not None:
                t = self.add(totals, mine, page.name, vs.name, suffix=".totals.sql")
                if t.get("kind") == "sql":
                    entry["totals"] = t
        if vs.title_query is not None:
            self.pkg.queries[f"{key}{TITLE_SUFFIX}"] = self.add(
                vs.title_query, mine, page.name, vs.name, suffix=".title.sql"
            )
        if q is not None and vs.hierarchy and vs.hierarchy.get("levels"):
            self.drill(page, vs, q, mine)

    def drill(self, page: PageSpec, vs: VisualSpec, q: QuerySpec, mine: list[Slot]) -> None:
        levels = list(vs.hierarchy["levels"])
        by_target: dict[str, dict] = {}
        parents = [(d.table, d.column) for d in q.dimensions if d.key in levels]
        for idx in range(len(levels)):
            active = set(levels[: idx + 1])
            query = q.model_copy(deep=True)
            query.dimensions = [
                d for d in query.dimensions if d.key in active or d.key not in levels
            ]
            by_target[str(idx)] = self.add(
                query, _dedupe([*mine, *parents]), page.name, vs.name, suffix=f".drill{idx}.sql"
            )
        self.pkg.drill[f"{page.name}/{vs.name}"] = {
            "levels": levels,
            "current_level": vs.hierarchy.get("current_level") or levels[-1],
            "by_target": by_target,
        }

    # ------------------------------------------------------------------ whole report

    def build(self) -> _Package:
        spec = self.spec
        card_columns: list[Slot] = []
        for page in spec.pages:
            cards = filter_card_columns(spec, page)
            card_columns.extend(cards)
            extra = list(cards)
            if page.page_type or page.drillthrough:
                extra.extend(source_slot_columns(spec, page))
            slots = page_slots(page, _dedupe(extra))
            for vs in page.visuals:
                self.visual(page, vs, slots, cards)
        for table, column in _dedupe(card_columns):
            name = f"{table}.{column}"
            self.pkg.filter_values[name] = self.add(
                filter_values_query(table, column, None, FILTER_VALUES_LIMIT),
                [(table, column)],
                "_filter_values",
                name,
            )
        self.pkg.coverage = self.coverage()
        return self.pkg

    def coverage(self) -> list[dict]:
        rows: list[dict] = []
        for page in self.spec.pages:
            for vs in page.visuals:
                entry = self.pkg.queries.get(f"{page.name}/{vs.name}") or {}
                kind = entry.get("kind")
                meta = entry.get("meta") or {}
                notes: list[str] = []
                if kind == "error":
                    notes.append(f"no data: {entry.get('error')}")
                if entry.get("edited"):
                    notes.append("hand-edited SQL")
                if entry.get("parse_warning"):
                    notes.append(entry["parse_warning"])
                for g in meta.get("guards") or []:
                    notes.append(
                        f"refused when filtered by a cross-filtering slicer: {g['message']}"
                    )
                for msg in (meta.get("slot_errors") or {}).values():
                    notes.append(f"cannot be filtered by one slicer: {msg}")
                honours = sorted(
                    {f"{s['table']}[{s['column']}]" for s in (meta.get("slots") or {}).values()}
                )
                rows.append(
                    {
                        "page": page.display_name,
                        "visual": vs.name,
                        "type": vs.visual_type,
                        "kind": kind,
                        "honours": honours,
                        "notes": notes,
                    }  # fmt: skip
                )
        return rows


def build_templates(
    spec: DashboardSpec, engine: SemanticEngine, sql_overrides: dict[str, dict] | None = None
) -> _Package:
    return _Builder(spec, engine, sql_overrides or {}).build()


# ---------------------------------------------------------------------------- the zip


def connection_settings(profile: Any) -> dict[str, Any]:
    """The exporting profile's non-secret settings (NEVER secrets)."""
    return {
        "account": profile.account,
        "user": profile.user,
        "auth_method": str(getattr(profile.auth_method, "value", profile.auth_method)),
        "role": profile.role,
        "warehouse": profile.warehouse,
        "database": profile.database,
        "schema": getattr(profile, "schema_name", None),
        "oauth_client_id": profile.oauth_client_id,
        "oauth_token_url": profile.oauth_token_url,
        "remember": False,
    }


def vendor_distributions(roots: tuple[str, ...] = VENDOR_ROOTS) -> list[Any]:
    """The installed distributions `roots` need (requirements, markers and extras followed)."""
    from importlib import metadata

    from packaging.requirements import Requirement
    from packaging.utils import canonicalize_name

    found: dict[str, Any] = {}
    queue = [(Requirement(r), None) for r in roots]
    while queue:
        req, _parent = queue.pop()
        name = canonicalize_name(req.name)
        try:
            dist = found.get(name) or metadata.distribution(req.name)
        except metadata.PackageNotFoundError as e:
            raise StandaloneExportError(
                f"Python package '{req.name}' is not installed in the converter's environment"
            ) from e
        new = name not in found
        found[name] = dist
        extras = sorted(req.extras) or [""]
        for requirement in dist.requires or []:
            r = Requirement(requirement)
            if r.marker is not None and not any(
                r.marker.evaluate({"extra": e}) for e in (extras if req.extras else [""])
            ):
                continue
            rname = canonicalize_name(r.name)
            if rname not in found or (r.extras and new):
                queue.append((r, dist))
    for dist in found.values():
        tops = {str(f).replace("\\", "/").split("/")[0] for f in dist.files or []}
        if "app" in tops:
            raise StandaloneExportError(
                f"refusing to vendor the converter itself ('{dist.metadata['Name']}')"
            )
    return sorted(found.values(), key=lambda d: str(d.metadata["Name"]).lower())


def _vendor_files(dists: list[Any]) -> list[tuple[str, Path]]:
    out: dict[str, Path] = {}
    for dist in dists:
        for f in dist.files or []:
            rel = str(f).replace("\\", "/")
            if rel.startswith("..") or "__pycache__" in rel or rel.endswith(".pyc"):
                continue
            path = Path(str(dist.locate_file(f)))
            if path.is_file():
                out[rel] = path
    return sorted(out.items())


def python_version() -> str:
    """The vendored libraries are the converter environment's: the package needs that Python."""
    return f"{sys.version_info.major}.{sys.version_info.minor}"


def _frontend_build() -> Path:
    env = os.environ.get("PBIC_STANDALONE_BUILD")
    if env:
        return Path(env)
    return Path(__file__).resolve().parents[3] / "frontend" / "dist-standalone"


def _service_dir() -> Path:
    return Path(__file__).resolve().parents[1] / "standalone"


def _coverage_md(spec: DashboardSpec, rows: list[dict]) -> str:
    lines = [
        f"# {spec.report_name}: coverage of the standalone dashboard",
        "",
        "What each pane honours (slicers, cross-filters, Filters-pane cards) and its limits.",
        "Logic is fixed when the package is exported; the data is live.",
        "",
    ]
    for page in spec.pages:
        lines += [
            f"## {page.display_name}",
            "",
            "| Pane | Type | Data | Honours | Limits |",
            "| --- | --- | --- | --- | --- |",
        ]
        for r in (r for r in rows if r["page"] == page.display_name):
            honours = ", ".join(r["honours"]) or "-"
            limits = "; ".join(r["notes"]) or "-"
            row = f"| {r['visual']} | {r['type']} | {r['kind'] or '-'} | {honours} | {limits} |"
            lines.append(row.replace("\n", " "))
        lines.append("")
    lines += [
        "## General limits",
        "",
        "- Top N Filters-pane cards and What-If parameter changes are not available here.",
        "- Accelerated (extract) mode is not available: queries always run on Snowflake.",
        "",
    ]
    return "\n".join(lines)


def build_standalone_zip(
    spec: DashboardSpec,
    engine: SemanticEngine,
    conv_dir: Path | None,
    profile: Any,
    resources: dict[str, bytes] | None = None,
    frontend_build: Path | None = None,
    vendor: bool = True,
) -> bytes:
    build = Path(frontend_build) if frontend_build else _frontend_build()
    if not (build / "standalone.html").is_file():
        raise StandaloneExportError(
            f"standalone front end not built ({build}): run `npm run build:standalone` in frontend/"
        )
    overrides = sqlo.load_overrides(conv_dir) if conv_dir else {}
    pkg = build_templates(spec, engine, overrides)

    slug = _UNSAFE.sub("-", spec.report_name.lower()).strip("-") or "dashboard"
    root = f"{slug}-standalone"
    token = secrets.token_urlsafe(32)
    package_id = secrets.token_hex(8)
    manifest = {
        "version": 1,
        "package_id": package_id,
        "report_name": spec.report_name,
        "python": python_version(),
        "queries": pkg.queries,
        "drill": pkg.drill,
        "filter_values": pkg.filter_values,
        "filter_values_limit": FILTER_VALUES_LIMIT,
    }
    dists = vendor_distributions() if vendor else []
    service = _service_dir()
    readme = (service / "README.md").read_text(encoding="utf-8")

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:

        def put(name: str, data: str | bytes) -> None:
            z.writestr(f"{root}/{name}", data)

        for path in sorted(build.rglob("*")):
            if path.is_file():
                rel = path.relative_to(build).as_posix()
                put(f"app/{'index.html' if rel == 'standalone.html' else rel}", path.read_bytes())
        put(
            "app/dashboard-config.json",
            json.dumps({"api_base": "/api/v1/published", "token": token}),
        )
        for name, data in (resources or {}).items():
            put(f"app/resources/{name}", data)

        for name in SERVICE_FILES:
            put(f"service/{name}", (service / name).read_bytes())
        put("service/render.py", Path(sr.__file__).read_bytes())
        for name in SCRIPT_FILES:
            put(name, (service / name).read_bytes())

        put("data/spec.json", spec.model_dump_json())
        put("data/manifest.json", json.dumps(manifest, indent=2))
        put("data/connection.json", json.dumps(connection_settings(profile), indent=2))
        put("data/token.txt", token)
        for path, sql in pkg.files.items():
            put(path, sql)

        put("COVERAGE.md", _coverage_md(spec, pkg.coverage))
        put(
            "README.md",
            readme.replace("{{REPORT_TITLE}}", spec.report_name).replace(
                "{{PYTHON}}", python_version()
            ),
        )
        for rel, path in _vendor_files(dists):
            put(f"vendor/{rel}", path.read_bytes())
    return buf.getvalue()


__all__ = [
    "StandaloneExportError", "build_standalone_zip", "build_templates", "connection_settings",
    "drill_sources", "edited_template", "filter_card_columns", "page_slots", "source_slot_columns",
    "vendor_distributions", "visual_slots",
]  # fmt: skip
