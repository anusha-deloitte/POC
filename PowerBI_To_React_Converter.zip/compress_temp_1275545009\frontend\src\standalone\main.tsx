import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { DashboardApp } from '../dashboard/DashboardApp'
import '../index.css'
import './standalone.css'

const response = await fetch('/dashboard-config.json')
if (!response.ok) throw new Error(`dashboard-config.json: ${response.status}`)
const config = (await response.json()) as { api_base: string; token: string }

const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false, refetchOnWindowFocus: false } } })

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <DashboardApp
        conversionId="standalone"
        connectionId="standalone"
        apiConfig={{ baseUrl: config.api_base, token: config.token, published: true }}
        variant="standalone"
      />
    </QueryClientProvider>
  </StrictMode>,
)
