"""The exported package's data: compiled spec, query-template manifest and dashboard token.

Shipped verbatim inside the package as `service/manifest.py`.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

try:  # shipped flat in service/ (render.py is a copy of runtime/sql_render.py)
    import render  # type: ignore
except ImportError:  # in the repo
    from app.runtime import sql_render as render


class Package:
    def __init__(self, root: Path | str):
        self.root = Path(root)
        data = self.root / "data"
        self.data_dir = data
        self.spec: dict[str, Any] = json.loads((data / "spec.json").read_text(encoding="utf-8"))
        self.manifest: dict[str, Any] = json.loads(
            (data / "manifest.json").read_text(encoding="utf-8")
        )
        self.token = (data / "token.txt").read_text(encoding="utf-8").strip()
        self._templates: dict[str, str] = {}

    @property
    def package_id(self) -> str:
        return str(self.manifest.get("package_id", ""))

    @property
    def report_name(self) -> str:
        return str(self.manifest.get("report_name") or self.spec.get("report_name") or "")

    @property
    def queries(self) -> dict[str, dict]:
        return self.manifest.get("queries") or {}

    @property
    def drill(self) -> dict[str, dict]:
        return self.manifest.get("drill") or {}

    @property
    def filter_values(self) -> dict[str, dict]:
        return self.manifest.get("filter_values") or {}

    @property
    def filter_values_limit(self) -> int:
        return int(self.manifest.get("filter_values_limit") or 500)

    def entry(self, page: str, visual: str) -> dict | None:
        return self.queries.get(f"{page}/{visual}")

    def template(self, entry: dict) -> str:
        file = entry["file"]
        if file not in self._templates:
            self._templates[file] = (self.root / "data" / file.removeprefix("data/")).read_text(
                encoding="utf-8"
            )
        return self._templates[file]

    def render(self, entry: dict, filters: list) -> tuple[str, list[str]]:
        """`(sql, unapplied warnings)`: the template filled with the request's filters.
        Raises `render.TemplateError` for filters the standalone dashboard can't apply."""
        return render.render_template(self.template(entry), entry.get("meta") or {}, filters)
