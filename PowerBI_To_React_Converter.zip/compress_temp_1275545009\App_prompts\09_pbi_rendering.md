# Phase 09 - Power BI-faithful rendering, navigation and bookmarks

## Purpose
Render converted pages the way Power BI does: raw PBIR formatting resolved with Power BI's precedence, Power BI default
geometry, buttons/shapes/images, bookmarks and page navigation, matrices with collapsed rows, measure-driven titles,
KPI cards, shape maps, scrollbars, number formats, and a clear "no data" state. Put every visual tuning in
`pbi/defaults.ts`, never per report. Visuals without `pbir` (e.g. the reimagined variant) keep the legacy styling.

## Current target state
`DashboardApp.tsx` (225 lines), `PageCanvas.tsx` (265), `ChartVisual.tsx` (465), `TableVisual.tsx` (116), basic Card,
Slicer, Textbox, Map; no `dashboard/pbi/*`, no navigation, no chrome visuals; backend spec without PBIR passthrough.

## 1. Backend: spec fields and passthroughs (`runtime/dashboard.py`)
1.1 `VisualSpec` adds: `z: float`, `data_status` (`ok | untranslated | unsupported_type`; the renderer draws chrome either way),
`manual_sql` (phase 08), `draft_query` (phase 08), `measure_show_as`, `default_selection` (saved slicer selection), `pbir`
(`{objects, container_objects, fields:[{role, table, name, display_name, is_measure, aggregate, query_ref}], sort, is_hidden,
self_hidden, parent_group}`), `action`, `title_query`, `hierarchy.expand_rows`. (`sync_group`, `tooltip_page` in phases 10/11.)
1.2 `PageSpec` adds `background` (raw `objects.background` entry), `is_hidden` ("Hide page": not in tabs, still a navigation /
drill-through / bookmark target), `display_option` (default FitToPage). `DashboardSpec` adds `pbi_theme {base_name, base, custom}`
and `vertical_alignment` (default Top).
1.3 Report folder: uploads are often nested (`source/<zip folder>/X.Report`): always locate the report folder via one helper
`_report_dir(bundle)` (images, base theme, layout fallbacks depend on it).
1.4 Themes: `pbi_theme_passthrough(bundle)`: base theme JSON from `StaticResources/SharedResources/BaseThemes/<name>.json`
(empty when missing) + the custom theme, read from the stored source.
1.5 Images: `image_source(visual)` -> `{resource: <file>}` for `StaticResources/RegisteredResources` images or `{url}` for linked
ones; `referenced_resources(spec)` = image visuals + custom button icons (used by the React export to bundle them).
`GET /dashboard/resources/{name}`: name must match `^[A-Za-z0-9 _.()\-]+$`, not start with `.`, resolve inside
RegisteredResources (no traversal), extension png/jpg/jpeg/gif/svg/webp/bmp; headers `Cache-Control: private, max-age=3600`,
`X-Content-Type-Options: nosniff`, `Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; sandbox`; else 404.
1.6 Stored conversions must pick up parser additions without re-upload (each idempotent, reading the stored source):
`visual_source_passthrough` (group container objects, projection `active`), `page_layout_passthrough` (displayOption,
verticalAlignment), `interaction_graph_passthrough` (empty graph -> rebuild), `bookmarks_passthrough` (always re-read).
1.7 Visual mapping:
- groups (`visualGroup`), shapes, buttons, images, textboxes, bookmark/page navigators are chrome (no query).
- unknown custom visuals -> `data_status="unsupported_type"` (layout kept, chrome drawn).
- the AppSource KPI-card custom visual (recognised by its kpiName / actual / target1 object signature) -> `kpiCard`.
- untranslated measure -> `data_status="untranslated"`, layout kept, `draft_query` set, `query=None`.
- 100% stacked bar/column types supported.
- inactive (`active: false`) drill levels are not queried; a pivotTable authored at a collapsed level gets
  `hierarchy.expand_rows=True` and expands (+/-) through `POST /dashboard/query/drill` (`{connection_id, page, visual, direction,
  level_key, parent_filters, filters}`; logged as kind `drill`).
- measure-driven titles (title.text = a measure) -> `title_query` (measure-only query under the visual's own column filters);
  `/query` returns it as the extra result `"<visual>#title"`; buttons whose text is a measure use the same mechanism.
- "Show value as -> percent of grand total" (`show_as`): `/query` adds the grand total in `VisualResult.totals`; the renderer divides.
- `saved_slicer_selection(visual)`: `objects.general[0].properties.filter.filter` Version-2 `In` with literals -> default selection
  (inverted/"all except" and non-literal shapes -> [] = All).
- `visual_filters_to_query(visual)` ("Filters on this visual") -> (column filters, measure filters, dropped descriptions); a TOPN
  visual filter is reported in warnings, never silently ignored; visuals with visual filters force the compatibility path.
- `_resolve_sort`: PBIR sorts map to output column keys; a sort on an aggregated column targets the implicit measure's alias;
  sorts matching no output column are dropped (ORDER BY an unprojected column is invalid in Snowflake).
- `_untranslatable_calc_column_warnings`: spec warnings for calculated columns the converter can't translate.
- Count aggregate code 2 is a distinct count.

## 2. Frontend formatting resolver (`frontend/src/dashboard/pbi/`)
2.1 `literal.ts`: `decodeLiteral` (`'text'` with `''`, `12D`, `2L`, `1.5M`, `true/false`, `null`); `lit(node)` accepts
`{expr:{Literal:{Value}}}`, `{Literal:...}` or plain theme values; `litNumber/litBool/litString`; `shade(hex, pct)` (pct > 0 blends
toward white, < 0 toward black); `themeDataColor(id, pct)`: ColorId 0 = background, 1 = foreground, n >= 2 = dataColors[n-2];
`color(node, tokens)` resolves `{solid:{color}}`, ThemeDataColor and named theme colours (foregroundNeutralSecondary, tableAccent, ...).
2.2 `fonts.ts`: `ptToPx = pt * 4/3`; `fontSizePx('12' | 12 | '24pt' | '16px')`; `parseFontFamily("'Segoe UI Bold', wf_segoe-ui_bold,
helvetica" | "Segoe (Bold)" | "Calibri") -> {family, weight}`; `font(familyNode, sizeNode, defaultPt, defaultWeight)` -> FontSpec
`{family, sizePx, weight}`; `fontCss`.
2.3 `defaults.ts` - `PBI_DEFAULTS` (copy these values exactly):
```
dataColors: #118DFF #12239E #E66C37 #6B007B #E044A7 #744EC2 #D9B300 #D64550 #197278 #1AAB40 #15C6F4 #4092FF #FFA058 #BE5DC9 #F472D0 #B5A1FF
foreground #252423, background #FFFFFF, secondaryForeground #605E5C, fontFamily 'Segoe UI'
container.padding 5; title {sizePt 12, weight 400, color #252423}
axis {labelSizePt 9, labelColor #605E5C, gridlineColor #E9E9E9}
category {minWidthPx 20, innerPaddingPct 20, singleSlotPlotShare 1/3, tallestBarShare 0.885, maxLabelHeightFactor 0.3, maxBarFraction 0.18}
labels {sizePt 9, color #605E5C}; legend {sizePt 8, color #605E5C}
card {valueSizePt 27, categorySizePt 12, categoryColor #605E5C}
slicer {sizePt 10, dropdown {gapPx 11.5, insetPx 9, borderColor #EAEAEA, textPadTopPx 8, textPadLeftPx 6,
        chevron {w 15, h 7, rightPx 6, topPx 12, color #777777, strokePx 1.2}}}
table {headerSizePt 10, valuesSizePt 10, valuesColor #252423, headerBackground undefined, banding #F3F2F1, gridColor #EDEBE9, rowPaddingPx 3}
pie {labelRoomPx 70, legendShare 0.28, leaderRoomPx 32}; map {defaultFill #E6E6E6, borderColor #FFFFFF}
button {textSizePt 10, textColor #252423, textMarginPx 2, textBaselineShiftEm 0.09, fill undefined, outlineColor #B3B0AD,
        outlineWeightPx 1, roundedCurvePx 0, hoverDarken 0.1, shadow '2px 3px 6px rgba(0, 0, 0, 0.35)', glowColor #FFFFFF, glowBlurPx 8}
shape {fill #118DFF, lineColor #118DFF, lineWeightPx 1, roundedCurvePx 0, lineShade -0.25}
```
Base-theme `visualStyles` are NOT applied (Power BI pins the visual defaults of the authoring version); base-theme colours are.
2.4 `resolve.ts`: `buildTheme(payload) -> ResolvedTheme {tokens (dataColors, foreground, background, named colours), customStyles}`;
`PbiThemeContext`/`usePbiTheme`; `resolveVisual(spec, theme) -> ResolvedStyle`. Precedence per property: first selector-less entry
of visual `objects` / `visualContainerObjects` > custom theme `visualStyles[visualType]['*'][obj][0][prop]` then `['*']['*']` >
`PBI_DEFAULTS`. Mapping (object.property -> resolved field):
- container (`visualContainerObjects`): `background.show` (default on for data visuals; off for textbox, shape, basicShape, image,
  actionButton, visualGroup, unknown - unless an explicit background colour is set), `background.color` (default theme background),
  `background.transparency` (alpha), `border.show/color(#E6E6E6)/width(1)/radius(0)`, `padding.top/right/bottom/left` (5 for data
  visuals, 0 for chrome).
- title: `title.show` (default on except textbox, card, slicer, shape, basicShape, image, actionButton, pivotTable, tableEx,
  visualGroup, unknown; true for visuals without pbir), `title.text` (else spec title), `fontFamily`, `fontSize`, `fontColor`,
  `alignment` (left default), `background`; `showSetting` = the switch alone (a measure title supplies the text later).
- palette = theme dataColors; `fill` = `dataPoint.fill`; `fillByValue` from `dataPoint` selectors: `selector.metadata` = a measure's
  queryRef -> colour by measure name/display name; `selector.data[0].scopeId.Comparison` (Left Column Property, Right literal) ->
  colour by category value, ONLY when the selector's entity matches the field's table (stale selectors ignored).
- categoryAxis: `show`, `labelColor`, `fontFamily`, `fontSize`, `preferredCategoryWidth` (Power BI's "Minimum category width";
  legacy `minCategoryWidth`) -> `minWidthPx` (default 20) + `preferredWidthSet`, `concatenateLabels` (default true), `innerPadding` (20).
- valueAxis: `show`, `labelColor`, fonts, `gridlineColor`, `gridlineShow` (true), `labelPrecision`, `labelDisplayUnits`.
- labels: `show`, `color`, fonts, `labelPrecision`, `labelDisplayUnits`, `percentageLabelPrecision`, `labelContentLayout`,
  `detailPercent` = `enableValueDataLabel` false + `enableDetailDataLabel` true + `detailContentType` "Percent of total";
  detail colour/font/precision. `slices.innerRadiusRatio / 100`. legend: `show`, `position`, `showTitle` (true), colour, fonts.
- card: value font from `labels` (27 pt, weight 600), value colour `labels.color` (theme foreground); `categoryLabels.show` (true),
  font (12 pt), colour.
- slicer: `header.show` (true), `header.text`, header/items fonts (`textSize`, 10 pt), `items.fontColor`.
- table/matrix: `columnHeaders` font (weight 600, 700 when `bold`), fontColor, backColor; `values` font, fontColorPrimary,
  backColorPrimary, backColorSecondary (banding #F3F2F1); `grid.gridHorizontal/Color/Weight`, `gridVertical/...`, `rowPadding` (3);
  `columnWidth` by `selector.metadata` (+ a selector-less default width); `columnFormatting.alignment` by metadata;
  `total.totals`/`total.show`, `total.label` ("Total"); `rowHeaders` font/colour, `showExpandCollapseButtons`; `values.valuesOnRow`.
- map: `dataPoint.fillRule.linearGradient2/3` min/mid/max colour stops (+ values) and `nullColoringStrategy` asZero;
  `defaultColors.defaultColor/borderColor`; `shape.projectionEnum`.
- `pageBackground(page, theme)` from page `objects.background`; `withAlpha(hex, alpha)`;
  `fieldColumnKey(field, available, used)`: explicit measures -> name, aggregated columns -> display-name alias, bare columns ->
  "table.column", falling back across candidates present in the result.
2.5 `chrome.ts`: buttons/shapes/images. `stateProp(objects, obj, prop, state)` precedence: state selector (hover/press) > default
selector > unselected entry > defaults. `resolveButton` -> `ButtonStyle` (fill, outline, text font/colour/alignment, text margins from
`text.left/right/top/bottomMargin` else 2 px, icon incl. custom image `icon.shapeType = custom`, shadow + glow CSS box-shadow,
rounded corners); `resolveShape` -> `ShapeStyle` (rectangle, rounded rectangle, oval, line, triangle; fill, line colour/weight;
legacy shapes without an outline object draw a 1 px outline in dataColors[0] shaded -25%; `rotation.angle`: a line rotated a quarter turn
spans the box vertically); `imageFit` (Fit stretches, Fill covers, Normal); `resourceItem`.

## 3. Page canvas (`PageCanvas.tsx`)
- Scales the report page to its container: `canvasScale(mode, ...)`: FitToPage uses the limiting dimension, FitToWidth ignores
  height, ActualSize = 1; `fit="auto"` honours the page's `display_option`; `vertical_alignment` Middle centres. Measure the nearest
  scrolling ancestor's width (ResizeObserver on the parent, not the canvas) to avoid feedback loops. Background = page background or
  theme background. Provides `CanvasScaleContext`.
- Z order: CSS z-index is the integer RANK of each visual's (possibly fractional) z.
- Hidden: `isEffectivelyHidden(spec, overrides, visuals)` = own flag or bookmark override, including hidden ancestor groups.
- Visuals without data (untranslated/unsupported/query error) render their normal chrome and renderer over an empty result
  (`emptyResult`) plus an info icon with a short reason (`unavailableReason`, `noDataLabel`); amber messages only in annotations mode.
  A pane with hand-edited SQL is queried and has no notice. Notices: one per stack of overlapping visuals (`groupNotices`) drawn in
  their own top layer, placed so none overlap (`placeNotices`; narrow ones show only the symbol); tiny decoration visuals and chrome
  never get one.
- `queryVisualNames(page)`: data visuals + panes with manual SQL + title queries.
- `titleFromResult(result)` reads `<visual>#title`; the canvas shows it when the title switch is on.
- `alignButtonRows`: a row of label buttons shares one text line (vertical offset).
- Chrome visuals have no card chrome; group containers and visuals whose action can't run get `pointer-events: none`; a group's
  background from `visualGroup.objects` is drawn.
- Matrix drill context `MatrixDrillContext`/`useMatrixDrill` (`dashboard/drill.ts`): loads an expanded row's children.

## 4. Visuals
- `ChartVisual.tsx::pbiChartOption(spec, data, st, scale)` (ECharts): category slot = `max(minWidthPx, ...)`; with "Minimum category
  width" and <= 1 category the slot is `max(min width, plot/3)` and bars are `slot x (1 - innerPadding)` shared by the series;
  without preferredCategoryWidth a lone bar is capped at 18% of the axis; preferredCategoryWidth drives scrolling; labels go 45° when
  they overflow their slot and 90° once the axis scrolls (nested axes go 90°); hidden axes hide their labels (else containLabel shifts
  the plot); columns with outside labels and no value axis draw the tallest at 0.885 of the plot with headroom for its label; horizontal
  bars reserve right room for value labels; Auto data-label units choose one unit for the whole visual (`autoDisplayUnits`) and column
  labels default to Auto; 100% stacked normalises per category (per-measure colours from metadata selectors, detail percent labels);
  stacked series without an explicit colour take the default colour; pie: explicit slice colours win, palette to the rest in order,
  sized so outside labels and a right legend fit, BLANK/zero slices get no slice/label, labels avoid overlap, one line unless
  `labelContentLayout` says otherwise; donut ring = `innerRadiusRatio`; measures-only charts get one unlabelled placeholder category per
  data point (`axisData`) so stacking works; blank spacer measures draw nothing; "show as % of grand total" divides by `totals`; multi-field
  Category axes render nested when `concatenateLabels=false` (inner labels + one outer label per group). Axis label layout (from the
  stable copy): `fitLabel(text, widthPx, fontPx, maxLines=2)` (wrap at spaces, max 2 lines, then "…", '' below ~3 chars at
  0.55 em per glyph); `grid.left += firstLabelOverhang` for 45° labels; outer nested labels fitted per group with `interval`/`formatter`
  and `lineHeight = round(labelPx*1.25)`; `grid.bottom` reserves `ceil(labelPx*1.25*outerLines)+6`; category axes `triggerEvent: true`.
- `EChart.tsx`: click calls `onItemClick` only for `componentType === 'series'`; mouseover on an xAxis/yAxis label sets the chart
  element's `title` to the full label, mouseout clears it; `keepScrollWindow` keeps the current dataZoom window when the same categories
  are re-applied; option memoized.
- Scrollbars (`visuals/scrollbar.ts`): `scrollThickness(scale) = 10/scale` canvas px (min 8), `scrollZoom({axis, axisIndex, endValue,
  scale, position})` = fixed window (`zoomLock`) slider + `inside` dataZoom (mouse wheel); used by charts, combo, time windows.
- `TableVisual.tsx`: `pbiTableColumns` (projection order, display names, explicit widths, alignment; unlisted columns keep query order),
  matrix `valuesOnRow` (measures as rows), collapsed-level matrices with +/- expanding child rows (indented), totals row computed
  server-side (`total.label`), word-wrap inside sized columns, never stretched to the container, banding, grid lines, row padding.
- `SlicerVisual.tsx`: Power BI dropdown geometry from `PBI_DEFAULTS.slicer.dropdown` (box inset, open at the bottom and clipped,
  chevron); the saved/current selection is always listed; no duplicate header when the container title names it; with a query error it
  still shows its "All" dropdown.
- `CardVisual.tsx`: value centred with optional category label; an overlay card whose measure is blank text draws nothing.
- `KpiCardVisual.tsx`: name, actual value, "<prefix> x.x% ▲/▼" comparison with `target1DecimalPlaces` (else the measure format, else 1
  decimal percent), thin arrows; without data the name renders and values show an em dash.
- `TextboxVisual.tsx`: paragraphs/runs with Power BI default run size, explicit background colour shown.
- `ChromeVisuals.tsx`: `ButtonVisual` (per-state fill/outline/text/icon, measure-driven text), `ShapeVisual` (SVG), `ImageVisual`
  (resource URL or linked URL, fit modes).
- `MapVisual.tsx` + `mapUtil.ts`: filledMap/shapeMap as an ECharts choropleth over US states GeoJSON with an albersUsa projection
  (Alaska/Hawaii insets; 50 states + DC); state matching case-insensitive by full name or USPS code (unknown values like "Not Mapped" are not
  drawn); colour by the Value/Color saturation measure (not the first tooltip projection); fillRule min/max default to data extremes, mid
  halfway; measure labels use visual display names; selection toggles by data value.
- `ComboVisual.tsx`: Y as columns, Y2 as lines on axis 2, scrollbar, time axes label every point.
- `format.ts`: VB/Power BI format strings: sections `positive;negative;zero` with literal decoration (parentheses), quoted or trailing
  unquoted suffixes (`"M"`, `bnM`, `K`), scaling commas (each divides by 1000, also before the decimal point), `0` required / `#` optional
  digits (`\$#,0.###` prints integers without decimals), percent; `formatWithDisplayUnits(v, fmt, units, precision)` (0 = Auto by
  magnitude K/M/bn, 1 = None, fixed units; precision: labelPrecision > the format's required digits > magnitude default); blank /
  whitespace-only text is not 0; numeric strings from Snowflake coerced.

## 5. Navigation and bookmarks (`dashboard/navigation.ts`, `DashboardApp.tsx`)
- `useReportNavigation(spec, ...)`: page tabs (hidden pages excluded; a tab click is a fresh start), buttons with actions: Bookmark
  (apply), PageNavigation (go to page, hidden pages reachable), Back (history), WebUrl (open in a new tab), Drillthrough (phase 11).
- `bookmarkVisibility(bookmark)` and `bookmarkPage(bookmark)`; `targets` restrict a bookmark to its captured visuals only when present.
- Missing bookmark (not in the export): re-hide the nearest as-authored hidden ancestor group (`authoredHiddenAncestor`), but only when no
  authored-visible visual on the page is hidden by an override (else no-op); missing-bookmark visuals without a hidden ancestor get
  `pointer-events: none`.
- A child of a hidden group is hidden until a bookmark shows the group.
- `BookmarksMenu`: Power BI's View > Bookmarks pane as a menu listing every bookmark by display name; choosing one applies it.
- Edit interactions: slicer filters are tagged with their slicer and skip visuals whose interaction is NoFilter
  (`interactions.ts::buildVisualQueryFilters`); repeat click toggles a selection; selections become page filters.

## 6. React project export and published dashboards
- `services/export.py` ("Download React project", `POST /dashboard/export`): the list of front-end source files copied into the exported
  Vite project must include every new renderer file (`dashboard/navigation.ts`, `dashboard/pbi/{chrome,defaults,fonts,literal,resolve}.ts`,
  `dashboard/visuals/{ChromeVisuals,KpiCardVisual}.tsx`, and any other module the dashboard imports - phases 10/11 add
  `filtersPaneState.ts`, `FiltersPane.tsx`, `dataPoint.ts`, `drillthrough.ts`, `DrillMenu.tsx`, `TooltipPage.tsx`, `drill.ts`,
  `visuals/{mapUtil,scrollbar}.ts`); `export_dashboard(..., resources=None)` writes report images to `public/resources/<name>`. Add a test
  that the exported project type-checks its import graph (every relative import resolves to a file in the zip).
- `api/published_dashboards.py`: published `/dashboard/query` goes through `run_batch_query(..., source="published")`; add
  `POST /dashboard/query/drill` (`PublishedDrillQueryRequest {page, visual, direction, level_key, parent_filters, filters}` bound to the
  publication's connection) and `POST /dashboard/filter-values` (phase 10).
- `services/code_docs.py`: tier labels include `3: "3 (hand-written SQL)"`.
- Wizard Preview step (`steps/PreviewStep.tsx`): uses the same rendering pipeline as the full dashboard (`useReportNavigation`, bookmarks
  menu, `queryVisualNames`, matrix drill rows, resource URLs, synced slicers and default pane filters from phase 10, without the pane) and a
  "Download standalone dashboard ⬇" button (phase 12). `AppShell.tsx`: on the Preview step `<main>` uses `overflow-x-auto` and the content is
  full width (`w-full max-w-none px-2 py-4`) instead of the centred max-width container.

## Files
Create: `frontend/src/dashboard/pbi/{literal,fonts,defaults,resolve,chrome}.ts`, `dashboard/navigation.ts`, `dashboard/drill.ts`,
`dashboard/visuals/{ChromeVisuals.tsx,KpiCardVisual.tsx,mapUtil.ts,scrollbar.ts}`.
Modify: `runtime/dashboard.py`, `api/dashboards.py` (resources, drill, title results, totals), `api/published_dashboards.py`,
`services/export.py` (bundle referenced images), `dashboard/{DashboardApp,PageCanvas}.tsx`, `dashboard/types.ts`, `dashboard/api.ts`,
`dashboard/format.ts`, `dashboard/interactions.ts`, all touched visuals, `steps/PreviewStep.tsx`, `steps/VisualParity.tsx`
(Visual Parity renders with the same pipeline).

## Tests (generic fixtures only; build synthetic PBIR/specs in the tests)
Backend: `test_dashboard_pbir_passthrough.py` (visual/page/theme passthrough; missing base theme -> empty), `test_layout_parity.py` (export
collects button icon images; nested upload report dir, resources and base theme found; display option + alignment; stored bundles read new
fields from source; default FitToPage; untranslated measure keeps layout; unknown custom visual -> unsupported_type; KPI card mapped by
signature; 100% stacked), plus resources endpoint traversal rejection, visual link actions, bookmark page/visibility and target rules,
group children keep their own hidden flag, image source.
Frontend: `pbiResolve.test.ts`, `pbiCalibration.test.ts`, `layoutParity.test.tsx`, `chromeNavigation.test.tsx` (a synthetic multi-level
menu navigation), `mapVisual.test.ts`, `scrollbar.test.tsx`, `format.test.ts`, `interactions.test.ts` - with the behaviours listed in
sections 2-5 (each bullet above is a test case). Create `src/test/renderingParity.test.tsx` for the chart geometry rules of section 4
using ECharts SSR (`echarts.init(null, null, {ssr: true, renderer: 'svg', width, height})` + `renderToSVGString()`; bars are
`<path d="M x yBottom l...Z">`): measures-only stacking, single-category slot/bar width, shared baseline with hidden axes, outside-label
headroom, axis label overhang, nested outer label fitting, fitLabel cases (`fitLabel('Portfolio 12', 71, 18.67) === 'Portf…\n12'`,
150 -> 'Portfolio 12', 110 -> 'Portfolio\n12', 'Alpha and Beta Gamma Portfolio' at 110 -> 'Alpha and\nBeta Gamm…', 20 -> '').

## Done criteria
A synthetic report with themes, groups, buttons, bookmarks, a matrix and a map renders per the rules above; tests pass.

 