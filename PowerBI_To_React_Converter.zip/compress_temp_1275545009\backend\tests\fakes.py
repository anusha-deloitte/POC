"""Shared test doubles: a catalog-aware fake Snowflake cursor and a scripted LLM client."""

from __future__ import annotations

import re

from app.binding.resolver import build_binding_map
from app.ir.model import SemanticModel
from tests.test_validation import FakeCursor


class FakeConnection:
    def close(self):
        pass


class CatalogCursor(FakeCursor):
    """FakeCursor that also answers SHOW DATABASES / INFORMATION_SCHEMA queries from the model's
    own bindings, so the pipeline's case check and pre-flight see a reachable, exact catalog."""

    def __init__(self, model: SemanticModel, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.connection = FakeConnection()
        self._model = model
        self._bindings = [
            b
            for b in build_binding_map(model).bindings.values()
            if b.database and b.schema_name and b.object_name and not b.native_query
        ]

    def execute(self, sql: str):
        low = sql.lower()
        if low.startswith("show databases"):
            self.executed.append(sql)
            self.description = [("created_on",), ("name",)]
            self._rows = [("x", d) for d in sorted({b.database for b in self._bindings})]
        elif "information_schema.schemata" in low:
            self.executed.append(sql)
            self.description = [("schema_name",)]
            self._rows = [(s,) for s in sorted({b.schema_name for b in self._bindings})]
        elif "information_schema.tables" in low and "table_schema =" in low:
            self.executed.append(sql)
            schema = re.search(r"table_schema = '([^']*)'", sql).group(1)
            self.description = [("table_name",)]
            self._rows = [(b.object_name,) for b in self._bindings if b.schema_name == schema]
        elif "information_schema.tables" in low:
            self.executed.append(sql)
            self.description = [("table_schema",), ("table_name",)]
            self._rows = [(b.schema_name, b.object_name) for b in self._bindings]
        elif "information_schema.columns" in low:
            self.executed.append(sql)
            table = re.search(r"table_name = '([^']*)'", sql).group(1)
            self.description = [("column_name",)]
            cols: list[tuple[str]] = []
            for b in self._bindings:
                if b.object_name == table:
                    t = self._model.table(b.table)
                    cols = [(c.source_column or c.name,) for c in (t.columns if t else [])]
            self._rows = cols
        elif "current_role" in low:
            self.executed.append(sql)
            self.description = [("a",), ("b",)]
            self._rows = [("ANALYST", "WH")]
        else:
            super().execute(sql)


class ScriptedLLM:
    """Fake chat client returning scripted replies; records every call."""

    provider = "fake"
    label = "AI"

    def __init__(self, replies):
        self.replies = list(replies)
        self.calls: list[list[dict]] = []

    def chat(self, messages, **kwargs):
        self.calls.append([dict(m) for m in messages])
        reply = self.replies.pop(0) if len(self.replies) > 1 else self.replies[0]
        return reply(messages) if callable(reply) else reply


class DuckCursor:
    """Cursor over a DuckWorld: catalog queries are answered from its model, everything else is
    transpiled and executed on DuckDB. `omit_tables` hides model tables from INFORMATION_SCHEMA
    (an unreachable table); `fail_when(sql, nth)` injects failures."""

    def __init__(self, world, omit_tables=(), fail_when=None, state=None, catalog_error=False):
        self.world = world
        self.catalog_error = catalog_error
        self.omit = set(omit_tables)
        self.fail_when = fail_when
        self._state = state if state is not None else {"seen": {}, "executed": []}
        self.executed = self._state["executed"]
        self.description: list = []
        self._rows: list = []
        self._con = world.con.cursor()
        self.connection = self

    def cursor(self):
        return DuckCursor(
            self.world, self.omit, self.fail_when, self._state, self.catalog_error
        )

    def close(self):
        pass

    def _objects(self):
        out = []
        for b in self.world.bindings.bindings.values():
            if b.object_name and b.table not in self.omit:
                out.append(b)
        return out

    def execute(self, sql: str, *args):
        from app.runtime.accelerate import to_duckdb_sql

        self.executed.append(sql)
        low = sql.lower()
        if low.startswith("show databases"):
            self.description = [("created_on",), ("name",)]
            self._rows = [("x", "DB")]
            return self
        if "information_schema.schemata" in low:
            self.description = [("schema_name",)]
            self._rows = [("PUBLIC",)]
            return self
        if self.catalog_error and "information_schema.tables" in low:
            raise RuntimeError("Schema 'DB.PUBLIC' does not exist or not authorized.")
        if "information_schema.tables" in low and "table_schema =" in low:
            self.description = [("table_name",)]
            self._rows = [(b.object_name,) for b in self._objects()]
            return self
        if "information_schema.tables" in low:
            self.description = [("table_schema",), ("table_name",)]
            self._rows = [("PUBLIC", b.object_name) for b in self._objects()]
            return self
        if "information_schema.columns" in low:
            name = re.search(r"table_name = '([^']*)'", sql).group(1)
            self.description = [("column_name",)]
            self._rows = []
            for b in self.world.bindings.bindings.values():
                if b.object_name == name:
                    t = self.world.model.table(b.table)
                    self._rows = [(c.name,) for c in t.columns if c.expression is None]
            return self
        if "current_role" in low:
            self.description = [("a",), ("b",)]
            self._rows = [("ANALYST", "WH")]
            return self
        seen = self._state["seen"]
        seen[sql] = seen.get(sql, 0) + 1
        if self.fail_when is not None and self.fail_when(sql, seen[sql]):
            raise RuntimeError("injected failure")
        res = self._con.execute(to_duckdb_sql(sql, self.world.bindings))
        self.description = [(d[0],) for d in res.description]
        self._rows = res.fetchall()
        return self

    def fetchall(self):
        return self._rows

    def fetchone(self):
        return self._rows[0] if self._rows else None
