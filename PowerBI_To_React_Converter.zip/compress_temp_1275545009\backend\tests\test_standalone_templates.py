"""Phase 12: query templates == live queries (DuckDB). A template is the generated SQL with a slot
wherever a filter on a column would go; rendering it with the request's filters must mean the same
as building the query live with those filters."""

from __future__ import annotations

import datetime as dt
import itertools
import re

import pytest

from app.runtime import sql_render as sr
from app.runtime.accelerate import to_duckdb_sql
from app.runtime.engine import (
    DimensionRef,
    FilterClause,
    MeasureRefSpec,
    QueryPlanError,
    QuerySpec,
)
from tests.duck import DuckWorld

MONTHS = [
    dt.date(2023, 1, 15),
    dt.date(2023, 7, 15),
    dt.date(2024, 1, 15),
    dt.date(2024, 2, 15),
    dt.date(2024, 7, 15),
]
ROWS = [
    (1, MONTHS[0], 1, "N", 10), (2, MONTHS[1], 1, "S", 20), (3, MONTHS[2], 1, "N", 30),
    (4, MONTHS[2], 2, "S", 40), (5, MONTHS[3], 2, "N", 50), (6, MONTHS[4], 3, "N", 60),
    (7, MONTHS[4], 2, None, 70), (8, MONTHS[1], 3, "S", 5),
]  # fmt: skip

SLOTS = [("Cat", "cat_name"), ("Sales", "region"), ("Date", "year"), ("Date", "date_key")]


@pytest.fixture(scope="module")
def world() -> DuckWorld:
    return DuckWorld(
        {
            "Sales": (["id", "date_key", "cat_key", "region", "amount"], ROWS),
            "Cat": (["cat_key", "cat_name"], [(1, "A"), (2, "B"), (3, "C"), (4, "D")]),
            "Date": (
                ["date_key", "month", "year"],
                [(d, d.month, d.year) for d in MONTHS],
            ),
        },
        rels=[("Sales", "cat_key", "Cat", "cat_key"), ("Sales", "date_key", "Date", "date_key")],
        measures={
            "Total": "SUM(Sales[amount])",
            "Rows": "COUNTROWS(Sales)",
            "LY": "CALCULATE([Total], SAMEPERIODLASTYEAR('Date'[date_key]))",
            "Window": "CALCULATE([Total], ALL('Date'), DATESBETWEEN('Date'[date_key], DATE(2023,1,1), DATE(2023,12,31)))",
            "Flag": "IF(ISFILTERED(Cat[cat_name]), 1, 0)",
        },
        measure_table="Sales",
    )


def spec(dims=(), measures=("Total",)) -> QuerySpec:
    return QuerySpec(
        dimensions=[DimensionRef(table=t.split(".")[0], column=t.split(".")[1]) for t in dims],
        measures=[MeasureRefSpec(name=m) for m in measures],
    )


def run(world: DuckWorld, sql: str) -> list[tuple]:
    rows = world.con.execute(to_duckdb_sql(sql, world.bindings)).fetchall()
    return sorted(rows, key=lambda r: tuple((v is None, str(v)) for v in r))


def live(world: DuckWorld, q: QuerySpec, filters: list[FilterClause]) -> list[tuple]:
    sql, _ = world.engine().build_sql(q.model_copy(update={"filters": filters}))
    return run(world, sql)


def templated(world: DuckWorld, q: QuerySpec, filters: list[FilterClause], slots=SLOTS):
    sql, meta, _ = world.engine().build_template(q, slots)
    rendered, unapplied = sr.render_template(sql, meta, filters)
    return run(world, rendered), rendered, unapplied, sql, meta


def clause(table, column, op="in", *values, **kw) -> FilterClause:
    return FilterClause(table=table, column=column, op=op, values=list(values), **kw)


SELECTIONS = {
    "cat": [clause("Cat", "cat_name", "in", "A", "B")],
    "region": [clause("Sales", "region", "in", "N")],
    "year": [clause("Date", "year", "in", 2024)],
    "dates": [clause("Date", "date_key", "gte", "2024-01-01")],
}

VISUALS = {
    "bars": spec(["Cat.cat_name"]),
    "months": spec(["Date.month"], ["Total", "LY"]),
    "card": spec([], ["Total"]),
    "two dims": spec(["Cat.cat_name", "Date.year"], ["Total", "Rows"]),
}


@pytest.mark.parametrize("visual", VISUALS)
def test_no_selection(world, visual):
    q = VISUALS[visual]
    assert templated(world, q, [])[0] == live(world, q, [])


@pytest.mark.parametrize("visual", VISUALS)
@pytest.mark.parametrize("slot", SELECTIONS)
def test_every_slot_alone(world, visual, slot):
    q = VISUALS[visual]
    flt = SELECTIONS[slot]
    assert templated(world, q, flt)[0] == live(world, q, flt)


@pytest.mark.parametrize("visual", VISUALS)
def test_all_slots_together(world, visual):
    q = VISUALS[visual]
    flt = list(itertools.chain.from_iterable(SELECTIONS.values()))
    assert templated(world, q, flt)[0] == live(world, q, flt)


def test_every_pair_of_slots(world):
    q = VISUALS["bars"]
    for a, b in itertools.combinations(SELECTIONS, 2):
        flt = SELECTIONS[a] + SELECTIONS[b]
        assert templated(world, q, flt)[0] == live(world, q, flt), (a, b)


def test_two_clauses_on_one_column_and_a_null_selection(world):
    q = VISUALS["bars"]
    two = [clause("Sales", "region", "in", "N", "S"), clause("Sales", "region", "neq", "S")]
    assert templated(world, q, two)[0] == live(world, q, two)
    nulls = [clause("Sales", "region", "in", None)]
    assert templated(world, q, nulls)[0] == live(world, q, nulls)
    mixed = [clause("Sales", "region", "not_in", None, "S")]
    assert templated(world, q, mixed)[0] == live(world, q, mixed)


def test_an_empty_selection_matches_nothing(world):
    q = VISUALS["card"]
    out, rendered, *_ = templated(world, q, [clause("Cat", "cat_name", "in")])
    assert "1=0" in rendered
    assert out in ([(None,)], [])


def test_inactive_template_has_no_markers_left_and_no_extra_join(world):
    q = VISUALS["card"]
    _, rendered, _, template, meta = templated(world, q, [])
    assert "{{" not in rendered and "}}" not in rendered
    assert re.search(r"JOIN", rendered) is None  # no semi-join, no filter-only join
    assert "IN (SELECT" not in rendered
    live_sql, _ = world.engine().build_sql(q)
    assert rendered.count("JOIN") == live_sql.count("JOIN")
    assert "{{#k:" in template  # the filter-only joins are conditional blocks
    assert meta["slots"] and meta["preds"]


def test_a_filter_only_dimension_is_a_semi_join_only_when_active(world):
    q = VISUALS["card"]
    _, active, *_ = templated(world, q, SELECTIONS["cat"])
    assert "IN (SELECT" in active
    assert active.count("JOIN") == 0


def test_filter_on_a_grain_dimension_projects_its_column_only_when_active(world):
    q = spec(["Cat.cat_name"])
    _, off, *_ = templated(world, q, [])
    _, on, *_ = templated(world, q, [clause("Cat", "cat_name", "in", "A")])
    live_off, _ = world.engine().build_sql(q)
    assert off.count("DISTINCT") == live_off.count("DISTINCT")
    assert on != off


def test_guard_mirrors_the_live_refusal():
    """Window bounds read the filter context of Date: a slot on a table that cross-filters Date
    (a snowflake parent) is refused when selected, exactly as the live query is."""
    d1, d2 = dt.date(2024, 1, 15), dt.date(2024, 2, 15)
    w = DuckWorld(
        {
            "Sales": (["id", "date_key", "amount"], [(1, d1, 10), (2, d2, 20)]),
            "Date": (["date_key", "month_key"], [(d1, 1), (d2, 2)]),
            "Month": (["month_key", "season"], [(1, "W"), (2, "S")]),
        },
        rels=[
            ("Sales", "date_key", "Date", "date_key"),
            ("Date", "month_key", "Month", "month_key"),
        ],
        measures={
            "Total": "SUM(Sales[amount])",
            "Win": "CALCULATE([Total], ALL('Date'[date_key]), DATESBETWEEN('Date'[date_key], DATE(2024,1,1), MAX('Date'[date_key])))",
        },
        measure_table="Sales",
    )
    slots = [("Month", "season"), ("Sales", "id")]
    q = spec([], ["Win"])
    sql, meta, _ = w.engine().build_template(q, slots)
    assert meta["guards"], "the slot on Month cross-filters the Date window bounds"
    month = [clause("Month", "season", "in", "W")]
    with pytest.raises(sr.TemplateError, match="date-window bounds"):
        sr.render_template(sql, meta, month)
    with pytest.raises(QueryPlanError, match="date-window bounds"):
        w.engine().build_sql(q.model_copy(update={"filters": month}))
    # a slot that does not cross-filter the bounds still renders, and an empty one always does
    ok = [clause("Sales", "id", "in", 1)]
    assert run(w, sr.render_template(sql, meta, ok)[0]) == live(w, q, ok)
    assert sr.render_template(sql, meta, [])[0]


def test_unplaceable_slots_are_reported_not_guessed(world):
    q = spec(["Cat.cat_name"])  # a slicer domain: filters on other tables don't reach it
    sql, meta, _ = world.engine().build_template(q, SLOTS)
    assert {s["column"] for s in meta["slots"].values()} <= {
        "cat_name",
        "region",
        "year",
        "date_key",
    }
    out, unapplied = sr.render_template(sql, meta, [clause("Nowhere", "x", "in", 1)])
    assert unapplied == [
        "[OVERLAY:UNREACHABLE_FILTER] filter on Nowhere cannot reach this visual; ignored"
    ]
    assert "{{" not in out


def test_isfiltered_follows_the_active_slots(world):
    q = spec([], ["Flag"])
    off, *_ = templated(world, q, [])
    on, *_ = templated(world, q, SELECTIONS["cat"])
    assert off == live(world, q, []) and on == live(world, q, SELECTIONS["cat"])
    assert off != on


@pytest.mark.parametrize(
    "op,values",
    [
        ("contains", ["lph"]), ("not_contains", ["lph"]), ("starts_with", ["a"]), ("not_starts_with", ["a"]),
        ("is_blank", []), ("is_not_blank", []), ("is_empty", []), ("is_not_empty", []),
        ("eq", ["A"]), ("neq", ["A"]), ("gt", ["A"]), ("lte", ["B"]),
    ],
)  # fmt: skip
def test_pane_operators_template_equals_live(world, op, values):
    q = VISUALS["bars"]
    flt = [clause("Cat", "cat_name", op, *values)]
    assert templated(world, q, flt)[0] == live(world, q, flt)


def test_or_filters_template_equals_live(world):
    q = VISUALS["bars"]
    flt = [FilterClause(table="Cat", column="cat_name", op="or",
                        clauses=[clause("Cat", "cat_name", "eq", "A"), clause("Cat", "cat_name", "eq", "C")])]  # fmt: skip
    assert templated(world, q, flt)[0] == live(world, q, flt)


def relative(unit, direction, n=1, calendar=False, include_today=False):
    from app.runtime.dashboard import relative_bounds

    lower, upper = relative_bounds(
        {
            "direction": direction,
            "n": n,
            "unit": unit,
            "calendar": calendar,
            "include_today": include_today,
        }
    )
    return FilterClause(
        table="Date", column="date_key", op="relative", params={"lower": lower, "upper": upper}
    )


def test_relative_and_date_range_template_equals_live(world):
    q = VISUALS["bars"]
    today = "DATE '2024-07-20'"
    for flt in (
        [relative("month", "this", calendar=True)],
        [relative("month", "last", 6, calendar=True)],
        [relative("year", "this", calendar=True)],
        [relative("day", "last", 30, include_today=True)],
        [
            FilterClause(
                table="Date",
                column="date_key",
                op="between_dates",
                values=["2024-01-01", "2024-03-01"],
            )
        ],
        [
            FilterClause(
                table="Date", column="date_key", op="between_dates", values=[None, "2023-12-31"]
            )
        ],
    ):
        eng = world.engine()
        eng.today_sql = today
        live_sql, _ = eng.build_sql(q.model_copy(update={"filters": flt}))
        sql, meta, _ = world.engine().build_template(q, SLOTS)
        rendered, _ = sr.render_template(sql, meta, flt, today=today)
        assert run(world, rendered) == run(world, live_sql), flt[0].op


def test_template_refusals(world):
    sql, meta, _ = world.engine().build_template(VISUALS["bars"], SLOTS)
    with pytest.raises(
        sr.TemplateError, match="Top N filters are not available in the standalone dashboard"
    ):
        sr.render_template(sql, meta, [clause("Cat", "cat_name", "topn", n=1)])
    with pytest.raises(sr.TemplateError, match="unknown filter op in_query"):
        sr.render_template(sql, meta, [clause("Cat", "cat_name", "in_query")])
    with pytest.raises(sr.TemplateError, match="needs at least one value"):
        sr.render_template(sql, meta, [clause("Cat", "cat_name", "contains")])


def test_live_queries_are_unaffected(world):
    eng = world.engine()
    q = VISUALS["bars"]
    before, _ = eng.build_sql(q)
    eng.build_template(q, SLOTS)
    after, _ = eng.build_sql(q)
    assert before == after and "{{" not in after
    with pytest.raises(QueryPlanError):
        eng.build_sql(
            q.model_copy(
                update={
                    "filters": [
                        FilterClause(
                            table="Cat", column="cat_name", op="slot", params={"sid": "s0"}
                        )
                    ]
                }
            )
        )


def test_slicer_domain_template(world):
    q = spec(["Cat.cat_name"], [])
    out, rendered, unapplied, *_ = templated(world, q, [clause("Cat", "cat_name", "contains", "a")])
    assert out == live(world, q, [clause("Cat", "cat_name", "contains", "a")])
    assert "{{" not in rendered
