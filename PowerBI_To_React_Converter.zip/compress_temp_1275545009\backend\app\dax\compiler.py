"""Compile DAX AST -> Metric Algebra (Tier 0/1).

A measure compiles to LEAF AGGREGATES + a scalar COMBINER:

    Volume Effect =
        VAR PriorUnitCost = CALCULATE(DIVIDE([Allowed], [Lines]), SPLY(...))
        VAR CurLines  = [Lines]
        VAR PriorLines = CALCULATE([Lines], SPLY(...))
        RETURN (CurLines - PriorLines) * PriorUnitCost

    leaves:  __m0 = SUM(ALLOWED)  ctx={shift: sply}
             __m1 = COUNT(LINES)  ctx={shift: sply}
             __m2 = COUNT(LINES)  ctx={}
    expr:    ((__m2) - (__m1)) * (IFF(__m1=0 OR __m1 IS NULL, NULL, __m0/__m1))

Each leaf is evaluated by the semantic runtime as its own aggregate over its
own filter/time context (same GROUP BY keys), then combined — the only way
measures mixing shifted and unshifted terms produce correct numbers.

Fidelity: DIVIDE -> IFF(den=0 OR NULL, alt, num/den); BLANK() -> NULL; DAX's blank arithmetic and
blank comparisons are reproduced. Anything outside the tier-1 surface raises DaxUnsupported
(-> tier 2 queue); nothing is ever guessed.
"""

from __future__ import annotations

import dataclasses
import hashlib
import time
from dataclasses import dataclass, field

from app.binding.resolver import quote_ident
from app.dax.parser import (
    BinOp,
    Blank,
    Bool,
    ColumnRef,
    DaxParseError,
    FuncCall,
    MeasureRef,
    Num,
    Str,
    TableCtor,
    TableRef,
    UnaryOp,
    VarExpr,
    VarRef,
    parse_dax,
)
from app.ir.model import Measure, SemanticModel, SummarizeBy, Table


class DaxUnsupported(Exception):
    """Measure needs Tier 2 (LLM) or human authoring."""


@dataclass(frozen=True)
class FilterPredicate:
    table: str
    sql: str
    cols: frozenset = frozenset()  # (table, column) pairs the predicate reads


@dataclass(frozen=True)
class TimeShift:
    kind: str  # sply | rolling | ytd
    date_table: str
    date_column: str
    n: int = 0
    unit: str = "month"


@dataclass(frozen=True)
class WindowAvg:
    """AVERAGEX(DATESINPERIOD(...), [M]): average of the measure evaluated
    per period — avg-of-ratios, not ratio-of-sums."""

    measure: str
    date_table: str
    date_column: str
    n: int
    unit: str = "month"


@dataclass(frozen=True)
class Context:
    """Filter context a leaf aggregate is evaluated under."""

    filters: tuple[FilterPredicate, ...] = ()
    # table names (str) cleared by ALL/REMOVEFILTERS, "*" for everything, and
    # (table, column) pairs cleared by ALL(T[c]) / a column predicate
    clears: frozenset = frozenset()
    time_shift: TimeShift | None = None
    # (from_table.from_col, to_table.to_col) pairs activated by USERELATIONSHIP
    use_relationships: tuple[tuple[str, str], ...] = ()
    # (table, column) whose current filter survives a table-level clear (ALLEXCEPT, keep idiom)
    keeps: frozenset = frozenset()

    def with_filter(self, p: FilterPredicate) -> Context:
        return dataclasses.replace(self, filters=self.filters + (p,))

    def with_clear(self, table: str, base: tuple = ()) -> Context:
        """Clear a table (or "*"); predicates of the incoming context (`base`) on it are dropped
        too, predicates added later by the same CALCULATE are not."""
        kept = tuple(
            p for p in self.filters if not (p in base and (table == "*" or p.table == table))
        )
        shift = self.time_shift
        if shift is not None and (table == "*" or table == shift.date_table):
            shift = None  # clearing the date table removes the time-intelligence filter too
        return dataclasses.replace(self, clears=self.clears | {table}, filters=kept, time_shift=shift)

    def with_col_clear(self, table: str, column: str, base: tuple = ()) -> Context:
        kept = tuple(
            p
            for p in self.filters
            if not (p in base and p.table == table and p.cols == frozenset({(table, column)}))
        )
        shift = self.time_shift
        if shift is not None and (table, column) == (shift.date_table, shift.date_column):
            shift = None
        return dataclasses.replace(self, clears=self.clears | {(table, column)}, filters=kept, time_shift=shift)

    def with_keep(self, table: str, column: str) -> Context:
        return dataclasses.replace(self, keeps=self.keeps | {(table, column)})

    def with_shift(self, s: TimeShift) -> Context:
        if self.time_shift is not None and self.time_shift != s:
            raise DaxUnsupported("nested conflicting time shifts")
        return dataclasses.replace(self, time_shift=s)

    def with_relationship(self, pair: tuple[str, str]) -> Context:
        return dataclasses.replace(self, use_relationships=self.use_relationships + (pair,))


@dataclass(frozen=True)
class GroupLevel:
    """One GROUPBY level over the previous level's columns."""

    keys: tuple[str, ...]  # canonical columns kept (k0.., g<level>_<name>)
    added: tuple[tuple[str, str], ...] = ()  # (canonical name, aggregate SQL over the previous level)


@dataclass(frozen=True)
class GroupedPlan:
    """A leaf evaluated over groups: rows of `fact` are summarized by `keys`, optionally through
    GROUPBY `levels`, filtered by `cond`; the leaf SQL then aggregates the groups per grain."""

    fact: str
    keys: tuple[tuple[str, str], ...]  # (table, column) -> canonical names k0..kn
    base: tuple[tuple[str, str], ...] = ()  # (canonical name, aggregate SQL over fact rows)
    levels: tuple[GroupLevel, ...] = ()
    cond: str | None = None  # predicate over the final level's canonical columns


@dataclass(frozen=True)
class TopnPlan:
    """TOPN(n, ADDCOLUMNS(SUMMARIZE(T, D[key]), "x", agg), [x], order) used as a CALCULATE filter:
    the engine ranks the keys once (a top-level CTE) and filters D[key] to the winners."""

    key_table: str
    key_column: str
    n: int
    descending: bool
    x: object  # CompiledMeasure ranking each key (None when every key ties)
    all_rows: bool  # the ranking can't be filtered by the key: every row ties, nothing is dropped
    source_filter: str | None = None  # SUMMARIZE(FILTER(D, cond), ...) predicate on the key table


@dataclass
class Leaf:
    sql: str  # aggregate expression, e.g. SUM("T"."C")
    tables: set[str]
    ctx: Context
    # tables joined to the fact only to evaluate the expression (RELATED columns)
    related: set[str] = field(default_factory=set)
    grouped: GroupedPlan | None = None


@dataclass
class CompiledMeasure:
    name: str
    expr: str  # scalar SQL combining leaf aliases (__m0, __m1, ...)
    leaves: dict[str, Leaf] = field(default_factory=dict)
    window_avg: WindowAvg | None = None  # set => engine evaluates via window fn
    tier: int = 1
    # per-query tokens the engine expands: token -> ("scalar", table, agg sql) |
    # ("isf", function, table, column, tables of enclosing CALCULATE filters)
    tokens: dict[str, tuple] = field(default_factory=dict)
    # slicer-text assumptions of IFERROR(VALUE(...)): (table, column, literals compared to it)
    value_assumptions: list[tuple[str, str, tuple[str, ...]]] = field(default_factory=list)

    @property
    def tables(self) -> set[str]:
        out: set[str] = set()
        for leaf in self.leaves.values():
            out |= leaf.tables
        return out


_SIMPLE_AGGS = {
    "SUM": "SUM({})",
    "MIN": "MIN({})",
    "MAX": "MAX({})",
    "AVERAGE": "AVG({})",
    "COUNTA": "COUNT({})",
    "COUNT": "COUNT({})",
    "DISTINCTCOUNT": "COUNT(DISTINCT {})",
    "DISTINCTCOUNTNOBLANK": "COUNT(DISTINCT {})",
}

_TIME_UNITS = ("day", "month", "quarter", "year")
_CMP_OPS = {"=", "<>", "<", "<=", ">", ">="}
_NUMERIC_FUNCS = {
    "SUM", "COUNT", "COUNTA", "COUNTROWS", "DISTINCTCOUNT", "DISTINCTCOUNTNOBLANK", "AVERAGE",
    "SUMX", "COUNTX", "AVERAGEX", "DIVIDE", "ABS", "ROUND", "INT", "SQRT", "LEN",
    "YEAR", "MONTH", "DAY", "QUARTER",
}  # fmt: skip


def qcol(table: str, column: str) -> str:
    try:
        t = quote_ident(table, "a DAX table reference")
        return f"{t}.{quote_ident(column, 'a DAX column reference')}"
    except ValueError as e:
        raise DaxUnsupported(str(e)) from e


def _lit_str(s: str) -> str:
    return "'" + s.replace("'", "''") + "'"


def _num_value(node) -> int | None:
    if isinstance(node, Num):
        return int(node.value)
    if isinstance(node, UnaryOp) and node.op == "-" and isinstance(node.operand, Num):
        return -int(node.operand.value)
    return None


def _unit_value(node) -> str | None:
    name = getattr(node, "name", None)
    name = name.lower() if isinstance(name, str) else None
    return name if name in _TIME_UNITS else None


def _prev_cols(levels, e) -> dict:
    """Added columns visible to the next GROUPBY level (those of the last level)."""
    if not levels:
        return {}
    return {name.split("_", 1)[1].casefold(): f'"{name}"' for name, _ in levels[-1].added}


def _num_sql(v: float) -> str:
    return str(int(v)) if v == int(v) else repr(v)


# ----------------------------------------------------------------------------- AST helpers


def rewrite_blank_comparisons(node):
    """`x = BLANK()` -> ISBLANK(x); `x <> BLANK()` -> NOT ISBLANK(x) (either operand order)."""
    match node:
        case BinOp(op="=" | "<>" as op, left=left, right=right) if isinstance(
            left, Blank
        ) or isinstance(right, Blank):
            other = right if isinstance(left, Blank) else left
            other = rewrite_blank_comparisons(other)
            call = FuncCall("ISBLANK", (other,))
            return call if op == "=" else UnaryOp("NOT", call)
        case BinOp(op=op, left=left, right=right):
            return BinOp(op, rewrite_blank_comparisons(left), rewrite_blank_comparisons(right))
        case UnaryOp(op=op, operand=o):
            return UnaryOp(op, rewrite_blank_comparisons(o))
        case FuncCall(name=name, args=args):
            return FuncCall(name, tuple(rewrite_blank_comparisons(a) for a in args))
        case VarExpr(bindings=bindings, body=body):
            return VarExpr(
                tuple((n, rewrite_blank_comparisons(a)) for n, a in bindings),
                rewrite_blank_comparisons(body),
            )
        case TableCtor(values=values):
            return TableCtor(tuple(rewrite_blank_comparisons(v) for v in values))
    return node


def _walk(node):
    yield node
    match node:
        case BinOp(left=left, right=right):
            yield from _walk(left)
            yield from _walk(right)
        case UnaryOp(operand=o):
            yield from _walk(o)
        case FuncCall(args=args):
            for a in args:
                yield from _walk(a)
        case VarExpr(bindings=bindings, body=body):
            for _, a in bindings:
                yield from _walk(a)
            yield from _walk(body)
        case TableCtor(values=values):
            for v in values:
                yield from _walk(v)


class _Var:
    """A VAR compiled lazily, in the context where it was defined."""

    def __init__(self, ast, env: _Env):
        self.ast = ast
        self.env = env
        self.value: str | None = None
        self.compiling = False

    def compile(self, comp: MeasureCompiler, bound: bool = False) -> str:
        if bound:  # a bound reads the query context: never cached with the plain value
            return f"({comp._expr(self.ast, dataclasses.replace(self.env, bound=True))})"
        if self.value is None:
            if self.compiling:
                raise DaxUnsupported("VAR refers to itself")
            self.compiling = True
            try:
                self.value = f"({comp._expr(self.ast, self.env)})"
            finally:
                self.compiling = False
        return self.value


@dataclass
class _Env:
    ctx: Context
    out: CompiledMeasure
    stack: tuple
    scope: dict
    row: str | None = None  # base table when compiling a row-context expression
    related: set | None = None  # tables referenced through RELATED in a row expression
    bound: bool = False  # compiling a DATESBETWEEN bound: aggregates read the query context
    inline: tuple | None = None  # calculated-column compile: columns being inlined (cycle guard)
    cols: dict | None = None  # ADDCOLUMNS names -> SQL (row over a grouped table)
    keycols: dict | None = None  # (table, column) -> SQL of a SUMMARIZE key in the grouped row

    def with_ctx(self, ctx: Context) -> _Env:
        return dataclasses.replace(self, ctx=ctx)

    def with_row(self, table: str | None, related: set | None = None) -> _Env:
        return dataclasses.replace(self, row=table, related=related)


class MeasureCompiler:
    def __init__(self, model: SemanticModel, logger=None):
        self.model = model
        self.logger = logger  # CompilationLogger: records every measure compilation
        self._memo: dict[str, CompiledMeasure | DaxUnsupported] = {}
        self._asts: dict[str, object] = {}
        self._sig = self._rewrite_signature()
        self._exact_cols: dict[str, dict[str, str]] = {}
        self._numeric_cache: dict[str, bool] = {}
        self._calc_memo: dict[tuple[str, str], str | DaxUnsupported] = {}

    # -- public ---------------------------------------------------------

    def compile_measure(self, name: str) -> CompiledMeasure:
        """Memoized per compiler instance (successes and failures); treat the result as read-only."""
        self._check_signature()
        found = self.model.find_measure(name)
        key = found[1].name if found else name
        hit = self._memo.get(key)
        if hit is None:
            record = None
            started = time.perf_counter()
            if self.logger is not None and found is not None:
                record = self.logger.start_record(
                    found[0].name, key, self.model.effective_dax(found[1])
                )
            try:
                out = CompiledMeasure(name=key, expr="")
                env = _Env(Context(), out, (), {})
                out.expr = self._measure_body(key, env)
                hit = out
                if record is not None:
                    self.logger.finish_record(record, out, (time.perf_counter() - started) * 1000)
            except DaxUnsupported as e:
                hit = e
                if record is not None:
                    self.logger.fail_record(
                        record, str(e), "parked", (time.perf_counter() - started) * 1000
                    )
            self._memo[key] = hit
        if isinstance(hit, DaxUnsupported):
            raise DaxUnsupported(str(hit)) from hit
        return hit

    def compile_implicit(self, table: str, column: str, aggregate: str | None) -> CompiledMeasure:
        """Tier 0: bare column + summarization in a visual."""
        tbl = self.model.table(table)
        col = tbl.column(column) if tbl else None
        agg = (aggregate or "").upper()
        if not agg and col is not None:
            agg = {
                SummarizeBy.SUM: "SUM",
                SummarizeBy.MIN: "MIN",
                SummarizeBy.MAX: "MAX",
                SummarizeBy.AVERAGE: "AVERAGE",
                SummarizeBy.COUNT: "COUNT",
                SummarizeBy.DISTINCT_COUNT: "DISTINCTCOUNT",
            }.get(col.summarize_by, "")
        tpl = _SIMPLE_AGGS.get({"AVG": "AVERAGE", "COUNTNONNULL": "COUNT"}.get(agg, agg))
        if tpl is None:
            raise DaxUnsupported(f"no implicit aggregate for {table}[{column}] ({agg or 'none'})")
        out = CompiledMeasure(name=f"{table}.{column}", expr="", tier=0)
        out.expr = self._add_leaf(
            out, tpl.format(qcol(tbl.name if tbl else table, col.name if col else column)),
            {tbl.name if tbl else table}, Context(),
        )  # fmt: skip
        return out

    def compile_calc_column(self, table: str, column: str, _stack: tuple = ()) -> str:
        """Row-context SQL of a calculated column (projected in the physical subquery).
        Raises DaxUnsupported naming the reason when it cannot be translated."""
        key = (table, column)
        if key in _stack:
            raise DaxUnsupported(f"calculated column {table}[{column}] refers to itself")
        t = self._table(table)
        col = t.column(column)
        if col is None or col.expression is None:
            raise DaxUnsupported(f"{table}[{column}] is not a calculated column")
        cache_key = (t.name, col.name)
        if not _stack and cache_key in self._calc_memo:
            hit = self._calc_memo[cache_key]
            if isinstance(hit, DaxUnsupported):
                raise DaxUnsupported(str(hit)) from hit
            return hit
        try:
            ast = rewrite_blank_comparisons(self._canon(parse_dax(col.expression)))
            related: set[str] = set()
            env = _Env(
                Context(), CompiledMeasure(col.name, ""), (), {}, row=t.name, related=related,
                inline=(*_stack, key),
            )  # fmt: skip
            sql = self._expr(ast, env)
            if related:
                raise DaxUnsupported(
                    f"calculated column {table}[{column}] reads columns of another table "
                    f"({', '.join(sorted(related))}) through RELATED"
                )
            if env.out.leaves or env.out.tokens:
                raise DaxUnsupported(f"calculated column {table}[{column}] needs filter context")
        except DaxParseError as e:
            err = DaxUnsupported(str(e))
            if not _stack:
                self._calc_memo[cache_key] = err
            raise err from e
        except DaxUnsupported as e:
            if not _stack:
                self._calc_memo[cache_key] = e
            raise
        if not _stack:
            self._calc_memo[cache_key] = sql
        return sql

    # -- name resolution ------------------------------------------------

    def _rewrite_signature(self) -> tuple:
        return (
            tuple(sorted((k, v.expression) for k, v in self.model.dax_rewrites.items())),
            tuple(sorted((k, v.sql) for k, v in self.model.measure_sql.items())),
        )

    def _check_signature(self) -> None:
        sig = self._rewrite_signature()
        if sig != self._sig:
            self._sig = sig
            self._memo.clear()
            self._asts.clear()
            self._numeric_cache.clear()
            self._calc_memo.clear()

    def _table(self, name: str) -> Table:
        t = self.model.table(name)
        if t is None:
            raise DaxUnsupported(f"unknown table '{name}'")
        return t

    def _exact_columns(self, table: Table) -> dict[str, str]:
        """Names with surrounding spaces, keyed by their trimmed spelling."""
        cached = self._exact_cols.get(table.name)
        if cached is None:
            cached = {c.name.strip().casefold(): c.name for c in table.columns if c.name != c.name.strip()}
            self._exact_cols[table.name] = cached
        return cached

    def _column(self, table: str, column: str) -> tuple[str, str]:
        t = self._table(table)
        col = t.column(column)
        if col is None:
            exact = self._exact_columns(t).get(column.strip().casefold())
            if exact is not None:
                return t.name, exact
            return t.name, column
        return t.name, col.name

    def _canon(self, node):
        """Canonical table/column/measure names + the BLANK comparison rewrite."""
        match node:
            case ColumnRef(table=t, column=c):
                tn, cn = self._column(t, c)
                return ColumnRef(tn, cn)
            case TableRef(name=n):
                t = self.model.table(n)
                return TableRef(t.name) if t else node
            case MeasureRef(name=n):
                found = self.model.find_measure(n)
                return MeasureRef(found[1].name) if found else node
            case BinOp(op=op, left=left, right=right):
                return BinOp(op, self._canon(left), self._canon(right))
            case UnaryOp(op=op, operand=o):
                return UnaryOp(op, self._canon(o))
            case FuncCall(name=name, args=args):
                return FuncCall(name, tuple(self._canon(a) for a in args))
            case VarExpr(bindings=bindings, body=body):
                return VarExpr(tuple((n, self._canon(a)) for n, a in bindings), self._canon(body))
            case TableCtor(values=values):
                return TableCtor(tuple(self._canon(v) for v in values))
        return node

    def _ast(self, measure: Measure):
        ast = self._asts.get(measure.name)
        if ast is None:
            try:
                parsed = parse_dax(self.model.effective_dax(measure))
            except DaxParseError as e:
                raise DaxUnsupported(str(e)) from e
            ast = rewrite_blank_comparisons(self._canon(parsed))
            self._asts[measure.name] = ast
        return ast

    # -- internals ------------------------------------------------------

    def _measure_body(self, name: str, env: _Env) -> str:
        found = self.model.find_measure(name)
        if found is None:
            raise DaxUnsupported(f"unknown measure [{name}]")
        _, measure = found
        if measure.name in env.stack:
            raise DaxUnsupported(f"measure cycle: {' -> '.join(env.stack)} -> {measure.name}")
        manual = self.model.measure_sql.get(measure.name)
        if manual is not None:
            # hand-written Snowflake SQL: one native value per query, never under CALCULATE
            if env.ctx != Context():
                parent = env.stack[-1] if env.stack else "this measure"
                raise DaxUnsupported(
                    f"[{measure.name}] uses hand-written SQL and cannot be referenced under "
                    f"CALCULATE modifiers (in [{parent}])"
                )
            env.out.tier = 3
            return self._token(env.out, ("native", measure.name))
        inner = dataclasses.replace(env, stack=env.stack + (measure.name,), scope={})
        return self._expr(self._ast(measure), inner)

    def _add_leaf(
        self,
        out: CompiledMeasure,
        sql: str,
        tables: set[str],
        ctx: Context,
        related: set[str] | None = None,
        grouped: GroupedPlan | None = None,
    ) -> str:
        for alias, leaf in out.leaves.items():  # dedup identical leaves
            if leaf.sql == sql and leaf.ctx == ctx and leaf.grouped == grouped:
                leaf.tables |= tables
                leaf.related |= related or set()
                return alias
        alias = f"__m{len(out.leaves)}"
        out.leaves[alias] = Leaf(
            sql=sql, tables=set(tables), ctx=ctx, related=set(related or ()), grouped=grouped
        )
        return alias

    def _table_node(self, node, env: _Env) -> TableRef | None:
        if isinstance(node, TableRef):
            return node
        if isinstance(node, VarRef) and self._lookup_var(node.name, env) is None:
            t = self.model.table(node.name)
            if t is not None:
                return TableRef(t.name)
        return None

    def _lookup_var(self, name: str, env: _Env):
        if name in env.scope:
            return env.scope[name]
        folded = [k for k in env.scope if k.casefold() == name.casefold()]
        return env.scope[folded[0]] if len(folded) == 1 else None

    # -- numeric / blank helpers ------------------------------------------

    def _numeric(self, node, env: _Env, depth: int = 0) -> bool:
        """True only when the expression provably yields a number (never a date/text)."""
        if depth > 12:
            return False
        match node:
            case Num() | Blank():
                return True
            case UnaryOp(op="-", operand=o):
                return self._numeric(o, env, depth + 1)
            case BinOp(op="+" | "-" | "*" | "/", left=left, right=right):
                return self._numeric(left, env, depth + 1) and self._numeric(right, env, depth + 1)
            case FuncCall(name=name, args=args):
                if name in _NUMERIC_FUNCS:
                    return True
                if name in ("IF", "SWITCH") and len(args) >= 2:
                    results = args[1::2] if name == "SWITCH" else args[1:]
                    return all(
                        isinstance(r, Blank) or self._numeric(r, env, depth + 1) for r in results
                    ) and any(not isinstance(r, Blank) for r in results)
                return False
            case MeasureRef(name=n):
                found = self.model.find_measure(n)
                if found is None:
                    return False
                try:
                    return self._numeric(self._ast(found[1]), _Env(Context(), env.out, (), {}), depth + 1)
                except DaxUnsupported:
                    return False
            case VarRef(name=n):
                var = self._lookup_var(n, env)
                return isinstance(var, _Var) and self._numeric(var.ast, var.env, depth + 1)
            case VarExpr(bindings=bindings, body=body):
                inner = dict(env.scope)
                for vn, vast in bindings:
                    inner[vn] = _Var(vast, dataclasses.replace(env, scope=inner))
                return self._numeric(body, dataclasses.replace(env, scope=inner), depth + 1)
        return False

    def _row_var(self, var: _Var, e: _Env) -> str:
        """A VAR read inside a row predicate: only constants and whole-table scalars are allowed
        (anything else depends on the filter context and is refused)."""
        node = var.ast
        if isinstance(node, Num | Str | Bool | Blank):
            return self._expr(node, dataclasses.replace(e, row=None))
        if isinstance(node, FuncCall) and node.name == "CALCULATE":
            return self._row_scalar(node, dataclasses.replace(var.env, row=e.row, out=e.out))
        raise DaxUnsupported(
            "a VAR used inside a row filter must be a constant or a whole-table scalar "
            "(CALCULATE(agg(T[c]), ALL(T))); this one depends on the filter context"
        )

    @staticmethod
    def _concat_sql(left: str, right: str) -> str:
        """BLANK concatenates as empty text, not NULL."""
        return f"(COALESCE({left}, '') || COALESCE({right}, ''))"

    # -- expressions (scalar position and row position share one compiler) -------------------

    def _expr(self, node, env: _Env) -> str:
        e = env
        match node:
            case Num(value=v):
                return _num_sql(v)
            case Str(value=s):
                return _lit_str(s)
            case Bool(value=b):
                return "TRUE" if b else "FALSE"
            case Blank():
                return "NULL"
            case MeasureRef(name=n):
                if e.cols and n.casefold() in e.cols:
                    return e.cols[n.casefold()]
                if e.row is not None:
                    raise DaxUnsupported(f"measure [{n}] inside a row expression is context dependent")
                return f"({self._measure_body(n, e)})"
            case VarRef(name=n):
                var = self._lookup_var(n, e)
                if var is None:
                    raise DaxUnsupported(f"unknown identifier {n}")
                if isinstance(var, str):
                    return var
                if e.row is not None:
                    return self._row_var(var, e)
                return var.compile(self, bound=e.bound)
            case VarExpr(bindings=bindings, body=body):
                local = dict(e.scope)
                for var_name, var_ast in bindings:
                    local[var_name] = _Var(var_ast, dataclasses.replace(e, scope=local))
                return self._expr(body, dataclasses.replace(e, scope=local))
            case UnaryOp(op="-", operand=o):
                return f"(-{self._expr(o, e)})"
            case UnaryOp(op="NOT", operand=o):
                return f"(NOT {self._expr(o, e)})"
            case BinOp(op=op):
                return self._binop(node, e)
            case ColumnRef(table=t, column=c):
                if e.keycols is not None:
                    if (t, c) in e.keycols:
                        return e.keycols[(t, c)]
                    raise DaxUnsupported(
                        f"column {t}[{c}] is not one of the grouped table's columns"
                    )
                if e.inline is not None and t == e.row:
                    target = self._table(t).column(c)
                    if target is not None and target.expression is not None:
                        return f"({self.compile_calc_column(t, c, e.inline)})"
                if e.row is None:
                    raise DaxUnsupported(f"bare column {t}[{c}] in scalar context (needs row context)")
                if t != e.row and e.related is not None:
                    e.related.add(t)
                return qcol(t, c)
            case TableCtor():
                raise DaxUnsupported("table constructor outside IN / TREATAS")
            case FuncCall():
                return self._func(node, e)
        raise DaxUnsupported(f"unsupported node {node!r}")

    def _binop(self, node: BinOp, env: _Env) -> str:
        op, left, right = node.op, node.left, node.right
        if op == "IN":
            return self._in_sql(self._expr(left, env), right, env)
        if op == "&":
            return self._concat_sql(self._expr(left, env), self._expr(right, env))
        ls = self._expr(left, env)
        rs = self._expr(right, env)
        if op in ("+", "-") and self._numeric(left, env) and self._numeric(right, env):
            # DAX blank arithmetic: BLANK acts as 0 unless both operands are BLANK
            return (
                f"IFF(({ls}) IS NULL AND ({rs}) IS NULL, NULL, "
                f"COALESCE({ls}, 0) {op} COALESCE({rs}, 0))"
            )
        if op in _CMP_OPS:
            ls, rs = self._blank_safe(left, ls, right, rs, env)
        sql_op = {"&&": "AND", "||": "OR"}.get(op, op)
        return f"({ls} {sql_op} {rs})"

    def _blank_safe(self, left, ls: str, right, rs: str, env: _Env) -> tuple[str, str]:
        """DAX compares BLANK as 0 / "" against a literal of that type."""
        if isinstance(right, Num) and not isinstance(left, Num | Str | Bool | Blank):
            ls = f"COALESCE({ls}, 0)" if self._numeric(left, env) else ls
        elif isinstance(left, Num) and not isinstance(right, Num | Str | Bool | Blank):
            rs = f"COALESCE({rs}, 0)" if self._numeric(right, env) else rs
        elif isinstance(right, Str) and right.value == "" and not isinstance(left, Str | Blank):
            ls = f"COALESCE({ls}, '')"
        elif isinstance(left, Str) and left.value == "" and not isinstance(right, Str | Blank):
            rs = f"COALESCE({rs}, '')"
        return ls, rs

    def _in_sql(self, left_sql: str, right, env: _Env) -> str:
        """DAX IN is strict and never BLANK: BLANK entries become IS NULL and the IN part is
        COALESCEd to FALSE, so NOT (x IN {BLANK(), "UNK"}) keeps the rows DAX keeps."""
        if not isinstance(right, TableCtor):
            raise DaxUnsupported("IN supports only a table constructor { ... } on the right")
        has_blank = any(isinstance(v, Blank) for v in right.values)
        values = [self._expr(v, env) for v in right.values if not isinstance(v, Blank)]
        parts = []
        if values:
            parts.append(f"COALESCE({left_sql} IN ({', '.join(values)}), FALSE)")
        if has_blank:
            parts.append(f"({left_sql}) IS NULL")
        if not parts:
            return "FALSE"
        return "(" + " OR ".join(parts) + ")" if len(parts) > 1 else parts[0]

    def _func(self, node: FuncCall, env: _Env) -> str:
        if env.bound:
            return self._bound_func(node, env)
        return self._func_core(node, env)

    def _func_core(self, node: FuncCall, env: _Env) -> str:
        fname, args = node.name, node.args
        e = env

        def s(n):
            return self._expr(n, e)

        if fname in _SIMPLE_AGGS and not (fname in ("MIN", "MAX") and len(args) == 2):
            if len(args) != 1 or not isinstance(args[0], ColumnRef):
                raise DaxUnsupported(f"{fname} expects a single column reference")
            if e.row is not None:
                # a bare cross-table aggregate inside a row predicate becomes an uncorrelated
                # scalar subquery over that table's binding (_rewrite_cross_table_agg)
                if args[0].table == e.row:
                    raise DaxUnsupported(
                        f"{fname}({args[0].table}[{args[0].column}]) inside a filter on the same "
                        "table depends on the outer filter context"
                    )
                sql = _SIMPLE_AGGS[fname].format(qcol(args[0].table, args[0].column))
                return self._scalar_token(e.out, args[0].table, sql)
            sql = _SIMPLE_AGGS[fname].format(qcol(args[0].table, args[0].column))
            return self._add_leaf(e.out, sql, {args[0].table}, e.ctx)

        match fname:
            case "COUNTROWS":
                if len(args) == 1 and e.row is None:
                    grouped = self._grouped_countrows(args[0], e)
                    if grouped is not None:
                        return grouped
                tref = self._table_node(args[0], e) if len(args) == 1 else None
                if tref is None:
                    tsrc = self._iter_source(args[0], e) if len(args) == 1 else None
                    if tsrc is None:
                        raise DaxUnsupported("COUNTROWS expects a table reference")
                    table, ctx2, related = tsrc
                    return self._add_leaf(e.out, "COUNT(*)", {table}, ctx2, related)
                return self._add_leaf(e.out, "COUNT(*)", {tref.name}, e.ctx)

            case "SUMX" | "AVERAGEX" | "MINX" | "MAXX" | "COUNTX":
                return self._iterator(fname, args, e)

            case "DIVIDE":
                if len(args) not in (2, 3):
                    raise DaxUnsupported("DIVIDE expects 2 or 3 arguments")
                num, den = s(args[0]), s(args[1])
                alt = s(args[2]) if len(args) == 3 else "NULL"
                return f"IFF(({den}) = 0 OR ({den}) IS NULL, {alt}, ({num}) / ({den}))"

            case "IF":
                if len(args) not in (2, 3):
                    raise DaxUnsupported("IF expects 2 or 3 arguments")
                alt = s(args[2]) if len(args) == 3 else "NULL"
                return f"IFF({s(args[0])}, {s(args[1])}, {alt})"

            case "IFERROR":
                return self._iferror(args, e)

            case "ISBLANK":
                return f"(({s(args[0])}) IS NULL)"

            case "COALESCE":
                return f"COALESCE({', '.join(s(a) for a in args)})"

            case "ABS" | "SQRT" | "EXP" | "LN" | "FLOOR":
                return f"{fname}({s(args[0])})"
            case "INT":
                return f"FLOOR({s(args[0])})"
            case "CEILING":
                return f"CEIL({s(args[0])})"
            case "ROUND":
                return f"ROUND({s(args[0])}, {s(args[1]) if len(args) > 1 else '0'})"

            case "SWITCH":
                return self._switch(args, e)

            case "SELECTEDVALUE":
                if e.row is not None:
                    raise DaxUnsupported("SELECTEDVALUE inside a row expression")
                # SELECTEDVALUE(col [, default]) -> IFF(COUNT(DISTINCT col)=1, MAX(col), default)
                if not args or not isinstance(args[0], ColumnRef):
                    raise DaxUnsupported("SELECTEDVALUE expects a column reference")
                col_sql = qcol(args[0].table, args[0].column)
                default_sql = s(args[1]) if len(args) > 1 else "NULL"
                count_alias = self._add_leaf(e.out, f"COUNT(DISTINCT {col_sql})", {args[0].table}, e.ctx)
                max_alias = self._add_leaf(e.out, f"MAX({col_sql})", {args[0].table}, e.ctx)
                return f"IFF(({count_alias}) = 1, ({max_alias}), {default_sql})"

            case "HASONEVALUE":
                if not args or not isinstance(args[0], ColumnRef):
                    raise DaxUnsupported("HASONEVALUE expects a column reference")
                col_sql = qcol(args[0].table, args[0].column)
                count_alias = self._add_leaf(e.out, f"COUNT(DISTINCT {col_sql})", {args[0].table}, e.ctx)
                return f"(({count_alias}) = 1)"

            case "VALUES" | "DISTINCT":
                # VALUES(table[col]) in scalar context -> MAX of that column
                if not args or not isinstance(args[0], ColumnRef):
                    raise DaxUnsupported(f"{fname} in scalar context requires a column ref")
                col_sql = qcol(args[0].table, args[0].column)
                return self._add_leaf(e.out, f"MAX({col_sql})", {args[0].table}, e.ctx)

            case "ALLSELECTED":
                # ALLSELECTED in scalar context: compile inner measure without the clear
                if args:
                    return self._expr(args[0], e.with_ctx(e.ctx.with_clear("*")))
                raise DaxUnsupported("ALLSELECTED() with no args not supported in tier-1")

            case "RANKX":
                return self._rankx(args, e)

            case "CONCATENATEX":
                raise DaxUnsupported("CONCATENATEX not in tier-1 (use tier-2)")

            case "FORMAT" | "TEXT":
                if not args:
                    raise DaxUnsupported(f"{fname} with no args")
                return f"TO_VARCHAR({s(args[0])})"

            case "YEAR" | "MONTH" | "DAY" | "HOUR" | "MINUTE" | "SECOND" | "QUARTER":
                if not args:
                    raise DaxUnsupported(f"{fname} needs an argument")
                return f"{fname}({s(args[0])})"

            case "WEEKDAY":
                return f"DAYOFWEEK({s(args[0])})"

            case "WEEKNUM":
                return f"WEEKOFYEAR({s(args[0])})"

            case "LEFT" | "RIGHT":
                return f"{fname}({s(args[0])}, {s(args[1]) if len(args) > 1 else '1'})"

            case "MID":
                length = s(args[2]) if len(args) > 2 else "NULL"
                return f"SUBSTR({s(args[0])}, {s(args[1])}, {length})"

            case "LEN":
                return f"LENGTH({s(args[0])})"

            case "UPPER" | "LOWER" | "TRIM":
                return f"{fname}({s(args[0])})"

            case "CONCATENATE":
                if len(args) != 2:
                    raise DaxUnsupported("CONCATENATE expects 2 args")
                return self._concat_sql(s(args[0]), s(args[1]))

            case "SUBSTITUTE":
                return f"REPLACE({s(args[0])}, {s(args[1])}, {s(args[2])})"

            case "VALUE":
                return f"TRY_CAST({s(args[0])} AS NUMBER)"

            case "DATE":
                return f"DATE_FROM_PARTS({s(args[0])}, {s(args[1])}, {s(args[2])})"

            case "TODAY":
                return "CURRENT_DATE()"

            case "NOW":
                return "CURRENT_TIMESTAMP()"

            case "EOMONTH":
                n = s(args[1]) if len(args) > 1 else "0"
                return f"LAST_DAY(DATEADD(month, {n}, {s(args[0])}))"

            case "EDATE":
                if len(args) != 2:
                    raise DaxUnsupported("EDATE expects 2 arguments")
                return f"DATEADD(month, {s(args[1])}, {s(args[0])})"

            case "MAX" if len(args) == 2:
                return f"GREATEST({s(args[0])}, {s(args[1])})"

            case "MIN" if len(args) == 2:
                return f"LEAST({s(args[0])}, {s(args[1])})"

            case "FIRSTNONBLANK" | "LASTNONBLANK":
                return self._first_last_nonblank(fname, args, e)

            case "ISFILTERED" | "ISCROSSFILTERED":
                return self._isfiltered(fname, args, e)

            case "RELATED":
                if e.row is None or len(args) != 1 or not isinstance(args[0], ColumnRef):
                    raise DaxUnsupported("RELATED needs a column reference in a row expression")
                if e.related is not None:
                    e.related.add(args[0].table)
                return qcol(args[0].table, args[0].column)

            case "TOTALYTD":
                if len(args) != 2 or not isinstance(args[1], ColumnRef):
                    raise DaxUnsupported("TOTALYTD(expr, date_col) only")
                shift = TimeShift("ytd", args[1].table, args[1].column)
                return self._expr(args[0], e.with_ctx(e.ctx.with_shift(shift)))

            case "CALCULATE":
                if e.row is not None:
                    return self._row_scalar(node, e)
                grouped = self._grouped_calculate(args, e)
                if grouped is not None:
                    return grouped
                return self._calculate(args, e)

            case _:
                raise DaxUnsupported(f"function {fname} not in tier-1 set")

    # -- IFERROR / FIRSTNONBLANK / ISFILTERED -----------------------------------------------

    @staticmethod
    def _can_raise(node) -> bool:
        for n in _walk(node):
            if isinstance(n, BinOp) and n.op == "/":
                return True
            if isinstance(n, FuncCall) and n.name in ("VALUE", "DATEVALUE", "SQRT", "LN", "LOG"):
                return True
        return False

    def _iferror(self, args, e: _Env) -> str:
        if len(args) != 2:
            raise DaxUnsupported("IFERROR expects 2 arguments")
        target, fallback = args
        if not self._can_raise(target) and not self._measure_can_raise(target, e):
            return self._expr(target, e)
        sel = self._value_of_selected_text(target, e)
        if sel is None:
            raise DaxUnsupported(
                "IFERROR around a division or VALUE can raise in SQL (division by zero is an "
                "error, TRY_CAST makes VALUE NULL) and is refused instead of guessing"
            )
        return sel(self._expr(fallback, e))

    def _measure_can_raise(self, node, e: _Env, depth: int = 0) -> bool:
        if depth > 8:
            return True
        for n in _walk(node):
            if isinstance(n, MeasureRef):
                found = self.model.find_measure(n.name)
                if found is None:
                    continue
                try:
                    inner = self._ast(found[1])
                except DaxUnsupported:
                    return True
                if self._can_raise(inner) or self._measure_can_raise(inner, e, depth + 1):
                    return True
            if isinstance(n, VarRef):
                var = self._lookup_var(n.name, e)
                if isinstance(var, _Var) and (
                    self._can_raise(var.ast) or self._measure_can_raise(var.ast, var.env, depth + 1)
                ):
                    return True
        return False

    def _selected_text_source(self, node, e: _Env, depth: int = 0):
        """(table, column) when node is TRIM/VAR/measure chain down to SELECTEDVALUE(T[c])."""
        if depth > 12:
            return None
        match node:
            case FuncCall(name="SELECTEDVALUE", args=args) if args and isinstance(args[0], ColumnRef):
                t, c = args[0].table, args[0].column
                col = self._table(t).column(c)
                if col is not None and col.data_type.value == "string":
                    return t, c
                return None
            case FuncCall(name="TRIM", args=(inner,)):
                return self._selected_text_source(inner, e, depth + 1)
            case MeasureRef(name=n):
                found = self.model.find_measure(n)
                return (
                    self._selected_text_source(self._ast(found[1]), e, depth + 1) if found else None
                )
            case VarRef(name=n):
                var = self._lookup_var(n, e)
                if isinstance(var, _Var):
                    return self._selected_text_source(var.ast, var.env, depth + 1)
            case VarExpr(bindings=bindings, body=body):
                inner_scope = dict(e.scope)
                for vn, vast in bindings:
                    inner_scope[vn] = _Var(vast, dataclasses.replace(e, scope=inner_scope))
                return self._selected_text_source(
                    body, dataclasses.replace(e, scope=inner_scope), depth + 1
                )
        return None

    def _value_of_selected_text(self, target, e: _Env):
        """IFERROR(VALUE(<slicer's selected text>), alt): returns a callable building the SQL, or
        None when the argument is not a slicer selection."""
        if not (isinstance(target, FuncCall) and target.name == "VALUE" and len(target.args) == 1):
            return None
        source = self._selected_text_source(target.args[0], e)
        if source is None:
            return None
        table, column = source
        literals = self._compared_literals(table, column)
        e.out.value_assumptions.append((table, column, literals))
        text_sql = self._expr(target.args[0], e)
        listed = ", ".join(f"UPPER({_lit_str(x)})" for x in literals)
        not_literal = f" AND UPPER(TRIM({text_sql})) NOT IN ({listed})" if literals else ""
        would_raise = (
            f"(({text_sql}) IS NOT NULL AND TRY_CAST(TRIM({text_sql}) AS NUMBER) IS NULL"
            f"{not_literal})"
        )

        def build(fallback_sql: str) -> str:
            return f"IFF({would_raise}, {fallback_sql}, TRY_CAST(TRIM({text_sql}) AS NUMBER))"

        return build

    def _compared_literals(self, table: str, column: str) -> tuple[str, ...]:
        """String literals compared with the column's selected value anywhere in the model."""
        out: list[str] = []
        for t in self.model.tables:
            for m in t.measures:
                try:
                    ast = self._ast(m)
                except DaxUnsupported:
                    continue
                env = _Env(Context(), CompiledMeasure("", ""), (), {})
                self._scan_compared(ast, env, (table, column), out)
        return tuple(out)

    def _scan_compared(self, node, env: _Env, target: tuple[str, str], out: list[str]) -> None:
        match node:
            case VarExpr(bindings=bindings, body=body):
                scope = dict(env.scope)
                inner = dataclasses.replace(env, scope=scope)
                for vn, vast in bindings:
                    scope[vn] = _Var(vast, inner)
                    self._scan_compared(vast, inner, target, out)
                self._scan_compared(body, inner, target, out)
                return
            case BinOp(op="=", left=left, right=right):
                for side, other in ((left, right), (right, left)):
                    if (
                        isinstance(other, Str)
                        and other.value not in out
                        and self._selected_text_source(side, env) == target
                    ):
                        out.append(other.value)
        for child in (
            [node.left, node.right]
            if isinstance(node, BinOp)
            else [node.operand]
            if isinstance(node, UnaryOp)
            else list(node.args)
            if isinstance(node, FuncCall)
            else []
        ):
            self._scan_compared(child, env, target, out)

    def _first_last_nonblank(self, fname: str, args, e: _Env) -> str:
        if len(args) != 2 or not isinstance(args[0], ColumnRef):
            raise DaxUnsupported(f"{fname}(T[c], <constant>) only")
        if any(not isinstance(n, Num | Str | Bool) for n in _walk(args[1])):
            raise DaxUnsupported(f"{fname} with a context-dependent expression is not supported")
        col = qcol(args[0].table, args[0].column)
        t = {args[0].table}
        if fname == "LASTNONBLANK":
            return self._add_leaf(e.out, f"MAX({col})", t, e.ctx)
        # BLANK sorts first: with any NULL the first value is BLANK
        sql = f"IFF(COUNT(*) > COUNT({col}), NULL, MIN({col}))"
        return self._add_leaf(e.out, sql, t, e.ctx)

    def _isfiltered(self, fname: str, args, e: _Env) -> str:
        if len(args) != 1:
            raise DaxUnsupported(f"{fname} expects 1 argument")
        arg = args[0]
        table = arg.table if isinstance(arg, ColumnRef) else getattr(arg, "name", None)
        if table is None or self.model.table(table) is None:
            raise DaxUnsupported(f"{fname} expects a table or column reference")
        table = self._table(table).name
        col = arg.column if isinstance(arg, ColumnRef) else None
        ctx = e.ctx
        # filters/clears added by an enclosing CALCULATE are known at compile time (a clear
        # drops the incoming predicates, so what remains in ctx.filters is really applied)
        if any(p.table == table and (col is None or qcol(table, col) in p.sql) for p in ctx.filters):
            return "TRUE"
        if "*" in ctx.clears or table in ctx.clears or (col and (table, col) in ctx.clears):
            return "FALSE"
        ctx_tables = tuple(sorted({p.table for p in ctx.filters}))
        return self._token(e.out, ("isf", fname, table, col, ctx_tables))

    # -- iterators / row expressions -----------------------------------------------------

    def _iter_source(self, node, e: _Env):
        """Iterator source -> (table, ctx, related). ALL(T) clears T; FILTER(src, pred) adds the
        predicate; a table VAR keeps the context where it was defined."""
        tref = self._table_node(node, e)
        if tref is not None:
            return tref.name, e.ctx, set()
        match node:
            case VarRef(name=n):
                var = self._lookup_var(n, e)
                if isinstance(var, _Var):
                    return self._iter_source(var.ast, var.env)
            case FuncCall(name="ALL", args=(a,)) if self._table_node(a, e):
                t = self._table_node(a, e).name
                return t, e.ctx.with_clear(t, base=e.ctx.filters), set()
            case FuncCall(name="FILTER", args=(src, pred)):
                inner = self._iter_source(src, e)
                if inner is None:
                    return None
                table, ctx, related = inner
                rel: set[str] = set(related)
                ctx2 = self._add_row_filter(pred, table, e.with_ctx(ctx), rel)
                return table, ctx2, rel
        return None

    def _add_row_filter(self, pred, table: str, e: _Env, related: set[str]) -> Context:
        """Row predicate of FILTER(table, pred) as a context filter (keep idiom aware)."""
        ctx = e.ctx
        for t, c in self._keep_idiom_columns(pred):
            ctx = ctx.with_keep(t, c)
        senv = dataclasses.replace(e, ctx=ctx, row=table, related=related)
        stripped = self._strip_keep_idiom(pred)
        sql = self._expr(stripped, senv)
        cols = frozenset(self._predicate_columns(stripped))
        return ctx.with_filter(FilterPredicate(table=table, sql=sql, cols=cols))

    def _keep_idiom_columns(self, pred) -> list[tuple[str, str]]:
        """`T[c] = MAX(T[c])` (also MIN/SELECTEDVALUE/VALUES) keeps the current filter on c."""
        out: list[tuple[str, str]] = []
        conjuncts = [pred]
        while conjuncts:
            n = conjuncts.pop()
            if isinstance(n, BinOp) and n.op == "&&":
                conjuncts += [n.left, n.right]
            elif isinstance(n, BinOp) and n.op == "=":
                for col, agg in ((n.left, n.right), (n.right, n.left)):
                    if (
                        isinstance(col, ColumnRef)
                        and isinstance(agg, FuncCall)
                        and agg.name in ("MAX", "MIN", "SELECTEDVALUE", "VALUES")
                        and agg.args == (col,)
                    ):
                        out.append((col.table, col.column))
        return out

    def _strip_keep_idiom(self, pred):
        """Remove keep-idiom conjuncts (they constrain nothing once the filter is kept)."""
        keep = set(self._keep_idiom_columns(pred))
        if not keep:
            return pred

        def strip(n):
            if isinstance(n, BinOp) and n.op == "&&":
                l, r = strip(n.left), strip(n.right)
                if l is None:
                    return r
                if r is None:
                    return l
                return BinOp("&&", l, r)
            if isinstance(n, BinOp) and n.op == "=":
                for col, agg in ((n.left, n.right), (n.right, n.left)):
                    if (
                        isinstance(col, ColumnRef)
                        and (col.table, col.column) in keep
                        and isinstance(agg, FuncCall)
                        and agg.args == (col,)
                    ):
                        return None
            return n

        stripped = strip(pred)
        return stripped if stripped is not None else Bool(True)

    def _iterator(self, fname: str, args, e: _Env) -> str:
        if e.row is not None:
            raise DaxUnsupported(f"{fname} inside a row expression is not supported")
        if len(args) != 2:
            raise DaxUnsupported(f"{fname} expects 2 arguments")
        # AVERAGEX(DATESINPERIOD(date, MAX(date), -n, unit), [M]) = rolling mean
        if (
            fname == "AVERAGEX"
            and isinstance(args[0], FuncCall)
            and args[0].name == "DATESINPERIOD"
            and isinstance(args[1], MeasureRef)
        ):
            if e.ctx != Context() or e.out.leaves or e.out.window_avg:
                raise DaxUnsupported("windowed AVERAGEX must be the whole measure")
            shift = self._parse_datesinperiod(args[0].args)
            e.out.window_avg = WindowAvg(
                measure=args[1].name,
                date_table=shift.date_table,
                date_column=shift.date_column,
                n=shift.n,
                unit=shift.unit,
            )
            return "__WINDOW__"  # placeholder; engine replaces the whole measure
        grouped = self._grouped_source(args[0], e)
        if grouped is not None:
            return self._grouped_iterator(fname, grouped, args[1], e)
        src = self._iter_source(args[0], e)
        if src is None:
            raise DaxUnsupported(f"{fname} supported only over a base table, ALL(T) or FILTER(T, ...)")
        table, ctx, related = src
        related = set(related)
        body = self._expr(args[1], dataclasses.replace(e, ctx=ctx, row=table, related=related))
        agg = {"SUMX": "SUM", "AVERAGEX": "AVG", "MINX": "MIN", "MAXX": "MAX", "COUNTX": "COUNT"}[fname]
        return self._add_leaf(e.out, f"{agg}({body})", {table}, ctx, related)

    # -- grouped tables: ADDCOLUMNS(SUMMARIZE(T, keys), "n", agg) ------------------------------

    def _resolve_table_var(self, node, e: _Env):
        """A table VAR is evaluated where it is defined: returns (ast, definition env)."""
        seen = 0
        while isinstance(node, VarRef) and seen < 8:
            var = self._lookup_var(node.name, e)
            if not isinstance(var, _Var):
                break
            node, e = var.ast, var.env
            seen += 1
        return node, e

    def _grouped_source(self, node, e: _Env):
        node, e = self._resolve_table_var(node, e)
        if not (isinstance(node, FuncCall) and node.name == "ADDCOLUMNS"):
            return None
        args = node.args
        if len(args) < 3 or len(args) % 2 == 0:
            raise DaxUnsupported("ADDCOLUMNS expects pairs of name and expression")
        base = args[0]
        if not (isinstance(base, FuncCall) and base.name == "SUMMARIZE" and len(base.args) >= 2):
            raise DaxUnsupported("ADDCOLUMNS supported only over SUMMARIZE(T, columns...)")
        tref = self._table_node(base.args[0], e)
        if tref is None or not all(isinstance(a, ColumnRef) for a in base.args[1:]):
            raise DaxUnsupported("SUMMARIZE supported only as SUMMARIZE(T, T[c], ...)")
        keys = tuple((a.table, a.column) for a in base.args[1:])
        added: dict[str, str] = {}
        for i in range(1, len(args), 2):
            name_node, expr = args[i], args[i + 1]
            if not isinstance(name_node, Str):
                raise DaxUnsupported("ADDCOLUMNS names must be string literals")
            added[name_node.value] = self._group_aggregate(expr, e)
        return tref.name, keys, added, e.ctx

    def _group_aggregate(self, expr, e: _Env) -> str:
        """Per-group aggregate of an ADDCOLUMNS column: CALCULATE(agg(T[c])) context-transitions to
        the group, i.e. a plain aggregate per key set. Extra modifiers are refused."""
        if isinstance(expr, FuncCall) and expr.name == "CALCULATE":
            if len(expr.args) != 1:
                raise DaxUnsupported("ADDCOLUMNS column with CALCULATE filters is not supported")
            expr = expr.args[0]
        if isinstance(expr, FuncCall) and expr.name in _SIMPLE_AGGS and len(expr.args) == 1:
            if isinstance(expr.args[0], ColumnRef):
                return _SIMPLE_AGGS[expr.name].format(qcol(expr.args[0].table, expr.args[0].column))
        if isinstance(expr, FuncCall) and expr.name == "COUNTROWS" and len(expr.args) == 1:
            return "COUNT(*)"
        raise DaxUnsupported("ADDCOLUMNS column must be an aggregate of one column")

    def _grouped_iterator(self, fname: str, source, body_node, e: _Env) -> str:
        fact, keys, added, def_ctx = source
        plan = GroupedPlan(
            fact=fact,
            keys=keys,
            base=tuple((f"g0_{name}", sql) for name, sql in added.items()),
        )
        cols = {name.casefold(): f'"g0_{name}"' for name in added}
        keycols = {key: f'"k{i}"' for i, key in enumerate(keys)}
        env = dataclasses.replace(e, ctx=def_ctx, row=fact, related=set(), cols=cols, keycols=keycols)
        body = self._expr(body_node, env)
        agg = {"SUMX": "SUM", "AVERAGEX": "AVG", "MINX": "MIN", "MAXX": "MAX", "COUNTX": "COUNT"}[fname]
        return self._add_leaf(e.out, f"{agg}({body})", {fact}, def_ctx, grouped=plan)

    # -- grouped "cap" measures (6.6): SUMMARIZE -> GROUPBY levels -> count over a filter ----------

    _GROUP_AGGS = {"SUMX": "SUM", "AVERAGEX": "AVG", "MINX": "MIN", "MAXX": "MAX", "COUNTX": "COUNT"}

    def _looks_grouped(self, node, e: _Env) -> bool:
        node, _ = self._resolve_table_var(node, e)
        if isinstance(node, FuncCall) and node.name == "CALCULATETABLE" and node.args:
            return self._looks_grouped(node.args[0], e)
        return isinstance(node, FuncCall) and node.name in ("SUMMARIZE", "GROUPBY")

    def _grouped_table(self, node, e: _Env):
        """(fact, keys, levels, cols, keycols, ctx) of SUMMARIZE / GROUPBY chains."""
        resolved, renv = self._resolve_table_var(node, e)
        if resolved is not node:  # a table VAR is a constant: no re-filtering by wrappers
            return self._grouped_table(resolved, renv)
        if isinstance(node, FuncCall) and node.name == "CALCULATETABLE" and node.args:
            ctx = e.ctx
            base = ctx.filters
            for farg in node.args[1:]:
                ctx = self._apply_filter_arg(farg, ctx, e, base)
            return self._grouped_table(node.args[0], e.with_ctx(ctx))
        if isinstance(node, FuncCall) and node.name == "SUMMARIZE":
            args = node.args
            tref = self._table_node(args[0], e) if args else None
            if tref is None or len(args) < 2 or not all(isinstance(a, ColumnRef) for a in args[1:]):
                raise DaxUnsupported(
                    "SUMMARIZE supported only as SUMMARIZE(T, T[c], ...) (columns, no computed columns)"
                )
            keys = tuple((a.table, a.column) for a in args[1:])
            keycols = {key: f'"k{i}"' for i, key in enumerate(keys)}
            return tref.name, keys, (), {}, keycols, e.ctx
        if isinstance(node, FuncCall) and node.name == "GROUPBY":
            return self._grouped_groupby(node, e)
        raise DaxUnsupported(
            f"grouped table shape {getattr(node, 'name', type(node).__name__)} is not supported "
            "(expected CALCULATETABLE(SUMMARIZE(...)) and GROUPBY(..., CURRENTGROUP()))"
        )

    def _grouped_groupby(self, node: FuncCall, e: _Env):
        args = node.args
        prev = self._grouped_table(args[0], e) if args else None
        if prev is None or len(args) < 2:
            raise DaxUnsupported("GROUPBY supported only over a SUMMARIZE / GROUPBY table")
        fact, keys, levels, _cols, keycols, ctx = prev
        i = 1
        kept: list[tuple[str, str]] = []
        while i < len(args) and isinstance(args[i], ColumnRef):
            col = (args[i].table, args[i].column)
            if col not in keycols:
                raise DaxUnsupported(f"GROUPBY column {col[0]}[{col[1]}] is not in the grouped table")
            kept.append(col)
            i += 1
        rest = args[i:]
        if len(rest) % 2:
            raise DaxUnsupported("GROUPBY expects pairs of name and SUMX(CURRENTGROUP(), ...)")
        level_no = len(levels) + 1
        env = dataclasses.replace(
            e, ctx=ctx, row=fact, related=set(), cols=_prev_cols(levels, e), keycols=keycols
        )
        added: list[tuple[str, str]] = []
        new_cols: dict[str, str] = {}
        for j in range(0, len(rest), 2):
            name_node, agg = rest[j], rest[j + 1]
            if not isinstance(name_node, Str):
                raise DaxUnsupported("GROUPBY names must be string literals")
            if not (
                isinstance(agg, FuncCall)
                and agg.name in self._GROUP_AGGS
                and len(agg.args) == 2
                and isinstance(agg.args[0], FuncCall)
                and agg.args[0].name == "CURRENTGROUP"
            ):
                raise DaxUnsupported(
                    "GROUPBY aggregates must be SUMX/AVERAGEX/MINX/MAXX/COUNTX(CURRENTGROUP(), expr)"
                )
            body = self._expr(agg.args[1], env)
            canon = f"g{level_no}_{name_node.value}"
            added.append((canon, f"{self._GROUP_AGGS[agg.name]}({body})"))
            new_cols[name_node.value.casefold()] = f'"{canon}"'
        kept_names = tuple(keycols[k].strip('"') for k in kept)
        level = GroupLevel(keys=kept_names, added=tuple(added))
        new_keycols = {k: keycols[k] for k in kept}
        return fact, keys, (*levels, level), new_cols, new_keycols, ctx

    def _grouped_filter(self, node, e: _Env):
        """FILTER(<grouped table>, cond) or a bare grouped table -> (plan, fact)."""
        cond_node = None
        if isinstance(node, FuncCall) and node.name == "FILTER" and len(node.args) == 2:
            node, cond_node = node.args
        fact, keys, levels, cols, keycols, ctx = self._grouped_table(node, e)
        cond_sql = None
        if cond_node is not None:
            env = dataclasses.replace(
                e, ctx=ctx, row=fact, related=set(), cols=cols or _prev_cols(levels, e), keycols=keycols
            )
            cond_sql = self._expr(cond_node, env)
        plan = GroupedPlan(fact=fact, keys=keys, levels=levels, cond=cond_sql)
        return plan, ctx, keycols

    def _grouped_countrows(self, arg, e: _Env):
        probe = arg.args[0] if isinstance(arg, FuncCall) and arg.name == "FILTER" and arg.args else arg
        if not self._looks_grouped(probe, e):
            return None
        plan, ctx, _keycols = self._grouped_filter(arg, e)
        return self._add_leaf(e.out, "COUNT(*)", {plan.fact}, ctx, grouped=plan)

    def _grouped_calculate(self, args, e: _Env):
        if len(args) != 2 or not isinstance(args[0], FuncCall):
            return None
        target, flt = args
        if not (isinstance(flt, FuncCall) and flt.name == "FILTER" and len(flt.args) == 2):
            return None
        if not self._looks_grouped(flt.args[0], e):
            return None
        plan, ctx, keycols = self._grouped_filter(flt, e)
        if target.name == "DISTINCTCOUNT" and len(target.args) == 1 and isinstance(
            target.args[0], ColumnRef
        ):
            key = (target.args[0].table, target.args[0].column)
            if key not in keycols:
                raise DaxUnsupported(
                    f"DISTINCTCOUNT({key[0]}[{key[1]}]) is not a column of the grouped table"
                )
            return self._add_leaf(
                e.out, f"COUNT(DISTINCT {keycols[key]})", {plan.fact}, ctx, grouped=plan
            )
        if target.name == "COUNTROWS":
            return self._add_leaf(e.out, "COUNT(*)", {plan.fact}, ctx, grouped=plan)
        raise DaxUnsupported(
            f"CALCULATE({target.name}(...), FILTER(<grouped table>, ...)) is not supported "
            "(expected DISTINCTCOUNT(key) or COUNTROWS)"
        )

    # -- TOPN as a CALCULATE filter (6.7) -----------------------------------------------------

    def _resolve_topn(self, farg, e: _Env):
        """(TOPN call, environment where its table is evaluated) or None."""
        node, env = self._resolve_table_var(farg, e)
        is_var = node is not farg
        if isinstance(node, FuncCall) and node.name == "CALCULATETABLE" and node.args:
            inner, inner_env = self._resolve_table_var(node.args[0], env)
            inner_is_var = inner is not node.args[0]
            if isinstance(inner, FuncCall) and inner.name == "TOPN":
                if is_var or inner_is_var:
                    return inner, inner_env  # a VAR is a constant: no re-filtering
                ctx = env.ctx
                for f in node.args[1:]:
                    ctx = self._apply_filter_arg(f, ctx, env, ctx.filters)
                return inner, env.with_ctx(ctx)
            return None
        if isinstance(node, FuncCall) and node.name == "TOPN":
            return node, env
        return None

    @staticmethod
    def _filters_reach(model: SemanticModel, source: str, targets: set[str]) -> bool:
        """Can filters on `source` reach any of `targets` through active relationships?"""
        seen = {source}
        frontier = [source]
        while frontier:
            cur = frontier.pop()
            for r in model.relationships:
                if not r.is_active:
                    continue
                nxt = []
                if r.to_table == cur:  # one side filters the many side
                    nxt.append(r.from_table)
                if r.from_table == cur and r.cross_filtering_behavior == "bothDirections":
                    nxt.append(r.to_table)
                for t in nxt:
                    if t not in seen:
                        seen.add(t)
                        frontier.append(t)
        return bool(seen & targets)

    def _topn_filter(self, topn, ctx: Context, e: _Env, base: tuple) -> Context:
        node, tenv = topn
        args = node.args
        if tenv.ctx.time_shift is not None:
            raise DaxUnsupported("TOPN under a time shift is not supported")
        if len(args) < 3 or not isinstance(args[0], Num) or args[0].value < 1:
            raise DaxUnsupported("TOPN(n, table, [x], ...) needs a literal n >= 1")
        n = int(args[0].value)
        table_node, tbl_env = self._resolve_table_var(args[1], tenv)
        if not (
            isinstance(table_node, FuncCall)
            and table_node.name == "ADDCOLUMNS"
            and len(table_node.args) == 3
            and isinstance(table_node.args[1], Str)
        ):
            raise DaxUnsupported(
                "TOPN supported only over ADDCOLUMNS(SUMMARIZE(T, D[key]), \"x\", agg) "
                "ranked by [x]"
            )
        summarize, x_name, x_expr = table_node.args[0], table_node.args[1].value, table_node.args[2]
        if not (
            isinstance(summarize, FuncCall)
            and summarize.name == "SUMMARIZE"
            and len(summarize.args) == 2
            and isinstance(summarize.args[1], ColumnRef)
        ):
            raise DaxUnsupported("TOPN supported only over SUMMARIZE(T, D[key]) with one key column")
        order_by = args[2]
        if not (isinstance(order_by, MeasureRef) and order_by.name.casefold() == x_name.casefold()):
            raise DaxUnsupported("TOPN must be ranked by the ADDCOLUMNS column [x]")
        descending = True
        if len(args) >= 4:
            o = args[3]
            if isinstance(o, VarRef) and o.name.upper() in ("ASC", "DESC"):
                descending = o.name.upper() == "DESC"
            elif isinstance(o, Num) and o.value in (0, 1):
                descending = o.value == 0
            else:
                raise DaxUnsupported("TOPN order must be ASC, DESC, 0 or 1")
        key = summarize.args[1]
        source = summarize.args[0]
        source_filter = None
        if isinstance(source, FuncCall) and source.name == "FILTER" and len(source.args) == 2:
            t = self._table_node(source.args[0], tbl_env)
            if t is None or t.name != key.table:
                raise DaxUnsupported("SUMMARIZE may read FILTER(<key table>, cond) only")
            source_filter = self._expr(
                source.args[1], dataclasses.replace(tbl_env, row=t.name, related=None)
            )
            source = source.args[0]
        fact_ref = self._table_node(source, tbl_env)
        if fact_ref is None:
            raise DaxUnsupported("TOPN's SUMMARIZE must read a base table")
        # context transition: only CALCULATE(...) or a measure ranks per key; a bare aggregate
        # reads the outer context and every key ties
        transition = any(
            isinstance(n, MeasureRef) or (isinstance(n, FuncCall) and n.name == "CALCULATE")
            for n in _walk(x_expr)
        )
        sub = CompiledMeasure(name=f"topn:{x_name}", expr="")
        inner = x_expr
        if isinstance(inner, FuncCall) and inner.name == "CALCULATE" and len(inner.args) == 1:
            inner = inner.args[0]
        x_ctx = tbl_env.ctx
        sub.expr = self._expr(inner, _Env(x_ctx, sub, tbl_env.stack, {}))
        if sub.window_avg is not None or not sub.leaves:
            raise DaxUnsupported("TOPN ranking expression must aggregate model data")
        if any(leaf.ctx.use_relationships for leaf in sub.leaves.values()):
            raise DaxUnsupported("TOPN ranked through USERELATIONSHIP is not supported")
        leaf_tables = {t for leaf in sub.leaves.values() for t in leaf.tables}
        reaches = self._filters_reach(self.model, key.table, leaf_tables)
        all_rows = (not transition) or (not reaches)
        plan = TopnPlan(
            key_table=key.table,
            key_column=key.column,
            n=n,
            descending=descending,
            x=None if all_rows else sub,
            all_rows=all_rows,
            source_filter=source_filter,
        )
        token = self._token(e.out, ("topn", plan))
        col = qcol(key.table, key.column)
        sql = (
            f"({col} IN {token} OR ({col} IS NULL AND EXISTS "
            f'(SELECT 1 FROM {token} AS "__tn" WHERE "__tn"."__k" IS NULL)))'
        )
        ctx = ctx.with_col_clear(key.table, key.column, base)
        return ctx.with_filter(
            FilterPredicate(
                table=key.table, sql=sql, cols=frozenset({(key.table, key.column)})
            )
        )

    def _row_scalar(self, node: FuncCall, e: _Env) -> str:
        """CALCULATE(<aggregate of one column>, ALL(T)) inside a row predicate: a whole-table
        scalar expanded by the engine into an uncorrelated subquery over T's binding."""
        args = node.args
        if len(args) < 2 or not isinstance(args[0], FuncCall) or args[0].name not in _SIMPLE_AGGS:
            raise DaxUnsupported("context-dependent expression inside a row filter is unsupported")
        agg = args[0]
        if len(agg.args) != 1 or not isinstance(agg.args[0], ColumnRef):
            raise DaxUnsupported("whole-table scalar needs an aggregate of one column")
        table = agg.args[0].table
        for mod in args[1:]:
            ok = (
                isinstance(mod, FuncCall)
                and mod.name in ("ALL", "REMOVEFILTERS")
                and len(mod.args) == 1
                and self._table_node(mod.args[0], e) is not None
                and self._table_node(mod.args[0], e).name == table
            )
            if not ok:
                raise DaxUnsupported("whole-table scalar supports only ALL(T) as a modifier")
        sql = _SIMPLE_AGGS[agg.name].format(qcol(table, agg.args[0].column))
        return self._scalar_token(e.out, table, sql)

    @staticmethod
    def _token(out: CompiledMeasure, definition: tuple) -> str:
        digest = hashlib.sha1(repr(definition).encode()).hexdigest()[:10]  # noqa: S324
        token = f"__T{digest}__"
        out.tokens[token] = definition
        return token

    def _scalar_token(self, out: CompiledMeasure, table: str, agg_sql: str) -> str:
        return self._token(out, ("scalar", table, agg_sql))

    def _parse_datesinperiod(self, dip) -> TimeShift:
        if len(dip) != 4 or not isinstance(dip[0], ColumnRef):
            raise DaxUnsupported("DATESINPERIOD pattern not recognized")
        n, unit = _num_value(dip[2]), _unit_value(dip[3])
        if n is None or unit is None:
            raise DaxUnsupported("DATESINPERIOD pattern not recognized")
        return TimeShift("rolling", dip[0].table, dip[0].column, n=abs(n), unit=unit)

    # -- CALCULATE ------------------------------------------------------------------------

    def _calculate(self, args, e: _Env) -> str:
        if not args:
            raise DaxUnsupported("empty CALCULATE")
        ctx = e.ctx
        base = e.ctx.filters
        cleared = self._tables_cleared_by(args[1:], e)
        for farg in args[1:]:
            if isinstance(farg, FuncCall) and farg.name == "DATESBETWEEN":
                ctx = self._datesbetween(farg, ctx, e, base, cleared)
            else:
                ctx = self._apply_filter_arg(farg, ctx, e, base)
        return self._expr(args[0], e.with_ctx(ctx))

    def _tables_cleared_by(self, fargs, e: _Env) -> set[str]:
        out: set[str] = set()
        for fa in fargs:
            if isinstance(fa, FuncCall) and fa.name in ("ALL", "REMOVEFILTERS"):
                if not fa.args:
                    out.add("*")
                for a in fa.args:
                    if isinstance(a, ColumnRef):
                        out.add(a.table)
                    elif (t := self._table_node(a, e)) is not None:
                        out.add(t.name)
        return out

    # -- DATESBETWEEN windows: bounds read the query's filter context ----------------------------

    def _datesbetween(self, farg: FuncCall, ctx: Context, e: _Env, base: tuple, cleared: set) -> Context:
        if len(farg.args) != 3 or not isinstance(farg.args[0], ColumnRef):
            raise DaxUnsupported("DATESBETWEEN(D[c], start, end) only")
        dcol, lo, hi = farg.args
        if dcol.table not in cleared and "*" not in cleared:
            raise DaxUnsupported(
                f"DATESBETWEEN over {dcol.table}[{dcol.column}] needs ALL({dcol.table}) in the same "
                "CALCULATE: the bounds are evaluated in the outer filter context"
            )
        # the bounds are evaluated where the CALCULATE is (incoming context), not inside it
        benv = dataclasses.replace(e, ctx=e.ctx, row=None, related=None, bound=True)
        lo_sql = self._bound_value(lo, benv)
        hi_sql = self._bound_value(hi, benv)
        col = qcol(dcol.table, dcol.column)
        pred = FilterPredicate(
            table=dcol.table,
            sql=f"({col} >= {lo_sql} AND {col} <= {hi_sql})",
            cols=frozenset({(dcol.table, dcol.column)}),
        )
        # ALL(D) was applied by its own argument; the window replaces what ALL removed
        ctx = ctx.with_clear(dcol.table, base)
        return ctx.with_filter(pred)

    def _bound_value(self, node, benv: _Env) -> str:
        return self._expr(node, benv)

    def _ctx_token(self, e: _Env, table: str, agg_sql: str) -> str:
        """Scalar read in the outer (query) filter context of `table`, rendered once by the engine
        as a CTE over the table's binding filtered by the query's own filters on it."""
        extra = tuple(p.sql for p in e.ctx.filters if p.table == table)
        shift = None
        ts = e.ctx.time_shift
        if ts is not None and ts.date_table == table:
            if ts.kind != "sply":
                raise DaxUnsupported(
                    f"date-window bounds cannot be read under a {ts.kind} time shift of {table}"
                )
            shift = ("year", -1, ts.date_column)
        # an enclosing ALL(D) removed the query's filters on D from the context the bound reads
        clears = e.ctx.clears
        skip_all = "*" in clears or table in clears
        skip_cols = tuple(
            sorted(c for x in clears if isinstance(x, tuple) for t, c in [x] if t == table)
        )
        return self._token(e.out, ("ctx", table, agg_sql, extra, shift, skip_all, skip_cols))

    def _bound_func(self, node: FuncCall, e: _Env) -> str:
        fname, args = node.name, node.args
        if fname in ("MIN", "MAX") and len(args) == 1 and isinstance(args[0], ColumnRef):
            col = qcol(args[0].table, args[0].column)
            return self._ctx_token(e, args[0].table, f"{fname}({col})")
        if fname == "SELECTEDVALUE" and args and isinstance(args[0], ColumnRef):
            col = qcol(args[0].table, args[0].column)
            tok = self._ctx_token(
                e, args[0].table, f"CASE WHEN COUNT(DISTINCT {col}) = 1 THEN MAX({col}) END"
            )
            if len(args) > 1:
                return f"COALESCE({tok}, {self._expr(args[1], e)})"
            return tok
        if fname == "STARTOFYEAR" and len(args) == 1 and isinstance(args[0], ColumnRef):
            col_ref = args[0]
            anchor = self._ctx_token(
                e, col_ref.table, f"MAX({qcol(col_ref.table, col_ref.column)})"
            )
            return self._token(
                e.out, ("startofyear", col_ref.table, col_ref.column, anchor)
            )
        if fname in _SIMPLE_AGGS or fname in ("COUNTROWS", "SUMX", "AVERAGEX", "CALCULATE"):
            raise DaxUnsupported(
                f"{fname} inside a DATESBETWEEN bound is not supported (bounds use MIN, MAX, "
                "SELECTEDVALUE, STARTOFYEAR and scalar functions of them)"
            )
        return self._func_core(node, e)

    def _predicate_columns(self, pred) -> set[tuple[str, str]]:
        return {(n.table, n.column) for n in _walk(pred) if isinstance(n, ColumnRef)}

    def _column_override(
        self, pred, ctx: Context, e: _Env, keep: bool = False, base: tuple = ()
    ) -> Context:
        """A CALCULATE predicate on T[c] replaces the existing filter on T[c] (unless KEEPFILTERS)."""
        cols = self._predicate_columns(pred)
        tables = {t for t, _ in cols}
        if len(tables) != 1:
            raise DaxUnsupported("filter predicate must reference exactly one table")
        table = next(iter(tables))
        if not keep:
            for t, c in cols:
                ctx = ctx.with_col_clear(t, c, base)
        sql = self._expr(pred, dataclasses.replace(e, ctx=ctx, row=table, related=None))
        return ctx.with_filter(FilterPredicate(table=table, sql=sql, cols=frozenset(cols)))

    def _apply_filter_arg(self, farg, ctx: Context, e: _Env, base: tuple = ()) -> Context:  # noqa: C901
        env = e.with_ctx(ctx)
        topn = self._resolve_topn(farg, e)
        if topn is not None:
            return self._topn_filter(topn, ctx, e, base)
        match farg:
            case BinOp() | UnaryOp(op="NOT") | FuncCall(name="ISBLANK"):
                return self._column_override(farg, ctx, e, base=base)
            case FuncCall(name="KEEPFILTERS", args=(inner,)):
                if isinstance(inner, BinOp | UnaryOp):
                    return self._column_override(inner, ctx, e, keep=True, base=base)
                if isinstance(inner, FuncCall) and inner.name == "FILTER":
                    return self._apply_filter_arg(inner, ctx, e, base)
                raise DaxUnsupported("KEEPFILTERS argument not in tier-1 set")
            case FuncCall(name="FILTER", args=(tbl, pred)):
                return self._filter_arg(tbl, pred, ctx, env, base)
            case FuncCall(name="ALL" | "REMOVEFILTERS", args=fargs):
                if not fargs:
                    return ctx.with_clear("*", base)
                for fa in fargs:
                    if (t := self._table_node(fa, env)) is not None:
                        ctx = ctx.with_clear(t.name, base)
                    elif isinstance(fa, ColumnRef):
                        ctx = ctx.with_col_clear(fa.table, fa.column, base)
                    else:
                        raise DaxUnsupported("ALL() over expressions unsupported")
                return ctx
            case FuncCall(name="ALLEXCEPT", args=fargs) if fargs:
                t = self._table_node(fargs[0], env)
                if t is None:
                    raise DaxUnsupported("ALLEXCEPT expects a table first")
                ctx = ctx.with_clear(t.name, base)
                for fa in fargs[1:]:
                    if not isinstance(fa, ColumnRef) or fa.table != t.name:
                        raise DaxUnsupported("ALLEXCEPT keeps columns of its own table only")
                    ctx = ctx.with_keep(fa.table, fa.column)
                return ctx
            case FuncCall(name="TREATAS", args=(TableCtor() as ctor, ColumnRef() as col)):
                pred = BinOp("IN", col, ctor)
                return self._column_override(pred, ctx, e, base=base)
            case FuncCall(name="VALUES" | "DISTINCT", args=(ColumnRef(),)):
                return ctx  # the current values are the current filter
            case FuncCall(name="SAMEPERIODLASTYEAR", args=(ColumnRef() as dcol,)):
                return ctx.with_shift(TimeShift("sply", dcol.table, dcol.column))
            case FuncCall(name="DATEADD", args=(ColumnRef() as dcol, n_node, unit_node)):
                n, unit = _num_value(n_node), _unit_value(unit_node)
                if (n, unit) in ((-12, "month"), (-1, "year")):
                    return ctx.with_shift(TimeShift("sply", dcol.table, dcol.column))
                raise DaxUnsupported(f"DATEADD({n},{unit}) not in tier-1 set")
            case FuncCall(name="DATESINPERIOD", args=dip):
                return ctx.with_shift(self._parse_datesinperiod(dip))
            case FuncCall(name="USERELATIONSHIP", args=(ColumnRef() as c1, ColumnRef() as c2)):
                return ctx.with_relationship(
                    (f"{c1.table}.{c1.column}", f"{c2.table}.{c2.column}")
                )
        raise DaxUnsupported(
            f"CALCULATE modifier not in tier-1 set: {getattr(farg, 'name', farg)}"
        )

    def _filter_arg(
        self, tbl, pred, ctx: Context, env: _Env, base: tuple = ()
    ) -> Context:
        """FILTER(<table expression>, pred) as a CALCULATE argument."""
        if isinstance(tbl, FuncCall) and tbl.name in ("VALUES", "DISTINCT") and tbl.args:
            if not isinstance(tbl.args[0], ColumnRef):
                raise DaxUnsupported(f"FILTER({tbl.name}(...)) expects a column")
            # iterates the current distinct values of c: intersects with the current filter
            return self._column_override(pred, ctx, env, keep=True)
        if isinstance(tbl, FuncCall) and tbl.name == "ALL" and len(tbl.args) == 1:
            inner = tbl.args[0]
            if isinstance(inner, ColumnRef):
                ctx = ctx.with_col_clear(inner.table, inner.column, base)
                return self._column_override(pred, ctx, env, keep=True)
            t = self._table_node(inner, env)
            if t is not None:
                ctx = ctx.with_clear(t.name, base)
                return self._add_row_filter(pred, t.name, env.with_ctx(ctx), set())
        t = self._table_node(tbl, env)
        if t is not None:
            return self._add_row_filter(pred, t.name, env.with_ctx(ctx), set())
        raise DaxUnsupported("FILTER over this table expression is not in the tier-1 set")

    # -- SWITCH / RANKX ---------------------------------------------------------------------

    def _switch(self, args, e: _Env) -> str:
        if len(args) < 3:
            raise DaxUnsupported("SWITCH expects at least 3 arguments")
        subject_node = args[0]
        rest = list(args[1:])
        default = "NULL"
        if len(rest) % 2 == 1:
            default = self._expr(rest.pop(), e)
        # SWITCH(TRUE(), cond, val, ...) -> CASE WHEN cond THEN val ...
        if isinstance(subject_node, Bool) and subject_node.value:
            cases = " ".join(
                f"WHEN {self._expr(rest[i], e)} THEN {self._expr(rest[i + 1], e)}"
                for i in range(0, len(rest), 2)
            )
            return f"(CASE {cases} ELSE {default} END)"
        # Standard SWITCH(expr, match, val, ...) -> CASE expr WHEN match THEN val ...
        subject = self._expr(subject_node, e)
        cases = " ".join(
            f"WHEN {self._expr(rest[i], e)} THEN {self._expr(rest[i + 1], e)}"
            for i in range(0, len(rest), 2)
        )
        return f"(CASE {subject} {cases} ELSE {default} END)"

    def _rankx(self, args, e: _Env) -> str:
        """RANKX(table, expr [, value, order, ties]) -> RANK() OVER (ORDER BY expr).

        Supported patterns:
          RANKX(ALL(Table), [Measure])       -> rank over all values
          RANKX(VALUES(Table[col]), [Measure]) -> rank within current filter
        The result is a window function leaf.
        """
        if len(args) < 2:
            raise DaxUnsupported("RANKX expects at least 2 arguments")
        table_arg, expr_arg = args[0], args[1]
        order = "DESC"  # PBI default: rank 1 = largest
        if len(args) >= 4:
            order_node = args[3]
            if isinstance(order_node, Num) and order_node.value == 2:
                order = "ASC"
            elif isinstance(order_node, Str) and order_node.value.upper() == "ASC":
                order = "ASC"

        inner = self._expr(expr_arg, e)

        tref = None
        if isinstance(table_arg, FuncCall) and table_arg.name in ("ALL", "ALLSELECTED"):
            tref = self._table_node(table_arg.args[0], e) if table_arg.args else None
        elif isinstance(table_arg, FuncCall) and table_arg.name == "VALUES":
            tref = (
                TableRef(table_arg.args[0].table)
                if table_arg.args and isinstance(table_arg.args[0], ColumnRef)
                else None
            )
        else:
            tref = self._table_node(table_arg, e)

        if tref is None:
            raise DaxUnsupported("RANKX table argument not recognized")

        window_sql = f"RANK() OVER (ORDER BY {inner} {order})"
        return self._add_leaf(e.out, window_sql, {tref.name}, e.ctx)
