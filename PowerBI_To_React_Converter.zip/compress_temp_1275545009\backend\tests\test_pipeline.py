import json
from pathlib import Path

import pytest

from app.agents.pipeline import run_conversion
from app.agents.tier2 import Tier2Result, propose_and_validate
from app.parsers.bundle import load_pbip
from tests.fakes import CatalogCursor
from tests.test_validation import FakeCursor

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "medical_cost_command_center"


class FakeConnection:
    def close(self):
        pass


def make_cursor():
    cur = FakeCursor()
    cur.connection = FakeConnection()
    return cur


@pytest.fixture(scope="module")
def bundle():
    return load_pbip(FIXTURE)


@pytest.fixture()
def cursor_factory(bundle):
    return lambda: CatalogCursor(bundle.model)


class TestPipeline:
    def test_full_run_emits_stages_and_persists(self, bundle, tmp_path_factory, cursor_factory):
        root = tmp_path_factory.mktemp("run")
        run = run_conversion(bundle, "conv-1", root, cursor_factory)
        stages = {e["stage"] for e in run.events}
        assert stages >= {"binding", "compile", "validate", "report"}
        persisted = json.loads((root / "conversion_run.json").read_text())
        assert persisted["summary"]["visuals_total"] == 63
        assert persisted["events"][0]["stage"] == "binding"

    def test_repair_without_llm_stops_cleanly(self, bundle, tmp_path_factory, cursor_factory):
        root = tmp_path_factory.mktemp("run2")
        run = run_conversion(bundle, "conv-2", root, cursor_factory, llm_client=None)
        # parked measure exists but no llm -> repair round emits and stops
        repair_events = [e for e in run.events if e["stage"] == "repair"]
        assert any("no further automatic fix" in e["message"] for e in repair_events)

    def test_llm_accepted_measure_recorded(self, bundle, tmp_path_factory, cursor_factory):
        root = tmp_path_factory.mktemp("run3")

        class FakeLLM:
            def chat(self, messages, **kwargs):
                return '{"sql": "SELECT 42 AS RESULT"}'

        run = run_conversion(
            bundle, "conv-3", root, cursor_factory, llm_client=FakeLLM(), ai_scope="all"
        )
        assert "Measures Above Benchmark" in run.tier2_accepted
        assert run.tier2_accepted["Measures Above Benchmark"] == "SELECT 42 AS RESULT"


class TestTier2:
    def test_rejects_dml(self, bundle):
        from app.binding.resolver import build_binding_map

        responses = iter(
            [
                '{"sql": "DROP TABLE x"}',
                '{"sql": "SELECT 1 AS RESULT"}',
            ]
        )

        class FakeLLM:
            def chat(self, messages, **kwargs):
                return next(responses)

        cur = make_cursor()
        result = propose_and_validate(
            bundle.model,
            build_binding_map(bundle.model),
            "Measures Above Benchmark",
            cur,
            client=FakeLLM(),
        )
        assert result.accepted
        assert result.attempts == 2
        assert any("rejected non-SELECT" in t for t in result.trace)

    def test_execution_error_feeds_retry(self, bundle):
        from app.binding.resolver import build_binding_map

        responses = iter(
            ['{"sql": "SELECT bad_col AS RESULT"}', '{"sql": "SELECT 7 AS RESULT"}']
        )

        class FakeLLM:
            def chat(self, messages, **kwargs):
                return next(responses)

        cur = make_cursor()
        original_execute = cur.execute

        def execute(sql):
            if "bad_col" in sql:
                raise RuntimeError("invalid identifier BAD_COL")
            return original_execute(sql)

        cur.execute = execute
        result = propose_and_validate(
            bundle.model,
            build_binding_map(bundle.model),
            "Measures Above Benchmark",
            cur,
            client=FakeLLM(),
        )
        assert result.accepted and result.attempts == 2
        assert isinstance(result, Tier2Result)
