import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { PdfComparison } from '../pages/PdfComparison'
import { useWizard } from '../store/wizard'
import { comparison } from './parityFixtures'

const compareMock = vi.hoisted(() => vi.fn())
vi.mock('../dashboard/parity/useParityRunner', () => ({
  useParityRunner: () => ({ comparePage: compareMock, captureHost: null, capturing: false }),
}))

const reportPagesC1 = [
  { page: 'p1', display_name: 'Overview', ordinal: 0 },
  { page: 'p2', display_name: 'Details', ordinal: 1 },
  { page: 'p3', display_name: 'Summary', ordinal: 2 },
]

const batch = {
  id: 'b1',
  created_at: 1_700_000_000,
  confirmed: false,
  confirmed_at: null,
  confirmations: [],
  pdfs: [
    {
      index: 0,
      file: 'sales.pdf',
      pages: 2,
      error: null,
      confident: false,
      warnings: ['page 2 is ambiguous'],
      candidates: [
        {
          conversion_id: 'c1',
          report: 'Sales Report',
          job_name: 'Q3 migration',
          uploaded_at: 1_700_000_000,
          converted_at: 1_700_000_100,
          score: 0.9,
          pages: [
            { pdf_page: 1, page: 'p1', display_name: 'Overview', score: 0.95, confident: true },
            { pdf_page: 2, page: 'p2', display_name: 'Details', score: 0.4, confident: false },
          ],
          report_pages: reportPagesC1,
        },
      ],
    },
  ],
  reports: [
    { conversion_id: 'c1', report: 'Sales Report', job_name: 'Q3 migration', ran_at: 1_700_000_100, pages: reportPagesC1 },
    {
      conversion_id: 'c2',
      report: 'HR Report',
      job_name: 'HR job',
      ran_at: 1_700_000_200,
      pages: [{ page: 'h1', display_name: 'Headcount', ordinal: 0 }],
    },
  ],
}

const reportRows = [
  {
    conversion_id: 'c1',
    report: 'Sales Report',
    job_name: 'Q3 migration',
    ran_at: 1_700_000_100,
    page: 'p1',
    display_name: 'Overview',
    kind: 'image',
    run_id: 'r1',
    run_at: 1_700_000_500,
    similarity: 82,
    findings: 3,
    fixable: 1,
    numbers_printed: 3,
    numbers_matched: 2,
    visuals_mismatched: 1,
    filters: [{ slicer: 'Year', value: 2024 }],
    trend: [70, 82],
  },
  {
    conversion_id: 'c1',
    report: 'Sales Report',
    job_name: 'Q3 migration',
    ran_at: 1_700_000_100,
    page: 'p3',
    display_name: 'Summary',
    kind: 'image',
    run_id: 'r2',
    run_at: 1_700_000_500,
    similarity: 99,
    findings: 0,
    fixable: 0,
    numbers_printed: 1,
    numbers_matched: 1,
    visuals_mismatched: 0,
    filters: null,
    trend: [99],
  },
]

interface Calls {
  confirmBody?: unknown
  created: boolean
  deleted: string[]
  ran: boolean
}

function install(calls: Calls) {
  let batches = [
    { id: 'old1', created_at: 1_699_000_000, files: ['old.pdf'], pdf_count: 1, confirmed: true, confirmed_at: 1_699_000_100, conversions: 1 },
  ]
  vi.stubGlobal(
    'fetch',
    vi.fn(async (url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET'
      const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status })
      if (url === '/api/v1/connections') return json([{ id: 'conn-1', name: 'Prod' }])
      if (url === '/api/v1/visual-compare/batches' && method === 'POST') {
        calls.created = true
        return json(batch)
      }
      if (url === '/api/v1/visual-compare/batches') return json({ batches })
      if (url === '/api/v1/visual-compare/batches/b1/confirm') {
        calls.confirmBody = JSON.parse(init!.body as string)
        return json({ stored: 2, superseded_comparisons: 1, batch: { ...batch, confirmed: true, confirmed_at: 1_700_000_050 } })
      }
      if (url === '/api/v1/visual-compare/batches/b1/report?format=json') return json(calls.ran ? reportRows : [])
      if (url === '/api/v1/visual-compare/batches/old1' && method === 'DELETE') {
        calls.deleted.push('old1')
        batches = []
        return new Response(null, { status: 204 })
      }
      if (url === '/api/v1/visual-compare/batches/old1')
        return json({
          ...batch,
          id: 'old1',
          confirmed: true,
          confirmed_at: 1,
          confirmations: [{ file_index: 0, conversion_id: 'c1', pages: [{ pdf_page: 1, page: 'p1' }, { pdf_page: 2, page: 'p3' }] }],
        })
      if (url === '/api/v1/visual-compare/batches/old1/report?format=json') return json(reportRows)
      if (url === '/api/v1/conversions/c1/dashboard/visual-compare')
        return json({ pages: [{ ...comparison, page: 'p1', values: null }] })
      if (url.endsWith('/p1/history'))
        return json({
          page: 'p1',
          runs: [
            { run_id: 'r1', page: 'p1', display_name: 'Overview', kind: 'image', batch_id: 'b1', ts: 1_700_000_500, summary: { similarity: 82 }, has_images: { reference: true, rendered: true } },
          ],
          trend: [{ run_id: 'r1', ts: 1_700_000_500, kind: 'image', value: 82 }],
        })
      return json({ detail: 'unexpected ' + method + ' ' + url }, 404)
    }),
  )
}

function renderPage() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false }, mutations: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <MemoryRouter>
        <PdfComparison />
      </MemoryRouter>
    </QueryClientProvider>,
  )
}

async function uploadAndMatch(user: ReturnType<typeof userEvent.setup>) {
  const file = new File(['%PDF'], 'sales.pdf', { type: 'application/pdf' })
  await user.upload(screen.getByLabelText('PDF files'), file)
  await user.click(screen.getByRole('button', { name: 'Match PDFs' }))
  await screen.findByTestId('match-table')
}

describe('PdfComparison', () => {
  let calls: Calls
  beforeEach(() => {
    calls = { created: false, deleted: [], ran: false }
    useWizard.setState({ connectionId: 'conn-1' })
    compareMock.mockReset()
    compareMock.mockImplementation(async () => {
      calls.ran = true
      return { comparison, values: null, valuesNote: null, filters: [] }
    })
    install(calls)
  })
  afterEach(() => vi.unstubAllGlobals())

  it('uploads, shows the match table with flags and warnings, and lets a match be corrected', async () => {
    const user = userEvent.setup()
    renderPage()
    await uploadAndMatch(user)

    expect(calls.created).toBe(true)
    expect(screen.getByText('sales.pdf')).toBeInTheDocument()
    expect(screen.getByText('page 2 is ambiguous')).toBeInTheDocument()
    // the top candidate is preselected, labelled "report — job · time"
    expect(screen.getByRole('combobox', { name: 'Job for sales.pdf' })).toHaveTextContent(
      /Sales Report — Q3 migration · /,
    )
    // confident row vs low-confidence row
    expect(screen.getByTestId('row-0-1')).toHaveAttribute('data-low', 'false')
    expect(screen.getByTestId('row-0-2')).toHaveAttribute('data-low', 'true')
    expect(within(screen.getByTestId('row-0-2')).getByText('low confidence')).toBeInTheDocument()

    const select = screen.getByLabelText('sales.pdf page 2 match')
    expect(select).toHaveValue('p2')
    await user.selectOptions(select, 'p3')
    expect(select).toHaveValue('p3')
    expect(screen.getByTestId('row-0-2')).toHaveAttribute('data-low', 'false')
    await user.selectOptions(select, '')
    expect(within(screen.getByTestId('row-0-2')).getByText('not matched')).toBeInTheDocument()
  })

  it('switching the job offers every stored report (searchable) and guesses pages by order', async () => {
    const user = userEvent.setup()
    renderPage()
    await uploadAndMatch(user)
    await user.click(screen.getByRole('combobox', { name: 'Job for sales.pdf' }))
    // candidates first, then the other stored reports
    expect(within(screen.getByRole('listbox')).getAllByRole('option').map((o) => o.textContent?.split(' — ')[0])).toEqual([
      'Sales Report',
      'HR Report',
    ])
    await user.type(screen.getByRole('searchbox'), 'hr job')
    await user.click(within(screen.getByRole('listbox')).getByRole('option'))
    expect(screen.getByRole('combobox', { name: 'Job for sales.pdf' })).toHaveTextContent(/HR Report — HR job/)
    // an ordinal guess is never "confident"
    expect(screen.getByTestId('row-0-1')).toHaveAttribute('data-low', 'true')
    expect(screen.getByLabelText('sales.pdf page 1 match')).toHaveValue('h1')
    expect(screen.getByLabelText('sales.pdf page 2 match')).toHaveValue('')
  })

  it('confirms the corrected matches, runs one conversion, and shows results, downloads and details', async () => {
    const user = userEvent.setup()
    renderPage()
    await uploadAndMatch(user)
    await user.selectOptions(screen.getByLabelText('sales.pdf page 2 match'), 'p3')
    await user.click(screen.getByRole('button', { name: 'Confirm matches' }))

    await waitFor(() =>
      expect(calls.confirmBody).toEqual({
        pdfs: [
          {
            file_index: 0,
            conversion_id: 'c1',
            pages: [
              { pdf_page: 1, page: 'p1' },
              { pdf_page: 2, page: 'p3' },
            ],
          },
        ],
      }),
    )
    expect(await screen.findByText(/Stored 2 references; 1 earlier comparison superseded\./)).toBeInTheDocument()

    await user.click(screen.getByRole('button', { name: 'Run comparison' }))
    await waitFor(() => expect(compareMock).toHaveBeenCalledTimes(2))
    expect(compareMock.mock.calls.map((c) => [c[0], c[1].batchId])).toEqual([
      ['p1', 'b1'],
      ['p3', 'b1'],
    ])

    const results = await screen.findByTestId('results')
    await within(results).findByTestId('result-p1')
    const row = within(results).getByTestId('result-p1')
    expect(within(row).getByText('82% similar')).toBeInTheDocument()
    expect(within(row).getByText('Year=2024')).toBeInTheDocument()
    expect(within(row).getByText('2 / 3')).toBeInTheDocument()

    expect(within(results).getByRole('link', { name: /JSON/ })).toHaveAttribute(
      'href',
      '/api/v1/visual-compare/batches/b1/report?format=json',
    )
    expect(within(results).getByRole('link', { name: /XLSX/ })).toHaveAttribute(
      'href',
      '/api/v1/visual-compare/batches/b1/report?format=xlsx',
    )

    // the details card opens on the first page with problems
    const details = await screen.findByTestId('details')
    expect(within(details).getByText('Overview')).toBeInTheDocument()
    expect(await within(details).findByText('Revenue chart')).toBeInTheDocument()
    expect(await within(details).findByTestId('page-history')).toBeInTheDocument()

    // another row can be opened
    await user.click(screen.getByRole('button', { name: 'Details for Summary' }))
    expect(await screen.findByText('No stored comparison for this page.')).toBeInTheDocument()
  })

  it('reports a page that failed to compare and keeps going', async () => {
    compareMock.mockReset()
    compareMock.mockImplementationOnce(async () => {
      throw new Error('snowflake down')
    })
    compareMock.mockImplementation(async () => {
      calls.ran = true
      return { comparison, values: null, valuesNote: null, filters: [] }
    })
    const user = userEvent.setup()
    renderPage()
    await uploadAndMatch(user)
    await user.click(screen.getByRole('button', { name: 'Confirm matches' }))
    await user.click(await screen.findByRole('button', { name: 'Run comparison' }))
    expect(await screen.findByText('Overview: snowflake down')).toBeInTheDocument()
    expect(compareMock).toHaveBeenCalledTimes(2)
  })

  it('lists earlier batches; opens one and deletes it', async () => {
    const user = userEvent.setup()
    renderPage()
    const history = await screen.findByTestId('batch-history')
    expect(await within(history).findByText('old.pdf')).toBeInTheDocument()

    await user.click(within(history).getByRole('button', { name: 'Open batch old.pdf' }))
    // a confirmed batch shows its saved matches and stored results
    expect(await screen.findByTestId('match-table')).toBeInTheDocument()
    expect(screen.getByLabelText('sales.pdf page 2 match')).toHaveValue('p3')
    expect(await screen.findByTestId('result-p1')).toBeInTheDocument()

    await user.click(within(history).getByRole('button', { name: 'Delete batch old.pdf' }))
    await waitFor(() => expect(calls.deleted).toEqual(['old1']))
    await waitFor(() => expect(screen.queryByTestId('match-table')).toBeNull())
    expect(await within(history).findByText('No earlier batches.')).toBeInTheDocument()
  })
})
