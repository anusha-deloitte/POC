import json
import threading
import zipfile

import pytest

from app.core.config import get_settings
from app.core.logging import append_jsonl, redact
from app.ir.report import ReportBundle
from app.services.ingest import IngestError, IngestService, safe_extract_zip


def _zip(path, n=3, size=10):
    with zipfile.ZipFile(path, "w") as zf:
        for i in range(n):
            zf.writestr(f"f{i}.txt", "a" * size + str(i))


def test_zip_member_limit_explicit(tmp_path):
    z = tmp_path / "a.zip"
    _zip(z, n=3)
    with pytest.raises(IngestError, match="too many"):
        safe_extract_zip(z, tmp_path / "o", max_members=2, max_uncompressed=10**6)


def test_zip_size_limit_from_settings(tmp_path, monkeypatch):
    z = tmp_path / "a.zip"
    _zip(z, n=2, size=1000)
    monkeypatch.setenv("PBIC_MAX_UNCOMPRESSED_BYTES", "100")
    get_settings.cache_clear()
    try:
        with pytest.raises(IngestError, match="too large"):
            safe_extract_zip(z, tmp_path / "o")
    finally:
        monkeypatch.delenv("PBIC_MAX_UNCOMPRESSED_BYTES")
        get_settings.cache_clear()


def test_zip_member_limit_from_settings(tmp_path, monkeypatch):
    z = tmp_path / "a.zip"
    _zip(z, n=3)
    monkeypatch.setenv("PBIC_MAX_ZIP_MEMBERS", "1")
    get_settings.cache_clear()
    try:
        with pytest.raises(IngestError, match="too many"):
            safe_extract_zip(z, tmp_path / "o")
    finally:
        monkeypatch.delenv("PBIC_MAX_ZIP_MEMBERS")
        get_settings.cache_clear()


def test_save_bundle_roundtrip_and_unknown(tmp_path, contoso_pbip):
    svc = IngestService(tmp_path)
    stored = svc.ingest_folder(contoso_pbip)
    bundle = svc.load_bundle(stored.id)
    svc.save_bundle(stored.id, bundle)
    assert svc.load_bundle(stored.id) == bundle
    with pytest.raises(IngestError, match="unknown conversion"):
        svc.save_bundle("00000000-0000-0000-0000-000000000000", bundle)
    assert isinstance(bundle, ReportBundle)


def test_redacts_passcode_and_client_secret():
    out = redact({"passcode": "123456", "nested": {"client_secret": "x", "ok": 1}})
    assert out["passcode"] != "123456"
    assert out["nested"]["client_secret"] != "x"
    assert out["nested"]["ok"] == 1


def test_parallel_appends_are_whole_lines(tmp_path):
    f = tmp_path / "e.jsonl"

    def work(t):
        for i in range(50):
            append_jsonl(f, "evt", thread=t, i=i, pad="x" * 2000)

    ts = [threading.Thread(target=work, args=(t,)) for t in range(8)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    lines = f.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 400
    assert all(json.loads(line)["event"] == "evt" for line in lines)


def test_storage_isolated_under_temp():
    import tempfile
    from pathlib import Path

    assert Path(tempfile.gettempdir()).resolve() in get_settings().storage_dir.resolve().parents
