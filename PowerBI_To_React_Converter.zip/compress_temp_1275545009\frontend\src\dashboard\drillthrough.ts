/** Drill-through: which pages a visual can drill to and the filters the target page opens with
 * (Power BI's default "Keep all filters"). */
import type { DataPoint } from './dataPoint'
import type { DashboardSpec, FilterClause, PageSpec, VisualSpec } from './types'

/** Every other page with at least ONE drill-through field the visual uses (a column in
 * `dim_keys`, a measure in `measure_keys`). "Any", not "all": with "all", reports commonly have
 * unreachable drill pages. */
export function drillTargets(
  spec: Pick<DashboardSpec, 'pages'>,
  visual: Pick<VisualSpec, 'dim_keys' | 'measure_keys'>,
  fromPage: string,
): PageSpec[] {
  return spec.pages.filter(
    (p) =>
      p.name !== fromPage &&
      (p.drillthrough ?? []).some((f) =>
        f.measure
          ? visual.measure_keys.includes(f.measure)
          : visual.dim_keys.includes(`${f.table}.${f.column}`),
      ),
  )
}

/** Each `Table.Column` of a point as a filter (BLANK stays NULL). */
export function pointClauses(point: DataPoint): FilterClause[] {
  return Object.entries(point).map(([key, value]) => {
    const dot = key.indexOf('.')
    return { table: key.slice(0, dot), column: key.slice(dot + 1), values: [value ?? null] }
  })
}

/** The filters a drill / tooltip page opens with: the point, then everything filtering the source
 * visual (its request filters except report filters, which every page applies already), then the
 * visual's own query filters; all tagged with `source`. */
export function contextClauses(
  visual: Pick<VisualSpec, 'query'>,
  point: DataPoint,
  requestFilters: FilterClause[],
  source: 'drillthrough' | 'tooltip',
): FilterClause[] {
  return [
    ...pointClauses(point),
    ...requestFilters.filter((f) => f.source !== 'report_filter'),
    ...(visual.query?.filters ?? []),
  ].map((f) => ({ ...f, source }))
}

const WORDS: Record<string, string> = {
  in: 'is',
  eq: 'is',
  not_in: 'is not',
  neq: 'is not',
  contains: 'contains',
  not_contains: 'does not contain',
  starts_with: 'starts with',
  not_starts_with: 'does not start with',
  gt: 'is greater than',
  gte: 'is greater than or equal to',
  lt: 'is less than',
  lte: 'is less than or equal to',
  is_blank: 'is blank',
  is_not_blank: 'is not blank',
  is_empty: 'is empty',
  is_not_empty: 'is not empty',
  or: 'matches any of',
  relative: 'is in a relative range',
  topn: 'is in the top N',
}

const shown = (v: unknown) => (v === null || v === undefined || v === '' ? '(Blank)' : String(v))

/** "Country is France", "Country is not France", "Country is (Blank)". */
export function clauseText(f: FilterClause): string {
  const op = f.op ?? 'in'
  const words = WORDS[op] ?? op
  const noValue = ['is_blank', 'is_not_blank', 'is_empty', 'is_not_empty', 'relative', 'topn', 'or'].includes(op)
  return noValue ? `${f.column} ${words}` : `${f.column} ${words} ${f.values.map(shown).join(', ')}`
}
