"""Snowflake Cortex as an LLM provider: SNOWFLAKE.CORTEX.COMPLETE on the conversion's
own signed-in Snowflake session (no extra credentials).

Messages are always bound as parameters, never formatted into the SQL text, and the
prompt text is never logged.
"""

from __future__ import annotations

import json
import re
import time
from collections.abc import Callable, Iterator
from contextlib import contextmanager, nullcontext
from contextvars import ContextVar
from typing import Any

from app.core.logging import get_logger, log_event
from app.services.llm_errors import LlmError

_logger = get_logger("cortex")

_SQL = "SELECT SNOWFLAKE.CORTEX.COMPLETE(%s, PARSE_JSON(%s), PARSE_JSON(%s))"
_MAX_ATTEMPTS = 3
_TRANSIENT_RE = re.compile(
    r"429|too many requests|rate limit|throttl|temporarily unavailable|service unavailable"
    r"|timed? ?out|50[234]",
    re.IGNORECASE,
)
_PRIVILEGE_RE = re.compile(
    r"unknown function|does not exist or not authorized|insufficient privileges", re.IGNORECASE
)
_MODEL_RE = re.compile(r"model.*(not available|unavailable|not found|not supported)", re.IGNORECASE)

_context: ContextVar[str] = ContextVar("cortex_llm_context", default="ai_llm")


class CortexError(LlmError):
    pass


@contextmanager
def llm_call_context(label: str) -> Iterator[None]:
    """Label used as the audit context of every Cortex call inside the block."""
    token = _context.set(label)
    try:
        yield
    finally:
        _context.reset(token)


def _audit(cursor: Any, context: str):
    try:
        from app.services.query_audit import audit_stage
    except ImportError:  # phase 08 not present: run without auditing
        return nullcontext()
    return audit_stage(cursor, "ai_llm", context)


def _parse_reply(value: Any) -> tuple[str, dict]:
    data = value
    if isinstance(value, str | bytes):
        try:
            data = json.loads(value)
        except ValueError as e:
            raise CortexError(f"Cortex returned a non-JSON response: {str(value)[:200]}") from e
    if not isinstance(data, dict):
        raise CortexError(f"Cortex returned a non-JSON response: {str(value)[:200]}")
    choices = data.get("choices") or []
    if not choices:
        raise CortexError("Cortex returned no choices")
    first = choices[0] if isinstance(choices[0], dict) else {}
    text = first.get("messages")
    if text is None and isinstance(first.get("message"), dict):
        text = first["message"].get("content")
    if not text:
        raise CortexError("Cortex returned an empty completion")
    usage = data.get("usage") if isinstance(data.get("usage"), dict) else {}
    return str(text), usage


class CortexClient:
    provider = "cortex"

    def __init__(
        self,
        cursor_factory: Callable[[], Any],
        model: str = "claude-3-5-sonnet",
        temperature: float = 0.0,
        max_tokens: int = 4096,
    ):
        self._cursor_factory = cursor_factory
        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens

    @property
    def label(self) -> str:
        return f"Cortex ({self.model})"

    def _hint(self, err: str) -> str:
        if _PRIVILEGE_RE.search(err):
            return (
                " The Snowflake role of this connection needs the SNOWFLAKE.CORTEX_USER "
                "database role to call SNOWFLAKE.CORTEX.COMPLETE."
            )
        if _MODEL_RE.search(err):
            return (
                f" Model '{self.model}' may not be available in this account's region; enable "
                "cross-region inference (CORTEX_ENABLED_CROSS_REGION) or set PBIC_CORTEX_MODEL."
            )
        return ""

    def chat(self, messages: list[dict[str, Any]], **_ignored: Any) -> str:
        context = _context.get()
        params = (
            self.model,
            json.dumps(messages),
            json.dumps({"temperature": self.temperature, "max_tokens": self.max_tokens}),
        )
        last: Exception | None = None
        for attempt in range(1, _MAX_ATTEMPTS + 1):
            cursor = self._cursor_factory()
            started = time.perf_counter()
            try:
                with _audit(cursor, context):
                    cursor.execute(_SQL, params)
                    row = cursor.fetchone()
                if not row:
                    raise CortexError("Cortex COMPLETE returned no row")
                text, usage = _parse_reply(row[0])
                log_event(
                    _logger,
                    "info",
                    "cortex_chat",
                    model=self.model,
                    attempt=attempt,
                    context=context,
                    usage=usage,
                    elapsed_ms=round((time.perf_counter() - started) * 1000),
                )
                return text
            except CortexError:
                raise
            except Exception as e:  # noqa: BLE001 - connector raises many exception types
                last = e
                err = str(e)
                if _TRANSIENT_RE.search(err) and attempt < _MAX_ATTEMPTS:
                    log_event(
                        _logger,
                        "warning",
                        "cortex_chat_retrying",
                        model=self.model,
                        attempt=attempt,
                        context=context,
                        error=err[:200],
                    )
                    time.sleep(2 * attempt)
                    continue
                raise CortexError(f"Cortex COMPLETE failed: {err[:500]}{self._hint(err)}") from e
            finally:
                self._release(cursor)
        raise CortexError(f"Cortex COMPLETE failed: {last}")

    @staticmethod
    def _release(cursor: Any) -> None:
        try:
            conn = getattr(cursor, "connection", None)
            if conn is not None:
                conn.close()
            else:
                cursor.close()
        except Exception as e:  # noqa: BLE001 - cleanup must stay best effort
            log_event(_logger, "debug", "cortex_release_failed", error=str(e))

    def preflight(self) -> None:
        """One tiny call proving the role/model can use Cortex; raises CortexError."""
        with llm_call_context("ai_llm_preflight"):
            self.chat([{"role": "user", "content": "Reply with the single word OK."}])


def build_cortex_client(cursor_factory: Callable[[], Any]) -> CortexClient:
    from app.core.config import get_settings

    s = get_settings()
    return CortexClient(
        cursor_factory,
        model=s.cortex_model,
        temperature=s.cortex_temperature,
        max_tokens=s.cortex_max_tokens,
    )
