from __future__ import annotations

import webbrowser

import pytest
from fastapi.testclient import TestClient

from app.services.connections import (
    AuthMethod,
    ConnectionStore,
    ConnectionValidationError,
    SnowflakeProfileIn,
    SnowflakeProfileUpdate,
    warehouse_identifier,
)
from app.services.snowflake_sessions import (
    SnowflakeMfaRequired,
    SnowflakeSessionManager,
    SnowflakeWarehouseError,
)

PROBE_SQL = "select current_version(), current_role(), current_warehouse(), current_database()"


class Cur:
    def __init__(self, conn):
        self.conn = conn
        self.rows = []

    def execute(self, sql, params=None):
        self.conn.log.append(sql)
        for needle, err in self.conn.fail.items():
            if needle in sql:
                raise RuntimeError(err)
        self.rows = self.conn.results.get(sql, [])
        return self

    def fetchall(self):
        return self.rows

    def fetchone(self):
        return self.rows[0] if self.rows else None

    def close(self):
        pass


class Conn:
    def __init__(self, fail=None, results=None):
        self.log = []
        self.fail = fail or {}
        self.results = results or {}
        self.closed = False

    def cursor(self):
        return Cur(self)

    def is_closed(self):
        return self.closed

    def close(self):
        self.closed = True


def make(tmp_path, auth=AuthMethod.PASSWORD, **over):
    store = ConnectionStore(tmp_path, tmp_path / ".k")
    spec = {
        "name": "n",
        "account": "a",
        "user": "u",
        "auth_method": auth,
        "warehouse": "WH",
        "role": "R",
        "password": "pw",
    }
    spec.update(over)
    return store, store.create(SnowflakeProfileIn(**spec))


def test_warehouse_identifier():
    assert warehouse_identifier(" my_wh ") == "my_wh"
    assert warehouse_identifier('"My WH"') == '"My WH"'
    for bad in ("a b", "x;drop", "", '""'):
        with pytest.raises(ValueError, match="invalid warehouse name"):
            warehouse_identifier(bad)


def test_create_requires_warehouse_and_update_validates(tmp_path):
    store = ConnectionStore(tmp_path, tmp_path / ".k")
    with pytest.raises(ConnectionValidationError, match="warehouse is required"):
        store.create(
            SnowflakeProfileIn(
                name="n", account="a", user="u", auth_method="password", password="x"
            )
        )
    _, p = make(tmp_path)
    store = ConnectionStore(tmp_path, tmp_path / ".k")
    with pytest.raises(ConnectionValidationError, match="name cannot be empty"):
        store.update(p.id, SnowflakeProfileUpdate(name=" "))
    with pytest.raises(ConnectionValidationError, match="warehouse is required"):
        store.update(p.id, SnowflakeProfileUpdate(warehouse=""))
    out = store.update(p.id, SnowflakeProfileUpdate(role="  ", schema="S"))
    assert out.role is None and out.schema_name == "S" and out.warehouse == "WH"
    assert store._secrets(p.id)["password"] == "pw"


def test_warehouse_failure_keeps_session_then_reapplies(tmp_path):
    store, p = make(tmp_path)
    conn = Conn(fail={"USE WAREHOUSE": "no usage"}, results={"SHOW WAREHOUSES": [("A",), ("B",)]})
    connects = []

    def connect(**kw):
        connects.append(kw)
        return conn

    mgr = SnowflakeSessionManager(store, connect=connect)
    with pytest.raises(SnowflakeWarehouseError, match="Warehouses this role can use: A, B"):
        mgr.authenticate(p.id)
    assert mgr.settings_error(p.id)
    status = mgr.status(p.id)
    assert status["authenticated"] is True and status["settings_error"]
    conn.fail.clear()
    store.update(p.id, SnowflakeProfileUpdate(warehouse="OTHER"))
    mgr.settings_changed(p.id)
    with mgr.lease(p.id):
        pass
    assert len(connects) == 1
    assert "USE WAREHOUSE OTHER" in conn.log
    assert mgr.settings_error(p.id) is None


def test_role_failure_message(tmp_path):
    store, p = make(tmp_path)
    mgr = SnowflakeSessionManager(store, connect=lambda **kw: Conn(fail={"USE ROLE": "denied"}))
    with pytest.raises(SnowflakeWarehouseError, match="role R could not be activated"):
        mgr.authenticate(p.id)


def test_mfa_flow(tmp_path):
    store, p = make(tmp_path)
    seen = []

    def connect(**kw):
        seen.append(kw)
        if "passcode" not in kw:
            raise RuntimeError("394508: MFA with TOTP is required")
        return Conn()

    mgr = SnowflakeSessionManager(store, connect=connect)
    with pytest.raises(SnowflakeMfaRequired):
        mgr.authenticate(p.id)
    assert store.mfa_enforced(p.id) is True
    assert mgr.status(p.id)["mfa_required"] is True
    with pytest.raises(ValueError, match="6-8 digit"):
        mgr.authenticate(p.id, passcode="12ab")
    mgr.authenticate(p.id, passcode="123456")
    assert seen[-1]["authenticator"] == "username_password_mfa"
    assert seen[-1]["passcode"] == "123456"


def test_plain_password_signin_clears_flag_and_passcode_only_for_password(tmp_path):
    store, p = make(tmp_path)
    store.set_mfa_enforced(p.id, False)
    mgr = SnowflakeSessionManager(store, connect=lambda **kw: Conn())
    mgr._mfa_profiles.add(p.id)
    store.set_mfa_enforced(p.id, True)
    store.set_mfa_enforced(p.id, False)
    mgr._mfa_profiles.clear()
    mgr.authenticate(p.id)
    assert store.mfa_enforced(p.id) is False
    _, k = make(tmp_path, auth=AuthMethod.PAT, pat_token="t")
    with pytest.raises(ValueError, match="only applies to username"):
        mgr.authenticate(k.id, passcode="123456")


def test_status_verify(tmp_path):
    store, p = make(tmp_path)
    conn = Conn()
    mgr = SnowflakeSessionManager(store, connect=lambda **kw: conn)
    assert set(mgr.status(p.id)) == {"authenticated", "sso_url", "mfa_required"}
    mgr.authenticate(p.id)
    ok = mgr.status(p.id, verify=True)
    assert ok["verified"] is True and ok["checked_at"] and ok["expired"] is False
    conn.fail["SELECT 1"] = "session gone"
    bad = mgr.status(p.id, verify=True)
    assert bad["authenticated"] is False and bad["expired"] is True
    assert "session gone" in bad["reason"]
    assert mgr.status(p.id)["authenticated"] is False


def test_force_signin_keeps_old_session_on_failure(tmp_path):
    store, p = make(tmp_path)
    first = Conn()
    state = {"n": 0}

    def connect(**kw):
        state["n"] += 1
        if state["n"] == 1:
            return first
        raise RuntimeError("boom")

    mgr = SnowflakeSessionManager(store, connect=connect)
    mgr.authenticate(p.id)
    with pytest.raises(RuntimeError, match="boom"):
        mgr.authenticate(p.id, force=True)
    assert first.closed is False
    assert mgr.status(p.id)["authenticated"] is True


def test_query_tag_set_once(tmp_path):
    store, p = make(tmp_path)
    conn = Conn()
    mgr = SnowflakeSessionManager(store, connect=lambda **kw: conn)
    mgr.authenticate(p.id, query_tag="t1")
    for _ in range(2):
        with mgr.lease(p.id, "t2"):
            pass
    assert sum("QUERY_TAG" in s for s in conn.log) == 1


def test_sso_url_captured_and_patches_restored(tmp_path):
    store, p = make(tmp_path, auth=AuthMethod.EXTERNAL_BROWSER)
    opened = []
    real_new, real_open = webbrowser.open_new, webbrowser.open

    def fake_open_new(url):
        opened.append(url)
        return True

    webbrowser.open_new = fake_open_new
    holder = {}

    def connect(**kw):
        webbrowser.open_new("https://sso.example/login")
        holder["status"] = holder["mgr"].status(p.id)
        return Conn()

    mgr = SnowflakeSessionManager(store, connect=connect)
    holder["mgr"] = mgr
    try:
        mgr.authenticate(p.id)
        assert holder["status"] == {"authenticated": False, "sso_url": "https://sso.example/login"}
        assert opened == ["https://sso.example/login"]
        assert webbrowser.open_new is fake_open_new and webbrowser.open is real_open
        assert mgr.status(p.id)["sso_url"] is None
    finally:
        webbrowser.open_new, webbrowser.open = real_new, real_open


def test_api_patch_test_and_session(tmp_path):
    from app.api import deps
    from app.main import app

    store = ConnectionStore(tmp_path, tmp_path / ".k")
    conns = []

    def connect(**kw):
        c = Conn(fail={"USE WAREHOUSE BAD": "nope"}, results={PROBE_SQL: [("v", "R", "WH", "DB")]})
        conns.append(c)
        return c

    mgr = SnowflakeSessionManager(store, connect=connect)
    app.dependency_overrides[deps.get_connection_store] = lambda: store
    app.dependency_overrides[deps.get_snowflake_session_manager] = lambda: mgr
    try:
        c = TestClient(app)
        created = c.post(
            "/api/v1/connections",
            json={
                "name": "n",
                "account": "a",
                "user": "u",
                "auth_method": "password",
                "password": "pw",
                "warehouse": "WH",
            },
        )
        pid = created.json()["id"]
        assert c.patch(f"/api/v1/connections/{pid}", json={"name": " "}).status_code == 422
        missing = "00000000-0000-0000-0000-000000000000"
        assert c.patch(f"/api/v1/connections/{missing}", json={"name": "x"}).status_code == 404
        assert c.post(f"/api/v1/connections/{pid}/test").json()["ok"] is True
        assert c.post(f"/api/v1/connections/{pid}/test", json={"force": True}).json()["ok"] is True
        assert len(conns) == 2
        assert c.patch(f"/api/v1/connections/{pid}", json={"warehouse": "BAD"}).status_code == 200
        out = c.post(f"/api/v1/connections/{pid}/test", json={})
        assert out.status_code == 200 and out.json()["ok"] is False
        assert "BAD" in out.json()["error"]
        assert c.get(f"/api/v1/connections/{pid}/session?verify=true").json()["verified"] is True
    finally:
        app.dependency_overrides.clear()
