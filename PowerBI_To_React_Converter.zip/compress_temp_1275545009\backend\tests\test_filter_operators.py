"""Phase 10: filter operators as SQL (DuckDB rows), templates, semantic view, filter values."""

from __future__ import annotations

import pytest

from app.runtime import sql_render as sr
from app.runtime.dashboard import filter_values_query
from app.runtime.engine import FilterClause, MeasureRefSpec, QueryPlanError, QuerySpec
from app.runtime.semantic_view import (
    SemanticViewAdapter,
    SemanticViewPlanError,
    SemanticViewRequest,
)
from tests.duck import DuckWorld
from tests.phase08 import FakeConn, World
from tests.test_api import client  # noqa: F401

ROWS = [
    (1, "Alpha", 10),
    (2, "alphabet", 20),
    (3, "Beta", 30),
    (4, "", 40),
    (5, None, 50),
    (6, "50%_off!", 60),
    (7, "xAlpha", 70),
]


@pytest.fixture()
def world() -> DuckWorld:
    return DuckWorld(
        {"T": (["id", "name", "amount"], ROWS)},
        measures={"Total": "SUM(T[amount])", "Rows": "COUNTROWS(T)"},
    )


def ids(world: DuckWorld, *filters: FilterClause) -> set[int]:
    """The ids that survive the filters (id is the grain)."""
    from app.runtime.engine import DimensionRef

    spec = QuerySpec(
        dimensions=[DimensionRef(table="T", column="id")],
        measures=[MeasureRefSpec(name="Total")],
        filters=list(filters),
    )
    return {r[0] for r in world.run(spec)}


def f(op: str, *values, **kw) -> FilterClause:
    return FilterClause(table="T", column="name", op=op, values=list(values), **kw)


class TestOperators:
    def test_contains_is_case_insensitive_and_skips_null(self, world):
        assert ids(world, f("contains", "ALPHA")) == {1, 2, 7}

    def test_not_contains_excludes_blanks(self, world):
        # a NULL name is not "not containing": blanks are excluded
        assert ids(world, f("not_contains", "alpha")) == {3, 4, 6}

    def test_starts_with_and_not_starts_with(self, world):
        assert ids(world, f("starts_with", "alpha")) == {1, 2}
        assert ids(world, f("not_starts_with", "alpha")) == {3, 4, 6, 7}

    def test_blank_vs_empty_text(self, world):
        assert ids(world, f("is_blank")) == {5}
        assert ids(world, f("is_not_blank")) == {1, 2, 3, 4, 6, 7}
        assert ids(world, f("is_empty")) == {4}
        assert ids(world, f("is_not_empty")) == {1, 2, 3, 6, 7}  # NULL <> '' is unknown

    def test_comparisons(self, world):
        amount = lambda op, v: FilterClause(table="T", column="amount", op=op, values=[v])  # noqa: E731
        assert ids(world, amount("gt", 60)) == {7}
        assert ids(world, amount("gte", 60)) == {6, 7}
        assert ids(world, amount("lt", 20)) == {1}
        assert ids(world, amount("lte", 20)) == {1, 2}

    def test_equality_with_null(self, world):
        assert ids(world, f("eq", None)) == {5}
        assert ids(world, f("neq", None)) == {1, 2, 3, 4, 6, 7}
        assert ids(world, f("eq", "Beta")) == {3}
        assert ids(world, f("in", "Beta", None)) == {3, 5}
        assert ids(world, f("not_in", "Beta", None)) == {1, 2, 4, 6, 7}

    def test_or_of_two_conditions(self, world):
        both = FilterClause(
            table="T",
            column="name",
            op="or",
            clauses=[f("eq", "Beta"), f("starts_with", "alpha")],
        )
        assert ids(world, both) == {1, 2, 3}

    def test_or_without_operands_matches_nothing(self, world):
        assert ids(world, FilterClause(table="T", column="name", op="or", clauses=[])) == set()

    def test_like_pattern_escapes_wildcards(self, world):
        assert sr.like_pattern("50%_off!") == "50!%!_off!!"
        assert ids(world, f("contains", "50%_off!")) == {6}
        assert ids(world, f("contains", "%")) == {6}  # a literal percent, not "anything"
        assert ids(world, f("contains", "_")) == {6}
        assert ids(world, f("starts_with", "50%")) == {6}

    def test_between_dates_open_ended(self):
        w = DuckWorld({"D": (["id", "d"], [(1, "2024-01-01"), (2, "2024-02-01"), (3, None)])},
                      measures={"N": "COUNTROWS(D)"}, types={("D", "d"): "string"})  # fmt: skip
        from app.runtime.engine import DimensionRef

        def run(*values):
            spec = QuerySpec(
                dimensions=[DimensionRef(table="D", column="id")],
                measures=[MeasureRefSpec(name="N")],
                filters=[FilterClause(table="D", column="d", op="between_dates", values=list(values))],
            )
            return {r[0] for r in w.run(spec)}

        assert run("2024-01-15", None) == {2}
        assert run(None, "2024-01-15") == {1}
        assert run("2024-01-01", "2024-02-01") == {1, 2}
        assert run(None, None) == {1, 2}

    def test_operators_that_need_a_value_refuse_none(self, world):
        for op in ("eq", "neq", "gt", "gte", "lt", "lte", "contains", "not_contains",
                   "starts_with", "not_starts_with"):  # fmt: skip
            with pytest.raises(QueryPlanError, match="needs at least one value"):
                world.engine().build_sql(
                    QuerySpec(measures=[MeasureRefSpec(name="Total")], filters=[f(op)])
                )
        assert not sr.clause_needs_values("is_blank") and sr.clause_needs_values("contains")
        assert sr.NO_VALUE_OPS >= {"is_blank", "or", "relative", "topn", "in_query"}

    def test_unknown_operator_is_refused(self, world):
        with pytest.raises(QueryPlanError, match="unknown filter op"):
            world.engine().build_sql(
                QuerySpec(measures=[MeasureRefSpec(name="Total")], filters=[f("wibble", "x")])
            )

    def test_in_query_cannot_be_sent(self, world):
        bad = FilterClause(table="T", column="id", op="in_query", params={"token": "SELECT 1"})
        with pytest.raises(QueryPlanError, match="unknown filter op in_query"):
            world.engine().build_sql(QuerySpec(measures=[MeasureRefSpec(name="Total")], filters=[bad]))


class TestSqlRender:
    def test_predicates(self):
        p = lambda op, *v, **kw: sr.predicate_sql('"c"', op, list(v), **kw)  # noqa: E731
        assert p("gt", 5) == '"c" > 5'
        assert p("contains", "a_b") == "CAST(\"c\" AS VARCHAR) ILIKE '%a!_b%' ESCAPE '!'"
        assert p("not_contains", "x").startswith('("c" IS NOT NULL AND NOT (')
        assert p("is_empty") == "\"c\" = ''"
        assert p("topn") is None
        assert p("nope") is None
        assert p("between_dates", None, None) == '"c" IS NOT NULL'
        assert p("in_query", params={"token": "TOK"}) == '"c" IN (TOK)'
        assert p("or", clauses=[{"op": "topn"}]) is None  # never inside an Or
        assert p("or", clauses=[{"op": "eq", "values": [1]}, {"op": "is_blank"}]) == (
            '(("c" = 1) OR ("c" IS NULL))'
        )

    def test_literals(self):
        assert [sr.lit(v) for v in (None, True, False, 3, 2.5, "it's")] == [
            "NULL", "TRUE", "FALSE", "3", "2.5", "'it''s'"
        ]  # fmt: skip

    def test_module_does_not_import_app(self):
        import inspect

        source = inspect.getsource(sr)
        assert "from app" not in source and "import app" not in source

    def test_relative_rejects_bad_bounds(self):
        bad = {"lower": {"DateAdd": {"Expression": {"Now": {}}, "Amount": 1.5, "TimeUnit": 0}}, "upper": {"Now": {}}}
        with pytest.raises(sr.TemplateError, match="invalid relative date bound"):
            sr.relative_sql('"c"', bad, "T", "N")
        with pytest.raises(sr.TemplateError):
            sr.relative_sql('"c"', {"lower": {"Weird": {}}, "upper": {"Now": {}}}, "T", "N")
        deep: dict = {"Now": {}}
        for _ in range(12):
            deep = {"DateAdd": {"Expression": deep, "Amount": 1, "TimeUnit": 0}}
        with pytest.raises(sr.TemplateError):
            sr.relative_sql('"c"', {"lower": deep, "upper": {"Now": {}}}, "T", "N")


class TestSemanticView:
    def adapter(self, world: DuckWorld) -> SemanticViewAdapter:
        return SemanticViewAdapter(world.model)

    def test_uses_the_same_predicates(self, world):
        a = self.adapter(world)
        for flt in (f("contains", "x"), f("is_blank"), f("not_starts_with", "a")):
            expected = sr.predicate_sql(a._qident("name"), flt.op, flt.values)
            assert a._filter_sql(flt) == expected

    def test_topn_and_in_query_fall_back_to_the_compatibility_path(self, world):
        a = self.adapter(world)
        for op in ("topn", "in_query"):
            with pytest.raises(SemanticViewPlanError, match="compatibility path"):
                a._filter_sql(f(op))

    def test_value_ops_require_a_value(self, world):
        with pytest.raises(SemanticViewPlanError, match="requires at least one value"):
            self.adapter(world)._filter_sql(f("contains"))
        assert SemanticViewRequest  # keep import


class TestFilterValues:
    def test_query_shape(self):
        q = filter_values_query("T", "name", None, 500)
        assert q.limit == 501 and q.filters == []
        assert q.sort == [{"key": "T.name", "direction": "Ascending"}]
        s = filter_values_query("T", "name", "abc", 10)
        assert s.filters[0].op == "contains" and s.filters[0].values == ["abc"] and s.limit == 11

    def test_keeps_blank_sorts_and_searches(self, world):
        def values(search):
            sql, _ = world.engine().build_sql(filter_values_query("T", "name", search, 100))
            from app.runtime.accelerate import to_duckdb_sql

            return [r[0] for r in world.con.execute(to_duckdb_sql(sql, world.bindings)).fetchall()]

        everything = values(None)
        assert None in everything and "" in everything  # blank and empty both kept
        non_null = [v for v in everything if v is not None]
        assert non_null == sorted(non_null)
        assert values("alpha") == ["Alpha", "alphabet", "xAlpha"][:3] or set(values("alpha")) == {"Alpha", "alphabet", "xAlpha"}


class TestEndpoint:
    @pytest.fixture()
    def api(self, client, contoso_pbip, monkeypatch):  # noqa: F811
        return World(client, contoso_pbip, monkeypatch)

    def body(self, api, **over):
        return {"connection_id": api.conn_id, "page": "p", "table": "Customer", "column": "Country", **over}

    def test_returns_values_and_truncates(self, api):
        api.responder = lambda sql: (["Country"], [("DE",), ("US",), ("FR",), (None,)])
        out = api.post("filter-values", self.body(api, limit=3)).json()
        assert out == {"values": ["DE", "US", "FR"], "truncated": True}
        full = api.post("filter-values", self.body(api, limit=10)).json()
        assert full == {"values": ["DE", "US", "FR", None], "truncated": False}  # NULL kept

    def test_is_audited_as_a_dashboard_query(self, api):
        api.responder = lambda sql: (["Country"], [("DE",)])
        api.post("filter-values", self.body(api, search="d"))
        record = api.get("query-audit", kind="all").json()["records"][0]
        assert record["kind"] == "dashboard" and record["visual"] == "filter-values:Customer.Country"
        assert record["row_count"] == 1 and "ILIKE" in record["sql"]

    def test_unknown_column_is_422_and_errors_surface(self, api):
        assert api.post("filter-values", self.body(api, table="Nope")).status_code == 422
        api.responder = lambda sql: (_ for _ in ()).throw(RuntimeError("no warehouse"))
        r = api.post("filter-values", self.body(api))
        assert r.status_code == 422 and "no warehouse" in r.text

    def test_limit_is_bounded(self, api):
        assert api.post("filter-values", self.body(api, limit=0)).status_code == 422
        assert api.post("filter-values", self.body(api, limit=5001)).status_code == 422

    def test_request_filters_record_their_source(self, api):
        api.query("card0001aaaabbbbcccc", filters=[
            {"table": "Customer", "column": "Country", "values": ["US"], "source": "page_filter"},
            {"table": "Product", "column": "Category", "values": ["Bikes"], "source": "report_filter"},
        ])  # fmt: skip
        rec = api.get("query-audit", kind="all").json()["records"][0]
        assert {x["source"] for x in rec["request_filters"]} == {"page_filter", "report_filter"}
        assert "page_filter" not in rec["sql"]  # never part of the SQL
        assert FakeConn
