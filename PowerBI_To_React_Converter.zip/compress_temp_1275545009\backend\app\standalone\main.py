"""The standalone dashboard's local query service (FastAPI, 127.0.0.1).

Serves the built React app, the compiled spec and the query routes the dashboard uses. Each data
query is a SQL template (`data/templates/**`) filled with the request's filters and run on
Snowflake with the signed-in user's own session. Shipped verbatim inside the package as
`service/main.py` (run as `python -m uvicorn main:app`).
"""

from __future__ import annotations

import os
import secrets as _secrets
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

try:
    from .connection_store import ConnectionStore, SettingsError
    from .manifest import Package, render
    from .snowflake_session import AuthenticationRequired, Session
except ImportError:  # shipped flat in service/
    from connection_store import ConnectionStore, SettingsError  # type: ignore
    from manifest import Package, render  # type: ignore
    from snowflake_session import AuthenticationRequired, Session  # type: ignore

PREFIX = "/api/v1/published"
CACHE_SECONDS = 300
STATIC_MESSAGE = "static visual: renders from spec, no data query"
TITLE_SUFFIX = "#title"
PBIS_ROOT = Path(os.environ.get("PBIS_ROOT") or Path(__file__).resolve().parent.parent)


class VisualQuery(BaseModel):
    visual: str
    page: str
    filters: list[dict] = Field(default_factory=list)


class BatchRequest(BaseModel):
    queries: list[VisualQuery]
    mode: str = "live"


class DrillRequest(BaseModel):
    page: str
    visual: str
    direction: str = "down"
    level_key: str | None = None
    parent_filters: list[dict] = Field(default_factory=list)
    filters: list[dict] = Field(default_factory=list)


class FilterValuesRequest(BaseModel):
    page: str | None = None
    table: str
    column: str
    search: str | None = None
    limit: int = Field(default=500, ge=1, le=5000)


class AuthenticateRequest(BaseModel):
    passcode: str | None = None


class ConnectionRequest(BaseModel):
    model_config = {"extra": "allow"}
    secrets: dict[str, Any] = Field(default_factory=dict)
    remember: bool | None = None


def _auth_required(e: AuthenticationRequired) -> HTTPException:
    return HTTPException(
        409,
        {
            "code": "snowflake_authentication_required",
            "message": str(e),
            "mfa_required": e.mfa_required,
        },
    )


class _Results:
    """SQL -> rows, cached for a few minutes (cleared on sign-in/out and connection changes)."""

    def __init__(self, session: Session):
        self.session = session
        self._cache: dict[str, tuple[float, dict]] = {}
        self._lock = threading.Lock()

    def clear(self) -> None:
        with self._lock:
            self._cache.clear()

    def run(self, sql: str) -> dict:
        now = time.time()
        with self._lock:
            hit = self._cache.get(sql)
        if hit and now - hit[0] < CACHE_SECONDS:
            return {**hit[1], "cached": True}
        started = time.perf_counter()
        columns, rows, query_id = self.session.run(sql)
        payload = {
            "columns": columns,
            "rows": rows,
            "query_id": query_id,
            "elapsed_ms": round((time.perf_counter() - started) * 1000),
            "cached": False,
        }
        with self._lock:
            self._cache[sql] = (now, {**payload, "elapsed_ms": 0})
        return payload


def create_app(
    root: Path | str = PBIS_ROOT,
    session: Session | None = None,
    store: ConnectionStore | None = None,
) -> FastAPI:
    root = Path(root)
    package = Package(root)
    store = store or ConnectionStore(root / "data", package.package_id)
    session = session or Session(store)
    results = _Results(session)
    workers = max(1, int(os.environ.get("PBIS_MAX_PARALLEL_QUERIES") or 8))
    pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="pbis-query")

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        pid_file = root / "logs" / "service.pid"
        if os.environ.get("PBIS_NO_AUTOSTART") != "1":
            try:
                pid_file.parent.mkdir(parents=True, exist_ok=True)
                pid_file.write_text(str(os.getpid()), encoding="utf-8")
            except OSError:
                pass
        yield
        pool.shutdown(wait=False, cancel_futures=True)

    app = FastAPI(title="PBI standalone dashboard", lifespan=lifespan)
    app.state.package, app.state.store, app.state.session = package, store, session

    def require_token(authorization: str | None = Header(default=None)) -> None:
        token = (authorization or "").removeprefix("Bearer ").strip() if authorization else ""
        if (
            not authorization
            or not authorization.startswith("Bearer ")
            or not _secrets.compare_digest(token.encode(), package.token.encode())
        ):
            raise HTTPException(401, "missing or invalid dashboard token")

    auth = [Depends(require_token)]

    @app.get(f"{PREFIX}/health")
    def health() -> dict:
        return {"ok": True, "report": package.report_name}

    # ------------------------------------------------------------------ session / connection

    @app.get(f"{PREFIX}/session", dependencies=auth)
    def session_status() -> dict:
        return session.status()

    @app.post(f"{PREFIX}/session/authenticate", dependencies=auth)
    def authenticate(req: AuthenticateRequest | None = None) -> dict:
        try:
            session.authenticate((req.passcode if req else None) or None)
        except AuthenticationRequired as e:
            return {"ok": False, "error": str(e), "mfa_required": e.mfa_required}
        except Exception as e:  # noqa: BLE001 - connector errors are shown to the user
            return {"ok": False, "error": str(e)[:500], "mfa_required": False}
        results.clear()
        return {"ok": True}

    @app.post(f"{PREFIX}/session/sign-out", dependencies=auth)
    def sign_out() -> dict:
        session.sign_out()
        results.clear()
        return {"ok": True}

    @app.get(f"{PREFIX}/connection", dependencies=auth)
    def get_connection() -> dict:
        return store.public()

    @app.put(f"{PREFIX}/connection", dependencies=auth)
    def put_connection(req: ConnectionRequest) -> dict:
        settings = dict(req.model_extra or {})
        try:
            change = store.update(settings, req.secrets, req.remember)
        except SettingsError as e:
            raise HTTPException(422, str(e)) from e
        if change == "reconnect":
            session.reset()
        elif change == "reapply":
            session.apply_settings()
        if change != "none":
            results.clear()
        return {**store.public(), "change": change, "session": session.status()}

    @app.delete(f"{PREFIX}/connection/secrets", dependencies=auth)
    def forget_secrets() -> dict:
        store.forget()
        session.reset()
        results.clear()
        return {**store.public(), "session": session.status()}

    # ------------------------------------------------------------------ dashboard

    @app.get(f"{PREFIX}/dashboard/spec", dependencies=auth)
    def get_spec() -> dict:
        return package.spec

    @app.get(f"{PREFIX}/dashboard/accelerate", dependencies=auth)
    def accelerate_status() -> dict:
        return {"hydrated": False, "available": False}

    @app.post(f"{PREFIX}/dashboard/accelerate", dependencies=auth)
    def accelerate() -> None:
        raise HTTPException(501, "the standalone dashboard is live-only")

    def run_one(q: VisualQuery) -> dict:
        out: dict[str, Any] = {
            "visual": q.visual, "columns": [], "rows": [], "sql": None, "warnings": [],
            "error": None, "elapsed_ms": 0, "cached": False, "execution_tier": "tier_a_native",
            "trace_codes": [], "execution_path": "compatibility", "fallback_reason": None,
            "totals": None,
        }  # fmt: skip
        entry = package.entry(q.page, q.visual)
        if entry is None:
            return {**out, "error": "unknown visual", "execution_path": "error",
                    "fallback_reason": "unknown visual"}  # fmt: skip
        kind = entry.get("kind")
        if kind == "static":
            return {**out, "execution_path": "static", "fallback_reason": STATIC_MESSAGE}
        if kind == "error":
            reason = entry.get("error") or "unsupported visual"
            return {**out, "error": reason, "execution_path": "error", "fallback_reason": reason}
        try:
            sql, unapplied = package.render(entry, q.filters)
        except render.TemplateError as e:
            return {**out, "error": str(e)}
        warnings = [*entry.get("warnings", []), *unapplied]
        out.update(sql=sql, warnings=warnings, trace_codes=_trace_codes(warnings))
        if entry.get("edited"):
            out["execution_path"] = "manual_sql"
        try:
            got = results.run(sql)
        except AuthenticationRequired:
            raise
        except Exception as e:  # noqa: BLE001
            return {**out, "error": str(e)}
        out.update(
            columns=got["columns"],
            rows=got["rows"],
            elapsed_ms=got["elapsed_ms"],
            cached=got["cached"],
        )
        totals = entry.get("totals")
        if totals:
            try:
                t_sql, _ = package.render(totals, q.filters)
                t = results.run(t_sql)
                if t["rows"]:
                    out["totals"] = {"columns": t["columns"], "row": list(t["rows"][0])}
            except AuthenticationRequired:
                raise
            except Exception:  # noqa: BLE001, S110 - totals are best-effort decoration
                pass
        return out

    @app.post(f"{PREFIX}/dashboard/query", dependencies=auth)
    def query(req: BatchRequest) -> dict:
        queries = list(req.queries)
        seen = {(q.page, q.visual) for q in queries}
        for q in req.queries:
            title = (q.page, f"{q.visual}{TITLE_SUFFIX}")
            if package.entry(*title) is not None and title not in seen:
                seen.add(title)
                queries.append(VisualQuery(visual=title[1], page=title[0], filters=q.filters))
        futures = [pool.submit(run_one, q) for q in queries]
        try:
            return {"results": [f.result() for f in futures]}
        except AuthenticationRequired as e:
            for f in futures:
                f.cancel()
            raise _auth_required(e) from e

    @app.post(f"{PREFIX}/dashboard/query/drill", dependencies=auth)
    def drill(req: DrillRequest) -> dict:
        info = package.drill.get(f"{req.page}/{req.visual}")
        if not info or not info.get("levels"):
            raise HTTPException(422, "visual has no drillable hierarchy")
        levels = list(info["levels"])
        current = req.level_key or info.get("current_level") or levels[-1]
        if current not in levels:
            current = levels[-1]
        idx = levels.index(current)
        if req.direction == "down":
            target = min(idx + 1, len(levels) - 1)
        elif req.direction == "up":
            target = max(idx - 1, 0)
        else:
            raise HTTPException(422, "direction must be 'down' or 'up'")
        entry = (info.get("by_target") or {}).get(str(target))
        if not entry or entry.get("kind") != "sql":
            raise HTTPException(
                422, (entry or {}).get("error") or "no query for this hierarchy level"
            )
        try:
            sql, unapplied = package.render(entry, [*req.filters, *req.parent_filters])
        except render.TemplateError as e:
            raise HTTPException(422, str(e)) from e
        try:
            got = results.run(sql)
        except AuthenticationRequired as e:
            raise _auth_required(e) from e
        return {
            "page": req.page, "visual": req.visual, "level_key": levels[target],
            "level_index": target, "total_levels": len(levels), "columns": got["columns"],
            "rows": got["rows"], "sql": sql, "warnings": [*entry.get("warnings", []), *unapplied],
        }  # fmt: skip

    @app.post(f"{PREFIX}/dashboard/filter-values", dependencies=auth)
    def filter_values(req: FilterValuesRequest) -> dict:
        entry = package.filter_values.get(f"{req.table}.{req.column}")
        if entry is None or entry.get("kind") != "sql":
            raise HTTPException(404, f"no value list for {req.table}[{req.column}]")
        filters = (
            [{"table": req.table, "column": req.column, "op": "contains", "values": [req.search]}]
            if req.search
            else []
        )
        try:
            sql, _ = package.render(entry, filters)
        except render.TemplateError as e:
            raise HTTPException(422, str(e)) from e
        try:
            got = results.run(sql)
        except AuthenticationRequired as e:
            raise _auth_required(e) from e
        except Exception as e:  # noqa: BLE001
            raise HTTPException(422, f"could not load the values: {e}") from e
        limit = min(req.limit, package.filter_values_limit)
        values = [r[0] for r in got["rows"]]
        return {"values": values[:limit], "truncated": len(values) > limit}

    web = root / "app"
    if web.is_dir():
        app.mount("/", StaticFiles(directory=str(web), html=True), name="app")
    return app


def _trace_codes(warnings: list[str]) -> list[str]:
    import re

    return sorted({m for w in warnings for m in re.findall(r"\[OVERLAY:([A-Z_]+)\]", w)})


def __getattr__(name: str):  # `uvicorn main:app` builds the app on first use
    if name == "app":
        value = create_app()
        globals()["app"] = value
        return value
    raise AttributeError(name)
