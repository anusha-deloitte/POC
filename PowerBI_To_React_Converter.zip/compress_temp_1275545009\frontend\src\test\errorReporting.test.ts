import { afterEach, describe, expect, it, vi } from 'vitest'
import { reportClientError } from '../api/errorReporting'

describe('reportClientError', () => {
  afterEach(() => vi.restoreAllMocks())

  it('posts a trimmed report to the client-logs endpoint', () => {
    const fetchMock = vi.fn(async () => new Response(null, { status: 204 }))
    vi.stubGlobal('fetch', fetchMock)
    reportClientError({ message: 'm'.repeat(3000), path: '/p'.repeat(400), status: 500, context: 'c'.repeat(300), conversionId: 'c1' })
    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit]
    expect(url).toBe('/api/v1/client-logs')
    const body = JSON.parse(String(init.body))
    expect(body.message).toHaveLength(2000)
    expect(body.path.length).toBeLessThanOrEqual(500)
    expect(body.context).toHaveLength(200)
    expect(body.conversion_id).toBe('c1')
  })

  it('never throws, even when fetch fails or throws', async () => {
    vi.stubGlobal('fetch', vi.fn(() => Promise.reject(new Error('offline'))))
    expect(() => reportClientError({ message: 'x', path: '/p' })).not.toThrow()
    vi.stubGlobal('fetch', vi.fn(() => { throw new Error('sync') }))
    expect(() => reportClientError({ message: 'x', path: '/p' })).not.toThrow()
    await Promise.resolve()
  })
})
