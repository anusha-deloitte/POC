"""Number checks: compare the values printed on a PDF page with the converted visuals' data.

Each printed run is assigned to the SMALLEST data visual containing it, axis ticks and category
labels are skipped, and what is left is compared with the visual's measure values, grand totals
and (for percentages) shares of the column total.
"""

from __future__ import annotations

import math
from typing import Any

from app.services.pdf_text import (
    PdfPageText,
    PrintedNumber,
    TextRun,
    is_numeric_text,
    parse_numbers,
)

STATIC_TYPES = frozenset(
    {
        "textbox", "shape", "basicShape", "image", "actionButton", "visualGroup", "unknown",
        "bookmarkNavigator", "pageNavigator", "slicer",
    }
)  # fmt: skip
CARD_TYPES = frozenset({"card", "multiRowCard", "kpi", "kpiCard", "cardVisual"})
TICK_MIN = 3
TICK_SPREAD = 0.01


def _is_hidden(vs: Any) -> bool:
    pbir = getattr(vs, "pbir", None) or {}
    return bool(pbir.get("is_hidden") or pbir.get("self_hidden"))


def _number(value: Any) -> float | None:
    if isinstance(value, bool) or value is None:
        return None
    try:
        out = float(value)
    except (TypeError, ValueError):
        return None
    return out if math.isfinite(out) else None


def _assign_runs(page: Any, pdf: PdfPageText) -> dict[str, list[TextRun]]:
    """Run -> the smallest containing visual, in canvas pixels (the PDF may be letter-boxed)."""
    scale = pdf.width_pt / page.width if page.width else 1.0
    dy = max((pdf.height_pt / scale - page.height) / 2, 0.0)
    boxes = [
        v
        for v in page.visuals
        if v.visual_type not in STATIC_TYPES and not _is_hidden(v) and v.width > 0 and v.height > 0
    ]
    out: dict[str, list[TextRun]] = {}
    for run in pdf.runs:
        cx = (run.x0 + run.x1) / 2 / scale
        cy = (run.y0 + run.y1) / 2 / scale - dy
        inside = [v for v in boxes if v.x <= cx <= v.x + v.width and v.y <= cy <= v.y + v.height]
        if inside:
            best = min(inside, key=lambda v: v.width * v.height)
            out.setdefault(best.name, []).append(run)
    return out


def _evenly_spaced(values: list[float]) -> bool:
    steps = [abs(b - a) for a, b in zip(values, values[1:], strict=False)]
    if not steps or max(steps) == 0:
        return False
    return (max(steps) - min(steps)) <= TICK_SPREAD * max(steps)


def _axis_ticks(runs: list[TextRun]) -> set[int]:
    """Indexes of runs that look like axis ticks: 3+ single-number runs sharing a column (right
    edge) or a row (bottom edge) with evenly spaced values."""
    singles = []
    for i, r in enumerate(runs):
        nums = parse_numbers(r.text)
        if len(nums) == 1 and is_numeric_text(r.text):
            singles.append((i, r, nums[0].value))
    ticks: set[int] = set()
    for key, along in (
        (lambda r: round(r.x1 / 3), lambda r: r.y0),
        (lambda r: round(r.y1 / 3), lambda r: r.x0),
    ):
        groups: dict[int, list[tuple[int, TextRun, float]]] = {}
        for item in singles:
            groups.setdefault(key(item[1]), []).append(item)
        for items in groups.values():
            if len(items) < TICK_MIN:
                continue
            items.sort(key=lambda it: along(it[1]))
            if _evenly_spaced([it[2] for it in items]):
                ticks.update(it[0] for it in items)
    return ticks


def _columns(vs: Any, result: dict) -> tuple[list[int], list[int]]:
    cols = list(result.get("columns") or [])
    rows = result.get("rows") or []
    dim_keys = set(getattr(vs, "dim_keys", []) or [])
    measure_keys = set(getattr(vs, "measure_keys", []) or [])
    dims = [i for i, c in enumerate(cols) if c in dim_keys]
    measures = [i for i, c in enumerate(cols) if c in measure_keys]
    if not measures:  # unknown naming: numeric columns that are not dimensions
        measures = [
            i
            for i in range(len(cols))
            if i not in dims and any(_number(r[i]) is not None for r in rows if i < len(r))
        ]
    return dims, measures


def _candidates(vs: Any, result: dict, measures: list[int]) -> tuple[list[float], list[float]]:
    """(plain values, percent values) a printed number can legitimately equal."""
    cols = list(result.get("columns") or [])
    rows = result.get("rows") or []
    formats = getattr(vs, "measure_formats", {}) or {}
    plain: list[float] = []
    percent: list[float] = []
    for i in measures:
        col = [v for v in (_number(r[i]) for r in rows if i < len(r)) if v is not None]
        plain.extend(col)
        percent.extend(col)
        total = sum(col)
        if total:
            percent.extend(v / total * 100 for v in col)
        if "%" in str(formats.get(cols[i] if i < len(cols) else "", "")):
            percent.extend(v * 100 for v in col)
    totals = result.get("totals") or {}
    tcols, trow = list(totals.get("columns") or []), list(totals.get("row") or [])
    dim_keys = set(getattr(vs, "dim_keys", []) or [])
    for c, v in zip(tcols, trow, strict=False):
        n = _number(v)
        if n is None or c in dim_keys:
            continue
        plain.append(n)
        percent.append(n)
        if "%" in str(formats.get(c, "")):
            percent.append(n * 100)
    return plain, percent


def _category_texts(result: dict, dims: list[int]) -> set[str]:
    out: set[str] = set()
    for r in result.get("rows") or []:
        for i in dims:
            if i < len(r) and r[i] is not None:
                v = r[i]
                out.add(str(v).strip())
                n = _number(v)
                if n is not None and n == int(n):
                    out.add(str(int(n)))
    return out


def _nearest(value: float, pool: list[float]) -> float | None:
    return min(pool, key=lambda v: abs(v - value)) if pool else None


def check_values(
    page: Any, pdf: PdfPageText, results: list[dict] | dict[str, dict]
) -> dict[str, Any]:
    """Per-visual number check of one PDF page against the converted page's query results."""
    by_visual = (
        {r["visual"]: r for r in results if isinstance(r, dict) and "visual" in r}
        if isinstance(results, list)
        else dict(results)
    )
    assigned = _assign_runs(page, pdf)
    visuals: list[dict[str, Any]] = []
    for vs in page.visuals:
        if vs.visual_type in STATIC_TYPES or _is_hidden(vs) or vs.width <= 0 or vs.height <= 0:
            continue
        runs = assigned.get(vs.name, [])
        result = by_visual.get(vs.name) or {}
        dims, measures = _columns(vs, result)
        skip = set() if vs.visual_type in CARD_TYPES else _axis_ticks(runs)
        categories = _category_texts(result, dims)
        printed: list[tuple[TextRun, PrintedNumber]] = []
        for i, run in enumerate(runs):
            if i in skip or not is_numeric_text(run.text) or run.text.strip() in categories:
                continue
            printed.extend((run, n) for n in parse_numbers(run.text))
        entry: dict[str, Any] = {
            "visual": vs.name, "title": vs.title, "type": vs.visual_type, "numbers": [],
            "error": result.get("error"),
        }  # fmt: skip
        if not printed:
            entry["status"] = "not_checked"
            visuals.append(entry)
            continue
        plain, pct = _candidates(vs, result, measures)
        if not plain and not pct:
            entry["status"] = "not_found"
            entry["error"] = result.get("error") or "the converted visual returned no values"
            entry["numbers"] = [
                {"text": n.text, "value": n.value, "matched": False} for _, n in printed
            ]
            visuals.append(entry)
            continue
        mismatched = False
        for _run, n in printed:
            pool = pct if n.percent else plain
            ok = any(n.matches(v) for v in pool)
            item: dict[str, Any] = {"text": n.text, "value": n.value, "matched": ok}
            if not ok:
                item["nearest"] = _nearest(n.value, pool)
                mismatched = True
            entry["numbers"].append(item)
        entry["status"] = "mismatch" if mismatched else "match"
        visuals.append(entry)
    counts = {
        s: sum(1 for v in visuals if v["status"] == s)
        for s in ("match", "mismatch", "not_found", "not_checked")
    }
    numbers = [n for v in visuals for n in v["numbers"]]
    return {
        "summary": {
            **counts,
            "numbers_printed": len(numbers),
            "numbers_matched": sum(1 for n in numbers if n["matched"]),
        },
        "visuals": visuals,
    }
