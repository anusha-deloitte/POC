import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { fmtTime } from '../components/fmtTime'
import { Sparkline } from '../components/Sparkline'
import { PageHistory } from '../dashboard/parity/PageHistory'
import { comparison, values } from './parityFixtures'

describe('Sparkline', () => {
  it('shows a ▲ delta for a rising trend', () => {
    render(<Sparkline values={[70, 80, 83.5]} />)
    expect(screen.getByTestId('sparkline-delta')).toHaveTextContent('▲ 3.5')
    expect(screen.getByRole('img').querySelector('polyline')).not.toBeNull()
  })

  it('shows a ▼ delta for a falling trend', () => {
    render(<Sparkline values={[90, 88.8]} />)
    expect(screen.getByTestId('sparkline-delta')).toHaveTextContent('▼ 1.2')
  })

  it('handles an empty trend', () => {
    render(<Sparkline values={[]} />)
    expect(screen.getByTestId('sparkline-empty')).toBeInTheDocument()
    expect(screen.queryByTestId('sparkline-delta')).toBeNull()
  })

  it('handles a single point and only-null values', () => {
    const { rerender } = render(<Sparkline values={[88]} />)
    expect(screen.getByTestId('sparkline-last')).toBeInTheDocument()
    expect(screen.queryByTestId('sparkline-delta')).toBeNull()
    rerender(<Sparkline values={[null, null]} />)
    expect(screen.getByTestId('sparkline-empty')).toBeInTheDocument()
  })

  it('skips null gaps when computing the delta', () => {
    render(<Sparkline values={[60, null, 65, null]} />)
    expect(screen.getByTestId('sparkline-delta')).toHaveTextContent('▲ 5')
  })
})

describe('fmtTime', () => {
  it('formats epoch seconds and dashes the empty values', () => {
    expect(fmtTime(null)).toBe('—')
    expect(fmtTime(0)).toBe('—')
    expect(fmtTime(1_700_000_000)).toMatch(/\d/)
  })
})

const history = {
  page: 'p1',
  runs: [
    {
      run_id: 'r3',
      page: 'p1',
      display_name: 'Overview',
      kind: 'image',
      batch_id: 'b1',
      ts: 1_700_000_300,
      summary: { similarity: 90, findings: 1 },
      has_images: { reference: true, rendered: true },
    },
    {
      run_id: 'r2',
      page: 'p1',
      display_name: 'Overview',
      kind: 'values',
      batch_id: 'b1',
      ts: 1_700_000_200,
      summary: { numbers_matched: 2, numbers_printed: 3 },
      has_images: { reference: false, rendered: false },
    },
    {
      run_id: 'r1',
      page: 'p1',
      display_name: 'Overview',
      kind: 'image',
      batch_id: null,
      ts: 1_700_000_100,
      summary: { similarity: 82, findings: 3 },
      has_images: { reference: true, rendered: true },
    },
  ],
  trend: [
    { run_id: 'r1', ts: 1_700_000_100, kind: 'image', value: 82 },
    { run_id: 'r2', ts: 1_700_000_200, kind: 'values', value: 66.7 },
    { run_id: 'r3', ts: 1_700_000_300, kind: 'image', value: 90 },
  ],
}

function renderHistory() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <PageHistory conversionId="c1" page="p1" />
    </QueryClientProvider>,
  )
}

describe('PageHistory', () => {
  afterEach(() => vi.unstubAllGlobals())

  it('lists runs with a trend and opens an older image run read-only', async () => {
    const urls: string[] = []
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        urls.push(url)
        if (url.endsWith('/p1/history')) return new Response(JSON.stringify(history))
        if (url.endsWith('/p1/history/r1'))
          return new Response(
            JSON.stringify({ ...history.runs[2], payload: { ...comparison, run_id: 'r1' } }),
          )
        return new Response(JSON.stringify({ detail: 'unexpected ' + url }), { status: 404 })
      }),
    )
    const user = userEvent.setup()
    renderHistory()
    expect(await screen.findByTestId('page-history')).toBeInTheDocument()
    // similarity trend: 82 -> 90 = ▲ 8; numbers trend has one point (no delta)
    expect(screen.getAllByTestId('sparkline-delta')[0]).toHaveTextContent('▲ 8')
    expect(screen.getAllByRole('button', { name: /Open run/ })).toHaveLength(3)

    await user.click(screen.getByRole('button', { name: 'Open run r1' }))
    expect(await screen.findByTestId('readonly-banner')).toBeInTheDocument()
    expect(screen.getByAltText('reference')).toHaveAttribute(
      'src',
      '/api/v1/conversions/c1/dashboard/visual-compare/p1/history/r1/image/reference',
    )
    // fixes can't be applied to an older run
    expect(screen.queryByRole('button', { name: /Apply/ })).toBeNull()
  })

  it('opens an older number-check run', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        if (url.endsWith('/p1/history')) return new Response(JSON.stringify(history))
        if (url.endsWith('/p1/history/r2'))
          return new Response(JSON.stringify({ ...history.runs[1], payload: values }))
        return new Response('{}', { status: 404 })
      }),
    )
    const user = userEvent.setup()
    renderHistory()
    await user.click(await screen.findByRole('button', { name: 'Open run r2' }))
    await waitFor(() => expect(screen.getByTestId('numbers-panel')).toBeInTheDocument())
    expect(screen.queryByAltText('reference')).toBeNull()
  })

  it('says so when there are no runs', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(JSON.stringify({ page: 'p1', runs: [], trend: [] }))),
    )
    renderHistory()
    expect(await screen.findByText('No earlier runs for this page.')).toBeInTheDocument()
  })
})
