/** Power BI geometry for charts: `pbiChartOption(spec, data, style, scale)` -> an ECharts option
 * that lays category slots, bars, labels and axes out the way Power BI does. */
import type { EChartsOption } from 'echarts'
import { formatValue, formatWithDisplayUnits } from '../format'
import { PBI_DEFAULTS } from '../pbi/defaults'
import type { ResolvedStyle } from '../pbi/resolve'
import type { VisualResult, VisualSpec } from '../types'
import { niceCeil, niceCeilBar } from './niceScale'
import { scrollThickness, scrollZoom } from './scrollbar'

const GLYPH = 0.55 // average glyph width in em

/** Wraps `text` at spaces into at most `maxLines` lines that fit `widthPx`, ending a cut line
 * with an ellipsis; '' when fewer than 3 characters fit. */
export function fitLabel(text: string, widthPx: number, fontPx: number, maxLines = 2): string {
  const cpl = Math.floor(widthPx / (GLYPH * fontPx))
  if (cpl < 3) return ''
  if (text.length <= cpl) return text
  const lines: string[] = []
  let cur = ''
  let cut = false
  const push = () => {
    lines.push(cur)
    cur = ''
  }
  for (const word of text.split(/\s+/).filter(Boolean)) {
    if (lines.length >= maxLines) {
      cut = true
      break
    }
    if (cur === '') {
      if (word.length > cpl) {
        cur = `${word.slice(0, cpl - 1)}…`
        push()
      } else cur = word
    } else if (cur.length + 1 + word.length <= cpl) {
      cur += ` ${word}`
    } else {
      push()
      if (lines.length >= maxLines) {
        cut = true
        break
      }
      if (word.length > cpl) {
        cur = `${word.slice(0, cpl - 1)}…`
        push()
      } else cur = word
    }
  }
  if (cur !== '' && lines.length < maxLines) lines.push(cur)
  else if (cur !== '') cut = true
  if (cut && lines.length) {
    const last = lines[lines.length - 1]
    if (!last.endsWith('…')) lines[lines.length - 1] = `${last.slice(0, Math.max(cpl - 1, 1))}…`
  }
  return lines.slice(0, maxLines).join('\n')
}

/** One display unit for the whole visual (K / M / bn / T by the largest magnitude). */
export function autoDisplayUnits(values: (number | null)[]): number {
  const max = Math.max(0, ...values.map((v) => Math.abs(v ?? 0)))
  return max >= 1e12 ? 1e12 : max >= 1e9 ? 1e9 : max >= 1e6 ? 1e6 : max >= 1e3 ? 1e3 : 1
}

const textPx = (text: string, fontPx: number) => text.length * GLYPH * fontPx

export interface ChartSeries {
  key: string
  values: (number | null)[]
}

interface Shaped {
  categories: string[]
  outer: string[]
  series: ChartSeries[]
  measureOnly: boolean
}

const num = (v: unknown): number | null =>
  v === null || v === undefined || v === '' ? null : Number.isFinite(Number(v)) ? Number(v) : null

/** Result rows shaped into categories x series (a Series/legend field pivots to one series per
 * value; no category = measures only, one placeholder category per data point). */
export function shapeSeries(spec: VisualSpec, data: VisualResult, concatenate = true): Shaped {
  const seriesKeys = spec.series_keys ?? []
  const axisKeys = spec.dim_keys.filter((k) => !seriesKeys.includes(k))
  const idx = (k: string) => data.columns.indexOf(k)
  const axisIdx = axisKeys.map(idx).filter((i) => i >= 0)
  const label = (r: (string | number | null)[], ids: number[]) => ids.map((i) => String(r[i] ?? '')).join(' ')
  const si = seriesKeys[0] ? idx(seriesKeys[0]) : -1
  const mi = spec.measure_keys.map(idx)
  const inner = axisIdx.slice(-1)
  const outerIdx = axisIdx.slice(0, -1)
  const nested = !concatenate && axisIdx.length > 1

  const catOf = (r: (string | number | null)[]) => (nested ? label(r, inner) : label(r, axisIdx))
  if (!axisIdx.length) {
    const series = spec.measure_keys.map((k, j) => ({
      key: k,
      values: data.rows.slice(0, 1).map((r) => (mi[j] >= 0 ? num(r[mi[j]]) : null)),
    }))
    return { categories: data.rows.length ? data.rows.slice(0, 1).map(() => '') : [''], outer: [], series, measureOnly: true }
  }
  if (si >= 0 && spec.measure_keys.length) {
    const keyOf = (r: (string | number | null)[]) => JSON.stringify(axisIdx.map((i) => r[i]))
    const rows: { cat: string; outer: string; key: string }[] = []
    const seen = new Map<string, number>()
    for (const r of data.rows) {
      const k = keyOf(r)
      if (!seen.has(k)) {
        seen.set(k, rows.length)
        rows.push({ cat: catOf(r), outer: label(r, outerIdx), key: k })
      }
    }
    const by = new Map<string, (number | null)[]>()
    for (const r of data.rows) {
      const name = String(r[si] ?? '')
      if (!by.has(name)) by.set(name, rows.map(() => null))
      by.get(name)![seen.get(keyOf(r))!] = num(r[mi[0]])
    }
    return {
      categories: rows.map((x) => x.cat),
      outer: nested ? rows.map((x) => x.outer) : [],
      series: [...by.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([key, values]) => ({ key, values })),
      measureOnly: false,
    }
  }
  return {
    categories: data.rows.map(catOf),
    outer: nested ? data.rows.map((r) => label(r, outerIdx)) : [],
    series: spec.measure_keys.map((k, j) => ({
      key: k,
      values: data.rows.map((r) => (mi[j] >= 0 ? num(r[mi[j]]) : null)),
    })),
    measureOnly: false,
  }
}

const STACKED = new Set(['barChart', 'columnChart', 'hundredPercentStackedBarChart', 'hundredPercentStackedColumnChart'])
const HUNDRED = new Set(['hundredPercentStackedBarChart', 'hundredPercentStackedColumnChart'])
const HORIZONTAL = new Set(['barChart', 'clusteredBarChart', 'hundredPercentStackedBarChart'])
const isPie = (t: string) => t === 'pieChart' || t === 'donutChart'

function seriesColor(name: string, index: number, st: ResolvedStyle, explicit: boolean): string {
  const byName = st.fillByValue.byMeasure[name]
  if (byName) return byName
  if (st.fill && (explicit || index === 0)) return st.fill
  return st.palette[index % st.palette.length]
}

export interface PbiChartGeometry {
  slotPx: number
  barPx: number
  scrolling: boolean
  rotate: 0 | 45 | 90
}

/** Category slot, bar width and label rotation of a column/bar chart (also exported for tests). */
export function categoryGeometry(
  count: number,
  axisPx: number,
  st: ResolvedStyle,
  seriesCount: number,
  stacked: boolean,
): PbiChartGeometry {
  const C = PBI_DEFAULTS.category
  const inner = st.categoryAxis.innerPaddingPct / 100
  let slot = Math.max(st.categoryAxis.minWidthPx, axisPx / Math.max(count, 1))
  if (count <= 1 && st.categoryAxis.preferredWidthSet) slot = Math.max(st.categoryAxis.minWidthPx, axisPx * C.singleSlotPlotShare)
  let bar = slot * (1 - inner)
  if (count <= 1 && !st.categoryAxis.preferredWidthSet) bar = Math.min(bar, axisPx * C.maxBarFraction)
  const scrolling = st.categoryAxis.preferredWidthSet && slot * count > axisPx + 0.5
  const perSeries = stacked ? bar : bar / Math.max(seriesCount, 1)
  return { slotPx: slot, barPx: perSeries, scrolling, rotate: 0 }
}

export function pbiChartOption(
  spec: VisualSpec,
  data: VisualResult,
  st: ResolvedStyle,
  scale = 1,
): EChartsOption {
  const type = spec.visual_type
  const pad = st.container.padding
  const titleRoom = st.title.show ? Math.ceil(st.title.font.sizePx * 1.4) + 4 : 0
  const width = Math.max(spec.width - pad.left - pad.right, 40)
  const height = Math.max(spec.height - pad.top - pad.bottom - titleRoom, 40)
  const shaped = shapeSeries(spec, data, st.categoryAxis.concatenateLabels)
  const { categories, outer } = shaped
  let series = shaped.series.filter((s) => s.values.some((v) => v !== null && v !== 0) || shaped.measureOnly)
  if (!series.length) series = shaped.series.slice(0, 1)
  const totals = data.totals
  const showAs = spec.measure_show_as ?? {}
  const total = (key: string) => {
    const i = totals?.columns.indexOf(key) ?? -1
    return i >= 0 ? num(totals!.row[i]) : null
  }
  series = series.map((s) => {
    const denom = showAs[s.key] === 'percent_of_grand_total' ? total(s.key) : null
    return denom ? { key: s.key, values: s.values.map((v) => (v === null ? null : v / denom)) } : s
  })
  const fmtFor = (key: string) =>
    showAs[key] === 'percent_of_grand_total' ? '0.00%' : spec.measure_formats[key]
  const allValues = series.flatMap((s) => s.values)
  const labelUnits =
    st.labels.displayUnits !== undefined ? st.labels.displayUnits : autoDisplayUnits(allValues)
  const labelText = (v: unknown, key: string) =>
    formatWithDisplayUnits(Number(v ?? 0), fmtFor(key), showAs[key] ? 1 : labelUnits, st.labels.precision)
  const axisFormat = (key: string) => (v: number) =>
    formatWithDisplayUnits(
      v,
      fmtFor(key),
      showAs[key] ? 1 : st.valueAxis.labelDisplayUnits ?? 1,
      st.valueAxis.labelPrecision,
    )
  const first = series[0]?.key ?? spec.measure_keys[0] ?? ''

  if (isPie(type)) return pieOption(spec, st, categories, series, width, height, labelText)

  const horizontal = HORIZONTAL.has(type)
  const hundred = HUNDRED.has(type)
  const stacked = STACKED.has(type)
  const waterfall = type === 'waterfallChart'
  const isLine = type === 'lineChart' || type === 'areaChart'

  // 100% stacked normalises each category
  let plotted = series
  const raw = series
  if (hundred) {
    const colTotals = categories.map((_, i) => series.reduce((a, s) => a + (s.values[i] ?? 0), 0))
    plotted = series.map((s) => ({
      key: s.key,
      values: s.values.map((v, i) => (v === null ? null : colTotals[i] ? (v / colTotals[i]) * 100 : 0)),
    }))
  }

  const catFont = st.categoryAxis.font.sizePx
  const valFont = st.valueAxis.font.sizePx
  const showValueAxis = st.valueAxis.show
  const showCatAxis = st.categoryAxis.show
  const valueAxisRoom = showValueAxis ? 44 : 0
  const labelRight = horizontal && st.labels.show
    ? Math.ceil(Math.max(...allValues.map((v) => textPx(labelText(v, first), st.labels.font.sizePx)), 0)) + 8
    : 0
  const catAxisPx = horizontal ? height - 8 : width - valueAxisRoom - 8
  const geom = categoryGeometry(categories.length, catAxisPx, st, series.length, stacked)
  const scrolling = geom.scrolling
  const nested = outer.length > 0

  // label rotation: 45 deg when a label overflows its slot, 90 once scrolling / nested
  const longest = Math.max(0, ...categories.map((c) => textPx(c, catFont)))
  let rotate: 0 | 45 | 90 = 0
  if (!horizontal && showCatAxis) {
    if (scrolling || nested) rotate = 90
    else if (longest > geom.slotPx && !isLine) rotate = 45
  }
  const overhang = rotate === 45 ? Math.max(0, Math.ceil(longest * Math.SQRT1_2 - geom.slotPx / 2)) : 0

  const outerLines = nested ? 2 : 0
  const outerLine = Math.round(catFont * 1.25)
  const gridBottom = nested ? Math.ceil(catFont * 1.25 * outerLines) + 6 + 4 : 4
  const legendOn = st.legend.show && series.length > 1
  const legendTop = legendOn && st.legend.position.startsWith('Top') ? 26 : 8
  const legendBottom = legendOn && st.legend.position.startsWith('Bottom') ? 26 : gridBottom
  const grid = {
    left: 8 + overhang,
    right: 12 + labelRight,
    top: legendTop,
    bottom: legendBottom + (scrolling ? scrollThickness(scale) : 0),
    containLabel: showCatAxis && showValueAxis,
  }

  const maxValue = Math.max(0, ...plotted.flatMap((s) => s.values.map((v) => v ?? 0)))
  const stackedMax = stacked && !hundred
    ? Math.max(0, ...categories.map((_, i) => plotted.reduce((a, s) => a + Math.max(s.values[i] ?? 0, 0), 0)))
    : maxValue
  let valueMax: number | undefined = hundred ? 100 : isLine ? niceCeil(stackedMax) : niceCeilBar(stackedMax)
  if (!showValueAxis && st.labels.show && !horizontal && !isLine) {
    // outside labels with no value axis: the tallest bar keeps headroom for its label
    valueMax = stackedMax / PBI_DEFAULTS.category.tallestBarShare
  }

  const axisLabelCat = {
    show: showCatAxis,
    interval: 0 as const,
    rotate: rotate,
    color: st.categoryAxis.labelColor,
    fontSize: catFont,
    fontFamily: st.categoryAxis.font.family,
    formatter: (v: string) =>
      rotate === 0 && !horizontal ? fitLabel(v, geom.slotPx - 4, catFont, 2) : horizontal ? fitLabel(v, 120, catFont, 2) : v,
  }
  const categoryAxis = {
    type: 'category' as const,
    data: categories,
    show: showCatAxis,
    triggerEvent: true,
    inverse: horizontal,
    boundaryGap: !isLine,
    axisLine: { show: showCatAxis, lineStyle: { color: st.valueAxis.gridlineColor } },
    axisTick: { show: false },
    axisLabel: axisLabelCat,
  }
  const secondary = nested
    ? {
        type: 'category' as const,
        data: outer,
        position: 'bottom' as const,
        offset: catFont * 1.25 + 4,
        triggerEvent: true,
        axisLine: { show: false },
        axisTick: { show: false },
        axisLabel: {
          interval: (index: number) => index === 0 || outer[index] !== outer[index - 1],
          fontSize: catFont,
          lineHeight: outerLine,
          color: st.categoryAxis.labelColor,
          formatter: (v: string, index: number) => {
            let span = 1
            while (outer[index + span] === v) span++
            return fitLabel(v, geom.slotPx * span - 4, catFont, outerLines)
          },
        },
      }
    : null
  const valueAxis = {
    type: 'value' as const,
    show: showValueAxis,
    max: valueMax,
    scale: type === 'lineChart',
    splitLine: { show: st.valueAxis.gridlineShow, lineStyle: { color: st.valueAxis.gridlineColor } },
    axisLabel: {
      show: showValueAxis,
      color: st.valueAxis.labelColor,
      fontSize: valFont,
      formatter: hundred ? (v: number) => `${v}%` : axisFormat(first),
    },
  }

  const zoom = scrolling
    ? scrollZoom({
        axis: horizontal ? 'y' : 'x',
        axisIndex: 0,
        endValue: Math.max(Math.floor(catAxisPx / geom.slotPx) - 1, 0),
        scale,
      })
    : undefined

  const labelOn = st.labels.show
  const detailPercent = st.labels.detailPercent
  const makeSeries = (s: ChartSeries, i: number) => {
    const color = seriesColor(s.key, i, st, !stacked)
    const rawSeries = raw[i]
    const label = labelOn
      ? {
          show: true,
          position: stacked ? ('inside' as const) : horizontal ? ('right' as const) : ('top' as const),
          color: st.labels.color,
          fontSize: st.labels.font.sizePx,
          formatter: (p: { dataIndex: number; value?: unknown }) =>
            hundred && detailPercent
              ? `${Number(p.value ?? 0).toFixed(st.labels.percentagePrecision ?? 0)}%`
              : labelText(rawSeries.values[p.dataIndex], s.key),
        }
      : undefined
    const byCategory = st.fillByValue.byCategory
    const points = s.values.map((v, k) => {
      const c = series.length === 1 ? byCategory[categories[k]] : undefined
      return c ? { value: v, itemStyle: { color: c } } : v
    })
    if (isLine) {
      return {
        name: s.key,
        type: 'line' as const,
        data: s.values,
        showSymbol: false,
        itemStyle: { color },
        lineStyle: { color },
        areaStyle: type === 'areaChart' ? { opacity: 0.7, color } : undefined,
        label,
        tooltip: { valueFormatter: (v: unknown) => formatValue(v as number, fmtFor(s.key)) },
      }
    }
    return {
      name: s.key,
      type: 'bar' as const,
      stack: stacked ? 'total' : undefined,
      barWidth: geom.barPx,
      itemStyle: { color },
      data: points,
      label,
      tooltip: {
        valueFormatter: (v: unknown) =>
          hundred
            ? formatValue(rawSeries.values[0] ?? (v as number), fmtFor(s.key))
            : formatValue(v as number, fmtFor(s.key)),
      },
    }
  }

  if (waterfall) {
    return waterfallOption(spec, st, categories, series[0]?.values ?? [], grid, categoryAxis, valueAxis)
  }

  const xAxis = horizontal ? valueAxis : [categoryAxis, ...(secondary ? [secondary] : [])]
  const yAxis = horizontal ? categoryAxis : valueAxis
  return {
    color: st.palette,
    animation: false,
    grid,
    legend: legendOn
      ? {
          show: true,
          textStyle: { color: st.legend.color, fontSize: st.legend.font.sizePx },
          itemHeight: 8,
          itemWidth: 12,
          ...(st.legend.position.startsWith('Bottom') ? { bottom: 0 } : { top: 0 }),
        }
      : undefined,
    tooltip: { trigger: 'axis' },
    xAxis: xAxis as EChartsOption['xAxis'],
    yAxis: yAxis as EChartsOption['yAxis'],
    dataZoom: zoom,
    series: plotted.map(makeSeries) as EChartsOption['series'],
  }
}

function waterfallOption(
  spec: VisualSpec,
  st: ResolvedStyle,
  categories: string[],
  values: (number | null)[],
  grid: object,
  categoryAxis: object,
  valueAxis: object,
): EChartsOption {
  const vals = values.map((v) => v ?? 0)
  const bases: number[] = []
  let running = 0
  for (const v of vals) {
    bases.push(v >= 0 ? running : running + v)
    running += v
  }
  const withTotal = spec.options?.waterfall_total !== false
  const good = st.palette[9] ?? '#1AAB40'
  const bad = st.palette[7] ?? '#D64550'
  return {
    animation: false,
    grid,
    xAxis: { ...categoryAxis, data: withTotal ? [...categories, 'Total'] : categories } as never,
    yAxis: valueAxis as never,
    series: [
      { type: 'bar', stack: 'wf', itemStyle: { color: 'transparent' }, data: withTotal ? [...bases, 0] : bases, silent: true },
      {
        type: 'bar',
        stack: 'wf',
        data: [
          ...vals.map((v) => ({ value: Math.abs(v), itemStyle: { color: v >= 0 ? good : bad } })),
          ...(withTotal ? [{ value: running, itemStyle: { color: st.palette[0] } }] : []),
        ],
      },
    ],
  }
}

function pieOption(
  spec: VisualSpec,
  st: ResolvedStyle,
  categories: string[],
  series: ChartSeries[],
  width: number,
  height: number,
  labelText: (v: unknown, key: string) => string,
): EChartsOption {
  const P = PBI_DEFAULTS.pie
  const key = series[0]?.key ?? ''
  const legendRight = st.legend.show && st.legend.position.startsWith('Right')
  const legendShare = legendRight ? P.legendShare : 0
  const plotW = width * (1 - legendShare)
  const outside = st.labels.show
  const room = outside ? P.labelRoomPx : 8
  const radiusPx = Math.max(Math.min(plotW - 2 * room, height - 2 * (outside ? P.leaderRoomPx : 4)) / 2, 20)
  const slices = categories
    .map((name, i) => ({ name, value: series[0]?.values[i] ?? 0 }))
    .filter((s) => s.value !== 0)
  // explicit slice colours win; the palette goes to the rest in order
  let next = 0
  const data = slices.map((s) => {
    const explicit = st.fillByValue.byCategory[s.name]
    const color = explicit ?? st.palette[next++ % st.palette.length]
    return { name: s.name, value: s.value, itemStyle: { color } }
  })
  const sep = st.labels.contentLayout === 'TwoLines' ? '\n' : ' '
  const ratio = st.slices.innerRadiusRatio
  const donut = spec.visual_type === 'donutChart' && ratio > 0
  return {
    animation: false,
    legend: st.legend.show
      ? {
          show: true,
          orient: 'vertical',
          right: 0,
          top: 'middle',
          itemHeight: 8,
          textStyle: { color: st.legend.color, fontSize: st.legend.font.sizePx },
        }
      : undefined,
    tooltip: { trigger: 'item' },
    series: [
      {
        type: 'pie',
        center: [plotW / 2, height / 2],
        radius: donut ? [radiusPx * ratio, radiusPx] : [0, radiusPx],
        avoidLabelOverlap: true,
        data,
        label: {
          show: outside,
          position: 'outside',
          color: st.labels.color,
          fontSize: st.labels.font.sizePx,
          formatter: (p: { value?: unknown; percent?: number; name?: string }) => {
            const percent = `${(p.percent ?? 0).toFixed(st.labels.percentagePrecision ?? 2)}%`
            if (st.labels.detailPercent) return percent
            return `${labelText(p.value, key)}${sep}(${percent})`
          },
        },
        labelLine: { show: outside, length: 8, length2: 6 },
      },
    ],
  }
}
