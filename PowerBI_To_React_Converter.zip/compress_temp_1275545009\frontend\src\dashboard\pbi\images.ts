import { resourceItem } from './chrome'
import { litString } from './literal'

type Dict = Record<string, unknown>
const isDict = (v: unknown): v is Dict => typeof v === 'object' && v !== null && !Array.isArray(v)

/** `{resource}` for a registered image, `{url}` for a linked one (mirrors the backend). */
export function imageSourceOf(spec: {
  pbir?: { objects: Record<string, unknown> } | null
}): { resource?: string; url?: string } | null {
  const objects = spec.pbir?.objects
  const list = isDict(objects) && Array.isArray(objects.image) ? objects.image : []
  for (const entry of list) {
    const props = isDict(entry) && isDict(entry.properties) ? entry.properties : {}
    const node = props.imageUrl ?? props.url
    if (node === undefined) continue
    const resource = resourceItem(node)
    if (resource) return { resource }
    const url = litString(node)
    if (url) return { url }
  }
  const any = resourceItem(objects)
  return any ? { resource: any } : null
}
