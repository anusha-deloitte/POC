# Starts the dashboard's local service and opens it in the browser.
#   .\start.ps1 [-Port 8765] [-NoBrowser]
param(
    [int]$Port = 8765,
    [switch]$NoBrowser
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$url = "http://127.0.0.1:$Port/"
$health = "http://127.0.0.1:$Port/api/v1/published/health"

function Test-Service {
    try {
        $r = Invoke-WebRequest -Uri $health -UseBasicParsing -TimeoutSec 2
        return ($r.StatusCode -eq 200)
    } catch { return $false }
}

if (Test-Service) {
    if (-not $NoBrowser) { Start-Process $url }
    Write-Host "The dashboard is already running at $url"
    exit 0
}

# the Python version the vendored libraries were built for (data\manifest.json), 3.12 by default
$want = '3.12'
try {
    $m = Get-Content "$root\data\manifest.json" -Raw | ConvertFrom-Json
    if ($m.python) { $want = [string]$m.python }
} catch { }
$wantTag = $want.Replace('.', '')

function Find-Python {
    $candidates = @()
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) {
        try {
            $exe = & py -$want -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $exe) { $candidates += $exe.Trim() }
        } catch { }
    }
    $candidates += "$env:ProgramFiles\Python$wantTag\python.exe"
    $candidates += "$env:LOCALAPPDATA\Programs\Python\Python$wantTag\python.exe"
    $onPath = Get-Command python -ErrorAction SilentlyContinue
    if ($onPath) { $candidates += $onPath.Source }
    foreach ($c in $candidates) {
        if ($c -and (Test-Path $c)) {
            try {
                $v = & $c -c "import sys; print('%d.%d' % sys.version_info[:2], 8 * __import__('struct').calcsize('P'))" 2>$null
                if ($v -eq "$want 64") { return $c }
            } catch { }
        }
    }
    return $null
}

$python = Find-Python
if (-not $python) {
    Write-Error "Python $want was not found. Install Python $want (64-bit) from https://www.python.org/downloads/ and run start.ps1 again."
    exit 1
}

New-Item -ItemType Directory -Force -Path "$root\logs" | Out-Null
$env:PYTHONPATH = "$root\vendor;$root\service"
$env:PBIS_ROOT = $root
$env:PYTHONDONTWRITEBYTECODE = '1'

$out = "$root\logs\service.out.log"
$err = "$root\logs\service.err.log"
$cmd = "`"$python`" -m uvicorn main:app --host 127.0.0.1 --port $Port --app-dir `"$root\service`" 1>`"$out`" 2>`"$err`" <NUL"
Start-Process -FilePath cmd.exe -ArgumentList @('/d', '/s', '/c', "`"$cmd`"") -WindowStyle Hidden | Out-Null

$deadline = (Get-Date).AddSeconds(60)
while ((Get-Date) -lt $deadline) {
    if (Test-Service) {
        if (-not $NoBrowser) { Start-Process $url }
        Write-Host "The dashboard is running at $url"
        exit 0
    }
    Start-Sleep -Milliseconds 500
}

Write-Host "The service did not start within 60 seconds. Last lines of the error log:"
if (Test-Path $err) { Get-Content $err -Tail 25 }
exit 1
