import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import {
  albersUsa,
  albersUsaInverse,
  gradientColor,
  gradientStops,
  stateName,
  US_STATES,
} from '../dashboard/visuals/mapUtil'
import { mapValueKey } from '../dashboard/visuals/MapVisual'
import type { VisualSpec } from '../dashboard/types'

describe('state matching', () => {
  it('matches full names and USPS codes case-insensitively', () => {
    expect(stateName('California')).toBe('California')
    expect(stateName(' ca ')).toBe('California')
    expect(stateName('NEW YORK')).toBe('New York')
    expect(stateName('dc')).toBe('District of Columbia')
    expect(stateName('district of columbia')).toBe('District of Columbia')
  })

  it('does not draw unknown values', () => {
    expect(stateName('Not Mapped')).toBeNull()
    expect(stateName('')).toBeNull()
    expect(stateName(null)).toBeNull()
    expect(stateName('PR')).toBeNull() // 50 states + DC only
  })

  it('knows 50 states plus DC', () => {
    expect(Object.keys(US_STATES)).toHaveLength(51)
    expect(new Set(Object.values(US_STATES)).size).toBe(51)
  })

  it('every state in the bundled GeoJSON is matched (territories are not)', () => {
    const geo = JSON.parse(readFileSync('public/us-states.geo.json', 'utf-8'))
    const names: string[] = geo.features.map((f: { properties: { name: string } }) => f.properties.name)
    expect(names.filter((n) => stateName(n))).toHaveLength(51)
    expect(names.filter((n) => !stateName(n))).toEqual(['Puerto Rico'])
  })
})

describe('albersUsa projection', () => {
  it('places the lower 48 inside the 960 x 500 box with the centre of the US mid-box', () => {
    const [x, y] = albersUsa(-96, 38.5)
    expect(x).toBeGreaterThan(400)
    expect(x).toBeLessThan(560)
    expect(y).toBeGreaterThan(200)
    expect(y).toBeLessThan(300)
    const [sx, sy] = albersUsa(-122.4, 37.8) // San Francisco: left of centre
    expect(sx).toBeLessThan(x)
    expect(sy).toBeGreaterThan(0)
    const [nx, ny] = albersUsa(-74, 40.7) // New York: right of centre, north of Miami
    expect(nx).toBeGreaterThan(x)
    expect(ny).toBeLessThan(albersUsa(-80.2, 25.8)[1])
  })

  it('draws Alaska and Hawaii as insets below the lower 48', () => {
    const [ax, ay] = albersUsa(-150, 64) // Alaska
    const [hx, hy] = albersUsa(-157.8, 21.3) // Honolulu
    const [tx, ty] = albersUsa(-97, 31) // Texas
    expect(ay).toBeGreaterThan(ty - 20)
    expect(hy).toBeGreaterThan(ty - 20)
    expect(ax).toBeLessThan(tx)
    expect(hx).toBeLessThan(tx)
    expect(ay).toBeLessThan(560)
    expect(hy).toBeLessThan(560)
    expect(hx).toBeGreaterThan(ax - 10)
  })

  it('round-trips the lower 48', () => {
    const [x, y] = albersUsa(-100, 40)
    const [lon, lat] = albersUsaInverse(x, y)
    expect(lon).toBeCloseTo(-100, 3)
    expect(lat).toBeCloseTo(40, 3)
  })
})

describe('map colouring', () => {
  it('min/max default to the data extremes and the mid stop sits halfway', () => {
    const stops = gradientStops({ min: '#000000', mid: '#808080', max: '#FFFFFF' }, [10, 30, 20])
    expect(stops).toEqual({ min: 10, mid: 20, max: 30 })
    expect(gradientStops({ min: '#000', max: '#fff', minValue: 0, maxValue: 100, midValue: 80 }, [1, 2])).toEqual({
      min: 0, mid: 80, max: 100,
    })
  })

  it('interpolates a two- and three-stop gradient', () => {
    const two = { min: '#000000', max: '#FFFFFF' }
    const s2 = gradientStops(two, [0, 100])
    expect(gradientColor(two, s2, 0)).toBe('#000000')
    expect(gradientColor(two, s2, 50)).toBe('#808080')
    expect(gradientColor(two, s2, 100)).toBe('#FFFFFF')
    const three = { min: '#0000FF', mid: '#FFFFFF', max: '#FF0000' }
    const s3 = gradientStops(three, [0, 100])
    expect(gradientColor(three, s3, 0)).toBe('#0000FF')
    expect(gradientColor(three, s3, 50)).toBe('#FFFFFF')
    expect(gradientColor(three, s3, 100)).toBe('#FF0000')
    expect(gradientColor(three, s3, 25)).toBe('#8080FF')
  })

  it('a single value colours at the mid / max stop', () => {
    const g = { min: '#000000', max: '#FFFFFF' }
    expect(gradientColor(g, gradientStops(g, [5]), 5)).toBe('#FFFFFF')
  })

  it('colours by the Value / Color saturation measure, not the first tooltip', () => {
    const spec = {
      measure_keys: ['Tooltip measure', 'Sales'],
      measure_roles: { 'Tooltip measure': 'Tooltips', Sales: 'Values' },
    } as unknown as VisualSpec
    expect(mapValueKey(spec)).toBe('Sales')
    expect(
      mapValueKey({ measure_keys: ['A', 'B'], measure_roles: { A: 'Tooltips', B: 'Y' } } as unknown as VisualSpec),
    ).toBe('B')
    expect(mapValueKey({ measure_keys: ['A'], measure_roles: {} } as unknown as VisualSpec)).toBe('A')
  })
})
