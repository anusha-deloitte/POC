"""Process-local Snowflake sessions for the native Windows application."""

from __future__ import annotations

import re
import sys
import time
import webbrowser
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from threading import Lock, RLock
from typing import Any

from app.core.logging import get_logger, log_event
from app.services.connections import AuthMethod, ConnectionStore, warehouse_identifier

_logger = get_logger("snowflake_sessions")

_PASSCODE_RE = re.compile(r"^\d{6,8}$")
_MFA_ERROR_RE = re.compile(r"\b394508\b|MFA with TOTP|TOTP passcode", re.IGNORECASE)


class SnowflakeAuthenticationRequired(Exception):
    """Raised when an interactive profile has no active authenticated session."""


class SnowflakeMfaRequired(SnowflakeAuthenticationRequired):
    """Snowflake demands an MFA passcode for this password login."""


class SnowflakeWarehouseError(RuntimeError):
    """The configured role/warehouse could not be activated on the signed-in session."""


class _ManagedCursor:
    def __init__(
        self, cursor: Any, connection: _ManagedConnection, release_connection: bool = False
    ):
        self._cursor = cursor
        self.connection = connection
        self._release_connection = release_connection
        self._closed = False

    def __getattr__(self, name: str) -> Any:
        return getattr(self._cursor, name)

    def close(self) -> None:
        if not self._closed:
            self._closed = True
            self._cursor.close()
            if self._release_connection:
                self.connection.close()


class _ManagedConnection:
    def __init__(self, connection: Any, lease: Any):
        self._connection = connection
        self._lease = lease
        self._cursors: list[_ManagedCursor] = []
        self._closed = False

    def __getattr__(self, name: str) -> Any:
        return getattr(self._connection, name)

    def cursor(self, *args: Any, **kwargs: Any) -> _ManagedCursor:
        cursor = self._open_cursor(False, *args, **kwargs)
        return cursor

    def _open_cursor(
        self, release_connection: bool, *args: Any, **kwargs: Any
    ) -> _ManagedCursor:
        cursor = _ManagedCursor(
            self._connection.cursor(*args, **kwargs), self, release_connection
        )
        self._cursors.append(cursor)
        return cursor

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        for cursor in self._cursors:
            cursor.close()
        self._lease.__exit__(None, None, None)


class SnowflakeSessionManager:
    def __init__(
        self,
        store: ConnectionStore,
        connect: Callable[..., Any] | None = None,
    ):
        self._store = store
        self._connect_override = connect
        self._connections: dict[str, Any] = {}
        self._locks: dict[str, RLock] = {}
        self._state_lock = Lock()
        self._applied: dict[str, tuple[str | None, str]] = {}
        self._settings_errors: dict[str, str] = {}
        self._mfa_profiles: set[str] = set()
        self._sso_urls: dict[str, str] = {}
        self._query_tags: dict[str, tuple[int, str]] = {}

    def _lock_for(self, profile_id: str) -> RLock:
        with self._state_lock:
            return self._locks.setdefault(profile_id, RLock())

    # ---- role / warehouse ----

    @staticmethod
    def _apply_session_settings(conn: Any, role: str | None, warehouse: str) -> None:
        cur = conn.cursor()
        try:
            if role:
                try:
                    cur.execute(f"USE ROLE {warehouse_identifier(role)}")
                except Exception as e:  # noqa: BLE001 - connector raises many exception types
                    raise SnowflakeWarehouseError(
                        f"role {role} could not be activated for this user: {e}"
                    ) from e
            try:
                cur.execute(f"USE WAREHOUSE {warehouse_identifier(warehouse)}")
            except Exception as e:  # noqa: BLE001
                hint = " Set a role that has USAGE on it, or pick another warehouse."
                try:
                    cur.execute("SHOW WAREHOUSES")
                    names = [str(r[0]) for r in cur.fetchall()][:15]
                    if names:
                        hint = f" Warehouses this role can use: {', '.join(names)}."
                except Exception as list_err:  # noqa: BLE001
                    log_event(_logger, "debug", "show_warehouses_failed", error=str(list_err))
                raise SnowflakeWarehouseError(
                    f"signed in, but warehouse {warehouse} could not be activated "
                    f"(role {role or 'default'}): {e}.{hint}"
                ) from e
        finally:
            cur.close()

    def _profile_settings(self, profile_id: str) -> tuple[str | None, str]:
        profile = self._store.get(profile_id)
        warehouse = (profile.warehouse or "").strip()
        if not warehouse:
            raise ValueError(
                f"connection '{profile.name}' has no warehouse; edit the connection and set one"
            )
        return (profile.role or None), warehouse

    def _ensure_settings(self, profile_id: str, conn: Any) -> None:
        role, warehouse = self._profile_settings(profile_id)
        if self._applied.get(profile_id) == (role, warehouse):
            return
        try:
            self._apply_session_settings(conn, role, warehouse)
        except SnowflakeWarehouseError as e:
            self._applied.pop(profile_id, None)
            self._settings_errors[profile_id] = str(e)
            log_event(
                _logger,
                "warning",
                "snowflake_session_settings_failed",
                profile_id=profile_id,
                error=str(e),
            )
            raise
        self._applied[profile_id] = (role, warehouse)
        self._settings_errors.pop(profile_id, None)

    def settings_changed(self, profile_id: str) -> None:
        self._applied.pop(profile_id, None)
        self._settings_errors.pop(profile_id, None)

    def settings_error(self, profile_id: str) -> str | None:
        return self._settings_errors.get(profile_id)

    # ---- MFA ----

    def _is_mfa(self, profile_id: str) -> bool:
        return profile_id in self._mfa_profiles or self._store.mfa_enforced(profile_id)

    def _remember_mfa(self, profile_id: str, enforced: bool) -> None:
        if enforced:
            self._mfa_profiles.add(profile_id)
        else:
            self._mfa_profiles.discard(profile_id)
        try:
            self._store.set_mfa_enforced(profile_id, enforced)
        except Exception as e:  # noqa: BLE001 - persistence is best effort
            log_event(_logger, "warning", "snowflake_mfa_flag_save_failed", error=str(e))

    # ---- connecting ----

    def _connect(
        self, profile_id: str, query_tag: str | None = None, passcode: str | None = None
    ):
        connect = self._connect_override
        if connect is None:
            import snowflake.connector

            connect = snowflake.connector.connect
        profile = self._store.get(profile_id)
        is_password = profile.auth_method == AuthMethod.PASSWORD
        passcode = (passcode or "").strip() or None
        if passcode:
            if not is_password:
                raise ValueError("an MFA passcode only applies to username & password logins")
            if not _PASSCODE_RE.match(passcode):
                raise ValueError("MFA passcode must be the 6-8 digit code from your authenticator")
        self._profile_settings(profile_id)  # no warehouse -> ValueError before any sign-in
        kwargs = self._store.connector_kwargs(profile_id, query_tag=query_tag)
        if passcode:
            kwargs["passcode"] = passcode
        use_mfa = is_password and (bool(passcode) or self._is_mfa(profile_id))
        if use_mfa:
            kwargs["authenticator"] = "username_password_mfa"
        # log only non-secret connection metadata, never the kwargs dict itself
        # (it carries password/private_key/token for several auth methods)
        started = time.perf_counter()
        try:
            if profile.auth_method == AuthMethod.EXTERNAL_BROWSER:
                connection = self._connect_via_browser(profile_id, connect, kwargs)
            else:
                connection = connect(**kwargs, login_timeout=120, network_timeout=120)
            if is_password:
                self._remember_mfa(profile_id, use_mfa)
            log_event(
                _logger,
                "info",
                "snowflake_connect",
                profile_id=profile_id,
                account=profile.account,
                user=profile.user,
                auth_method=profile.auth_method,
                query_tag=query_tag,
                elapsed_ms=round((time.perf_counter() - started) * 1000),
            )
            return connection
        except Exception as e:
            if is_password and _MFA_ERROR_RE.search(str(e)):
                self._remember_mfa(profile_id, True)
                suffix = " (the code was rejected or expired)" if passcode else ""
                raise SnowflakeMfaRequired(
                    "Snowflake requires MFA for this user: enter the current 6-digit code "
                    "from your authenticator app and sign in again" + suffix
                ) from e
            log_event(
                _logger,
                "error",
                "snowflake_connect_failed",
                profile_id=profile_id,
                query_tag=query_tag,
                error=str(e),
                elapsed_ms=round((time.perf_counter() - started) * 1000),
            )
            raise

    def _connect_via_browser(
        self, profile_id: str, connect: Callable[..., Any], kwargs: dict[str, Any]
    ):
        """Sign in with SSO, capturing the sign-in URL so the UI can show it when the
        browser doesn't open on its own."""
        real_open_new = webbrowser.open_new
        real_open = webbrowser.open

        def capture(url: str, *args: Any, **kw: Any) -> bool:
            if self._sso_urls.get(profile_id) != url:
                self._sso_urls[profile_id] = url
                log_event(_logger, "info", "snowflake_sso_url", profile_id=profile_id)
                print(
                    f"[pbic] Snowflake SSO sign-in URL (profile {profile_id}): {url}",
                    file=sys.stderr,
                )
            # restore around the real call so it can't recurse into this capture
            webbrowser.open_new = real_open_new
            webbrowser.open = real_open
            try:
                return real_open_new(url)
            finally:
                webbrowser.open_new = capture
                webbrowser.open = capture

        webbrowser.open_new = capture
        webbrowser.open = capture
        try:
            return connect(**kwargs, login_timeout=120, network_timeout=120)
        finally:
            webbrowser.open_new = real_open_new
            webbrowser.open = real_open
            self._sso_urls.pop(profile_id, None)

    @staticmethod
    def _is_open(connection: Any | None) -> bool:
        if connection is None:
            return False
        try:
            return not connection.is_closed()
        except (AttributeError, TypeError):
            return True

    @staticmethod
    def _close(connection: Any | None) -> None:
        if connection is None:
            return
        try:
            connection.close()
        except Exception as e:  # noqa: BLE001 - cleanup must remain best effort
            log_event(_logger, "warning", "snowflake_close_failed", error=str(e))

    def authenticate(
        self,
        profile_id: str,
        query_tag: str = "pbic:authenticate",
        passcode: str | None = None,
        force: bool = False,
    ):
        """Establish a session. This is the only operation allowed to launch SSO."""
        lock = self._lock_for(profile_id)
        with lock:
            current = self._connections.get(profile_id)
            if self._is_open(current) and not force:
                self._ensure_settings(profile_id, current)
                return current

            connection = self._connect(profile_id, query_tag, passcode=passcode)
            previous = self._connections.pop(profile_id, None)
            self._connections[profile_id] = connection
            self._close(previous)
            self._applied.pop(profile_id, None)
            self._query_tags[profile_id] = (id(connection), query_tag)
            self._ensure_settings(profile_id, connection)  # error keeps the session cached
            return connection

    @contextmanager
    def lease(self, profile_id: str, query_tag: str = "pbi_converter") -> Iterator[Any]:
        lock = self._lock_for(profile_id)
        with lock:
            connection = self._connections.get(profile_id)
            if not self._is_open(connection):
                self._connections.pop(profile_id, None)
                self._close(connection)
                profile = self._store.get(profile_id)
                if profile.auth_method == AuthMethod.EXTERNAL_BROWSER:
                    log_event(
                        _logger,
                        "warning",
                        "snowflake_session_expired",
                        profile_id=profile_id,
                        query_tag=query_tag,
                        auth_method=profile.auth_method,
                    )
                    raise SnowflakeAuthenticationRequired(
                        "Snowflake browser authentication is required"
                    )
                connection = self._connect(profile_id, query_tag)
                self._connections[profile_id] = connection
                self._applied.pop(profile_id, None)
                self._query_tags[profile_id] = (id(connection), query_tag)
            elif self._query_tags.get(profile_id) != (id(connection), query_tag):
                cursor = connection.cursor()
                try:
                    cursor.execute("ALTER SESSION SET QUERY_TAG = %s", (query_tag,))
                finally:
                    cursor.close()
                self._query_tags[profile_id] = (id(connection), query_tag)
            self._ensure_settings(profile_id, connection)
            yield connection

    def status(self, profile_id: str, verify: bool = False) -> dict[str, Any]:
        self._store.get(profile_id)
        sso_url = self._sso_urls.get(profile_id)
        if sso_url:  # a browser connect holds the profile lock, so look before taking it
            return {"authenticated": False, "sso_url": sso_url}
        lock = self._lock_for(profile_id)
        with lock:
            connection = self._connections.get(profile_id)
            authenticated = self._is_open(connection)
            verified = False
            expired = False
            reason: str | None = None
            if not authenticated:
                self._connections.pop(profile_id, None)
                self._close(connection)
            elif verify:
                try:
                    cur = connection.cursor()
                    try:
                        cur.execute("SELECT 1")
                    finally:
                        cur.close()
                    verified = True
                except Exception as e:  # noqa: BLE001
                    self._connections.pop(profile_id, None)
                    self._close(connection)
                    self._applied.pop(profile_id, None)
                    self._query_tags.pop(profile_id, None)
                    authenticated = False
                    expired = True
                    reason = str(e)[:300]
                    log_event(
                        _logger,
                        "warning",
                        "snowflake_session_check_failed",
                        profile_id=profile_id,
                        error=reason,
                    )
            out: dict[str, Any] = {
                "authenticated": authenticated,
                "sso_url": None,
                "mfa_required": (not authenticated) and self._is_mfa(profile_id),
            }
            if authenticated:
                out["settings_error"] = self._settings_errors.get(profile_id)
            if verify:
                out["mfa_enforced"] = self._is_mfa(profile_id)
                out["verified"] = verified
                out["checked_at"] = round(time.time())
                out["expired"] = expired
                if reason is not None:
                    out["reason"] = reason
            return out

    def open_connection(
        self, profile_id: str, query_tag: str = "pbi_converter"
    ) -> _ManagedConnection:
        """Return a close-compatible lease for existing synchronous call sites."""
        lease = self.lease(profile_id, query_tag)
        connection = lease.__enter__()
        return _ManagedConnection(connection, lease)

    def open_cursor(self, profile_id: str, query_tag: str = "pbi_converter") -> _ManagedCursor:
        connection = self.open_connection(profile_id, query_tag)
        return connection._open_cursor(True)

    def evict(self, profile_id: str) -> None:
        lock = self._lock_for(profile_id)
        with lock:
            self._close(self._connections.pop(profile_id, None))
            self._applied.pop(profile_id, None)
            self._settings_errors.pop(profile_id, None)
            self._query_tags.pop(profile_id, None)

    def close_all(self) -> None:
        with self._state_lock:
            profile_ids = list(self._connections)
        for profile_id in profile_ids:
            self.evict(profile_id)
