"""NULL-safe filter lists and BLANK comparison semantics (phase 06.3)."""

from __future__ import annotations

import pytest

from app.dax.compiler import MeasureCompiler, rewrite_blank_comparisons
from app.dax.parser import BinOp, Blank, ColumnRef, FuncCall, UnaryOp, parse_dax
from app.runtime.engine import (
    DimensionRef,
    FilterClause,
    MeasureFilter,
    MeasureRefSpec,
    QuerySpec,
    null_safe_in_sql,
)
from tests.duck import DuckWorld


def lit(v):
    return "NULL" if v is None else (repr(v) if not isinstance(v, str) else f"'{v}'")


@pytest.mark.parametrize(
    ("op", "values", "expected"),
    [
        ("not_in", [None], "c IS NOT NULL"),
        ("not_in", [None, "x"], "(c IS NOT NULL AND c != 'x')"),
        ("not_in", [None, "x", "y"], "(c IS NOT NULL AND c NOT IN ('x', 'y'))"),
        ("in", [None], "c IS NULL"),
        ("in", [None, "x", "y"], "(c IS NULL OR c IN ('x', 'y'))"),
        ("eq", [None], "c IS NULL"),
        ("neq", [None], "c IS NOT NULL"),
        ("in", ["x"], "c IN ('x')"),
        ("not_in", ["x", "y"], "c NOT IN ('x', 'y')"),
        ("eq", ["x"], "c = 'x'"),
        ("neq", ["x"], "c <> 'x'"),
    ],
)
def test_null_safe_rules(op, values, expected):
    assert null_safe_in_sql("c", op, values, lit) == expected


ROWS = [(1, "N", 10.0), (2, "S", 5.0), (3, None, 4.0), (4, "E", 1.0)]


def world(measures=None) -> DuckWorld:
    return DuckWorld(
        {"T": (["Id", "Region", "Amount"], ROWS)},
        measures={"Total": "SUM(T[Amount])", **(measures or {})},
    )


def total(w, op, values):
    return w.value(
        "Total", filters=[FilterClause(table="T", column="Region", op=op, values=values)]
    )


def test_filter_rows_match_power_bi():
    w = world()
    assert total(w, "not_in", [None]) == 16.0  # blanks excluded
    assert total(w, "not_in", [None, "N"]) == 6.0
    assert total(w, "in", [None, "S"]) == 9.0
    assert total(w, "in", [None]) == 4.0
    assert total(w, "eq", [None]) == 4.0
    assert total(w, "neq", [None]) == 16.0
    assert total(w, "in", ["N", "S"]) == 15.0


def test_or_clause_filter():
    w = world()
    flt = FilterClause(
        table="T",
        column="Region",
        op="or",
        clauses=[
            FilterClause(table="T", column="Region", op="eq", values=["N"]),
            FilterClause(table="T", column="Region", op="eq", values=[None]),
        ],
    )
    assert w.value("Total", filters=[flt]) == 14.0


def test_filter_source_is_audit_only():
    w = world()
    a = FilterClause(table="T", column="Region", values=["N"])
    b = FilterClause(table="T", column="Region", values=["N"], source="slicer")
    assert w.sql(QuerySpec(measures=[MeasureRefSpec(name="Total")], filters=[a])) == w.sql(
        QuerySpec(measures=[MeasureRefSpec(name="Total")], filters=[b])
    )


def test_measure_filter_keeps_matching_rows_and_is_not_projected():
    w = DuckWorld(
        {
            "F": (["K", "Amt"], [(1, 10.0), (2, 3.0), (3, 8.0)]),
            "D": (["Id", "Name"], [(1, "a"), (2, "b"), (3, "c")]),
        },
        rels=[("F", "K", "D", "Id")],
        measures={"Total": "SUM(F[Amt])"},
    )
    spec = QuerySpec(
        dimensions=[DimensionRef(table="D", column="Name")],
        measures=[],
        measure_filters=[MeasureFilter(measure="Total", op="gt", values=[5])],
    )
    assert w.run(spec) == [("a",), ("c",)]
    shown = QuerySpec(
        dimensions=[DimensionRef(table="D", column="Name")],
        measures=[MeasureRefSpec(name="Total")],
        measure_filters=[MeasureFilter(measure="Total", op="in", values=[3.0, 8.0])],
    )
    assert w.run(shown) == [("b", 3.0), ("c", 8.0)]
    # the filter combines with column filters
    both = QuerySpec(
        dimensions=[DimensionRef(table="D", column="Name")],
        measures=[MeasureRefSpec(name="Total")],
        measure_filters=[MeasureFilter(measure="Total", op="gte", values=[3])],
        filters=[FilterClause(table="D", column="Name", op="not_in", values=["a"])],
    )
    assert w.run(both) == [("b", 3.0), ("c", 8.0)]


def test_measure_filter_on_card_without_dimensions():
    w = world()
    spec_keep = QuerySpec(
        measures=[MeasureRefSpec(name="Total")],
        measure_filters=[MeasureFilter(measure="Total", op="gt", values=[1])],
    )
    spec_drop = QuerySpec(
        measures=[MeasureRefSpec(name="Total")],
        measure_filters=[MeasureFilter(measure="Total", op="lt", values=[1])],
    )
    assert w.run(spec_keep) == [(20.0,)]
    assert w.run(spec_drop) == []


# ---------------------------------------------------------------------- BLANK comparisons


def test_blank_comparison_ast_rewrite():
    ne = rewrite_blank_comparisons(parse_dax("T[c] <> BLANK()"))
    assert ne == UnaryOp("NOT", FuncCall("ISBLANK", (ColumnRef("T", "c"),)))
    eq = rewrite_blank_comparisons(parse_dax("BLANK() = T[c]"))
    assert eq == FuncCall("ISBLANK", (ColumnRef("T", "c"),))
    eq2 = rewrite_blank_comparisons(parse_dax("T[c] == BLANK()"))
    assert eq2 == FuncCall("ISBLANK", (ColumnRef("T", "c"),))
    nested = rewrite_blank_comparisons(parse_dax("IF(T[c] = BLANK(), 1, 2)"))
    assert nested.args[0] == FuncCall("ISBLANK", (ColumnRef("T", "c"),))
    keep = rewrite_blank_comparisons(parse_dax("T[c] > BLANK()"))
    assert isinstance(keep, BinOp) and isinstance(keep.right, Blank)


def test_blank_comparisons_compile_without_equals_null_and_compute():
    w = world(
        {
            "NotBlank": "CALCULATE([Total], T[Region] <> BLANK())",
            "OnlyBlank": "CALCULATE([Total], T[Region] = BLANK())",
            "IfBlank": 'IF(SELECTEDVALUE(T[Region]) = BLANK(), "none", "some")',
        }
    )
    comp = MeasureCompiler(w.model)
    for name in ("NotBlank", "OnlyBlank", "IfBlank"):
        cm = comp.compile_measure(name)
        sqls = [leaf.sql for leaf in cm.leaves.values()] + [cm.expr]
        sqls += [p.sql for leaf in cm.leaves.values() for p in leaf.ctx.filters]
        joined = " ".join(sqls)
        assert "= NULL" not in joined and "<> NULL" not in joined
    assert w.value("NotBlank") == 16.0
    assert w.value("OnlyBlank") == 4.0
    assert w.value("IfBlank") == "none"  # no single value selected -> BLANK


def test_blank_arithmetic_and_text_concat():
    w = DuckWorld(
        {"T": (["A", "B"], [(None, None)])},
        types={("T", "A"): "double", ("T", "B"): "double"},
        measures={
            "Both": "SUM(T[A]) + SUM(T[B])",
            "OneSide": "1 - BLANK()",
            "Minus": "5 - SUM(T[A])",
            "Mul": "5 * SUM(T[A])",
            "Cat": '"a" & BLANK() & "b"',
            "AllBlank": '"" & BLANK()',
        },
    )
    assert w.value("Both") is None  # BLANK + BLANK stays BLANK
    assert w.value("OneSide") == 1  # BLANK acts as 0 in + and -
    assert w.value("Minus") == 5
    assert w.value("Mul") is None
    assert w.value("Cat") == "ab"
    assert w.value("AllBlank") == ""


def test_blank_compares_as_zero_and_empty_text_inside_conditions():
    w = DuckWorld(
        {"T": (["A", "S"], [(None, None)])},
        types={("T", "A"): "double", ("T", "S"): "string"},
        measures={
            "Zero": 'IF(SUM(T[A]) = 0, "zero", "other")',
            "Lt": 'IF(SUM(T[A]) < 1, "lt", "ge")',
            "Empty": 'IF(MAX(T[S]) = "", "empty", "text")',
        },
    )
    assert w.value("Zero") == "zero"
    assert w.value("Lt") == "lt"
    assert w.value("Empty") == "empty"
