"""Page fingerprints and content-based PDF page / report matching."""

from __future__ import annotations

import itertools
import os
import random
from types import SimpleNamespace

import pytest

from app.ir.report import Page, Visual, VisualField
from app.services import page_fingerprint as pf
from app.services import pdf_matching as pm
from app.services.pdf_text import PdfPageText, TextRun


def lit(text: str) -> dict:
    return {"expr": {"Literal": {"Value": f"'{text}'"}}}


def textbox(*values: str) -> Visual:
    runs = [{"value": v} for v in values]
    return Visual(
        name="tb", visual_type="textbox",
        formatting={"general": [{"properties": {"paragraphs": [{"textRuns": runs}]}}]},
    )  # fmt: skip


def page(name, display, ordinal, visuals=(), **kw) -> Page:
    return Page(name=name, display_name=display, ordinal=ordinal, visuals=list(visuals), **kw)


def pdf_page(index, text, w=1280, h=720) -> PdfPageText:
    runs = [TextRun(t, 10, 10 + 20 * i, 80, 25 + 20 * i, 12) for i, t in enumerate(text.split("|"))]
    return PdfPageText(index, w, h, runs)


# ------------------------------------------------------------------ fingerprints


def test_fingerprint_collects_titles_textbox_labels_and_fields():
    chart = Visual(
        name="c1", visual_type="barChart", title="Claims by Provider",
        fields=[VisualField(role="Y", table="Fact", name="Paid", display_name="Paid Amount", is_measure=True)],
        container_objects={"title": [{"properties": {"text": lit("Network Mix")}}]},
    )  # fmt: skip
    hidden = Visual(name="h", visual_type="card", title="Secret Hidden Title", is_hidden=True)
    p = page("p1", "Cost​ Overview", 0, [chart, textbox("Quarterly", "Dashboard"), hidden])
    fp = pf.fingerprint_page(p)
    words = set(fp.words)
    assert {"cost", "overview", "claims", "provider", "paid", "amount", "network", "mix"} <= words
    assert {"quarterly", "dashboard"} <= words and "secret" not in words
    assert fp.display_name == "Cost Overview"
    assert set(fp.title_tokens) == {"cost", "overview", "quarterly", "dashboard"}


def test_bundle_fingerprint_skips_tooltips_keeps_hidden_pages_in_ordinal_order(monkeypatch):
    bundle = SimpleNamespace(
        report=SimpleNamespace(
            pages=[
                page("c", "Third", 2),
                page("t", "Tip", 1, page_type="Tooltip"),
                page("h", "Hidden Detail", 3, is_hidden=True),
                page("a", "First", 0),
            ]
        )
    )
    monkeypatch.setattr("app.runtime.pbir_passthrough.filters_passthrough", lambda b: None)
    assert [f.page for f in pf.fingerprint_bundle(bundle)] == ["a", "c", "h"]


def test_stored_fingerprints_are_cached_on_bundle_mtime(tmp_path, monkeypatch):
    calls = []
    bundle_file = tmp_path / "bundle.json"
    bundle_file.write_text("{}")
    bundle = SimpleNamespace(report=SimpleNamespace(name="R", pages=[page("a", "Alpha", 0)]))

    class Svc:
        def list_jobs(self):
            return [{"id": "c1", "name": "job", "uploaded_at": 1.0, "converted_at": None}]

        def conversion_dir(self, cid):
            return tmp_path

        def load_bundle(self, cid):
            calls.append(cid)
            return bundle

    monkeypatch.setattr(pf, "_cache", {})
    monkeypatch.setattr("app.runtime.pbir_passthrough.filters_passthrough", lambda b: None)
    first = pf.stored_fingerprints(Svc())
    pf.stored_fingerprints(Svc())
    assert len(calls) == 1 and first[0].job_name == "job" and first[0].pages[0].page == "a"
    st = bundle_file.stat()
    os.utime(bundle_file, (st.st_atime, st.st_mtime + 5))
    pf.stored_fingerprints(Svc())
    assert len(calls) == 2


def test_unreadable_conversions_are_skipped(tmp_path, monkeypatch):
    class Svc:
        def list_jobs(self):
            return [{"id": "bad"}]

        def conversion_dir(self, cid):
            return tmp_path / "missing"

    monkeypatch.setattr(pf, "_cache", {})
    assert pf.stored_fingerprints(Svc()) == []


# ------------------------------------------------------------------ assignment


def test_hungarian_finds_the_best_total_not_the_greedy_one():
    # greedy takes 9 and leaves 1 (total 10); the optimum is 8 + 8
    assert pm.hungarian_max([[9.0, 8.0], [8.0, 1.0]]) == [1, 0]
    assert pm.hungarian_max([[1.0, 5.0, 2.0]]) == [1]
    assert pm.hungarian_max([[1.0], [3.0], [2.0]]) == [-1, 0, -1]
    assert pm.hungarian_max([]) == []


@pytest.mark.parametrize("seed", range(6))
def test_hungarian_matches_brute_force(seed):
    rnd = random.Random(seed)
    n, m = rnd.randint(1, 5), rnd.randint(1, 5)
    s = [[rnd.random() for _ in range(m)] for _ in range(n)]
    got = pm.hungarian_max(s)
    total = sum(s[i][j] for i, j in enumerate(got) if j >= 0)
    k = min(n, m)
    best = max(
        sum(s[r][c] for r, c in zip(rows, cols, strict=True))
        for rows in itertools.permutations(range(n), k)
        for cols in itertools.permutations(range(m), k)
    )
    assert total == pytest.approx(best)


# ------------------------------------------------------------------ page matching


def fps() -> list[pf.PageFingerprint]:
    return [
        pf.fingerprint_page(page("a", "Cost Overview", 0, [textbox("Total Paid Claims Summary")])),
        pf.fingerprint_page(
            page("b", "Provider Network", 1, [textbox("Provider Network Utilization")])
        ),
        pf.fingerprint_page(
            page("c", "Member Demographics", 2, [textbox("Member Age Gender Mix")])
        ),
    ]


def test_pages_match_by_content_even_when_the_pdf_order_differs():
    pdf = [
        pdf_page(0, "Member Demographics|Member Age Gender Mix|Average age"),
        pdf_page(1, "Cost Overview|Total Paid Claims Summary|$2.14M"),
        pdf_page(2, "Provider Network|Provider Network Utilization"),
    ]
    got = pm.match_pages(pdf, fps())
    assert [m.page for m in got] == ["c", "a", "b"]
    assert all(m.confident for m in got) and got[0].display_name == "Member Demographics"


def test_a_weak_page_stays_unmatched_with_its_best_guess_as_runner_up():
    pdf = [
        pdf_page(0, "Cost Overview|Total Paid Claims Summary"),
        pdf_page(1, "zzz qqq|nothing relevant"),
    ]
    got = pm.match_pages(pdf, fps())
    assert got[0].page == "a"
    assert got[1].page is None and got[1].confident is False
    assert got[1].runner_up and got[1].runner_up["page"] in {"a", "b", "c"}


def test_two_pdf_pages_never_take_the_same_report_page():
    same = "Cost Overview|Total Paid Claims Summary"
    got = pm.match_pages([pdf_page(0, same), pdf_page(1, same)], fps())
    assigned = [m.page for m in got if m.page]
    assert len(assigned) == len(set(assigned))


def test_aspect_ratio_and_order_break_ties():
    twin = [
        pf.fingerprint_page(page("w", "Overview", 0, width=1280, height=720)),
        pf.fingerprint_page(page("t", "Overview", 1, width=720, height=1280)),
    ]
    assert pm.match_pages([pdf_page(0, "Overview", w=540, h=960)], twin)[0].page == "t"
    same = [
        pf.fingerprint_page(page("x", "Overview", 0)),
        pf.fingerprint_page(page("y", "Overview", 1)),
    ]
    got = pm.match_pages([pdf_page(0, "Overview"), pdf_page(1, "Overview")], same)
    assert [m.page for m in got] == ["x", "y"]  # the order bonus keeps document order


def test_empty_inputs():
    assert pm.match_pages([], fps()) == []
    only = pm.match_pages([pdf_page(0, "x")], [])
    assert only[0].page is None and only[0].runner_up is None


# ------------------------------------------------------------------ report matching


def report(cid, name, pages, job=None, uploaded=1.0, converted=None):
    return pf.ReportFingerprint(cid, name, job, uploaded, converted, pages)


def test_the_right_report_wins_and_is_confident():
    other = [pf.fingerprint_page(page("o", "Inventory Levels", 0, [textbox("Warehouse Stock")]))]
    reports = [report("r1", "Claims Analytics", fps()), report("r2", "Stock", other)]
    pdf = [
        pdf_page(0, "Cost Overview|Total Paid Claims Summary"),
        pdf_page(1, "Provider Network|Provider Network Utilization"),
        pdf_page(2, "Member Demographics|Member Age Gender Mix"),
    ]
    got = pm.match_pdf("claims_analytics.pdf", pdf, reports, pdf_title="Claims Analytics")
    assert got.confident and got.candidates[0].conversion_id == "r1" and got.warnings == []
    assert len(got.candidates) == 2 and got.candidates[0].score > got.candidates[1].score
    assert [p["page"] for p in got.candidates[0].report_pages] == ["a", "b", "c"]


def test_ambiguous_reports_warn_and_list_candidates_newest_first():
    twins = [
        report("old", "Claims", fps(), job="old run", uploaded=1.0),
        report("new", "Claims", fps(), job="new run", uploaded=5.0, converted=9.0),
    ]
    got = pm.match_pdf("x.pdf", [pdf_page(0, "Cost Overview|Total Paid Claims Summary")], twins)
    assert [c.conversion_id for c in got.candidates] == ["new", "old"]
    assert got.confident is False
    assert any("score equally" in w for w in got.warnings)
    assert any("no confident report match" in w and "Claims" in w for w in got.warnings)


def test_no_reports_and_scanned_pdfs_warn():
    got = pm.match_pdf("x.pdf", [pdf_page(0, "Cost")], [])
    assert got.candidates == [] and "no stored reports" in got.warnings[0]
    scanned = pm.match_pdf("x.pdf", [PdfPageText(0, 960, 540, [])], [report("r", "R", fps())])
    assert any("no text" in w for w in scanned.warnings)


def test_extra_pdf_pages_are_penalised():
    one = [report("r", "Report", fps()[:1])]
    first = pdf_page(0, "Cost Overview|Total Paid Claims Summary")
    base = pm.match_pdf("r.pdf", [first], one)
    extra = pm.match_pdf("r.pdf", [first, pdf_page(1, "zzz"), pdf_page(2, "yyy")], one)
    assert extra.candidates[0].score < base.candidates[0].score
