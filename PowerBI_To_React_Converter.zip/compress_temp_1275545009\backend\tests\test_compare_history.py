"""Per-page comparison history: ids, path safety, retention, trend."""

from __future__ import annotations

import pytest

from app.services import compare_history as ch


def image_payload(sim, findings=()):
    return {
        "similarity": sim,
        "findings": list(findings),
        "filters_applied": [{"slicer": "Year", "value": 2024}],
    }


def values_payload(printed, matched, bad=0):
    return {
        "summary": {"numbers_printed": printed, "numbers_matched": matched, "mismatch": bad},
        "visuals": [],
    }


def test_run_ids_are_sortable_and_validated():
    a, b = ch.new_run_id(), ch.new_run_id()
    assert ch.RUN_ID.match(a) and ch.RUN_ID.match(b) and a != b
    for bad in (
        "",
        "../x",
        "20260101T000000-abcd",
        "20260101T000000000-ABCD",
        "20260101T000000000-abc",
    ):
        with pytest.raises(ch.HistoryError):
            ch.valid_run_id(bad)


@pytest.mark.parametrize(
    "bad", ["", "..", ".", "a/b", "a\\b", "a:b", "x" * 201, "a\x00b", "q?", 'q"']
)
def test_page_names_are_path_safe(bad):
    with pytest.raises(ch.HistoryError):
        ch.valid_page(bad)
    assert ch.valid_page("Page 1 (ok)") == "Page 1 (ok)"


def test_record_and_read_back_image_and_value_runs(tmp_path):
    f = {"fixable": True}, {"fixable": False}
    image = ch.record_run(
        tmp_path, "p1", "image", image_payload(0.8, f), {"reference": b"R", "rendered": b"X"}, "b1"
    )
    assert image["summary"] == {
        "similarity": 0.8,
        "findings": 2,
        "fixable": 1,
        "filters_applied": [{"slicer": "Year", "value": 2024}],
    }
    assert image["has_images"] == {"reference": True, "rendered": True} and "payload" not in image
    values = ch.record_run(tmp_path, "p1", "values", values_payload(10, 8, 1), None, "b1")
    assert values["summary"] == {
        "numbers_printed": 10,
        "numbers_matched": 8,
        "visuals_mismatched": 1,
        "filters_applied": [],
    }
    assert values["has_images"] == {"reference": False, "rendered": False}
    full = ch.load_run(tmp_path, "p1", image["run_id"])
    assert full["payload"]["similarity"] == 0.8 and full["batch_id"] == "b1"
    assert ch.run_image(tmp_path, "p1", image["run_id"], "reference") == b"R"
    assert ch.run_image(tmp_path, "p1", values["run_id"], "rendered") is None
    with pytest.raises(ch.HistoryError):
        ch.run_image(tmp_path, "p1", image["run_id"], "../x")
    with pytest.raises(ch.HistoryError):
        ch.record_run(tmp_path, "p1", "other", {})


def test_listing_is_newest_first_filterable_and_never_exposes_payloads(tmp_path):
    ids = [
        ch.record_run(tmp_path, "p", "image", image_payload(i / 10), None, "A" if i % 2 else "B")[
            "run_id"
        ]
        for i in range(4)
    ]
    listed = ch.list_runs(tmp_path, "p")
    assert [r["run_id"] for r in listed] == ids[::-1] and all("payload" not in r for r in listed)
    assert [r["run_id"] for r in ch.list_runs(tmp_path, "p", batch_id="A")] == [ids[3], ids[1]]
    assert len(ch.list_runs(tmp_path, "p", limit=2)) == 2
    assert (
        ch.list_runs(tmp_path, "missing") == []
        and ch.load_run(tmp_path, "p", "20200101T000000000-0000") is None
    )


def test_retention_keeps_the_newest_25_and_earlier_snapshots_survive_later_runs(tmp_path):
    first = ch.record_run(tmp_path, "p", "image", image_payload(0.1), {"reference": b"first"})
    for _ in range(ch.KEEP_RUNS):
        ch.record_run(tmp_path, "p", "image", image_payload(0.5))
    runs = ch.list_runs(tmp_path, "p")
    assert len(runs) == ch.KEEP_RUNS and first["run_id"] not in {r["run_id"] for r in runs}
    # below the cap an older run (and its images) is untouched by newer ones
    kept = ch.record_run(tmp_path, "q", "image", image_payload(0.2), {"reference": b"old"})
    ch.record_run(tmp_path, "q", "image", image_payload(0.9))
    assert ch.run_image(tmp_path, "q", kept["run_id"], "reference") == b"old"


def test_trend_is_oldest_first_with_similarity_or_number_percentages(tmp_path):
    ch.record_run(tmp_path, "p", "image", image_payload(0.6))
    ch.record_run(tmp_path, "p", "values", values_payload(4, 3))
    ch.record_run(tmp_path, "p", "values", values_payload(0, 0))
    ch.record_run(tmp_path, "p", "image", image_payload(0.9))
    t = ch.trend(tmp_path, "p")
    assert [(x["kind"], x["value"]) for x in t] == [
        ("image", 0.6),
        ("values", 75.0),
        ("values", None),
        ("image", 0.9),
    ]
    assert len(ch.trend(tmp_path, "p", limit=2)) == 2


def test_history_is_invisible_to_the_visual_compare_json_glob(tmp_path):
    ch.record_run(tmp_path, "p", "image", image_payload(0.5))
    assert list((tmp_path / "visual_compare").glob("*.json")) == []


def test_batch_runs_span_pages(tmp_path):
    ch.record_run(tmp_path, "a", "image", image_payload(0.5), None, "B1")
    ch.record_run(tmp_path, "b", "values", values_payload(1, 1), None, "B1")
    ch.record_run(tmp_path, "b", "values", values_payload(1, 0), None, "B2")
    assert {(r["page"], r["kind"]) for r in ch.batch_runs(tmp_path, "B1")} == {
        ("a", "image"),
        ("b", "values"),
    }
    assert ch.pages_with_history(tmp_path) == ["a", "b"]
