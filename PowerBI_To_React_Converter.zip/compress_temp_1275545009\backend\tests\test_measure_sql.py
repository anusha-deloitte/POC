"""Phase 08: Fix measure (hand-written measure SQL) and the DAX Audit overlay."""

from __future__ import annotations

import datetime

import pytest

from app.services.compilation_logger import CompilationLogger
from tests.phase08 import BAR, CARD, LINE, World
from tests.test_api import client  # noqa: F401

NATIVE = (
    'SELECT SUM("Sales"."SalesAmount") FROM CONTOSO.SALES.FACT_SALES AS "Sales" WHERE {{filters}}'
)


@pytest.fixture()
def world(client, contoso_pbip, monkeypatch):  # noqa: F811
    w = World(client, contoso_pbip, monkeypatch)
    w.park_measure(dax="FOOBAR(1)")
    w.responder = lambda sql: (["v"], [(100.0,)])
    return w


def _test(world, sql=NATIVE, measure="Total Sales"):
    return world.post(
        "measure-sql/test", {"measure": measure, "sql": sql, "connection_id": world.conn_id}
    )


def _save(world, sql=NATIVE, measure="Total Sales"):
    return world.client.put(world.url("measure-sql"), json={"measure": measure, "sql": sql})


def _panes(world):
    return {
        v["name"]: v for p in world.get("spec").json()["pages"] for v in p["visuals"]
    }


def test_check_reports_the_impact_and_runs_the_fixed_panes(world):
    r = _test(world)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["ok"] is True and body["measure"] == "Total Sales"
    assert body["measure_run"]["value"] == 100.0 and body["measure_run"]["error"] is None
    assert body["measure_run"]["query_id"] and "1=1" in body["measure_run"]["sql"]
    assert "Total Sales" in body["newly_translated"]
    assert "Average Price" in body["newly_translated"]  # a dependent
    assert [p["visual"] for p in body["fixed_panes"]] == [CARD]
    assert [p["visual"] for p in body["not_applicable"]] == [BAR]  # groups by rows
    still = {p["visual"]: p for p in body["still_untranslated"]}
    assert "hand-written SQL" in still[LINE]["reason"] and "Sales LY" in still[LINE]["reason"]
    assert "Sales LY" in body["still_untranslated_measures"]
    (run,) = body["pane_runs"]
    assert run["visual"] == CARD and run["rows"] == 1 and run["error"] is None
    assert run["query_id"] and body["panes_not_run"] == 0
    assert body["null_comparison_warnings"] == []
    # the run is audited as a setup query
    setup = world.get("query-audit", kind="setup").json()["records"]
    assert any(r["check"] == "measure_sql_test:Total Sales" for r in setup)


def test_one_number_rule(world):
    world.responder = lambda sql: (["a"], [(1,), (2,)])
    body = _test(world).json()
    assert body["ok"] is False
    assert body["measure_run"]["error"] == (
        "must return exactly one row with one column (got 2 row(s), 1 column(s))"
    )
    world.responder = lambda sql: (["a", "b"], [(1, 2)])
    assert "got 1 row(s), 2 column(s)" in _test(world).json()["measure_run"]["error"]
    world.responder = lambda sql: (["a"], [(datetime.date(2024, 1, 1),)])
    body = _test(world).json()
    assert body["measure_run"]["error"] == "must return a number or text (got date)"
    assert body["pane_runs"] == [] and body["ok"] is False
    world.responder = lambda sql: (["a"], [(True,)])
    assert "got boolean" in _test(world).json()["measure_run"]["error"]


def test_text_values_are_accepted(world):
    world.responder = lambda sql: (["a"], [("high",)])
    body = _test(world).json()
    assert body["measure_run"]["value"] == "high"
    assert body["ok"] is True


def test_failing_pane_makes_the_check_fail(world):
    def responder(sql):
        if "SUM(" in sql and sql.lstrip().startswith("SELECT SUM"):
            return ["v"], [(1.0,)]
        raise RuntimeError("pane exploded")

    world.responder = responder
    body = _test(world).json()
    assert body["measure_run"]["error"] is None and body["ok"] is False
    assert body["pane_runs"][0]["error"] == "pane exploded"
    assert _save(world).status_code == 409


def test_warns_about_null_comparisons(world):
    body = _test(world, sql="SELECT 1 WHERE x <> NULL").json()
    assert any("IS NOT NULL" in w for w in body["null_comparison_warnings"])


def test_rejections(world):
    assert _test(world, sql="DROP TABLE x").status_code == 422
    assert _test(world, measure="Nope").status_code == 404
    assert _save(world, measure="Nope").status_code == 404


def test_save_needs_a_passing_check_of_the_exact_text(world):
    r = _save(world)
    assert r.status_code == 409
    assert "run 'Check on Snowflake' on this exact SQL before saving" in r.text
    assert _test(world).json()["ok"] is True
    changed = NATIVE.replace("SalesAmount", "Quantity")
    assert _save(world, sql=changed).status_code == 409
    saved = _save(world)
    assert saved.status_code == 200, saved.text
    fix = saved.json()["fix"]
    assert fix["sql"] == NATIVE and fix["original"] == "FOOBAR(1)" and fix["saved_at"]
    assert fix["checked"]
    assert _save(world).status_code == 409  # the remembered check was consumed
    assert list(world.get("measure-sql").json()["fixes"]) == ["Total Sales"]


def test_fixed_measure_and_dependents_use_the_sql_and_filters_reach_it(world):
    assert _test(world).json()["ok"]
    _save(world)
    assert _panes(world)[CARD]["supported"] is True
    slicer = [{"table": "Sales", "column": "Quantity", "values": [3], "source": "slicer"}]
    result = world.query(CARD, filters=slicer).json()["results"][0]
    assert result["error"] is None
    assert 'SELECT SUM("Sales"."SalesAmount")' in result["sql"]
    assert '"Sales"."Quantity"' in result["sql"]  # {{filters}} was rendered
    assert "{{" not in result["sql"]
    # a dependent measure compiles through it too
    compiled = world.get("spec").json()
    assert compiled["measure_tiers"]["Average Price"] >= 0


def test_grouping_is_refused_with_the_reason(world):
    _test(world)
    _save(world)
    result = world.query(BAR).json()["results"][0]
    assert "hand-written SQL" in result["error"] and "one value per query" in result["error"]


def test_revert_restores_the_untranslated_state(world):
    _test(world)
    _save(world)
    gone = world.client.delete(world.url("measure-sql/Total Sales"))
    assert gone.json() == {"reverted": "Total Sales", "remaining": []}
    assert _panes(world)[CARD]["supported"] is False
    again = world.client.delete(world.url("measure-sql/Total Sales"))
    assert again.status_code == 404


def test_dax_audit_shows_the_fix(world):
    root = world.root
    log = CompilationLogger(root)
    log.initialize_for_conversion(world.cid)
    for name, dax in (("Total Sales", "FOOBAR(1)"), ("Total Quantity", "FOOBAR(2)")):
        rec = log.start_record("Sales", name, dax)
        log.fail_record(rec, "function FOOBAR not in tier-1 set", "parked", 1.0)
    before = world.get("compilation-audit")
    assert before.status_code == 200, before.text
    rows = {r["measure_name"]: r for r in before.json()["records"]}
    assert rows["Total Sales"]["overall_status"] == "broken"
    # a measure that compiles now is shown working: Total Quantity's real DAX is fine
    assert rows["Total Quantity"]["overall_status"] == "working"
    assert _test(world).json()["ok"]
    _save(world)
    after = world.get("compilation-audit").json()
    fixed = {r["measure_name"]: r for r in after["records"]}["Total Sales"]
    assert fixed["compiler_type"] == "manual_sql" and fixed["overall_status"] == "working"
    assert after["summary"]["by_compiler_type"].get("manual_sql") == 1
    xlsx = world.get("compilation-audit/export", format="xlsx")
    assert xlsx.status_code == 200 and "spreadsheetml" in xlsx.headers["content-type"]
    js = world.get("compilation-audit/export", format="json").json()
    assert js["kind"] == "dax_compilation_audit" and len(js["records"]) == 2


def test_dax_audit_404_without_logs(world):
    r = world.get("compilation-audit")
    assert r.status_code == 404 and "no compilation logs found" in r.text
