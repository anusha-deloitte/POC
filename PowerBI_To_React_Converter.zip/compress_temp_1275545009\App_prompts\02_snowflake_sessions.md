# Phase 02 - Snowflake connections and sessions (MFA, warehouse/role, live status, SSO URL)

## Purpose
Make Snowflake sign-in robust: required warehouse, role/warehouse applied on the cached session
without re-signing in, MFA (TOTP) for password logins, a live "is my session still valid" check,
a forced re-sign-in, editable warehouse/role, and a visible SSO link when the browser doesn't open.

## Current target state
- `services/connections.py`: `AuthMethod` (password, key_pair, oauth_client_credentials, pat,
  external_browser), `SnowflakeProfile`, `ConnectionStore` (JSON record per profile under the storage
  dir, secrets Fernet-encrypted). Warehouse is optional.
- `services/snowflake_sessions.py`: `SnowflakeSessionManager` with `authenticate`, `lease`, `status`
  (`{"authenticated": bool}`), logout; external browser supported, no MFA, no settings handling.
- `api/connections.py`: list/create/delete/test/session/logout. No PATCH.
- `frontend/src/steps/ConnectStep.tsx`: `AUTH_LABELS` defined inline; session status only for
  external browser.

## Required behaviour - backend

### 1. Warehouse identifier and required warehouse (`services/connections.py`)
1.1 `warehouse_identifier(name) -> str`: strip; if it matches `^[A-Za-z_][A-Za-z0-9_$]*$` (plain,
left unquoted so Snowflake resolves case-insensitively) or `^"[^"]+"$` (explicitly quoted, kept
exact) return it; else `ValueError("invalid warehouse name: '<name>'")`. Used for `USE WAREHOUSE`
and `USE ROLE`.
1.2 Creating a profile requires a warehouse: `_validated_warehouse` -> `ConnectionValidationError
("warehouse is required")` when empty, or the ValueError message when invalid. Role is stripped,
empty -> None. There is NO fallback warehouse anywhere.
1.3 `SnowflakeProfileUpdate` (pydantic): optional `name, role, warehouse, database, schema_name`
(alias `schema`, `populate_by_name`). `ConnectionStore.update(id, patch)`: only fields that were set
(`exclude_unset`) change; warehouse validated as 1.2; role/database/schema/name stripped, empty ->
None; empty name -> `ConnectionValidationError("name cannot be empty")`; secrets untouched; record
rewritten in place.
1.4 `ConnectionStore.mfa_enforced(id) -> bool` (record key `mfa_enforced`, False on missing/unknown)
and `set_mfa_enforced(id, enforced)` (writes only on change).

### 2. Session manager (`services/snowflake_sessions.py`)
2.1 New exceptions: `SnowflakeMfaRequired(SnowflakeAuthenticationRequired)` and
`SnowflakeWarehouseError(RuntimeError)`.
2.2 `_apply_session_settings(conn, role, warehouse)`: on a cursor, `USE ROLE <ident>` if role (failure
-> `SnowflakeWarehouseError("role X could not be activated for this user: <err>")`), then
`USE WAREHOUSE <ident>`; failure -> `SnowflakeWarehouseError("signed in, but warehouse W could not
be activated (role R|default): <err>.<hint>")` where hint lists up to 15 names from `SHOW WAREHOUSES`
("Warehouses this role can use: a, b.") or "Set a role that has USAGE on it, or pick another warehouse."
2.3 Manager state per profile: `_applied: {profile: (role, warehouse)}`, `_settings_errors`,
`_mfa_profiles` (set), `_sso_urls`, `_query_tags: {profile: (id(conn), tag)}`.
2.4 `_ensure_settings(profile, conn)`: read the profile's role/warehouse; empty warehouse ->
`ValueError("connection '<name>' has no warehouse; edit the connection and set one")`; skip if
`_applied[profile] == (role, wh)`; else apply; on `SnowflakeWarehouseError` drop `_applied`, store
the message in `_settings_errors`, log `snowflake_session_settings_failed`, re-raise. The
authenticated session stays cached either way (the user fixes the setting, no new SSO sign-in).
2.5 `settings_changed(profile)`: drop `_applied` and `_settings_errors` (re-applied on next lease).
`settings_error(profile)` returns the stored message.
2.6 MFA: passcode regex `^\d{6,8}$`; MFA error regex `\b394508\b|MFA with TOTP|TOTP passcode`
(case-insensitive). `_is_mfa(profile)`: in `_mfa_profiles` or `store.mfa_enforced(profile)`.
`_remember_mfa(profile, enforced)` updates the set and persists via `set_mfa_enforced` (log a
warning if saving fails, never raise).
2.7 `_connect(profile, query_tag, passcode=None)`:
- passcode given for a non-password profile -> `ValueError("an MFA passcode only applies to username & password logins")`;
  invalid format -> `ValueError("MFA passcode must be the 6-8 digit code from your authenticator")`;
  else `kwargs["passcode"] = passcode.strip()`.
- password profile with a passcode or known MFA -> `authenticator="username_password_mfa"` (the
  connector caches an MFA token when the account allows it).
- missing warehouse -> the ValueError of 2.4, checked BEFORE connecting (no wasted SSO round trip).
- connect with `login_timeout=120, network_timeout=30`; external browser goes through
  `_connect_via_browser` (2.8).
- after a successful password sign-in: `_remember_mfa(profile, used_mfa_authenticator)` (a plain
  password sign-in proves MFA isn't enforced).
- on an error matching the MFA regex for a password profile: `_remember_mfa(True)` and raise
  `SnowflakeMfaRequired("Snowflake requires MFA for this user: enter the current 6-digit code from
  your authenticator app and sign in again" + (" (the code was rejected or expired)" if passcode))`.
2.8 `_connect_via_browser`: temporarily replace `webbrowser.open_new` and `webbrowser.open` with a
capture function that records the SSO URL in `_sso_urls[profile]` (once per URL), logs
`snowflake_sso_url`, prints `[pbic] Snowflake SSO sign-in URL (profile <id>): <url>` to stderr, then
calls the real `open_new` with both functions restored around the call (avoid recursion), re-patching
afterwards. Always restore both and pop `_sso_urls[profile]` in `finally`.
2.9 `authenticate(profile, query_tag="pbic:authenticate", passcode=None, force=False)`: if a session
is open and not `force`: `_ensure_settings` and return it. Else connect (passcode passed through);
the new connection replaces the old one only on success; reset `_applied`; then `_ensure_settings`
(raise its error but keep the session).
2.10 `lease(...)`: when a new connection is created, reset `_applied` and record the query tag; when
the tag differs from `_query_tags[profile]`, run `ALTER SESSION SET QUERY_TAG` and record it (skip
the round trip when unchanged); always `_ensure_settings` before yielding.
2.11 `status(profile, verify=False) -> dict`:
- if `_sso_urls[profile]` is set (checked BEFORE taking the profile lock, since a browser connect
  holds it), return `{"authenticated": False, "sso_url": url}`.
- `verify=True` and a cached open session: run `SELECT 1` (bounded by network_timeout); on failure
  evict the session, `authenticated=False, expired=True, reason=str(e)[:300]`, log
  `snowflake_session_check_failed`. Never signs in.
- result: `authenticated`, `sso_url`, `settings_error` (only when authenticated), `mfa_required`
  (`not authenticated and _is_mfa`). Only with verify, add `mfa_enforced`, `verified`, `checked_at`
  (epoch seconds), `expired`, `reason`. Without verify the response has no extra keys.
2.12 Logout/evict also clears `_applied` and `_settings_errors` for the profile.

### 3. API (`api/connections.py`)
3.1 `PATCH /api/v1/connections/{id}` body `SnowflakeProfileUpdate` -> the updated profile;
404 on unknown id, 422 on `ConnectionValidationError`; then `sessions.settings_changed(id)`
(keeps the signed-in session).
3.2 `POST /connections/{id}/test` optional body `ConnectionTestRequest {passcode?: str, force: bool=false}`
(empty passcode -> None). `SnowflakeMfaRequired` -> `{"ok": false, "error": msg, "mfa_required": true}`.
Every outcome (ok or error) is logged as `snowflake_connection_test` with profile id, ok, error,
configured warehouse, and role/warehouse/database from the result. Existing error mapping kept.
3.3 `GET /connections/{id}/session?verify=false|true` -> `status(id, verify=verify)`.
3.4 `SnowflakeWarehouseError` anywhere -> HTTP 422 `{"detail": msg}` (handler in `main.py`, phase 01).

## Required behaviour - frontend
4.1 `src/components/snowflakeAuth.ts`: export `AUTH_LABELS: Record<AuthMethod,string>`
(key_pair "Key pair (JWT) — recommended", external_browser "External browser (SSO)", password
"Username & password", oauth_client_credentials "OAuth client credentials", pat "Programmatic access
token"). ConnectStep imports it (remove its inline copy).
4.2 `src/components/MfaPasscodePrompt.tsx` props `{required=true, label?, pending, error?, onSubmit(code), onCancel?}`:
`data-testid="mfa-prompt"`; amber styling when required, neutral otherwise; default text
"Snowflake requires MFA: enter the current code from your authenticator app." / "MFA code (if your
account requires it)"; numeric input (`aria-label="MFA code"`, `autoComplete="one-time-code"`,
maxLength 8, non-digits stripped); Enter or "Sign in" submits only when `/^\d{6,8}$/` and not pending,
then clears; button text "Signing in…" while pending; optional "Cancel"; error in `role="alert"`.
The wrapper calls `preventDefault` on click (it sits inside a radio `<label>`), the input/button stop propagation.
4.3 `api/client.ts`: `updateConnection(id, patch)` (PATCH); `testConnection(id, passcode?, {force?})`
sends a JSON body only when it has keys; `connectionSession(id, {verify?})` adds `?verify=true`.
Types: `ConnectionTestResult.mfa_required?`, `ConnectionUpdate`, `ConnectionSessionStatus` gains
`sso_url, settings_error, mfa_required, mfa_enforced, verified, checked_at, expired, reason`;
`ConnectionProfile.warehouse` is required (string).
4.4 Saved-connection row in ConnectStep (target panel):
- shows ` · WH <warehouse>` and ` · role <role>` after the account.
- session query for every connection: `connectionSession(id, {verify: !authenticate.isPending})`,
  polling every 1.5 s only while a sign-in is pending and no `sso_url` yet.
- `ready = hasWarehouse && !settingsError && !needsMfa && (!usesBrowser || authenticated)` where
  `needsMfa = password && !signedIn && (mfa_required || mfa_enforced || last test mfa_required)`.
- `SessionStatusLine` (`data-testid="session-status"`, when the profile has a warehouse): "Checking
  session…" while fetching; "Session active · checked HH:MM" (green) when authenticated; "Session
  expired — enter your MFA code to sign in again" / "Session expired — sign in again" (amber) when
  expired; "Not signed in — MFA required" (amber); "Not signed in"; "Session status unknown";
  `title` = reason; a "Check again" link (refetch) when not fetching.
- `settings_error` shown in red (`role="alert"`).
- `ConnectionSettingsEditor`: link "Edit warehouse / role"; forced open (with "Warehouse required —
  set it to use this connection.") when the warehouse is missing or there is a settings error;
  inputs `aria-label` Warehouse / Role; the warehouse pre-fills from source hints (phase 05:
  `GET /conversions/{id}/source-hints` `warehouse`) when empty; Save (disabled when empty) PATCHes,
  invalidates `['connections']` and the session query, then re-runs `authenticate({})`.
- password profiles, signed out: `MfaPasscodePrompt required={needsMfa}` -> `authenticate({passcode})`.
- password profiles, signed in: link "Re-enter MFA code" -> prompt with label "Sign in again with a
  new MFA code (the current session stays until it succeeds)", `required=false`, Cancel ->
  `authenticate({passcode, force: true})`; closes on success.
- external browser pending with `sso_url`: link "Browser didn't open? Click here to sign in".
4.5 New-connection form: Warehouse field required (label "Warehouse"), pre-filled from source hints
with "Pre-filled from the report's Power Query (<wh>)."; password method gets an "MFA code (if your
account requires it)" field ("Used once to sign in; never saved."), sent with the first test then
cleared; when the test returns `mfa_required` show `MfaPasscodePrompt` for the created profile; while
an external-browser test is pending poll the session and show "Browser didn't open? Click here to
sign in to Snowflake" with the SSO URL; the "continue" condition also requires `!mfa_required`.
4.6 `auth.ts` (app login/signup): `authRequest(path, payload, fallback)` reads the body as text and
decodes JSON safely; network failure or a 5xx with an empty/non-JSON body -> error
`API_UNREACHABLE = 'The API server is not reachable. Start it with ./start.ps1 (see logs/api.err.log).'`;
`detail` is shown when present; a 2xx without token/user -> API_UNREACHABLE. login/signup use it.

## Files
Create: `frontend/src/components/MfaPasscodePrompt.tsx`, `frontend/src/components/snowflakeAuth.ts`.
Modify: `backend/app/services/connections.py`, `backend/app/services/snowflake_sessions.py`,
`backend/app/api/connections.py`, `backend/app/main.py`, `frontend/src/steps/ConnectStep.tsx`,
`frontend/src/api/client.ts`, `frontend/src/api/types.ts`, `frontend/src/auth.ts`.

## Tests
Backend (`tests/test_snowflake_sessions.py`, fake connector/cursors, no network):
- warehouse required on create; PATCH validates, keeps secrets, calls `settings_changed`.
- `warehouse_identifier` accepts plain/quoted, rejects `a b`, `x;drop`.
- role/warehouse failure raises `SnowflakeWarehouseError` (422 through the API) but the session stays
  cached; after PATCH the next lease re-applies.
- MFA: error 394508 -> `SnowflakeMfaRequired`, profile flagged and persisted; passcode sign-in uses
  `username_password_mfa`; plain password sign-in clears the flag; invalid passcode format rejected.
- `status(verify=True)`: SELECT 1 success -> verified + checked_at; failure -> expired, reason,
  session evicted; without verify only the base keys.
- `test {"force": true}` signs in again while a session is open; the old session survives a failed attempt.
- query tag set once per (connection, tag).
- SSO URL captured and returned by `status` while connecting; patches restored afterwards.
Frontend (`src/test/ConnectStep.test.tsx`, mocked API): status line texts; missing warehouse forces
the editor open and Save PATCHes; MFA prompt appears for MFA-required and submits the code;
"Re-enter MFA code" sends `force: true`; SSO link shown while pending.

## Done criteria
All tests above pass; existing ConnectStep tests still pass (update them only where the new
required warehouse changes their fixtures).
 