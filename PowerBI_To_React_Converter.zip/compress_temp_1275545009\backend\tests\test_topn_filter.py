"""TOPN as a CALCULATE filter (phase 06.7) and its tie behaviour."""

from __future__ import annotations

import pytest

from app.dax.compiler import DaxUnsupported
from app.runtime.engine import DimensionRef, FilterClause, MeasureRefSpec, QueryPlanError, QuerySpec
from tests.duck import DuckWorld

RANK = 'ADDCOLUMNS(SUMMARIZE(Product, Product[Name]), "x", CALCULATE(SUM(Sales[Amt])))'


def top(n, order="DESC", wrapper=None):
    table = f"TOPN({n}, {RANK}, [x], {order})"
    return wrapper.format(table) if wrapper else table


def world(extra: dict[str, str] | None = None, product_rows=None) -> DuckWorld:
    return DuckWorld(
        {
            "Product": (
                ["Id", "Name"],
                product_rows or [(1, "a"), (2, "b"), (3, "c"), (4, "d")],
            ),
            "Sales": (
                ["ProdId", "Region", "Amt"],
                [(1, "N", 10.0), (1, "N", 10.0), (2, "E", 15.0), (3, "E", 15.0), (4, "E", 5.0)],
            ),
            "Other": (["V"], [(7.0,), (8.0,)]),
        },
        rels=[("Sales", "ProdId", "Product", "Id")],
        measures={
            "Total": "SUM(Sales[Amt])",
            "Top1": f"CALCULATE([Total], {top(1)})",
            "Top2": f"CALCULATE([Total], {top(2)})",
            "Bottom1": f"CALCULATE([Total], {top(1, 'ASC')})",
            **(extra or {}),
        },
        measure_table="Sales",
    )


def test_top_item():
    assert world().value("Top1") == 20.0


def test_ties_are_kept():
    # a = 20, b = c = 15: the second rank is shared, both b and c stay
    assert world().value("Top2") == 20.0 + 15.0 + 15.0


def test_ascending_order():
    assert world().value("Bottom1") == 5.0


def test_var_is_not_refiltered_but_inline_table_is():
    w = world(
        {
            "VarForm": f"VAR t = {top(1)} RETURN CALCULATE([Total], CALCULATETABLE(t, Sales[Region] = \"E\"))",
            "Inline": f'CALCULATE([Total], CALCULATETABLE({top(1)}, Sales[Region] = "E"))',
        }
    )
    assert w.value("VarForm") == 20.0  # the VAR was evaluated where it is defined
    assert w.value("Inline") == 15.0 + 15.0  # re-ranked among region E: b and c tie


def test_table_var_defined_outside_calculate():
    w = world({"ViaVar": f"VAR t = {top(1)} RETURN CALCULATE([Total], t)"})
    assert w.value("ViaVar") == 20.0


def test_slicer_on_the_key_is_replaced_by_the_top_set():
    w = world()
    flt = [FilterClause(table="Product", column="Name", op="not_in", values=["a"])]
    assert w.value("Top1", filters=flt) == 30.0  # ranked among b, c, d: b and c tie


def test_per_row_ranking_is_refused():
    w = world()
    with pytest.raises(QueryPlanError, match="re-ranked"):
        w.run(
            QuerySpec(
                dimensions=[DimensionRef(table="Sales", column="Region")],
                measures=[MeasureRefSpec(name="Top1")],
            )
        )


def test_unsupported_shapes_are_named():
    w = world(
        {
            "NoAdd": "CALCULATE([Total], TOPN(2, SUMMARIZE(Product, Product[Name]), Product[Name]))",
            "WrongOrder": f"CALCULATE([Total], TOPN(1, {RANK}, CALCULATE(SUM(Sales[Amt]))))",
            "NotLiteral": f"CALCULATE([Total], TOPN([Total], {RANK}, [x]))",
        }
    )
    for name in ("NoAdd", "WrongOrder", "NotLiteral"):
        with pytest.raises((DaxUnsupported, QueryPlanError), match="TOPN"):
            w.value(name)


def test_under_a_time_shift_is_refused():
    w = world({"Shifted": "CALCULATE([Top1], SAMEPERIODLASTYEAR(Product[Name]))"})
    with pytest.raises((DaxUnsupported, QueryPlanError)):
        w.value("Shifted")


def test_key_set_is_a_top_level_cte():
    w = world()
    _, _, sql = w.run_full(QuerySpec(measures=[MeasureRefSpec(name="Top1")]))
    assert sql.startswith('WITH "__topn0" AS (')
    assert "QUALIFY RANK() OVER" in sql
    assert sql.count('"__topn0" AS (') == 1


# ------------------------------------------------------------------ ties


def test_all_ties_keep_every_row_and_firstnonblank_is_the_first():
    unrelated = (
        'ADDCOLUMNS(SUMMARIZE(Product, Product[Name]), "x", CALCULATE(SUM(Other[V])))'
    )
    w = world(
        {
            "First": f"CALCULATE(FIRSTNONBLANK(Product[Name], 1), TOPN(1, {unrelated}, [x], DESC))",
            "Count": f"CALCULATE(COUNTROWS(Product), TOPN(1, {unrelated}, [x], DESC))",
        }
    )
    assert w.value("First") == "a"
    assert w.value("Count") == 4  # nothing dropped: every key ties
    # an unrelated filter changes nothing
    assert w.value("Count", filters=[FilterClause(table="Other", column="V", values=[7.0])]) == 4


def test_blank_key_sorts_first_and_is_kept():
    unrelated = 'ADDCOLUMNS(SUMMARIZE(Product, Product[Name]), "x", CALCULATE(SUM(Other[V])))'
    w = world(
        {
            "First": f"CALCULATE(FIRSTNONBLANK(Product[Name], 1), TOPN(1, {unrelated}, [x], DESC))",
            "Count": f"CALCULATE(COUNTROWS(Product), TOPN(1, {unrelated}, [x], DESC))",
        },
        product_rows=[(1, None), (2, "b"), (3, "c"), (4, "d")],
    )
    assert w.value("First") is None  # BLANK sorts first
    assert w.value("Count") == 4


def test_summarize_over_filter_of_the_key_table():
    unrelated = (
        'ADDCOLUMNS(SUMMARIZE(FILTER(Product, Product[Id] > 1), Product[Name]), "x", '
        "CALCULATE(SUM(Other[V])))"
    )
    w = world(
        {"Count": f"CALCULATE(COUNTROWS(Product), TOPN(1, {unrelated}, [x], DESC))"}
    )
    assert w.value("Count") == 3  # ids 2..4 survive
