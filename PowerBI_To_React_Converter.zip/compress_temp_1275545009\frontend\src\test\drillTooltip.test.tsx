import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { chartPoint, rowPoint } from '../dashboard/dataPoint'
import { DashboardApp } from '../dashboard/DashboardApp'
import { clauseText, contextClauses, drillTargets, pointClauses } from '../dashboard/drillthrough'
import type { DashboardSpec, FilterClause, PageSpec, VisualSpec } from '../dashboard/types'

const pbir = { objects: {}, container_objects: {}, fields: [], sort: [], is_hidden: false, self_hidden: false }

function visual(name: string, over: Partial<VisualSpec> = {}): VisualSpec {
  return {
    name, visual_type: 'card', x: 0, y: 0, width: 300, height: 120, z: 1, supported: true,
    dim_keys: [], column_keys: [], series_keys: [], measure_keys: ['M'], measure_roles: {}, measure_formats: {},
    static_content: {}, sort: [], data_status: 'ok',
    query: { dimensions: [], measures: [{ name: 'M' }], filters: [], sort: [] }, pbir, ...over,
  } as VisualSpec
}

const table = visual('tbl', {
  visual_type: 'tableEx', dim_keys: ['Customer.Country'], y: 140, height: 160,
  query: { dimensions: [{ table: 'Customer', column: 'Country' }], measures: [{ name: 'M' }], filters: [], sort: [] },
})
const city = visual('city', {
  visual_type: 'slicer', dim_keys: ['Customer.City'], measure_keys: [], x: 320, width: 160, height: 60,
  slicer_target: { table: 'Customer', column: 'City' },
  query: { dimensions: [{ table: 'Customer', column: 'City' }], measures: [], filters: [], sort: [] },
})
const tipCard = visual('card1', { x: 320, y: 80, width: 160, tooltip_page: 'tip' })
const plainChart = visual('other', {
  visual_type: 'tableEx', dim_keys: ['Product.Category'], y: 320,
  query: { dimensions: [{ table: 'Product', column: 'Category' }], measures: [{ name: 'M' }], filters: [], sort: [] },
})

function pageOf(name: string, display: string, visuals: VisualSpec[], over: Partial<PageSpec> = {}): PageSpec {
  return { name, display_name: display, width: 800, height: 500, ordinal: 0, visuals, filters: [], ...over }
}

const regionCard = {
  name: 'region', scope: 'report', table: 'Customer', column: 'Region', display_name: 'Region', data_type: 'string',
  kind: 'basic', default: { join: 'and', conditions: [{ op: 'in', values: ['EU'], params: {} }] },
  require_single: false, hidden: false, locked: false, supported: true,
}

function makeSpec(): DashboardSpec {
  return {
    report_name: 'r',
    pages: [
      pageOf('p1', 'Page 1', [table, city, tipCard, plainChart]),
      pageOf('dt', 'Customer detail', [visual('dcard')], {
        is_hidden: true, page_type: 'Drillthrough',
        drillthrough: [{ table: 'Customer', column: 'Country' }],
      }),
      pageOf('tip', 'Tip', [visual('tcard')], { is_hidden: true, page_type: 'Tooltip', width: 300, height: 200 }),
    ],
    warnings: [], measure_tiers: { M: 0 }, theme: { data_colors: [], text_classes: {} },
    interaction_graph: { nodes: [], edges: [], sync_groups: {} }, bookmarks: [],
    drill_through: [{ page: 'dt', fields: ['Customer.Country'] }],
    report_filters: [regionCard],
  } as unknown as DashboardSpec
}

describe('drill targets and context', () => {
  const spec = makeSpec()

  it('a page is offered when the visual uses ANY of its drill-through fields', () => {
    expect(drillTargets(spec, table, 'p1').map((p) => p.name)).toEqual(['dt'])
    expect(drillTargets(spec, plainChart, 'p1')).toEqual([])
    expect(drillTargets(spec, tipCard, 'p1')).toEqual([])
    expect(drillTargets(spec, table, 'dt')).toEqual([]) // not the page it is on
    const measureTarget = { ...spec, pages: [...spec.pages, pageOf('m', 'M page', [], { drillthrough: [{ measure: 'M' }, { table: 'X', column: 'Y' }] })] }
    expect(drillTargets(measureTarget, tipCard, 'p1').map((p) => p.name)).toEqual(['m']) // a measure the visual uses
  })

  it('points: charts report category and series, rows report every dim', () => {
    const chart = { dim_keys: ['Product.Category', 'Customer.Country'], series_keys: ['Customer.Country'] }
    expect(chartPoint(chart, 'Bikes', 'DE')).toEqual({ 'Product.Category': 'Bikes', 'Customer.Country': 'DE' })
    expect(chartPoint(chart, '', '')).toEqual({}) // empty names are skipped
    expect(chartPoint({ dim_keys: ['A.x', 'A.y'], series_keys: [] }, 'v')).toEqual({ 'A.x': 'v' }) // first level only
    expect(rowPoint({ dim_keys: ['Customer.Country', 'Customer.City'] }, ['Customer.City', 'M', 'Customer.Country'], ['Oslo', 3, null])).toEqual({
      'Customer.City': 'Oslo',
      'Customer.Country': null,
    })
  })

  it('point clauses keep BLANK as NULL', () => {
    expect(pointClauses({ 'Customer.Country': 'France', 'Customer.City': null })).toEqual([
      { table: 'Customer', column: 'Country', values: ['France'] },
      { table: 'Customer', column: 'City', values: [null] },
    ])
  })

  it('"Keep all filters": the point, the source visual\'s filters except report filters, its own filters; tagged', () => {
    const request: FilterClause[] = [
      { table: 'Customer', column: 'Region', values: ['EU'], source: 'report_filter' },
      { table: 'Customer', column: 'City', values: ['Oslo'], source: 'slicer' },
      { table: 'Date', column: 'Year', values: [2024], source: 'page_filter' },
    ]
    const own = visual('v', { query: { dimensions: [], measures: [], sort: [], filters: [{ table: 'P', column: 'Cat', values: ['Bikes'], source: 'visual' }] } })
    const out = contextClauses(own, { 'Customer.Country': 'France' }, request, 'drillthrough')
    expect(out.map((f) => `${f.column}=${f.values[0]}`)).toEqual(['Country=France', 'City=Oslo', 'Year=2024', 'Cat=Bikes'])
    expect(out.every((f) => f.source === 'drillthrough')).toBe(true)
    expect(contextClauses(own, {}, [], 'tooltip').every((f) => f.source === 'tooltip')).toBe(true)
  })

  it('clause text reads like Power BI', () => {
    expect(clauseText({ table: 'C', column: 'Country', values: ['France'], op: 'in' })).toBe('Country is France')
    expect(clauseText({ table: 'C', column: 'Country', values: ['France'], op: 'not_in' })).toBe('Country is not France')
    expect(clauseText({ table: 'C', column: 'Country', values: [null] })).toBe('Country is (Blank)')
    expect(clauseText({ table: 'C', column: 'Country', values: [''] })).toBe('Country is (Blank)')
    expect(clauseText({ table: 'C', column: 'Name', values: ['x'], op: 'contains' })).toBe('Name contains x')
    expect(clauseText({ table: 'C', column: 'Name', values: [], op: 'is_blank' })).toBe('Name is blank')
    expect(clauseText({ table: 'C', column: 'Qty', values: [5], op: 'gte' })).toBe('Qty is greater than or equal to 5')
  })
})

type Query = { visual: string; page: string; filters: FilterClause[] }
let requests: { page: string; queries: Query[] }[] = []

function renderApp() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <DashboardApp conversionId="c1" connectionId="conn" />
    </QueryClientProvider>,
  )
}

const sentTo = (page: string) => requests.filter((r) => r.page === page)
const filterOf = (page: string, v: string) => sentTo(page).at(-1)?.queries.find((q) => q.visual === v)?.filters ?? []
const text = (f: FilterClause) => `${f.column}=${f.values[0]}${f.source ? `:${f.source}` : ''}`

describe('right-click drill-through and hover tooltips', () => {
  beforeEach(() => {
    requests = []
    class RO {
      observe() {}
      disconnect() {}
      unobserve() {}
    }
    vi.stubGlobal('ResizeObserver', RO)
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        const u = String(url)
        if (u.endsWith('/dashboard/spec')) return new Response(JSON.stringify(makeSpec()))
        if (u.endsWith('/dashboard/query')) {
          const body = JSON.parse(String(init?.body))
          requests.push({ page: body.queries[0].page, queries: body.queries })
          const results = body.queries.map((q: Query) => ({
            visual: q.visual,
            columns: q.visual === 'tbl' ? ['Customer.Country', 'M'] : q.visual === 'city' ? ['Customer.City'] : q.visual === 'other' ? ['Product.Category', 'M'] : ['M'],
            rows: q.visual === 'tbl' ? [['France', 1], ['Spain', 2]] : q.visual === 'city' ? [['Oslo'], ['Rome']] : q.visual === 'other' ? [['Bikes', 3]] : [[7]],
            warnings: [], elapsed_ms: 1, cached: false,
          }))
          return new Response(JSON.stringify({ results }))
        }
        return new Response(JSON.stringify({ available: false }))
      }),
    )
  })
  afterEach(() => vi.restoreAllMocks())

  async function rightClickRow(name: string) {
    const rows = await screen.findAllByTestId('table-row')
    const row = rows.find((r) => r.textContent?.includes(name))!
    await userEvent.hover(row)
    fireEvent.contextMenu(row)
    return row
  }

  it('right-click a table row -> Drill through -> the target page is queried with the row and its context', async () => {
    renderApp()
    const slicer = await screen.findByRole('combobox', { name: 'City' })
    await waitFor(() => expect(within(slicer).getByRole('option', { name: 'Oslo' })).toBeTruthy())
    await userEvent.selectOptions(slicer, 'Oslo')
    await rightClickRow('France')
    const menu = await screen.findByTestId('drill-menu')
    expect(within(menu).getByRole('menuitem', { name: /Drill through/ })).toBeTruthy()
    await userEvent.click(within(menu).getByRole('menuitem', { name: /Drill through/ }))
    const sub = screen.getByRole('menu', { name: 'Drill through' })
    await userEvent.click(within(sub).getByRole('menuitem', { name: 'Customer detail' }))
    await waitFor(() => expect(sentTo('dt').length).toBeGreaterThan(0))
    const filters = filterOf('dt', 'dcard').map(text)
    expect(filters).toContain('Country=France:drillthrough')
    expect(filters).toContain('City=Oslo:drillthrough')
    expect(filters).toContain('Region=EU:report_filter') // the report cards apply on every page
    expect(filters.filter((f) => f.startsWith('Region')).length).toBe(1) // ...and are not repeated by the context
    // the drill context is shown read-only in the Filters pane
    await userEvent.click(screen.getByTestId('filters-tab'))
    const section = screen.getByTestId('filters-section-drill')
    expect(section.textContent).toContain('Country is France')
    expect(section.textContent).toContain('City is Oslo')
  })

  it('any page change clears the drill context', async () => {
    renderApp()
    await rightClickRow('Spain')
    await userEvent.click(within(await screen.findByTestId('drill-menu')).getByRole('menuitem', { name: /Drill through/ }))
    await userEvent.click(screen.getByRole('menuitem', { name: 'Customer detail' }))
    await waitFor(() => expect(filterOf('dt', 'dcard').map(text)).toContain('Country=Spain:drillthrough'))
    await userEvent.click(screen.getByRole('button', { name: 'Page 1' }))
    await waitFor(() => expect(sentTo('p1').length).toBeGreaterThan(1))
    expect(filterOf('p1', 'tbl').some((f) => f.source === 'drillthrough')).toBe(false)
  })

  it('Escape closes the menu without drilling', async () => {
    renderApp()
    await rightClickRow('France')
    await screen.findByTestId('drill-menu')
    fireEvent.keyDown(document, { key: 'Escape' })
    expect(screen.queryByTestId('drill-menu')).toBeNull()
    expect(sentTo('dt')).toHaveLength(0)
  })

  it('no menu for a visual that drills nowhere (and the browser menu is left alone)', async () => {
    renderApp()
    const rows = await screen.findAllByTestId('table-row')
    const other = rows.find((r) => r.textContent?.includes('Bikes'))!
    await userEvent.hover(other)
    const notPrevented = fireEvent.contextMenu(other)
    expect(notPrevented).toBe(true)
    expect(screen.queryByTestId('drill-menu')).toBeNull()
    // a card (no categories) uses its whole container as the point but drills nowhere either
    expect(fireEvent.contextMenu(await screen.findByTestId('visual-card1'))).toBe(true)
    expect(screen.queryByTestId('drill-menu')).toBeNull()
  })

  it('a drill menu opening suppresses the browser menu', async () => {
    renderApp()
    const rows = await screen.findAllByTestId('table-row')
    const row = rows.find((r) => r.textContent?.includes('France'))!
    await userEvent.hover(row)
    expect(fireEvent.contextMenu(row)).toBe(false) // default prevented
  })

  it('hovering a card shows its tooltip page, queried with the card context', async () => {
    renderApp()
    const slicer = await screen.findByRole('combobox', { name: 'City' })
    await waitFor(() => expect(within(slicer).getByRole('option', { name: 'Rome' })).toBeTruthy())
    await userEvent.selectOptions(slicer, 'Rome')
    const card = await screen.findByTestId('visual-card1')
    await userEvent.hover(card)
    expect(screen.queryByTestId('tooltip-page')).toBeNull() // not before the 350 ms delay
    const tip = await screen.findByTestId('tooltip-page', {}, { timeout: 2000 })
    expect(tip.getAttribute('role')).toBe('tooltip')
    expect(tip.style.width).toBe('300px')
    expect(tip.style.height).toBe('200px')
    await waitFor(() => expect(sentTo('tip').length).toBeGreaterThan(0))
    const filters = filterOf('tip', 'tcard').map(text)
    expect(filters).toContain('City=Rome:tooltip')
    expect(filters).toContain('Region=EU:report_filter') // the report cards apply to the tooltip page too
    await userEvent.unhover(card)
    await waitFor(() => expect(screen.queryByTestId('tooltip-page')).toBeNull())
  })

  it('a visual without a tooltip page shows none', async () => {
    renderApp()
    const rows = await screen.findAllByTestId('table-row')
    await userEvent.hover(rows[0])
    await new Promise((r) => setTimeout(r, 500))
    expect(screen.queryByTestId('tooltip-page')).toBeNull()
  })

  it('an open drill menu hides the tooltip', async () => {
    renderApp()
    const card = await screen.findByTestId('visual-card1')
    await userEvent.hover(card)
    await screen.findByTestId('tooltip-page', {}, { timeout: 2000 })
    await rightClickRow('France')
    await screen.findByTestId('drill-menu')
    await waitFor(() => expect(screen.queryByTestId('tooltip-page')).toBeNull())
  })
})
