import { useState } from 'react'
import type { Bookmark } from './types'

/** Power BI's View > Bookmarks pane as a menu: every bookmark by display name; choosing one
 * applies it. */
export function BookmarksMenu({
  bookmarks,
  onApply,
  dark = false,
}: {
  bookmarks: Bookmark[]
  onApply: (bookmark: Bookmark) => void
  dark?: boolean
}) {
  const [open, setOpen] = useState(false)
  if (!bookmarks.length) return null
  return (
    <div className="relative">
      <button
        type="button"
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={() => setOpen(!open)}
        className={`rounded-[10px] border px-3 py-1.5 text-xs font-semibold ${
          dark
            ? 'border-white/10 text-white/70 hover:border-white/20 hover:bg-white/10 hover:text-white'
            : 'border-surface-300 text-surface-700 hover:bg-surface-100'
        }`}
      >
        Bookmarks
      </button>
      {open && (
        <ul
          role="menu"
          data-testid="bookmarks-menu"
          className="absolute right-0 z-50 mt-1 max-h-72 min-w-48 overflow-auto rounded-lg border border-surface-300 bg-white py-1 shadow-lg"
        >
          {bookmarks.map((b) => (
            <li key={b.name} role="none">
              <button
                role="menuitem"
                type="button"
                className="block w-full px-3 py-1.5 text-left text-xs text-surface-800 hover:bg-surface-100"
                onClick={() => {
                  onApply(b)
                  setOpen(false)
                }}
              >
                {b.display_name ?? b.name}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}
