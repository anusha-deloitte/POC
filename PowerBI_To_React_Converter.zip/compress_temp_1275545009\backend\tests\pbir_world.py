"""Synthetic PBIR reports for the phase 09-11 tests: the Contoso fixture plus whatever visuals,
page/report properties and files a test adds."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from app.parsers.bundle import load_pbip
from app.runtime.dashboard import compile_dashboard

FIXTURE = Path(__file__).resolve().parents[2] / "fixtures" / "contoso_sales"
PAGE = "overview01aa2bcc3dd4"


def lit(value) -> dict:
    return {"expr": {"Literal": {"Value": value}}}


def column(table: str, name: str) -> dict:
    return {"Column": {"Expression": {"SourceRef": {"Entity": table}}, "Property": name}}


def measure(table: str, name: str) -> dict:
    return {"Measure": {"Expression": {"SourceRef": {"Entity": table}}, "Property": name}}


def projection(field: dict, ref: str, native: str | None = None, **extra) -> dict:
    return {"field": field, "queryRef": ref, "nativeQueryRef": native or ref, **extra}


def visual_json(
    name: str,
    visual_type: str,
    *,
    x: float = 0,
    y: float = 0,
    z: float = 1,
    width: float = 200,
    height: float = 100,
    query_state: dict | None = None,
    objects: dict | None = None,
    container: dict | None = None,
    parent: str | None = None,
    hidden: bool = False,
    sort: list | None = None,
    filter_config: dict | None = None,
) -> dict:
    visual: dict = {"visualType": visual_type}
    if query_state:
        visual["query"] = {"queryState": query_state}
        if sort:
            visual["query"]["sortDefinition"] = {"sort": sort}
    if objects:
        visual["objects"] = objects
    if container:
        visual["visualContainerObjects"] = container
    if filter_config:
        visual["filterConfig"] = filter_config
    data: dict = {
        "name": name,
        "position": {"x": x, "y": y, "z": z, "width": width, "height": height},
        "visual": visual,
    }
    if parent:
        data["parentGroupName"] = parent
    if hidden:
        data["isHidden"] = True
    return data


def group_json(name: str, *, x=0, y=0, z=1, width=300, height=200, objects=None, parent=None,
               hidden=False) -> dict:  # fmt: skip
    data = {
        "name": name,
        "position": {"x": x, "y": y, "z": z, "width": width, "height": height},
        "visualGroup": {"displayName": name, "groupMode": "ScaleMode", "objects": objects or {}},
    }
    if parent:
        data["parentGroupName"] = parent
    if hidden:
        data["isHidden"] = True
    return data


class Report:
    """A writable copy of the Contoso fixture."""

    def __init__(self, tmp_path: Path, nested: bool = False):
        self.root = tmp_path / "upload"
        target = self.root / "inner" if nested else self.root
        shutil.copytree(FIXTURE, target)
        self.base = target
        self.report_dir = target / "Contoso Sales.Report"
        self.definition = self.report_dir / "definition"
        self.page_dir = self.definition / "pages" / PAGE

    def add_visual(self, data: dict, page: str = PAGE) -> None:
        vdir = self.definition / "pages" / page / "visuals" / data["name"]
        vdir.mkdir(parents=True, exist_ok=True)
        (vdir / "visual.json").write_text(json.dumps(data), encoding="utf-8")

    def remove_visuals(self, *names: str) -> None:
        for n in names:
            shutil.rmtree(self.page_dir / "visuals" / n, ignore_errors=True)

    def patch_json(self, path: Path, **updates) -> None:
        data = json.loads(path.read_text(encoding="utf-8"))
        data.update(updates)
        path.write_text(json.dumps(data), encoding="utf-8")

    def patch_page(self, page: str = PAGE, **updates) -> None:
        self.patch_json(self.definition / "pages" / page / "page.json", **updates)

    def patch_report(self, **updates) -> None:
        self.patch_json(self.definition / "report.json", **updates)

    def add_page(self, name: str, display: str, **extra) -> Path:
        pdir = self.definition / "pages" / name
        pdir.mkdir(parents=True)
        (pdir / "page.json").write_text(
            json.dumps({"name": name, "displayName": display, "width": 1280, "height": 720, **extra}),
            encoding="utf-8",
        )
        index = self.definition / "pages" / "pages.json"
        order = (
            json.loads(index.read_text(encoding="utf-8")).get("pageOrder", [PAGE])
            if index.is_file()
            else [PAGE]
        )
        index.write_text(json.dumps({"pageOrder": [*order, name]}), encoding="utf-8")
        return pdir

    def write_resource(self, name: str, data: bytes = b"\x89PNG-bytes") -> Path:
        path = self.report_dir / "StaticResources" / "RegisteredResources" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        return path

    def write_base_theme(self, name: str, data: dict) -> None:
        path = self.report_dir / "StaticResources" / "SharedResources" / "BaseThemes" / f"{name}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data), encoding="utf-8")

    def write_bookmark(self, name: str, state: dict, display: str | None = None, **options) -> None:
        bdir = self.definition / "bookmarks"
        bdir.mkdir(exist_ok=True)
        (bdir / f"{name}.bookmark.json").write_text(
            json.dumps(
                {"name": name, "displayName": display or name, "options": options,
                 "explorationState": state}
            ),
            encoding="utf-8",
        )
        index = bdir / "bookmarks.json"
        items = json.loads(index.read_text(encoding="utf-8"))["items"] if index.is_file() else []
        index.write_text(json.dumps({"items": [*items, {"name": name}]}), encoding="utf-8")

    def bundle(self):
        return load_pbip(self.root)

    def compile(self, tier2_sql=None):
        bundle = self.bundle()
        spec, _ = compile_dashboard(bundle, tier2_sql=tier2_sql)
        return bundle, spec

    def visual(self, spec, name: str, page: str = PAGE):
        return next(v for p in spec.pages if p.name == page for v in p.visuals if v.name == name)
