"""Combining subqueries, frames, sort columns, dimension-only tables, calculated columns (6.9/6.10)."""

from __future__ import annotations

import pytest

from app.runtime.engine import DimensionRef, FilterClause, MeasureRefSpec, QueryPlanError, QuerySpec
from tests.duck import DuckWorld


def facts_world(extra=None) -> DuckWorld:
    return DuckWorld(
        {
            "D": (["Id", "Name"], [(1, "a"), (2, "b"), (3, "c"), (4, "d")]),
            "F1": (["K", "Amt"], [(1, 10.0), (2, 20.0), (3, 30.0)]),
            "F2": (["K", "Qty"], [(2, 1.0), (3, 2.0), (3, 3.0), (4, 4.0)]),
            "F3": (["K", "V"], [(4, 100.0)]),
        },
        rels=[("F1", "K", "D", "Id"), ("F2", "K", "D", "Id"), ("F3", "K", "D", "Id")],
        measures={
            "Combo": "SUM(F1[Amt]) + SUM(F2[Qty])",
            "Three": "SUM(F1[Amt]) + SUM(F2[Qty]) + SUM(F3[V])",
            **(extra or {}),
        },
        measure_table="D",
    )


NAME = DimensionRef(table="D", column="Name")


def test_two_subqueries_full_outer_join_without_duplicate_cells():
    w = facts_world()
    rows = w.run(QuerySpec(dimensions=[NAME], measures=[MeasureRefSpec(name="Combo")]))
    assert rows == [("a", 10.0), ("b", 21.0), ("c", 35.0), ("d", 4.0)]


def test_three_subqueries_join_on_coalesced_keys():
    w = facts_world()
    rows = w.run(QuerySpec(dimensions=[NAME], measures=[MeasureRefSpec(name="Three")]))
    assert rows == [("a", 10.0), ("b", 21.0), ("c", 35.0), ("d", 104.0)]
    _, _, sql = w.run_full(QuerySpec(dimensions=[NAME], measures=[MeasureRefSpec(name="Three")]))
    assert "COALESCE(" in sql and "FULL OUTER JOIN" in sql


def test_all_blank_cells_are_dropped_with_several_subqueries():
    w = DuckWorld(
        {
            "D": (["Id", "Name"], [(1, "a"), (2, "b"), (3, "c")]),
            "F1": (["K", "Amt"], [(1, 10.0)]),
            "F2": (["K", "Qty"], [(2, None)]),
        },
        rels=[("F1", "K", "D", "Id"), ("F2", "K", "D", "Id")],
        types={("F2", "Qty"): "double"},
        measures={"A": "SUM(F1[Amt])", "Q": "SUM(F2[Qty])"},
        measure_table="D",
    )
    rows = w.run(
        QuerySpec(dimensions=[NAME], measures=[MeasureRefSpec(name="A"), MeasureRefSpec(name="Q")])
    )
    assert rows == [("a", 10.0, None)]  # b has a row but every measure is blank


def test_frame_drops_all_blank_cells_and_repeats_unreachable_dims():
    w = DuckWorld(
        {
            "D": (["Id", "Name"], [(1, "a"), (2, "b"), (4, "d")]),
            "Cat": (["Label"], [("x",), ("y",)]),
            "F1": (["K", "Amt"], [(1, 10.0), (2, 20.0)]),
        },
        rels=[("F1", "K", "D", "Id")],
        measures={"A": "SUM(F1[Amt])"},
        measure_table="D",
    )
    rows = w.run(
        QuerySpec(
            dimensions=[NAME, DimensionRef(table="Cat", column="Label")],
            measures=[MeasureRefSpec(name="A")],
        )
    )
    assert rows == [("a", "x", 10.0), ("a", "y", 10.0), ("b", "x", 20.0), ("b", "y", 20.0)]


def test_sort_column_that_is_not_one_to_one_does_not_duplicate_cells():
    w = DuckWorld(
        {
            "D": (["Id", "Name", "Ord"], [(1, "a", 2), (2, "a", 1), (3, "b", 3)]),
            "Cat": (["Label"], [("x",)]),
            "F1": (["K", "Amt"], [(1, 10.0), (2, 5.0), (3, 1.0)]),
        },
        rels=[("F1", "K", "D", "Id")],
        measures={"A": "SUM(F1[Amt])"},
        measure_table="D",
        sort_by={("D", "Name"): "Ord"},
    )
    rows = w.run(
        QuerySpec(
            dimensions=[NAME, DimensionRef(table="Cat", column="Label")],
            measures=[MeasureRefSpec(name="A")],
        )
    )
    assert rows == [("a", "x", 15.0), ("b", "x", 1.0)]


def test_sort_by_column_orders_axis():
    w = DuckWorld(
        {
            "D": (["Id", "Month", "Ord"], [(1, "Feb", 2), (2, "Jan", 1), (3, "Mar", 3)]),
            "F": (["K", "Amt"], [(1, 2.0), (2, 1.0), (3, 3.0)]),
        },
        rels=[("F", "K", "D", "Id")],
        measures={"A": "SUM(F[Amt])"},
        measure_table="D",
        sort_by={("D", "Month"): "Ord"},
    )
    rows = w.run(
        QuerySpec(
            dimensions=[DimensionRef(table="D", column="Month")], measures=[MeasureRefSpec(name="A")]
        )
    )
    assert [r[0] for r in rows] == ["Jan", "Feb", "Mar"]


# ----------------------------------------------------------------------- dimension only tables


def test_columns_only_table_returns_existing_combinations_through_relationships():
    w = DuckWorld(
        {
            "Sales": (["Id", "Key", "Region"], [(1, 1, "N"), (2, 1, "S"), (3, 2, "N")]),
            "Dim": (["Id", "Name"], [(1, "a"), (2, "b"), (3, "c")]),
        },
        rels=[("Sales", "Key", "Dim", "Id")],
    )
    spec = QuerySpec(
        dimensions=[
            DimensionRef(table="Sales", column="Region"),
            DimensionRef(table="Dim", column="Name"),
        ]
    )
    assert w.run(spec) == [("N", "a"), ("N", "b"), ("S", "a")]  # c has no sales: no combination
    filtered = spec.model_copy(
        update={"filters": [FilterClause(table="Dim", column="Name", values=["b"])]}
    )
    assert w.run(filtered) == [("N", "b")]
    single = QuerySpec(dimensions=[DimensionRef(table="Dim", column="Name")])
    assert [r[0] for r in w.run(single)] == ["a", "b", "c"]  # slicer domain unchanged


def test_columns_only_table_without_connecting_relationship_is_refused():
    w = DuckWorld(
        {"A": (["x"], [(1,)]), "B": (["y"], [(2,)])},
    )
    with pytest.raises(QueryPlanError, match="not connected"):
        w.run(
            QuerySpec(
                dimensions=[DimensionRef(table="A", column="x"), DimensionRef(table="B", column="y")]
            )
        )


# ----------------------------------------------------------------------- calculated columns


def calc_world() -> DuckWorld:
    return DuckWorld(
        {
            "Sales": (
                ["Id", "Region", "Inv", "Amount"],
                [(1, "N", 5, 10.0), (2, "S", 1, 5.0), (3, "n", 2, 7.0), (4, "E", 9, 1.0)],
            ),
            "Dim": (["Id", "Name"], [(1, "a")]),
        },
        measures={"Total": "SUM(Sales[Amount])"},
        calc_columns={
            "Sales": {
                "Big": 'IF(Sales[Amount] > 6, "big", "small")',
                "North": 'Sales[Region] in {"n"}',
                "Inv2": "IF(Sales[Inv] > 1, 1, 0)",
                "Chain": "Sales[Inv2] + 1",
                "Bad": "[Total] + 1",
            }
        },
    )


def test_calc_column_projected_grouped_and_filtered():
    w = calc_world()
    rows = w.run(
        QuerySpec(
            dimensions=[DimensionRef(table="Sales", column="Big")],
            measures=[MeasureRefSpec(name="Total")],
        )
    )
    assert rows == [("big", 17.0), ("small", 6.0)]
    f = w.value(
        "Total", filters=[FilterClause(table="Sales", column="Big", values=["small"])]
    )
    assert f == 6.0


def test_in_keyword_any_case_in_calc_column_and_calc_columns_chain():
    w = calc_world()
    assert w.value("CALCULATE(SUM(Sales[Amount]), Sales[North] = TRUE())") == 7.0
    rows = w.run(
        QuerySpec(
            dimensions=[DimensionRef(table="Sales", column="North")],
            measures=[MeasureRefSpec(name="Total")],
        )
    )
    # the lower-case `in` keyword parses; SQL string comparison stays case-sensitive
    assert dict(rows)[True] == 7.0
    chain = w.run(
        QuerySpec(
            dimensions=[DimensionRef(table="Sales", column="Chain")],
            measures=[MeasureRefSpec(name="Total")],
        )
    )
    assert dict(chain) == {2: 18.0, 1: 5.0}  # Chain = Inv2 + 1, inlined from another calc column


def test_distinct_count_of_calc_column():
    w = calc_world()
    assert w.value("DISTINCTCOUNT(Sales[Big])") == 2


def test_untranslatable_calc_column_fails_naming_column_and_reason():
    w = calc_world()
    with pytest.raises(QueryPlanError, match=r"Sales\[Bad\].*measure"):
        w.run(
            QuerySpec(
                dimensions=[DimensionRef(table="Sales", column="Bad")],
                measures=[MeasureRefSpec(name="Total")],
            )
        )
    assert w.value("Total") == 23.0  # queries that don't touch it are unaffected


def test_table_named_like_a_column_gets_an_internal_alias():
    w = DuckWorld(
        {
            "Region": (["Region", "Code"], [("N", 1), ("S", 2)]),
            "F": (["Code", "Amt"], [(1, 5.0), (2, 7.0)]),
        },
        rels=[("F", "Code", "Region", "Code")],
        measures={"Total": "SUM(F[Amt])"},
        measure_table="F",
    )
    rows, _, sql = w.run_full(
        QuerySpec(
            dimensions=[DimensionRef(table="Region", column="Region")],
            measures=[MeasureRefSpec(name="Total")],
        )
    )
    assert rows == [("N", 5.0), ("S", 7.0)]
    assert '"__t_Region"' in sql and 'AS "Region"' not in sql
    # de-aliasing is idempotent
    assert w.engine()._dealias(sql) == sql
