import { ptToPx } from '../pbi/fonts'
import type { VisualSpec } from '../types'

interface TextRun {
  value?: string
  textStyle?: { fontSize?: string; color?: string; fontWeight?: string; fontStyle?: string; textDecoration?: string }
}
interface Paragraph {
  textRuns?: TextRun[]
  horizontalTextAlignment?: string
}

/** Paragraphs of runs. Runs without a size use Power BI's default (12 pt); a visual without PBIR
 * keeps the legacy sizing. */
export function TextboxVisual({ spec }: { spec: VisualSpec }) {
  const paragraphs = (spec.static_content?.paragraphs ?? []) as Paragraph[]
  const pbi = !!spec.pbir
  return (
    <div
      data-testid="textbox"
      className="flex h-full w-full flex-col justify-center overflow-hidden px-2"
      style={pbi ? { justifyContent: 'flex-start' } : undefined}
    >
      {paragraphs.map((p, i) => (
        <p
          key={i}
          className={pbi ? 'leading-snug whitespace-pre-wrap' : 'truncate leading-tight'}
          style={{ textAlign: (p.horizontalTextAlignment?.toLowerCase() as React.CSSProperties['textAlign']) ?? undefined }}
        >
          {(p.textRuns ?? []).map((run, j) => {
            const size = run.textStyle?.fontSize ? parseFloat(run.textStyle.fontSize) : undefined
            return (
              <span
                key={j}
                style={{
                  fontSize: pbi
                    ? `${size !== undefined ? ptToPx(size) : ptToPx(12)}px`
                    : size !== undefined
                      ? `${size * 1.1}px`
                      : undefined,
                  color: run.textStyle?.color,
                  fontWeight: run.textStyle?.fontWeight as React.CSSProperties['fontWeight'],
                  fontStyle: run.textStyle?.fontStyle as React.CSSProperties['fontStyle'],
                  textDecoration: run.textStyle?.textDecoration,
                }}
              >
                {run.value}
              </span>
            )
          })}
        </p>
      ))}
    </div>
  )
}
