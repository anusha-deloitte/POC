import { useMutation, useQueryClient } from '@tanstack/react-query'
import { auditApi } from '../api/client'
import { useWizard } from '../store/wizard'

/** The server's sign-in requirement arrives as a JSON detail string. */
export function friendlyAuthMessage(message: string): string | null {
  if (!/snowflake_authentication_required|authentication/i.test(message)) return null
  try {
    const body = JSON.parse(message) as { message?: string }
    if (body.message) return body.message
  } catch {
    /* plain text */
  }
  return 'Sign in to Snowflake again, then re-check.'
}

export function RecheckButton({
  page,
  visual,
  compact = false,
  onDone,
}: {
  page: string
  visual: string
  compact?: boolean
  onDone?: () => void
}) {
  const conversionId = useWizard((s) => s.conversionId)
  const connectionId = useWizard((s) => s.connectionId)
  const queryClient = useQueryClient()
  const recheck = useMutation({
    mutationFn: () => auditApi.recheck(conversionId!, { page, visual, connection_id: connectionId! }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['fidelity', conversionId] })
      await queryClient.invalidateQueries({ queryKey: ['query-audit', conversionId] })
      onDone?.()
    },
  })
  const disabled = !connectionId || recheck.isPending
  const result = recheck.data
  const authMessage = recheck.isError ? friendlyAuthMessage(recheck.error.message) : null

  return (
    <span data-testid="recheck" className="inline-flex flex-col gap-1">
      <button
        type="button"
        className={compact ? 'btn-secondary !px-2 !py-0.5 !text-[11px]' : 'btn-secondary !text-xs'}
        disabled={disabled}
        title={!connectionId ? 'Connect to Snowflake first' : 'Re-run this pane’s checks on Snowflake'}
        onClick={() => recheck.mutate()}
      >
        {recheck.isPending ? 'Re-checking…' : compact ? 'Re-check' : 'Re-check this pane'}
      </button>
      {!connectionId && !compact && (
        <span className="text-[11px] text-surface-500">Connect to Snowflake first</span>
      )}
      {recheck.isError && (
        <span role="alert" className="text-[11px] text-brand-red">
          {authMessage ?? recheck.error.message}
        </span>
      )}
      {result && !compact && (
        <span data-testid="recheck-result" className="text-[11px] text-surface-700">
          <span className="font-semibold">
            {result.visual.status === 'passed' ? 'Passed' : 'Failed'}
          </span>
          {result.previous_status && result.previous_status !== result.visual.status
            ? ` (was ${result.previous_status})`
            : ''}
          {result.summary.previous_overall_score != null && result.summary.overall_score != null
            ? ` · score ${(result.summary.previous_overall_score * 100).toFixed(0)}% → ${(result.summary.overall_score * 100).toFixed(0)}%`
            : ''}
          {result.used_edited_sql ? ' · edited SQL' : ''}
          <span className="mt-0.5 block">
            {result.visual.checks.map((c) => (
              <span
                key={c.name}
                title={c.detail}
                data-status={c.status}
                className="mr-1 rounded px-1 data-[status=failed]:bg-brand-red/10 data-[status=failed]:text-brand-red data-[status=passed]:bg-brand/10 data-[status=passed]:text-brand-dark data-[status=skipped]:bg-surface-100"
              >
                {c.name}
              </span>
            ))}
          </span>
        </span>
      )}
    </span>
  )
}
