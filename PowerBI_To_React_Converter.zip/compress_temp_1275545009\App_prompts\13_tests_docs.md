# Phase 13 - Test infrastructure, final verification and documentation

Most tests are written in their own phase (each spec's "Tests" section). This phase makes the infrastructure consistent,
runs everything, and writes the project documentation. Do it last, but keep `AGENTS.md` updated after every phase.

## 1. Test infrastructure
- Backend
  - `tests/conftest.py`: session-wide temp `PBIC_STORAGE_DIR` (phase 01); disable or isolate the DAX parse disk cache per test
    session (`dax.parser.set_parse_cache_dir(tmp)`); never touch `~/.pbic*` folders.
  - DuckDB helpers: build small in-memory tables, generate Snowflake SQL with the engine, transpile with
    `runtime/accelerate.to_duckdb_sql`, compare with hand-computed numbers. DuckDB matches quoted names case-insensitively, so case-check
    tests assert the SQL text.
  - Fake Snowflake objects: cursor (`execute`, `fetchall`, `fetchone`, `fetchmany`, `description`, `rowcount`, `sfqid`, `close`,
    `connection`), connection (`cursor()`, `close()`), connector `connect(**kwargs)` that records kwargs and can raise configured errors
    (e.g. "394508 MFA with TOTP is required").
  - Fake LLM clients: an object with `chat(messages, **kw) -> str` returning scripted replies; Horizon tests use `httpx.MockTransport`.
  - Fixtures copied from OneDrive are read-only: copy with `shutil.copytree(src, dst, ignore=...)` and never rely on deleting them.
  - Record the target's existing failing tests before phase 01 (the baseline) and compare after every phase; new failures are not allowed.
- Frontend
  - `src/test/setup.ts`: jest-dom + the in-memory localStorage shim (phase 01).
  - Tests render components with a fresh `QueryClient` and a mocked `fetch` (`vi.stubGlobal('fetch', ...)`) answering per URL.
  - Chart geometry: ECharts SSR (`echarts.init(null, null, {ssr: true, renderer: 'svg', width, height})`, `renderToSVGString()`).
  - jsdom has no canvas: stderr "Not implemented: HTMLCanvasElement.prototype.getContext" is expected noise, not a failure.
  - Heavy UI tests may need a longer timeout (`it(..., 15000)`); the full run is slow when the backend suite runs in parallel - run them apart.

## 2. Test inventory (create these files; the cases are listed in the phase specs)
| File | Phase |
|---|---|
| backend `test_snowflake_sessions.py`, `test_conversion_fixes.py` (sessions/warehouse/MFA/pre-flight/DAX parsing/report measures/bookmarks/images) | 02, 04, 05, 06 |
| `test_horizon_client.py`, `test_cortex_client.py` | 03 |
| `test_remote_model.py`, `test_m_rename_and_alias_collision.py` | 04 |
| `test_identifier_quoting.py`, `test_identifier_case.py`, `test_case_apply.py` | 05 |
| `test_sliding_window.py`, `test_tier1_patterns.py`, `test_grouped_measures.py`, `test_topn_filter.py`, `test_topn_ties.py`, `test_iferror_value.py`, `test_combine_groups.py`, `test_null_filters.py`, `test_blank_comparisons.py`, `test_speed.py`, `test_calc_column_in_and_visual_filters.py`, `test_dimension_only_tables.py`, `test_owner_availability.py` | 06 |
| `test_ai_rewrite.py`, `test_compilation_logger.py` | 07 |
| `test_query_audit.py`, `test_sql_overrides.py`, `test_recheck.py`, `test_no_sql_panes.py`, `test_measure_sql.py`, `test_dax_visual_query.py` | 08 |
| `test_dashboard_pbir_passthrough.py`, `test_layout_parity.py` | 09 |
| `test_global_filters.py`, `test_filter_operators.py`, `test_topn_relative_cards.py` | 10, 11 |
| `test_standalone_templates.py`, `test_standalone_export.py`, `test_standalone_connection.py` | 12 |
| frontend `ConnectStep.test.tsx` (extended), `auth.test.ts` | 02 |
| `llmProvider.test.tsx` | 03 |
| `queryAudit.test.tsx`, `sqlEditor.test.tsx`, `recheck.test.tsx`, `compilationAudit.test.tsx` | 08 |
| `pbiResolve.test.ts`, `pbiCalibration.test.ts`, `layoutParity.test.tsx`, `chromeNavigation.test.tsx`, `mapVisual.test.ts`, `scrollbar.test.tsx`, `format.test.ts` (extended), `interactions.test.ts` (extended), `renderingParity.test.tsx` | 09 |
| `filtersPane.test.tsx`, `filtersPhase3.test.tsx`, `syncSlicers.test.tsx` | 10 |
| `drillTooltip.test.tsx` | 11 |
| `standalone.test.tsx`, `standaloneShell.test.tsx` | 12 |
`auth.test.ts`: explains a dead API (empty 5xx body) instead of "Unexpected end of JSON input"; explains a network failure; surfaces the
API error `detail`; stores the session on success.
All fixtures are synthetic and generic (no customer report names or data).

## 3. Final verification (all must pass)
From `backend/` (use the venv directly; `uv run` may fail behind a TLS-inspecting proxy):
```
.venv/Scripts/python.exe -m pytest -q -p no:cacheprovider          # no failures beyond the recorded baseline
.venv/Scripts/python.exe -m ruff check --output-format concise <every file you touched>
```
From `frontend/`:
```
npx tsc -b
npx vitest run
npm run build:standalone
```
Then a manual smoke run: `./start.ps1 -SkipInstall`, open the studio, upload a small fixture, Connect (warehouse required), Analyze (target
card, Translation AI), Convert, Review (DAX Audit, Snowflake queries), open the full dashboard tab (Filters pane, drill-through, tooltips),
download the standalone package; `./stop.ps1`. Report what could not be checked without Snowflake.

## 4. Documentation
- `AGENTS.md` at the repo root, one section per feature area with the essentials a future agent needs: data folder (`~/.pbic-target`),
  run/stop commands, verification commands and the baseline failures, and per feature: entry points (files/functions), contracts (endpoints,
  file formats), invariants (e.g. "all SQL identifiers via quote_ident", "sql_render.py must not import app", "filtersPaneState.ts name",
  "rebuild dist-standalone after front-end changes", "put visual tuning in pbi/defaults.ts", "Top N refused in standalone templates"),
  known limitations, and the test files.
- `README.md`: AI configuration (Horizon credentials / Cortex role), the standalone package, the new review tabs.
- `.env.example` (phase 01).

## Known limitations to document (they are intended behaviour)
- Top N cards are refused in the standalone package; relative "weeks" follow Snowflake's WEEK_START; bookmarks don't restore the Filters
  pane's open/closed state; nested category axes pass only their first level to drill-through/tooltips; heatmap and map visuals don't report
  hover points; hand-written measure SQL can't be used by visuals that group by rows; AI rewrites are gated but not proven equal to Power BI.

## Done criteria
Every command in section 3 passes; AGENTS.md and README.md updated; a final summary lists each phase, what was verified, and anything left open.
 