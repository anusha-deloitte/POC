import { readErrorDetail } from '../../api/client'
import type { AuthMethod } from '../../api/types'
import type { DashboardApiConfig } from '../api'

export interface SessionStatus {
  auth_method: AuthMethod
  account?: string | null
  user?: string | null
  role?: string | null
  warehouse?: string | null
  authenticated: boolean
  signing_in?: boolean
  sso_url?: string | null
  mfa_required?: boolean
  settings_error?: string | null
  last_error?: string | null
  [key: string]: unknown
}

export interface ConnectionSettings {
  account: string
  user: string
  auth_method: AuthMethod
  role: string
  warehouse: string
  database: string
  schema: string
  oauth_client_id: string
  oauth_token_url: string
}

export interface ConnectionPublic extends Partial<ConnectionSettings> {
  remember?: boolean
  /** names of the secret fields held by the service; never their values */
  saved_secrets?: string[]
  load_error?: string | null
}

export type SecretField =
  | 'password'
  | 'private_key_pem'
  | 'private_key_passphrase'
  | 'oauth_client_secret'
  | 'pat_token'

export interface ConnectionUpdateBody extends ConnectionSettings {
  secrets: Partial<Record<SecretField, string>>
  remember: boolean
}

export interface ConnectionUpdateResult extends ConnectionPublic {
  change: 'reconnect' | 'reapply' | 'none'
  session?: SessionStatus
}

export interface AuthenticateResult {
  ok: boolean
  error?: string
  mfa_required?: boolean
}

export class SnowflakeAuthRequired extends Error {
  constructor(
    message: string,
    readonly mfaRequired = false,
  ) {
    super(message)
  }
}

async function request<T>(
  config: DashboardApiConfig,
  path: string,
  init: { method?: string; body?: unknown } = {},
): Promise<T> {
  const res = await fetch(`${config.baseUrl ?? '/api/v1/published'}${path}`, {
    method: init.method ?? 'GET',
    headers: {
      ...(init.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
      ...(config.token ? { Authorization: `Bearer ${config.token}` } : {}),
    },
    ...(init.body !== undefined ? { body: JSON.stringify(init.body) } : {}),
  })
  if (!res.ok) {
    if (res.status === 409) {
      const detail = (await res.clone().json().catch(() => null))?.detail
      if (detail?.code === 'snowflake_authentication_required')
        throw new SnowflakeAuthRequired(detail.message ?? 'Snowflake sign-in required', !!detail.mfa_required)
    }
    throw new Error(await readErrorDetail(res))
  }
  return res.json() as Promise<T>
}

export const standaloneApi = {
  session: (config: DashboardApiConfig) => request<SessionStatus>(config, '/session'),
  authenticate: (config: DashboardApiConfig, passcode?: string) =>
    request<AuthenticateResult>(config, '/session/authenticate', {
      method: 'POST',
      body: passcode ? { passcode } : {},
    }),
  signOut: (config: DashboardApiConfig) =>
    request<unknown>(config, '/session/sign-out', { method: 'POST', body: {} }),
  connection: (config: DashboardApiConfig) => request<ConnectionPublic>(config, '/connection'),
  saveConnection: (config: DashboardApiConfig, body: ConnectionUpdateBody) =>
    request<ConnectionUpdateResult>(config, '/connection', { method: 'PUT', body }),
  forgetSecrets: (config: DashboardApiConfig) =>
    request<unknown>(config, '/connection/secrets', { method: 'DELETE' }),
}
