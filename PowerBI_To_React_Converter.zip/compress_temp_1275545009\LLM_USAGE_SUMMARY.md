# LLM Usage Summary: PBI Converter

## Current LLM Provider

**Name:** Horizon (Elevance Health Internal Gateway)  
**Protocol:** OAuth2 + JSON REST API  
**Underlying Models:** OpenAI (configurable via QOS parameter)  
**Models:** GPT-4o, GPT-4-turbo, GPT-4 (via `accurate` QOS), GPT-3.5-turbo (via `cheap` QOS)  
**Client Library:** Custom `HorizonClient` (backend/app/services/horizon_client.py)

### Configuration (Environment Variables)
```
PBIC_HORIZON_CLIENT_ID          → OAuth2 client ID
PBIC_HORIZON_CLIENT_SECRET      → OAuth2 client secret
PBIC_HORIZON_BASE_URL           → Default: https://api.horizon.elevancehealth.com
PBIC_HORIZON_QOS                → "accurate" (default) | "cheap" (GPT-3.5)
PBIC_HORIZON_GOVERNANCE_QOS     → "cheap" (for governance questions)
PBIC_HORIZON_MAX_REQUESTS_PER_MINUTE → Default: 15
PBIC_HORIZON_VERIFY_SSL         → true (default, can disable for testing)
```

If `PBIC_HORIZON_CLIENT_ID` and `PBIC_HORIZON_CLIENT_SECRET` are empty, **all LLM features are disabled**.

---

## Where LLMs Are Used

### 1. **Tier-2 Measure Compilation** (High Priority)
**File:** `backend/app/agents/tier2.py`  
**Function:** `propose_and_validate()`  
**When:** User enables LLM in conversion request OR measures are too complex for deterministic compiler

**What it does:**
- Takes complex DAX expressions that the Python tier-1 compiler cannot handle
- Sends to Horizon with physical table schema and measure DAX
- Gets back proposed Snowflake SQL
- **Validates** the SQL by executing it on Snowflake (no unverified LLM output)
- Retries up to 3 times with error feedback if SQL execution fails

**Example:**
```
DAX (complex): [Sales YTD] = CALCULATE(SUM([Amount]), DATESINPERIOD(...))
              ↓ (tier-1 compiler fails)
              ↓ (tier-2: send to Horizon)
LLM Output:   SELECT SUM(amount) FROM fact_sales 
              WHERE date >= DATE_TRUNC('year', CURRENT_DATE())
              ↓ (execute on Snowflake to validate)
✓ Accepted: Stored per conversion, used at query time
```

**Trigger:**
```python
# In backend/app/api/dashboards.py
if req.use_llm:
    llm_client = build_client_from_settings()
    # Then in pipeline.py:
    if llm_client is not None and tier2_candidates:
        propose_and_validate(
            bundle.model, binding_map, measure_name, 
            cursor, client=llm_client
        )
```

---

### 2. **Visual Comparison (Low Priority)**
**File:** `backend/app/agents/visual_compare.py`  
**Function:** `compare_page_images()`  
**When:** Dashboard validation step to verify visual fidelity

**What it does:**
- Takes two PNG images: original Power BI dashboard + rendered React version
- Sends to Horizon vision API with visual inventory metadata
- Gets back similarity score (0-100%) + list of visual differences
- Used for quality gates (e.g., "pass if >85% similar")

**Example:**
```
Input:  Original PBI image + Converted React image + Visual list
        ↓ (vision model analyzes both)
Output: {
  "similarity": 87,
  "findings": [
    "Chart 1: Title color differs",
    "Slicer 2: Missing filter value",
    "Overall: 87% visual parity"
  ]
}
```

**Trigger:**
```python
# In backend/app/validation/reimagine_gate.py (if called)
compare_page_images(
    reference_png=pbi_screenshot,
    rendered_png=react_screenshot,
    visual_inventory=dashboard_spec.pages[0].visuals
)
```

---

### 3. **Governance Analysis** (Optional)
**File:** `backend/app/runtime/semantic_governance.py`  
**When:** User requests governance/compliance analysis

**What it does:**
- Analyzes measures and data model for governance issues
- Uses cheaper QOS (`horizon_governance_qos = "cheap"`)
- Suggests data classification, PII handling, etc.

**Trigger:**
```python
# Governance is optional, only if explicitly enabled in settings
if s.enable_governance_analysis:
    analyze_model_governance(llm_client, model)
```

---

## API Endpoints That Use LLM

| Endpoint | Method | Parameter | What It Does |
|----------|--------|-----------|--------------|
| `/api/v1/conversions` | POST | `use_llm: bool` | If true, enable tier-2 LLM compilation during conversion |
| `/api/v1/conversions/{id}/convert` | POST | `use_llm: bool` | Run full pipeline with LLM tier-2 fallback |
| `/api/v1/conversions/{id}/compare` | POST | N/A | Compare visuals using vision model |

---

## LLM Call Statistics

From code inspection:

| Component | Model Type | Calls/Conversion | Max Retries | Validation |
|-----------|-----------|-----------------|-------------|-----------|
| Tier-2 Measures | `accurate` QOS | ~5-10 (1 per tier-2 measure) | 3 | ✓ Execution test |
| Visual Compare | Vision | 1 per page | 2 | ✓ JSON schema + manual |
| Governance | `cheap` QOS | 1 | None | ✓ Text analysis |

---

## Cost Estimation

Assuming GPT-4o pricing (~$0.005 per 1K input tokens, ~$0.015 per 1K output tokens):

| Scenario | Calls | Avg Input | Avg Output | Est. Cost |
|----------|-------|-----------|-----------|-----------|
| Simple conversion (no tier-2) | 0 | - | - | $0.00 |
| 5 tier-2 measures | 5 | 1.5K | 200 | ~$0.04 |
| Visual compare (1 page, 5 visuals) | 1 | 4K + image | 500 | ~$0.03 |
| Full conversion + compare | 6 | - | - | ~$0.07 |

**Per-minute rate limit:** 15 calls/minute (configurable)

---

## Fallback Behavior (When LLM Unavailable)

```
If PBIC_HORIZON_CLIENT_ID is not set:
  ├─ Tier-2 measures → marked "needs_llm_support"
  ├─ Visual comparison → skipped (validation passes)
  └─ Governance → skipped (no governance report)
  
Result: Dashboard compiles but some measures return empty/null
```

---

## Future LLM Integrations (Proposed)

### **Calculated Columns (Not Yet Implemented)**
- Convert DAX calculated columns to Snowflake SQL
- Would use same tier-2 pattern as measures
- Expected: +3-10 LLM calls per conversion (1 per calc column)

### **Power Query (M) Translation (Not Yet Implemented)**
- Convert Power Query transforms to SQL views
- Handle Excel/SharePoint source migration
- Expected: +2-5 LLM calls per Excel/SharePoint source

### **Fallback Visual Renderers (Not Yet Implemented)**
- Generate React components for unsupported custom visuals
- Use vision model to understand intent
- Expected: +1-3 LLM calls per unsupported custom visual

---

## Summary: What Each LLM Call Does

```
┌─────────────────────────────────────────────────────────────┐
│                  LLM USAGE HIERARCHY                        │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  1. TIER-2 MEASURE COMPILATION (REQUIRED when enabled)      │
│     ├─ Input: DAX expression + table schema                 │
│     ├─ Process: Translate to SQL, validate with Snowflake  │
│     ├─ Output: Verified SQL or error                        │
│     └─ Impact: HIGH - Measures missing without this         │
│                                                              │
│  2. VISUAL COMPARISON (OPTIONAL)                            │
│     ├─ Input: Two PNG images + visual metadata              │
│     ├─ Process: Vision model analyzes visual parity         │
│     ├─ Output: Similarity % + difference list               │
│     └─ Impact: MEDIUM - QA/validation only                  │
│                                                              │
│  3. GOVERNANCE ANALYSIS (OPTIONAL)                          │
│     ├─ Input: Data model structure                          │
│     ├─ Process: Analyze for compliance issues               │
│     ├─ Output: Recommendations                              │
│     └─ Impact: LOW - Informational only                     │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

## Configuration Best Practices

### Development/Testing
```bash
# Disable LLM (all features off)
unset PBIC_HORIZON_CLIENT_ID
unset PBIC_HORIZON_CLIENT_SECRET

# Or use cheap models
export PBIC_HORIZON_QOS="cheap"
export PBIC_HORIZON_MAX_REQUESTS_PER_MINUTE=5
```

### Production
```bash
# Use accurate models with rate limiting
export PBIC_HORIZON_QOS="accurate"
export PBIC_HORIZON_MAX_REQUESTS_PER_MINUTE=30
export PBIC_HORIZON_GOVERNANCE_QOS="cheap"

# Monitor logs for LLM calls
export PBIC_LOG_LEVEL="INFO"  # Logs all horizon_* events
```

---

## Monitoring & Logging

All LLM calls are logged via `log_event()` in `backend/app/core/logging.py`:

```python
log_event(_logger, "info", "horizon_chat", 
    qos="accurate", 
    elapsed_ms=250,
    attempt=1
)
```

Check logs for:
- `horizon_token_refreshed` → Token rotation working
- `horizon_chat` → Successful LLM calls
- `horizon_rate_limited` → Rate limiting hit
- `horizon_chat_failed` → API errors
- `horizon_server_error_retrying` → Transient failures

---

## Decision: Use Internal Horizon or Switch to Direct OpenAI/Claude?

### Current (Horizon)
✓ OAuth2 security  
✓ Model routing (accurate vs cheap)  
✓ Rate limiting built-in  
✓ Internal audit trail  
✗ Depends on Elevance Health infrastructure  
✗ Cannot use Claude models  

### Alternative: Direct OpenAI SDK
✓ Direct control  
✓ Access to latest models  
✗ Credential management burden  
✗ No built-in rate limiting  
✗ Cost tracking harder  

### Alternative: Claude API
✓ Better for complex reasoning (DAX translation)  
✓ Vision capabilities  
✗ Different pricing  
✗ Different rate limits  

**Recommendation for the prompt you gave Devin:** If implementing calculated column/Power Query transpilation, consider adding Claude as an alternative to Horizon via the same abstraction (keep `HorizonClient` interface but add optional `ClaudeClient`).
