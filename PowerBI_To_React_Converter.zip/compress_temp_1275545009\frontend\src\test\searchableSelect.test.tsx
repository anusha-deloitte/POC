import { render, screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { useState } from 'react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  highlightSegments,
  matchesWords,
  SearchableSelect,
} from '../components/SearchableSelect'

const OPTIONS = [
  { value: 'a', label: 'Sales Overview' },
  { value: 'b', label: 'Customer Retention' },
  { value: 'c', label: 'Reg​ional  Sales Detail' },
  { value: 'd', label: 'Inventory' },
]

function Harness({ onChange = () => {} }: { onChange?: (v: string) => void }) {
  const [value, setValue] = useState<string | null>('b')
  return (
    <div>
      <SearchableSelect
        ariaLabel="Page"
        itemLabel="pages"
        options={OPTIONS}
        value={value}
        onChange={(v) => {
          setValue(v)
          onChange(v)
        }}
      />
      <span data-testid="outside">outside</span>
    </div>
  )
}

const trigger = () => screen.getByRole('combobox', { name: 'Page' })
const search = () => screen.getByRole('searchbox')
const optionTexts = () => screen.queryAllByRole('option').map((o) => o.textContent)

function rect(top: number, height = 30): DOMRect {
  return {
    left: 40,
    right: 240,
    top,
    bottom: top + height,
    width: 200,
    height,
    x: 40,
    y: top,
    toJSON: () => ({}),
  } as DOMRect
}

afterEach(() => {
  vi.restoreAllMocks()
  vi.unstubAllGlobals()
})

describe('matching helpers', () => {
  it('requires every word, any order, ignoring case, zero-width characters and spacing', () => {
    expect(matchesWords('Sales Overview', 'overview sales')).toBe(true)
    expect(matchesWords('Sales Overview', '  SALES   over ')).toBe(true)
    expect(matchesWords('Reg​ional Sales', 'regional')).toBe(true)
    expect(matchesWords('Reg​ional Sales', 're​gional')).toBe(true)
    expect(matchesWords('Sales Overview', 'sales profit')).toBe(false)
    expect(matchesWords('anything', '   ')).toBe(true)
  })

  it('returns bold segments for every typed word', () => {
    expect(highlightSegments('Sales Overview', 'over sal')).toEqual([
      { text: 'Sal', hit: true },
      { text: 'es ', hit: false },
      { text: 'Over', hit: true },
      { text: 'view', hit: false },
    ])
  })
})

describe('SearchableSelect', () => {
  it('shows the selection and opens a list with a focused search box and a footer count', async () => {
    const user = userEvent.setup()
    render(<Harness />)
    expect(trigger()).toHaveTextContent('Customer Retention')
    expect(trigger()).toHaveAttribute('aria-expanded', 'false')
    await user.click(trigger())
    expect(trigger()).toHaveAttribute('aria-expanded', 'true')
    expect(search()).toHaveFocus()
    expect(screen.getByRole('listbox', { name: 'Page' })).toBeInTheDocument()
    expect(screen.getByText('4 of 4 pages')).toBeInTheDocument()
  })

  it('filters by words in any order and bolds the matched text', async () => {
    const user = userEvent.setup()
    render(<Harness />)
    await user.click(trigger())
    await user.type(search(), 'sales  regional')
    // the zero-width character is invisible to the match and to the label
    expect(optionTexts()).toEqual(['Regional Sales Detail'])
    expect(screen.getByText('1 of 4 pages')).toBeInTheDocument()
    const bold = within(screen.getByRole('option'))
      .getAllByTestId('match')
      .map((n) => n.textContent)
    expect(bold).toEqual(['Regional', 'Sales'])
  })

  it('reorders words and shows an empty state', async () => {
    const user = userEvent.setup()
    render(<Harness />)
    await user.click(trigger())
    await user.type(search(), 'overview SALES')
    expect(optionTexts()).toEqual(['Sales Overview'])
    await user.clear(search())
    await user.type(search(), 'zzz')
    expect(optionTexts()).toEqual([])
    expect(screen.getByText('0 of 4 pages')).toBeInTheDocument()
  })

  it('selects with Up/Down and Enter; typing alone never changes the selection', async () => {
    const user = userEvent.setup()
    const onChange = vi.fn()
    render(<Harness onChange={onChange} />)
    await user.click(trigger())
    await user.type(search(), 'sales')
    expect(onChange).not.toHaveBeenCalled()
    expect(trigger()).toHaveTextContent('Customer Retention')
    // the active row starts on the first match; Down moves to the second
    await user.keyboard('{ArrowDown}')
    expect(search().getAttribute('aria-activedescendant')).toBe(screen.getAllByRole('option')[1].id)
    await user.keyboard('{Enter}')
    expect(onChange).toHaveBeenCalledWith('c')
    expect(trigger()).toHaveTextContent('Regional Sales Detail')
    expect(screen.queryByRole('listbox')).toBeNull()
  })

  it('moves back up with ArrowUp', async () => {
    const user = userEvent.setup()
    const onChange = vi.fn()
    render(<Harness onChange={onChange} />)
    await user.click(trigger())
    await user.type(search(), 'sales')
    await user.keyboard('{ArrowDown}{ArrowUp}{Enter}')
    expect(onChange).toHaveBeenCalledWith('a')
  })

  it('closes on Escape and clears the search', async () => {
    const user = userEvent.setup()
    const onChange = vi.fn()
    render(<Harness onChange={onChange} />)
    await user.click(trigger())
    await user.type(search(), 'inv')
    await user.keyboard('{Escape}')
    expect(screen.queryByRole('listbox')).toBeNull()
    expect(onChange).not.toHaveBeenCalled()
    await user.click(trigger())
    expect(search()).toHaveValue('')
    expect(screen.getByText('4 of 4 pages')).toBeInTheDocument()
  })

  it('closes on an outside click and clears the search', async () => {
    const user = userEvent.setup()
    render(<Harness />)
    await user.click(trigger())
    await user.type(search(), 'inv')
    await user.click(screen.getByTestId('outside'))
    expect(screen.queryByRole('listbox')).toBeNull()
    await user.click(trigger())
    expect(search()).toHaveValue('')
  })

  it('selects with a click', async () => {
    const user = userEvent.setup()
    const onChange = vi.fn()
    render(<Harness onChange={onChange} />)
    await user.click(trigger())
    await user.click(screen.getByRole('option', { name: 'Inventory' }))
    expect(onChange).toHaveBeenCalledWith('d')
    expect(trigger()).toHaveTextContent('Inventory')
  })

  it('renders through a portal into document.body with fixed positioning', async () => {
    const user = userEvent.setup()
    const { container } = render(<Harness />)
    await user.click(trigger())
    const popup = screen.getByTestId('searchable-select-popup')
    expect(container.contains(popup)).toBe(false)
    expect(popup.parentElement).toBe(document.body)
    expect(popup.style.position).toBe('fixed')
    expect(popup.dataset.placement).toBe('down')
  })

  it('follows the button when the page scrolls', async () => {
    const user = userEvent.setup()
    render(<Harness />)
    const spy = vi.spyOn(HTMLElement.prototype, 'getBoundingClientRect').mockReturnValue(rect(100))
    await user.click(trigger())
    const popup = screen.getByTestId('searchable-select-popup')
    expect(popup.style.top).toBe('134px')
    spy.mockReturnValue(rect(160))
    window.dispatchEvent(new Event('scroll'))
    await vi.waitFor(() => expect(popup.style.top).toBe('194px'))
  })

  it('opens upward when there is no room below', async () => {
    const user = userEvent.setup()
    render(<Harness />)
    vi.stubGlobal('innerHeight', 768)
    vi.spyOn(HTMLElement.prototype, 'getBoundingClientRect').mockReturnValue(rect(700))
    await user.click(trigger())
    const popup = screen.getByTestId('searchable-select-popup')
    expect(popup.dataset.placement).toBe('up')
    expect(popup.style.bottom).toBe('72px') // 768 - 700 + 4
    expect(popup.style.top).toBe('')
  })
})
