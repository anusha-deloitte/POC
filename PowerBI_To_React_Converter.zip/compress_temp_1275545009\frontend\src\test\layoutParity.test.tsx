import { render, screen, within } from '@testing-library/react'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import {
  alignButtonRows,
  canvasScale,
  emptyResult,
  groupNotices,
  isEffectivelyHidden,
  noDataLabel,
  placeNotices,
  queryVisualNames,
  resolveFit,
  titleFromResult,
  unavailableReason,
  zRanks,
} from '../dashboard/canvas'
import { PageCanvas } from '../dashboard/PageCanvas'
import { buildTheme, PbiThemeContext } from '../dashboard/pbi/resolve'
import type { PageSpec, VisualResult, VisualSpec } from '../dashboard/types'

const L = (v: string) => ({ expr: { Literal: { Value: v } } })

function v(name: string, over: Partial<VisualSpec> = {}): VisualSpec {
  return {
    name, visual_type: 'card', x: 0, y: 0, width: 100, height: 60, z: 1, supported: true,
    dim_keys: [], column_keys: [], series_keys: [], measure_keys: ['M'], measure_roles: {}, measure_formats: {},
    static_content: {}, sort: [], data_status: 'ok',
    query: { dimensions: [], measures: [{ name: 'M' }], filters: [], sort: [] },
    pbir: { objects: {}, container_objects: {}, fields: [], sort: [], is_hidden: false, self_hidden: false },
    ...over,
  } as VisualSpec
}

const page = (visuals: VisualSpec[], over: Partial<PageSpec> = {}): PageSpec => ({
  name: 'p1', display_name: 'Page 1', width: 1280, height: 720, ordinal: 0, visuals, ...over,
})

const result = (name: string, rows: (string | number | null)[][] = [[42]], over: Partial<VisualResult> = {}): VisualResult => ({
  visual: name, columns: ['M'], rows, warnings: [], elapsed_ms: 1, cached: false, ...over,
})

describe('canvas scaling', () => {
  it('FitToPage uses the limiting dimension, FitToWidth ignores height, ActualSize is 1', () => {
    expect(canvasScale('FitToPage', 640, 720, 1280, 720)).toBe(0.5)
    expect(canvasScale('FitToPage', 1280, 180, 1280, 720)).toBe(0.25)
    expect(canvasScale('FitToWidth', 640, 100, 1280, 720)).toBe(0.5)
    expect(canvasScale('ActualSize', 640, 100, 1280, 720)).toBe(1)
  })

  it('fit=auto honours the page display option (default FitToPage)', () => {
    expect(resolveFit('auto', 'FitToWidth')).toBe('FitToWidth')
    expect(resolveFit('auto', 'ActualSize')).toBe('ActualSize')
    expect(resolveFit('auto', undefined)).toBe('FitToPage')
    expect(resolveFit('auto', 'Whatever')).toBe('FitToPage')
    expect(resolveFit('FitToWidth', 'ActualSize')).toBe('FitToWidth')
  })
})

describe('stacking and visibility', () => {
  it('CSS z-index is the integer rank of the (fractional) z', () => {
    const ranks = zRanks([v('a', { z: 3.00002 }), v('b', { z: 1 }), v('c', { z: 3.00001 }), v('d', { z: 2 })])
    expect([...ranks.entries()].sort((a, b) => a[1] - b[1]).map(([n]) => n)).toEqual(['b', 'd', 'c', 'a'])
    expect(ranks.get('b')).toBe(1)
    expect(ranks.get('a')).toBe(4)
  })

  const group = v('grp', { visual_type: 'visualGroup', pbir: { objects: {}, container_objects: {}, fields: [], sort: [], is_hidden: true, self_hidden: true } })
  const child = v('child', { pbir: { objects: {}, container_objects: {}, fields: [], sort: [], is_hidden: true, self_hidden: false, parent_group: 'grp' } })

  it('a child of a hidden group is hidden until a bookmark shows the group', () => {
    const all = [group, child]
    expect(isEffectivelyHidden(child, {}, all)).toBe(true)
    expect(isEffectivelyHidden(child, { grp: 'visible' }, all)).toBe(false)
    expect(isEffectivelyHidden(group, {}, all)).toBe(true)
  })

  it('an override can hide a visible visual or a group child on its own', () => {
    const plain = v('plain')
    expect(isEffectivelyHidden(plain, {}, [plain])).toBe(false)
    expect(isEffectivelyHidden(plain, { plain: 'hidden' }, [plain])).toBe(true)
    expect(isEffectivelyHidden(child, { grp: 'visible', child: 'hidden' }, [group, child])).toBe(true)
  })

  it('survives a parent cycle', () => {
    const a = v('a', { pbir: { objects: {}, container_objects: {}, fields: [], sort: [], is_hidden: false, parent_group: 'b' } })
    const b = v('b', { pbir: { objects: {}, container_objects: {}, fields: [], sort: [], is_hidden: false, parent_group: 'a' } })
    expect(isEffectivelyHidden(a, {}, [a, b])).toBe(false)
  })
})

describe('queries and titles', () => {
  it('queryVisualNames: data visuals, panes with manual SQL and title queries', () => {
    const names = queryVisualNames(
      page([
        v('data'),
        v('untranslated', { supported: false, data_status: 'untranslated', query: null }),
        v('edited', { supported: false, data_status: 'untranslated', query: null, manual_sql: 'SELECT 1' }),
        v('chrome', { visual_type: 'shape', query: null }),
        v('titled', { title_query: { dimensions: [], measures: [{ name: 'T' }], filters: [], sort: [] } }),
      ]),
    )
    expect(names).toEqual(['data', 'edited', 'titled', 'titled#title'])
  })

  it('titleFromResult reads the first cell', () => {
    expect(titleFromResult(result('x#title', [['Sales 2024']]))).toBe('Sales 2024')
    expect(titleFromResult(result('x#title', [['  ']]))).toBeUndefined()
    expect(titleFromResult(result('x#title', [[null]]))).toBeUndefined()
    expect(titleFromResult(result('x#title', [], {}))).toBeUndefined()
    expect(titleFromResult(result('x#title', [['t']], { error: 'boom' }))).toBeUndefined()
    expect(titleFromResult(undefined)).toBeUndefined()
  })
})

describe('data-less visuals', () => {
  it('describes why a visual has no data; a pane with hand-edited SQL has no notice', () => {
    expect(unavailableReason(v('a', { data_status: 'untranslated', supported: false }))).toMatch(/could not be translated/)
    expect(unavailableReason(v('a', { data_status: 'untranslated', supported: false, manual_sql: 'SELECT 1' }))).toBeNull()
    expect(unavailableReason(v('a', { data_status: 'unsupported_type', supported: false, visual_type: 'weird' }))).toMatch(/weird/)
    expect(unavailableReason(v('a'), result('a', [], { error: 'SQL error\nsecond line' }))).toBe('Query failed: SQL error')
    expect(unavailableReason(v('a'), result('a'))).toBeNull()
    expect(noDataLabel(v('a', { data_status: 'untranslated', supported: false }))).toBe('No SQL generated')
    expect(noDataLabel(v('a'), result('a', [], { error: 'x' }))).toBe('Query failed')
    expect(noDataLabel(v('a'))).toBe('No data')
  })

  it('emptyResult has the columns the renderer reads and no rows', () => {
    const e = emptyResult(v('a', { dim_keys: ['T.C'], measure_keys: ['M'] }))
    expect(e.columns).toEqual(['T.C', 'M'])
    expect(e.rows).toEqual([])
  })

  it('one notice per stack of overlapping visuals; chrome and tiny decorations never get one', () => {
    const stack1 = v('s1', { x: 0, y: 0, width: 200, height: 100, z: 1, data_status: 'untranslated', supported: false })
    const stack2 = v('s2', { x: 100, y: 50, width: 200, height: 100, z: 2, data_status: 'untranslated', supported: false })
    const alone = v('alone', { x: 600, y: 0, width: 200, height: 100, data_status: 'untranslated', supported: false })
    const tiny = v('tiny', { x: 0, y: 300, width: 10, height: 10, data_status: 'untranslated', supported: false })
    const chrome = v('shape', { visual_type: 'shape', x: 0, y: 400, width: 100, height: 100, data_status: 'unsupported_type', supported: false })
    const fine = v('fine', { x: 0, y: 600 })
    const groups = groupNotices([stack1, stack2, alone, tiny, chrome, fine], {})
    expect(groups.map((g) => g.visuals.map((x) => x.name).sort())).toEqual([['s1', 's2'], ['alone']])
  })

  it('places notices so none overlap; narrow ones show only the symbol', () => {
    const a = v('a', { x: 0, y: 0, width: 300, height: 100, data_status: 'untranslated', supported: false })
    const b = v('b', { x: 0, y: 0, width: 40, height: 100, data_status: 'untranslated', supported: false, z: 5 })
    const placed = placeNotices(groupNotices([a, b], {}))
    expect(placed).toHaveLength(1) // overlapping -> one stack
    const c = v('c', { x: 700, y: 0, width: 300, height: 100, data_status: 'untranslated', supported: false })
    const d = v('d', { x: 700, y: 200, width: 300, height: 100, data_status: 'untranslated', supported: false })
    const e = v('e', { x: 750, y: 10, width: 40, height: 90, data_status: 'untranslated', supported: false })
    const two = placeNotices(groupNotices([c, d], {}))
    expect(two[0].width).toBeGreaterThan(18)
    const narrow = placeNotices(groupNotices([e], {}))
    expect(narrow[0]).toMatchObject({ compact: true, width: 18 })
    // two notices on the same row never overlap
    const same = placeNotices([
      { visuals: [c], reason: 'x' },
      { visuals: [v('c2', { x: 700, y: 0, width: 300, height: 100 })], reason: 'y' },
    ])
    expect(same[1].x + same[1].width).toBeLessThanOrEqual(same[0].x)
  })

  it('a row of label buttons shares one text line', () => {
    const b1 = v('b1', { visual_type: 'actionButton', y: 100, height: 40 })
    const b2 = v('b2', { visual_type: 'actionButton', y: 101, height: 44 })
    const b3 = v('b3', { visual_type: 'actionButton', y: 300, height: 40 })
    const offsets = alignButtonRows([b1, b2, b3])
    expect(offsets.b3).toBe(0) // alone on its row
    expect(Math.abs((b1.y + b1.height / 2 + offsets.b1) - (b2.y + b2.height / 2 + offsets.b2))).toBeLessThan(0.01)
  })
})

describe('PageCanvas', () => {
  beforeEach(() => {
    class RO {
      observe() {}
      disconnect() {}
      unobserve() {}
    }
    vi.stubGlobal('ResizeObserver', RO)
  })

  const renderPage = (p: PageSpec, results: Record<string, VisualResult> = {}, extra = {}) =>
    render(
      <PbiThemeContext.Provider value={buildTheme(undefined)}>
        <PageCanvas page={p} results={results} slicerState={{}} onSlicerChange={() => {}} {...extra} />
      </PbiThemeContext.Provider>,
    )

  it('stacks by z rank, drops hidden visuals and gives chrome no card', () => {
    const p = page([
      v('low', { z: 1.00001 }),
      v('high', { z: 7 }),
      v('hidden', { pbir: { objects: {}, container_objects: {}, fields: [], sort: [], is_hidden: true, self_hidden: true } }),
      v('box', { visual_type: 'shape', query: null, z: 3 }),
    ])
    renderPage(p, { low: result('low'), high: result('high') })
    const z = (name: string) => Number(screen.getByTestId(`visual-${name}`).style.zIndex)
    expect([z('low'), z('box'), z('high')].every(Number.isInteger)).toBe(true)
    expect(z('low')).toBeLessThan(z('box'))
    expect(z('box')).toBeLessThan(z('high'))
    expect(screen.queryByTestId('visual-hidden')).toBeNull()
    expect(screen.getByTestId('visual-box').className).not.toContain('border')
  })

  it('bookmark overrides show or hide visuals', () => {
    const grp = v('grp', { visual_type: 'visualGroup', query: null, pbir: { objects: {}, container_objects: {}, fields: [], sort: [], is_hidden: true, self_hidden: true } })
    const kid = v('kid', { pbir: { objects: {}, container_objects: {}, fields: [], sort: [], is_hidden: true, self_hidden: false, parent_group: 'grp' } })
    const p = page([grp, kid])
    const { unmount } = renderPage(p, { kid: result('kid') })
    expect(screen.queryByTestId('visual-kid')).toBeNull()
    unmount()
    renderPage(p, { kid: result('kid') }, { overrides: { grp: 'visible' } })
    expect(screen.getByTestId('visual-kid')).toBeTruthy()
    expect(screen.getByTestId('visual-grp').style.pointerEvents).toBe('none')
  })

  it('shows the measure-driven title and the switch alone otherwise', () => {
    const titled = v('t1', {
      pbir: { objects: {}, container_objects: { title: [{ properties: { show: L('true'), text: L("'Static'") } }] }, fields: [], sort: [], is_hidden: false },
      title_query: { dimensions: [], measures: [{ name: 'T' }], filters: [], sort: [] },
    })
    renderPage(page([titled]), { t1: result('t1'), 't1#title': result('t1#title', [['Revenue 2024']]) })
    expect(screen.getByTestId('title-t1').textContent).toContain('Revenue 2024')
    const off = v('t2', {
      pbir: { objects: {}, container_objects: { title: [{ properties: { show: L('false'), text: L("'Hidden title'") } }] }, fields: [], sort: [], is_hidden: false },
    })
    const { container } = renderPage(page([off]), { t2: result('t2') })
    expect(within(container).queryByTestId('title-t2')).toBeNull()
  })

  it('visuals without data keep their chrome and get one info symbol with the reason', () => {
    const p = page([v('u', { supported: false, data_status: 'untranslated', query: null, width: 300, height: 120 })])
    renderPage(p, {})
    expect(screen.getByTestId('visual-u')).toBeTruthy()
    const notice = screen.getByTestId('data-notice')
    expect(notice.getAttribute('title')).toMatch(/could not be translated/)
    expect(screen.getByTestId('inline-notice-u').textContent).toBe('No SQL generated')
  })

  it('amber messages are annotations-mode only; the symbol stays', () => {
    const p = page([v('u', { supported: false, data_status: 'untranslated', query: null, width: 300, height: 120 })])
    renderPage(p, {}, { annotations: false })
    expect(screen.queryByTestId('inline-notice-u')).toBeNull()
    expect(screen.getByTestId('data-notice')).toBeTruthy()
  })

  it('a pane with hand-edited SQL is queried and has no notice', () => {
    const p = page([v('e', { supported: false, data_status: 'untranslated', query: null, manual_sql: 'SELECT 1' })])
    renderPage(p, { e: result('e') })
    expect(screen.queryByTestId('data-notice')).toBeNull()
  })

  it('actions that cannot run get pointer-events none', () => {
    const btn = v('btn', { visual_type: 'actionButton', query: null, action: { type: 'PageNavigation', page: 'gone' } })
    renderPage(page([btn]), {}, { actionDisabled: () => true })
    expect(screen.getByTestId('visual-btn').style.pointerEvents).toBe('none')
  })

  it('exposes the page scale and honours the vertical alignment', () => {
    renderPage(page([v('a')]))
    expect(screen.getByTestId('page-canvas').getAttribute('data-scale')).toBe('1.0000')
  })
})
