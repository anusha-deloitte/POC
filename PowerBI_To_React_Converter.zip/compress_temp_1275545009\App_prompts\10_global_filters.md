# Phase 10 - Power BI global filters: report/page filters, synced slicers, Filters pane, Top N, relative date, bookmark filters

## Purpose
Reproduce Power BI's Filters pane and synced slicers: report ("Filters on all pages") and page ("Filters on this page") filters
applied by default (hidden/locked respected), a collapsible pane, slicer selections synced across pages, more operators, Top N and
relative date/time cards, and bookmarks that restore filter state. Numbers will change where hidden/saved page filters now apply
(that is Power BI's behaviour).

## 1. Parser (`parsers/pbir.py`, `ir/report.py`)
1.1 `Filter` gains `is_locked` (`isLockedInViewMode`), `ordinal` (int only), `how_created` (`howCreated`: User | Drillthrough | ...),
`display_name` (card title), `require_single` (`objects.general[0].properties.requireSingleSelection` literal true).
1.2 `Visual.sync_group: SyncGroup {name, field_changes, filter_changes}` from `visual.syncGroup` (`groupName`, `fieldChanges`,
`filterChanges`; None without a group name); `InteractionGraph.sync_groups = {group: [visual names]}` over all pages.
1.3 `FilterPane {expanded, visible, width, colours}` from `objects.outspacePane[0].properties` (booleans/number literals; every other
literal - colours via `{solid:{color}}` - into `colours`) plus `objects.filterCard` entries grouped by `selector.id` (default
"Available"; "Applied") into `colours["filterCard"]`; None when neither exists. On `Report.filter_pane` (report.json) and
`Page.filter_pane` (page.json). `Report/Page.filter_sort_order` = `filterConfig.filterSortOrder` (Custom | Ascending | Descending);
`Report.allow_change_filter_types` = `settings.allowChangeFilterTypes` (default True).
1.4 Bookmarks (phase 04 parser): unless `options.suppressData` ("Data" off), `state.filters = {report: {name: {type, filter}},
pages: {section: {name: {type, filter}}}, slicers: {visual: <filter> | None}}` from `explorationState.filters` (`byName` values +
`byExpr` list), each section's `filters`, and slicer visuals' `objects.merge.general[0].properties.filter.filter`.
1.5 `Report.filters_parsed = True` / `pages_parsed = True` for new parses; `runtime/dashboard.py::filters_passthrough(bundle)` re-reads
all of the above (and phase 11's page type/drill-through/tooltip fields) from the stored source while they are False (no re-upload).

## 2. Spec (`runtime/dashboard.py`)
2.1 Models: `FilterCondition {op, values, params}`, `FilterDefault {join: and|or, conditions}`, `FilterCard {name, scope: report|page,
table, column, display_name, data_type, kind: basic|advanced|topn|relative, default: FilterDefault|None (None = "(All)"),
require_single, hidden, locked, supported, reason}`. `DashboardSpec.report_filters`, `filter_pane`, `allow_change_filter_types`;
`PageSpec.filters`, `filter_pane`; `VisualSpec.sync_group`.
2.2 `_condition_to_filter(cond)`: `Not` (negates eq -> neq, in -> not_in, contains -> not_contains, starts_with -> not_starts_with; others
unsupported), `Contains` / `StartsWith` (literal right side, non-null), `In` (one expression; tuples -> values; Values missing = TopN
subquery -> unsupported), `Comparison` (ComparisonKind 0 eq, 1 gt, 2 gte, 3 lt, 4 lte). Target Measure or Column. Returns
`(kind, None, name, op, values)` or None.
2.3 `ENGINE_FILTER_OPS = {in, not_in, eq, neq, gt, gte, lt, lte, contains, not_contains, starts_with, not_starts_with, is_blank,
is_not_blank, is_empty, is_not_empty, topn, relative, between_dates}`. Visual filters with other ops are dropped with a description.
2.4 `filter_card(filter, bundle, compiler=None)`: `howCreated == "Drillthrough"` -> None (that is the "Drill through" well, not a page
filter). Kind from filter type (Categorical basic, Advanced advanced, TopN topn, RelativeDate/RelativeTime relative, else advanced).
Refusals (`supported=False`, `reason`): no field ("filter field not recognised"), measure field ("filters on a measure are not supported in
the Filters pane"), unknown column ("column T[c] not found in the model"), unreadable default ("filter condition shape not supported",
"Top N definition not recognised", relative-bound errors), unknown ops ("operator X not supported"), Top N "By value" measure that doesn't
compile ("Top N 'By value' measure [m] could not be translated: ..."). Defaults: `_card_default` (an Advanced card is one condition with
`And`/`Or` of Left/Right -> join and two conditions), `_topn_default` (2.6), `_relative_default` (2.7).
2.5 `ordered_cards(filters, sort_order, bundle, warnings, scope, compiler)`: Ascending/Descending by title (case-insensitive), else by
`ordinal` (None last) then authoring order; an unsupported card that has a saved condition adds warning
"<scope> filter '<title>' not applied: <reason>".
2.6 Top N cards: PBIR `From[].Expression.Subquery.Query` with `Top` (n) and `OrderBy[0]` (Direction 1 = bottom) by a Measure or an
Aggregation over a column (implicit aggregate; Count -> DistinctCount, CountNonNull -> Count) -> one condition
`{op: "topn", params: {n, direction, measure | table, column, aggregate}}`; n must be a positive int.
2.7 Relative date/time cards: `Where[0].Condition.Between {LowerBound, UpperBound}` -> `{op: "relative", params: {lower, upper, time,
ui?}}` validated by rendering; `_recognise_relative(params)` adds `ui {direction: last|next|this, n, unit: day|week|month|year|minute|hour,
calendar, include_today}` by trying every combination of `relative_bounds(ui)` (n from the amounts present, and 1) that reproduces the
bounds exactly (None: the filter still applies, the card UI just can't show it). `relative_bounds(ui)` builds the PBIR trees
(`Now`, `DateAdd {Expression, Amount, TimeUnit}`, `DateSpan {Expression, TimeUnit}`; TimeUnit day 0, week 1, month 2, year 3, minute 6,
hour 7): this -> span/span; minutes/hours: last -> [now-n, now], next -> [now, now+n]; calendar (non-day): last -> [span(now-n), span(now-1)],
next -> [span(now+1), span(now+n)]; days-based: last incl. today -> [span(now+1day-n units, day), span(now, day)], excl. today ->
[span(now-n, day), span(now-1day, day)]; next incl. today -> [span(now, day), span(now-1day+n, day)], excl. -> [span(now+1day, day),
span(now+n, day)].
2.8 `card_clauses(card)`: [] for unsupported/(All); each condition -> `FilterClause(table, column, op, values, params, source="<scope>_filter")`;
join "or" with > 1 condition -> one `op="or"` clause with `clauses`.
2.9 `default_filter_clauses(spec, page)` = report cards + the page's cards (hidden and locked included) -> clauses.
`with_default_filters(spec)`: deep copy where every visual's `query`, `draft_query` and `title_query` carry its page's defaults (the spec
itself when nothing applies). Used by validation (`run_validation`), Re-check and the rendering of edited SQL.
2.10 `filter_values_query(table, column, search, limit)`: dim-only QuerySpec on the column, `contains` filter when searching, sorted asc,
`limit + 1` rows (to detect truncation); cards are NOT cross-filtered (Power BI behaviour).
2.11 `bookmark_filter_values(bookmark, spec)`: converts `state.filters` into `state.filter_values = {report: {card: FilterDefault|null},
pages: {page: {card: ...}}, slicers: {visual: [values]}}` (only supported, unlocked cards the spec shows; slicer filters of In conditions ->
values, else []); `filters` removed; bookmarks without filters unchanged. Applied in `compile_dashboard`.
2.12 `compile_dashboard` fills cards (`ordered_cards` with the compiler), pane settings, sync groups and bookmark filter values.

## 3. SQL operators (`runtime/sql_render.py`, shared; must not import `app`)
3.1 `lit(v)`: NULL / TRUE / FALSE / `repr` for numbers / `'..'` with `''`. `null_safe_in_sql` (phase 06 rules).
3.2 `predicate_sql(col, op, values, clauses=None, params=None, today=CURRENT_DATE(), now=CURRENT_TIMESTAMP()) -> str | None`:
in/not_in null-safe; eq/neq (NULL -> IS [NOT] NULL, else `=`/`<>`); gt/gte/lt/lte; contains/not_contains/starts_with/not_starts_with ->
`CAST(col AS VARCHAR) ILIKE '<pattern>' ESCAPE '!'` (case-insensitive; `like_pattern` escapes `%`, `_` and `!` with `!` - a backslash is an
escape in Snowflake literals but not DuckDB's), the `not_*` forms are `(col IS NOT NULL AND NOT (...))` (blanks excluded); is_blank `IS NULL`,
is_not_blank, is_empty `= ''`, is_not_empty `<> ''`; or -> `((a) OR (b))` over the sub-clauses (topn/in_query never inside Or -> None; no
operands -> `1=0`); relative -> `relative_sql`; between_dates `[lo, hi]` (either may be None; both None -> `col IS NOT NULL`); in_query with
`params.token` -> `col IN (<token>)`. Unknown -> None.
3.3 `relative_sql(col, params, today, now)`: anchor = now if `params.time` else today; bounds rendered from the PBIR tree (`Now` -> anchor,
`DateAdd` -> `DATEADD(UNIT, amount, inner)` (integer amounts only), `DateSpan` -> `DATE_TRUNC('UNIT', inner)`, units DAY WEEK MONTH YEAR
SECOND MINUTE HOUR from codes 0,1,2,3,5,6,7; depth <= 10; anything else -> `TemplateError("invalid relative date bound...")`); result
`(col >= lo AND col <= hi)`, or `col < DATEADD(UNIT, 1, hi)` when the upper bound is a DateSpan (exclusive at the next span). Weeks follow
Snowflake's WEEK_START.
3.4 `NO_VALUE_OPS = {is_blank, is_not_blank, is_empty, is_not_empty, or, relative, topn, in_query}`; `clause_needs_values(op)`.
3.5 Engine: `_filter_sql` uses `predicate_sql` with `engine.today_sql` / `engine.now_sql` (defaults the constants; tests pin them); ops that
need a value refuse an empty list; `semantic_view._filter_sql` mirrors the same SQL (Top N / in_query fall back to the compatibility path).
3.6 Top N expansion (`engine._expand_filter_ops`, at the start of `build_sql`): refuse `in_query` anywhere in a request
("unknown filter op in_query"); for each `topn` clause build the ranking query = the key column x the "By value" measure (or implicit aggregate,
alias `__topn_by`) under the query's OTHER non-Top-N filters (not the visual's rows), and replace the clause with
`op=in_query, params.token=<token>` where the token is later substituted (after alias rewriting) by
`SELECT "__topn_key" FROM (<rank sql>) AS "__topn_rank" WHERE "__topn_by" IS NOT NULL QUALIFY RANK() OVER (ORDER BY "__topn_by" DESC|ASC) <= n`
(ties kept, blanks never ranked, a NULL key never in the result). Validation: n positive int, direction top|bottom, a By value field.
Refused in standalone templates ("Top N filters are not available in the standalone dashboard").

## 4. API
4.1 `POST /dashboard/filter-values {connection_id, page?, table, column, search?, limit=500 (1..5000)}` -> `{values, truncated}`; NULL kept
(shown as "(Blank)"); runs `filter_values_query` through `engine.build_sql`; audited as kind `dashboard`, visual `filter-values:<table>.<column>`.
Same route on the published router (`/api/v1/published/dashboard/filter-values`, token-protected like published `/query`).
4.2 Request filters carry an optional `source` (slicer | page_filter | report_filter | cross_filter | drillthrough | tooltip), recorded in the
query audit (Filters sheet) and never in SQL.

## 5. Frontend logic
5.1 `dashboard/filtersPaneState.ts` (NOT `filtersPane.ts`: on Windows it collides with `FiltersPane.tsx` in TS module resolution):
`cardClauses` (TS twin of 2.8), `defaultFilterClauses(spec, page)`; `PaneState = Record<key, {kind, value}>` with
`cardKey = report:<card>` (kept across pages) / `page:<page>:<card>` (per page) for the session; `currentCard` (user value unless
unsupported/locked), `cardValue`, `isModified` (value or kind differs from the saved default), `pageCards`, `paneModified`, `paneClauses`
(hidden/locked cards keep their saved default), `resetPane` (drops this page's keys), `searchCards` (title, case-insensitive),
`BLANK_LABEL="(Blank)"`, `formatValue`, operator lists (text: contains, does not contain, starts with, does not start with, is, is not,
is blank, is not blank, is empty, is not empty; number/date: is less than, is less than or equal to, is greater than, is greater than or equal
to, is, is not, is blank, is not blank; numeric = data types int64/double/decimal/currency/number/integer/datetime/date/time), `cardSummary`
("is Monthly", "is not UNK", "is (All)", "or"/"and" joins, the reason for unsupported cards), `topnText` ("Top 5 by [m]" / "Bottom 3 by Sum of
X"), `relativeText` ("is in the last 2 months (calendar)", "is in this month", "..., including today"), `relativeBounds` (TS twin of 2.7, must
produce identical trees), Basic selection (`inverted` = "Select all" then unchecked items; `basicSelection`, `basicValue` ((All) when inverted
with nothing unchecked), `isChecked`, `toggleValue(sel, v, single)` - Require single selection replaces), `paneWidth(page, report)` = page
width ?? report width ?? 260, `applyBookmarkFilters(spec, filterValues, {pane, slicers, sync})`.
5.2 `interactions.ts::buildVisualQueryFilters(..., globalClauses)`: the page's pane clauses are added to EVERY visual's query, slicers
included, never dropped by NoFilter interactions; cross filters tagged `cross_filter`, slicers `slicer`. Totals and drill reuse the same
per-visual filters. All four callers (DashboardApp, PreviewStep, VisualParity, ReimagineStudio) pass them.
5.3 Synced slicers (`PageCanvas.tsx`): `syncState: Record<group, values>` lives in DashboardApp / PreviewStep;
`applySlicerChange(slicerState, syncState, visual, values)`: a slicer whose group has `filter_changes` writes the group (and clearing to All
clears the group); others write only their own state. `withSlicerDefaults(page, slicerState, syncState)`: every slicer in a group gets the
group's selection on any page, hidden or not; unsynced slicers keep page-local state, which resets on page change; `fieldChanges`-only
groups don't share selections. Saved slicer selections (phase 09 `default_selection`) apply until changed.

## 6. Filters pane UI (`dashboard/FiltersPane.tsx`)
- Not shown when `filter_pane.visible === false`. Collapsed state: a vertical "Filters" tab with `<<` running the full height on the right
  edge; opens per `expanded` (page setting, else report; collapsed when false) at `paneWidth`; `>>` collapses. A dot indicator when anything
  differs from the default; "Reset to default" (whole pane); a search box over card titles.
- Sections "Filters on this page" and "Filters on all pages" (collapsible); cards in spec order; hidden cards not rendered; locked cards
  read-only with a lock icon; unsupported cards show their reason; a read-only "Drill through" section (phase 11).
- Card collapsed: chevron, title, one-line summary, eraser (clear to default (All)), lock. Expanded Basic: search, "Select all", check list
  with "(Blank)", "Require single selection" honoured; values load lazily from `filter-values` when expanded (max 500, "use search" beyond).
  Advanced: two conditions with And/Or and "Apply filter", operator lists per data type. Basic <-> Advanced switch only when
  `allow_change_filter_types`. Top N: "Show items" Top/Bottom, N, "By value", "Apply filter". Relative date/time: last/next/this, N, unit,
  calendar, include today, "Apply filter".
- Styling from `filter_pane.colours` (outspacePane background/foreground/border, filterCard Available/Applied) when set.
- Layout: DashboardApp's page area is a flex row (`data-testid="canvas-column"` + pane). The studio layout has a fixed height
  (`data-testid="dashboard-root"`: `h-screen overflow-hidden`; `<main>` `min-h-0 flex-1`): the window never scrolls; the canvas column is
  `overflow-auto`; the pane is `h-full min-h-0` with its card list (`filters-scroll`) and each Basic value list `overflow-y-auto
  overscroll-contain`. PageCanvas rescales from its parent width, so opening/closing the pane refits the page.
- Shown on the full dashboard tab (`#/dashboard/<conversion>/<connection>`), the published dashboard and the standalone dashboard; Preview
  and Visual Parity apply the defaults without showing the pane.
- `DashboardApp.applyBookmark`: bookmarks with `filter_values` restore pane values and slicer/sync state via `applyBookmarkFilters`; bookmarks
  without (Data off) leave filters as they are. The pane's open/closed state isn't restored.

## Files
Create: `backend/app/runtime/sql_render.py`, `frontend/src/dashboard/filtersPaneState.ts`, `frontend/src/dashboard/FiltersPane.tsx`.
Modify: `ir/report.py`, `parsers/pbir.py`, `runtime/dashboard.py`, `runtime/engine.py`, `runtime/semantic_view.py`, `dax/visual_query.py`
(render new ops as DAX), `api/dashboards.py`, `api/published_dashboards.py`, `services/query_audit.py`, `agents/pipeline.py`
(validation uses defaults), `validation/harness.py`, frontend `dashboard/{types,api,interactions,PageCanvas,DashboardApp}.ts(x)`,
`steps/{PreviewStep,VisualParity}.tsx`, `pages/ReimagineStudio.tsx`.

## Tests
Backend: `test_global_filters.py` (parser reads card fields, sync groups, pane; cards ordered, hidden/locked kept, drill-through excluded;
default clauses reach every visual query incl. draft/title; spec without defaults returned as is; passthrough fills a stored bundle;
unsupported saved filter reported; Advanced Or card -> one or clause; bookmark filter state), `test_filter_operators.py` (DuckDB: every
operator row incl. NULL vs '' and case-insensitivity; Or of two conditions; like-pattern escapes wildcards; value-needing ops refuse none;
template renders the new ops; semantic view uses the same predicates; filter_values_query keeps blank, sorts, searches; endpoint truncates
and audits; audit records each filter's source), `test_topn_relative_cards.py` (DuckDB, pinned today: top 2 keeps the tie at the cut; top
1; bottom N ignores blanks; ranked under the other filters; independent of the visual rows; implicit aggregate; invalid/injected Top N
refused; Top N card from PBIR; relative day / month / year windows; relative filter on a fact measure; card from PBIR with recognised
settings; relative time last hours), re-check includes the default page filters.
Frontend: `filtersPane.test.tsx`, `filtersPhase3.test.tsx`, `syncSlicers.test.tsx`, `interactions.test.ts` with the cases listed in
sections 5-6 (summaries; hidden/locked defaults vs user values and reset; Or card; search; select-all inversion and single selection; starts
collapsed at page width; hidden pane; report width fallback; sections collapse; Basic lazy values/(Blank)/search/select all/single/dot/reset;
Advanced two conditions with Or applied on "Apply filter"; Basic <-> Advanced only when allowed; canvas column shares the row and pane values
reach every query; `relativeBounds` matches the backend shapes; Top N "Bottom 5" applied; relative "last 2 calendar months"; bookmarks restore
pane and sync state, Data-off bookmarks keep filters; synced selection follows to another page incl. hidden synced slicers, unsynced reset;
clearing a synced slicer clears the group).

## Done criteria
Defaults apply everywhere (dashboard, validation, re-check, edited SQL); the pane works on the full dashboard tab and published view; tests pass.
 