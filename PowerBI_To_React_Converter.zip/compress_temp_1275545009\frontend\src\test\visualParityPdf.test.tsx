import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { MemoryRouter } from 'react-router-dom'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { fmtTime } from '../components/fmtTime'
import { Jobs } from '../pages/Jobs'
import { VisualParity } from '../steps/VisualParity'
import { comparison, values } from './parityFixtures'

const spec = {
  report_name: 'Demo',
  pages: [{ name: 'p1', display_name: 'Overview', width: 1200, height: 800, ordinal: 0, visuals: [] }],
  warnings: [],
  measure_tiers: {},
  theme: { data_colors: [], text_classes: {} },
  interaction_graph: { nodes: [], edges: [], sync_groups: {} },
  bookmarks: [],
  drill_through: [],
}

function renderParity() {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <VisualParity conversionId="conv-1" connectionId="conn-1" />
    </QueryClientProvider>,
  )
}

afterEach(() => vi.unstubAllGlobals())

describe('VisualParity PDF comparison additions', () => {
  it('uploads with content matching, lists matches and warnings, and shows the numbers panel', async () => {
    let uploadUrl = ''
    vi.stubGlobal('ResizeObserver', class { observe() {} disconnect() {} unobserve() {} })
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        const json = (b: unknown) => new Response(JSON.stringify(b))
        if (url.endsWith('/dashboard/spec')) return json(spec)
        if (url.includes('/reference-pdf')) {
          uploadUrl = url
          expect(init?.method).toBe('POST')
          return json({
            mode: 'content',
            pdf_pages: 2,
            report_pages: 1,
            superseded_comparisons: 0,
            references_stored: [{ page: 'p1', display_name: 'Overview' }],
            matches: [
              { pdf_page: 1, page: 'p1', display_name: 'Overview', score: 0.62, confident: false },
              { pdf_page: 2, page: null, display_name: '', score: 0, confident: false },
            ],
            warnings: ['PDF page 2 matched nothing'],
          })
        }
        if (url.endsWith('/visual-compare/references'))
          return json({ pages: [{ page: 'p1', display_name: 'Overview', has_reference: true }] })
        if (url.endsWith('/visual-compare'))
          return json({ pages: [{ ...comparison, page: 'p1', values }] })
        return new Response(JSON.stringify({ detail: 'unexpected ' + url }), { status: 404 })
      }),
    )
    const user = userEvent.setup()
    const { container } = renderParity()

    // the stored number check is shown next to the comparison
    expect(await screen.findByTestId('numbers-panel')).toBeInTheDocument()
    expect(screen.getByText('2 of 3 printed numbers matched')).toBeInTheDocument()
    expect(screen.getByRole('combobox', { name: 'Page' })).toHaveTextContent('Overview')

    await user.click(screen.getByLabelText('Match pages by content'))
    await user.upload(
      container.querySelector('input[accept="application/pdf"]') as HTMLInputElement,
      new File(['%PDF'], 'export.pdf', { type: 'application/pdf' }),
    )
    expect(await screen.findByTestId('upload-result')).toHaveTextContent('matched by content')
    expect(uploadUrl).toContain('reference-pdf?match=true')
    expect(screen.getByText('PDF page 2 matched nothing')).toBeInTheDocument()
    expect(screen.getByText(/62% · low confidence/)).toBeInTheDocument()
  })
})

describe('Jobs uses the shared fmtTime', () => {
  it('renders upload times through fmtTime', async () => {
    const uploaded = 1_700_000_000
    vi.stubGlobal(
      'fetch',
      vi.fn(async () =>
        new Response(
          JSON.stringify([
            {
              id: 'aaa11111-1111-1111-1111-111111111111',
              name: 'Alpha',
              report: 'Alpha Report',
              pages: 2,
              visuals: 8,
              measures: 10,
              status: 'complete',
              fidelity: 0.95,
              uploaded_at: uploaded,
              converted_at: null,
              accelerated: false,
            },
          ]),
        ),
      ),
    )
    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
    render(
      <QueryClientProvider client={qc}>
        <MemoryRouter>
          <Jobs />
        </MemoryRouter>
      </QueryClientProvider>,
    )
    expect((await screen.findAllByText(fmtTime(uploaded), { exact: false })).length).toBeGreaterThan(0)
  })
})
