"""Match the pages of a Power BI PDF export to report pages (and the PDF to a report) by content.

The words printed on a PDF page are compared with each report page's label fingerprint
(`page_fingerprint`): TF-IDF cosine similarity plus page-name / text-box terms, aspect ratio and a
small order bonus, assigned one-to-one. A weak match is never forced: the page stays unmatched
and the best guess is only reported as a runner-up.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from app.services.page_fingerprint import PageFingerprint, ReportFingerprint
from app.services.pdf_text import PdfPageText, label_tokens

PAGE_MIN_SCORE = 0.30
PAGE_CONFIDENT = 0.45
PAGE_MARGIN = 0.05
REPORT_CONFIDENT = 0.40
REPORT_MARGIN = 0.08
TITLE_WEIGHT = 0.3
ASPECT_WEIGHT = 0.15
ORDER_BONUS = 0.02
NAME_BONUS = 0.1
EXTRA_PAGE_PENALTY = 0.1


@dataclass
class PageMatch:
    pdf_page: int
    page: str | None
    display_name: str | None
    score: float
    confident: bool
    runner_up: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "pdf_page": self.pdf_page, "page": self.page, "display_name": self.display_name,
            "score": round(self.score, 4), "confident": self.confident, "runner_up": self.runner_up,
        }  # fmt: skip


@dataclass
class ReportMatch:
    conversion_id: str
    report: str
    job_name: str | None
    uploaded_at: float
    converted_at: float | None
    score: float
    pages: list[PageMatch] = field(default_factory=list)
    report_pages: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "conversion_id": self.conversion_id, "report": self.report, "job_name": self.job_name,
            "uploaded_at": self.uploaded_at, "converted_at": self.converted_at,
            "score": round(self.score, 4), "pages": [p.to_dict() for p in self.pages],
            "report_pages": self.report_pages,
        }  # fmt: skip


@dataclass
class PdfMatch:
    file: str
    pdf_pages: int
    confident: bool
    warnings: list[str]
    candidates: list[ReportMatch]

    def to_dict(self) -> dict[str, Any]:
        return {
            "file": self.file, "pdf_pages": self.pdf_pages, "confident": self.confident,
            "warnings": self.warnings, "candidates": [c.to_dict() for c in self.candidates],
        }  # fmt: skip


# ------------------------------------------------------------------ assignment


def hungarian_max(score: list[list[float]]) -> list[int]:
    """Row -> column of the maximum-total one-to-one assignment (Kuhn-Munkres on the padded
    square matrix); -1 for a row left to a padding column. Pure Python, no scipy."""
    rows = len(score)
    cols = len(score[0]) if rows else 0
    n = max(rows, cols)
    if n == 0:
        return []
    cost = [[0.0] * (n + 1) for _ in range(n + 1)]
    for i in range(rows):
        for j in range(cols):
            cost[i + 1][j + 1] = -score[i][j]
    inf = float("inf")
    u, v = [0.0] * (n + 1), [0.0] * (n + 1)
    p, way = [0] * (n + 1), [0] * (n + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv = [inf] * (n + 1)
        used = [False] * (n + 1)
        while True:
            used[j0] = True
            i0, delta, j1 = p[j0], inf, 0
            for j in range(1, n + 1):
                if used[j]:
                    continue
                cur = cost[i0][j] - u[i0] - v[j]
                if cur < minv[j]:
                    minv[j], way[j] = cur, j0
                if minv[j] < delta:
                    delta, j1 = minv[j], j
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
            if j0 == 0:
                break
    result = [-1] * rows
    for j in range(1, n + 1):
        i = p[j]
        if 1 <= i <= rows and j <= cols:
            result[i - 1] = j - 1
    return result


# ------------------------------------------------------------------ scoring


def _idf(pages: list[PageFingerprint]) -> dict[str, float]:
    n = len(pages)
    df: Counter[str] = Counter()
    for p in pages:
        df.update(set(p.words))
    return {w: math.log((1 + n) / (1 + c)) + 1 for w, c in df.items()}


def _vector(tokens: list[str], idf: dict[str, float], unseen: float) -> dict[str, float]:
    return {w: c * idf.get(w, unseen) for w, c in Counter(tokens).items()}


def _cosine(a: dict[str, float], b: dict[str, float]) -> float:
    dot = sum(x * b.get(w, 0.0) for w, x in a.items())
    na = math.sqrt(sum(x * x for x in a.values()))
    nb = math.sqrt(sum(x * x for x in b.values()))
    return dot / (na * nb) if na and nb else 0.0


def pdf_page_tokens(page: PdfPageText) -> list[str]:
    return label_tokens(" ".join(r.text for r in page.runs))


def score_matrix(pdf_pages: list[PdfPageText], pages: list[PageFingerprint]) -> list[list[float]]:
    idf = _idf(pages)
    unseen = math.log(1 + len(pages)) + 1
    page_vecs = [_vector(p.words, idf, unseen) for p in pages]
    matrix: list[list[float]] = []
    for i, pdf in enumerate(pdf_pages):
        tokens = pdf_page_tokens(pdf)
        present = set(tokens)
        vec = _vector(tokens, idf, unseen)
        row = []
        for j, page in enumerate(pages):
            s = _cosine(vec, page_vecs[j])
            if page.title_tokens:
                s += (
                    TITLE_WEIGHT
                    * sum(t in present for t in page.title_tokens)
                    / len(page.title_tokens)
                )
            if pdf.aspect > 0 and page.aspect > 0:
                off = abs(math.log(pdf.aspect / page.aspect))
                s += ASPECT_WEIGHT * max(0.0, 1 - off / 0.1)
            if i == j:
                s += ORDER_BONUS
            row.append(s)
        matrix.append(row)
    return matrix


def match_pages(pdf_pages: list[PdfPageText], pages: list[PageFingerprint]) -> list[PageMatch]:
    """One PageMatch per PDF page. A page below PAGE_MIN_SCORE (or left unassigned) stays
    unmatched with its best guess as `runner_up`; it is never forced."""
    if not pdf_pages:
        return []
    if not pages:
        return [PageMatch(p.index, None, None, 0.0, False) for p in pdf_pages]
    matrix = score_matrix(pdf_pages, pages)
    assigned = hungarian_max(matrix)
    out: list[PageMatch] = []
    for i, pdf in enumerate(pdf_pages):
        row = matrix[i]
        order = sorted(range(len(pages)), key=lambda j: -row[j])
        j = assigned[i]
        if j < 0 or j >= len(pages) or row[j] < PAGE_MIN_SCORE:
            guess = order[0]
            out.append(
                PageMatch(
                    pdf.index, None, None, row[j] if 0 <= j < len(pages) else 0.0, False,
                    {"page": pages[guess].page, "display_name": pages[guess].display_name,
                     "score": round(row[guess], 4)},
                )
            )  # fmt: skip
            continue
        others = [k for k in order if k != j]
        lead = row[j] - row[others[0]] if others else row[j]
        runner = (
            {"page": pages[others[0]].page, "display_name": pages[others[0]].display_name,
             "score": round(row[others[0]], 4)}
            if others
            else None
        )  # fmt: skip
        out.append(
            PageMatch(
                pdf.index, pages[j].page, pages[j].display_name, row[j],
                row[j] >= PAGE_CONFIDENT and lead >= PAGE_MARGIN, runner,
            )
        )  # fmt: skip
    return out


def _name_tokens(file_name: str, pdf_title: str | None) -> set[str]:
    stem = re.sub(r"\.pdf$", "", file_name, flags=re.I)
    return set(label_tokens(re.sub(r"[_\-.]+", " ", stem) + " " + (pdf_title or "")))


def match_pdf(
    file_name: str,
    pages: list[PdfPageText],
    reports: list[ReportFingerprint],
    pdf_title: str | None = None,
    top: int = 3,
) -> PdfMatch:
    """Rank stored reports for one PDF: mean matched-page score + a file/title name bonus - a
    penalty for PDF pages beyond the report's page count."""
    warnings: list[str] = []
    if not reports:
        warnings.append("no stored reports to match against; upload and convert a report first")
        return PdfMatch(file_name, len(pages), False, warnings, [])
    if pages and not any(p.runs for p in pages):
        warnings.append("the PDF has no text (scanned?), so pages must be matched by hand")
    names = _name_tokens(file_name, pdf_title)
    n = max(len(pages), 1)
    ranked: list[ReportMatch] = []
    for rep in reports:
        matches = match_pages(pages, rep.pages)
        matched = sum(m.score for m in matches if m.page is not None)
        report_tokens = set(label_tokens(rep.report))
        bonus = (
            NAME_BONUS * len(report_tokens & names) / len(report_tokens) if report_tokens else 0.0
        )
        extra = max(0, len(pages) - len(rep.pages))
        score = matched / n + bonus - EXTRA_PAGE_PENALTY * extra / n
        ranked.append(
            ReportMatch(
                rep.conversion_id, rep.report, rep.job_name, rep.uploaded_at, rep.converted_at,
                score, matches,
                [{"page": p.page, "display_name": p.display_name, "ordinal": p.ordinal}
                 for p in rep.pages],
            )
        )  # fmt: skip
    ranked.sort(key=lambda r: (-round(r.score, 6), -(r.converted_at or r.uploaded_at or 0)))
    candidates = ranked[: max(top, 1)]
    best = candidates[0]
    lead = best.score - (candidates[1].score if len(candidates) > 1 else 0.0)
    confident = best.score >= REPORT_CONFIDENT and lead >= REPORT_MARGIN
    if len(candidates) > 1 and abs(lead) < 1e-9:
        warnings.append("several reports score equally; the newest job is listed first")
    if not confident:
        listing = "; ".join(f"{c.report} ({c.score:.2f})" for c in candidates)
        warnings.append(f"no confident report match; check the candidates: {listing}")
    return PdfMatch(file_name, len(pages), confident, warnings, candidates)
