"""Live-connected (byConnection) reports with a shipped TMDL / TMSL model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import pytest

from app.parsers.bundle import EXPORT_HINT, load_pbip
from app.parsers.pbir import (
    PbirParseError,
    RemoteModelRef,
    parse_remote_reference,
    read_dataset_reference,
    resolve_dataset_reference,
)
from app.parsers.tmsl import load_tmsl, write_tmdl_from_tmsl

CONN = (
    "Data Source=powerbi://api.powerbi.com/v1.0/myorg/Sales%20Workspace;"
    'Initial Catalog="Sales; Model";semanticmodelid=abc-123'
)


def _bim(name="Sales Model", extra_measure=True) -> dict:
    measures = [{"name": "Total", "expression": ["SUM(Sales[Amount])"], "formatString": "0.00"}]
    return {
        "name": name,
        "compatibilityLevel": 1600,
        "model": {
            "culture": "en-US",
            "tables": [
                {
                    "name": "Sales",
                    "lineageTag": "t1",
                    "columns": [
                        {"name": "RowNumber-2662979B", "type": "rowNumber", "dataType": "int64"},
                        {
                            "name": "Amount",
                            "dataType": "double",
                            "sourceColumn": "AMOUNT",
                            "summarizeBy": "sum",
                            "isHidden": True,
                            "description": "line amount",
                        },
                        {"name": "Key", "dataType": "int64", "sourceColumn": "KEY", "isKey": True},
                        {
                            "name": "Calc",
                            "type": "calculated",
                            "dataType": "double",
                            "expression": ["Sales[Amount] * 2"],
                        },
                    ],
                    "measures": measures if extra_measure else [],
                    "hierarchies": [
                        {
                            "name": "H",
                            "levels": [{"name": "L1", "ordinal": 0, "column": "Key"}],
                        }
                    ],
                    "partitions": [
                        {
                            "name": "p",
                            "mode": "import",
                            "source": {
                                "type": "m",
                                "expression": [
                                    "let",
                                    '    Source = Snowflake.Databases("a.snowflakecomputing.com","WH"),',
                                    '    D = Source{[Name="DB",Kind="Database"]}[Data],',
                                    '    S = D{[Name="PUB",Kind="Schema"]}[Data],',
                                    '    T = S{[Name="SALES",Kind="Table"]}[Data]',
                                    "in",
                                    "    T",
                                ],
                            },
                        }
                    ],
                },
                {"name": "Dim Product", "columns": [{"name": "Id", "dataType": "int64"}]},
            ],
            "relationships": [
                {
                    "name": "r1",
                    "fromTable": "Sales",
                    "fromColumn": "Key",
                    "toTable": "Dim Product",
                    "toColumn": "Id",
                    "crossFilteringBehavior": "bothDirections",
                    "isActive": False,
                }
            ],
            "roles": [
                {
                    "name": "Reader",
                    "modelPermission": "read",
                    "tablePermissions": [{"name": "Sales", "filterExpression": "Sales[Key] = 1"}],
                }
            ],
            "expressions": [{"name": "P1", "kind": "m", "expression": '"x" meta [IsParameterQuery=true]'}],
        },
    }


def _make_pbip(root: Path, definition: dict) -> None:
    (root / "R.Report" / "definition" / "pages" / "pg").mkdir(parents=True)
    (root / "R.pbip").write_text(json.dumps({"artifacts": [{"report": {"path": "R.Report"}}]}))
    (root / "R.Report" / "definition.pbir").write_text(json.dumps({"datasetReference": definition}))
    (root / "R.Report" / "definition" / "report.json").write_text("{}")
    (root / "R.Report" / "definition" / "pages" / "pages.json").write_text(
        json.dumps({"pageOrder": ["pg"]})
    )
    (root / "R.Report" / "definition" / "pages" / "pg" / "page.json").write_text(
        json.dumps({"name": "pg", "displayName": "Page"})
    )


def _by_connection(**over) -> dict:
    conn = {"connectionString": CONN, "pbiModelDatabaseName": "abc-123", "name": "EntityDataSource"}
    conn.update(over)
    return {"byConnection": conn}


def test_connection_string_parsing_with_quoted_semicolons():
    ref = parse_remote_reference(_by_connection()["byConnection"])
    assert ref.model_name == "Sales; Model"
    assert ref.model_id == "abc-123"
    assert ref.workspace == "Sales Workspace"
    assert ref.describe() == "remote semantic model 'Sales; Model' in workspace 'Sales Workspace'"
    assert RemoteModelRef().describe() == "remote semantic model 'unknown'"


def test_by_connection_without_model_raises_with_hint(tmp_path):
    _make_pbip(tmp_path, _by_connection())
    with pytest.raises(PbirParseError) as e:
        load_pbip(tmp_path, generated_dir=tmp_path / "gen")
    assert "live-connected (byConnection)" in str(e.value) and EXPORT_HINT in str(e.value)
    ref = read_dataset_reference(tmp_path / "R.Report")
    assert isinstance(ref, RemoteModelRef)
    with pytest.raises(PbirParseError, match=r"include an export of that model in the upload"):
        resolve_dataset_reference(tmp_path / "R.Report")


def test_by_connection_with_tmsl_bim_converts_into_generated_dir(tmp_path):
    upload = tmp_path / "upload"
    upload.mkdir()
    _make_pbip(upload, _by_connection())
    (upload / "Sales Model.bim").write_text(json.dumps(_bim()), encoding="utf-8-sig")
    gen = tmp_path / "gen"
    bundle = load_pbip(upload, generated_dir=gen)
    assert (gen / "Sales Model.SemanticModel" / "definition" / "model.tmdl").is_file()
    assert not list(upload.rglob("definition/model.tmdl"))  # nothing written into the upload
    assert any("(TMSL converted to TMDL)" in w and "live-connected" in w for w in bundle.warnings)
    sales = bundle.model.table("Sales")
    assert sales is not None
    assert [c.name for c in sales.columns] == ["Amount", "Key", "Calc"]  # rowNumber skipped
    amount = sales.column("Amount")
    assert amount.is_hidden and amount.source_column == "AMOUNT"
    assert sales.column("Calc").expression == "Sales[Amount] * 2"
    assert sales.measure("Total").expression == "SUM(Sales[Amount])"
    assert sales.hierarchies[0].levels[0].column == "Key"
    assert "Snowflake.Databases" in sales.partitions[0].expression
    rel = bundle.model.relationships[0]
    assert (rel.from_table, rel.to_table, rel.is_active) == ("Sales", "Dim Product", False)
    assert rel.cross_filtering_behavior == "bothDirections"
    assert bundle.model.roles[0].table_permissions == {"Sales": "Sales[Key] = 1"}
    assert bundle.model.expressions["P1"].startswith('"x"')


def test_by_connection_with_tmdl_folder(tmp_path, contoso_pbip):
    upload = tmp_path / "upload"
    shutil.copytree(contoso_pbip, upload)
    report_dir = next(upload.glob("*.Report"))
    pbir = report_dir / "definition.pbir"
    os_mode = pbir.stat().st_mode
    pbir.chmod(os_mode | 0o200)
    pbir.write_text(json.dumps({"datasetReference": _by_connection(name="Contoso Sales")}))
    bundle = load_pbip(upload, generated_dir=tmp_path / "gen")
    assert any("rebound to the uploaded model" in w and "SemanticModel" in w for w in bundle.warnings)
    assert bundle.model.tables


def test_several_models_matched_by_catalog_name(tmp_path):
    upload = tmp_path / "upload"
    upload.mkdir()
    _make_pbip(upload, _by_connection(connectionString="Initial Catalog=Alpha"))
    (upload / "Alpha.bim").write_text(json.dumps(_bim("Alpha")))
    (upload / "Beta.bim").write_text(json.dumps(_bim("Beta", extra_measure=False)))
    bundle = load_pbip(upload, generated_dir=tmp_path / "gen")
    assert bundle.model.table("Sales").measure("Total") is not None
    assert (tmp_path / "gen" / "Alpha.SemanticModel").is_dir()
    assert not (tmp_path / "gen" / "Beta.SemanticModel").exists()


def test_ambiguous_models_error_text(tmp_path):
    upload = tmp_path / "upload"
    upload.mkdir()
    _make_pbip(upload, _by_connection(connectionString="Initial Catalog=Gamma"))
    (upload / "Alpha.bim").write_text(json.dumps(_bim("Alpha")))
    (upload / "Beta.bim").write_text(json.dumps(_bim("Beta")))
    with pytest.raises(PbirParseError, match="none could be matched unambiguously"):
        load_pbip(upload, generated_dir=tmp_path / "gen")


def test_unreadable_model_files_are_listed(tmp_path):
    upload = tmp_path / "upload"
    upload.mkdir()
    _make_pbip(upload, _by_connection())
    (upload / "broken.bim").write_text("{not json")
    with pytest.raises(PbirParseError, match="Unreadable model files: broken.bim"):
        load_pbip(upload, generated_dir=tmp_path / "gen")


def test_ssms_xmla_script(tmp_path):
    upload = tmp_path / "upload"
    upload.mkdir()
    _make_pbip(upload, _by_connection())
    script = {"createOrReplace": {"object": {"database": "Sales Model"}, "database": _bim()}}
    (upload / "script.xmla").write_text(json.dumps(script))
    bundle = load_pbip(upload, generated_dir=tmp_path / "gen")
    assert bundle.model.table("Sales") is not None


def test_local_bim_model_converted_with_warning(tmp_path):
    upload = tmp_path / "upload"
    (upload / "X.SemanticModel").mkdir(parents=True)
    _make_pbip(upload, {"byPath": {"path": "../X.SemanticModel"}})
    (upload / "X.SemanticModel" / "model.bim").write_text(json.dumps(_bim()))
    bundle = load_pbip(upload, generated_dir=tmp_path / "gen")
    assert any("semantic model was TMSL (model.bim); converted to TMDL at" in w for w in bundle.warnings)
    assert bundle.model.table("Sales") is not None


def test_existing_nonempty_target_is_an_error(tmp_path):
    upload = tmp_path / "upload"
    upload.mkdir()
    _make_pbip(upload, _by_connection())
    (upload / "Sales Model.bim").write_text(json.dumps(_bim()))
    gen = tmp_path / "gen"
    load_pbip(upload, generated_dir=gen)
    with pytest.raises(PbirParseError, match="already exists"):
        load_pbip(upload, generated_dir=gen)


def test_tmsl_names_and_duplicate_files(tmp_path):
    db = _bim()
    db["model"]["tables"].append({"name": "sales", "columns": [{"name": "A"}]})
    write_tmdl_from_tmsl(db, tmp_path / "def")
    names = sorted(p.name for p in (tmp_path / "def" / "tables").iterdir())
    assert names == ["Dim Product.tmdl", "Sales.tmdl", "sales_2.tmdl"]
    text = (tmp_path / "def" / "tables" / "Dim Product.tmdl").read_text()
    assert text.startswith("table 'Dim Product'")


def test_load_tmsl_shapes(tmp_path):
    f = tmp_path / "a.bim"
    f.write_text(json.dumps({"model": {"tables": []}}))
    assert "model" in load_tmsl(f)
    f.write_text(json.dumps({"tables": []}))
    assert load_tmsl(f)["model"] == {"tables": []}
    f.write_text("[]")
    from app.parsers.tmdl import TmdlParseError

    with pytest.raises(TmdlParseError):
        load_tmsl(f)
