import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { SqlEditor } from '../steps/SqlEditor'
import { useWizard } from '../store/wizard'

function wrap(ui: React.ReactElement) {
  const qc = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  })
  return render(<QueryClientProvider client={qc}>{ui}</QueryClientProvider>)
}

const editorInfo = (override: unknown = null) => ({
  page: 'p1',
  visual: 'v1',
  pane: 'Sales by category',
  base_sql: 'SELECT generated',
  base_error: null,
  expected_columns: ['Product.Category', 'Total Sales'],
  filter_tables: [{ table: 'Product', alias: '"Product"' }],
  override,
})

const okResult = (over = {}) => ({
  rendered_sql: 'SELECT rendered',
  unapplied_filter_tables: [],
  has_filters_placeholder: true,
  null_comparison_warnings: [],
  expected_columns: ['Product.Category', 'Total Sales'],
  columns: ['Product.Category', 'Total Sales'],
  rows: [['A', 1]],
  row_count: 1,
  elapsed_ms: 12,
  query_id: 'q1',
  error: null,
  missing_columns: [],
  ...over,
})

let requests: { url: string; method: string; body?: string }[] = []

function mockApi(opts: { override?: unknown; test?: () => unknown } = {}) {
  requests = []
  vi.stubGlobal(
    'fetch',
    vi.fn(async (url: string, init?: RequestInit) => {
      const method = init?.method ?? 'GET'
      requests.push({ url: String(url), method, body: init?.body as string | undefined })
      if (String(url).includes('/sql-overrides/test'))
        return new Response(JSON.stringify(opts.test ? opts.test() : okResult()))
      if (method === 'PUT') return new Response(JSON.stringify({ override: {} }))
      if (method === 'DELETE') return new Response(JSON.stringify({ deleted: true }))
      return new Response(JSON.stringify(editorInfo(opts.override ?? null)))
    }),
  )
}

describe('SqlEditor', () => {
  beforeEach(() => {
    useWizard.getState().reset()
    useWizard.setState({ conversionId: 'c1', connectionId: 'conn-1' })
  })
  afterEach(() => vi.restoreAllMocks())

  it('shows the generated SQL, expected columns and filter tables', async () => {
    mockApi()
    wrap(<SqlEditor page="p1" visual="v1" />)
    const editor = await screen.findByTestId('sql-editor')
    expect(editor.textContent).toContain('SELECT generated')
    expect(editor.textContent).toContain('Product.Category, Total Sales')
    expect(editor.textContent).toContain('Product')
    expect((screen.getByLabelText('Edited SQL') as HTMLTextAreaElement).value).toBe('SELECT generated')
  })

  it('saves only after a successful run of the exact current text', async () => {
    mockApi()
    wrap(<SqlEditor page="p1" visual="v1" />)
    await screen.findByTestId('sql-editor')
    const save = screen.getByRole('button', { name: 'Save' }) as HTMLButtonElement
    expect(save.disabled).toBe(true)
    expect(screen.getByText('Run the current SQL successfully first')).toBeTruthy()
    await userEvent.click(screen.getByRole('button', { name: 'Run' }))
    expect(await screen.findByTestId('sql-test-result')).toBeTruthy()
    await waitFor(() => expect((screen.getByRole('button', { name: 'Save' }) as HTMLButtonElement).disabled).toBe(false))
    // any edit invalidates the run
    await userEvent.type(screen.getByLabelText('Edited SQL'), ' ')
    expect((screen.getByRole('button', { name: 'Save' }) as HTMLButtonElement).disabled).toBe(true)
    await userEvent.click(screen.getByRole('button', { name: 'Run' }))
    await waitFor(() => expect((screen.getByRole('button', { name: 'Save' }) as HTMLButtonElement).disabled).toBe(false))
    await userEvent.click(screen.getByRole('button', { name: 'Save' }))
    await waitFor(() => expect(requests.some((r) => r.method === 'PUT')).toBe(true))
    const put = requests.find((r) => r.method === 'PUT')!
    expect(JSON.parse(put.body!).sql).toBe('SELECT generated ')
  })

  it('missing columns block saving', async () => {
    mockApi({ test: () => okResult({ columns: ['Total Sales'], missing_columns: ['Product.Category'] }) })
    wrap(<SqlEditor page="p1" visual="v1" />)
    await screen.findByTestId('sql-editor')
    await userEvent.click(screen.getByRole('button', { name: 'Run' }))
    const result = await screen.findByTestId('sql-test-result')
    expect(result.textContent).toContain('Missing columns: Product.Category')
    expect((screen.getByRole('button', { name: 'Save' }) as HTMLButtonElement).disabled).toBe(true)
  })

  it('an error blocks saving and shows the warnings', async () => {
    mockApi({
      test: () =>
        okResult({
          error: 'invalid identifier',
          null_comparison_warnings: ['`col <> NULL` is never true: use `col IS NOT NULL`'],
          unapplied_filter_tables: ['Customer'],
        }),
    })
    wrap(<SqlEditor page="p1" visual="v1" />)
    await screen.findByTestId('sql-editor')
    await userEvent.click(screen.getByRole('button', { name: 'Run' }))
    const result = await screen.findByTestId('sql-test-result')
    expect(result.textContent).toContain('invalid identifier')
    expect(screen.getByTestId('null-comparison-warnings').textContent).toContain('IS NOT NULL')
    expect(result.textContent).toContain('Customer')
    expect((screen.getByRole('button', { name: 'Save' }) as HTMLButtonElement).disabled).toBe(true)
  })

  it('cannot run without a connection', async () => {
    useWizard.setState({ connectionId: null })
    mockApi()
    wrap(<SqlEditor page="p1" visual="v1" />)
    await screen.findByTestId('sql-editor')
    expect((screen.getByRole('button', { name: 'Run' }) as HTMLButtonElement).disabled).toBe(true)
    expect(screen.getByText('Select a Snowflake connection first')).toBeTruthy()
  })

  it('reverts a saved edit', async () => {
    mockApi({ override: { sql: 'SELECT mine', base_sql: 'SELECT generated', saved_at: 1 } })
    wrap(<SqlEditor page="p1" visual="v1" />)
    await screen.findByTestId('sql-editor')
    expect((screen.getByLabelText('Edited SQL') as HTMLTextAreaElement).value).toBe('SELECT mine')
    await userEvent.click(screen.getByRole('button', { name: 'Revert to generated SQL' }))
    await waitFor(() => expect(requests.some((r) => r.method === 'DELETE')).toBe(true))
    expect(requests.find((r) => r.method === 'DELETE')!.url).toContain('/sql-overrides/p1/v1')
  })
})
