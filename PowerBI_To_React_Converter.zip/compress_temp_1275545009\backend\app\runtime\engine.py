"""Semantic runtime: QuerySpec -> Snowflake SQL.

Reproduces Power BI's evaluation shape for tier-0/1 measures:

1. Compile each measure to leaves (aggregate expression + Context).
2. Group leaves by Context; each group is one subquery: fact table joined
   along active many->one relationship paths, WHERE from visual/slicer
   filters plus CALCULATE predicates (minus cleared tables), GROUP BY the
   visual's dimension keys.
3. Time shifts join the date dimension twice:
     fact -> d_data (relationship join: rows feeding the aggregate)
     d_cur (rows carrying the visual's date grain/filters), connected by
       sply:    d_data.date = DATEADD(year, -1, d_cur.date)
       ytd:     YEAR(d_data.date) = YEAR(d_cur.date) AND d_data.date <= d_cur.date
       rolling: d_data.date >  DATEADD(unit, -n, d_cur.date) AND <= d_cur.date
   With no date column in the grain, ytd/rolling anchor to a scalar
   (SELECT MAX(date) ... under the context's date filters) instead.
4. Subqueries FULL OUTER JOIN on grain keys; combiners compute final values.

Filters on tables unreachable from a leaf's fact are dropped for that leaf
(single-direction cross-filter semantics) and surfaced as warnings.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from heapq import heappop, heappush

from pydantic import BaseModel, Field

from app.binding.resolver import BindingMap, quote_ident, requote_columns
from app.dax.compiler import (
    CompiledMeasure,
    Context,
    DaxUnsupported,
    MeasureCompiler,
    qcol,
)
from app.ir.model import SemanticModel
from app.runtime import sql_render as sr

_D_CUR = "__d_cur"
_D_DATA = "__d_data"


class DimensionRef(BaseModel):
    table: str
    column: str
    alias: str | None = None

    @property
    def key(self) -> str:
        return self.alias or f"{self.table}.{self.column}"


class FilterClause(BaseModel):
    table: str
    column: str
    values: list[str | int | float | bool | None] = Field(default_factory=list)
    # in | not_in | eq | neq | gt | gte | lt | lte | contains | not_contains | starts_with |
    # not_starts_with | is_blank | is_not_blank | is_empty | is_not_empty | or | topn | relative |
    # between_dates | in_query (internal: a Top N ranking subquery token)
    op: str = "in"
    clauses: list[FilterClause] = Field(default_factory=list)  # operands of op="or"
    params: dict = Field(default_factory=dict)
    # audit only (slicer | page_filter | report_filter | cross_filter | drillthrough | tooltip):
    # never part of the SQL; result caches are keyed on SQL
    source: str | None = None


class MeasureFilter(BaseModel):
    """A visual filter on a measure's value, evaluated per grain row (the measure is not projected)."""

    measure: str
    op: str = "eq"  # eq | neq | in | not_in | gt | gte | lt | lte
    values: list[str | int | float | bool | None] = Field(default_factory=list)


class MeasureRefSpec(BaseModel):
    name: str | None = None  # model measure
    table: str | None = None  # or implicit column aggregate
    column: str | None = None
    aggregate: str | None = None
    alias: str | None = None

    @property
    def key(self) -> str:
        return self.alias or self.name or f"{self.aggregate or 'agg'}({self.table}.{self.column})"


class QuerySpec(BaseModel):
    dimensions: list[DimensionRef] = Field(default_factory=list)
    measures: list[MeasureRefSpec] = Field(default_factory=list)
    filters: list[FilterClause] = Field(default_factory=list)
    measure_filters: list[MeasureFilter] = Field(default_factory=list)
    sort: list[dict] = Field(default_factory=list)
    limit: int | None = None


class QueryPlanError(Exception):
    pass


class _TemplateMeta:
    """What a query template needs at render time (see `sql_render.render_template`)."""

    def __init__(self) -> None:
        self.preds: list[dict] = []
        self.blocks: dict[str, dict] = {}
        self.isf: dict[str, dict] = {}
        self.slots: dict[str, dict] = {}
        self.guards: list[dict] = []
        self.slot_errors: dict[str, str] = {}
        self._block_cache: dict[tuple, str] = {}

    def pred(self, sid: str, col: str) -> str:
        self.preds.append({"slot": sid, "col": col})
        return f"{{{{p:{len(self.preds) - 1}}}}}"

    def block(self, slots: list[str], text: str, otherwise: str = "") -> str:
        key = (tuple(sorted(slots)), otherwise)
        # one block id per distinct (slots, else); the same id may wrap several fragments
        bid = self._block_cache.get(key)
        if bid is None:
            bid = f"b{len(self.blocks)}"
            self._block_cache[key] = bid
            self.blocks[bid] = {"slots": sorted(set(slots)), "else": otherwise}
        return f"{{{{#k:{bid}}}}}{text}{{{{/k:{bid}}}}}"

    def as_dict(self) -> dict:
        return {
            "preds": self.preds,
            "blocks": self.blocks,
            "isf": self.isf,
            "slots": self.slots,
            "guards": self.guards,
            "slot_errors": self.slot_errors,
        }


# operators that read their value list (an empty list is a caller bug, not "no filter")
_VALUE_OPS = frozenset(
    {"eq", "neq", "gt", "gte", "lt", "lte", "contains", "not_contains", "starts_with",
     "not_starts_with"}
)  # fmt: skip


@dataclass
class _Join:
    from_table: str
    from_column: str
    to_table: str
    to_column: str
    relationship_name: str = ""
    # true when this edge is the synthetic reverse traversal for bothDirections rels
    reverse_edge: bool = False
    # true when relationship cardinality is many-to-many
    many_to_many: bool = False


@dataclass
class _Group:
    ctx: Context
    fact: str
    alias: str = ""
    leaves: dict[str, str] = field(default_factory=dict)  # global alias -> aggregate sql
    reachable: list[DimensionRef] = field(default_factory=list)
    related: set = field(default_factory=set)  # tables joined only to evaluate leaf expressions
    plan: object | None = None  # GroupedPlan: leaves aggregate over summarized groups


def _q(name: str) -> str:
    return quote_ident(name, "a generated query alias")


def _sortkey(key: str) -> str:
    return quote_ident("__sort_" + key, "a generated sort alias")


_lit = sr.lit


def null_safe_in_sql(col: str, op: str, values: list, lit=_lit) -> str:
    """Filter lists that mention NULL, rendered the way Power BI/DAX treats BLANK:
    not_in [NULL] -> col IS NOT NULL; not_in [NULL, v] -> (col IS NOT NULL AND col != v);
    in [NULL, ...] -> (col IS NULL OR col IN (...)); eq NULL -> IS NULL; neq NULL -> IS NOT NULL."""
    try:
        return sr.null_safe_in_sql(col, op, values, lit)
    except sr.TemplateError as e:
        raise QueryPlanError(str(e)) from e


def _overlay_warning(code: str, message: str) -> str:
    return f"[OVERLAY:{code}] {message}"


class SemanticEngine:
    def __init__(
        self,
        model: SemanticModel,
        binding_map: BindingMap,
        tier2_sql: dict[str, str] | None = None,
        logger=None,
    ):
        self.model = model
        self.logger = logger  # CompilationLogger: receives the SQL generated per measure
        self.bindings = binding_map
        self.compiler = MeasureCompiler(model)
        self._calc_cache: dict[str, tuple[dict[str, str], dict[str, str]]] = {}
        # execution-validated LLM SQL for measures outside the tier-1 surface
        self.tier2_sql = tier2_sql or {}
        self._edges: dict[str, list[_Join]] = {}
        self._inactive: dict[tuple[str, str], _Join] = {}
        for r in model.relationships:
            j = _Join(
                r.from_table,
                r.from_column,
                r.to_table,
                r.to_column,
                relationship_name=r.name,
                many_to_many=(r.from_cardinality == "many" and r.to_cardinality == "many"),
            )
            if not r.is_active:
                self._inactive[
                    (f"{r.from_table}.{r.from_column}", f"{r.to_table}.{r.to_column}")
                ] = j
                continue
            self._edges.setdefault(r.from_table, []).append(j)
            if r.cross_filtering_behavior == "bothDirections":
                # reverse traversal: dimension filters can flow back to the fact
                self._edges.setdefault(r.to_table, []).append(
                    _Join(
                        r.to_table,
                        r.to_column,
                        r.from_table,
                        r.from_column,
                        relationship_name=r.name,
                        reverse_edge=True,
                        many_to_many=(
                            r.from_cardinality == "many" and r.to_cardinality == "many"
                        ),
                    )
                )

    # ---------------- planning ----------------

    def expanded_table(self, table: str) -> set[str]:
        """DAX expanded table: the table plus every table reachable via active
        many->one relationships. REMOVEFILTERS/ALL over a table clears filters
        on the whole expanded table, not just the base table."""
        seen = {table}
        frontier = [table]
        while frontier:
            cur = frontier.pop()
            for j in self._edges.get(cur, []):
                if not j.reverse_edge and j.to_table not in seen:
                    seen.add(j.to_table)
                    frontier.append(j.to_table)
        return seen

    def _effective_clears(self, ctx) -> set[str]:
        """Tables whose filters are cleared (ALL/REMOVEFILTERS expand to related one-side tables)."""
        out: set[str] = set()
        for t in ctx.clears:
            if isinstance(t, tuple):
                continue  # column-level clear, see _is_cleared
            if t == "*":
                return {"*"}
            out |= self.expanded_table(t)
        return out

    @staticmethod
    def _is_cleared(ctx, cleared_tables: set[str], table: str, column: str) -> bool:
        if (table, column) in ctx.keeps:
            return False
        if "*" in cleared_tables or table in cleared_tables:
            return True
        return (table, column) in ctx.clears

    def join_path(
        self,
        fact: str,
        target: str,
        use_relationships: tuple[tuple[str, str], ...] = (),
    ) -> list[_Join] | None:
        if fact == target:
            return []
        edges = self._edges
        if use_relationships:
            # activate the named inactive relationships for this context only
            edges = {k: list(v) for k, v in self._edges.items()}
            for pair in use_relationships:
                j = self._inactive.get(pair) or self._inactive.get((pair[1], pair[0]))
                if j is not None:
                    edges.setdefault(j.from_table, []).append(j)
        # Phase-7: weighted traversal that prefers non-reverse edges first.
        # This preserves stable one-direction semantics and only uses reverse
        # propagation when necessary.
        pq: list[tuple[int, int, str, list[_Join]]] = []
        best_cost: dict[str, tuple[int, int]] = {fact: (0, 0)}
        heappush(pq, (0, 0, fact, []))
        while pq:
            reverse_cost, hops, node, path = heappop(pq)
            if node == target:
                return path
            for edge in edges.get(node, []):
                new_reverse = reverse_cost + (1 if edge.reverse_edge else 0)
                new_hops = hops + 1
                cur = best_cost.get(edge.to_table)
                if cur is not None and cur <= (new_reverse, new_hops):
                    continue
                best_cost[edge.to_table] = (new_reverse, new_hops)
                heappush(pq, (new_reverse, new_hops, edge.to_table, path + [edge]))
        return None

    def _calc_columns(self, table: str) -> tuple[dict[str, str], dict[str, str]]:
        """(translated calculated columns name -> row SQL, untranslated name -> reason)."""
        cached = self._calc_cache.get(table)
        if cached is not None:
            return cached
        ok: dict[str, str] = {}
        failed: dict[str, str] = {}
        t = self.model.table(table)
        for col in t.columns if t else []:
            if col.expression is None:
                continue
            try:
                ok[col.name] = self.compiler.compile_calc_column(table, col.name)
            except DaxUnsupported as e:
                failed[col.name] = str(e)
        self._calc_cache[table] = (ok, failed)
        return ok, failed

    def _physical(self, table: str) -> str:
        b = self.bindings.get(table)
        if b is None or b.status != "resolved":
            raise QueryPlanError(f"table {table} has no physical binding")
        if b.native_query:
            return f"({b.native_query})"
        qname = b.qualified_name
        case = b.column_case
        # Phase-5: if the binding has a WHERE clause (from Table.SelectRows),
        # wrap as a subquery so the filter is always applied
        if b.where_clause:
            where = requote_columns(b.where_clause, case)
            source = f"(SELECT * FROM {qname} WHERE {where})"  # noqa: S608
        else:
            source = qname
        model_table = self.model.table(table)
        model_cols: set[str] = set()
        if model_table is not None:
            model_cols = {c.name for c in model_table.columns}
            model_cols |= {c.source_column for c in model_table.columns if c.source_column}
        calc_ok, _calc_failed = self._calc_columns(table)

        exclude: list[str] = []
        extra: list[str] = []
        renames = b.column_aliases  # M Table.RenameColumns: physical old name -> model name
        reverse = {new: old for old, new in renames.items()}
        computed_final = {renames.get(name, name) for name in b.computed_columns}
        for old, new in renames.items():
            if old in b.computed_columns:
                continue  # an AddColumn result renamed later is exposed as its expression
            phys = case.get(old, old)
            exclude.append(phys)
            extra.append(f"{quote_ident(phys, 'a Snowflake column')} AS {quote_ident(new, 'a model column')}")
        for name, expr in b.computed_columns.items():
            # expressions written with post-rename names read the physical source columns
            for new, old in reverse.items():
                expr = expr.replace(quote_ident(new), quote_ident(case.get(old, old)))
            expr = requote_columns(expr, case)
            final = renames.get(name, name)
            extra.append(f"{expr} AS {quote_ident(final, 'a model column')}")
        for src, exact in sorted(case.items()):
            if src in renames or src in b.computed_columns:
                continue
            if exact not in model_cols and exact not in exclude:
                exclude.append(exact)
            extra.append(
                f"{quote_ident(exact, 'a Snowflake column')} AS {quote_ident(src, 'a model column')}"
            )
        for name, expr in calc_ok.items():
            if name in computed_final:
                continue
            extra.append(f"{expr} AS {quote_ident(name, 'a calculated column')}")
        if not exclude and not extra:
            return source
        select = "*"
        if exclude:
            names = ", ".join(quote_ident(c, "a Snowflake column") for c in dict.fromkeys(exclude))
            select += f" EXCLUDE ({names})"
        if extra:
            select += ", " + ", ".join(extra)
        # calculated columns read their table's columns through its model name
        return f"(SELECT {select} FROM {source} AS {_q(table)})"  # noqa: S608

    def _pick_fact(self, leaf_tables: set[str], dims: list[DimensionRef]) -> str:
        # prefer the leaf table that reaches the most dims (PBI: unreachable dims repeat)
        best, best_n = None, -1
        for t in sorted(leaf_tables):
            n = sum(1 for d in dims if self.join_path(t, d.table) is not None)
            if n > best_n:
                best, best_n = t, n
        if best is None:
            raise QueryPlanError(f"no usable leaf table among {sorted(leaf_tables)}")
        return best

    def _sort_column(self, table: str, column: str) -> str | None:
        t = self.model.table(table)
        col = t.column(column) if t else None
        return col.sort_by_column if col else None

    # ---------------- public ----------------

    def build_sql(
        self, spec: QuerySpec, sql_context: str | None = None
    ) -> tuple[str, list[str]]:
        """`sql_context` labels the query for the audit (`visual:<page>/<visual>:main`, ...)."""
        try:
            expanded, tokens = self._expand_filter_ops(spec)
            sql, warnings = self._build_sql(expanded)
            for token, inner in tokens.items():
                sql = sql.replace(token, inner)
        except Exception as e:
            self._annotate_sql(spec, None, str(e), sql_context)
            raise
        self._annotate_sql(spec, sql, None, sql_context)
        return sql, warnings

    _tpl: _TemplateMeta | None = None

    def build_template(
        self, spec: QuerySpec, slots: list[tuple[str, str]]
    ) -> tuple[str, dict, list[str]]:
        """`(sql, meta, warnings)`: the query with a `FilterClause(op="slot")` placed wherever a
        real filter on each (table, column) would go. Template mode never affects live queries."""
        meta = _TemplateMeta()
        slot_filters = [
            FilterClause(table=t, column=c, op="slot", params={"sid": f"s{i}"})
            for i, (t, c) in enumerate(slots)
        ]
        meta_slots = {f"s{i}": {"table": t, "column": c} for i, (t, c) in enumerate(slots)}
        self._tpl = meta
        try:
            sql, warnings = self.build_sql(
                spec.model_copy(update={"filters": [*spec.filters, *slot_filters]})
            )
        finally:
            self._tpl = None
        # only slots that actually appear in the SQL can be applied
        used: set[str] = set()
        for m in re.finditer(r"\{\{p:(\d+)\}\}", sql):
            used.add(meta.preds[int(m.group(1))]["slot"])
        for m in re.finditer(r"\{\{#k:(\w+)\}\}", sql):
            used.update(meta.blocks[m.group(1)]["slots"])
        for m in re.finditer(r"\{\{isf:(\w+)\}\}", sql):
            used.update(meta.isf[m.group(1)].get("slots", []))
        for g in meta.guards:  # a guarded slot is refused when selected, never silently ignored
            used.update(g["slots"])
        meta.slots = {sid: info for sid, info in meta_slots.items() if sid in used}
        for p in meta.preds:
            p["col"] = self._dealias(p["col"])
        return sql, meta.as_dict(), warnings

    def _expand_filter_ops(self, spec: QuerySpec) -> tuple[QuerySpec, dict[str, str]]:
        """Top N filters become `col IN (<token>)`; the token is later replaced (after alias
        rewriting) by the ranking subquery. `in_query` itself is internal: refused when sent."""

        def has_in_query(clauses: list) -> bool:
            return any(c.op == "in_query" or has_in_query(c.clauses) for c in clauses)

        if has_in_query(spec.filters):
            raise QueryPlanError("unknown filter op in_query")
        topn = [f for f in spec.filters if f.op == "topn"]
        if not topn:
            return spec, {}
        others = [f for f in spec.filters if f.op != "topn"]
        filters = list(others)
        tokens: dict[str, str] = {}
        for i, f in enumerate(topn):
            p = f.params or {}
            n = p.get("n")
            direction = p.get("direction", "top")
            if isinstance(n, bool) or not isinstance(n, int) or n < 1:
                raise QueryPlanError("Top N needs a positive whole number")
            if direction not in ("top", "bottom"):
                raise QueryPlanError("Top N direction must be top or bottom")
            if p.get("measure"):
                by = MeasureRefSpec(name=str(p["measure"]), alias="__topn_by")
            elif p.get("table") and p.get("column"):
                by = MeasureRefSpec(
                    table=p["table"], column=p["column"], aggregate=p.get("aggregate"), alias="__topn_by"
                )
            else:
                raise QueryPlanError("Top N needs a 'By value' field")
            rank_spec = QuerySpec(
                dimensions=[DimensionRef(table=f.table, column=f.column, alias="__topn_key")],
                measures=[by],
                filters=others,
            )
            rank_sql, _ = self._build_sql(rank_spec)
            order = "DESC" if direction == "top" else "ASC"
            token = f"__TOPN_TOKEN_{i}__"
            tokens[token] = (
                f'SELECT "__topn_key" FROM ({rank_sql}) AS "__topn_rank" '  # noqa: S608
                f'WHERE "__topn_by" IS NOT NULL AND "__topn_key" IS NOT NULL '
                f'QUALIFY RANK() OVER (ORDER BY "__topn_by" {order}) <= {n}'
            )
            filters.append(
                FilterClause(
                    table=f.table, column=f.column, op="in_query", params={"token": token}, source=f.source
                )
            )
        return spec.model_copy(update={"filters": filters}), tokens

    def _annotate_sql(
        self, spec: QuerySpec, sql: str | None, error: str | None, context: str | None
    ) -> None:
        if sql and context:
            try:
                from app.services.query_audit import remember_sql_context

                remember_sql_context(sql, context)
            except ImportError:
                pass
        if self.logger is None:
            return
        for m in spec.measures:
            if m.name and not m.name.startswith("__"):
                self.logger.annotate_sql(m.name, sql, error, context)

    def _build_sql(self, spec: QuerySpec) -> tuple[str, list[str]]:
        warnings: list[str] = []
        if not spec.measures and not spec.dimensions:
            raise QueryPlanError("empty query")

        # visual filters on a measure's value are compiled as hidden extra measures
        mf_specs = [
            MeasureRefSpec(name=mf.measure, alias=f"__mf{i}")
            for i, mf in enumerate(spec.measure_filters)
        ]

        compiled: dict[str, CompiledMeasure] = {}
        for m in [*spec.measures, *mf_specs]:
            try:
                compiled[m.key] = (
                    self.compiler.compile_measure(m.name)
                    if m.name
                    else self.compiler.compile_implicit(m.table, m.column, m.aggregate)
                )
            except DaxUnsupported as e:
                if m.name and m.name in self.tier2_sql:
                    # zero-leaf scalar-subquery measure; whole-model value
                    compiled[m.key] = CompiledMeasure(
                        name=m.name,
                        expr=f"(\n{self.tier2_sql[m.name]}\n)",
                        tier=2,
                    )
                    warnings.append(
                        _overlay_warning(
                            "TIER2_MEASURE",
                            f"measure '{m.name}' is AI-translated (tier-2): whole-model "
                            "value, does not respond to slicers/filters",
                        )
                    )
                else:
                    raise QueryPlanError(f"measure {m.key}: {e}") from e

        return self._plan_sql(spec, compiled, warnings)

    def _plan_sql(
        self, spec: QuerySpec, compiled: dict[str, CompiledMeasure], warnings: list[str]
    ) -> tuple[str, list[str]]:
        """Group the compiled leaves, build the subqueries and combine them."""
        self._check_untranslated_columns(spec, compiled)

        if not compiled:
            return self._multi_dimension_sql(spec, warnings), warnings

        # windowed rolling averages evaluate via their own date-grain CTE
        windowed = {k: cm for k, cm in compiled.items() if cm.window_avg is not None}
        compiled = {k: cm for k, cm in compiled.items() if cm.window_avg is None}

        if windowed and not compiled:
            raise QueryPlanError(
                "windowed measure needs a companion measure in the same visual"
            )

        # all remaining measures tier-2 (zero leaves): plain scalar select
        if compiled and all(not cm.leaves for cm in compiled.values()) and not windowed:
            visible = {k: cm for k, cm in compiled.items() if not k.startswith("__mf")}
            selects = ", ".join(f"{cm.expr} AS {_q(k)}" for k, cm in visible.items())
            sql = f"SELECT {selects}"
            conds = self._measure_filter_conditions(
                spec, {k: cm.expr for k, cm in compiled.items()}
            )
            if conds:
                sql += "\nWHERE " + " AND ".join(conds)
            return self.finalize(sql, spec, compiled, warnings), warnings

        groups: dict[tuple, _Group] = {}
        leaf_to_group: dict[tuple[str, str], tuple[str, str]] = {}
        for mkey, cm in compiled.items():
            for local_alias, leaf in cm.leaves.items():
                fact = leaf.grouped.fact if leaf.grouped else self._pick_fact(
                    leaf.tables, spec.dimensions
                )
                gkey = (leaf.ctx, fact, leaf.grouped)
                grp = groups.setdefault(
                    gkey, _Group(ctx=leaf.ctx, fact=fact, plan=leaf.grouped)
                )
                galias = None
                for existing_alias, existing_sql in grp.leaves.items():
                    if existing_sql == leaf.sql:
                        galias = existing_alias
                        break
                if galias is None:
                    galias = f"v{len(grp.leaves)}"
                    grp.leaves[galias] = leaf.sql
                grp.related |= leaf.related
                leaf_to_group[(mkey, local_alias)] = (gkey, galias)

        for i, grp in enumerate(groups.values()):
            grp.alias = f"q{i}"
            # dims on a cleared expanded table leave this leaf's grain entirely:
            # the value is computed without them and repeated via the frame
            clears = self._effective_clears(grp.ctx)
            grp.reachable = [
                d
                for d in spec.dimensions
                if not self._is_cleared(grp.ctx, clears, d.table, d.column)
                and self.join_path(grp.fact, d.table, grp.ctx.use_relationships) is not None
            ]

        # a frame is needed when any group cannot reach every dim (PBI repeat semantics)
        needs_frame = any(
            len(grp.reachable) < len(spec.dimensions) for grp in groups.values()
        )
        sub_sql = {grp.alias: self._group_sql(grp, spec, warnings) for grp in groups.values()}
        frame_sql = self._frame_sql(spec, warnings) if needs_frame else None
        window_ctes = {
            k: self._window_avg_sql(cm, spec, warnings) for k, cm in windowed.items()
        }
        sql = self._combine(
            spec, compiled, groups, leaf_to_group, sub_sql, frame_sql, window_ctes
        )
        return self.finalize(sql, spec, compiled, warnings), warnings

    def _check_untranslated_columns(self, spec: QuerySpec, compiled: dict) -> None:
        """A calculated column that could not be translated is absent from the projection; fail at
        planning time naming the column and reason instead of Snowflake's invalid identifier."""
        refs: set[tuple[str, str]] = {(d.table, d.column) for d in spec.dimensions}
        for f in spec.filters:
            if f.op == "slot" and self._tpl is not None:
                failed = self._calc_columns(f.table)[1]
                if f.column in failed:
                    self._tpl.slot_errors[f.params["sid"]] = (
                        f"calculated column {f.table}[{f.column}] cannot be translated to SQL: "
                        f"{failed[f.column]}"
                    )
                continue
            refs.add((f.table, f.column))
        refs |= {(m.table, m.column) for m in spec.measures if m.table and m.column}
        sqls: list[str] = []
        for cm in compiled.values():
            for leaf in cm.leaves.values():
                sqls.append(leaf.sql)
                sqls.extend(p.sql for p in leaf.ctx.filters)
        tables = {t.name for t in self.model.tables}
        for table in tables:
            failed = self._calc_columns(table)[1]
            if not failed:
                continue
            for column, reason in failed.items():
                qualified = qcol(table, column)
                if (table, column) in refs or any(qualified in sql for sql in sqls):
                    raise QueryPlanError(
                        f"calculated column {table}[{column}] cannot be translated to SQL: {reason}"
                    )

    # ---------------- finalize: per-query tokens ----------------

    def finalize(self, sql: str, spec: QuerySpec, compiled: dict, warnings: list[str]) -> str:
        """Expand the tokens compiled measures left in the SQL: whole-table scalar subqueries,
        ISFILTERED / ISCROSSFILTERED, per-query context scalars; then de-alias colliding names."""
        tokens: dict[str, tuple] = {}
        for cm in compiled.values():
            tokens.update(cm.tokens)
        ctes: list[tuple[str, str]] = []

        def expand(text: str) -> str:
            for _ in range(8):  # expansions may introduce further tokens
                pending = [t for t in tokens if t in text]
                if not pending:
                    break
                # TOPN first: its CTE must be top level and may contain the other tokens
                pending.sort(key=lambda t: 0 if tokens[t][0] == "topn" else 1)
                for token in pending:
                    repl = self._render_token(token, tokens[token], spec, ctes, expand)
                    text = text.replace(token, repl)
            return text

        sql = expand(sql)
        if ctes:
            sql = self._with_ctes(sql, ctes)
        return self._dealias(sql)

    @staticmethod
    def _with_ctes(sql: str, ctes: list[tuple[str, str]]) -> str:
        """Merge CTEs into the query's top-level WITH (or start one)."""
        block = ",\n".join(f"{_q(name)} AS (\n{body}\n)" for name, body in ctes)
        if sql.startswith("WITH "):
            return "WITH " + block + ",\n" + sql[len("WITH ") :]
        return f"WITH {block}\n{sql}"

    def _native_measure_sql(self, measure: str, spec: QuerySpec) -> str:
        """A reviewer's hand-written SQL, rendered with the query's filters as a scalar subquery."""
        from app.services.sql_overrides import render

        if spec.dimensions:
            raise QueryPlanError(
                f"measure [{measure}] uses hand-written SQL, which returns one value per query; "
                "it cannot be grouped by the visual's fields"
            )
        sql, _unapplied = render(self.model.measure_sql[measure].sql, spec.filters, self)
        return f"(\n{sql}\n)"

    def _render_token(self, token, definition, spec, ctes, expand) -> str:
        match definition:
            case ("scalar", table, agg_sql):
                return f"(SELECT {agg_sql} FROM {self._physical(table)} AS {_q(table)})"  # noqa: S608
            case ("isf", fname, table, column, ctx_tables):
                value = self._isf_value(spec, fname, table, column, ctx_tables)
                if isinstance(value, str):  # template mode: a marker
                    return value
                return "TRUE" if value else "FALSE"
            case ("ctx", table, agg_sql, extra_where, shift, skip_all, skip_cols):
                return self._render_ctx_token(
                    spec, table, agg_sql, extra_where, shift, skip_all, skip_cols, ctes, expand
                )
            case ("topn", plan):
                return self._render_topn(spec, plan, ctes)
            case ("native", measure):
                return self._native_measure_sql(measure, spec)
            case ("startofyear", table, column, anchor):
                col = qcol(table, column)
                return (
                    f"(SELECT MIN({col}) FROM {self._physical(table)} AS {_q(table)} "  # noqa: S608
                    f"WHERE YEAR({col}) = YEAR({anchor}) AND {col} <= {anchor})"
                )
        raise QueryPlanError(f"unknown query token {token}")

    def _render_topn(self, spec: QuerySpec, plan, ctes: list) -> str:
        """Top-level CTE of the winning keys, read as (SELECT "__k" FROM "__topnN")."""
        if spec.dimensions:
            raise QueryPlanError(
                "a TOPN filter would have to be re-ranked for every row of this visual "
                f"(grouped by {', '.join(d.key for d in spec.dimensions)}); use it on a card"
            )
        table, column = plan.key_table, plan.key_column
        key_filters = [self._filter_sql(f, table) for f in spec.filters if f.table == table]
        if plan.source_filter:
            key_filters.append(plan.source_filter)
        if plan.all_rows:
            body = f"SELECT DISTINCT {qcol(table, column)} AS \"__k\"\nFROM {self._physical(table)} AS {_q(table)}"  # noqa: S608
            if key_filters:
                body += "\nWHERE " + " AND ".join(key_filters)
        else:
            extra = []
            if plan.source_filter:
                extra.append(
                    FilterClause(table=table, column=column, op="sql", params={"sql": plan.source_filter})
                )
            rank_spec = QuerySpec(
                dimensions=[DimensionRef(table=table, column=column, alias="__k")],
                measures=[MeasureRefSpec(alias="__x")],
                filters=[*spec.filters, *extra],
            )
            rank_sql, _w = self._plan_sql(rank_spec, {"__x": plan.x}, [])
            order = "DESC NULLS LAST" if plan.descending else "ASC NULLS FIRST"
            body = (
                f'SELECT "__k"\nFROM (\n{rank_sql}\n) AS "__rk"\n'
                f'QUALIFY RANK() OVER (ORDER BY "__x" {order}) <= {int(plan.n)}'
            )
        name = f"__topn{len(ctes)}"
        ctes.append((name, body))
        return f'(SELECT "__k" FROM {_q(name)})'  # noqa: S608

    def _check_ctx_table(self, spec: QuerySpec, table: str) -> None:
        """Date-window bounds read the filter context of `table`: refused when that context is
        per visual row (the table is on the axis) or reaches the table through relationships."""
        if any(d.table == table for d in spec.dimensions):
            raise QueryPlanError(
                f"date-window bounds read the filter context of '{table}', which is on this "
                "visual's rows/axis; the window would have to be evaluated per row"
            )
        real = [f for f in spec.filters if not (self._tpl is not None and f.op == "slot")]
        others = {f.table for f in real} | {d.table for d in spec.dimensions}
        for other in sorted(others):
            if other != table and self.join_path(table, other) is not None:
                raise QueryPlanError(
                    f"date-window bounds read the filter context of '{table}', which is "
                    f"cross-filtered by {other} in this query"
                )
        if self._tpl is not None:  # a slot that would cross-filter the bounds: refused when active
            for f in spec.filters:
                crosses = f.table != table and self.join_path(table, f.table) is not None
                if f.op == "slot" and crosses:
                    self._tpl.guards.append(
                        {
                            "slots": [f.params["sid"]],
                            "message": (
                                f"date-window bounds read the filter context of '{table}', which "
                                f"is cross-filtered by {f.table} in this query"
                            ),
                        }
                    )

    def _render_ctx_token(
        self, spec, table, agg_sql, extra_where, shift, skip_all, skip_cols, ctes, expand
    ) -> str:
        if not skip_all:
            self._check_ctx_table(spec, table)
        query_filters = [
            f
            for f in spec.filters
            if f.table == table and not skip_all and f.column not in skip_cols
        ]
        wheres = [self._filter_sql(f, table) for f in query_filters]
        wheres += [expand(w) for w in extra_where]
        if shift:
            unit, n, date_col = shift
            inner = (
                f"SELECT DATEADD({unit}, {n}, {qcol('__s', date_col)}) "  # noqa: S608
                f"FROM {self._physical(table)} AS {_q('__s')}"
            )
            sf = [self._filter_sql(f, "__s") for f in query_filters]
            if sf:
                inner += " WHERE " + " AND ".join(sf)
            wheres = [w for w in wheres if w not in {self._filter_sql(f, table) for f in query_filters}]
            wheres.append(f"{qcol(table, date_col)} IN ({inner})")
        body = f'SELECT {expand(agg_sql)} AS "v"\nFROM {self._physical(table)} AS {_q(table)}'  # noqa: S608
        if wheres:
            body += "\nWHERE " + " AND ".join(wheres)
        name = f"__ctx{len(ctes)}"
        ctes.append((name, body))
        return f'(SELECT "v" FROM {_q(name)})'  # noqa: S608

    def table_alias(self, table: str) -> str:
        """Quoted alias the generated SQL uses for a model table."""
        t = self.model.table(table)
        return quote_ident(self._alias_of(t.name if t else table))

    def slot_column(self, table: str, column: str) -> tuple[str, str]:
        """(quoted table alias, column reference) as the generated SQL spells them."""
        t = self.model.table(table)
        alias = self._alias_of(t.name if t else table)
        return quote_ident(alias), qcol(alias, column)

    def filter_predicate(self, f: FilterClause) -> tuple[str, str]:
        """(quoted table alias, predicate) spelled exactly like the generated SQL's WHERE."""
        t = self.model.table(f.table)
        name = t.name if t else f.table
        alias = self._alias_of(name)
        return quote_ident(alias), self._filter_sql(f.model_copy(update={"table": name}), alias)

    def _alias_of(self, table: str) -> str:
        """Tables whose name equals one of their column names get an internal alias, because
        Snowflake can read "T"."T" as a field access instead of a column."""
        t = self.model.table(table)
        if t is not None and any(c.name == table for c in t.columns):
            return f"__t_{table}"
        return table

    def _dealias(self, sql: str) -> str:
        """Rewrite "Table". qualifiers and AS "Table" aliases for colliding tables (idempotent)."""
        for t in self.model.tables:
            alias = self._alias_of(t.name)
            if alias == t.name:
                continue
            quoted, quoted_alias = quote_ident(t.name), quote_ident(alias)
            sql = re.sub(rf'(?<![\w"]){re.escape(quoted)}\.', lambda _m, a=quoted_alias: a + ".", sql)
            sql = sql.replace(f"AS {quoted}", f"AS {quoted_alias}")
        return sql

    def _isf_value(
        self, spec: QuerySpec, fname: str, table: str, column, ctx_tables
    ) -> bool | str:
        def on_column(t: str, c: str) -> bool:
            return t == table and (column is None or c == column)

        tpl = self._tpl
        real = [f for f in spec.filters if not (tpl is not None and f.op == "slot")]
        slots = [f for f in spec.filters if tpl is not None and f.op == "slot"]
        filtered = any(on_column(f.table, f.column) for f in real) or any(
            on_column(d.table, d.column) for d in spec.dimensions
        )
        if fname == "ISFILTERED":
            sids = [f.params["sid"] for f in slots if on_column(f.table, f.column)]
        else:
            # ISCROSSFILTERED: another table's filters reach `table` through active relationships
            query_tables = {f.table for f in real} | {d.table for d in spec.dimensions}
            query_tables |= set(ctx_tables)
            filtered = any(
                t != table and self.join_path(table, t) is not None for t in query_tables
            )
            sids = [
                f.params["sid"]
                for f in slots
                if f.table != table and self.join_path(table, f.table) is not None
            ]
        if tpl is None or filtered or not sids:
            return filtered
        key = f"i{len(tpl.isf)}"
        tpl.isf[key] = {"static": False, "slots": sorted(set(sids))}
        return f"{{{{isf:{key}}}}}"

    def _window_avg_sql(self, cm: CompiledMeasure, spec: QuerySpec, warnings) -> tuple[str, str]:
        """(join_key_sql, cte_body) evaluating AVG of the inner measure over a
        trailing window at date grain. Grain must include a column of the date
        table (the standard trend-visual shape)."""
        wa = cm.window_avg
        date_dims = [d for d in spec.dimensions if d.table == wa.date_table]
        if not date_dims:
            raise QueryPlanError(
                f"windowed measure '{cm.name}' needs a {wa.date_table} column in the grain"
            )
        grain_dim = date_dims[0]
        inner_spec = QuerySpec(
            dimensions=[DimensionRef(table=wa.date_table, column=wa.date_column, alias="__d")],
            measures=[MeasureRefSpec(name=wa.measure, alias="__v")],
            filters=[f for f in spec.filters if f.table != wa.date_table],
        )
        inner_sql, inner_warnings = self.build_sql(inner_spec)
        warnings.extend(inner_warnings)
        # inner CTE names (q0, q1, __frame) collide with the outer query's scope
        inner_sql = inner_sql.replace('"q', '"wiq').replace('"__frame"', '"__wiframe"')
        # map window date grain back to the visual's grain column
        # (identifiers validated by qcol/safe_ident)
        label = (
            f'SELECT {qcol(wa.date_table, grain_dim.column)} AS "k", '  # noqa: S608
            f'{qcol(wa.date_table, wa.date_column)} AS "d" '
            f'FROM {self._physical(wa.date_table)} AS {_q(wa.date_table)}'
        )
        body = (
            f"SELECT lbl.\"k\", AVG(win.\"__v\") OVER ("
            f"ORDER BY win.\"__d\" ROWS BETWEEN {max(wa.n - 1, 0)} PRECEDING AND CURRENT ROW"
            f') AS "__v"\nFROM (\n{inner_sql}\n) AS win\n'
            f'JOIN (\n{label}\n) AS lbl ON win."__d" = lbl."d"'
        )
        return grain_dim.key, body

    # ---------------- pieces ----------------

    def _measure_filter_conditions(self, spec: QuerySpec, exprs: dict[str, str]) -> list[str]:
        out = []
        for i, mf in enumerate(spec.measure_filters):
            expr = exprs[f"__mf{i}"]
            if mf.op in ("gt", "gte", "lt", "lte"):
                sym = {"gt": ">", "gte": ">=", "lt": "<", "lte": "<="}[mf.op]
                out.append(f"({expr}) {sym} {_lit(mf.values[0])}")
            elif mf.op in ("eq", "neq", "in", "not_in"):
                out.append(null_safe_in_sql(f"({expr})", mf.op, mf.values, _lit))
            else:
                raise QueryPlanError(f"unknown measure filter operator {mf.op}")
        return out

    def _dimension_only_sql(self, spec: QuerySpec, warnings: list[str]) -> str:
        d = spec.dimensions[0]
        parts = []
        for f in spec.filters:
            if f.table != d.table:
                warnings.append(
                    _overlay_warning(
                        "UNREACHABLE_FILTER",
                        f"filter on {f.table} ignored for slicer domain {d.table}",
                    )
                )
                continue
            parts.append(self._filter_sql(f, d.table))
        sort_col = self._sort_column(d.table, d.column)
        select = f"{qcol(d.table, d.column)} AS {_q(d.key)}"
        order = _q(d.key)
        if sort_col:
            select += f', MIN({qcol(d.table, sort_col)}) AS "__sort"'
            sql = f"SELECT {select}\nFROM {self._physical(d.table)} AS {_q(d.table)}"  # noqa: S608
            if parts:
                sql += "\nWHERE " + " AND ".join(parts)
            sql += f'\nGROUP BY {qcol(d.table, d.column)}\nORDER BY "__sort"'
        else:
            sql = f"SELECT DISTINCT {select}\nFROM {self._physical(d.table)} AS {_q(d.table)}"  # noqa: S608
            if parts:
                sql += "\nWHERE " + " AND ".join(parts)
            sql += f"\nORDER BY {order}"
        if spec.limit:
            sql += f"\nLIMIT {int(spec.limit)}"
        return sql

    def _multi_dimension_sql(self, spec: QuerySpec, warnings: list[str]) -> str:
        """Table visuals with columns only: the distinct combinations that exist in the data,
        joined along active many->one relationships from the table that reaches every column's
        table, with filters applied. A single column keeps the slicer-domain query."""
        if len(spec.dimensions) == 1:
            return self._dimension_only_sql(spec, warnings)
        dim_tables = {d.table for d in spec.dimensions}
        base = None
        for t in sorted(dim_tables):
            if all(self.join_path(t, other) is not None for other in dim_tables):
                base = t
                break
        if base is None:
            raise QueryPlanError(
                "columns of "
                + ", ".join(sorted(dim_tables))
                + " are not connected by active relationships; no row combination exists"
            )
        grp = _Group(ctx=Context(), fact=base, alias="q0", reachable=list(spec.dimensions))
        sql = self._group_sql(grp, spec, warnings)
        orders: list[str] = []
        for d in spec.dimensions:
            if self._sort_column(d.table, d.column):
                orders.append(_sortkey(d.key))
        orders += [_q(d.key) for d in spec.dimensions]
        sql += "\nORDER BY " + ", ".join(orders)
        if spec.limit:
            sql += f"\nLIMIT {int(spec.limit)}"
        return sql

    def _frame_sql(self, spec: QuerySpec, warnings: list[str]) -> str:
        """Cell-grid CTE body: cross-join of per-table axes. A sortByColumn is projected as
        MIN(sort) ... GROUP BY value so a sort column that is not 1:1 with its value cannot
        duplicate cells."""
        by_table: dict[str, list[DimensionRef]] = {}
        for d in spec.dimensions:
            by_table.setdefault(d.table, []).append(d)
        parts: list[str] = []
        outer_cols: list[str] = []
        for i, (table, dims) in enumerate(by_table.items()):
            cols = []
            group_cols = []
            has_sort = False
            for d in dims:
                cols.append(f"{qcol(table, d.column)} AS {_q(d.key)}")
                group_cols.append(qcol(table, d.column))
                outer_cols.append(f'"ax{i}".{_q(d.key)}')
                sc = self._sort_column(table, d.column)
                if sc:
                    has_sort = True
                    cols.append(f"MIN({qcol(table, sc)}) AS {_sortkey(d.key)}")
                    outer_cols.append(f'"ax{i}".{_sortkey(d.key)}')
            flt = [self._filter_sql(f, table) for f in spec.filters if f.table == table]
            inner = f"SELECT {'' if has_sort else 'DISTINCT '}{', '.join(cols)}"
            inner += f"\nFROM {self._physical(table)} AS {_q(table)}"  # noqa: S608
            if flt:
                inner += "\nWHERE " + " AND ".join(flt)
            if has_sort:
                inner += "\nGROUP BY " + ", ".join(group_cols)
            parts.append(f'(\n{inner}\n) AS "ax{i}"')
        body = "SELECT " + ", ".join(outer_cols) + "\nFROM " + "\nCROSS JOIN ".join(parts)
        return body

    today_sql = "CURRENT_DATE()"
    now_sql = "CURRENT_TIMESTAMP()"

    def _filter_sql(self, f: FilterClause, alias: str) -> str:
        col = qcol(alias, f.column)
        if f.op == "sql":  # internal: a pre-rendered predicate over the table alias
            return f"({f.params['sql']})"
        if f.op == "slot":  # template mode: a placeholder for the request's clauses on this column
            if self._tpl is None:
                raise QueryPlanError("slot filters only exist in template mode")
            return self._tpl.pred(f.params["sid"], col)
        if sr.clause_needs_values(f.op) and not f.values and f.op in _VALUE_OPS:
            raise QueryPlanError(f"filter op '{f.op}' needs at least one value")
        try:
            sql = sr.predicate_sql(
                col, f.op, f.values, f.clauses, f.params, self.today_sql, self.now_sql
            )
        except sr.TemplateError as e:
            raise QueryPlanError(str(e)) from e
        if sql is None:
            raise QueryPlanError(f"unknown filter op {f.op}")
        return sql

    def _semi_join_sql(self, fact: str, path: list, f: FilterClause) -> str:
        """Filter via IN-subquery along the relationship path (no row duplication).

        Mirrors PBI filter-context semantics: a filter on a dimension restricts
        fact rows without multiplying them, even if the dim's join key repeats.
        """
        first = path[0]
        inner_from = self._physical(first.to_table) + f' AS {_q(first.to_table)}'
        inner_joins = ""
        for e in path[1:]:
            inner_joins += (
                f'\n  JOIN {self._physical(e.to_table)} AS {_q(e.to_table)} ON '
                f"{qcol(e.from_table, e.from_column)} = {qcol(e.to_table, e.to_column)}"
            )
        pred = self._filter_sql(f, f.table)
        # identifiers validated by safe_ident in _physical/qcol
        return (
            f"{qcol(fact, first.from_column)} IN "  # noqa: S608
            f"(SELECT {qcol(first.to_table, first.to_column)} FROM {inner_from}"
            f"{inner_joins} WHERE {pred})"
        )

    def _grouped_group_sql(self, grp: _Group, spec: QuerySpec, warnings: list[str]) -> str:
        """Leaves over summarized groups: rows of the fact are grouped by the plan's keys (plus the
        visual's grain), pass through GROUPBY levels and a condition, then aggregate per grain."""
        plan = grp.plan
        key_dims = [
            DimensionRef(table=t, column=c, alias=f"k{i}") for i, (t, c) in enumerate(plan.keys)
        ]
        for d in key_dims:
            if self.join_path(plan.fact, d.table, grp.ctx.use_relationships) is None:
                raise QueryPlanError(
                    f"grouped column {d.table}[{d.column}] is unreachable from {plan.fact}"
                )
        inner_spec = spec.model_copy(update={"dimensions": [*spec.dimensions, *key_dims]})
        inner = _Group(
            ctx=grp.ctx,
            fact=plan.fact,
            alias=grp.alias,
            leaves=dict(plan.base),
            reachable=[*grp.reachable, *key_dims],
            related=set(grp.related),
        )
        sql = self._group_sql(inner, inner_spec, warnings)
        grain = [_q(d.key) for d in grp.reachable]
        for i, level in enumerate(plan.levels, start=1):
            cols = grain + [_q(k) for k in level.keys]
            cols += [f"{agg} AS {_q(name)}" for name, agg in level.added]
            group_by = grain + [_q(k) for k in level.keys]
            sql = f"SELECT {', '.join(cols)}\nFROM (\n{sql}\n) AS {_q(f'gl{i}')}"
            if group_by:
                sql += "\nGROUP BY " + ", ".join(group_by)
        outer_cols = grain + [f"{expr} AS {_q(alias)}" for alias, expr in grp.leaves.items()]
        out = f"SELECT {', '.join(outer_cols)}\nFROM (\n{sql}\n) AS {_q('gfinal')}"
        if plan.cond:
            out += f"\nWHERE {plan.cond}"
        if grain:
            out += "\nGROUP BY " + ", ".join(grain)
        return out

    def _group_sql(self, grp: _Group, spec: QuerySpec, warnings: list[str]) -> str:
        if grp.plan is not None:
            return self._grouped_group_sql(grp, spec, warnings)
        ctx, fact = grp.ctx, grp.fact
        shift = ctx.time_shift
        date_table = shift.date_table if shift else None

        joins: list[str] = []
        joined: dict[str, str] = {fact: fact}

        # columns referenced per table: join keys + grain dims + filters +
        # CALCULATE predicate columns; used to project deduped dim subqueries
        needed: dict[str, set[str]] = {}
        for d in grp.reachable:
            needed.setdefault(d.table, set()).add(d.column)
            # sortByColumn is MIN-aggregated later; the deduped subquery must project it
            sc = self._sort_column(d.table, d.column)
            if sc:
                needed[d.table].add(sc)
        slot_columns: dict[str, dict[str, list[str]]] = {}
        for f in spec.filters:
            if f.op == "slot" and self._tpl is not None:
                # projected only when the slot is active (a conditional block)
                slot_columns.setdefault(f.table, {}).setdefault(f.column, []).append(
                    f.params["sid"]
                )
                continue
            needed.setdefault(f.table, set()).add(f.column)
        for p in ctx.filters:
            table_ref = re.escape(_q(p.table))
            for col in re.findall(rf'{table_ref}\.("(?:[^"]|"")+")', p.sql):
                needed.setdefault(p.table, set()).add(col[1:-1].replace('""', '"'))
        for rel_table in grp.related:
            table_ref = re.escape(_q(rel_table))
            for leaf_sql in grp.leaves.values():
                for col in re.findall(rf'{table_ref}\.("(?:[^"]|"")+")', leaf_sql):
                    needed.setdefault(rel_table, set()).add(col[1:-1].replace('""', '"'))

        def _dim_source(table: str, join_col: str, next_out_col: str | None) -> str:
            """Dim joined as a DISTINCT projection — one row per key set, so a
            non-unique join key on the one-side cannot fan out fact rows
            (mirrors PBI's unique-one-side relationship semantics)."""
            cols = {join_col} | needed.get(table, set())
            if next_out_col:
                cols.add(next_out_col)
            proj = ", ".join(qcol(table, c) for c in sorted(cols))
            for col, sids in sorted(slot_columns.get(table, {}).items()):
                if col not in cols and self._tpl is not None:
                    proj += self._tpl.block(sids, f", {qcol(table, col)}")
            # identifiers validated by safe_ident in _physical/qcol
            return (
                f'(SELECT DISTINCT {proj} FROM {self._physical(table)} AS {_q(table)})'  # noqa: S608
            )

        def ensure(table: str) -> str | None:
            """Join `table` reachable from fact; date table maps to d_cur under shift."""
            if shift and table == date_table:
                return _D_CUR if _D_CUR in joined.values() else None
            if table in joined:
                return joined[table]
            path = self.join_path(fact, table, ctx.use_relationships)
            if path is None:
                return None
            if any(e.many_to_many for e in path):
                warnings.append(
                    _overlay_warning(
                        "M2M_PATH",
                        f"path {fact}->{table} crosses many-to-many relationship; "
                        "verify totals for potential fanout",
                    )
                )
            hop = fact
            for i, e in enumerate(path):
                if e.to_table not in joined:
                    nxt = path[i + 1].from_column if i + 1 < len(path) else None
                    joins.append(
                        f'JOIN {_dim_source(e.to_table, e.to_column, nxt)} AS {_q(e.to_table)} ON '
                        f"{qcol(joined[hop], e.from_column)} = {qcol(e.to_table, e.to_column)}"
                    )
                    joined[e.to_table] = e.to_table
                hop = e.to_table
            return joined[table]

        date_in_grain = any(shift and d.table == date_table for d in spec.dimensions)
        date_filters = [f for f in spec.filters if shift and f.table == date_table]
        anchor_sql = None

        if shift:
            path = self.join_path(fact, date_table, ctx.use_relationships)
            if path is None or len(path) != 1:
                raise QueryPlanError(f"time shift needs single-hop fact->{date_table}")
            edge = path[0]
            joins.append(
                f'JOIN {self._physical(date_table)} AS {_q(_D_DATA)} ON '
                f"{qcol(fact, edge.from_column)} = {qcol(_D_DATA, edge.to_column)}"
            )
            joined[_D_DATA] = _D_DATA
            dcol_data = qcol(_D_DATA, shift.date_column)

            if shift.kind == "sply" or date_in_grain:
                cond = {
                    "sply": f"{dcol_data} = DATEADD(year, -1, {qcol(_D_CUR, shift.date_column)})",
                    "ytd": (
                        f"YEAR({dcol_data}) = YEAR({qcol(_D_CUR, shift.date_column)}) "
                        f"AND {dcol_data} <= {qcol(_D_CUR, shift.date_column)}"
                    ),
                    "rolling": (
                        f"{dcol_data} > DATEADD({shift.unit}, -{shift.n}, "
                        f"{qcol(_D_CUR, shift.date_column)}) "
                        f"AND {dcol_data} <= {qcol(_D_CUR, shift.date_column)}"
                    ),
                }[shift.kind]
                joins.append(f'JOIN {self._physical(date_table)} AS {_q(_D_CUR)} ON {cond}')
                joined[_D_CUR] = _D_CUR
            else:
                # ytd/rolling on a card: anchor at MAX(date) under the context's date filters
                anchor_filters = " AND ".join(
                    self._filter_sql(f, "a") for f in date_filters
                )
                # identifiers validated by safe_ident in _physical/qcol
                anchor_sql = (
                    f"(SELECT MAX({qcol('a', shift.date_column)}) "  # noqa: S608
                    f'FROM {self._physical(date_table)} AS "a"'
                    + (f" WHERE {anchor_filters}" if anchor_filters else "")
                    + ")"
                )

        # grain: only dims reachable from this group's fact (others repeat via frame)
        select_dims, group_by = [], []
        for d in grp.reachable:
            alias = ensure(d.table)
            if alias is None:
                raise QueryPlanError(f"dimension {d.table} unreachable from {fact}")
            select_dims.append(f'{qcol(alias, d.column)} AS {_q(d.key)}')
            group_by.append(qcol(alias, d.column))

        # tables only read by row expressions (RELATED) are joined like dimensions
        for rel_table in sorted(grp.related):
            if ensure(rel_table) is None:
                raise QueryPlanError(
                    f"table {rel_table} used by a row expression is unreachable from {fact}"
                )

        # filters
        where: list[str] = []
        effective_clears = self._effective_clears(ctx)
        for f in spec.filters:
            if self._is_cleared(ctx, effective_clears, f.table, f.column):
                continue
            if shift and f.table == date_table:
                if date_in_grain or shift.kind == "sply":
                    where.append(self._filter_sql(f, _D_CUR))
                # else consumed by the anchor subquery
                continue
            if f.table not in joined:
                # filter-only dim: semi-join (IN subquery) instead of JOIN —
                # immune to fan-out when the dim's join key is non-unique
                path = self.join_path(fact, f.table, ctx.use_relationships)
                if path is not None:
                    if any(e.many_to_many for e in path):
                        warnings.append(
                            _overlay_warning(
                                "M2M_FILTER_PATH",
                                f"filter path {fact}->{f.table} crosses many-to-many relationship",
                            )
                        )
                    semi = self._semi_join_sql(fact, path, f)
                    if f.op == "slot" and self._tpl is not None:
                        semi = self._tpl.block([f.params["sid"]], semi, otherwise="1=1")
                    where.append(semi)
                    continue
            alias = ensure(f.table)
            if alias is None:
                warnings.append(
                    _overlay_warning(
                        "UNREACHABLE_FILTER",
                        f"filter on {f.table} unreachable from {fact}; ignored",
                    )
                )
                continue
            where.append(self._filter_sql(f, alias))

        if anchor_sql:
            dcol_data = qcol(_D_DATA, shift.date_column)
            if shift.kind == "ytd":
                where.append(
                    f"YEAR({dcol_data}) = YEAR({anchor_sql}) AND {dcol_data} <= {anchor_sql}"
                )
            else:
                where.append(
                    f"{dcol_data} > DATEADD({shift.unit}, -{shift.n}, {anchor_sql}) "
                    f"AND {dcol_data} <= {anchor_sql}"
                )

        for p in ctx.filters:
            if shift and p.table == date_table and date_in_grain:
                target = _D_CUR
            else:
                target = ensure(p.table)
            if target is None:
                warnings.append(
                    _overlay_warning(
                        "UNREACHABLE_CALCULATE_FILTER",
                        f"CALCULATE filter on unreachable {p.table}; ignored",
                    )
                )
                continue
            # predicate SQL is emitted against the model-table alias name
            if target == p.table:
                where.append(p.sql)
            else:
                where.append(p.sql.replace(f'{_q(p.table)}', f'{_q(target)}'))

        # Phase-5: include sort_by_column as MIN-aggregated hidden columns
        sort_selects: list[str] = []
        for d in grp.reachable:
            sc = self._sort_column(d.table, d.column)
            if sc:
                tbl_alias = ensure(d.table)
                if tbl_alias:
                    sort_selects.append(
                        f'MIN({qcol(tbl_alias, sc)}) AS {_sortkey(d.key)}'
                    )
        select_leaves = [f'{expr} AS {_q(alias)}' for alias, expr in grp.leaves.items()]
        sql = "SELECT " + ", ".join(select_dims + select_leaves + sort_selects)
        sql += f'\nFROM {self._physical(fact)} AS {_q(fact)}'
        for j in joins:
            sql += f"\n{j}"
        if where:
            sql += "\nWHERE " + " AND ".join(f"({w})" for w in where)
        if group_by:
            sql += "\nGROUP BY " + ", ".join(group_by)
        return sql

    def _combine(
        self, spec, compiled, groups, leaf_to_group, sub_sql, frame_sql, window_ctes=None
    ) -> str:
        window_ctes = window_ctes or {}
        grp_list = list(groups.values())
        aliases = [g.alias for g in grp_list]
        dim_keys = [d.key for d in spec.dimensions]

        window_aliases: dict[str, tuple[str, str]] = {}  # measure key -> (cte alias, join key)
        for i, (mkey, (join_key, _body)) in enumerate(window_ctes.items()):
            window_aliases[mkey] = (f"w{i}", join_key)

        def expr_for(key: str) -> str:
            if key in window_aliases:
                return f'{_q(window_aliases[key][0])}."__v"'
            expr = compiled[key].expr
            # longest-first so __m10 is replaced before __m1
            for local_alias in sorted(compiled[key].leaves, key=len, reverse=True):
                gkey, galias = leaf_to_group[(key, local_alias)]
                expr = expr.replace(local_alias, f"{_q(groups[gkey].alias)}.{_q(galias)}")
            return expr

        exprs = {m.key: expr_for(m.key) for m in spec.measures}
        select_measures = [f"{exprs[m.key]} AS {_q(m.key)}" for m in spec.measures]
        for i in range(len(spec.measure_filters)):
            exprs[f"__mf{i}"] = expr_for(f"__mf{i}")

        sql = "WITH " + ",\n".join(f"{_q(a)} AS (\n{sub_sql[a]}\n)" for a in aliases)
        for mkey, (walias, _jk) in window_aliases.items():
            sql += f',\n{_q(walias)} AS (\n{window_ctes[mkey][1]}\n)'

        # sortByColumn ordering: honored when the frame carries __sort_ cols
        sort_orders: list[str] = []
        # sortByColumn expressions per dim key, usable by explicit sorts too
        sort_expr_by_key: dict[str, str] = {}
        multi = len(aliases) > 1

        if frame_sql is not None:
            # frame = full cell grid; each group LEFT JOINs on its reachable keys
            sql += f',\n"__frame" AS (\n{frame_sql}\n)'
            select_dims = [f'"__frame".{_q(k)} AS {_q(k)}' for k in dim_keys]
            sql += "\nSELECT " + ", ".join(select_dims + select_measures)
            sql += '\nFROM "__frame"'
            for grp in grp_list:
                keys = [d.key for d in grp.reachable]
                if keys:
                    cond = " AND ".join(
                        f'"__frame".{_q(k)} = {_q(grp.alias)}.{_q(k)}' for k in keys
                    )
                    sql += f"\nLEFT JOIN {_q(grp.alias)} ON {cond}"
                else:
                    sql += f"\nCROSS JOIN {_q(grp.alias)}"
            for _mkey, (walias, jk) in window_aliases.items():
                sql += f'\nLEFT JOIN {_q(walias)} ON "__frame".{_q(jk)} = {_q(walias)}."k"'
            for d in spec.dimensions:
                if self._sort_column(d.table, d.column):
                    sort_expr_by_key[d.key] = f'"__frame".{_sortkey(d.key)}'
                    sort_orders.append(sort_expr_by_key[d.key])
            blank_filter = bool(dim_keys)
        else:
            base = aliases[0]
            if len(aliases) == 1:
                select_dims = [f"{_q(base)}.{_q(k)} AS {_q(k)}" for k in dim_keys]
            else:
                select_dims = [
                    "COALESCE(" + ", ".join(f"{_q(a)}.{_q(k)}" for a in aliases) + f") AS {_q(k)}"
                    for k in dim_keys
                ]
            sql += "\nSELECT " + ", ".join(select_dims + select_measures)
            sql += f"\nFROM {_q(base)}"
            for i, a in enumerate(aliases[1:], start=1):
                if dim_keys:
                    conds = []
                    for k in dim_keys:
                        left = (
                            f"{_q(base)}.{_q(k)}"
                            if i == 1
                            else "COALESCE("
                            + ", ".join(f"{_q(x)}.{_q(k)}" for x in aliases[:i])
                            + ")"
                        )
                        conds.append(
                            f"({left} = {_q(a)}.{_q(k)} "
                            f"OR ({left} IS NULL AND {_q(a)}.{_q(k)} IS NULL))"
                        )
                    sql += f"\nFULL OUTER JOIN {_q(a)} ON " + " AND ".join(conds)
                else:
                    sql += f"\nCROSS JOIN {_q(a)}"
            for _mkey, (walias, jk) in window_aliases.items():
                sql += f'\nLEFT JOIN {_q(walias)} ON {_q(base)}.{_q(jk)} = {_q(walias)}."k"'
            # sort-by-column: COALESCE across the subqueries that carry it
            for d in spec.dimensions:
                sc = self._sort_column(d.table, d.column)
                if sc:
                    carriers = [g.alias for g in grp_list if d in g.reachable] or [base]
                    parts = [f"{_q(a)}.{_sortkey(d.key)}" for a in carriers]
                    sort_expr_by_key[d.key] = (
                        parts[0] if len(parts) == 1 else "COALESCE(" + ", ".join(parts) + ")"
                    )
                    sort_orders.append(sort_expr_by_key[d.key])
            blank_filter = multi and bool(dim_keys)

        # SUMMARIZECOLUMNS semantics: cells where every projected measure is blank are dropped
        conds: list[str] = []
        if blank_filter and spec.measures:
            conds.append(
                "(" + " OR ".join(f"({exprs[m.key]}) IS NOT NULL" for m in spec.measures) + ")"
            )
        conds += self._measure_filter_conditions(spec, exprs)
        if conds:
            sql += "\nWHERE " + " AND ".join(conds)

        if spec.sort:
            # a dim with sortByColumn sorts by that column even when the sort
            # is explicit (PBI: month names order Jan..Dec, not alphabetically)
            orders = [
                sort_expr_by_key.get(s["key"], _q(s["key"]))
                + (" DESC" if str(s.get("direction", "")).lower().startswith("desc") else " ASC")
                for s in spec.sort
            ]
            sql += "\nORDER BY " + ", ".join(orders)
        elif sort_orders:
            sql += "\nORDER BY " + ", ".join(sort_orders)
        elif dim_keys:
            sql += "\nORDER BY " + ", ".join(_q(k) for k in dim_keys)
        if spec.limit:
            sql += f"\nLIMIT {int(spec.limit)}"
        return sql

