"""Parse cache, compile memo, parallel execution and validation reuse (phase 06.1/06.2/06.13)."""

from __future__ import annotations

import json
import threading
import time

import pytest

from app.core import parallel
from app.core.parallel import run_parallel
from app.dax import parser as dp
from app.dax.compiler import DaxUnsupported, MeasureCompiler
from app.dax.parser import DaxParseError, parse_dax, parse_dax_uncached, strip_comments
from app.runtime.dashboard import compile_dashboard
from app.validation.harness import CachingCursor, run_validation
from tests.duck import DuckWorld


@pytest.fixture()
def cache_dir(tmp_path):
    dp.set_parse_cache_dir(tmp_path / "dax")
    yield tmp_path / "dax"
    dp.set_parse_cache_dir(tmp_path / "other")


def test_cached_ast_equals_uncached(cache_dir):
    text = 'CALCULATE(SUM(T[a]), T[b] IN {"x", "y"}) + [M]'
    assert parse_dax(text) == parse_dax_uncached(text)
    assert parse_dax(text) == parse_dax_uncached(text)


def test_disk_round_trip_after_clearing_memory(cache_dir):
    text = "SUM(T[a]) + 1"
    first = parse_dax(text)
    files = list(cache_dir.rglob("*.json"))
    assert len(files) == 1
    dp.clear_memory_cache()
    assert parse_dax(text) == first
    stored = json.loads(files[0].read_text(encoding="utf-8"))
    assert stored["grammar"] == dp.GRAMMAR_VERSION and stored["text"] == text
    assert stored["ast"]["t"] == "BinOp"  # typed JSON, never pickle


def test_parse_errors_are_cached_and_reraised_as_new_errors(cache_dir):
    with pytest.raises(DaxParseError) as e1:
        parse_dax("SUM(")
    dp.clear_memory_cache()
    with pytest.raises(DaxParseError) as e2:
        parse_dax("SUM(")
    assert e1.value is not e2.value and str(e1.value) == str(e2.value)
    assert any("error" in json.loads(f.read_text()) for f in cache_dir.rglob("*.json"))


def test_corrupt_or_foreign_entries_are_ignored(cache_dir):
    text = "SUM(T[a])"
    parse_dax(text)
    (path,) = cache_dir.rglob("*.json")
    dp.clear_memory_cache()
    path.write_text("{not json", encoding="utf-8")
    assert parse_dax(text) == parse_dax_uncached(text)
    dp.clear_memory_cache()
    path.write_text(json.dumps({"grammar": "other", "text": text, "ast": {}}), encoding="utf-8")
    assert parse_dax(text) == parse_dax_uncached(text)
    dp.clear_memory_cache()
    path.write_text(
        json.dumps({"grammar": dp.GRAMMAR_VERSION, "text": "different", "ast": None}),
        encoding="utf-8",
    )
    assert parse_dax(text) == parse_dax_uncached(text)


def test_unknown_node_types_are_never_instantiated(cache_dir):
    text = "SUM(T[a])"
    parse_dax(text)
    (path,) = cache_dir.rglob("*.json")
    dp.clear_memory_cache()
    evil = {
        "grammar": dp.GRAMMAR_VERSION,
        "text": text,
        "ast": {"t": "os.system", "f": {"command": "echo pwned"}},
    }
    path.write_text(json.dumps(evil), encoding="utf-8")
    assert parse_dax(text) == parse_dax_uncached(text)  # a miss, not an instantiation
    with pytest.raises(dp._CacheMiss):
        dp._decode({"t": "Popen", "f": {}})


def test_disabled_disk_cache_writes_nothing(tmp_path):
    dp.set_parse_cache_dir(tmp_path / "off", disabled=True)
    parse_dax("SUM(T[zz])")
    assert not (tmp_path / "off").exists()
    dp.set_parse_cache_dir(tmp_path / "other")


def test_warm_parses_each_distinct_text_once(cache_dir):
    texts = ["SUM(T[a])", "SUM(T[a])", "SUM(T[b])", "SUM("]
    assert dp.warm_parse_cache(texts) == 3
    assert dp.warm_parse_cache(texts) == 0


def test_comments_removed_outside_literals():
    assert strip_comments('"a--b" + \'x//y\' + [c--d] -- gone\n+ 1 /* z */').split() == [
        '"a--b"', "+", "'x//y'", "+", "[c--d]", "+", "1",
    ]
    ast = parse_dax("CALCULATE([M], -- keep M\n  T[x] = 1 /* a */) // end")
    assert ast.name == "CALCULATE" and len(ast.args) == 2


def test_spaced_constant_calls_and_exact_column_names():
    assert parse_dax("TRUE ( )") == parse_dax("TRUE()") == parse_dax("TRUE")
    assert parse_dax("BLANK ( )") == parse_dax("BLANK()")
    w = DuckWorld(
        {"T": (["Rolling Period ", "V"], [("p", 1.0)])},
        measures={"M": "SUM(T[V]) + COUNTROWS(FILTER(T, T[Rolling Period ] = \"p\"))"},
    )
    assert w.value("M") == 2.0  # the trimmed name resolves to the model's exact column


# ------------------------------------------------------------------ compile memo / parallel


def test_memo_returns_the_same_object_and_memoizes_failures():
    w = DuckWorld(
        {"T": (["V"], [(1.0,)])},
        measures={"A": "SUM(T[V])", "Bad": "CONCATENATEX(T, T[V], \",\")"},
    )
    comp = MeasureCompiler(w.model)
    assert comp.compile_measure("A") is comp.compile_measure("a")
    for _ in range(2):
        with pytest.raises(DaxUnsupported):
            comp.compile_measure("Bad")


def test_run_parallel_preserves_order_and_is_truly_parallel():
    barrier = threading.Barrier(4, timeout=5)
    seen: set[str] = set()

    def work(i: int) -> int:
        seen.add(threading.current_thread().name)
        barrier.wait()  # only passes when four workers run at the same time
        return i * i

    assert run_parallel(work, [1, 2, 3, 4], max_workers=4) == [1, 4, 9, 16]
    assert all(name.startswith("pbic-q") for name in seen)


def test_run_parallel_single_item_runs_inline():
    names: list[str] = []
    assert run_parallel(lambda x: names.append(threading.current_thread().name) or x, [7]) == [7]
    assert names == [threading.current_thread().name]
    assert parallel.MAX_PARALLEL_QUERIES >= 1


def test_max_parallel_env_minimum_is_one(monkeypatch):
    monkeypatch.setenv("PBIC_MAX_PARALLEL_QUERIES", "0")
    assert parallel._read_max_parallel() == 1
    monkeypatch.setenv("PBIC_MAX_PARALLEL_QUERIES", "3")
    assert parallel._read_max_parallel() == 3


# ------------------------------------------------------------------ validation reuse


class CountingCursor:
    def __init__(self, world: DuckWorld, bindings, delay: float = 0.0):
        from app.runtime.accelerate import to_duckdb_sql

        self._to = to_duckdb_sql
        self.world = world
        self.bindings = bindings
        self.executed: list[str] = []
        self.description: list = []
        self._rows: list = []
        self.connection = self
        self.delay = delay
        self._con = world.con.cursor()  # DuckDB cursors are the thread-safe way to share a database

    def cursor(self):
        return CountingCursor.sibling(self)

    @classmethod
    def sibling(cls, parent):
        child = cls(parent.world, parent.bindings, parent.delay)
        child.executed = parent.executed
        child.connection = parent
        return child

    def execute(self, sql, *a):
        self.executed.append(sql)
        if self.delay:
            time.sleep(self.delay)
        res = self._con.execute(self._to(sql, self.bindings))
        self.description = [(d[0],) for d in res.description]
        self._rows = res.fetchall()
        return self

    def fetchall(self):
        return self._rows

    def fetchone(self):
        return self._rows[0] if self._rows else None

    def close(self):
        pass


def _dashboard_world():
    from app.ir.model import Column, Measure, Partition, Table
    from app.ir.report import Page, Report, ReportBundle, Visual, VisualField, VisualPosition

    w = DuckWorld(
        {
            "Sales": (["Key", "Amt"], [(1, 10.0), (2, 5.0)]),
            "Dim": (["Id", "Name"], [(1, "a"), (2, "b")]),
        },
        rels=[("Sales", "Key", "Dim", "Id")],
        measures={"Total": "SUM(Sales[Amt])"},
    )
    visuals = [
        Visual(
            name=f"v{i}",
            visual_type="card" if i % 2 else "clusteredColumnChart",
            position=VisualPosition(x=0, y=0, width=10, height=10),
            fields=[VisualField(role="Values", table="Sales", name="Total", is_measure=True)]
            + (
                [VisualField(role="Category", table="Dim", name="Name")] if i % 2 == 0 else []
            ),
        )
        for i in range(4)
    ]
    bundle = ReportBundle(
        source_path="x",
        model=w.model,
        report=Report(pages=[Page(name="p", display_name="P", visuals=visuals)]),
    )
    return w, bundle, Column, Measure, Partition, Table


def test_validation_scores_identical_with_reuse_and_parallel_prefetch():
    from app.agents.pipeline import _compile_with_overrides  # noqa: F401

    w, bundle, *_ = _dashboard_world()
    spec, bm = compile_dashboard(bundle)
    # table partitions are not M sources here: bind to the DuckDB extract tables directly
    bm = w.bindings
    engine = w.engine()
    plain = CountingCursor(w, bm)
    sequential = run_validation(spec, engine, plain)
    cache: dict = {}
    parallel_cursor = CountingCursor(w, bm)
    first = run_validation(spec, engine, parallel_cursor, result_cache=cache)
    runs_after_first = len(parallel_cursor.executed)
    second = run_validation(spec, engine, parallel_cursor, result_cache=cache)
    assert first.summary() == sequential.summary() == second.summary()
    assert len(parallel_cursor.executed) == runs_after_first  # a second round re-executes nothing
    assert len(set(parallel_cursor.executed)) == len(parallel_cursor.executed)  # distinct SQL once


def test_caching_cursor_reuses_results_and_errors():
    class Boom:
        description = [("c",)]
        calls = 0

        def execute(self, sql, *a):
            Boom.calls += 1
            if "bad" in sql:
                raise RuntimeError("nope")

        def fetchall(self):
            return [(1,)]

    cache: dict = {}
    cur = CachingCursor(Boom(), cache)
    for _ in range(2):
        cur.execute("select 1")
        assert cur.fetchall() == [(1,)] and cur.description == [("c",)]
    for _ in range(2):
        with pytest.raises(RuntimeError, match="nope"):
            cur.execute("bad sql")
    assert Boom.calls == 2
