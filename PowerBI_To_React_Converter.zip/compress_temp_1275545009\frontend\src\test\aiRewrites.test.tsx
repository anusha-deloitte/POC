import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { AiRewrites } from '../steps/AiRewrites'
import { useWizard } from '../store/wizard'

function wrap(ui: React.ReactElement) {
  const qc = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  })
  return render(<QueryClientProvider client={qc}>{ui}</QueryClientProvider>)
}

const rewrite = {
  expression: 'CALCULATE(SUM(F[x]))',
  original: 'SUMX(F, F[x])',
  source: 'ai',
  gates: ['compiles', 'runs on every visual'],
  created_at: 1,
}

describe('AiRewrites', () => {
  beforeEach(() => {
    useWizard.getState().reset()
    useWizard.setState({ conversionId: 'c1' })
  })
  afterEach(() => vi.restoreAllMocks())

  it('renders nothing without rewrites', async () => {
    const fetchMock = vi.fn(async () => new Response(JSON.stringify({ rewrites: {} })))
    vi.stubGlobal('fetch', fetchMock)
    wrap(<AiRewrites />)
    await waitFor(() => expect(fetchMock).toHaveBeenCalled())
    expect(screen.queryByTestId('ai-rewrites')).toBeNull()
  })

  it('lists rewrites and reverts one', async () => {
    let rewrites: Record<string, typeof rewrite> = { Sales: rewrite }
    const fetchMock = vi.fn(async (_url: string, init?: RequestInit) => {
      if (init?.method === 'DELETE') {
        rewrites = {}
        return new Response(JSON.stringify({ reverted: 'Sales', remaining: [] }))
      }
      return new Response(JSON.stringify({ rewrites }))
    })
    vi.stubGlobal('fetch', fetchMock)
    wrap(<AiRewrites />)
    expect(await screen.findByText('AI-rewritten DAX (1)')).toBeTruthy()
    expect(screen.getByText('SUMX(F, F[x])')).toBeTruthy()
    expect(screen.getByText('compiles')).toBeTruthy()
    await userEvent.click(screen.getByRole('button', { name: 'Revert' }))
    await waitFor(() => expect(screen.queryByTestId('ai-rewrites')).toBeNull())
    expect(
      fetchMock.mock.calls.some(
        ([u, i]) => String(u).endsWith('/dax-rewrites/Sales') && i?.method === 'DELETE',
      ),
    ).toBe(true)
  })
})
