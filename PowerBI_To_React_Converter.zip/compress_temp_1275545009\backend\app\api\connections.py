from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from app.api.deps import get_connection_store, get_snowflake_session_manager, require_token
from app.core.logging import get_logger, log_event
from app.services.connections import (
    ConnectionStore,
    ConnectionValidationError,
    SnowflakeProfile,
    SnowflakeProfileIn,
    SnowflakeProfileUpdate,
)
from app.services.snowflake_sessions import SnowflakeMfaRequired, SnowflakeSessionManager

_logger = get_logger("connections_api")


class ConnectionTestRequest(BaseModel):
    passcode: str | None = None
    force: bool = False

router = APIRouter(
    prefix="/api/v1/connections", tags=["connections"], dependencies=[Depends(require_token)]
)

# data-source catalogue for the connect wizard; snowflake is implemented,
# the rest are roadmap surfaces shown for scoping conversations
SOURCE_TYPES = [
    {"id": "snowflake", "label": "Snowflake", "available": True},
    {"id": "databricks", "label": "Databricks SQL", "available": False},
    {"id": "bigquery", "label": "Google BigQuery", "available": False},
    {"id": "synapse", "label": "Azure Synapse", "available": False},
    {"id": "redshift", "label": "Amazon Redshift", "available": False},
    {"id": "postgres", "label": "PostgreSQL", "available": False},
    {"id": "sqlserver", "label": "SQL Server", "available": False},
]


@router.get("/source-types")
def source_types() -> list[dict]:
    return SOURCE_TYPES


@router.post("", status_code=201, response_model=SnowflakeProfile)
def create_connection(
    spec: SnowflakeProfileIn,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> SnowflakeProfile:
    try:
        return store.create(spec)
    except ConnectionValidationError as e:
        raise HTTPException(422, str(e)) from e


@router.get("", response_model=list[SnowflakeProfile])
def list_connections(
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> list[SnowflakeProfile]:
    return store.list()


@router.get("/{profile_id}", response_model=SnowflakeProfile)
def get_connection(
    profile_id: str,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
) -> SnowflakeProfile:
    try:
        return store.get(profile_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e


@router.delete("/{profile_id}", status_code=204)
def delete_connection(
    profile_id: str,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
    sessions: Annotated[SnowflakeSessionManager, Depends(get_snowflake_session_manager)],
) -> None:
    try:
        sessions.evict(profile_id)
        store.delete(profile_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e


@router.patch("/{profile_id}", response_model=SnowflakeProfile)
def update_connection(
    profile_id: str,
    patch: SnowflakeProfileUpdate,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
    sessions: Annotated[SnowflakeSessionManager, Depends(get_snowflake_session_manager)],
) -> SnowflakeProfile:
    try:
        profile = store.update(profile_id, patch)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e
    except ConnectionValidationError as e:
        raise HTTPException(422, str(e)) from e
    sessions.settings_changed(profile_id)  # keeps the signed-in session
    return profile


@router.post("/{profile_id}/test")
def test_connection_endpoint(
    profile_id: str,
    store: Annotated[ConnectionStore, Depends(get_connection_store)],
    sessions: Annotated[SnowflakeSessionManager, Depends(get_snowflake_session_manager)],
    body: ConnectionTestRequest | None = None,
) -> dict:
    try:
        profile = store.get(profile_id)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e
    body = body or ConnectionTestRequest()
    passcode = (body.passcode or "").strip() or None

    def _log(ok: bool, error: str | None = None, result: dict | None = None) -> None:
        result = result or {}
        log_event(
            _logger,
            "info" if ok else "warning",
            "snowflake_connection_test",
            profile_id=profile_id,
            ok=ok,
            error=error,
            configured_warehouse=profile.warehouse,
            role=result.get("role"),
            warehouse=result.get("warehouse"),
            database=result.get("database"),
        )

    try:
        connection = sessions.authenticate(
            profile_id,
            query_tag="pbic:connection-test",
            passcode=passcode,
            force=body.force,
        )
    except SnowflakeMfaRequired as e:
        _log(False, str(e))
        return {"ok": False, "error": str(e), "mfa_required": True}
    except ValueError as e:
        _log(False, str(e))
        raise HTTPException(422, f"invalid connection configuration: {e}") from e
    except ModuleNotFoundError as e:
        raise HTTPException(
            501, "snowflake-connector-python not installed (install extra: snowflake)"
        ) from e
    except Exception as e:  # connector raises many exception types during authentication
        _log(False, str(e))
        return {"ok": False, "error": str(e)}
    try:
        from app.services.connections import probe_connection

        result = probe_connection(connection)
        _log(True, None, result)
        return result
    except ModuleNotFoundError as e:
        raise HTTPException(
            501, "snowflake-connector-python not installed (install extra: snowflake)"
        ) from e
    except Exception as e:  # connector raises many exception types
        _log(False, str(e))
        return {"ok": False, "error": str(e)}


@router.get("/{profile_id}/session")
def connection_session_status(
    profile_id: str,
    sessions: Annotated[SnowflakeSessionManager, Depends(get_snowflake_session_manager)],
    verify: bool = False,
) -> dict:
    try:
        return sessions.status(profile_id, verify=verify)
    except (KeyError, ValueError) as e:
        raise HTTPException(404, "connection not found") from e
