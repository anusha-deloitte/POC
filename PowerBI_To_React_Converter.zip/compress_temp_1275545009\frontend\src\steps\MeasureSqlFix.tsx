import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { auditApi } from '../api/client'
import type { MeasureSqlResult } from '../api/types'
import { useWizard } from '../store/wizard'

export function MeasureSqlFix({ measure }: { measure: string }) {
  const conversionId = useWizard((s) => s.conversionId)!
  const connectionId = useWizard((s) => s.connectionId)
  const queryClient = useQueryClient()
  const fixes = useQuery({
    queryKey: ['measure-sql', conversionId],
    queryFn: () => auditApi.measureSqlFixes(conversionId),
  })
  const existing = fixes.data?.fixes[measure]
  const [open, setOpen] = useState(false)
  const [text, setText] = useState('')
  const [checked, setChecked] = useState<{ text: string; result: MeasureSqlResult } | null>(null)

  const refresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ['measure-sql', conversionId] })
    await queryClient.invalidateQueries({ queryKey: ['compilation-audit', conversionId] })
    await queryClient.invalidateQueries({ queryKey: ['dash-spec', conversionId] })
    await queryClient.invalidateQueries({ queryKey: ['no-sql-panes', conversionId] })
  }
  const check = useMutation({
    mutationFn: () =>
      auditApi.testMeasureSql(conversionId, { measure, sql: text, connection_id: connectionId! }),
    onSuccess: (result) => setChecked({ text, result }),
  })
  const save = useMutation({
    mutationFn: () => auditApi.saveMeasureSql(conversionId, { measure, sql: text }),
    onSuccess: refresh,
  })
  const revert = useMutation({
    mutationFn: () => auditApi.revertMeasureSql(conversionId, measure),
    onSuccess: async () => {
      setChecked(null)
      setText('')
      await refresh()
    },
  })

  const result = checked && checked.text === text ? checked.result : null
  const canSave = !!result && result.ok
  const error = check.error ?? save.error ?? revert.error

  const toggle = () => {
    if (!open && !text) setText(existing?.sql ?? '')
    setOpen(!open)
  }

  return (
    <div className="mt-2" data-testid="measure-sql-fix">
      <button type="button" className="btn-secondary !px-2 !py-0.5 !text-xs" onClick={toggle}>
        {existing ? 'Edit measure SQL' : 'Fix measure'}
      </button>
      {open && (
        <div className="mt-2 rounded-lg border border-black/[0.08] bg-white p-3 text-xs">
          <p className="text-surface-600">
            Write Snowflake SQL that returns <strong>one number or text value</strong>. Use{' '}
            <code>{'{{filters}}'}</code> where slicers should apply. Panes that group by rows can’t
            use it.
          </p>
          <textarea
            aria-label="Measure SQL"
            className="input mt-2 h-32 font-mono text-xs"
            value={text}
            spellCheck={false}
            onChange={(e) => setText(e.target.value)}
          />
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <button
              type="button"
              className="btn-secondary !text-xs"
              disabled={!connectionId || !text.trim() || check.isPending}
              onClick={() => check.mutate()}
            >
              {check.isPending ? 'Checking…' : 'Check on Snowflake'}
            </button>
            <button
              type="button"
              className="btn-primary !text-xs"
              disabled={!canSave || save.isPending}
              onClick={() => save.mutate()}
            >
              Save
            </button>
            {existing && (
              <button
                type="button"
                className="btn-secondary !text-xs"
                disabled={revert.isPending}
                onClick={() => revert.mutate()}
              >
                Revert
              </button>
            )}
            {!connectionId && (
              <span className="text-surface-500">Select a Snowflake connection to check.</span>
            )}
          </div>
          {error && (
            <p role="alert" className="mt-2 text-brand-red">
              {error.message}
            </p>
          )}
          {result && (
            <div data-testid="measure-sql-result" className="mt-2 space-y-1">
              {result.measure_run.error ? (
                <p role="alert" className="text-brand-red">
                  {result.measure_run.error}
                </p>
              ) : (
                <p className="font-semibold text-brand-dark">
                  Returned {String(result.measure_run.value)}
                </p>
              )}
              {result.fixed_panes.length > 0 && (
                <p>Fixed panes: {result.fixed_panes.map((p) => p.pane).join(', ')}</p>
              )}
              {result.pane_runs
                .filter((r) => r.error)
                .map((r) => (
                  <p key={r.visual} className="text-brand-red">
                    {r.pane}: {r.error}
                  </p>
                ))}
              {result.still_untranslated_measures.length > 0 && (
                <p>
                  Measures still not translated: {result.still_untranslated_measures.join(', ')}
                </p>
              )}
              {result.not_applicable.length > 0 && (
                <p>
                  Not applicable (group by rows): {result.not_applicable.map((p) => p.pane).join(', ')}
                </p>
              )}
              {result.null_comparison_warnings.length > 0 && (
                <ul className="ml-4 list-disc text-brand-amber">
                  {result.null_comparison_warnings.map((w) => (
                    <li key={w}>{w}</li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
