"""Phase 12: the standalone dashboard package and its local service (queries run on DuckDB)."""

from __future__ import annotations

import datetime as dt
import json
import zipfile
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app.runtime import sql_render as sr
from app.runtime.accelerate import to_duckdb_sql
from app.runtime.dashboard import (
    DashboardSpec,
    DrillthroughFieldSpec,
    PageSpec,
    VisualSpec,
)
from app.runtime.engine import DimensionRef, FilterClause, MeasureRefSpec, QuerySpec
from app.runtime.filter_cards import FilterCard
from app.services import sql_overrides as sqlo
from app.services import standalone_export as se
from app.standalone.connection_store import ConnectionStore
from app.standalone.main import create_app
from app.standalone.snowflake_session import AuthenticationRequired
from tests.duck import DuckWorld

D = [
    dt.date(2023, 1, 15),
    dt.date(2023, 7, 15),
    dt.date(2024, 1, 15),
    dt.date(2024, 2, 15),
    dt.date(2024, 7, 15),
]
ROWS = [
    (1, D[0], 1, "N", 10), (2, D[1], 1, "S", 20), (3, D[2], 1, "N", 30), (4, D[2], 2, "S", 40),
    (5, D[3], 2, "N", 50), (6, D[4], 3, "N", 60), (7, D[4], 2, None, 70), (8, D[1], 3, "S", 5),
]  # fmt: skip
TOKEN = "t"
P1, P2 = "page1", "detail"


def make_world() -> DuckWorld:
    return DuckWorld(
        {
            "Sales": (["id", "date_key", "cat_key", "region", "amount"], ROWS),
            "Cat": (["cat_key", "cat_name"], [(1, "Alpha"), (2, "Beta"), (3, "Gamma")]),
            "Date": (["date_key", "month", "year"], [(d, d.month, d.year) for d in D]),
        },
        rels=[("Sales", "cat_key", "Cat", "cat_key"), ("Sales", "date_key", "Date", "date_key")],
        measures={"Total": "SUM(Sales[amount])"},
        measure_table="Sales",
    )


def dims(*keys: str) -> list[DimensionRef]:
    return [DimensionRef(table=k.split(".")[0], column=k.split(".")[1]) for k in keys]


def visual(name: str, vtype: str, *, dim=(), measures=("Total",), **kw) -> VisualSpec:
    query = QuerySpec(dimensions=dims(*dim), measures=[MeasureRefSpec(name=m) for m in measures])
    return VisualSpec(
        name=name, visual_type=vtype, x=0, y=0, width=100, height=100, query=query,
        dim_keys=list(dim), measure_keys=list(measures), **kw,
    )  # fmt: skip


def make_spec() -> DashboardSpec:
    table = visual(
        "table", "tableEx", dim=("Date.year", "Date.month"),
        options={"show_totals": True},
        hierarchy={"name": "h", "levels": ["Date.year", "Date.month"], "current_level": "Date.year"},
    )  # fmt: skip
    slicer = visual(
        "slicer",
        "slicer",
        dim=("Cat.cat_name",),
        measures=(),
        slicer_target={"table": "Cat", "column": "cat_name"},
    )
    note = VisualSpec(name="note", visual_type="textbox", x=0, y=0, width=10, height=10)
    broken = VisualSpec(
        name="broken", visual_type="funnel", x=0, y=0, width=10, height=10,
        supported=False, unsupported_reason="unsupported visual type funnel",
    )  # fmt: skip
    return DashboardSpec(
        report_name="Sales Report",
        report_filters=[
            FilterCard(
                name="f1", scope="report", table="Sales", column="region", display_name="Region"
            )
        ],
        pages=[
            PageSpec(
                name=P1,
                display_name="Overview",
                width=1280,
                height=720,
                ordinal=0,
                visuals=[
                    visual("bar", "barChart", dim=("Cat.cat_name",)),
                    visual("card", "card"),
                    slicer,
                    table,
                    note,
                    broken,
                ],
            ),  # fmt: skip
            PageSpec(
                name=P2,
                display_name="Detail",
                width=1280,
                height=720,
                ordinal=1,
                page_type="Drillthrough",
                drillthrough=[DrillthroughFieldSpec(table="Cat", column="cat_name")],
                visuals=[visual("detail", "tableEx", dim=("Sales.region",))],
            ),  # fmt: skip
        ],
    )


class DuckSession:
    """Stands in for the Snowflake session: runs the service's SQL on DuckDB."""

    def __init__(self, world: DuckWorld):
        self.world = world
        self.ran: list[str] = []
        self.signed_in = True

    def run(self, sql):
        if not self.signed_in:
            raise AuthenticationRequired("Snowflake browser authentication is required")
        self.ran.append(sql)
        cur = self.world.con.cursor()  # one cursor per query: the service runs them in threads
        cur.execute(to_duckdb_sql(sql, self.world.bindings))
        return [d[0] for d in cur.description], [list(r) for r in cur.fetchall()], "qid"

    def status(self):
        return {"authenticated": self.signed_in}

    def authenticate(self, passcode=None):
        self.signed_in = True

    def reset(self):
        pass

    def sign_out(self):
        self.signed_in = False

    def apply_settings(self):
        pass


@pytest.fixture(scope="module")
def world() -> DuckWorld:
    return make_world()


@pytest.fixture
def build_dir(tmp_path: Path) -> Path:
    out = tmp_path / "dist-standalone"
    (out / "assets").mkdir(parents=True)
    (out / "standalone.html").write_text(
        "<html><body>standalone app</body></html>", encoding="utf-8"
    )
    (out / "assets" / "app.js").write_text("console.log(1)", encoding="utf-8")
    return out


PROFILE = SimpleNamespace(
    account="acct", user="me", auth_method="password", role="ANALYST", warehouse="WH",
    database="DB", schema_name="PUBLIC", oauth_client_id=None, oauth_token_url=None,
)  # fmt: skip


def package(world, build_dir, tmp_path, overrides=None) -> tuple[Path, dict[str, bytes]]:
    conv = tmp_path / "conv"
    conv.mkdir(exist_ok=True)
    for (page, vis), sql in (overrides or {}).items():
        sqlo.save_override(conv, page, vis, sql, "test")
    payload = se.build_standalone_zip(
        make_spec(), world.engine(), conv, PROFILE, {"logo.png": b"png"}, build_dir, vendor=False
    )
    out = tmp_path / "pkg"
    with zipfile.ZipFile(__import__("io").BytesIO(payload)) as z:
        names = z.namelist()
        z.extractall(out)
    root = out / "sales-report-standalone"
    return root, {n.split("/", 1)[1]: b"" for n in names}


@pytest.fixture
def pkg(world, build_dir, tmp_path):
    root, names = package(world, build_dir, tmp_path)
    return root, names


@pytest.fixture
def client(world, pkg, monkeypatch):
    root, _ = pkg
    monkeypatch.setenv("PBIS_NO_AUTOSTART", "1")
    session = DuckSession(world)
    store = ConnectionStore(root / "data", "pid", keyring_module=SimpleNamespace(
        get_password=lambda *a: None, set_password=lambda *a: None, delete_password=lambda *a: None))  # fmt: skip
    app = create_app(root, session=session, store=store)
    c = TestClient(
        app,
        headers={"Authorization": f"Bearer {(root / 'data' / 'token.txt').read_text().strip()}"},
    )
    c.session = session  # type: ignore[attr-defined]
    c.root = root  # type: ignore[attr-defined]
    return c


API = "/api/v1/published/dashboard"


def post_query(client, visuals, filters=None, page=P1):
    body = {"queries": [{"page": page, "visual": v, "filters": filters or []} for v in visuals]}
    r = client.post(f"{API}/query", json=body)
    assert r.status_code == 200, r.text
    return {x["visual"]: x for x in r.json()["results"]}


def live(world, vis: str, filters: list[dict]):
    spec = make_spec()
    vs = next(v for p in spec.pages for v in p.visuals if v.name == vis)
    q = vs.query.model_copy(update={"filters": [FilterClause(**f) for f in filters]})
    rows = world.run(q)
    return sorted([list(r) for r in rows], key=str)


def got(result):
    return sorted(result["rows"], key=str)


# ---------------------------------------------------------------------------- the package


def test_package_contents(pkg):
    root, names = pkg
    for path in (
        "app/index.html", "app/assets/app.js", "app/dashboard-config.json", "app/resources/logo.png",
        "service/main.py", "service/snowflake_session.py", "service/manifest.py",
        "service/connection_store.py", "service/render.py",
        "data/spec.json", "data/manifest.json", "data/connection.json", "data/token.txt",
        "start.ps1", "stop.ps1", "install-autostart.ps1", "uninstall-autostart.ps1",
        "README.md", "COVERAGE.md",
    ):  # fmt: skip
        assert path in names, path
    assert not (root / "app" / "standalone.html").exists()
    cfg = json.loads((root / "app" / "dashboard-config.json").read_text())
    assert cfg["api_base"] == "/api/v1/published"
    assert (
        cfg["token"] == (root / "data" / "token.txt").read_text().strip()
        and len(cfg["token"]) >= 32
    )
    assert (root / "service" / "render.py").read_bytes() == Path(sr.__file__).read_bytes()
    assert "Sales Report" in (root / "README.md").read_text()
    manifest = json.loads((root / "data" / "manifest.json").read_text())
    assert (
        manifest["version"] == 1
        and manifest["package_id"]
        and manifest["report_name"] == "Sales Report"
    )
    assert manifest["filter_values_limit"] == 500
    conn = json.loads((root / "data" / "connection.json").read_text())
    assert conn["account"] == "acct" and conn["remember"] is False
    assert not {"password", "private_key_pem", "pat_token", "oauth_client_secret"} & set(conn)
    queries = manifest["queries"]
    assert queries[f"{P1}/note"] == {"kind": "static"}
    assert queries[f"{P1}/broken"] == {"kind": "error", "error": "unsupported visual type funnel"}
    assert queries[f"{P1}/bar"]["file"].startswith("data/templates/")
    assert (root / queries[f"{P1}/bar"]["file"]).is_file()
    assert queries[f"{P1}/table"]["totals"]["file"].endswith(".totals.sql")
    assert set(manifest["drill"][f"{P1}/table"]["by_target"]) == {"0", "1"}
    assert "Sales.region" in manifest["filter_values"]
    assert "Sales Report" in (root / "COVERAGE.md").read_text()


def test_every_template_parses(pkg):
    root, _ = pkg
    manifest = json.loads((root / "data" / "manifest.json").read_text())
    entries = [e for e in manifest["queries"].values() if e.get("kind") == "sql"]
    assert entries and not [e for e in entries if e.get("parse_warning")]


def test_a_slicer_never_filters_its_own_list_but_other_panes_follow_it(pkg):
    root, _ = pkg
    queries = json.loads((root / "data" / "manifest.json").read_text())["queries"]
    cols = lambda key: {s["column"] for s in queries[key]["meta"]["slots"].values()}  # noqa: E731
    assert "cat_name" not in cols(f"{P1}/slicer")
    assert "cat_name" in cols(f"{P1}/bar")
    # filters on a fact table don't reach a dimension's own list: no slot is placed for them
    assert "region" not in cols(f"{P1}/slicer")


def test_drill_through_page_receives_its_source_columns(world):
    spec = make_spec()
    detail = spec.pages[1]
    sources = se.drill_sources(spec, detail)
    assert [(p.name, v.name) for p, v in sources] == [(P1, "bar"), (P1, "slicer")]
    assert ("Cat", "cat_name") in se.source_slot_columns(spec, detail)
    assert ("Sales", "region") in se.page_slots(detail, se.filter_card_columns(spec, detail))


def test_edited_sql_replaces_the_generated_template(world, build_dir, tmp_path):
    edited = 'SELECT "Cat"."cat_name" AS "Cat", SUM("Sales"."amount") AS "Total"\nFROM DB.PUBLIC.SALES AS "Sales"\nJOIN DB.PUBLIC.CAT AS "Cat" ON "Sales"."cat_key" = "Cat"."cat_key"\nWHERE {{filters}}\nGROUP BY 1'
    root, _ = package(world, build_dir, tmp_path, {(P1, "bar"): edited})
    entry = json.loads((root / "data" / "manifest.json").read_text())["queries"][f"{P1}/bar"]
    assert entry["edited"] is True and entry["file"].endswith(".edited.sql")
    text = (root / entry["file"]).read_text()
    assert "{{filters}}" not in text and "{{p:" in text and "cat_name" in text
    assert {s["column"] for s in entry["meta"]["slots"].values()} >= {"cat_name", "region"}


def test_missing_front_end_build_fails_clearly(world, tmp_path):
    with pytest.raises(
        se.StandaloneExportError, match="run `npm run build:standalone` in frontend/"
    ):
        se.build_standalone_zip(
            make_spec(), world.engine(), None, PROFILE, {}, tmp_path / "nope", vendor=False
        )


def test_vendored_packages_are_the_service_closure():
    names = {str(d.metadata["Name"]).lower().replace("_", "-") for d in se.vendor_distributions()}
    assert {"fastapi", "uvicorn", "starlette", "pydantic", "keyring", "cryptography"} <= names
    assert not ({"duckdb", "sqlglot", "pytest"} & names)
    with pytest.raises(
        se.StandaloneExportError, match="Python package 'no-such-package-xyz' is not installed"
    ):
        se.vendor_distributions(("no-such-package-xyz",))


def test_vendor_files_skip_bytecode_and_outside_paths():
    dists = se.vendor_distributions(("uvicorn",))
    files = dict(se._vendor_files(dists))
    assert files and not [
        n for n in files if "__pycache__" in n or n.endswith(".pyc") or n.startswith("..")
    ]


# ---------------------------------------------------------------------------- the service


def test_service_requires_the_local_token(client):
    anon = TestClient(client.app)
    assert anon.get("/api/v1/published/health").json() == {"ok": True, "report": "Sales Report"}
    for method, path in (
        ("get", f"{API}/spec"),
        ("post", f"{API}/query"),
        ("get", "/api/v1/published/session"),
    ):
        r = getattr(anon, method)(path)
        assert r.status_code == 401 and r.json()["detail"] == "missing or invalid dashboard token"
    wrong = TestClient(client.app, headers={"Authorization": "Bearer nope"})
    assert wrong.get(f"{API}/spec").status_code == 401


def test_service_serves_spec_app_and_live_only_mode(client):
    assert client.get(f"{API}/spec").json()["report_name"] == "Sales Report"
    assert "standalone app" in client.get("/").text
    assert client.get(f"{API}/accelerate").json() == {"hydrated": False, "available": False}
    assert client.post(f"{API}/accelerate").status_code == 501
    assert post_query(client, ["card"])["card"]["error"] is None


def test_query_results_match_the_converter(client, world):
    got_all = post_query(client, ["bar", "card", "table", "slicer"])
    for name in ("bar", "card", "table", "slicer"):
        assert got(got_all[name]) == live(world, name, []), name
        assert got_all[name]["sql"] and got_all[name]["execution_path"] == "compatibility"
    assert got_all["table"]["totals"]["row"] is not None
    assert post_query(client, ["note"])["note"]["execution_path"] == "static"
    broken = post_query(client, ["broken"])["broken"]
    assert (
        broken["error"] == "unsupported visual type funnel" and broken["execution_path"] == "error"
    )
    assert post_query(client, ["ghost"])["ghost"]["error"] == "unknown visual"


def test_slicer_and_cross_filters_are_applied_like_the_converter(client, world):
    for filters in (
        [{"table": "Cat", "column": "cat_name", "values": ["Alpha", "Beta"]}],
        [
            {"table": "Sales", "column": "region", "values": ["N"]},
            {"table": "Date", "column": "year", "values": [2024]},
        ],
        [{"table": "Sales", "column": "region", "values": [None]}],
    ):
        for name in ("bar", "card", "table"):
            assert got(post_query(client, [name], filters)[name]) == live(world, name, filters), (
                name,
                filters,
            )


def test_pane_filters_are_applied_like_the_converter(client, world):
    for flt in (
        {"table": "Cat", "column": "cat_name", "op": "contains", "values": ["a"]},
        {"table": "Cat", "column": "cat_name", "op": "not_in", "values": ["Beta"]},
        {"table": "Sales", "column": "region", "op": "is_not_blank", "values": []},
        {"table": "Date", "column": "year", "op": "gte", "values": [2024]},
    ):
        for name in ("bar", "card"):
            assert got(post_query(client, [name], [flt])[name]) == live(world, name, [flt]), (
                name,
                flt,
            )


def test_unsupported_filters_come_back_as_errors_or_warnings(client):
    top = {"table": "Cat", "column": "cat_name", "op": "topn", "params": {"n": 1}}
    assert (
        "Top N filters are not available in the standalone dashboard"
        in post_query(client, ["bar"], [top])["bar"]["error"]
    )
    nowhere = {"table": "Nowhere", "column": "x", "values": [1]}
    r = post_query(client, ["bar"], [nowhere])["bar"]
    assert r["error"] is None and any("UNREACHABLE_FILTER" in w for w in r["warnings"])


def test_results_are_cached_and_cleared_on_sign_out(client):
    first = post_query(client, ["card"])["card"]
    again = post_query(client, ["card"])["card"]
    assert not first["cached"] and again["cached"]
    ran = len(client.session.ran)
    post_query(client, ["card"])
    assert len(client.session.ran) == ran
    assert client.post("/api/v1/published/session/sign-out").json() == {"ok": True}
    client.session.signed_in = True
    assert not post_query(client, ["card"])["card"]["cached"]


def test_drill_down_with_a_parent_filter(client, world):
    r = client.post(
        f"{API}/query/drill",
        json={"page": P1, "visual": "table", "direction": "down", "level_key": "Date.year",
              "parent_filters": [{"table": "Date", "column": "year", "values": [2024]}]},
    )  # fmt: skip
    assert r.status_code == 200, r.text
    body = r.json()
    assert (
        body["level_key"] == "Date.month" and body["level_index"] == 1 and body["total_levels"] == 2
    )
    years = {row[0] for row in body["rows"]}
    assert years == {2024}
    up = client.post(
        f"{API}/query/drill",
        json={"page": P1, "visual": "table", "direction": "up", "level_key": "Date.month"},
    )
    assert up.json()["level_key"] == "Date.year"


def test_drill_errors(client):
    r = client.post(f"{API}/query/drill", json={"page": P1, "visual": "bar", "direction": "down"})
    assert r.status_code == 422 and "no drillable hierarchy" in r.text
    r = client.post(
        f"{API}/query/drill", json={"page": P1, "visual": "table", "direction": "sideways"}
    )
    assert r.status_code == 422 and "direction must be" in r.text


def test_asks_for_snowflake_sign_in(client):
    client.session.signed_in = False
    r = client.post(
        f"{API}/query", json={"queries": [{"page": P1, "visual": "card", "filters": []}]}
    )
    assert r.status_code == 409
    assert r.json()["detail"] == {
        "code": "snowflake_authentication_required",
        "message": "Snowflake browser authentication is required",
        "mfa_required": False,
    }
    drill = client.post(
        f"{API}/query/drill", json={"page": P1, "visual": "table", "direction": "down"}
    )
    assert drill.status_code == 409


def test_filter_values_for_cards(client):
    r = client.post(
        f"{API}/filter-values", json={"table": "Sales", "column": "region", "limit": 500}
    )
    assert r.status_code == 200
    assert r.json() == {"values": ["N", "S", None], "truncated": False} or set(
        r.json()["values"]
    ) == {"N", "S", None}
    s = client.post(
        f"{API}/filter-values", json={"table": "Sales", "column": "region", "search": "n"}
    )
    assert s.json()["values"] == ["N"]
    small = client.post(
        f"{API}/filter-values", json={"table": "Sales", "column": "region", "limit": 2}
    )
    assert len(small.json()["values"]) == 2 and small.json()["truncated"] is True
    missing = client.post(f"{API}/filter-values", json={"table": "Cat", "column": "cat_name"})
    assert (
        missing.status_code == 404 and missing.json()["detail"] == "no value list for Cat[cat_name]"
    )


def test_slots_exist_for_every_filter_card_column(pkg):
    root, _ = pkg
    queries = json.loads((root / "data" / "manifest.json").read_text())["queries"]
    for key in (f"{P1}/bar", f"{P1}/card", f"{P1}/table", f"{P2}/detail"):
        assert "region" in {s["column"] for s in queries[key]["meta"]["slots"].values()}, key
