import type { PageSpec } from '../types'

/** Power BI Service-style page tabs: the non-hidden pages plus the current page when hidden. */
export function pageTabs(pages: PageSpec[], current: string): PageSpec[] {
  return pages.filter((p) => !p.is_hidden || p.name === current)
}

export function PageTabs({
  pages,
  current,
  onSelect,
}: {
  pages: PageSpec[]
  current: string
  onSelect: (name: string) => void
}) {
  const tabs = pageTabs(pages, current)
  if (tabs.length <= 1) return null
  return (
    <nav
      aria-label="Report pages"
      className="flex shrink-0 gap-px overflow-x-auto border-t border-surface-300 bg-surface-100 px-2"
    >
      {tabs.map((p) => (
        <button
          key={p.name}
          type="button"
          onClick={() => onSelect(p.name)}
          aria-current={p.name === current ? 'page' : undefined}
          data-active={p.name === current}
          className="whitespace-nowrap border-t-2 border-transparent px-4 py-2 text-xs font-semibold text-surface-600 hover:bg-white data-[active=true]:border-brand data-[active=true]:bg-white data-[active=true]:text-surface-900"
        >
          {p.display_name}
        </button>
      ))}
    </nav>
  )
}
