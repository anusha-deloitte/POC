"""Phase 10: Top N filters and relative date/time cards (DuckDB, a pinned "today")."""

from __future__ import annotations

import datetime as dt

import pytest

from app.ir.report import Filter, FilterScope
from app.runtime.dashboard import relative_bounds
from app.runtime.engine import DimensionRef, FilterClause, MeasureRefSpec, QueryPlanError, QuerySpec
from app.runtime.filter_cards import _recognise_relative, filter_card
from tests.duck import DuckWorld
from tests.pbir_world import Report, column, measure

TODAY = dt.date(2024, 6, 15)


def sales_world() -> DuckWorld:
    return DuckWorld(
        {
            "Dim": (["k", "cat"], [(1, "A"), (2, "B"), (3, "C"), (4, "D"), (5, "E")]),
            "F": (
                ["k", "region", "v"],
                [
                    (1, "N", 50), (1, "S", 5),
                    (2, "N", 20), (2, "S", 20),
                    (3, "N", 10), (3, "S", 30),
                    (4, "N", 10), (4, "S", 0),
                    # E has no fact rows: its measure is blank
                ],
            ),
        },
        rels=[("F", "k", "Dim", "k")],
        measures={"Total": "SUM(F[v])"},
        measure_table="F",
    )  # fmt: skip


def topn(n=2, direction="top", **by) -> FilterClause:
    params = {"n": n, "direction": direction, **(by or {"measure": "Total"})}
    return FilterClause(table="Dim", column="cat", op="topn", params=params)


def cats(world: DuckWorld, *filters: FilterClause, dims=("Dim.cat",)) -> list:
    spec = QuerySpec(
        dimensions=[DimensionRef(table=d.split(".")[0], column=d.split(".")[1]) for d in dims],
        measures=[MeasureRefSpec(name="Total")],
        filters=list(filters),
    )
    return [r[0] for r in world.run(spec)]


class TestTopN:
    def test_top_two_keeps_the_tie_at_the_cut(self):
        # totals: A 55, B 40, C 40, D 10 -> the cut is at 2 and C ties B
        assert set(cats(sales_world(), topn(2))) == {"A", "B", "C"}

    def test_top_one(self):
        assert cats(sales_world(), topn(1)) == ["A"]

    def test_bottom_n_ignores_blanks(self):
        # E has no rows (blank) and is never ranked, so the bottom 1 is D
        assert cats(sales_world(), topn(1, "bottom")) == ["D"]

    def test_ranked_under_the_other_filters(self):
        region = FilterClause(table="F", column="region", op="in", values=["S"])
        # in S: C 30, B 20, A 5, D 0 -> the top 1 is C
        assert cats(sales_world(), region, topn(1)) == ["C"]
        assert cats(sales_world(), topn(1)) == ["A"]

    def test_independent_of_the_visual_rows(self):
        out = cats(sales_world(), topn(1), dims=("Dim.cat", "F.region"))
        assert set(out) == {"A"}  # A in both regions, whatever the visual's grain

    def test_implicit_aggregate(self):
        world = sales_world()
        by = {"table": "F", "column": "v", "aggregate": "Sum"}
        assert cats(world, topn(1, **by)) == ["A"]
        assert set(cats(world, topn(2, "bottom", **by))) == {"D", "C"} or "D" in cats(world, topn(2, "bottom", **by))

    @pytest.mark.parametrize("n", [0, -1, "5", 1.5, True, None])
    def test_invalid_n_is_refused(self, n):
        with pytest.raises(QueryPlanError, match="positive whole number"):
            sales_world().engine().build_sql(
                QuerySpec(measures=[MeasureRefSpec(name="Total")], filters=[topn(n)])
            )

    def test_injected_values_are_refused(self):
        world = sales_world()
        for bad in ("1; DROP TABLE x", "1) OR (1=1"):
            with pytest.raises(QueryPlanError):
                world.engine().build_sql(
                    QuerySpec(measures=[MeasureRefSpec(name="Total")], filters=[topn(bad)])
                )
        with pytest.raises(QueryPlanError, match="direction"):
            world.engine().build_sql(
                QuerySpec(measures=[MeasureRefSpec(name="Total")], filters=[topn(1, "sideways")])
            )
        no_by = FilterClause(table="Dim", column="cat", op="topn", params={"n": 1, "direction": "top"})
        with pytest.raises(QueryPlanError, match="By value"):
            world.engine().build_sql(QuerySpec(measures=[MeasureRefSpec(name="Total")], filters=[no_by]))

    def test_the_subquery_is_a_ranking_with_ties_kept(self):
        sql, _ = sales_world().engine().build_sql(
            QuerySpec(measures=[MeasureRefSpec(name="Total")], filters=[topn(3)])
        )
        assert "QUALIFY RANK() OVER" in sql and '"__topn_by" IS NOT NULL' in sql
        assert "__TOPN_TOKEN" not in sql


class TestTopNCard:
    def card_from_pbir(self, tmp_path, n=3, direction=2):
        rep = Report(tmp_path)
        topn_filter = {
            "Version": 2,
            "From": [
                {
                    "Name": "subquery",
                    "Expression": {
                        "Subquery": {
                            "Query": {
                                "Version": 2,
                                "From": [{"Name": "p", "Entity": "Product", "Type": 0}],
                                "Select": [{"Column": {"Expression": {"SourceRef": {"Source": "p"}}, "Property": "Category"}, "Name": "field"}],
                                "OrderBy": [{"Direction": direction, "Expression": measure("Sales", "Total Sales")}],
                                "Top": n,
                            }
                        }
                    },
                    "Type": 2,
                },
                {"Name": "p", "Entity": "Product", "Type": 0},
            ],
            "Where": [{"Condition": {"In": {"Expressions": [{"Column": {"Expression": {"SourceRef": {"Source": "p"}}, "Property": "Category"}}], "Table": {"SourceRef": {"Source": "subquery"}}}}}],
        }
        rep.patch_report(filterConfig={"filters": [{
            "name": "tn", "field": column("Product", "Category"), "type": "TopN", "filter": topn_filter,
        }]})  # fmt: skip
        bundle = rep.bundle()
        return bundle, filter_card(bundle.report.filters[0], bundle)

    def test_top_n_card_from_pbir(self, tmp_path):
        _, card = self.card_from_pbir(tmp_path)
        assert card.kind == "topn" and card.supported
        (cond,) = card.default.conditions
        assert cond.op == "topn"
        assert cond.params == {"n": 3, "direction": "top", "measure": "Total Sales"}

    def test_bottom_direction_and_bad_definitions(self, tmp_path):
        _, card = self.card_from_pbir(tmp_path, direction=1)
        assert card.default.conditions[0].params["direction"] == "bottom"
        _, bad = self.card_from_pbir(tmp_path / "x", n=0)
        assert bad.supported is False and bad.reason == "Top N definition not recognised"

    def test_by_value_measure_that_does_not_compile_is_refused(self, tmp_path):
        bundle, _ = self.card_from_pbir(tmp_path)
        bundle.model.find_measure("Total Sales")[1].expression = "FOOBAR(1)"
        from app.dax.compiler import MeasureCompiler

        card = filter_card(bundle.report.filters[0], bundle, MeasureCompiler(bundle.model))
        assert card.supported is False
        assert card.reason.startswith("Top N 'By value' measure [Total Sales] could not be translated")


def relative(world: DuckWorld, ui: dict, column_="d", *extra: FilterClause, time=False) -> set:
    lower, upper = relative_bounds(ui)
    clause = FilterClause(
        table="R", column=column_, op="relative", params={"lower": lower, "upper": upper, "time": time}
    )
    engine = world.engine()
    engine.today_sql = "DATE '2024-06-15'"
    engine.now_sql = "TIMESTAMP '2024-06-15 12:30:00'"
    spec = QuerySpec(
        dimensions=[DimensionRef(table="R", column="id")],
        measures=[MeasureRefSpec(name="N")],
        filters=[clause, *extra],
    )
    from app.runtime.accelerate import to_duckdb_sql

    sql, _ = engine.build_sql(spec)
    return {r[0] for r in world.con.execute(to_duckdb_sql(sql, world.bindings)).fetchall()}


def day(n: int) -> dt.date:
    return TODAY + dt.timedelta(days=n)


@pytest.fixture()
def dates_world() -> DuckWorld:
    rows = [(i, day(delta)) for i, delta in enumerate(
        [-400, -45, -20, -7, -6, -1, 0, 1, 6, 7, 20, 45, 400], start=1)]  # fmt: skip
    return DuckWorld({"R": (["id", "d"], rows)}, measures={"N": "COUNTROWS(R)"})


def ids_of(*deltas: int) -> set[int]:
    all_deltas = [-400, -45, -20, -7, -6, -1, 0, 1, 6, 7, 20, 45, 400]
    return {i for i, d in enumerate(all_deltas, start=1) if d in deltas}


class TestRelativeDates:
    def test_last_7_days_including_today(self, dates_world):
        ui = {"direction": "last", "n": 7, "unit": "day", "calendar": False, "include_today": True}
        assert relative(dates_world, ui) == ids_of(-6, -1, 0)

    def test_last_7_days_excluding_today(self, dates_world):
        ui = {"direction": "last", "n": 7, "unit": "day", "calendar": False, "include_today": False}
        assert relative(dates_world, ui) == ids_of(-7, -6, -1)

    def test_next_7_days(self, dates_world):
        inc = {"direction": "next", "n": 7, "unit": "day", "calendar": False, "include_today": True}
        exc = {**inc, "include_today": False}
        assert relative(dates_world, inc) == ids_of(0, 1, 6)
        assert relative(dates_world, exc) == ids_of(1, 6, 7)

    def test_this_month(self, dates_world):
        ui = {"direction": "this", "n": 1, "unit": "month", "calendar": True, "include_today": True}
        # 2024-06-01 .. 2024-06-30
        assert relative(dates_world, ui) == ids_of(-7, -6, -1, 0, 1, 6, 7)

    def test_last_2_calendar_months(self, dates_world):
        ui = {"direction": "last", "n": 2, "unit": "month", "calendar": True, "include_today": False}
        # April 1 .. May 31
        assert relative(dates_world, ui) == ids_of(-45, -20)

    def test_this_year_and_last_year(self, dates_world):
        this = {"direction": "this", "n": 1, "unit": "year", "calendar": True, "include_today": True}
        last = {"direction": "last", "n": 1, "unit": "year", "calendar": True, "include_today": False}
        assert relative(dates_world, this) == ids_of(-45, -20, -7, -6, -1, 0, 1, 6, 7, 20, 45)
        assert relative(dates_world, last) == ids_of(-400)

    def test_next_calendar_year(self, dates_world):
        ui = {"direction": "next", "n": 1, "unit": "year", "calendar": True, "include_today": False}
        assert relative(dates_world, ui) == ids_of(400)

    def test_relative_filter_on_a_fact_measure(self):
        world = DuckWorld(
            {"F": (["id", "d", "v"], [(1, day(-1), 10), (2, day(-1), 5), (3, day(-30), 100)])},
            measures={"N": "SUM(F[v])"},
        )
        lower, upper = relative_bounds(
            {"direction": "last", "n": 7, "unit": "day", "calendar": False, "include_today": True}
        )
        engine = world.engine()
        engine.today_sql = "DATE '2024-06-15'"
        clause = FilterClause(table="F", column="d", op="relative", params={"lower": lower, "upper": upper})
        sql, _ = engine.build_sql(QuerySpec(measures=[MeasureRefSpec(name="N")], filters=[clause]))
        from app.runtime.accelerate import to_duckdb_sql

        assert world.con.execute(to_duckdb_sql(sql, world.bindings)).fetchall() == [(15,)]

    def test_last_hours_uses_now(self):
        ts = dt.datetime(2024, 6, 15, 12, 30)
        rows = [(1, ts - dt.timedelta(hours=5)), (2, ts - dt.timedelta(hours=2)), (3, ts - dt.timedelta(minutes=10)), (4, ts + dt.timedelta(hours=1))]
        world = DuckWorld({"R": (["id", "d"], rows)}, measures={"N": "COUNTROWS(R)"})
        ui = {"direction": "last", "n": 3, "unit": "hour", "calendar": False, "include_today": False}
        assert relative(world, ui, time=True) == {2, 3}


class TestRelativeBoundsShapes:
    NOW = {"Now": {}}

    def test_this_is_span_of_span(self):
        lower, upper = relative_bounds({"direction": "this", "unit": "month", "n": 1})
        assert lower == upper == {"DateSpan": {"Expression": self.NOW, "TimeUnit": 2}}

    def test_minutes_and_hours(self):
        lower, upper = relative_bounds({"direction": "last", "n": 90, "unit": "minute"})
        assert lower == {"DateAdd": {"Expression": self.NOW, "Amount": -90, "TimeUnit": 6}}
        assert upper == self.NOW
        lower, upper = relative_bounds({"direction": "next", "n": 4, "unit": "hour"})
        assert lower == self.NOW
        assert upper == {"DateAdd": {"Expression": self.NOW, "Amount": 4, "TimeUnit": 7}}

    def test_calendar_windows(self):
        lower, upper = relative_bounds({"direction": "last", "n": 2, "unit": "month", "calendar": True})
        assert lower["DateSpan"]["Expression"]["DateAdd"]["Amount"] == -2
        assert upper["DateSpan"]["Expression"]["DateAdd"]["Amount"] == -1
        lower, upper = relative_bounds({"direction": "next", "n": 3, "unit": "week", "calendar": True})
        assert lower["DateSpan"]["Expression"]["DateAdd"]["Amount"] == 1
        assert upper["DateSpan"]["Expression"]["DateAdd"]["Amount"] == 3
        assert lower["DateSpan"]["TimeUnit"] == 1  # week

    def test_day_based_windows(self):
        lower, upper = relative_bounds({"direction": "last", "n": 3, "unit": "month", "calendar": False, "include_today": True})
        assert upper == {"DateSpan": {"Expression": self.NOW, "TimeUnit": 0}}
        inner = lower["DateSpan"]["Expression"]["DateAdd"]
        assert inner["Amount"] == -3 and inner["TimeUnit"] == 2
        assert inner["Expression"]["DateAdd"]["Amount"] == 1 and inner["Expression"]["DateAdd"]["TimeUnit"] == 0


class TestRelativeCards:
    def card(self, ui, filter_type="RelativeDate"):
        lower, upper = relative_bounds(ui)
        f = Filter(
            name="rel", scope=FilterScope.PAGE, field_table="Date", field_name="DateKey",
            filter_type=filter_type,
            definition={"Where": [{"Condition": {"Between": {"LowerBound": lower, "UpperBound": upper}}}]},
        )  # fmt: skip
        return f

    def bundle(self, tmp_path):
        return Report(tmp_path).bundle()

    def test_card_recognises_its_settings(self, tmp_path):
        ui = {"direction": "last", "n": 2, "unit": "month", "calendar": True, "include_today": False}
        card = filter_card(self.card(ui), self.bundle(tmp_path))
        assert card.kind == "relative" and card.supported
        params = card.default.conditions[0].params
        assert params["ui"] == ui and params["time"] is False

    def test_every_combination_round_trips(self):
        for direction in ("last", "next", "this"):
            for unit in ("day", "week", "month", "year", "minute", "hour"):
                for calendar in (False, True):
                    ui = {"direction": direction, "n": 3, "unit": unit, "calendar": calendar, "include_today": False}
                    lower, upper = relative_bounds(ui)
                    found = _recognise_relative({"lower": lower, "upper": upper})
                    assert found is not None
                    assert relative_bounds(found) == (lower, upper)

    def test_unrecognised_bounds_still_apply(self, tmp_path):
        f = self.card({"direction": "last", "n": 2, "unit": "month", "calendar": True})
        f.definition["Where"][0]["Condition"]["Between"]["UpperBound"] = {"DateAdd": {"Expression": {"Now": {}}, "Amount": 11, "TimeUnit": 2}}
        card = filter_card(f, self.bundle(tmp_path))
        assert card.supported and "ui" not in card.default.conditions[0].params

    def test_relative_time_card(self, tmp_path):
        ui = {"direction": "last", "n": 5, "unit": "hour", "calendar": False, "include_today": False}
        card = filter_card(self.card(ui, "RelativeTime"), self.bundle(tmp_path))
        assert card.default.conditions[0].params["time"] is True
        assert card.default.conditions[0].params["ui"]["unit"] == "hour"

    def test_unreadable_bounds_are_refused(self, tmp_path):
        f = self.card({"direction": "last", "n": 2, "unit": "month", "calendar": True})
        bundle = self.bundle(tmp_path)
        f.definition["Where"][0]["Condition"]["Between"]["LowerBound"] = {"Weird": {}}
        card = filter_card(f, bundle)
        assert card.supported is False and "invalid relative date bound" in card.reason
        f.definition["Where"][0]["Condition"] = {"In": {}}
        assert filter_card(f, bundle).reason == "filter condition shape not supported"


def test_recheck_includes_the_default_page_filters(tmp_path):
    """The validated spec carries the report/page defaults on every query."""
    rep = Report(tmp_path)
    in_us = {"Version": 2, "Where": [{"Condition": {"In": {"Expressions": [column("Customer", "Country")],
                                                           "Values": [[{"Literal": {"Value": "'US'"}}]]}}}]}  # fmt: skip
    rep.patch_page(filterConfig={"filters": [{"name": "pf", "field": column("Customer", "Country"), "type": "Categorical", "filter": in_us}]})
    _, spec = rep.compile()
    from app.validation.harness import with_default_filters

    out = with_default_filters(spec)
    queries = [v.query for p in out.pages for v in p.visuals if v.query is not None]
    assert queries and all(any(f.column == "Country" and f.values == ["US"] for f in q.filters) for q in queries)
    assert all(f.source == "page_filter" for q in queries for f in q.filters if f.column == "Country")
