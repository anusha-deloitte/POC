import { rowPoint, useReportPoint } from '../dataPoint'
import { rowPathKey, useMatrixDrill } from '../drill'
import { formatValue } from '../format'
import { fontCss } from '../pbi/fonts'
import { fieldColumnKey, resolveVisual, usePbiTheme, type ResolvedStyle } from '../pbi/resolve'
import type { FilterClause, VisualResult, VisualSpec } from '../types'

export interface PbiColumn {
  /** result column key */
  key: string
  header: string
  widthPx?: number
  align: 'left' | 'center' | 'right'
  isMeasure: boolean
}

const alignOf = (value: string | undefined, isMeasure: boolean): PbiColumn['align'] => {
  const v = (value ?? '').toLowerCase()
  if (v === 'right' || v === 'center' || v === 'left') return v
  return isMeasure ? 'right' : 'left'
}

/** Table columns in PBIR projection order with display names, explicit widths and alignment;
 * columns the projections do not name keep their query order after them. */
export function pbiTableColumns(spec: VisualSpec, columns: string[], style: ResolvedStyle): PbiColumn[] {
  const out: PbiColumn[] = []
  const used = new Set<string>()
  for (const f of spec.pbir?.fields ?? []) {
    const key = fieldColumnKey(f, columns, used)
    if (key === undefined) continue
    const ref = f.query_ref ?? ''
    const isMeasure = f.is_measure || !!f.aggregate
    out.push({
      key,
      header: f.display_name ?? f.name ?? key,
      widthPx: style.table.columnWidths[ref] ?? style.table.defaultColumnWidth,
      align: alignOf(style.table.alignments[ref], isMeasure),
      isMeasure,
    })
  }
  for (const key of columns) {
    if (used.has(key)) continue
    const isMeasure = spec.measure_keys.includes(key)
    out.push({
      key,
      header: key.includes('.') ? key.split('.').pop()! : key,
      widthPx: style.table.defaultColumnWidth,
      align: alignOf(undefined, isMeasure),
      isMeasure,
    })
  }
  return out
}

/** Matrix with the measures on rows: every result row becomes one row per measure. */
export function valuesOnRowRows(
  spec: VisualSpec,
  data: VisualResult,
): { columns: string[]; rows: (string | number | null)[][] } {
  const dimIdx = spec.dim_keys.map((k) => data.columns.indexOf(k)).filter((i) => i >= 0)
  const columns = [...spec.dim_keys, 'Values', 'Value']
  const rows: (string | number | null)[][] = []
  for (const r of data.rows) {
    for (const mk of spec.measure_keys) {
      const mi = data.columns.indexOf(mk)
      if (mi < 0) continue
      rows.push([...dimIdx.map((i) => r[i]), mk, r[mi]])
    }
  }
  return { columns, rows }
}

type Cell = string | number | null

export function PbiTable({
  spec,
  data,
  onSelect,
}: {
  spec: VisualSpec
  data: VisualResult
  onSelect?: (values: (string | number)[]) => void
}) {
  const style = resolveVisual(spec, usePbiTheme())
  const drill = useMatrixDrill()
  const report = useReportPoint()
  const t = style.table
  const onRows = t.valuesOnRow && spec.measure_keys.length > 0
  const source = onRows ? valuesOnRowRows(spec, data) : { columns: data.columns, rows: data.rows }
  const cols: PbiColumn[] = onRows
    ? source.columns.map((key, i) => ({
        key,
        header: i < spec.dim_keys.length ? (key.split('.').pop() ?? key) : key === 'Values' ? '' : 'Value',
        align: i < spec.dim_keys.length + 1 ? 'left' : 'right',
        isMeasure: i === source.columns.length - 1,
      }))
    : pbiTableColumns(spec, source.columns, style)
  const index = new Map(source.columns.map((c, i) => [c, i]))
  const totals = data.totals
  const border = (h: { show: boolean; color: string; weight: number }) =>
    h.show ? `${h.weight}px solid ${h.color}` : 'none'
  const expandable = !!spec.hierarchy?.expand_rows && t.showExpandCollapse && !!drill
  const firstDim = cols.findIndex((c) => !c.isMeasure)
  const fixedWidth = cols.length > 0 && cols.every((c) => c.widthPx !== undefined)
  const cellStyle: React.CSSProperties = {
    padding: `${t.rowPaddingPx}px 6px`,
    borderBottom: border(t.gridHorizontal),
    borderRight: border(t.gridVertical),
    wordBreak: 'break-word',
    whiteSpace: cols.some((c) => c.widthPx !== undefined) ? 'normal' : 'nowrap',
  }

  const renderRow = (
    row: Cell[],
    key: string,
    i: number,
    rowCols: PbiColumn[],
    depth: number,
    cmap: Map<string, number>,
    path: Cell[],
  ) => (
    <tr
      key={key}
      data-testid="table-row"
      style={{ background: i % 2 === 1 ? t.backSecondary : t.backPrimary }}
      className={onSelect ? 'cursor-pointer' : undefined}
      onMouseEnter={() => report(rowPoint(spec, [...cmap.keys()], row))}
      onMouseLeave={() => report(null)}
      onClick={() => {
        if (onSelect && firstDim >= 0)
          onSelect([String(row[cmap.get(rowCols[firstDim].key) ?? 0] ?? '')])
      }}
    >
      {rowCols.map((c, j) => {
        const v = row[cmap.get(c.key) ?? -1] ?? null
        const isFirst = j === firstDim
        const rowKey = rowPathKey(path)
        return (
          <td
            key={c.key}
            style={{
              ...cellStyle,
              textAlign: c.align,
              ...fontCss(c.isMeasure ? t.valuesFont : t.rowHeaderFont),
              color: c.isMeasure ? t.valuesColor : t.rowHeaderColor,
              paddingLeft: isFirst ? 6 + depth * 14 : 6,
            }}
          >
            {isFirst && expandable && depth === 0 && (
              <button
                type="button"
                aria-label={drill!.isExpanded(rowKey) ? 'Collapse row' : 'Expand row'}
                className="mr-1 inline-block w-4 text-center font-mono"
                onClick={(e) => {
                  e.stopPropagation()
                  const [table, column] = c.key.split('.')
                  const filters: FilterClause[] = [
                    { table, column, values: [String(v ?? '')], source: 'drill' },
                  ]
                  drill!.toggle(rowKey, filters, spec.hierarchy?.current_level ?? null)
                }}
              >
                {drill!.isExpanded(rowKey) ? '−' : '+'}
              </button>
            )}
            {c.isMeasure ? formatValue(v, spec.measure_formats[c.key]) : String(v ?? '')}
          </td>
        )
      })}
    </tr>
  )

  return (
    <div className="h-full w-full overflow-auto" data-testid="pbi-table">
      <table
        className="border-collapse"
        style={{
          tableLayout: fixedWidth ? 'fixed' : 'auto',
          width: fixedWidth ? cols.reduce((n, c) => n + (c.widthPx ?? 0), 0) : undefined,
        }}
      >
        <thead>
          <tr>
            {cols.map((c) => (
              <th
                key={c.key}
                style={{
                  ...cellStyle,
                  ...fontCss(t.headerFont),
                  color: t.headerColor,
                  background: t.headerBackground ?? 'transparent',
                  textAlign: c.align,
                  width: c.widthPx,
                  position: 'sticky',
                  top: 0,
                }}
              >
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {source.rows.flatMap((row, i) => {
            const path: Cell[] = firstDim >= 0 ? [row[index.get(cols[firstDim].key) ?? 0]] : [i]
            const rowKey = rowPathKey(path)
            const parent = renderRow(row, `r${i}`, i, cols, 0, index, path)
            const child = drill?.isExpanded(rowKey) ? drill.children(rowKey) : undefined
            if (!child) return [parent]
            const cmap = new Map(child.columns.map((c, k) => [c, k]))
            const levels = spec.hierarchy?.levels ?? spec.dim_keys
            const nextDim = child.columns.find((c) => levels.includes(c) && c !== cols[firstDim]?.key)
            const childCols = cols.map((c, j) => (j === firstDim && nextDim ? { ...c, key: nextDim } : c))
            return [
              parent,
              ...child.rows.map((r, k) =>
                renderRow(r, `r${i}c${k}`, i + k + 1, childCols, 1, cmap, [...path, k]),
              ),
            ]
          })}
          {totals && t.totalsShow && (
            <tr data-testid="totals-row">
              {cols.map((c, j) => {
                const ti = totals.columns.indexOf(c.key)
                return (
                  <td
                    key={c.key}
                    style={{
                      ...cellStyle,
                      textAlign: c.align,
                      borderTop: `1px solid ${t.gridHorizontal.color}`,
                      ...fontCss(t.valuesFont),
                      fontWeight: 700,
                    }}
                  >
                    {j === 0
                      ? t.totalLabel
                      : ti >= 0
                        ? formatValue(totals.row[ti], spec.measure_formats[c.key])
                        : ''}
                  </td>
                )
              })}
            </tr>
          )}
        </tbody>
      </table>
    </div>
  )
}
