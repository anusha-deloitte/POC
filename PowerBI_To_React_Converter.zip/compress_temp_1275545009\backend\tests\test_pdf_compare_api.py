"""PDF reference upload (ordinal + content matching), number checks and per-page history."""

from __future__ import annotations

import pytest

from app.agents.visual_compare import CompareResult
from tests.pdf_helpers import make_pdf
from tests.phase08 import CARD, PAGE, World
from tests.test_api import client  # noqa: F401

PNG = b"\x89PNG\r\n\x1a\n" + b"0" * 32


@pytest.fixture()
def world(client, contoso_pbip, monkeypatch):  # noqa: F811
    return World(client, contoso_pbip, monkeypatch)


def sales_pdf(value="$1.5M") -> bytes:
    runs = [
        ("Sales Overview", 24, 2, 14),
        ("Total Sales", 30, 30, 12),
        (value, 60, 70, 24),
        ("Sales by Category", 40, 180, 12),
        ("Sales Trend vs Last Year", 660, 180, 12),
    ]
    return make_pdf([{"width": 1280, "height": 720, "runs": runs}])


def upload(world, pdf: bytes, **params):
    return world.client.post(
        world.url("visual-compare/reference-pdf"),
        params=params,
        files={"pdf": ("report.pdf", pdf, "application/pdf")},
    )


def card_result(value=1_500_000.0):
    return {
        "results": [{"visual": CARD, "columns": ["Total Sales"], "rows": [[value]], "totals": None}]
    }


def test_ordinal_upload_still_works_and_keeps_the_text_for_number_checks(world):
    r = upload(world, sales_pdf())
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["mode"] == "ordinal" and body["pdf_pages"] == 1
    assert body["references_stored"] == [{"page": PAGE, "display_name": "Sales Overview"}]
    assert {"report_pages", "superseded_comparisons", "warnings"} <= set(body)
    refs = world.get("visual-compare/references").json()["pages"]
    assert next(p for p in refs if p["page"] == PAGE)["has_reference"] is True
    assert (world.root / "visual_compare" / f"{PAGE}_reference_text.json").is_file()


def test_content_matching_stores_only_confident_enough_pages(world):
    r = upload(world, sales_pdf(), match="true")
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["mode"] == "content"
    assert body["matches"][0]["page"] == PAGE and body["matches"][0]["confident"] is True
    assert [p["page"] for p in body["references_stored"]] == [PAGE]

    other = make_pdf(
        [{"width": 1280, "height": 720, "runs": [("zzz qqq nothing relevant", 20, 20, 14)]}]
    )
    world.root.joinpath("visual_compare", f"{PAGE}_reference.png").unlink()
    r2 = upload(world, other, match="true").json()
    assert r2["references_stored"] == [] and r2["matches"][0]["page"] is None
    assert any("did not match" in w for w in r2["warnings"])
    assert not world.root.joinpath("visual_compare", f"{PAGE}_reference.png").exists()


def test_upload_errors(world):
    assert upload(world, b"").status_code == 422
    assert upload(world, b"not a pdf").status_code == 422
    assert upload(world, b"not a pdf", match="true").status_code == 422


def test_number_check_matches_mismatches_and_is_listed(world):
    upload(world, sales_pdf("$1.5M"))
    ok = world.post(f"visual-compare/{PAGE}/values", card_result())
    assert ok.status_code == 200, ok.text
    body = ok.json()
    card = next(v for v in body["visuals"] if v["visual"] == CARD)
    assert card["status"] == "match" and body["summary"]["numbers_matched"] >= 1
    assert body["run_id"] and (world.root / "visual_compare" / f"{PAGE}_values.json").is_file()

    bad = world.post(f"visual-compare/{PAGE}/values", card_result(9_000_000.0)).json()
    assert next(v for v in bad["visuals"] if v["visual"] == CARD)["status"] == "mismatch"

    listed = world.get("visual-compare").json()["pages"]
    assert len(listed) == 1 and listed[0]["similarity"] is None
    assert listed[0]["values"]["summary"]["mismatch"] == 1  # the latest run


def test_number_check_needs_pdf_text(world):
    assert world.post(f"visual-compare/{PAGE}/values", card_result()).status_code == 422
    upload(world, sales_pdf())
    world.root.joinpath("visual_compare", f"{PAGE}_reference_text.json").unlink()
    r = world.post(f"visual-compare/{PAGE}/values", card_result())
    assert r.status_code == 422 and "no PDF text" in r.text
    assert world.post("visual-compare/nope/values", card_result()).status_code == 404
    bad_batch = world.post(f"visual-compare/{PAGE}/values", {**card_result(), "batch_id": "../x"})
    assert bad_batch.status_code == 422


def test_a_new_reference_makes_the_number_check_stale(world):
    upload(world, sales_pdf("$1.5M"))
    world.post(f"visual-compare/{PAGE}/values", card_result())
    upload(world, sales_pdf("$7.0M"))
    page = world.get("visual-compare").json()["pages"][0]
    assert page["values"]["stale"] is True


def test_history_keeps_every_run_and_serves_images(world, monkeypatch):
    upload(world, sales_pdf())
    findings = [{"region": "x", "severity": "low", "kind": "style", "difference": "d", "fix": None}]
    monkeypatch.setattr(
        "app.agents.visual_compare.compare_page_images",
        lambda ref, ren, inv, filter_context=None: CompareResult(
            similarity=80, findings=list(findings)
        ),
    )
    batch = "a" * 32
    for i in range(2):
        r = world.client.post(
            world.url(f"visual-compare/{PAGE}"),
            files={"rendered": ("r.png", PNG + bytes([i]), "image/png")},
            data={"batch_id": batch},
        )
        assert r.status_code == 200, r.text
        assert r.json()["run_id"]
    world.post(f"visual-compare/{PAGE}/values", card_result())

    hist = world.get(f"visual-compare/{PAGE}/history").json()
    assert [r["kind"] for r in hist["runs"]] == ["values", "image", "image"]
    assert hist["trend"][0]["kind"] == "image" and hist["trend"][0]["value"] == 80
    only_batch = world.get(f"visual-compare/{PAGE}/history", batch_id=batch).json()["runs"]
    assert [r["kind"] for r in only_batch] == ["image", "image"]

    first_image = hist["runs"][2]
    run = world.get(f"visual-compare/{PAGE}/history/{first_image['run_id']}").json()
    assert run["payload"]["similarity"] == 80 and run["batch_id"] == batch
    img = world.client.get(
        world.url(f"visual-compare/{PAGE}/history/{first_image['run_id']}/image/rendered")
    )
    assert img.status_code == 200 and img.content == PNG + bytes([0])
    # a later run did not overwrite the earlier snapshot
    second = hist["runs"][1]["run_id"]
    img2 = world.client.get(world.url(f"visual-compare/{PAGE}/history/{second}/image/rendered"))
    assert img2.content == PNG + bytes([1])


def test_history_routes_are_path_safe(world):
    assert world.get(f"visual-compare/{PAGE}/history/not-a-run-id").status_code == 422
    ok_id = "20260101T000000000-abcd"
    assert world.get(f"visual-compare/{PAGE}/history/{ok_id}").status_code == 404
    assert world.get(f"visual-compare/{PAGE}/history/{ok_id}/image/sideways").status_code == 422
    assert world.get(f"visual-compare/{PAGE}/history/{ok_id}/image/reference").status_code == 404
    assert world.get("visual-compare/bad%5Cname/history").status_code == 422
    assert world.get(f"visual-compare/{PAGE}/history").json() == {
        "page": PAGE,
        "runs": [],
        "trend": [],
    }
