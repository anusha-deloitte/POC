import { formatValue } from '../format'
import { firstEntry, usePbiTheme } from '../pbi/resolve'
import { color, litNumber, litString } from '../pbi/literal'
import { fontCss, font } from '../pbi/fonts'
import type { VisualResult, VisualSpec } from '../types'

const DASH = '—'

type Dict = Record<string, unknown>
const props = (spec: VisualSpec, name: string): Dict => {
  const e = firstEntry(spec.pbir?.objects, name)
  return e && typeof e.properties === 'object' && e.properties ? (e.properties as Dict) : {}
}

const decimalsOf = (n: number) => (n > 0 ? '.' + '0'.repeat(Math.min(n, 6)) : '')

/** The number format of the KPI's actual value. With explicit decimal places every decimal
 * placeholder is rewritten to that many required zeros; without them Power BI's "auto" decimals
 * (optional `.###…` runs) are dropped so no arbitrary precision shows, while required decimals
 * ("#,0.00") are kept. Quoted literals and backslash escapes are never touched. */
export function kpiActualFormat(fmt: string | undefined, placesRaw?: number | string | null): string | undefined {
  const places = placesRaw === undefined || placesRaw === null ? null : Number(placesRaw)
  const set = places !== null && Number.isFinite(places)
  if (!fmt) return set ? '#,0' + decimalsOf(places as number) : fmt
  return fmt
    .split(/("[^"]*"|\\.)/)
    .map((part, i) => {
      if (i % 2 === 1) return part
      return set
        ? part.replace(/\.[0#]+/g, decimalsOf(places as number))
        : part.replace(/\.#+(?![0#])/g, '')
    })
    .join('')
}

/** The AppSource KPI card: name, actual value and a "<prefix> x.x% ▲/▼" comparison with the
 * target. Without data the name renders and values show an em dash. */
export function KpiCardVisual({ spec, data }: { spec: VisualSpec; data?: VisualResult }) {
  const theme = usePbiTheme()
  const [actualKey, targetKey] = spec.measure_keys
  const value = (key?: string) => {
    if (!key || !data) return null
    const i = data.columns.indexOf(key)
    const raw = i >= 0 ? data.rows[0]?.[i] : null
    return raw === null || raw === undefined || raw === '' ? null : Number(raw)
  }
  const actual = value(actualKey)
  const target = value(targetKey)
  const name = litString(props(spec, 'kpiName').text) ?? spec.title ?? actualKey ?? ''
  const prefix = litString(props(spec, 'target1').prefix) ?? litString(props(spec, 'target1').text) ?? ''
  const decimals = litNumber(props(spec, 'target1').decimalPlaces) ?? litNumber(props(spec, 'target1').target1DecimalPlaces)
  const actualProps = props(spec, 'actual')
  const fmt = kpiActualFormat(
    spec.measure_formats[actualKey ?? ''] || undefined,
    litNumber(actualProps.actualDecimalPlaces) ?? litNumber(actualProps.decimalPlaces),
  )
  const hasComparison = actual !== null && target !== null && target !== 0
  const ratio = hasComparison ? (actual! - target!) / Math.abs(target!) : null
  const percentFmt = decimals !== undefined
    ? `0.${'0'.repeat(decimals)}%`.replace('0.%', '0%')
    : '0.0%'
  const comparison =
    ratio === null ? DASH : `${prefix ? prefix + ' ' : ''}${formatValue(Math.abs(ratio), percentFmt)}`
  const up = ratio !== null && ratio >= 0
  const valueColor = color(props(spec, 'actual').fontColor, theme.tokens) ?? theme.tokens.foreground
  return (
    <div data-testid="kpi-card" className="flex h-full w-full flex-col items-center justify-center overflow-hidden px-2 text-center">
      <span data-testid="kpi-name" className="truncate" style={{ ...fontCss(font(undefined, undefined, 12)), color: theme.tokens.secondaryForeground }}>
        {name}
      </span>
      <span
        data-testid="kpi-actual"
        className="truncate"
        style={{ ...fontCss(font(undefined, undefined, 27, 600)), color: valueColor }}
      >
        {actual === null ? DASH : formatValue(actual, fmt || undefined)}
      </span>
      <span data-testid="kpi-comparison" className="truncate" style={{ ...fontCss(font(undefined, undefined, 12)), color: theme.tokens.secondaryForeground }}>
        {comparison}
        {ratio !== null && (
          <span aria-label={up ? 'above target' : 'below target'} style={{ marginLeft: 4, fontSize: '0.8em' }}>
            {up ? '▲' : '▼'}
          </span>
        )}
      </span>
    </div>
  )
}
