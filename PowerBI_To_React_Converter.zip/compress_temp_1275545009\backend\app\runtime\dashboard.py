"""Compile a ReportBundle into a renderable DashboardSpec.

The spec is the contract between backend and the spec-driven React renderer:
layout + visual configs + per-visual QuerySpecs. Visual types outside the
registry render as an "unsupported" badge with their type name.
"""

from __future__ import annotations

import re

from pydantic import BaseModel, Field

from app.binding.resolver import BindingMap, build_bundle_binding_map
from app.dax.compiler import DaxUnsupported, MeasureCompiler
from app.ir.report import (
    Bookmark,
    DrillThroughTarget,
    FilterPane,
    InteractionGraph,
    Page,
    ReportBundle,
    SyncGroup,
    Visual,
)
from app.runtime import pbir_passthrough as pt
from app.runtime.filter_cards import (  # noqa: F401 - re-exported
    ENGINE_FILTER_OPS,
    FilterCard,
    FilterCondition,
    FilterDefault,
    bookmark_filter_values,
    card_clauses,
    default_filter_clauses,
    filter_card,
    filter_values_query,
    ordered_cards,
    relative_bounds,
    with_default_filters,
)

filters_passthrough = pt.filters_passthrough
from app.runtime.engine import (
    DimensionRef,
    FilterClause,
    MeasureFilter,
    MeasureRefSpec,
    QuerySpec,
)
from app.semantic.yaml_compiler import semantic_metric_plan

SUPPORTED_VISUALS = {
    "card",
    "slicer",
    "donutChart",
    "pieChart",
    "clusteredColumnChart",
    "clusteredBarChart",
    "barChart",
    "columnChart",
    "lineChart",
    "areaChart",
    "waterfallChart",
    "pivotTable",
    "tableEx",
    "textbox",
    "scatterChart",
    "lineClusteredColumnComboChart",
    "gauge",
    "filledMap",
    "hundredPercentStackedBarChart",
    "hundredPercentStackedColumnChart",
    "kpiCard",
    # rendered as drillable treemap (nearest equivalent, same contribution story)
    "decompositionTreeVisual",
}

# roles that carry grouping fields per visual family
_DIM_ROLES = {"Category", "Rows", "Axis", "Legend", "Columns", "Explain By", "Details", "Series"}
_MEASURE_ROLES = {
    "Y",
    "Values",
    "Y2",
    "Tooltips",
    "X",
    "Size",
    "Analyzed",
    "TargetValue",
    "MinValue",
    "MaxValue",
}

# PBIR writes the same logical role under several spellings depending on the
# visual and the Desktop version that authored it (e.g. "ExplainBy" vs "Explain By").
_ROLE_ALIASES = {
    "explainby": "Explain By",
    "analyze": "Analyzed",
    "actual": "Values",
    "group": "Category",
    "groups": "Category",
    "axis": "Axis",
    "y2axis": "Y2",
    "secondaryy": "Y2",
    "tooltip": "Tooltips",
    "details": "Details",
    "value": "Values",
    "target": "TargetValue",
    "minimum": "MinValue",
    "maximum": "MaxValue",
}


def _canonical_role(role: str) -> str:
    """Map a PBIR projection role onto the compiler's canonical role vocabulary."""
    if role in _DIM_ROLES or role in _MEASURE_ROLES:
        return role
    return _ROLE_ALIASES.get(role.replace(" ", "").replace("_", "").lower(), role)


class DrillthroughFieldSpec(BaseModel):
    """A field a drill-through page receives: a column (`table`, `column`) or a measure."""

    table: str | None = None
    column: str | None = None
    measure: str | None = None

    @property
    def key(self) -> str:
        return self.measure if self.measure else f"{self.table}.{self.column}"


class VisualSpec(BaseModel):
    name: str
    visual_type: str
    x: float
    y: float
    width: float
    height: float
    z: float = 0
    title: str | None = None
    supported: bool = True
    unsupported_reason: str | None = None
    # ok | untranslated (a measure needs tier-2) | unsupported_type;
    # the renderer draws chrome either way
    data_status: str = "ok"
    # hand-edited SQL of an untranslated pane and the query that would have run (phase 08)
    manual_sql: str | None = None
    draft_query: QuerySpec | None = None
    # set when the PBI visual has no exact match and a nearest equivalent is used
    substituted_as: str | None = None
    # renderer inputs
    query: QuerySpec | None = None
    dim_keys: list[str] = Field(default_factory=list)
    # dims that came from the PBI "Columns" role (matrix pivot axis)
    column_keys: list[str] = Field(default_factory=list)
    # dims that came from the PBI "Series"/"Legend" role (chart series split)
    series_keys: list[str] = Field(default_factory=list)
    # projections defined in the PBI visual that the compiler did NOT consume
    dropped_fields: list[str] = Field(default_factory=list)
    measure_keys: list[str] = Field(default_factory=list)
    measure_roles: dict[str, str] = Field(default_factory=dict)  # measure key -> role
    measure_formats: dict[str, str] = Field(default_factory=dict)
    slicer_target: dict | None = None  # {table, column}
    static_content: dict = Field(default_factory=dict)  # textbox paragraphs etc.
    sort: list[dict] = Field(default_factory=list)
    # renderer options set by remediations (waterfall_total, show_legend, ...)
    options: dict = Field(default_factory=dict)
    # hierarchy drill metadata for visuals using hierarchy levels
    # ({name, levels, current_level, drill_enabled, expand_rows})
    hierarchy: dict | None = None
    # measure key -> "percent_of_grand_total" (PBI "Show value as")
    measure_show_as: dict[str, str] = Field(default_factory=dict)
    # a slicer's saved selection (empty = All)
    default_selection: list = Field(default_factory=list)
    # raw PBIR passthrough for the renderer: {objects, container_objects, fields, sort,
    # is_hidden, self_hidden, parent_group}; None for visuals that do not come from PBIR
    pbir: dict | None = None
    # {type, bookmark, page, url, tooltip}
    action: dict | None = None
    # measure-only query behind a measure-driven title / button text (`<visual>#title`)
    title_query: QuerySpec | None = None
    # slicers sharing a selection across pages
    sync_group: SyncGroup | None = None
    # the exported Tooltip page shown on hover (None = Power BI's default field tooltip)
    tooltip_page: str | None = None


class PageSpec(BaseModel):
    name: str
    display_name: str
    width: float
    height: float
    ordinal: int
    # raw `objects.background` entry; `is_hidden` pages are not tabs but stay navigable
    background: dict = Field(default_factory=dict)
    is_hidden: bool = False
    display_option: str = "FitToPage"
    # "Filters on this page" cards and the pane settings
    filters: list[FilterCard] = Field(default_factory=list)
    filter_pane: FilterPane | None = None
    page_type: str | None = None
    drillthrough: list[DrillthroughFieldSpec] = Field(default_factory=list)
    visuals: list[VisualSpec] = Field(default_factory=list)


class ThemeSpec(BaseModel):
    data_colors: list[str] = Field(default_factory=list)
    background: str | None = None
    foreground: str | None = None
    table_accent: str | None = None
    good: str | None = None
    bad: str | None = None
    neutral: str | None = None
    font_family: str | None = None
    card_background: str | None = None
    panel_background: str | None = None
    panel_border: str | None = None
    tooltip_background: str | None = None
    tooltip_text: str | None = None
    text_classes: dict[str, dict] = Field(default_factory=dict)


class DashboardSpec(BaseModel):
    report_name: str
    pages: list[PageSpec] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    # measure name -> tier (0/1/2) or -1 for parked
    measure_tiers: dict[str, int] = Field(default_factory=dict)
    theme: ThemeSpec = Field(default_factory=ThemeSpec)
    interaction_graph: InteractionGraph = Field(default_factory=InteractionGraph)
    bookmarks: list[Bookmark] = Field(default_factory=list)
    drill_through: list[DrillThroughTarget] = Field(default_factory=list)
    # detected Power BI What-If parameters from calculated tables
    what_if_parameters: list[dict] = Field(default_factory=list)
    # {base_name, base, custom}: the report's base theme and custom theme JSON
    pbi_theme: dict = Field(default_factory=dict)
    vertical_alignment: str = "Top"
    # "Filters on all pages" cards, the pane and whether users may switch card types
    report_filters: list[FilterCard] = Field(default_factory=list)
    filter_pane: FilterPane | None = None
    allow_change_filter_types: bool = True


_GENERATESERIES_RE = re.compile(
    r"GENERATESERIES\s*\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\)",
    re.IGNORECASE,
)


def _detect_what_if_parameters(bundle: ReportBundle) -> list[dict]:
    """Detect basic What-If parameter tables from calculated table expressions.

    Pattern: calculated table partition with GENERATESERIES(min, max, step).
    """
    out: list[dict] = []
    for t in bundle.model.tables:
        if not t.partitions:
            continue
        part = t.partitions[0]
        if part.source_type != "calculated" or not part.expression:
            continue
        m = _GENERATESERIES_RE.search(part.expression)
        if not m:
            continue
        col_name = t.columns[0].name if t.columns else "Value"
        out.append(
            {
                "table": t.name,
                "column": col_name,
                "min": m.group(1).strip(),
                "max": m.group(2).strip(),
                "step": m.group(3).strip(),
            }
        )
    return out


def _find_what_if_for_measure(bundle: ReportBundle, measure_name: str) -> dict | None:
    """Link a measure to a detected What-If parameter via SELECTEDVALUE refs."""
    found = bundle.model.find_measure(measure_name)
    if not found:
        return None
    _, m = found
    expr = m.expression or ""
    params = _detect_what_if_parameters(bundle)
    for p in params:
        pattern = rf"SELECTEDVALUE\s*\(\s*'?{re.escape(p['table'])}'?\s*\[\s*{re.escape(p['column'])}\s*\]"
        if re.search(pattern, expr, re.IGNORECASE):
            return p
    return None


def _reachable_tables(model: ReportBundle, start: str) -> set[str]:
    seen = {start}
    frontier = [start]
    while frontier:
        cur = frontier.pop()
        for rel in model.model.relationships:
            if getattr(rel, "is_active", True) is False:
                continue
            if rel.from_table == cur and rel.to_table not in seen:
                seen.add(rel.to_table)
                frontier.append(rel.to_table)
    return seen


def compile_theme(raw_theme: dict) -> ThemeSpec:
    custom = raw_theme.get("custom", {}) if isinstance(raw_theme, dict) else {}
    return ThemeSpec(
        data_colors=custom.get("dataColors", []),
        background=custom.get("background"),
        foreground=custom.get("foreground"),
        table_accent=custom.get("tableAccent"),
        good=custom.get("good"),
        bad=custom.get("bad"),
        neutral=custom.get("neutral"),
        font_family=custom.get("fontFamily"),
        card_background=custom.get("cardBackground"),
        panel_background=custom.get("panelBackground"),
        panel_border=custom.get("panelBorder"),
        tooltip_background=custom.get("tooltipBackground"),
        tooltip_text=custom.get("tooltipText"),
        text_classes=custom.get("textClasses", {}),
    )


def _format_for(bundle: ReportBundle, measure_name: str) -> str | None:
    found = bundle.model.find_measure(measure_name)
    return found[1].format_string if found else None


# PBI labelDisplayUnits values with a fixed scale (0 = Auto, 1 = None)
_DISPLAY_UNITS = {1000, 1000000, 1000000000, 1000000000000}


def _fmt_literal(objects: dict, section: str, prop: str):
    """Decode a PBIR formatting literal: 'true'/'false', 9D/0D numbers, 'Right' strings."""
    try:
        raw = objects[section][0]["properties"][prop]["expr"]["Literal"]["Value"]
    except (KeyError, IndexError, TypeError):
        return None
    if not isinstance(raw, str):
        return raw
    if raw in ("true", "false"):
        return raw == "true"
    if raw.startswith("'") and raw.endswith("'"):
        return raw[1:-1]
    if raw.endswith(("D", "L")):
        try:
            return float(raw[:-1])
        except ValueError:
            return None
    return raw


def _fmt_color(objects: dict, section: str, prop: str) -> str | None:
    """Decode a PBIR solid-color literal: objects.<section>[0].properties.<prop>.solid.color."""
    try:
        raw = objects[section][0]["properties"][prop]["solid"]["color"]["expr"]["Literal"]["Value"]
    except (KeyError, IndexError, TypeError):
        return None
    if isinstance(raw, str) and raw.startswith("'") and raw.endswith("'"):
        return raw[1:-1]
    return raw if isinstance(raw, str) else None


# visual families where PBI shows grand totals unless explicitly disabled
_TOTALS_DEFAULT_ON = {"pivotTable", "tableEx"}


def extract_declared_presentation(visual: Visual) -> dict:
    """Read every presentation property this engine understands from the raw
    PBIR payload. Single source of truth shared by the compiler, the
    validation harness, and the presentation repair agent — so a compile gap
    is always caught by validation instead of silently diverging."""
    fmt = visual.formatting or {}
    container = visual.container_objects or {}
    declared: dict = {}

    show_legend = _fmt_literal(fmt, "legend", "show")
    if isinstance(show_legend, bool):
        declared["show_legend"] = show_legend
    position = _fmt_literal(fmt, "legend", "position")
    if isinstance(position, str):
        declared["legend_position"] = position
    legend_font = _fmt_literal(fmt, "legend", "fontSize")
    if isinstance(legend_font, (int, float)):
        declared["legend_font_size"] = int(legend_font)

    show_labels = _fmt_literal(fmt, "labels", "show")
    if isinstance(show_labels, bool):
        declared["show_labels"] = show_labels
    units = _fmt_literal(fmt, "labels", "labelDisplayUnits")
    if isinstance(units, (int, float)) and (units == 0 or int(units) in _DISPLAY_UNITS):
        declared["display_units"] = int(units)
    precision = _fmt_literal(fmt, "labels", "labelPrecision")
    if isinstance(precision, (int, float)):
        declared["label_precision"] = int(precision)
    label_font = _fmt_literal(fmt, "labels", "fontSize")
    if isinstance(label_font, (int, float)):
        declared["label_font_size"] = int(label_font)
    label_color = _fmt_color(fmt, "labels", "color")
    if label_color:
        declared["label_color"] = label_color

    show_cat = _fmt_literal(fmt, "categoryLabels", "show")
    if isinstance(show_cat, bool):
        declared["show_category_labels"] = show_cat

    axis_units = _fmt_literal(fmt, "valueAxis", "labelDisplayUnits")
    if isinstance(axis_units, (int, float)) and (
        axis_units == 0 or int(axis_units) in _DISPLAY_UNITS
    ):
        declared["axis_display_units"] = int(axis_units)
    axis_precision = _fmt_literal(fmt, "valueAxis", "labelPrecision")
    if isinstance(axis_precision, (int, float)):
        declared["axis_precision"] = int(axis_precision)
    axis_title = _fmt_literal(fmt, "valueAxis", "titleText")
    if isinstance(axis_title, str) and _fmt_literal(fmt, "valueAxis", "showAxisTitle") is True:
        declared["axis_title"] = axis_title

    grid_vertical = _fmt_literal(fmt, "grid", "gridVertical")
    if isinstance(grid_vertical, bool):
        declared["grid_vertical"] = grid_vertical
    values_font = _fmt_literal(fmt, "values", "fontSize")
    if isinstance(values_font, (int, float)):
        declared["values_font_size"] = int(values_font)
    headers_bold = _fmt_literal(fmt, "columnHeaders", "bold")
    if isinstance(headers_bold, bool):
        declared["column_headers_bold"] = headers_bold

    if visual.visual_type in _TOTALS_DEFAULT_ON:
        # PBI shows grand totals unless the author explicitly turned them off
        totals_off = _fmt_literal(fmt, "subTotals", "rowSubtotals") is False or (
            _fmt_literal(fmt, "total", "show") is False
        )
        declared["show_totals"] = not totals_off

    bg_color = _fmt_color(container, "background", "color")
    if bg_color:
        transparency = _fmt_literal(container, "background", "transparency")
        declared["container_background"] = {
            "color": bg_color,
            "transparency": float(transparency) if isinstance(transparency, (int, float)) else 0.0,
        }
    border_show = _fmt_literal(container, "border", "show")
    if isinstance(border_show, bool):
        border: dict = {"show": border_show}
        border_color = _fmt_color(container, "border", "color")
        if border_color:
            border["color"] = border_color
        radius = _fmt_literal(container, "border", "radius")
        if isinstance(radius, (int, float)):
            border["radius"] = int(radius)
        declared["container_border"] = border

    return declared


def _default_sort(visual: Visual, dims: list, measures: list) -> list[dict]:
    """PBI applies a deterministic default sort when the author didn't set one:
    group columns ascending (respecting each column's sortByColumn, which the
    engine resolves downstream). Sorting every grouping column keeps row AND
    pivot-column order identical between the original and the conversion, and
    fixes the category→color assignment for charts (colors follow order)."""
    if dims:
        return [{"key": d.key, "direction": "Ascending"} for d in dims]
    return []


def _extract_presentation_options(visual: Visual, vs: VisualSpec) -> None:
    """Lift every declared presentation property from the PBIR payload into
    renderer options at compile time — parity on formatting is enforced up
    front instead of discovered later by the vision compare."""
    vs.options.update(extract_declared_presentation(visual))



# ---------------------------------------------------------------- phase 09 helpers

_KPI_SIGNATURE = {"kpiName", "actual", "target1"}
_COMPARISON = {0: "eq", 1: "gt", 2: "gte", 3: "lt", 4: "lte"}


def _is_kpi_card(visual: Visual) -> bool:
    """The AppSource KPI-card custom visual, recognised by its object signature."""
    return len(_KPI_SIGNATURE & set(visual.formatting or {})) >= 2


def _measure_name_of(node) -> str | None:
    """The measure a `{expr: {Measure: ...}}` property points to (measure-driven text)."""
    try:
        return node["expr"]["Measure"]["Property"]
    except (KeyError, TypeError):
        return None


def _title_measure(visual: Visual) -> str | None:
    """Measure behind a measure-driven title; buttons use their `text.text` the same way."""
    try:
        name = _measure_name_of(visual.container_objects["title"][0]["properties"]["text"])
    except (KeyError, IndexError, TypeError):
        name = None
    if name:
        return name
    if visual.visual_type == "actionButton":
        try:
            return _measure_name_of(visual.formatting["text"][0]["properties"]["text"])
        except (KeyError, IndexError, TypeError):
            return None
    return None


def _condition_clauses(
    cond: dict, table: str, column: str, is_measure: bool
) -> tuple[list[tuple[str, list]], str | None]:
    """[(op, values)] of one PBIR filter condition, or (.., reason) when it can't be expressed."""
    if "Not" in cond:
        inner, reason = _condition_clauses(
            cond["Not"].get("Expression", {}), table, column, is_measure
        )
        flip = {
            "in": "not_in", "eq": "neq", "neq": "eq",
            "gt": "lte", "gte": "lt", "lt": "gte", "lte": "gt",
        }  # fmt: skip
        if reason or any(op not in flip for op, _ in inner):
            return [], reason or "unsupported negation"
        return [(flip[op], values) for op, values in inner], None
    if "In" in cond:
        values = []
        for tup in cond["In"].get("Values", []) or []:
            for lit in tup:
                raw = (lit.get("Literal") or {}).get("Value")
                if raw is None:
                    return [], "non-literal values"
                values.append(pt._decode(raw))
        return [("in", values)], None
    if "Comparison" in cond:
        cmp = cond["Comparison"]
        op = _COMPARISON.get(cmp.get("ComparisonKind"))
        raw = ((cmp.get("Right") or {}).get("Literal") or {}).get("Value")
        if op is None or raw is None:
            return [], "unsupported comparison"
        return [(op, [pt._decode(raw)])], None
    if "And" in cond:
        out: list[tuple[str, list]] = []
        for side in ("Left", "Right"):
            part, reason = _condition_clauses(cond["And"].get(side, {}), table, column, is_measure)
            if reason:
                return [], reason
            out.extend(part)
        return out, None
    return [], "unsupported condition " + (next(iter(cond), "?"))


def visual_filters_to_query(
    visual: Visual,
) -> tuple[list[FilterClause], list[MeasureFilter], list[str]]:
    """"Filters on this visual" -> (column filters, measure-value filters, dropped descriptions).
    A TOPN visual filter is reported, never silently ignored."""
    columns: list[FilterClause] = []
    measures: list[MeasureFilter] = []
    dropped: list[str] = []
    for f in visual.filters:
        label = f"{f.field_table}.{f.field_name}" if f.field_table else (f.field_name or "?")
        if f.filter_type == "TopN":
            dropped.append(f"TOPN filter on {label} was not applied")
            continue
        if not f.field_name or (not f.field_table and not f.field_is_measure):
            dropped.append(f"filter on {label}: no field")
            continue
        wheres = (f.definition or {}).get("Where", []) or []
        if not wheres:
            continue  # an empty ("all") filter
        for where in wheres:
            clauses, reason = _condition_clauses(
                where.get("Condition", {}) or {},
                f.field_table or "",
                f.field_name,
                f.field_is_measure,
            )
            if reason:
                dropped.append(f"filter on {label}: {reason}")
                continue
            for op, values in clauses:
                if f.field_is_measure:
                    measures.append(MeasureFilter(measure=f.field_name, op=op, values=values))
                else:
                    columns.append(
                        FilterClause(
                            table=f.field_table, column=f.field_name, op=op,
                            values=[str(v) if v is not None else None for v in values]
                            if op in ("in", "not_in", "eq", "neq") else values,
                            source="visual",
                        )
                    )  # fmt: skip
    return columns, measures, dropped


def _resolve_sort(visual: Visual, dims: list, measures: list) -> list[dict]:
    """PBIR sorts mapped onto output column keys. A sort on an aggregated column targets the
    implicit measure's alias; sorts matching no output column are dropped (Snowflake rejects
    ORDER BY an unprojected column)."""
    dim_keys = {d.key for d in dims}
    by_name = {m.name: m.key for m in measures if m.name}
    implicit = {(m.table, m.column): m.key for m in measures if not m.name and m.table}
    out: list[dict] = []
    for s in visual.sort:
        field = s.get("field")
        if not field:
            continue
        direction = s.get("direction", "Ascending")
        if s.get("is_measure"):
            key = by_name.get(field)
        else:
            col_key = f"{s.get('table')}.{field}"
            key = col_key if col_key in dim_keys else implicit.get((s.get("table"), field))
        if key is not None:
            out.append({"key": key, "direction": direction})
    return out


def _untranslatable_calc_column_warnings(
    bundle: ReportBundle, compiler: MeasureCompiler
) -> list[str]:
    out: list[str] = []
    for t in bundle.model.tables:
        for c in t.columns:
            if c.expression is None:
                continue
            try:
                compiler.compile_calc_column(t.name, c.name)
            except DaxUnsupported as e:
                out.append(f"calculated column {t.name}[{c.name}] cannot be translated: {e}")
    return out


def _drillthrough_fields(page: Page, bundle: ReportBundle, warnings: list[str]) -> list[DrillthroughFieldSpec]:
    """The fields a drill-through page receives: columns by their exact model name, measures when
    the model (or a report-extension measure) has them."""
    out: list[DrillthroughFieldSpec] = []
    for f in page.drillthrough:
        if f.is_measure:
            found = bundle.model.find_measure(f.name or "")
            if found is not None:
                out.append(DrillthroughFieldSpec(measure=found[1].name))
                continue
        else:
            table = bundle.model.table(f.table or "")
            col = table.column(f.name or "") if table else None
            if table is not None and col is not None:
                out.append(DrillthroughFieldSpec(table=table.name, column=col.name))
                continue
        warnings.append(
            f"drill-through page '{page.display_name}': field {f.table}[{f.name}] is not in the "
            "model; ignored"
        )
    return out


def _tooltip_page(visual: Visual, tooltip_pages: set[str]) -> tuple[str | None, str | None]:
    """(tooltip page, missing section): None when `show` is false, the type is Default, there is
    no section or it is `___AUTO___`; the section when it names an exported Tooltip page; else the
    missing section is returned so it can be reported."""
    t = visual.tooltip
    if t is None or t.show is False or (t.type or "Canvas") == "Default" or not t.section:
        return None, None
    if t.section == "___AUTO___":
        return None, None
    if t.section in tooltip_pages:
        return t.section, None
    return None, t.section


def _pbir_payload(visual: Visual) -> dict:
    return {
        "objects": visual.formatting or {},
        "container_objects": visual.container_objects or {},
        "fields": [
            {
                "role": f.role,
                "table": f.table,
                "name": f.name,
                "display_name": f.display_name,
                "is_measure": f.is_measure,
                "aggregate": f.aggregate,
                "query_ref": f.query_ref,
            }
            for f in visual.fields
        ],
        "sort": visual.sort,
        "is_hidden": visual.is_hidden,
        "self_hidden": visual.self_hidden,
        "parent_group": visual.parent_group,
    }


def compile_visual(
    visual: Visual,
    bundle: ReportBundle,
    compiler: MeasureCompiler,
    warnings: list[str],
    tier2_sql: dict[str, str] | None = None,
) -> VisualSpec:
    """One visual's spec: layout + query (`_compile_visual`) plus the raw PBIR passthrough."""
    if visual.visual_type not in SUPPORTED_VISUALS and _is_kpi_card(visual):
        visual = visual.model_copy(update={"visual_type": "kpiCard"})
    if visual.visual_type in pt.CHROME_VISUAL_TYPES and visual.visual_type != "textbox":
        # chrome: drawn from the PBIR payload alone, no query
        vs = VisualSpec(
            name=visual.name,
            visual_type=visual.visual_type,
            x=visual.position.x,
            y=visual.position.y,
            width=visual.position.width,
            height=visual.position.height,
            z=visual.position.z,
            title=visual.title,
        )
    else:
        vs = _compile_visual(visual, bundle, compiler, warnings, tier2_sql)
    vs.pbir = _pbir_payload(visual)
    vs.action = visual.action
    vs.sync_group = visual.sync_group
    measure = _title_measure(visual)
    filters, measure_filters, dropped = visual_filters_to_query(visual)
    for text in dropped:
        warnings.append(f"{visual.name}: {text}")
    if measure and compiler.model.find_measure(measure) is not None:
        vs.title_query = QuerySpec(
            measures=[MeasureRefSpec(name=measure, alias=measure)],
            filters=[f.model_copy(deep=True) for f in filters],
        )
    if visual.visual_type == "slicer":
        vs.default_selection = pt.saved_slicer_selection(visual)
    if (filters or measure_filters) and vs.query is not None:
        vs.query.filters.extend(filters)
        vs.query.measure_filters.extend(measure_filters)
        vs.options["semantic_force_compatibility"] = True
        vs.options["semantic_force_compatibility_reason"] = "visual has filters on this visual"
    return vs


def _compile_visual(
    visual: Visual,
    bundle: ReportBundle,
    compiler: MeasureCompiler,
    warnings: list[str],
    tier2_sql: dict[str, str] | None = None,
) -> VisualSpec:
    tier2_sql = tier2_sql or {}
    vs = VisualSpec(
        name=visual.name,
        visual_type=visual.visual_type,
        x=visual.position.x,
        y=visual.position.y,
        width=visual.position.width,
        height=visual.position.height,
        z=visual.position.z,
        title=visual.title,
    )
    if visual.visual_type not in SUPPORTED_VISUALS:
        vs.supported = False
        vs.data_status = "unsupported_type"
        vs.unsupported_reason = f"visual type '{visual.visual_type}' not yet in registry"
        return vs

    if visual.visual_type == "textbox":
        vs.static_content = visual.formatting.get("general", [{}])[0].get("properties", {})
        # banner textboxes carry their fill in visualContainerObjects
        _extract_presentation_options(visual, vs)
        return vs

    if visual.visual_type == "slicer":
        fields = [f for f in visual.fields if not f.is_measure and f.table and f.name]
        if not fields:
            vs.supported = False
            vs.unsupported_reason = "slicer without a field"
            return vs
        f = fields[0]
        vs.slicer_target = {"table": f.table, "column": f.name}
        vs.query = QuerySpec(
            dimensions=[DimensionRef(table=f.table, column=f.name)], limit=500
        )
        vs.dim_keys = [f"{f.table}.{f.name}"]
        _extract_presentation_options(visual, vs)
        return vs

    is_table_visual = visual.visual_type in ("pivotTable", "tableEx")
    dims: list[DimensionRef] = []
    column_keys: list[str] = []
    series_keys: list[str] = []
    measures: list[MeasureRefSpec] = []
    measure_roles: dict[str, str] = {}
    dropped: list[str] = []
    # decomposition tree: nearest equivalent is a 2-level drillable treemap
    max_dims = 2 if visual.visual_type == "decompositionTreeVisual" else None
    inactive_levels: set[str] = set()
    for f in visual.fields:
        role = _canonical_role(f.role)
        if (
            f.active is False
            and role in _DIM_ROLES
            and f.is_hierarchy_level
            and f.hierarchy
            and f.table
            and f.name
        ):
            # an inactive drill level: kept in the hierarchy, never queried
            ref = DimensionRef(table=f.table, column=f.name)
            levels = vs.options.setdefault("hierarchy_levels", {})
            levels.setdefault(f.hierarchy, []).append(ref.key)
            inactive_levels.add(ref.key)
            continue
        if role in _DIM_ROLES and not f.is_measure and f.table and f.name:
            if max_dims is not None and len(dims) >= max_dims:
                dropped.append(f"{f.role}: {f.table}.{f.name} (beyond drill depth)")
                continue
            ref = DimensionRef(table=f.table, column=f.name)
            dims.append(ref)
            if f.is_hierarchy_level and f.hierarchy:
                levels = vs.options.setdefault("hierarchy_levels", {})
                levels.setdefault(f.hierarchy, []).append(ref.key)
            if role == "Columns":
                column_keys.append(ref.key)
            elif role == "Series" or (
                role == "Legend" and visual.visual_type not in ("donutChart", "pieChart")
            ):
                series_keys.append(ref.key)
        elif role in _MEASURE_ROLES:
            if f.is_measure and f.name:
                measures.append(MeasureRefSpec(name=f.name, alias=f.name))
                measure_roles[f.name] = role
            elif f.table and f.name:
                # in table visuals a bare, non-aggregated column is a grouping
                # column (PBI "don't summarize"), not an implicit measure
                col = None
                t = bundle.model.table(f.table)
                if t is not None:
                    col = t.column(f.name)
                summarizes = f.aggregate or (
                    col is not None and col.summarize_by.value not in ("none", "default")
                )
                if is_table_visual and not summarizes:
                    dims.append(DimensionRef(table=f.table, column=f.name))
                else:
                    alias = f.display_name or f"{f.table}.{f.name}"
                    measures.append(
                        MeasureRefSpec(
                            table=f.table, column=f.name, aggregate=f.aggregate, alias=alias
                        )
                    )
                    measure_roles[alias] = role
        else:
            # projection in a role the compiler doesn't map -> visible parity gap
            label = f"[{f.name}]" if f.is_measure else f"{f.table}.{f.name}"
            dropped.append(f"{f.role}: {label}")

    if dropped:
        vs.dropped_fields = dropped
        warnings.append(f"{visual.name}: dropped projections {dropped}")

    if not measures and not dims:
        vs.supported = False
        vs.unsupported_reason = "no query fields"
        return vs

    # verify measures compile; tier-2 registry rescues, else park the visual
    non_semantic: list[str] = []
    semantic_homes: set[str] = set()
    for m in measures:
        if m.name:
            try:
                compiler.compile_measure(m.name)
            except DaxUnsupported as e:
                if m.name in tier2_sql:
                    vs.substituted_as = vs.substituted_as or "AI-translated measure"
                    continue
                vs.supported = False
                vs.data_status = "untranslated"
                vs.unsupported_reason = f"measure [{m.name}] needs tier-2: {e}"
                vs.draft_query = QuerySpec(
                    dimensions=dims,
                    measures=measures,
                    sort=[
                        {
                            "key": x.get("field")
                            if x.get("is_measure")
                            else f"{x.get('table')}.{x.get('field')}",
                            "direction": x.get("direction", "Ascending"),
                        }
                        for x in visual.sort
                        if x.get("field")
                    ]
                    or _default_sort(visual, dims, measures),
                )
                vs.dim_keys = [d.key for d in dims]
                vs.column_keys = column_keys
                vs.series_keys = series_keys
                vs.measure_keys = [x.key for x in measures]
                warnings.append(f"{visual.name}: {vs.unsupported_reason}")
                return vs
            # Some tier-1 measures still require the compatibility runtime
            # (for example time-shift/window semantics) and cannot be surfaced
            # as semantic-view metrics yet.
            plan = semantic_metric_plan(bundle.model, compiler, m.name)
            if plan is None:
                non_semantic.append(m.name)
                continue
            if plan.kind == "table" and plan.home:
                semantic_homes.add(plan.home)
            elif plan.kind == "derived":
                semantic_homes.update(home for home, _, _ in plan.helpers)

    sort = _resolve_sort(visual, dims, measures)
    if not sort:
        sort = _default_sort(visual, dims, measures)

    vs.query = QuerySpec(dimensions=dims, measures=measures, sort=sort)
    vs.dim_keys = [d.key for d in dims]
    vs.column_keys = column_keys
    vs.series_keys = series_keys
    vs.measure_keys = [m.key for m in measures]
    vs.measure_roles = measure_roles
    if visual.visual_type == "decompositionTreeVisual":
        vs.substituted_as = "decomposition tree (top 2 levels)"

    # Phase-7: emit hierarchy drill metadata
    if "hierarchy_levels" in vs.options:
        hmap = vs.options["hierarchy_levels"]
        # pick the first hierarchy used by the visual as default drill track
        hname = next(iter(hmap.keys()))
        levels = hmap[hname]
        active = [lv for lv in levels if lv not in inactive_levels]
        vs.hierarchy = {
            "name": hname,
            "levels": levels,
            "current_level": active[-1] if active else (levels[-1] if levels else None),
            "drill_enabled": len(levels) > 1,
            "expand_rows": visual.visual_type == "pivotTable" and bool(inactive_levels),
        }

    for f in visual.fields:
        if f.show_as and f.active is not False:
            key = f.name if f.is_measure else (f.display_name or f"{f.table}.{f.name}")
            if key in vs.measure_keys:
                vs.measure_show_as[key] = f.show_as
    for m in measures:
        if m.name:
            fmt = _format_for(bundle, m.name)
            if fmt:
                vs.measure_formats[m.key] = fmt
            # Phase-7: surface What-If parameter linkage for renderer controls
            what_if = _find_what_if_for_measure(bundle, m.name)
            if what_if is not None:
                vs.options.setdefault("what_if", what_if)
    vs.sort = sort
    _extract_presentation_options(visual, vs)
    if non_semantic:
        vs.options["semantic_force_compatibility"] = True
        vs.options["semantic_force_compatibility_reason"] = (
            "measures not semantic-metric eligible: " + ", ".join(sorted(non_semantic))
        )
    elif semantic_homes and dims:
        # A SEMANTIC_VIEW query resolves every requested metric against every
        # requested dimension, so each dimension must be reachable from EVERY
        # metric home — reachability from just one home is not enough.
        for d in dims:
            unrelated = [
                home
                for home in semantic_homes
                if d.table != home and d.table not in _reachable_tables(bundle, home)
            ]
            if unrelated:
                vs.options["semantic_force_compatibility"] = True
                vs.options["semantic_force_compatibility_reason"] = (
                    f"dimension table {d.table} not connected to semantic metric homes "
                    + ", ".join(sorted(unrelated))
                )
                break
    return vs


def compile_dashboard(
    bundle: ReportBundle,
    tier2_sql: dict[str, str] | None = None,
    compilation_log=None,
) -> tuple[DashboardSpec, BindingMap]:
    binding_map = build_bundle_binding_map(bundle)
    pt.apply_source_passthroughs(bundle)
    filters_passthrough(bundle)
    compiler = MeasureCompiler(bundle.model, logger=compilation_log)
    warnings = list(binding_map.warnings)
    warnings.extend(_untranslatable_calc_column_warnings(bundle, compiler))
    tier2_sql = tier2_sql or {}

    tiers: dict[str, int] = {}
    for t in bundle.model.tables:
        for m in t.measures:
            try:
                cm = compiler.compile_measure(m.name)
                tiers[m.name] = cm.tier
            except DaxUnsupported:
                tiers[m.name] = 2 if m.name in tier2_sql else -1
                if compilation_log is not None:
                    # only here is it known that a failed measure ended tier-2 or stayed parked
                    compilation_log.annotate_tier(
                        m.name, "tier2" if m.name in tier2_sql else "parked"
                    )

    tooltip_pages = {p.name for p in bundle.report.pages if p.page_type == "Tooltip"}
    pages = [
        PageSpec(
            name=p.name,
            display_name=p.display_name,
            width=p.width,
            height=p.height,
            ordinal=p.ordinal,
            background=p.background or {},
            is_hidden=p.is_hidden,
            display_option=p.display_option or "FitToPage",
            filters=ordered_cards(
                p.filters, p.filter_sort_order, bundle, warnings, "page", compiler
            ),
            filter_pane=p.filter_pane,
            page_type=p.page_type,
            drillthrough=_drillthrough_fields(p, bundle, warnings),
            visuals=[
                compile_visual(v, bundle, compiler, warnings, tier2_sql) for v in p.visuals
            ],
        )
        for p in bundle.report.pages
    ]
    spec = DashboardSpec(
        report_name=bundle.report.name,
        pages=pages,
        warnings=warnings,
        measure_tiers=tiers,
        theme=compile_theme(bundle.report.theme),
        interaction_graph=bundle.report.interaction_graph,
        bookmarks=bundle.report.bookmarks,
        drill_through=bundle.report.drill_through,
        what_if_parameters=_detect_what_if_parameters(bundle),
        pbi_theme=pt.pbi_theme_passthrough(bundle),
        vertical_alignment=bundle.report.vertical_alignment or "Top",
        report_filters=ordered_cards(
            bundle.report.filters,
            bundle.report.filter_sort_order,
            bundle,
            warnings,
            "report",
            compiler,
        ),
        filter_pane=bundle.report.filter_pane,
        allow_change_filter_types=bundle.report.allow_change_filter_types,
    )
    spec.bookmarks = [bookmark_filter_values(b, spec, bundle, compiler) for b in spec.bookmarks]
    # tooltip pages and drill-through targets
    for page_src, page_spec in zip(bundle.report.pages, spec.pages, strict=True):
        missing: dict[str, int] = {}
        by_name = {v.name: v for v in page_src.visuals}
        for vs in page_spec.visuals:
            src = by_name.get(vs.name)
            if src is None:
                continue
            vs.tooltip_page, gone = _tooltip_page(src, tooltip_pages)
            if gone:
                missing[gone] = missing.get(gone, 0) + 1
        for section, count in sorted(missing.items()):
            spec.warnings.append(
                f"page '{page_src.display_name}': {count} visual(s) use tooltip page '{section}', "
                "which is not in the export; the default tooltip is shown"
            )
    spec.drill_through = [
        DrillThroughTarget(page=p.name, fields=[f.key for f in p.drillthrough])
        for p in spec.pages
        if p.drillthrough
    ]
    return spec, binding_map


def page_filters_to_clauses(page: Page) -> list[FilterClause]:
    """Convert PBIR page filters with concrete conditions into engine filters."""
    out: list[FilterClause] = []
    for f in page.filters:
        if not (f.field_table and f.field_name):
            continue
        values = _categorical_values(f.definition)
        if values:
            out.append(FilterClause(table=f.field_table, column=f.field_name, values=values))
    return out


def _categorical_values(definition: dict) -> list:
    """Pull literal values out of a PBIR filter definition (Version 2 shape)."""
    values = []
    for where in definition.get("Where", []):
        cond = where.get("Condition", {})
        in_expr = cond.get("In", {})
        for tup in in_expr.get("Values", []):
            for lit in tup:
                v = lit.get("Literal", {}).get("Value")
                if isinstance(v, str):
                    if v.endswith("L"):
                        values.append(int(v[:-1]))
                    elif v.startswith("'") and v.endswith("'"):
                        values.append(v[1:-1])
                    else:
                        try:
                            values.append(float(v) if "." in v else int(v))
                        except ValueError:
                            values.append(v)
    return values
