"""Filter predicates as Snowflake SQL, shared by the engine, the semantic-view adapter and the
standalone dashboard templates. Must not import `app`: the standalone package vendors this file."""

from __future__ import annotations

import re
from typing import Any


class TemplateError(ValueError):
    pass


# operators whose predicate needs no value list
NO_VALUE_OPS = frozenset(
    {"is_blank", "is_not_blank", "is_empty", "is_not_empty", "or", "relative", "topn", "in_query"}
)


def clause_needs_values(op: str) -> bool:
    return op not in NO_VALUE_OPS and op != "between_dates"


def lit(v: Any) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return repr(v)
    return "'" + str(v).replace("'", "''") + "'"


def null_safe_in_sql(col: str, op: str, values: list, lit_fn=lit) -> str:
    """Filter lists that mention NULL, rendered the way Power BI/DAX treats BLANK:
    not_in [NULL] -> col IS NOT NULL; not_in [NULL, v] -> (col IS NOT NULL AND col != v);
    in [NULL, ...] -> (col IS NULL OR col IN (...)); eq NULL -> IS NULL; neq NULL -> IS NOT NULL."""
    present = [v for v in values if v is not None]
    has_null = len(present) != len(values)
    if op == "eq":
        return f"{col} IS NULL" if not present else f"{col} = {lit_fn(present[0])}"
    if op == "neq":
        return f"{col} IS NOT NULL" if not present else f"{col} <> {lit_fn(present[0])}"
    listed = ", ".join(lit_fn(v) for v in present)
    if op == "not_in":
        if not has_null:
            return f"{col} NOT IN ({listed})"
        if not present:
            return f"{col} IS NOT NULL"
        if len(present) == 1:
            return f"({col} IS NOT NULL AND {col} != {lit_fn(present[0])})"
        return f"({col} IS NOT NULL AND {col} NOT IN ({listed}))"
    if op == "in":
        if not has_null:
            return f"{col} IN ({listed})"
        if not present:
            return f"{col} IS NULL"
        return f"({col} IS NULL OR {col} IN ({listed}))"
    raise TemplateError(f"unknown list operator {op}")


def like_pattern(text: str) -> str:
    """`text` escaped for `ILIKE ... ESCAPE '!'`. A backslash is an escape in Snowflake string
    literals but not in DuckDB's, so `!` is the escape character."""
    return text.replace("!", "!!").replace("%", "!%").replace("_", "!_")


def _get(obj: Any, name: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


_UNITS = {0: "DAY", 1: "WEEK", 2: "MONTH", 3: "YEAR", 5: "SECOND", 6: "MINUTE", 7: "HOUR"}


def _render_bound(tree: Any, anchor: str, depth: int = 0) -> str:
    if depth > 10 or not isinstance(tree, dict):
        raise TemplateError("invalid relative date bound: too deep or not a mapping")
    if "Now" in tree:
        return anchor
    if "DateAdd" in tree:
        node = tree["DateAdd"]
        amount = node.get("Amount")
        unit = _UNITS.get(node.get("TimeUnit"))
        if isinstance(amount, bool) or not isinstance(amount, int) or unit is None:
            raise TemplateError(
                "invalid relative date bound: DateAdd needs an integer amount and a known unit"
            )
        inner = _render_bound(node.get("Expression"), anchor, depth + 1)
        return f"DATEADD({unit}, {amount}, {inner})"
    if "DateSpan" in tree:
        node = tree["DateSpan"]
        unit = _UNITS.get(node.get("TimeUnit"))
        if unit is None:
            raise TemplateError("invalid relative date bound: DateSpan needs a known unit")
        inner = _render_bound(node.get("Expression"), anchor, depth + 1)
        return f"DATE_TRUNC('{unit}', {inner})"
    raise TemplateError("invalid relative date bound: unknown node")


def relative_sql(col: str, params: dict, today: str, now: str) -> str:
    anchor = now if params.get("time") else today
    lower, upper = params.get("lower"), params.get("upper")
    lo = _render_bound(lower, anchor)
    hi = _render_bound(upper, anchor)
    if isinstance(upper, dict) and "DateSpan" in upper:
        unit = _UNITS[upper["DateSpan"]["TimeUnit"]]
        return f"({col} >= {lo} AND {col} < DATEADD({unit}, 1, {hi}))"
    return f"({col} >= {lo} AND {col} <= {hi})"


def predicate_sql(
    col: str,
    op: str,
    values: list | None = None,
    clauses: list | None = None,
    params: dict | None = None,
    today: str = "CURRENT_DATE()",
    now: str = "CURRENT_TIMESTAMP()",
) -> str | None:
    """SQL predicate over `col`, or None for an operator that has no direct rendering (Top N,
    unknown ones)."""
    values = list(values or [])
    params = params or {}
    if op in ("in", "not_in", "eq", "neq"):
        return null_safe_in_sql(col, op, values)
    if op in ("gt", "gte", "lt", "lte"):
        sign = {"gt": ">", "gte": ">=", "lt": "<", "lte": "<="}[op]
        return f"{col} {sign} {lit(values[0])}"
    if op in ("contains", "not_contains", "starts_with", "not_starts_with"):
        text = "" if values[0] is None else str(values[0])
        pattern = like_pattern(text)
        pattern = f"%{pattern}%" if "contains" in op else f"{pattern}%"
        like = f"CAST({col} AS VARCHAR) ILIKE {lit(pattern)} ESCAPE '!'"
        return f"({col} IS NOT NULL AND NOT ({like}))" if op.startswith("not_") else like
    if op == "is_blank":
        return f"{col} IS NULL"
    if op == "is_not_blank":
        return f"{col} IS NOT NULL"
    if op == "is_empty":
        return f"{col} = ''"
    if op == "is_not_empty":
        return f"{col} <> ''"
    if op == "or":
        if not clauses:
            return "1=0"
        parts = []
        for c in clauses:
            sub = predicate_sql(
                col,
                _get(c, "op", "in"),
                _get(c, "values", []),
                _get(c, "clauses", []),
                _get(c, "params", {}),
                today,
                now,
            )
            if sub is None or _get(c, "op") in ("topn", "in_query"):
                return None
            parts.append(f"({sub})")
        return "(" + " OR ".join(parts) + ")"
    if op == "relative":
        return relative_sql(col, params, today, now)
    if op == "between_dates":
        lo = values[0] if len(values) > 0 else None
        hi = values[1] if len(values) > 1 else None
        if lo is None and hi is None:
            return f"{col} IS NOT NULL"
        parts = []
        if lo is not None:
            parts.append(f"{col} >= {lit(lo)}")
        if hi is not None:
            parts.append(f"{col} <= {lit(hi)}")
        return "(" + " AND ".join(parts) + ")"
    if op == "in_query" and params.get("token"):
        return f"{col} IN ({params['token']})"
    return None


# ---------------------------------------------------------------- templates (standalone dashboard)

_TOKEN = re.compile(r"\{\{(p|isf|#k|/k):([A-Za-z0-9_]+)\}\}")
UNREACHABLE = "[OVERLAY:UNREACHABLE_FILTER] filter on {table} cannot reach this visual; ignored"


def _flt(f: Any, name: str, default: Any = None) -> Any:
    return _get(f, name, default)


def _check_filter(f: Any) -> None:
    op = _flt(f, "op", "in")
    if op == "topn":
        raise TemplateError("Top N filters are not available in the standalone dashboard")
    if op == "in_query":
        raise TemplateError("unknown filter op in_query")
    values = _flt(f, "values", []) or []
    if clause_needs_values(op) and op not in ("in", "not_in") and not values:
        raise TemplateError(f"filter op '{op}' needs at least one value")
    for c in _flt(f, "clauses", []) or []:
        if _flt(c, "op") in ("topn", "in_query"):
            raise TemplateError(f"filter op '{_flt(c, 'op')}' cannot be used inside an OR filter")


def _clause_predicate(col: str, f: Any, today: str, now: str) -> str:
    op = _flt(f, "op", "in")
    values = list(_flt(f, "values", []) or [])
    if op in ("in", "not_in") and not values:
        # an empty selection matches nothing / excludes nothing
        return "1=0" if op == "in" else "1=1"
    sql = predicate_sql(col, op, values, _flt(f, "clauses"), _flt(f, "params"), today, now)
    if sql is None:
        raise TemplateError(f"unknown filter op {op}")
    return sql


def render_template(
    sql: str,
    meta: dict,
    filters: list,
    today: str = "CURRENT_DATE()",
    now: str = "CURRENT_TIMESTAMP()",
) -> tuple[str, list[str]]:
    """Fill a query template with the request's filters: `(sql, unapplied warnings)`.

    `{{p:N}}` is predicate occurrence N (the AND of the clauses on its slot's column, `1=1` when
    inactive); `{{#k:K}}...{{/k:K}}` is kept when any of its slots is active, else its `else`
    text; `{{isf:K}}` is TRUE when static or any of its slots is active."""
    slot_of = {
        (str(s["table"]).casefold(), str(s["column"]).casefold()): sid
        for sid, s in (meta.get("slots") or {}).items()
    }
    by_slot: dict[str, list] = {}
    unapplied: list[str] = []
    for f in filters:
        _check_filter(f)
        key = (str(_flt(f, "table", "")).casefold(), str(_flt(f, "column", "")).casefold())
        sid = slot_of.get(key)
        if sid is None:
            unapplied.append(UNREACHABLE.format(table=_flt(f, "table")))
            continue
        by_slot.setdefault(sid, []).append(f)
    active = set(by_slot)
    for guard in meta.get("guards") or []:
        if active & set(guard["slots"]):
            raise TemplateError(guard["message"])
    for sid in sorted(active):
        message = (meta.get("slot_errors") or {}).get(sid)
        if message:
            raise TemplateError(message)

    preds = meta.get("preds") or []
    blocks = meta.get("blocks") or {}
    isf = meta.get("isf") or {}

    def predicate(n: int) -> str:
        info = preds[n]
        clauses = by_slot.get(info["slot"], [])
        if not clauses:
            return "1=1"
        parts = [_clause_predicate(info["col"], f, today, now) for f in clauses]
        return parts[0] if len(parts) == 1 else " AND ".join(f"({p})" for p in parts)

    out: list[str] = []
    # a stack of (block id, kept?, buffer); text inside a dropped block is discarded
    stack: list[tuple[str, bool, list[str]]] = []
    pos = 0

    def emit(text: str) -> None:
        (stack[-1][2] if stack else out).append(text)

    for m in _TOKEN.finditer(sql):
        emit(sql[pos : m.start()])
        pos = m.end()
        kind, ident = m.group(1), m.group(2)
        if kind == "p":
            emit(predicate(int(ident)))
        elif kind == "isf":
            info = isf[ident]
            emit("TRUE" if info.get("static") or active & set(info.get("slots", [])) else "FALSE")
        elif kind == "#k":
            stack.append((ident, bool(active & set(blocks[ident]["slots"])), []))
        else:  # /k
            bid, kept, buf = stack.pop()
            text = "".join(buf) if kept else str(blocks[bid].get("else", ""))
            emit(text)
    emit(sql[pos:])
    if stack:
        raise TemplateError("unbalanced conditional blocks in the query template")
    return "".join(out), unapplied
