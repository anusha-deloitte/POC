"""Phase 09: raw PBIR passthrough into the dashboard spec (visuals, pages, themes, resources)."""

from __future__ import annotations

import pytest

from app.runtime import pbir_passthrough as pt
from tests.pbir_world import (
    PAGE,
    Report,
    column,
    group_json,
    lit,
    measure,
    projection,
    visual_json,
)


@pytest.fixture()
def rep(tmp_path):
    return Report(tmp_path)


def test_visual_passthrough_carries_objects_container_fields_and_action(rep):
    rep.add_visual(
        visual_json(
            "btn1",
            "actionButton",
            objects={"text": [{"properties": {"text": lit("'Go'")}}]},
            container={
                "visualLink": [
                    {
                        "properties": {
                            "show": lit("true"),
                            "type": lit("'PageNavigation'"),
                            "navigationSection": lit("'other'"),
                        }
                    }
                ]
            },
        )
    )
    _, spec = rep.compile()
    btn = rep.visual(spec, "btn1")
    assert btn.pbir["objects"]["text"][0]["properties"]["text"] == lit("'Go'")
    assert btn.action == {"type": "PageNavigation", "page": "other"}
    bar = rep.visual(spec, "bar00001aaaabbbbcccc")
    roles = {f["role"] for f in bar.pbir["fields"]}
    assert roles == {"Category", "Y"}
    field = next(f for f in bar.pbir["fields"] if f["role"] == "Y")
    assert field["name"] == "Total Sales" and field["is_measure"] is True
    assert bar.pbir["sort"] and bar.pbir["is_hidden"] is False and bar.pbir["parent_group"] is None


def test_page_fields_and_defaults(rep):
    rep.patch_page(
        displayOption="FitToWidth",
        visibility="HiddenInViewMode",
        objects={"background": [{"properties": {"color": {"solid": {"color": lit("'#EEEEEE'")}}}}]},
    )
    rep.patch_report(
        objects={"section": [{"properties": {"verticalAlignment": lit("'Middle'")}}]}
    )
    _, spec = rep.compile()
    page = spec.pages[0]
    assert page.display_option == "FitToWidth" and page.is_hidden is True
    assert page.background["properties"]["color"]["solid"]["color"] == lit("'#EEEEEE'")
    assert spec.vertical_alignment == "Middle"


def test_default_display_option_is_fit_to_page(rep):
    rep.patch_json(rep.page_dir / "page.json", displayOption=None)
    _, spec = rep.compile()
    assert spec.pages[0].display_option == "FitToPage"
    assert spec.vertical_alignment == "Top"


def test_theme_passthrough_reads_the_base_theme(rep):
    rep.write_base_theme("CY24SU06", {"name": "CY24SU06", "dataColors": ["#111111"]})
    _, spec = rep.compile()
    assert spec.pbi_theme["base_name"] == "CY24SU06"
    assert spec.pbi_theme["base"]["dataColors"] == ["#111111"]
    assert spec.pbi_theme["custom"] == {}


def test_missing_base_theme_is_empty(rep):
    _, spec = rep.compile()
    assert spec.pbi_theme["base_name"] == "CY24SU06" and spec.pbi_theme["base"] == {}


def test_nested_upload_finds_report_resources_and_theme(tmp_path):
    rep = Report(tmp_path, nested=True)
    rep.write_base_theme("CY24SU06", {"dataColors": ["#222222"]})
    rep.write_resource("logo.png")
    bundle, spec = rep.compile()
    assert pt.report_dir(bundle) == rep.report_dir.resolve()
    assert spec.pbi_theme["base"]["dataColors"] == ["#222222"]
    assert pt.resolve_resource(bundle, "logo.png") is not None


def test_group_children_keep_their_own_hidden_flag_and_geometry(rep):
    rep.add_visual(group_json("grp", x=100, y=50, z=3, hidden=True))
    rep.add_visual(
        visual_json("child1", "card", x=10, y=5, z=2, parent="grp",
                    query_state={"Values": {"projections": [
                        projection(measure("Sales", "Total Sales"), "Sales.Total Sales")]}})
    )  # fmt: skip
    rep.add_visual(visual_json("child2", "card", x=0, y=0, z=1, parent="grp", hidden=False))
    _, spec = rep.compile()
    child = rep.visual(spec, "child1")
    assert (child.x, child.y) == (110, 55) and child.z == pytest.approx(3 + 2 / 100000)
    assert child.pbir["is_hidden"] is True  # hidden through its ancestor group
    assert child.pbir["self_hidden"] is False  # its own flag is kept
    group = rep.visual(spec, "grp")
    assert group.pbir["self_hidden"] is True and group.visual_type == "visualGroup"


def test_group_container_objects_are_passed_through(rep):
    rep.add_visual(
        group_json("grp", objects={"background": [{"properties": {"show": lit("true")}}]})
    )
    _, spec = rep.compile()
    group = rep.visual(spec, "grp")
    assert group.pbir["container_objects"]["background"][0]["properties"]["show"] == lit("true")


def test_stored_bundle_reads_new_fields_from_source(rep):
    """A bundle ingested before the parser learnt these fields still renders them."""
    rep.add_visual(group_json("grp", x=10, y=10, objects={"x": [{"properties": {}}]}))
    rep.add_visual(visual_json("kid", "card", x=1, y=1, parent="grp"))
    rep.patch_page(displayOption="ActualSize")
    bundle = rep.bundle()
    # simulate an old bundle: strip what newer parsers add
    for page in bundle.report.pages:
        page.display_option = None
        page.background = {}
        for v in page.visuals:
            v.container_objects = {}
            v.self_hidden = None
            v.parent_group = None
            v.action = None
            for f in v.fields:
                f.active = None
    bundle.report.interaction_graph.edges.clear()
    bundle.report.bookmarks = []
    bundle.report.vertical_alignment = None
    pt.apply_source_passthroughs(bundle)
    assert bundle.report.pages[0].display_option == "ActualSize"
    assert bundle.report.vertical_alignment == "Top"
    grp = next(v for v in bundle.report.pages[0].visuals if v.name == "grp")
    assert grp.container_objects == {"x": [{"properties": {}}]}
    kid = next(v for v in bundle.report.pages[0].visuals if v.name == "kid")
    assert kid.parent_group == "grp" and kid.position.x == 11
    bar = next(v for v in bundle.report.pages[0].visuals if v.name.startswith("bar"))
    assert all(f.active is True for f in bar.fields)
    # idempotent
    pt.apply_source_passthroughs(bundle)
    assert bundle.report.pages[0].display_option == "ActualSize"


def test_bookmarks_are_always_re_read(rep):
    rep.write_bookmark("b1", {"activeSection": PAGE}, display="First")
    bundle = rep.bundle()
    bundle.report.bookmarks = []
    pt.bookmarks_passthrough(bundle)
    assert [b.display_name for b in bundle.report.bookmarks] == ["First"]
    bundle.report.bookmarks[0].display_name = "Edited"
    pt.bookmarks_passthrough(bundle)
    assert bundle.report.bookmarks[0].display_name == "First"


def test_empty_interaction_graph_is_rebuilt(rep):
    rep.patch_page(
        visualInteractions=[
            {"source": "slicer01aaaabbbbcccc", "target": "bar00001aaaabbbbcccc", "type": "NoFilter"}
        ]
    )
    bundle = rep.bundle()
    bundle.report.interaction_graph.edges.clear()
    pt.interaction_graph_passthrough(bundle)
    assert [(e.from_visual, e.mode.value) for e in bundle.report.interaction_graph.edges] == [
        ("slicer01aaaabbbbcccc", "none")
    ]


def test_image_source_registered_and_linked(rep):
    registered = visual_json(
        "img1", "image",
        objects={"image": [{"properties": {"imageUrl": {"expr": {"ResourcePackageItem": {
            "PackageName": "RegisteredResources", "PackageType": 1, "ItemName": "logo123.png"}}}}}]},
    )  # fmt: skip
    linked = visual_json(
        "img2", "image",
        objects={"image": [{"properties": {"imageUrl": lit("'https://example.com/a.png'")}}]},
    )  # fmt: skip
    rep.add_visual(registered)
    rep.add_visual(linked)
    bundle = rep.bundle()
    by = {v.name: v for v in bundle.report.pages[0].visuals}
    assert pt.image_source(by["img1"]) == {"resource": "logo123.png"}
    assert pt.image_source(by["img2"]) == {"url": "https://example.com/a.png"}
    assert pt.image_source(by["bar00001aaaabbbbcccc"]) is None


def test_export_collects_button_icons_and_images(rep):
    item = lambda n: {"expr": {"ResourcePackageItem": {  # noqa: E731
        "PackageName": "RegisteredResources", "PackageType": 1, "ItemName": n}}}
    rep.add_visual(visual_json("img1", "image", objects={"image": [{"properties": {"imageUrl": item("a.png")}}]}))
    rep.add_visual(visual_json("btn1", "actionButton",
                               objects={"icon": [{"properties": {"image": item("icon.svg")}}]}))  # fmt: skip
    rep.add_visual(visual_json("btn2", "actionButton", objects={"icon": [{"properties": {"image": item("a.png")}}]}))
    _, spec = rep.compile()
    assert pt.referenced_resources(spec) == ["a.png", "icon.svg"]


def test_resources_endpoint_rejects_traversal_and_other_types(rep):
    bundle = rep.bundle()
    rep.write_resource("ok.png")
    rep.write_resource("notes.txt")
    rep.write_resource(".hidden.png")
    assert pt.resolve_resource(bundle, "ok.png").name == "ok.png"
    for bad in ("../../report.json", "..\\x.png", "notes.txt", ".hidden.png", "a/b.png", "", "x;y.png"):
        assert pt.resolve_resource(bundle, bad) is None, bad
    assert pt.resolve_resource(bundle, "missing.png") is None


def test_saved_slicer_selection(rep):
    sel = lambda body: {"general": [{"properties": {"filter": {"filter": body}}}]}  # noqa: E731
    in_us = {"Version": 2, "Where": [{"Condition": {"In": {"Values": [
        [{"Literal": {"Value": "'US'"}}], [{"Literal": {"Value": "'DE'"}}]]}}}]}  # fmt: skip
    inverted = {"Where": [{"Condition": {"Not": {"Expression": {"In": {"Values": [
        [{"Literal": {"Value": "'US'"}}]]}}}}}]}  # fmt: skip
    nonliteral = {"Where": [{"Condition": {"In": {"Values": [[{"Column": {}}]]}}}]}
    qs = {"Values": {"projections": [projection(column("Customer", "Country"), "Customer.Country")]}}
    for name, body in (("s1", in_us), ("s2", inverted), ("s3", nonliteral)):
        rep.add_visual(visual_json(name, "slicer", query_state=qs, objects=sel(body)))
    rep.add_visual(visual_json("s4", "slicer", query_state=qs))
    _, spec = rep.compile()
    assert rep.visual(spec, "s1").default_selection == ["US", "DE"]
    assert rep.visual(spec, "s2").default_selection == []
    assert rep.visual(spec, "s3").default_selection == []
    assert rep.visual(spec, "s4").default_selection == []


def test_untranslatable_calculated_columns_are_reported(rep):
    from app.ir.model import Column, DataType

    bundle = rep.bundle()
    sales = bundle.model.table("Sales")
    sales.columns.append(Column(name="Bad", expression="FOOBAR(1)", data_type=DataType.UNKNOWN))
    from app.runtime.dashboard import compile_dashboard

    spec, _ = compile_dashboard(bundle)
    assert any("calculated column Sales[Bad]" in w for w in spec.warnings)
