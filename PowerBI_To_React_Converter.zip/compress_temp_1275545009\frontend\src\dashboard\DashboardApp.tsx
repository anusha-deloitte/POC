import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { useEffect, useMemo, useRef, useState } from 'react'
import {
  authenticatePublishedSession,
  DashboardApiError,
  fetchDashboardSpec,
  fetchVisualData,
  type DashboardApiConfig,
} from './api'
import { BookmarksMenu } from './BookmarksMenu'
import type { DataPoint } from './dataPoint'
import { DrillMenu } from './DrillMenu'
import { contextClauses, drillTargets } from './drillthrough'
import { TooltipPage } from './TooltipPage'
import { actionCannotRun, useReportNavigation } from './navigation'
import { ModeToggle, type QueryMode } from './ModeToggle'
import { PageCanvas, slicersToFilters } from './PageCanvas'
import { applySlicerChange, queryVisualNames, withSlicerDefaults } from './canvas'
import { FiltersPane } from './FiltersPane'
import {
  applyBookmarkFilters,
  paneClauses,
  resetPane,
  type FilterValues,
  type PaneState,
} from './filtersPaneState'
import {
  buildVisualQueryFilters,
  emptyInteractionState,
  resolveVisualInteractions,
} from './interactions'
import { buildTheme, PbiThemeContext } from './pbi/resolve'
import { ReportActionsContext, ReportContext } from './reportContext'
import { ThemeProvider } from './theme'
import { ConnectionPanel } from './standalone/ConnectionPanel'
import { PageTabs } from './standalone/PageTabs'
import { standaloneApi } from './standalone/standaloneApi'
import { StandaloneTopBar } from './standalone/StandaloneTopBar'
import type { Bookmark, FilterClause, InteractionState, PageSpec, VisualAction, VisualSpec } from './types'

type Values = (string | number)[]

/** The saved selection of every slicer on a page. */
export function defaultSlicerState(page: PageSpec | undefined): Record<string, Values> {
  const out: Record<string, Values> = {}
  for (const v of page?.visuals ?? [])
    if (v.visual_type === 'slicer' && v.default_selection?.length) out[v.name] = [...v.default_selection]
  return out
}

/** Standalone full-tab dashboard: #/dashboard/{conversionId}/{connectionId} */
export function DashboardApp({
  conversionId,
  connectionId,
  apiConfig,
  compact = false,
  showFiltersPane = !compact,
  variant = 'converter',
}: {
  conversionId: string
  connectionId: string
  apiConfig?: DashboardApiConfig
  /** the wizard preview: no app header, full-width canvas */
  compact?: boolean
  /** the Filters pane; Preview applies the defaults without showing it */
  showFiltersPane?: boolean
  /** `standalone`: the packaged dashboard served by the local query service */
  variant?: 'converter' | 'standalone'
}) {
  const standalone = variant === 'standalone'
  const queryClient = useQueryClient()
  const [panelOpen, setPanelOpen] = useState(false)
  const [authRequired, setAuthRequired] = useState(false)
  const [mode, setMode] = useState<QueryMode>('live')
  const [rawSlicers, setRawSlicers] = useState<Record<string, Values>>({})
  const [syncState, setSyncState] = useState<Record<string, Values>>({})
  const [paneState, setPaneState] = useState<PaneState>({})
  const [interactionState, setInteractionState] = useState<InteractionState>(emptyInteractionState())

  const spec = useQuery({
    queryKey: ['dash-spec', conversionId],
    queryFn: () => fetchDashboardSpec(conversionId, undefined, apiConfig),
  })
  // drill-through: the target page opens filtered by the data point and its context
  const [drill, setDrill] = useState<{ page: string; clauses: FilterClause[] } | null>(null)
  const [menu, setMenu] = useState<{ visual: VisualSpec; point: DataPoint; at: { x: number; y: number } } | null>(null)
  const [tip, setTip] = useState<{ visual: VisualSpec; point: DataPoint; at: { x: number; y: number } } | null>(null)
  const tipTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  const drillButton = useRef<(action: VisualAction, visual: VisualSpec) => void>(() => undefined)
  const nav = useReportNavigation(spec.data, {
    onFreshStart: () => {
      setInteractionState(emptyInteractionState())
    },
    onDrillthrough: (action, visual) => drillButton.current(action, visual),
  })
  const page = nav.page
  useEffect(() => () => clearTimeout(tipTimer.current), [])

  // page-local slicer state and cross filters reset on a page change; synced slicers and the
  // Filters pane keep their values
  useEffect(() => {
    setRawSlicers({})
    setInteractionState(emptyInteractionState())
    // ANY page change (Back, tabs, navigation) clears the drill-through context
    setDrill((d) => (d && d.page !== page?.name ? null : d))
    setMenu(null)
    setTip(null)
  }, [page?.name])

  // saved selections apply until changed; synced slicers share their group's selection
  const slicerState = useMemo(
    () => (page ? withSlicerDefaults(page, rawSlicers, syncState) : {}),
    [page, rawSlicers, syncState],
  )

  const theme = useMemo(() => buildTheme(spec.data?.pbi_theme), [spec.data?.pbi_theme])
  const slicerFilters = useMemo(() => (page ? slicersToFilters(page, slicerState) : []), [page, slicerState])
  const visualInteractions = useMemo(
    () => (page && spec.data ? resolveVisualInteractions(page, spec.data.interaction_graph, interactionState) : {}),
    [page, spec.data, interactionState],
  )
  const drillClauses = useMemo(
    () => (drill && page && drill.page === page.name ? drill.clauses : []),
    [drill, page],
  )
  const globalClauses = useMemo(
    () => [...(spec.data ? paneClauses(spec.data, page, paneState) : []), ...drillClauses],
    [spec.data, page, paneState, drillClauses],
  )
  const filtersByVisual = useMemo(
    () =>
      page && spec.data
        ? buildVisualQueryFilters(
            page,
            spec.data.interaction_graph,
            interactionState,
            slicerFilters,
            globalClauses,
          )
        : {},
    [page, spec.data, interactionState, slicerFilters, globalClauses],
  )

  const data = useQuery({
    queryKey: ['dash-data', conversionId, page?.name, filtersByVisual, mode],
    queryFn: () =>
      fetchVisualData(
        conversionId,
        connectionId,
        page!.name,
        queryVisualNames(page!),
        filtersByVisual,
        mode,
        undefined,
        apiConfig,
      ),
    enabled: !!page,
    placeholderData: (prev) => prev,
  })
  const session = useQuery({
    queryKey: ['standalone-session'],
    queryFn: () => standaloneApi.session(apiConfig!),
    enabled: standalone && !!apiConfig,
    refetchInterval: (q) => (q.state.data?.signing_in ? 2000 : false),
  })
  // any snowflake_authentication_required answer opens the connection panel
  useEffect(() => {
    if (!standalone) return
    return queryClient.getQueryCache().subscribe((event) => {
      if (event.type !== 'updated' || event.action.type !== 'error') return
      const error = event.action.error
      if (error instanceof DashboardApiError && error.code === 'snowflake_authentication_required') {
        setAuthRequired(true)
        setPanelOpen(true)
        queryClient.invalidateQueries({ queryKey: ['standalone-session'] })
      }
    })
  }, [standalone, queryClient])
  const signedIn = () => {
    setAuthRequired(false)
    void queryClient.invalidateQueries()
  }
  const authenticate = useMutation({
    mutationFn: () => authenticatePublishedSession(apiConfig!),
    onSuccess: async (result) => {
      if (!result.ok) throw new Error(result.error ?? 'Snowflake authentication failed')
      await data.refetch()
    },
  })

  if (spec.isLoading) return <p className="p-8 text-surface-500">Loading dashboard…</p>
  if (spec.isError)
    return (
      <div role="alert" className="m-8 rounded-lg bg-red-50 p-4 text-sm text-red-700">
        {spec.error.message}
      </div>
    )

  if (
    !standalone &&
    apiConfig?.published &&
    data.error instanceof DashboardApiError &&
    data.error.code === 'snowflake_authentication_required'
  )
    return (
      <div role="alert" className="m-8 rounded-lg bg-white p-6 text-sm text-surface-700">
        <h2 className="font-bold text-surface-900">Snowflake sign-in required</h2>
        <p className="mt-2">Authenticate in your browser to restore this dashboard connection.</p>
        <button
          className="mt-4 rounded-lg bg-brand px-4 py-2 font-semibold text-white"
          disabled={authenticate.isPending}
          onClick={() => authenticate.mutate()}
        >
          {authenticate.isPending ? 'Complete sign-in in your browser…' : 'Authenticate with Snowflake'}
        </button>
        {authenticate.isError && <p className="mt-2 text-red-700">{authenticate.error.message}</p>}
      </div>
    )

  const onSlicerChange = (visual: VisualSpec, values: Values) => {
    const next = applySlicerChange(rawSlicers, syncState, visual, values)
    setRawSlicers(next.slicerState)
    setSyncState(next.syncState)
  }

  const dash = spec.data!
  const drillTo = (target: PageSpec, clauses: FilterClause[]) => {
    setMenu(null)
    setTip(null)
    setDrill({ page: target.name, clauses })
    nav.goToPage(target.name)
  }
  drillButton.current = (action, visual) => {
    const target = dash.pages.find((p) => p.name === action.page)
    if (target)
      drillTo(target, contextClauses(visual, {}, filtersByVisual[visual.name] ?? [], 'drillthrough'))
  }
  const onDrillMenu = (visual: VisualSpec, point: DataPoint, at: { x: number; y: number }) => {
    if (!page || !drillTargets(dash, visual, page.name).length) return false
    clearTimeout(tipTimer.current)
    setTip(null)
    setMenu({ visual, point, at })
    return true
  }
  const onTooltip = (visual: VisualSpec, point: DataPoint | null, at: { x: number; y: number }) => {
    clearTimeout(tipTimer.current)
    if (!point || !visual.tooltip_page || menu) {
      setTip(null)
      return
    }
    tipTimer.current = setTimeout(() => setTip({ visual, point, at }), 350)
  }
  const tipPage = tip ? dash.pages.find((p) => p.name === tip.visual.tooltip_page) : undefined

  // a bookmark with filter state restores the pane and slicers / sync groups; one captured with
  // Data off leaves the filters as they are
  const applyBookmark = (bookmark: Bookmark) => {
    const values = (bookmark.state as { filter_values?: FilterValues }).filter_values
    if (values) {
      const restored = applyBookmarkFilters(dash, values, {
        pane: paneState,
        slicers: rawSlicers,
        sync: syncState,
      })
      setPaneState(restored.pane)
      setRawSlicers(restored.slicers)
      setSyncState(restored.sync)
    }
    nav.applyBookmark(bookmark)
  }

  const tabs = (
    <nav className="flex gap-1" aria-label="Pages">
      {nav.tabs.map((p) => (
        <button
          key={p.name}
          onClick={() => {
            nav.goToTab(p.name)
            setRawSlicers({})
          }}
          data-active={p.name === nav.pageName}
          className="rounded-[10px] px-3 py-1.5 text-xs font-semibold text-gray-400 hover:bg-white/10 hover:text-white data-[active=true]:bg-brand/20 data-[active=true]:text-brand"
        >
          {p.display_name}
        </button>
      ))}
    </nav>
  )

  const canvas = page && (
    <ThemeProvider value={dash.theme}>
      <PbiThemeContext.Provider value={theme}>
        <ReportContext.Provider value={{ conversionId, connectionId, apiConfig }}>
          <ReportActionsContext.Provider
            value={{
              bookmarks: dash.bookmarks,
              pages: dash.pages,
              currentPage: nav.pageName,
              applyBookmark,
              goToPage: (name) => nav.goToPage(name),
            }}
          >
            <PageCanvas
              page={page}
              results={data.data ?? {}}
              slicerState={slicerState}
              onSlicerChange={onSlicerChange}
              interactionState={interactionState}
              onInteractionChange={setInteractionState}
              visualInteractions={visualInteractions}
              verticalAlignment={dash.vertical_alignment}
              overrides={nav.overrides}
              onAction={nav.runAction}
              actionDisabled={(v) => actionCannotRun(v, page, dash)}
              filtersByVisual={filtersByVisual}
              onDrillMenu={onDrillMenu}
              onTooltip={onTooltip}
            />
            {menu && page && (
              <DrillMenu
                at={menu.at}
                targets={drillTargets(dash, menu.visual, page.name)}
                onClose={() => setMenu(null)}
                onDrill={(target) =>
                  drillTo(
                    target,
                    contextClauses(menu.visual, menu.point, filtersByVisual[menu.visual.name] ?? [], 'drillthrough'),
                  )
                }
              />
            )}
            {tip && tipPage && !menu && (
              <TooltipPage
                spec={dash}
                page={tipPage}
                context={contextClauses(tip.visual, tip.point, filtersByVisual[tip.visual.name] ?? [], 'tooltip')}
                paneState={paneState}
                at={tip.at}
                conversionId={conversionId}
                connectionId={connectionId}
                apiConfig={apiConfig}
              />
            )}
          </ReportActionsContext.Provider>
        </ReportContext.Provider>
      </PbiThemeContext.Provider>
    </ThemeProvider>
  )

  const errorBanner = data.isError && (
    <div role="alert" className="mb-3 rounded-xl border border-brand-red/20 bg-brand-red/5 p-3 text-sm text-brand-red">
      {data.error.message}
    </div>
  )
  const pane = showFiltersPane && page && (
    <FiltersPane
      key={page.name}
      spec={dash}
      page={page}
      state={paneState}
      onChange={setPaneState}
      onReset={() => setPaneState(resetPane(paneState, page.name))}
      conversionId={conversionId}
      connectionId={connectionId}
      apiConfig={apiConfig}
      drillClauses={drillClauses}
    />
  )

  if (standalone && apiConfig)
    return (
      <div data-testid="dashboard-root" className="flex h-screen flex-col overflow-hidden bg-surface-200">
        <StandaloneTopBar
          reportName={dash.report_name}
          session={session.data}
          authRequired={authRequired}
          fetching={data.isFetching}
          onSignInAgain={() => setPanelOpen(true)}
          onSettings={() => setPanelOpen(true)}
        >
          <ModeToggle
            conversionId={conversionId}
            connectionId={connectionId}
            mode={mode}
            onChange={setMode}
            apiConfig={apiConfig}
          />
          <BookmarksMenu bookmarks={dash.bookmarks} onApply={applyBookmark} />
        </StandaloneTopBar>
        <main className="flex min-h-0 flex-1">
          <div data-testid="canvas-column" className="min-w-0 flex-1 overflow-auto p-4">
            {errorBanner}
            {canvas}
          </div>
          {pane}
        </main>
        <PageTabs
          pages={dash.pages}
          current={nav.pageName}
          onSelect={(name) => {
            nav.goToTab(name)
            setRawSlicers({})
          }}
        />
        <ConnectionPanel
          config={apiConfig}
          open={panelOpen}
          session={session.data}
          onClose={() => setPanelOpen(false)}
          onSignedIn={signedIn}
        />
      </div>
    )

  if (compact)
    return (
      <div className="w-full">
        <div className="mb-2 flex flex-wrap items-center gap-2 rounded-lg bg-black px-3 py-2">
          {tabs}
          <div className="ml-auto flex items-center gap-2">
            <ModeToggle
              conversionId={conversionId}
              connectionId={connectionId}
              mode={mode}
              onChange={setMode}
              dark
              apiConfig={apiConfig}
            />
            <BookmarksMenu bookmarks={dash.bookmarks} onApply={applyBookmark} dark />
          </div>
        </div>
        {errorBanner}
        {canvas}
      </div>
    )

  return (
    <div data-testid="dashboard-root" className="flex h-screen flex-col overflow-hidden bg-surface-200">
      <header className="flex items-center justify-between border-b border-white/[0.08] bg-black px-6 py-3">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand to-brand-dark text-xs font-extrabold text-white">
            P
          </div>
          <div>
            <h1 className="text-sm font-bold text-white">{dash.report_name}</h1>
            <p className="text-[10px] text-white/50">
              Converted from Power BI · live on Snowflake
              {data.isFetching ? ' · refreshing…' : ''}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <ModeToggle
            conversionId={conversionId}
            connectionId={connectionId}
            mode={mode}
            onChange={setMode}
            dark
            apiConfig={apiConfig}
          />
          {tabs}
          <BookmarksMenu bookmarks={dash.bookmarks} onApply={applyBookmark} dark />
        </div>
      </header>
      <main className="flex min-h-0 flex-1">
        <div data-testid="canvas-column" className="min-w-0 flex-1 overflow-auto p-6">
          {errorBanner}
          {canvas}
        </div>
        {pane}
      </main>
    </div>
  )
}
