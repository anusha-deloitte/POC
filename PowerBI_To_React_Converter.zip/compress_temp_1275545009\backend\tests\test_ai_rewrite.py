"""AI repair order: DAX rewrite into tier-1 first, whole-model SQL last (phase 07)."""

from __future__ import annotations

import json

import pytest
from fastapi.testclient import TestClient

from app.agents import tier2
from app.agents.pipeline import (
    ConversionRun,
    _drop_other_provider_ai,
    _tier2_order,
    run_conversion,
)
from app.dax.compiler import DaxUnsupported, MeasureCompiler
from app.ir.model import DaxRewrite, Measure
from app.ir.report import Page, Report, ReportBundle, Visual, VisualField, VisualPosition
from app.runtime.dashboard import compile_dashboard
from tests.duck import DuckWorld
from tests.fakes import DuckCursor, ScriptedLLM

HARD = "SUMX(VALUES(Sales[Region]), CALCULATE(SUM(Sales[Amount])))"
GOOD = (
    "SUMX(FILTER(Sales, NOT(ISBLANK(Sales[Region]))), Sales[Amount]) + "
    "SUMX(FILTER(Sales, ISBLANK(Sales[Region])), Sales[Amount])"
)

ROWS = [(1, 1, "N", 10.0), (2, 1, "S", 5.0), (3, 2, None, 4.0)]


def make_world(extra: dict[str, str] | None = None, extra_tables=None) -> DuckWorld:
    tables = {
        "Sales": (["Id", "Key", "Region", "Amount"], ROWS),
        "Dim": (["Id", "Name"], [(1, "a"), (2, "b")]),
        **(extra_tables or {}),
    }
    return DuckWorld(
        tables,
        rels=[("Sales", "Key", "Dim", "Id")],
        measures={"Total": "SUM(Sales[Amount])", "Hard": HARD, **(extra or {})},
        measure_table="Sales",
    )


def make_bundle(world: DuckWorld, measures: list[str]) -> ReportBundle:
    visuals = [
        Visual(
            name=f"v{i}",
            visual_type="card",
            position=VisualPosition(x=0, y=0, width=10, height=10),
            fields=[VisualField(role="Values", table="Sales", name=m, is_measure=True)],
        )
        for i, m in enumerate(measures)
    ]
    return ReportBundle(
        source_path="x",
        model=world.model,
        report=Report(pages=[Page(name="p", display_name="P", visuals=visuals)]),
    )


def llm(rewrite="{}", sql='{"sql": "SELECT 1 AS RESULT"}') -> ScriptedLLM:
    def reply(messages):
        system = messages[0]["content"]
        text = rewrite if "rewrite one Power BI DAX" in system else sql
        return text(messages) if callable(text) else text

    return ScriptedLLM([reply])


def rewrite_only(model, bundle, world, client, measure="Hard", cursor=None):
    cursor = cursor or DuckCursor(world)
    from app.binding.resolver import build_bundle_binding_map

    bm = build_bundle_binding_map(bundle)
    found = model.find_measure(measure)[1]
    return tier2.propose_dax_rewrite(
        model,
        found,
        "needs tier-1",
        lambda candidate: tier2.rewrite_gate(bundle, candidate, bm, measure, cursor, {}),
        client,
    )


# ------------------------------------------------------------------ the rewrite itself


def test_accepted_rewrite_has_all_gates_and_compiles_at_tier1():
    w = make_world()
    bundle = make_bundle(w, ["Hard"])
    client = llm(json.dumps({"dax": GOOD}))
    result = rewrite_only(w.model, bundle, w, client)
    assert result.accepted and result.attempts == 1
    assert result.gates == [
        "parses; references only model objects",
        "keeps all 2 columns / 1 tables the original reads",
        "compiles in tier-1 (follows slicers and visual rows)",
        "executed for 1 visual and totals queries",
    ]
    candidate = w.model.model_copy(deep=True)
    candidate.dax_rewrites["Hard"] = DaxRewrite(expression=result.expression, original=HARD)
    assert MeasureCompiler(candidate).compile_measure("Hard").tier >= 0


def test_rewrite_dropping_a_column_is_rejected_and_retried():
    w = make_world()
    bundle = make_bundle(w, ["Hard"])
    replies = iter([json.dumps({"dax": "SUM(Sales[Amount])"}), json.dumps({"dax": GOOD})])
    client = ScriptedLLM([lambda m: next(replies)])
    result = rewrite_only(w.model, bundle, w, client)
    assert result.accepted and result.attempts == 2
    assert "dropped column Sales[Region]" in result.trace[0]
    assert "keep" in client.calls[1][-1]["content"].lower()


def test_unknown_objects_are_rejected():
    w = make_world()
    bundle = make_bundle(w, ["Hard"])
    client = ScriptedLLM([json.dumps({"dax": "SUM(Sales[Nope])"})])
    result = rewrite_only(w.model, bundle, w, client)
    assert not result.accepted and result.attempts == 3
    assert "unknown objects: column Sales[Nope]" in result.trace[0]


def test_tier1_failure_is_retried():
    w = make_world()
    bundle = make_bundle(w, ["Hard"])
    replies = iter(
        [
            json.dumps({"dax": 'CONCATENATEX(Sales, Sales[Region], ",") & SUM(Sales[Amount])'}),
            json.dumps({"dax": GOOD}),
        ]
    )
    result = rewrite_only(w.model, bundle, w, ScriptedLLM([lambda m: next(replies)]))
    assert result.accepted and result.attempts == 2
    assert "tier-1 compiler rejected it" in result.trace[0]


def test_gate_failure_is_retried():
    w = make_world()
    bundle = make_bundle(w, ["Hard"])
    cursor = DuckCursor(w, fail_when=lambda sql, nth: "IS NULL" in sql and nth == 1)
    result = rewrite_only(w.model, bundle, w, llm(json.dumps({"dax": GOOD})), cursor=cursor)
    assert result.accepted and result.attempts == 2
    assert "execution gate failed" in result.trace[0]


def test_declared_impossible_and_unparseable_replies():
    w = make_world()
    bundle = make_bundle(w, ["Hard"])
    result = rewrite_only(w.model, bundle, w, ScriptedLLM(['{"error": "no exact rewrite"}']))
    assert not result.accepted and "declared impossible" in result.trace[0]
    result2 = rewrite_only(w.model, bundle, w, ScriptedLLM(["not json at all"]))
    assert not result2.accepted and result2.attempts == 3


# ------------------------------------------------------------------ analysis helpers


def test_reference_analysis():
    w = make_world(
        {
            "Uses": "IF(ISFILTERED(Sales[Region]), [Hard], 0) + [Missing]",
            "Plain": "[Total] * 2",
        }
    )
    m = w.model
    assert tier2.measure_references(m, "Uses") == ["Hard", "Missing"]
    assert tier2.undefined_measures(m) == {"Missing": ["Uses"]}
    assert tier2.context_functions(m, "Uses") == ["ISFILTERED", "VALUES"]
    assert tier2.dependency_closure(m, "Plain") == ["Total"]
    refs = tier2.reference_closure(m, "Plain")
    assert refs["tables"] == {"Sales"} and ("Sales", "Amount") in refs["columns"]
    # a bracket that names a column or a string literal of the expression is not an undefined measure
    w2 = make_world({"Lit": 'IF(1 = 1, "[Region]", 0) + [Region]'})
    assert tier2.undefined_measures(w2.model) == {}


def test_tier2_order_puts_dependencies_first():
    w = make_world({"A": "CONCATENATEX(Sales, Sales[Region], \",\")", "B": "[A] & \"x\"", "C": "[B]"})
    order = _tier2_order(w.model, ["C", "B", "A"])
    assert order == ["A", "B", "C"]


# ------------------------------------------------------------------ through the pipeline


def run(world, bundle, tmp_path, client, **kwargs):
    (tmp_path / "bundle.json").write_text(bundle.model_dump_json(), encoding="utf-8")
    cursor_kwargs = kwargs.pop("cursor_kwargs", {})
    return run_conversion(
        bundle,
        "conv",
        tmp_path,
        lambda: DuckCursor(world, **cursor_kwargs),
        llm_client=client,
        llm_provider=kwargs.pop("llm_provider", "cortex"),
        **kwargs,
    )


def test_pipeline_stores_accepted_rewrite_with_provider_and_it_survives_recompile(tmp_path):
    w = make_world()
    bundle = make_bundle(w, ["Total", "Hard"])
    client = llm(json.dumps({"dax": GOOD}))
    result = run(w, bundle, tmp_path, client)
    rewrite = bundle.model.dax_rewrites["Hard"]
    assert rewrite.expression == GOOD and rewrite.original == HARD
    assert rewrite.provider == "cortex" and len(rewrite.gates) == 4 and rewrite.created_at > 0
    assert result.spec.measure_tiers["Hard"] >= 0
    messages = [e["message"] for e in result.events if e["stage"] == "repair"]
    assert any("[Hard]: AI rewrite accepted after 1 attempt(s)" in m for m in messages)
    saved = json.loads((tmp_path / "bundle.json").read_text())["model"]["dax_rewrites"]
    assert saved["Hard"]["expression"] == GOOD
    spec, _ = compile_dashboard(bundle)
    assert spec.measure_tiers["Hard"] >= 0


def test_pipeline_logs_events_preflight_and_compilation_audit(tmp_path):
    w = make_world()
    bundle = make_bundle(w, ["Total", "Hard"])
    result = run(w, bundle, tmp_path, llm(json.dumps({"dax": GOOD})))
    stages = [e["stage"] for e in result.events]
    assert "preflight" in stages
    pre = next(e for e in result.events if e["stage"] == "preflight")
    assert "tables reachable with role ANALYST" in pre["message"]
    compile_event = next(e for e in result.events if "compilation_audit" in e)
    assert compile_event["compilation_audit"]["total"] >= 2
    assert (tmp_path / "compilation_logs" / "conv_compilation.jsonl").is_file()
    assert result.preflight and result.preflight["accessible"] >= 1
    persisted = json.loads((tmp_path / "conversion_run.json").read_text())
    assert persisted["preflight"] is not None and persisted["llm_provider"] == "cortex"
    case = next(e for e in result.events if e["message"].startswith("identifier case:"))
    assert "match Snowflake exactly" in case["message"]


def test_rewrite_failure_falls_back_to_whole_model_sql(tmp_path):
    w = make_world({"Joined": 'CONCATENATEX(Sales, Sales[Region], ",")'})
    bundle = make_bundle(w, ["Total", "Joined"])
    client = llm(json.dumps({"dax": "SUM(Sales[Amount])"}), sql='{"sql": "SELECT 27 AS RESULT"}')
    result = run(w, bundle, tmp_path, client)
    assert "Joined" not in bundle.model.dax_rewrites
    assert result.tier2_accepted["Joined"] == "SELECT 27 AS RESULT"
    # a measure that reads the filter context (VALUES) is never sent for a whole-model value
    assert "Hard" not in result.tier2_accepted


def test_context_function_measures_are_never_sent_for_whole_model_sql(tmp_path):
    w = make_world(
        {"Ctx": "IF(ISFILTERED(Sales[Region]), CONCATENATEX(Sales, Sales[Region], \",\"), 0)"}
    )
    bundle = make_bundle(w, ["Total", "Ctx"])
    sql_requests: list[str] = []

    def sql_reply(messages):
        sql_requests.append(messages[1]["content"])
        return '{"sql": "SELECT 1 AS RESULT"}'

    client = llm('{"error": "no exact rewrite"}', sql=sql_reply)
    result = run(w, bundle, tmp_path, client)
    assert "Ctx" not in result.tier2_accepted
    assert not any("[Ctx]" in req for req in sql_requests)
    assert any(
        "reads the filter context (ISFILTERED)" in e["message"]
        for e in result.events
        if e["stage"] == "repair"
    )


def test_undefined_measure_and_unreachable_table_are_not_sent(tmp_path):
    w = make_world(
        {
            "Undef": "[Nope] + CONCATENATEX(Sales, Sales[Region], \",\")",
            "Hidden": "CONCATENATEX(Secret, Secret[X], \",\")",
        },
        extra_tables={"Secret": (["X"], [("a",)])},
    )
    bundle = make_bundle(w, ["Total", "Undef", "Hidden"])
    client = llm('{"error": "no"}')
    result = run(w, bundle, tmp_path, client, cursor_kwargs={"omit_tables": ["Secret"]})
    messages = [e["message"] for e in result.events if e["stage"] == "repair"]
    assert any(
        "the uploaded model references measures it does not define: [Nope]" in m for m in messages
    )
    assert any(
        "[Undef]: not sent to AI — it references [Nope], which is not defined" in m for m in messages
    )
    assert any(
        "[Hidden]: not sent to AI — it reads Secret, which the Snowflake session cannot reach" in m
        for m in messages
    )
    assert not any("[Hidden]" in c[1]["content"] for c in client.calls)


def test_dependency_rejected_skips_dependants_and_order_is_respected(tmp_path):
    w = make_world(
        {
            "Base": "CONCATENATEX(Sales, Sales[Region], \",\")",
            "Top": "[Base] & \"x\"",
        }
    )
    bundle = make_bundle(w, ["Total", "Top"])
    asked: list[str] = []

    def rewrite_reply(messages):
        asked.append(messages[1]["content"].split("\n")[0])
        return '{"error": "no"}'

    result = run(
        w, bundle, tmp_path, llm(rewrite_reply, sql='{"error": "no"}'), ai_scope="all"
    )
    messages = [e["message"] for e in result.events if e["stage"] == "repair"]
    assert any("[Top]: skipped AI translation — depends on [Base]" in m for m in messages)
    assert any("Base" in a for a in asked) and not any("Measure [Top]" in a for a in asked)


def test_scope_visuals_leaves_unused_measures_for_review(tmp_path):
    w = make_world({"Unused": "CONCATENATEX(Sales, Sales[Region], \",\")"})
    bundle = make_bundle(w, ["Total"])
    client = llm('{"error": "no"}')
    result = run(w, bundle, tmp_path, client)
    assert any(
        "untranslated measures are not used by any visual" in e["message"]
        for e in result.events
    )
    assert client.calls == []


def test_blocking_preflight_skips_ai(tmp_path):
    w = make_world()
    bundle = make_bundle(w, ["Total", "Hard"])
    client = llm(json.dumps({"dax": GOOD}))
    result = run(w, bundle, tmp_path, client, cursor_kwargs={"catalog_error": True})
    assert client.calls == []
    assert any("skipping AI translation of" in e["message"] for e in result.events)


def test_llm_error_parks_the_measure_and_the_run_continues(tmp_path):
    from app.services.llm_errors import LlmError

    w = make_world()
    bundle = make_bundle(w, ["Total", "Hard"])

    class Boom:
        label = "Cortex (m)"

        def chat(self, messages, **kw):
            raise LlmError("gateway down")

    result = run(w, bundle, tmp_path, Boom())
    messages = [e["message"] for e in result.events if e["stage"] == "repair"]
    assert any("[Hard]: AI translation unavailable — measure parked, needs assistance" in m for m in messages)
    assert result.events[-1]["stage"] == "report"


def test_rejected_round_reverts_its_rewrites(tmp_path, monkeypatch):
    from app.agents import pipeline
    from app.validation.harness import FidelityReport, PageScore, VisualScore, Check, CheckStatus

    w = make_world()
    bundle = make_bundle(w, ["Total", "Hard"])
    real = pipeline.run_validation
    calls = {"n": 0}

    def fake_validation(*args, **kwargs):
        report = real(*args, **kwargs)
        calls["n"] += 1
        if calls["n"] == 2:  # the re-validation after the rewrite regresses
            report = FidelityReport(
                report_name="r",
                pages=[
                    PageScore(
                        page="p",
                        display_name="P",
                        visuals=[
                            VisualScore(
                                visual="v",
                                page="p",
                                visual_type="card",
                                checks=[Check(name="execute", status=CheckStatus.FAILED)],
                            )
                        ],
                    )
                ],
            )
        return report

    monkeypatch.setattr(pipeline, "run_validation", fake_validation)
    result = run(w, bundle, tmp_path, llm(json.dumps({"dax": GOOD})))
    assert "Hard" not in bundle.model.dax_rewrites
    messages = [e["message"] for e in result.events if e["stage"] == "repair"]
    assert any("REJECTED - score regressed" in m for m in messages)
    assert any("reverted 1 AI DAX rewrites from the rejected round" in m for m in messages)
    saved = json.loads((tmp_path / "bundle.json").read_text())["model"]["dax_rewrites"]
    assert saved == {}


def test_provider_switch_drops_ai_rewrites_and_sql(tmp_path):
    w = make_world()
    bundle = make_bundle(w, ["Total"])
    bundle.model.dax_rewrites["Hard"] = DaxRewrite(expression=GOOD, original=HARD, source="ai")
    bundle.model.dax_rewrites["Manual"] = DaxRewrite(expression="1", original="2", source="user")
    (tmp_path / "bundle.json").write_text(bundle.model_dump_json(), encoding="utf-8")
    run_state = ConversionRun(conversion_id="c", tier2_accepted={"X": "select 1"})
    _drop_other_provider_ai(run_state, bundle, tmp_path, {"llm_provider": "horizon"}, "cortex")
    assert list(bundle.model.dax_rewrites) == ["Manual"] and run_state.tier2_accepted == {}
    assert "1 AI DAX rewrite(s) dropped" in run_state.events[-1]["message"]


# ------------------------------------------------------------------ API


@pytest.fixture()
def api(tmp_path, monkeypatch, contoso_pbip):
    from app.api.deps import get_ingest_service
    from app.main import app
    from app.services.ingest import IngestService

    svc = IngestService(tmp_path / "storage")
    monkeypatch.setattr("app.api.dashboards.get_ingest_service", lambda: svc)
    app.dependency_overrides[get_ingest_service] = lambda: svc
    with TestClient(app) as c:
        yield c, svc
    app.dependency_overrides.clear()


def test_dax_rewrite_endpoints(api, contoso_pbip):
    c, svc = api
    stored = svc.ingest_folder(contoso_pbip)
    bundle = svc.load_bundle(stored.id)
    bundle.model.dax_rewrites["Zed"] = DaxRewrite(expression="1", original="2", gates=["g"])
    bundle.model.dax_rewrites["Alpha"] = DaxRewrite(expression="3", original="4")
    svc.save_bundle(stored.id, bundle)
    base = f"/api/v1/conversions/{stored.id}/dashboard/dax-rewrites"
    listed = c.get(base).json()["rewrites"]
    assert list(listed) == ["Alpha", "Zed"] and listed["Zed"]["gates"] == ["g"]
    gone = c.delete(f"{base}/Zed")
    assert gone.json() == {"reverted": "Zed", "remaining": ["Alpha"]}
    assert "Zed" not in svc.load_bundle(stored.id).model.dax_rewrites
    missing = c.delete(f"{base}/Zed")
    assert missing.status_code == 404 and "no AI rewrite for measure 'Zed'" in missing.text


def test_measure_object_is_unused_import_guard():
    assert Measure and DaxUnsupported
