/** The data point under the pointer: what drill-through and report-page tooltips are keyed on. */
import { createContext, useContext } from 'react'
import type { VisualSpec } from './types'

/** `"Table.Column"` -> the value (NULL kept). An empty point means the whole container. */
export type DataPoint = Record<string, string | number | null>

/** Set by PageCanvas around each visual; visuals report the point under the pointer and null when
 * the pointer leaves it. */
export type ReportPoint = (point: DataPoint | null) => void
export const DataPointContext = createContext<ReportPoint>(() => undefined)
export const useReportPoint = (): ReportPoint => useContext(DataPointContext)

/** The point of a chart item: its category (the first dim key that isn't a series key; nested
 * category axes report their first level only; empty names are skipped) and its series. */
export function chartPoint(
  spec: Pick<VisualSpec, 'dim_keys' | 'series_keys'>,
  name: string | null | undefined,
  seriesName?: string | null,
): DataPoint {
  const point: DataPoint = {}
  const seriesKeys = spec.series_keys ?? []
  const category = spec.dim_keys.find((k) => !seriesKeys.includes(k))
  if (category && name !== undefined && name !== null && name !== '') point[category] = name
  const series = seriesKeys[0]
  if (series && seriesName !== undefined && seriesName !== null && seriesName !== '') point[series] = seriesName
  return point
}

/** The point of a table / matrix row: every dim key present in the result (NULL kept). */
export function rowPoint(
  spec: Pick<VisualSpec, 'dim_keys'>,
  columns: string[],
  row: (string | number | null)[],
): DataPoint {
  const point: DataPoint = {}
  for (const key of spec.dim_keys) {
    const i = columns.indexOf(key)
    if (i >= 0) point[key] = row[i] ?? null
  }
  return point
}
