import type { EChartsOption } from 'echarts'
import * as echarts from 'echarts'
import { useEffect, useState } from 'react'
import { formatValue } from '../format'
import { resolveVisual, usePbiTheme } from '../pbi/resolve'
import { usePalette, useThemeTokens } from '../theme'
import type { VisualResult, VisualSpec } from '../types'
import { EChart } from './EChart'
import { albersUsa, albersUsaInverse, gradientColor, gradientStops, stateName } from './mapUtil'

let usMapRegistered = false
async function ensureUsMap(): Promise<void> {
  if (usMapRegistered) return
  const geo = await (await fetch('/us-states.geo.json')).json()
  // 50 states + DC (no territories); matching is by canonical state name
  geo.features = (geo.features ?? []).filter((f: { properties?: { name?: string } }) => stateName(f.properties?.name))
  echarts.registerMap('USA', geo)
  usMapRegistered = true
}

const SATURATION_ROLES = ['Color', 'Value', 'Values', 'Y', 'Size']

/** The measure that colours the map: the Value / Color saturation role, not the first tooltip
 * projection. */
export function mapValueKey(spec: VisualSpec): string | undefined {
  for (const role of SATURATION_ROLES) {
    const key = spec.measure_keys.find((k) => spec.measure_roles[k] === role)
    if (key) return key
  }
  return spec.measure_keys.find((k) => spec.measure_roles[k] !== 'Tooltips') ?? spec.measure_keys[0]
}

function displayName(spec: VisualSpec, key: string): string {
  const f = spec.pbir?.fields.find((x) => x.name === key || x.display_name === key || x.query_ref === key)
  return f?.display_name ?? key
}

/** Power BI filled map: ECharts choropleth over US states with an albersUsa projection. */
function PbiMap({
  spec,
  data,
  selected = [],
  onSelect,
}: {
  spec: VisualSpec
  data: VisualResult
  selected?: (string | number)[]
  onSelect?: (values: (string | number)[]) => void
}) {
  const style = resolveVisual(spec, usePbiTheme())
  const dimKey = spec.dim_keys[0]
  const mKey = mapValueKey(spec)
  const di = data.columns.indexOf(dimKey)
  const mi = mKey ? data.columns.indexOf(mKey) : -1
  const originals = new Map<string, string | number>() // canonical state -> value in the data
  const points: { name: string; value: number | null }[] = []
  for (const r of data.rows) {
    const name = stateName(r[di])
    if (!name) continue // "Not Mapped" and friends are not drawn
    originals.set(name, r[di] as string | number)
    const raw = mi >= 0 ? r[mi] : null
    const value = raw === null || raw === undefined ? null : Number(raw)
    points.push({ name, value: value === null && style.map.nullAsZero ? 0 : value })
  }
  const values = points.map((p) => p.value).filter((v): v is number => v !== null)
  const gradient = style.map.gradient ?? { min: '#E6EEF7', max: style.palette[0] }
  const stops = gradientStops(gradient, values.length ? values : [0])
  const picked = new Set(selected.map((s) => stateName(s) ?? String(s)))
  const fmt = spec.measure_formats[mKey ?? '']
  const option: EChartsOption = {
    animation: false,
    tooltip: {
      formatter: (p) => {
        const item = p as { name: string; value?: number }
        const v = item.value
        return `<b>${item.name}</b><br/>${displayName(spec, mKey ?? '')}: ${
          v !== undefined && Number.isFinite(v) ? formatValue(v, fmt) : '—'
        }`
      },
    },
    series: [
      {
        type: 'map',
        map: 'USA',
        roam: false,
        // albersUsa: lower 48 plus Alaska / Hawaii insets, in a 960 x 500 box
        projection: { project: (pt: number[]) => albersUsa(pt[0], pt[1]), unproject: (pt: number[]) => albersUsaInverse(pt[0], pt[1]) },
        selectedMode: 'multiple',
        itemStyle: { areaColor: style.map.defaultFill, borderColor: style.map.borderColor },
        emphasis: { label: { show: false } },
        select: { label: { show: false } },
        data: points.map((p) => ({
          name: p.name,
          value: p.value ?? undefined,
          selected: picked.has(p.name),
          itemStyle: {
            areaColor: p.value === null ? style.map.defaultFill : gradientColor(gradient, stops, p.value),
            opacity: picked.size && !picked.has(p.name) ? 0.55 : 1,
          },
        })),
      },
    ],
  }
  return (
    <EChart
      option={option}
      onItemClick={(name) => {
        if (!onSelect) return
        const value = originals.get(name) ?? name
        const current = selected.map(String)
        onSelect(current.includes(String(value)) ? selected.filter((s) => String(s) !== String(value)) : [...selected, value])
      }}
    />
  )
}

/** filledMap -> ECharts choropleth over public-domain US states GeoJSON.
 *  Clicking a state cross-filters the page (PBI parity); click again clears. */
export function MapVisual({
  spec,
  data,
  selected = [],
  onSelect,
}: {
  spec: VisualSpec
  data?: VisualResult
  selected?: (string | number)[]
  onSelect?: (values: (string | number)[]) => void
}) {
  const palette = usePalette()
  const theme = useThemeTokens()
  const [ready, setReady] = useState(usMapRegistered)
  useEffect(() => {
    ensureUsMap().then(() => setReady(true))
  }, [])

  if (!data || !ready) return <div className="p-2 text-xs text-surface-400">…</div>
  if (data.error) return <div className="p-2 text-xs text-brand-red">{data.error}</div>
  if (spec.pbir) return <PbiMap spec={spec} data={data} selected={selected} onSelect={onSelect} />

  const dimKey = spec.dim_keys[0]
  const mKey = spec.measure_keys[0]
  const di = data.columns.indexOf(dimKey)
  const mi = data.columns.indexOf(mKey)
  const rows = data.rows
    .filter((r) => r[di] !== null)
    .map((r) => ({
      name: String(r[di]),
      value: Number(r[mi] ?? 0),
      selected: selected.includes(String(r[di])),
    }))
  const values = rows.map((r) => r.value)
  const fmt = spec.measure_formats[mKey]
  const hasSelection = selected.length > 0

  const option: EChartsOption = {
    tooltip: {
      formatter: (p) => {
        const item = p as { name: string; value: number }
        return `<b>${item.name}</b><br/>${mKey}: ${
          Number.isFinite(item.value) ? formatValue(item.value, fmt) : '—'
        }`
      },
      backgroundColor: theme.tooltipBackground,
      borderColor: theme.panelBorder,
      textStyle: { color: theme.tooltipText, fontFamily: theme.fontFamily, fontSize: 11 },
    },
    visualMap: {
      min: Math.min(...values),
      max: Math.max(...values),
      inRange: { color: ['#e6eef7', palette[0], palette[1] ?? palette[0]] },
      calculable: false,
      orient: 'horizontal',
      left: 'center',
      bottom: 0,
      itemHeight: 60,
      textStyle: { fontSize: 8 },
      formatter: (v) => formatValue(v as number, fmt),
    },
    series: [
      {
        type: 'map',
        map: 'USA',
        roam: false,
        // continental-US focus
        center: [-96, 38.5],
        zoom: 1.15,
        selectedMode: 'multiple',
        select: {
          label: { show: false },
          itemStyle: { areaColor: '#E66C37', borderColor: '#b45309', borderWidth: 1.5 },
        },
        emphasis: { label: { show: false }, itemStyle: { areaColor: '#E66C37' } },
        itemStyle: {
          borderColor: '#fff',
          areaColor: '#eef2f7',
          opacity: hasSelection ? 0.55 : 1,
        },
        data: rows,
      },
    ],
  }
  return (
    <EChart
      option={option}
      onItemClick={(name) => {
        if (!onSelect) return
        // toggle: click selected state again to clear it
        onSelect(
          selected.includes(name) ? selected.filter((s) => s !== name) : [...selected, name],
        )
      }}
    />
  )
}
