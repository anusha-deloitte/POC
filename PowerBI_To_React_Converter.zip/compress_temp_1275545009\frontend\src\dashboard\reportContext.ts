import { createContext, useContext } from 'react'
import type { DashboardApiConfig } from './api'
import type { Bookmark, PageSpec } from './types'

export interface ReportContextValue {
  conversionId: string
  connectionId?: string
  apiConfig?: DashboardApiConfig
}

export const ReportContext = createContext<ReportContextValue>({ conversionId: '' })
export const useReport = (): ReportContextValue => useContext(ReportContext)

/** What bookmark / page navigators can do. */
export interface ReportActions {
  bookmarks: Bookmark[]
  pages: PageSpec[]
  currentPage?: string
  applyBookmark: (bookmark: Bookmark) => void
  goToPage: (name: string) => void
}

export const ReportActionsContext = createContext<ReportActions>({
  bookmarks: [],
  pages: [],
  applyBookmark: () => undefined,
  goToPage: () => undefined,
})
export const useReportActions = (): ReportActions => useContext(ReportActionsContext)
