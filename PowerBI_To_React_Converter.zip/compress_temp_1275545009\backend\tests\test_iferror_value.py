"""IFERROR over VALUE(<slicer's selected text>) (phase 06.8)."""

from __future__ import annotations

import pytest

from app.dax.compiler import DaxUnsupported, MeasureCompiler
from app.runtime.engine import FilterClause, QueryPlanError
from tests.duck import DuckWorld

VAL = (
    'VAR s = TRIM(SELECTEDVALUE(Sel[Text])) '
    'RETURN IF(s = "All", 0, IFERROR(VALUE(s), -1))'
)


def world(extra=None) -> DuckWorld:
    return DuckWorld(
        {"Sel": (["Text"], [("10",), ("20",), ("All",), ("abc",)])},
        measures={"Val": VAL, **(extra or {})},
    )


def pick(*vals):
    return [FilterClause(table="Sel", column="Text", values=list(vals))]


def test_translates_and_computes_the_number():
    assert world().value("Val", filters=pick("10")) == 10


def test_offending_selection_returns_the_fallback():
    assert world().value("Val", filters=pick("abc")) == -1


def test_compared_literal_takes_its_own_branch():
    assert world().value("Val", filters=pick("All")) == 0


def test_no_single_selection_takes_no_fallback():
    # several values selected: SELECTEDVALUE is BLANK, VALUE(BLANK) is BLANK, not an error
    assert world().value("Val", filters=pick("10", "20")) is None
    assert world().value("Val") is None


def test_value_outside_a_slicer_selection_is_refused():
    w = world({"Bad": "IFERROR(VALUE(MAX(Sel[Text])), 0)"})
    with pytest.raises((DaxUnsupported, QueryPlanError), match="IFERROR"):
        w.value("Bad")


def test_assumption_is_recorded_with_the_compared_literals():
    w = world()
    cm = MeasureCompiler(w.model).compile_measure("Val")
    assert cm.value_assumptions == [("Sel", "Text", ("All",))]


def test_iferror_without_raise_risk_compiles_to_the_value():
    w = world({"Safe": "IFERROR(COUNTROWS(Sel), 0)"})
    assert w.value("Safe") == 4
