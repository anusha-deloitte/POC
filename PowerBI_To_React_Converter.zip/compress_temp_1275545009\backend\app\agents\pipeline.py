"""Conversion pipeline: Binding -> Compile -> Validate -> Repair -> Report.

A deterministic state machine with agent stages; every stage emits events to
a persisted JSON log (the live event feed in the Studio and the audit trace).
RepairAgent is bounded (max 3 rounds) and monotonic: a repair is kept only if
the overall fidelity score does not regress.

AI repair order (safest first): a parked measure is first rewritten into tier-1 DAX (checked by
gates
that run it on every visual using it), and only if that fails - and the measure does not read the
filter context - translated into whole-model SQL. Measures that cannot possibly be validated (they
reference undefined measures or unreachable tables, or depend on a rejected measure) are not sent.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path

from app.binding.case_check import case_summary_message, correct_bundle_case
from app.binding.preflight import run_preflight
from app.binding.resolver import build_bundle_binding_map
from app.core.logging import append_jsonl
from app.dax.compiler import DaxUnsupported, MeasureCompiler
from app.ir.model import DaxRewrite
from app.ir.report import ReportBundle
from app.runtime.dashboard import DashboardSpec, compile_dashboard
from app.runtime.engine import MeasureRefSpec, QuerySpec, SemanticEngine
from app.services.compilation_logger import CompilationLogger
from app.services.llm_errors import LlmError
from app.services.query_audit import audit_stage
from app.validation.harness import (
    CachingCursor,
    CheckStatus,
    FidelityReport,
    run_filter_probes,
    run_validation,
    with_default_filters,
)
from app.validation.value_check import run_value_check

_MAX_REPAIR_ROUNDS = 3


@dataclass
class ConversionRun:
    conversion_id: str
    events: list[dict] = field(default_factory=list)
    spec: DashboardSpec | None = None
    fidelity: FidelityReport | None = None
    tier2_accepted: dict[str, str] = field(default_factory=dict)  # measure -> sql
    llm_provider: str | None = None  # provider that produced the AI work (cortex | horizon)
    preflight: dict | None = None  # PreflightReport.summary()
    # Phase-8: track which stages have completed for resume-on-failure
    stages_complete: dict[str, bool] = field(default_factory=dict)
    # progressive sink: called after every emit so the Studio can stream the log live
    on_emit: object = None
    # append-only durable trace for troubleshooting (conversion_run.json is
    # overwritten wholesale on every run; this file keeps every run's history)
    log_path: Path | None = None

    def emit(self, stage: str, message: str, **data) -> None:
        self.events.append(
            {"ts": round(time.time(), 3), "stage": stage, "message": message, **data}
        )
        if self.on_emit is not None:
            self.on_emit(self.events)  # type: ignore[operator]
        if self.log_path is not None:
            append_jsonl(
                self.log_path,
                "pipeline_stage",
                conversion_id=self.conversion_id,
                stage=stage,
                message=message,
                **data,
            )

    def stage_done(self, stage: str) -> bool:
        return self.stages_complete.get(stage, False)

    def mark_stage(self, stage: str) -> None:
        self.stages_complete[stage] = True


def _progress_writer(root: Path):
    """Persist the running event list so GET /convert/progress can stream it."""
    path = root / "conversion_progress.json"

    def write(events: list[dict], done: bool = False) -> None:
        path.write_text(
            json.dumps({"events": events, "done": done}, default=str), encoding="utf-8"
        )

    return write


def _persist(run: ConversionRun, root: Path) -> None:
    (root / "conversion_run.json").write_text(
        json.dumps(
            {
                "events": run.events,
                "fidelity": run.fidelity.model_dump() if run.fidelity else None,
                "summary": run.fidelity.summary() if run.fidelity else None,
                "tier2_accepted": run.tier2_accepted,
                "llm_provider": run.llm_provider,
                "preflight": run.preflight,
                # Phase-8: stage completion map for resume support
                "stages_complete": run.stages_complete,
            },
            indent=2,
            default=str,
        ),
        encoding="utf-8",
    )


def _load_existing_run(root: Path) -> dict:
    """Load a persisted conversion_run.json if it exists."""
    path = root / "conversion_run.json"
    if not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save_bundle(bundle: ReportBundle, root: Path) -> None:
    """Every later compile reads bundle.json, so rewrites and case fixes are persisted there."""
    path = root / "bundle.json"
    if path.is_file():
        path.write_text(bundle.model_dump_json(indent=2), encoding="utf-8")


def _drop_other_provider_ai(
    run: ConversionRun,
    bundle: ReportBundle,
    root: Path,
    prior: dict,
    provider: str | None,
) -> None:
    """AI work from the other provider is not trusted: drop it so it is translated again."""
    if not provider or not prior:
        return
    previous = prior.get("llm_provider") or "horizon"
    if previous == provider:
        return
    sql_dropped = len(run.tier2_accepted)
    run.tier2_accepted = {}
    rewrites = getattr(bundle.model, "dax_rewrites", None) or {}
    ai_keys = [
        k
        for k, v in rewrites.items()
        if (v.get("source") if isinstance(v, dict) else getattr(v, "source", None)) == "ai"
    ]
    for k in ai_keys:
        del rewrites[k]
    if ai_keys:
        (root / "bundle.json").write_text(bundle.model_dump_json(indent=2), encoding="utf-8")
    run.emit(
        "pipeline",
        f"AI provider changed from {previous} to {provider}: {sql_dropped} AI SQL "
        f"translation(s) and {len(ai_keys)} AI DAX rewrite(s) dropped, translating again",
    )


def _compile_with_overrides(
    bundle: ReportBundle,
    storage_root: Path,
    tier2_sql: dict[str, str],
    compilation_log: CompilationLogger | None = None,
):
    """Compile and apply persisted spec overrides — the pipeline must validate
    the same spec the dashboard will serve (repairs land as overrides)."""
    from app.services.overrides import apply_overrides, load_overrides

    spec, binding_map = compile_dashboard(
        bundle, tier2_sql=tier2_sql, compilation_log=compilation_log
    )
    overrides = load_overrides(storage_root)
    if overrides:
        spec.warnings.extend(apply_overrides(spec, overrides))
    return spec, binding_map


# --------------------------------------------------------------------------- repair helpers


def _visual_measures(bundle: ReportBundle) -> set[str]:
    """Measures a visual field projects (canonical names)."""
    out: set[str] = set()
    for page in bundle.report.pages:
        for visual in page.visuals:
            for f in visual.fields:
                if f.is_measure and f.name:
                    found = bundle.model.find_measure(f.name)
                    out.add(found[1].name if found else f.name)
    return out


def _tier2_order(model, candidates: list[str]) -> list[str]:
    """Dependencies before dependants (DFS over the dependency closure, sorted start)."""
    from app.agents.tier2 import dependency_closure

    wanted = set(candidates)
    ordered: list[str] = []
    visiting: set[str] = set()

    def visit(name: str) -> None:
        if name in ordered or name in visiting:
            return
        visiting.add(name)
        for dep in sorted(dependency_closure(model, name)):
            if dep in wanted:
                visit(dep)
        visiting.discard(name)
        ordered.append(name)

    for name in sorted(candidates):
        visit(name)
    return ordered


def _unreachable_tables(binding_map, preflight: dict | None) -> set[str]:
    """Model tables the pre-flight found unreachable: the schema failed to list, or it listed but
    this exact name is not among the tables found."""
    if not preflight:
        return set()
    targets = {
        (t["database"], t["schema_name"]): t for t in preflight.get("targets", [])
    }
    out: set[str] = set()
    for b in binding_map.bindings.values():
        target = targets.get((b.database or "", b.schema_name or ""))
        if target is None or not b.object_name:
            continue
        if target.get("error") or (
            target.get("listed", 0) > 0 and b.object_name not in target.get("found", [])
        ):
            out.add(b.table)
    return out


def _dependency_sql(model, measure: str, run: ConversionRun, engine, cache: dict) -> dict[str, str]:
    """Accepted tier-2 SQL of dependencies, else their tier-1 SQL built as standalone cards."""
    from app.agents.tier2 import dependency_closure

    out: dict[str, str] = {}
    for dep in dependency_closure(model, measure):
        if dep in run.tier2_accepted:
            out[dep] = run.tier2_accepted[dep]
            continue
        if dep not in cache:
            try:
                cache[dep] = engine.build_sql(
                    QuerySpec(measures=[MeasureRefSpec(name=dep)]),
                    sql_context="tier2_dependency_context",
                )[0]
            except Exception:  # noqa: BLE001 - a dependency without SQL is simply omitted
                cache[dep] = ""
        if cache[dep]:
            out[dep] = cache[dep]
    return out


def _manual_sql(
    run: ConversionRun, spec: DashboardSpec, engine, root: Path, quiet: bool = False
) -> dict:
    """Hand-edited SQL of untranslated panes (sql_overrides.json), rendered with only the default
    report/page filters. {(page, visual): sql}."""
    try:
        from app.services.sql_overrides import load_overrides as load_sql_overrides
        from app.services.sql_overrides import render as render_sql
    except ImportError:
        return {}
    overrides = load_sql_overrides(root)
    out: dict = {}
    for page in spec.pages:
        for vs in page.visuals:
            override = overrides.get(f"{page.name}/{vs.name}")
            if not override or vs.data_status != "untranslated":
                continue
            try:
                from app.runtime.filter_cards import default_filter_clauses

                sql, _unapplied = render_sql(
                    override["sql"], default_filter_clauses(spec, page), engine
                )
            except Exception as e:  # noqa: BLE001
                run.emit(
                    "validate", f"edited SQL of '{vs.title or vs.name}' could not be rendered: {e}"
                )
                continue
            out[(page.name, vs.name)] = sql
    if out and not quiet:
        run.emit("validate", f"{len(out)} untranslated pane(s) are validated with their edited SQL")
    return out


def _annotate_validation(compilation_log: CompilationLogger, spec, fidelity: FidelityReport) -> None:  # noqa: E501
    """Record, per measure, whether the visuals using it validated."""
    outcomes: dict[str, tuple[bool, str | None]] = {}
    vmap = {(p.name, v.name): v for p in spec.pages for v in p.visuals}
    for ps in fidelity.pages:
        for score in ps.visuals:
            vs = vmap.get((ps.page, score.visual))
            if vs is None or vs.query is None:
                continue
            failed = [c.detail for c in score.checks if c.status == CheckStatus.FAILED]
            for m in vs.query.measures:
                if not m.name:
                    continue
                passed, err = outcomes.get(m.name, (True, None))
                if failed:
                    passed, err = False, err or failed[0][:300]
                outcomes[m.name] = (passed, err)
    for name, (passed, err) in outcomes.items():
        compilation_log.annotate_validation(name, passed, err)


def _backfill_audit_sql(run: ConversionRun, compilation_log: CompilationLogger, engine) -> None:
    """Build a standalone card query for translated measures no visual exercised, so the audit has
    SQL for every translation (nothing is executed; plan errors land on the record)."""
    names = compilation_log.measures_without_sql()
    for name in names:
        try:
            engine.build_sql(
                QuerySpec(measures=[MeasureRefSpec(name=name)]),
                sql_context="audit_backfill:standalone_measure",
            )
        except Exception:  # noqa: BLE001, S112 - recorded on the measure by the engine
            continue
    if names:
        run.emit(
            "report",
            f"audit: generated standalone SQL for {len(names)} measures not used by any "
            "converted visual",
        )


def _value_check(run: ConversionRun, engine, bundle: ReportBundle, cursor) -> None:
    for r in run_value_check(engine, bundle.model, cursor):
        ref = f"{r['table']}[{r['column']}]"
        listed = ", ".join(f"'{x}'" for x in r["literals"])
        if r["error"]:
            run.emit("validate", f"could not check the values of {ref}: {r['error']}")
        elif r["offending"]:
            accepted = f"numbers nor {listed}" if listed else "numbers"
            bad = ", ".join(f"'{x}'" for x in r["offending"])
            run.emit(
                "validate",
                f"{ref} has values that make VALUE() fail in Power BI (neither {accepted}): "
                f"{bad}. % Change (IFERROR) measures return their fallback (BLANK) for them, "
                "exactly like Power BI. Measures using the same window without IFERROR show an "
                "error in Power BI for such a selection; the dashboard shows a value",
            )
        else:
            only = f"numbers and {listed}" if listed else "numbers"
            run.emit(
                "validate",
                f"{ref} holds only {only}: IFERROR measures using it translate exactly",
            )


def _apply_identifier_case(
    run: ConversionRun, bundle: ReportBundle, root: Path, cursor
) -> bool:
    """Letter-case check against the live catalog; saves corrections with the bundle."""
    with audit_stage(cursor, "setup", "identifier_case_check"):
        report, changed = correct_bundle_case(bundle, cursor)
    run.emit("validate", case_summary_message(report), case=report.summary())
    if changed:
        _save_bundle(bundle, root)
    return changed


def _connection_close(cursor) -> None:
    try:
        cursor.connection.close()
    except Exception:  # noqa: BLE001, S110 - best-effort close
        pass


def run_conversion(
    bundle: ReportBundle,
    conversion_id: str,
    storage_root: Path,
    cursor_factory,
    llm_client=None,
    resume: bool = False,
    migrator=None,
    llm_provider: str | None = None,
    ai_scope: str = "visuals",
) -> ConversionRun:
    """`migrator`: optional callable(binding_map, bundle, emit) -> dict summary.
    Runs when the report is bound to a foreign source database; lifts base
    tables into Snowflake and repoints the bundle so binding resolves natively.
    `ai_scope`: "visuals" translates only measures a visual uses; "all" also sends the others."""
    progress = _progress_writer(storage_root)
    run = ConversionRun(
        conversion_id=conversion_id, on_emit=progress, log_path=storage_root / "events.jsonl"
    )

    prior = _load_existing_run(storage_root)
    run.llm_provider = llm_provider or prior.get("llm_provider")

    # Phase-8: load prior run for resume support
    if resume:
        if prior:
            run.events = prior.get("events", [])
            run.tier2_accepted = prior.get("tier2_accepted", {})
            run.stages_complete = prior.get("stages_complete", {})
            run.emit("pipeline", "resuming from prior run state")
        else:
            run.emit("pipeline", "no prior run found, starting fresh")

    _drop_other_provider_ai(run, bundle, storage_root, prior, llm_provider)
    if llm_provider == "horizon" and llm_client is None:
        run.emit(
            "pipeline",
            "Horizon credentials are not configured — AI translation is off for this run",
        )
    ai_label = getattr(llm_client, "label", None) or "AI"

    # ---- Discovery (binding) ----
    settings = bundle.binding_settings
    if settings.database_override or settings.schema_override:
        run.emit(
            "binding",
            "Snowflake target overridden: "
            f"database={settings.database_override or '(from model)'}, "
            f"schema={settings.schema_override or '(from model)'}",
        )
    run.emit("binding", "matching report tables to your Snowflake warehouse")
    binding_map = build_bundle_binding_map(bundle)

    # ---- Source migration (foreign database -> Snowflake) ----
    to_migrate = binding_map.needs_migration
    if to_migrate:
        sources = sorted({b.source_kind or "?" for b in to_migrate})
        if migrator is None:
            run.emit(
                "migration",
                f"{len(to_migrate)} tables live in a {'/'.join(sources)} source database "
                "but no source connection was provided — they cannot be resolved",
                tables=[b.table for b in to_migrate],
            )
        else:
            run.emit(
                "migration",
                f"migrating {len(to_migrate)} base tables from {'/'.join(sources)} "
                "into Snowflake (schema + data + verification)",
                tables=[b.table for b in to_migrate],
            )
            summary = migrator(
                binding_map,
                bundle,
                lambda table, msg: run.emit("migration", f"{table}: {msg}"),
            )
            run.emit(
                "migration",
                (
                    "source migration complete — all tables verified and rebound to Snowflake"
                    if summary.get("ok")
                    else "source migration finished with errors"
                ),
                **summary,
            )
            # rebuild bindings from the rewritten bundle: everything now Snowflake
            binding_map = build_bundle_binding_map(bundle)
        run.mark_stage("migration")
        _persist(run, storage_root)

    resolved = sum(1 for b in binding_map.bindings.values() if b.status == "resolved")
    virtual = sum(1 for b in binding_map.bindings.values() if b.status == "virtual")
    materialization_required = sum(
        1 for b in binding_map.bindings.values() if b.status == "materialization_required"
    )
    materialization_by_strategy = {
        strategy: sum(
            1
            for b in binding_map.bindings.values()
            if b.status == "materialization_required" and b.materialization_strategy == strategy
        )
        for strategy in sorted(
            {
                b.materialization_strategy
                for b in binding_map.bindings.values()
                if b.status == "materialization_required" and b.materialization_strategy
            }
        )
    }
    unresolved = [b.table for b in binding_map.unresolved]
    still_foreign = [b.table for b in binding_map.needs_migration]
    run.emit(
        "binding",
        f"{resolved} tables matched, {virtual} calculated in-model, "
        f"{materialization_required} need staging, {len(unresolved)} not found"
        + (f", {len(still_foreign)} awaiting source migration" if still_foreign else ""),
        unresolved=unresolved,
        needs_migration=still_foreign,
        materialization_required=[b.table for b in binding_map.materialization_required],
        materialization_by_strategy=materialization_by_strategy,
        warnings=binding_map.warnings,
    )
    run.mark_stage("binding")
    _persist(run, storage_root)

    # ---- Translation (compile) ----
    run.emit("compile", "translating measures and visuals into the new dashboard")
    compilation_log = CompilationLogger(storage_root)
    compilation_log.initialize_for_conversion(conversion_id)
    spec, binding_map = _compile_with_overrides(
        bundle, storage_root, run.tier2_accepted, compilation_log
    )
    run.spec = spec
    parked = [m for m, t in spec.measure_tiers.items() if t < 0]
    run.emit(
        "compile",
        f"{sum(1 for t in spec.measure_tiers.values() if t >= 0)}/{len(spec.measure_tiers)} "
        f"measures translated automatically; {len(parked)} need assistance",
        parked=parked,
        compilation_audit=compilation_log.summary(),
    )
    for page in spec.pages:
        unsupported = [v.name for v in page.visuals if not v.supported]
        substituted = [v.name for v in page.visuals if v.substituted_as]
        run.emit(
            "compile",
            f"page '{page.display_name}': {len(page.visuals)} visuals, "
            f"{len(unsupported)} unsupported, {len(substituted)} substituted",
        )
    run.mark_stage("compile")
    _persist(run, storage_root)

    engine = SemanticEngine(
        bundle.model, binding_map, tier2_sql=run.tier2_accepted, logger=compilation_log
    )

    # one result cache for validation, every repair round and the probes
    query_results: dict = {}

    # ---- ValidationAgent ----
    cursor = cursor_factory()
    try:
        # identifier case + reachability before validating anything
        if _apply_identifier_case(run, bundle, storage_root, cursor):
            binding_map = build_bundle_binding_map(bundle)
            engine = SemanticEngine(
                bundle.model, binding_map, tier2_sql=run.tier2_accepted, logger=compilation_log
            )
        with audit_stage(cursor, "setup", "access_preflight"):
            preflight = run_preflight(binding_map, cursor)
        run.preflight = preflight.summary()
        run.emit(
            "preflight",
            preflight.message(),
            role=preflight.role,
            warehouse=preflight.warehouse,
            targets=run.preflight["targets"],
        )
        _persist(run, storage_root)
        _value_check(run, engine, bundle, cursor)

        run.emit("validate", "checking every visual's numbers against Snowflake")
        fidelity = run_validation(
            spec,
            engine,
            cursor,
            on_page=lambda ps: run.emit(
                "validate",
                f"page '{ps.display_name}': {len(ps.visuals)} visuals checked, "
                f"score {ps.score:.2%}",
            ),
            bundle=bundle,
            result_cache=query_results,
            manual_sql=_manual_sql(run, spec, engine, storage_root),
        )
        run.fidelity = fidelity
        _annotate_validation(compilation_log, spec, fidelity)
        run.emit("validate", "fidelity computed", summary=fidelity.summary())
        run.mark_stage("validate")
        _persist(run, storage_root)

        # ---- RepairAgent (bounded, monotonic) ----
        from app.agents.presentation_repair import presentation_gaps, propose_overrides
        from app.services.overrides import add_override, validate_override

        rejected: set[str] = set()
        rewritten: set[str] = set()
        announced_scope = False
        announced_undefined = False
        dependency_cache: dict[str, str] = {}

        for round_no in range(1, _MAX_REPAIR_ROUNDS + 1):
            failures = [
                v
                for p in fidelity.pages
                for v in p.visuals
                if v.status == CheckStatus.FAILED
            ]
            from app.agents import tier2 as tier2_mod

            undefined = tier2_mod.undefined_measures(bundle.model)
            if undefined and not announced_undefined:
                announced_undefined = True
                shown = []
                for name, users in sorted(undefined.items()):
                    extra = f" and {len(users) - 2} more" if len(users) > 2 else ""
                    shown.append(f"[{name}] (used by {', '.join(f'[{u}]' for u in users[:2])}{extra})")  # noqa: E501
                run.emit(
                    "repair",
                    "the uploaded model references measures it does not define: "
                    + "; ".join(shown),
                )
            in_visuals = _visual_measures(bundle)
            parked = [m for m, t in spec.measure_tiers.items() if t < 0]
            if ai_scope == "visuals":
                in_scope = [m for m in parked if m in in_visuals]
                skipped_scope = [m for m in parked if m not in in_visuals]
                if skipped_scope and not announced_scope:
                    announced_scope = True
                    run.emit(
                        "repair",
                        f"{len(skipped_scope)} untranslated measures are not used by any visual; "
                        "they are left for review instead of AI translation",
                    )
            else:
                in_scope = parked
            candidates = [
                m
                for m in in_scope
                if m not in run.tier2_accepted and m not in rejected and m not in rewritten
            ]
            gaps = presentation_gaps(bundle, spec)
            if not failures and not candidates and not gaps:
                break
            run.emit(
                "repair",
                f"round {round_no}: {len(failures)} visuals need attention, "
                f"{len(candidates)} measures need AI translation, "
                f"{len(gaps)} presentation gaps detected",
            )
            progressed = False
            round_rewrites: list[str] = []

            # deterministic presentation repair: re-read declared PBIR intent
            # and patch the spec through the whitelisted override vocabulary
            proposals = propose_overrides(gaps)
            applied = 0
            for proposal in proposals:
                err = validate_override(spec, proposal)
                if err:
                    run.emit(
                        "repair",
                        f"presentation fix skipped ({proposal['op']}@{proposal['visual']}): {err}",
                    )
                    continue
                finding = (
                    f"presentation:{proposal['page']}:{proposal['visual']}:"
                    f"{proposal.get('key') or proposal.get('measure')}"
                )
                add_override(storage_root, proposal, finding_id=finding)
                applied += 1
            if applied:
                run.emit(
                    "repair",
                    f"round {round_no}: applied {applied} declared-presentation "
                    "repairs (legend/labels/units/containers/formats from the PBIR source)",
                )
                progressed = True

            if llm_client is not None and candidates:
                if preflight.blocking:
                    run.emit(
                        "repair",
                        f"skipping AI translation of {len(candidates)} measures: no Snowflake "
                        "table is reachable, so no proposal could be validated",
                    )
                else:
                    unreachable = _unreachable_tables(binding_map, run.preflight)
                    log_path = storage_root / "tier2_llm.jsonl"
                    for m in _tier2_order(bundle.model, candidates):
                        try:
                            outcome = _repair_measure(
                                run=run,
                                bundle=bundle,
                                root=storage_root,
                                m=m,
                                llm_client=llm_client,
                                ai_label=ai_label,
                                undefined=undefined,
                                unreachable=unreachable,
                                rejected=rejected,
                                rewritten=rewritten,
                                binding_map=binding_map,
                                engine=engine,
                                cursor=cursor,
                                log_path=log_path,
                                dependency_cache=dependency_cache,
                            )
                        except LlmError as e:
                            rejected.add(m)
                            run.emit(
                                "repair",
                                f"[{m}]: AI translation unavailable — measure parked, "
                                f"needs assistance ({str(e)[:300]})",
                            )
                            continue
                        if outcome == "rewritten":
                            round_rewrites.append(m)
                            progressed = True
                        elif outcome in ("sql", "tier1"):
                            progressed = True

            if not progressed:
                run.emit("repair", f"round {round_no}: no further automatic fix available")
                break

            # recompile with accepted tier-2 SQL / rewrites and repair overrides applied
            spec, binding_map = _compile_with_overrides(
                bundle, storage_root, run.tier2_accepted, compilation_log
            )
            engine = SemanticEngine(
                bundle.model, binding_map, tier2_sql=run.tier2_accepted, logger=compilation_log
            )
            candidate = run_validation(
                spec,
                engine,
                cursor,
                bundle=bundle,
                result_cache=query_results,
                manual_sql=_manual_sql(run, spec, engine, storage_root, quiet=True),
            )
            if candidate.score >= fidelity.score:
                fidelity = candidate
                run.fidelity = candidate
                run.spec = spec
                _annotate_validation(compilation_log, spec, candidate)
                run.emit("repair", f"round {round_no}: accepted (score {candidate.score:.4f})")
                _persist(run, storage_root)
            else:
                run.emit(
                    "repair",
                    f"round {round_no}: REJECTED - score regressed "
                    f"{fidelity.score:.4f} -> {candidate.score:.4f}",
                )
                if round_rewrites:
                    for name in round_rewrites:
                        bundle.model.dax_rewrites.pop(name, None)
                        rewritten.discard(name)
                    _save_bundle(bundle, storage_root)
                    run.emit(
                        "repair",
                        f"round {round_no}: reverted {len(round_rewrites)} AI DAX rewrites from "
                        "the rejected round",
                    )
                break
        _backfill_audit_sql(run, compilation_log, engine)
    finally:
        _connection_close(cursor)

    # ---- Filter Testing (probe): prove filters propagate correctly ----
    cursor2 = cursor_factory()
    try:
        run.emit("probe", "testing that slicers and filters change the numbers correctly")
        with audit_stage(cursor2, "probe"):
            probes = run_filter_probes(
                with_default_filters(run.spec or spec),
                SemanticEngine(
                    bundle.model, binding_map, tier2_sql=run.tier2_accepted, logger=compilation_log
                ),
                CachingCursor(cursor2, query_results),
                on_probe=lambda p: run.emit(
                    "probe",
                    " · ".join(
                        [
                            p.display_name,
                            " & ".join(f"{f['column']}={f['value']}" for f in p.filters),
                            f"[{p.measure}]: "
                            + {
                                CheckStatus.PASSED: "✓ reconciled",
                                CheckStatus.SKIPPED: f"⊘ skipped — {p.detail}",
                            }.get(p.status, f"✗ {p.detail}"),
                        ]
                    ),
                ),
            )
        if run.fidelity is not None:
            run.fidelity.filter_probes = probes
        tested = [p for p in probes if p.status != CheckStatus.SKIPPED]
        passed = sum(1 for p in tested if p.status == CheckStatus.PASSED)
        skipped = len(probes) - len(tested)
        run.emit(
            "probe",
            f"filter checks: {passed}/{len(tested)} combinations verified"
            + (f" ({skipped} skipped: unrelated fields)" if skipped else ""),
        )
        run.mark_stage("probe")
        _persist(run, storage_root)
    finally:
        _connection_close(cursor2)

    # ---- Summary (report) ----
    s = run.fidelity.summary() if run.fidelity else {}
    run.emit(
        "report",
        f"conversion complete: score {s.get('overall_score', 0):.2%}, "
        f"{s.get('visuals_passed', 0)}/{s.get('visuals_total', 0)} visuals passing, "
        f"{s.get('substituted', 0)} closest-match substitutions, "
        f"{s.get('measures_parked', 0)} measures awaiting review",
    )
    run.mark_stage("report")
    _persist(run, storage_root)
    progress(run.events, done=True)
    return run


def _repair_measure(
    *,
    run: ConversionRun,
    bundle: ReportBundle,
    root: Path,
    m: str,
    llm_client,
    ai_label: str,
    undefined: dict,
    unreachable: set,
    rejected: set,
    rewritten: set,
    binding_map,
    engine,
    cursor,
    log_path: Path,
    dependency_cache: dict,
) -> str:
    """One candidate through the safe AI order. Returns rewritten | sql | tier1 | rejected."""
    from app.agents import tier2 as tier2_mod
    from app.agents.tier2 import propose_and_validate, propose_dax_rewrite, rewrite_gate
    from app.services.cortex_client import llm_call_context

    model = bundle.model
    closure = [m, *tier2_mod.dependency_closure(model, m)]

    # 1. references an undefined measure
    for name, users in sorted(undefined.items()):
        if any(u in closure for u in users):
            rejected.add(m)
            run.emit(
                "repair",
                f"[{m}]: not sent to AI — it references [{name}], which is not defined in the "
                "uploaded model",
            )
            return "rejected"
    # 2. reads a table the session cannot reach
    reads = tier2_mod.reference_closure(model, m)["tables"] & unreachable
    if reads:
        rejected.add(m)
        run.emit(
            "repair",
            f"[{m}]: not sent to AI — it reads {', '.join(sorted(reads))}, which the Snowflake "
            "session cannot reach (see pre-flight)",
        )
        return "rejected"
    # 3. a dependency could not be translated
    bad = next((d for d in closure[1:] if d in rejected), None)
    if bad is not None:
        rejected.add(m)
        run.emit(
            "repair",
            f"[{m}]: skipped AI translation — depends on [{bad}], which could not be translated",
        )
        return "rejected"
    # 4. a dependency was rewritten: it may compile now
    compiler = MeasureCompiler(model)
    try:
        compiler.compile_measure(m)
        run.emit("repair", f"[{m}]: now compiles in tier-1 (a dependency was rewritten)")
        return "tier1"
    except DaxUnsupported as e:
        tier1_error = str(e)

    # 5. AI DAX rewrite into the tier-1 subset
    measure = model.find_measure(m)[1]
    original = model.effective_dax(measure)
    with llm_call_context(f"ai_llm_rewrite:{m}"):
        result = propose_dax_rewrite(
            model,
            measure,
            tier1_error,
            lambda candidate: rewrite_gate(
                bundle, candidate, binding_map, m, cursor, run.tier2_accepted
            ),
            llm_client,
            log_path=log_path,
        )
    if result.accepted and result.expression:
        model.dax_rewrites[m] = DaxRewrite(
            expression=result.expression,
            original=original,
            gates=result.gates,
            created_at=time.time(),
            provider=run.llm_provider,
        )
        _save_bundle(bundle, root)
        rewritten.add(m)
        run.emit(
            "repair",
            f"[{m}]: {ai_label} rewrite accepted after {result.attempts} attempt(s) — compiled by "
            "tier-1; shown as 'AI-rewritten DAX' in Review",
            trace=result.trace,
            gates=result.gates,
            dax=result.expression,
        )
        return "rewritten"

    # 6. filter-context measures must never become whole-model values
    ctx_funcs = tier2_mod.context_functions(model, m)
    if ctx_funcs:
        rejected.add(m)
        run.emit(
            "repair",
            f"[{m}]: no tier-1 rewrite was accepted, and it is not sent for a whole-model SQL "
            f"value because it reads the filter context ({', '.join(ctx_funcs)}), which such a "
            "value would ignore",
            trace=result.trace,
        )
        return "rejected"

    # 7. whole-model SQL
    run.emit(
        "repair",
        f"[{m}]: complex formula — asking {ai_label} for a Snowflake translation (checked "
        "against real data before acceptance)",
    )
    with audit_stage(cursor, "ai_check", f"ai_sql_check:{m}"), llm_call_context(f"ai_llm_sql:{m}"):
        sql_result = propose_and_validate(
            model,
            binding_map,
            m,
            cursor,
            client=llm_client,
            log_path=log_path,
            dependency_sql=_dependency_sql(model, m, run, engine, dependency_cache),
        )
    run.emit(
        "repair",
        f"[{m}]: {ai_label} translation {'accepted' if sql_result.accepted else 'rejected'} "
        f"after {sql_result.attempts} attempt(s)",
        trace=sql_result.trace,
    )
    if sql_result.accepted and sql_result.sql:
        run.tier2_accepted[m] = sql_result.sql
        return "sql"
    rejected.add(m)
    return "rejected"
