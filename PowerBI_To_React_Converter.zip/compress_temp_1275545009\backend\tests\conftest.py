import os
import tempfile
from pathlib import Path

import pytest

_SESSION_STORAGE = Path(tempfile.mkdtemp(prefix="pbic-test-storage-"))
os.environ["PBIC_STORAGE_DIR"] = str(_SESSION_STORAGE)
os.environ["PBIC_SECRETS_KEY_FILE"] = str(_SESSION_STORAGE / ".secrets.key")

FIXTURES = Path(__file__).resolve().parents[2] / "fixtures"


@pytest.fixture(scope="session")
def contoso_pbip() -> Path:
    return FIXTURES / "contoso_sales"


@pytest.fixture(scope="session")
def contoso_model_def(contoso_pbip: Path) -> Path:
    return contoso_pbip / "Contoso Sales.SemanticModel" / "definition"


@pytest.fixture(scope="session")
def contoso_report_dir(contoso_pbip: Path) -> Path:
    return contoso_pbip / "Contoso Sales.Report"


@pytest.fixture(scope="session", autouse=True)
def _isolated_storage():
    from app.core.config import get_settings

    from app.dax.parser import set_parse_cache_dir

    get_settings.cache_clear()
    set_parse_cache_dir(_SESSION_STORAGE / "cache" / "dax")
    yield
    set_parse_cache_dir(None, disabled=True)
    get_settings.cache_clear()
