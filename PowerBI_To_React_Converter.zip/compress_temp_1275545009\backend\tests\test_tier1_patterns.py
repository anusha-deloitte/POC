"""Tier-1 DAX patterns proven on DuckDB with hand-computed numbers (phase 06.4)."""

from __future__ import annotations

import pytest

from app.dax.compiler import DaxUnsupported
from app.runtime.engine import DimensionRef, MeasureRefSpec, QueryPlanError, QuerySpec
from tests.duck import DuckWorld

SALES_ROWS = [
    (1, 1, "N", 10.0),
    (2, 1, "S", 5.0),
    (3, 2, "N", 7.0),
    (4, 3, "E", 1.0),
    (5, 2, None, 4.0),
]


def world(extra_measures: dict[str, str] | None = None) -> DuckWorld:
    return DuckWorld(
        {
            "Sales": (["Id", "Key", "Region", "Amount"], SALES_ROWS),
            "Dim": (["Id", "Name"], [(1, "a"), (2, "b"), (3, "c")]),
        },
        rels=[("Sales", "Key", "Dim", "Id")],
        measures={"Total": "SUM(Sales[Amount])", **(extra_measures or {})},
    )


def test_in_table_constructor_filter():
    w = world()
    assert w.value('CALCULATE(SUM(Sales[Amount]), Sales[Region] IN {"N", "S"})') == 22.0


def test_treatas_literals():
    w = world()
    assert w.value('CALCULATE(SUM(Sales[Amount]), TREATAS({"N"}, Sales[Region]))') == 17.0


def test_two_level_sumx_card_and_grouped():
    two = (
        'SUMX(ADDCOLUMNS(SUMMARIZE(Sales, Sales[Key]), "n", CALCULATE(SUM(Sales[Amount]))), [n] * 2)'
    )
    w = world({"Two": two})
    assert w.value("Two") == 54.0
    rows = w.run(
        QuerySpec(
            dimensions=[DimensionRef(table="Dim", column="Name")],
            measures=[MeasureRefSpec(name="Two")],
        )
    )
    assert rows == [("a", 30.0), ("b", 22.0), ("c", 2.0)]


def test_two_level_nonlinear_body_differs_from_flat_sum():
    sq = 'SUMX(ADDCOLUMNS(SUMMARIZE(Sales, Sales[Key]), "n", CALCULATE(SUM(Sales[Amount]))), [n] * [n])'
    w = world({"Sq": sq})
    assert w.value("Sq") == 15.0**2 + 11.0**2 + 1.0


def test_sumx_over_summarize_with_summed_column_as_key():
    expr = (
        'SUMX(ADDCOLUMNS(SUMMARIZE(Sales, Sales[Key]), "n", CALCULATE(COUNTROWS(Sales))), '
        "Sales[Key] * [n])"
    )
    assert world({"K": expr}).value("K") == 2 + 4 + 3


def test_table_var_is_materialized_where_defined():
    var_form = (
        'VAR t = ADDCOLUMNS(SUMMARIZE(Sales, Sales[Key]), "n", CALCULATE(SUM(Sales[Amount]))) '
        'RETURN CALCULATE(SUMX(t, [n]), Sales[Region] = "N")'
    )
    inline = (
        'CALCULATE(SUMX(ADDCOLUMNS(SUMMARIZE(Sales, Sales[Key]), "n", '
        'CALCULATE(SUM(Sales[Amount]))), [n]), Sales[Region] = "N")'
    )
    w = world({"V": var_form, "I": inline})
    assert w.value("V") == 27.0  # a VAR is a constant: CALCULATE does not re-filter it
    assert w.value("I") == 17.0  # an inline table is filtered by the CALCULATE


def test_unused_table_var_never_fails_a_measure():
    w = world({"U": "VAR x = CONCATENATEX(Sales, Sales[Region], \",\") RETURN SUM(Sales[Amount])"})
    assert w.value("U") == 27.0


def test_case_insensitive_measure_reference_and_names():
    w = world({"Again": "[total] + sales[amount] * 0 + 0" if False else "[TOTAL]"})
    assert w.value("Again") == 27.0
    assert w.value("SUM(SALES[AMOUNT])") == 27.0


def test_countx():
    assert world().value("COUNTX(Sales, Sales[Amount])") == 5


def test_sumx_over_filter_and_all():
    w = world()
    assert w.value('SUMX(FILTER(Sales, Sales[Region] = "N"), Sales[Amount])') == 17.0
    assert (
        w.value(
            'CALCULATE(SUMX(ALL(Sales), Sales[Amount]), Sales[Region] = "S")',
        )
        == 27.0
    )


def test_iferror_over_divide_is_fine_and_over_slash_refused():
    w = world()
    assert w.value("IFERROR(DIVIDE(SUM(Sales[Amount]), 0), -1)") is None
    assert w.value("IFERROR(DIVIDE(SUM(Sales[Amount]), 27), -1)") == 1.0
    with pytest.raises((DaxUnsupported, QueryPlanError), match="IFERROR"):
        w.value("IFERROR(SUM(Sales[Amount]) / 2, 0)")


def test_not_in_with_blank_drops_blank_rows():
    w = world()
    assert w.value('CALCULATE(SUM(Sales[Amount]), NOT (Sales[Region] IN {BLANK(), "N"}))') == 6.0


def test_not_in_keeps_blank_rows():
    w = world()
    assert w.value('CALCULATE(SUM(Sales[Amount]), NOT (Sales[Region] IN {"N"}))') == 10.0


def test_in_blank():
    w = world()
    assert w.value('CALCULATE(SUM(Sales[Amount]), Sales[Region] IN {BLANK(), "S"})') == 9.0


def test_calculate_replaces_filter_on_same_column_but_keepfilters_intersects():
    w = world({"North": 'CALCULATE([Total], Sales[Region] = "N")'})
    spec_filters = [
        __import__("app.runtime.engine", fromlist=["FilterClause"]).FilterClause(
            table="Sales", column="Region", values=["S"]
        )
    ]
    # slicer says S; the measure's own predicate replaces it
    assert w.value("North", filters=spec_filters) == 17.0
    w2 = world({"North": 'CALCULATE([Total], KEEPFILTERS(Sales[Region] = "N"))'})
    assert w2.value("North", filters=spec_filters) is None  # S ∩ N is empty


def test_allexcept_keeps_listed_column_filters():
    from app.runtime.engine import FilterClause

    w = world({"AllButRegion": "CALCULATE([Total], ALLEXCEPT(Sales, Sales[Region]))"})
    flt = [
        FilterClause(table="Sales", column="Region", values=["N"]),
        FilterClause(table="Sales", column="Key", values=[1]),
    ]
    assert w.value("AllButRegion", filters=flt) == 17.0  # Key filter cleared, Region kept


def test_all_column_clears_only_that_column():
    from app.runtime.engine import FilterClause

    w = world({"NoRegion": "CALCULATE([Total], ALL(Sales[Region]))"})
    flt = [
        FilterClause(table="Sales", column="Region", values=["N"]),
        FilterClause(table="Sales", column="Key", values=[1]),
    ]
    assert w.value("NoRegion", filters=flt) == 15.0  # only Key = 1 remains


def test_related_in_iterator_body():
    w = DuckWorld(
        {
            "Sales": (["Id", "Key", "Qty"], [(1, 1, 2), (2, 2, 3), (3, 1, 1)]),
            "Prod": (["Id", "Price"], [(1, 10.0), (2, 4.0)]),
        },
        rels=[("Sales", "Key", "Prod", "Id")],
        measures={"Rev": "SUMX(Sales, Sales[Qty] * RELATED(Prod[Price]))"},
    )
    assert w.value("Rev") == 2 * 10 + 3 * 4 + 1 * 10


def test_edate_int_and_blank_helpers():
    from datetime import date

    w = DuckWorld(
        {"D": (["Dt", "V"], [(date(2024, 1, 31), 7.9), (date(2024, 3, 1), 1.0)])},
        measures={
            "Mx": "MAX(D[Dt])",
            "E": "EDATE(MAX(D[Dt]), 1)",
            "I": "INT(SUM(D[V]))",
        },
    )
    got = w.value("E")
    assert (got.date() if hasattr(got, "date") else got) == date(2024, 4, 1)
    assert w.value("I") == 8


def test_firstnonblank_and_lastnonblank():
    w = DuckWorld(
        {
            "T": (["C"], [(3,), (1,), (2,)]),
            "U": (["C"], [(None,), (5,), (9,)]),
        },
        measures={
            "F": "FIRSTNONBLANK(T[C], 1)",
            "L": "LASTNONBLANK(T[C], 1)",
            "FU": "FIRSTNONBLANK(U[C], 1)",
            "LU": "LASTNONBLANK(U[C], 1)",
        },
    )
    assert w.value("F") == 1
    assert w.value("L") == 3
    assert w.value("FU") is None  # BLANK sorts first
    assert w.value("LU") == 9
    with pytest.raises((DaxUnsupported, QueryPlanError)):
        w.value("FIRSTNONBLANK(T[C], SUM(T[C]))")


def test_isfiltered_and_iscrossfiltered_per_query():
    from app.runtime.engine import FilterClause

    w = world(
        {
            "F": 'IF(ISFILTERED(Sales[Region]), "yes", "no")',
            "X": 'IF(ISCROSSFILTERED(Sales), "yes", "no")',
            "InCalc": 'CALCULATE(IF(ISFILTERED(Sales[Region]), "yes", "no"), Sales[Region] = "N")',
            "Cleared": 'CALCULATE(IF(ISFILTERED(Sales[Region]), "yes", "no"), ALL(Sales[Region]))',
        }
    )
    assert w.value("F") == "no"
    assert w.value("F", filters=[FilterClause(table="Sales", column="Region", values=["N"])]) == "yes"
    assert w.value("X") == "no"
    assert w.value("X", filters=[FilterClause(table="Dim", column="Name", values=["a"])]) == "yes"
    assert w.value("InCalc") == "yes"
    assert w.value(
        "Cleared", filters=[FilterClause(table="Sales", column="Region", values=["N"])]
    ) == "no"


def test_compile_memo_and_failure_memo():
    w = world({"Bad": "CONCATENATEX(Sales, Sales[Region], \",\")"})
    from app.dax.compiler import MeasureCompiler

    comp = MeasureCompiler(w.model)
    a = comp.compile_measure("Total")
    assert comp.compile_measure("total") is a
    with pytest.raises(DaxUnsupported) as e1:
        comp.compile_measure("Bad")
    with pytest.raises(DaxUnsupported) as e2:
        comp.compile_measure("Bad")
    assert str(e1.value) == str(e2.value)
    assert "Bad" in comp._memo


def test_rewrite_invalidates_memo_and_revert_restores():
    from app.dax.compiler import MeasureCompiler
    from app.ir.model import DaxRewrite

    w = world()
    comp = MeasureCompiler(w.model)
    before = comp.compile_measure("Total")
    w.model.dax_rewrites["Total"] = DaxRewrite(expression="SUM(Sales[Id])", original="x")
    after = comp.compile_measure("Total")
    assert after is not before
    assert next(iter(after.leaves.values())).sql == 'SUM("Sales"."Id")'
    del w.model.dax_rewrites["Total"]
    reverted = comp.compile_measure("Total")
    assert next(iter(reverted.leaves.values())).sql == 'SUM("Sales"."Amount")'
