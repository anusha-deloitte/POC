import { useQueryClient } from '@tanstack/react-query'
import { toPng } from 'html-to-image'
import { useRef, useState, type ReactNode } from 'react'
import { parityApi } from '../../api/client'
import type { ParityComparison, ParityValues } from '../../api/types'
import { fetchDashboardSpec, fetchVisualData } from '../api'
import { queryVisualNames } from '../canvas'
import { defaultFilterClauses } from '../filtersPaneState'
import { emptyInteractionState, resolveVisualInteractions } from '../interactions'
import { PageCanvas } from '../PageCanvas'
import { buildTheme, PbiThemeContext } from '../pbi/resolve'
import { ReportContext } from '../reportContext'
import { ThemeProvider } from '../theme'
import type { DashboardSpec, PageSpec, VisualResult } from '../types'

export interface DetectedFilter {
  slicer_name: string
  slicer: string
  table: string
  column: string
  value: string | number
}

interface CaptureBundle {
  spec: DashboardSpec
  pageName: string
  results: Record<string, VisualResult>
  slicerState: Record<string, (string | number)[]>
}

export interface CompareOptions {
  /** ties the stored runs to a PDF-comparison batch */
  batchId?: string
  /** a screenshot used instead of the stored reference (no filter detection / number check) */
  manualRef?: File
  /** progress callback: "Detecting filters…", "Checking numbers…", … */
  onStage?: (message: string) => void
}

export interface CompareOutcome {
  comparison: ParityComparison
  /** null when the number check was skipped or failed */
  values: ParityValues | null
  /** why the number check did not run (e.g. the reference PDF has no text) */
  valuesNote: string | null
  filters: { slicer: string; value: string | number }[]
}

export interface ParityRunnerOptions {
  conversionId: string
  connectionId: string | null | undefined
  /** wait before the capture so animated charts settle (tests pass 0) */
  settleMs?: number
}

/**
 * The compare pipeline for one conversion: detect the reference's slicer state ->
 * query data under those filters -> number check against the PDF text ->
 * render offscreen + capture -> vision compare.
 *
 * Render `captureHost` somewhere in the tree: it is the offscreen render target.
 */
export function useParityRunner({ conversionId, connectionId, settleMs = 1800 }: ParityRunnerOptions) {
  const qc = useQueryClient()
  const [capture, setCapture] = useState<CaptureBundle | null>(null)
  const captureRef = useRef<HTMLDivElement>(null)

  const getSpec = () =>
    qc.fetchQuery({
      queryKey: ['dash-spec', conversionId],
      queryFn: () => fetchDashboardSpec(conversionId),
      staleTime: 30_000,
    })

  const defaultsFor = (spec: DashboardSpec, p: PageSpec) => {
    const clauses = defaultFilterClauses(spec, p)
    return Object.fromEntries(queryVisualNames(p).map((name) => [name, clauses]))
  }

  const captureNow = async (p: PageSpec): Promise<Blob> => {
    // charts animate in; give ECharts a settle window before capture
    await new Promise((r) => setTimeout(r, settleMs))
    for (let i = 0; i < 40 && !captureRef.current; i++) await new Promise((r) => setTimeout(r, 50))
    const dataUrl = await toPng(captureRef.current!, {
      width: p.width,
      height: p.height,
      pixelRatio: 1,
      backgroundColor: '#ffffff',
    })
    return (await fetch(dataUrl)).blob()
  }

  /** Detect the reference's slicer state so the render is captured under the SAME filters
   *  (a 2024-filtered PDF vs an all-years render would otherwise produce false differences). */
  const detectFilters = async (
    p: PageSpec,
    unfiltered: Record<string, VisualResult>,
  ): Promise<DetectedFilter[]> => {
    const slicers = p.visuals.filter((v) => v.visual_type === 'slicer' && v.slicer_target)
    if (!slicers.length) return []
    try {
      const body = await parityApi.detectFilters(conversionId, p.name, {
        slicers: slicers.map((s) => ({
          name: s.name,
          title: s.title ?? s.slicer_target!.column,
          table: s.slicer_target!.table,
          column: s.slicer_target!.column,
          // slicer domain values from the unfiltered render results
          options: (unfiltered[s.name]?.rows ?? [])
            .map((r) => r[0])
            .filter((v): v is string | number => v !== null)
            .slice(0, 40),
        })),
      })
      return (body.selections ?? []) as DetectedFilter[]
    } catch {
      return [] // detection is best-effort; compare proceeds unfiltered
    }
  }

  const comparePage = async (
    pageOrName: PageSpec | string,
    opts: CompareOptions = {},
  ): Promise<CompareOutcome> => {
    if (!connectionId) throw new Error('no warehouse connection selected')
    const stage = opts.onStage ?? (() => {})
    const spec = await getSpec()
    const name = typeof pageOrName === 'string' ? pageOrName : pageOrName.name
    // always compare the freshest spec (a fix may just have patched the page)
    const p = spec.pages.find((x) => x.name === name) ?? (typeof pageOrName === 'string' ? null : pageOrName)
    if (!p) throw new Error(`page ${name} not found in the dashboard spec`)
    const names = queryVisualNames(p)

    stage('Querying data…')
    const unfiltered = await fetchVisualData(conversionId, connectionId, p.name, names, defaultsFor(spec, p))
    // manual screenshots have no stored reference to read filters from
    stage('Detecting filters…')
    const detected = opts.manualRef ? [] : await detectFilters(p, unfiltered)
    let results = unfiltered
    const slicerState: Record<string, (string | number)[]> = {}
    if (detected.length) {
      const clauses = detected.map((d) => ({ table: d.table, column: d.column, values: [d.value] }))
      const base = defaultFilterClauses(spec, p)
      const visualFilters = Object.fromEntries(names.map((n) => [n, [...base, ...clauses]]))
      results = await fetchVisualData(conversionId, connectionId, p.name, names, visualFilters)
      for (const d of detected) slicerState[d.slicer_name] = [d.value]
    }
    const filters = detected.map((d) => ({ slicer: d.slicer, value: d.value }))

    // number check FIRST: query results vs the numbers printed in the reference PDF
    let values: ParityValues | null = null
    let valuesNote: string | null = null
    if (!opts.manualRef) {
      stage('Checking numbers…')
      try {
        values = await parityApi.values(conversionId, p.name, {
          results: Object.values(results)
            .filter((r) => !r.visual.endsWith('#title') && !r.error)
            .map((r) => ({ visual: r.visual, columns: r.columns, rows: r.rows, totals: r.totals })),
          filters,
          ...(opts.batchId ? { batch_id: opts.batchId } : {}),
        })
      } catch (e) {
        valuesNote = (e as Error).message
      }
    }

    stage('Capturing render…')
    setCapture({ spec, pageName: p.name, results, slicerState })
    try {
      const rendered = await captureNow(p)
      stage('Comparing with the reference…')
      const comparison = await parityApi.compare(conversionId, p.name, {
        rendered,
        reference: opts.manualRef,
        filters: filters.length ? filters : undefined,
        batchId: opts.batchId,
      })
      return { comparison, values, valuesNote, filters }
    } finally {
      setCapture(null)
    }
  }

  // offscreen render target at native PBI page size for pixel-true capture
  const capPage = capture?.spec.pages.find((p) => p.name === capture.pageName)
  const captureHost: ReactNode =
    capture && capPage ? (
      <div
        aria-hidden
        data-testid="parity-capture"
        className="fixed top-0 left-[-10000px]"
        style={{ width: capPage.width, height: capPage.height }}
      >
        <div ref={captureRef} style={{ width: capPage.width, height: capPage.height }}>
          <ThemeProvider value={capture.spec.theme}>
            <PbiThemeContext.Provider value={buildTheme(capture.spec.pbi_theme)}>
              <ReportContext.Provider value={{ conversionId, connectionId: connectionId ?? undefined }}>
                <PageCanvas
                  page={capPage}
                  results={capture.results}
                  slicerState={capture.slicerState}
                  onSlicerChange={() => {}}
                  interactionState={emptyInteractionState()}
                  onInteractionChange={() => {}}
                  visualInteractions={resolveVisualInteractions(
                    capPage,
                    capture.spec.interaction_graph,
                    emptyInteractionState(),
                  )}
                  annotations={false}
                  fit="ActualSize"
                  verticalAlignment={capture.spec.vertical_alignment}
                />
              </ReportContext.Provider>
            </PbiThemeContext.Provider>
          </ThemeProvider>
        </div>
      </div>
    ) : null

  return { comparePage, captureHost, capturing: capture !== null }
}
