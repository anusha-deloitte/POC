"""Accuracy harness: per-visual validation producing a Fidelity Scorecard.

Checks per visual, cheapest first:
1. compile   - spec compiled, measures in tier 0/1 (or substituted)
2. parity    - every projection in the PBI visual definition was consumed
               by the compiler (catches lost Series/Legend/roles = visuals
               that render with the right numbers but the wrong shape)
3. execute   - generated SQL runs on Snowflake without error
4. sanity    - result-shape invariants (rows, nulls, duplicate grain keys)
5. totals    - self-consistency: grouped result re-aggregates to the
               ungrouped total for additive measures (catches join fanout,
               the classic silent-wrong-number bug)

Scores roll up visual -> page -> report. External goldens (Performance
Analyzer DAX / CSV exports) plug in as an optional fifth check later.
"""

from __future__ import annotations

import math
import time
from enum import StrEnum

from pydantic import BaseModel, Field

from app.core.parallel import run_parallel
from app.services.query_audit import remember_sql_context
from app.runtime.dashboard import DashboardSpec, VisualSpec
from app.runtime.engine import QueryPlanError, QuerySpec, SemanticEngine
from app.runtime.semantic_view import SemanticViewPlanError
from app.validation.parity_compare import compare_result_grids

REL_TOL = 1e-6

# decorative / navigational visuals: they carry no data, so they must not hide a failing data pane
STATIC_VISUAL_TYPES = frozenset(
    {
        "actionButton", "shape", "basicShape", "image", "visualGroup", "textbox",
        "bookmarkNavigator", "pageNavigator",
    }
)  # fmt: skip


class CheckStatus(StrEnum):
    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"


class Check(BaseModel):
    name: str
    status: CheckStatus
    detail: str = ""


class VisualScore(BaseModel):
    visual: str
    page: str
    visual_type: str
    title: str | None = None
    checks: list[Check] = Field(default_factory=list)
    substituted_as: str | None = None
    elapsed_ms: int = 0
    rechecked_at: float | None = None
    sql_override: bool = False  # the pane was validated with hand-edited SQL

    @property
    def is_data_visual(self) -> bool:
        return self.visual_type not in STATIC_VISUAL_TYPES

    @property
    def status(self) -> CheckStatus:
        statuses = {c.status for c in self.checks}
        if CheckStatus.FAILED in statuses:
            return CheckStatus.FAILED
        if statuses == {CheckStatus.SKIPPED}:
            return CheckStatus.SKIPPED
        return CheckStatus.PASSED

    @property
    def score(self) -> float:
        scored = [c for c in self.checks if c.status != CheckStatus.SKIPPED]
        if not scored:
            return 1.0
        return sum(1 for c in scored if c.status == CheckStatus.PASSED) / len(scored)


class PageScore(BaseModel):
    page: str
    display_name: str
    visuals: list[VisualScore] = Field(default_factory=list)

    @property
    def score(self) -> float:
        return sum(v.score for v in self.visuals) / len(self.visuals) if self.visuals else 1.0

    @property
    def data_score(self) -> float:
        data = [v for v in self.visuals if v.is_data_visual]
        return sum(v.score for v in data) / len(data) if data else 1.0


class FilterProbe(BaseModel):
    """One filter-combination check: filtered slices must re-aggregate to the
    unfiltered total for an additive measure (slice-invariance)."""

    page: str
    display_name: str
    measure: str
    filters: list[dict] = Field(default_factory=list)  # [{table, column, value}]
    filtered_value: float | None = None
    status: CheckStatus = CheckStatus.SKIPPED
    detail: str = ""


class FidelityReport(BaseModel):
    report_name: str
    pages: list[PageScore] = Field(default_factory=list)
    measure_tiers: dict[str, int] = Field(default_factory=dict)
    filter_probes: list[FilterProbe] = Field(default_factory=list)
    generated_at: float = Field(default_factory=time.time)

    @property
    def score(self) -> float:
        vs = [v for p in self.pages for v in p.visuals]
        return sum(v.score for v in vs) / len(vs) if vs else 1.0

    @property
    def data_score(self) -> float:
        data = [v for p in self.pages for v in p.visuals if v.is_data_visual]
        return sum(v.score for v in data) / len(data) if data else 1.0

    def summary(self) -> dict:
        vs = [v for p in self.pages for v in p.visuals]
        data = [v for v in vs if v.is_data_visual]
        out = {
            "report": self.report_name,
            "overall_score": round(self.score, 4),
            "visuals_total": len(vs),
            "visuals_passed": sum(1 for v in vs if v.status == CheckStatus.PASSED),
            "visuals_failed": sum(1 for v in vs if v.status == CheckStatus.FAILED),
            "data_visuals_total": len(data),
            "data_visuals_passed": sum(1 for v in data if v.status == CheckStatus.PASSED),
            "data_score": round(self.data_score, 4),
            "substituted": sum(1 for v in vs if v.substituted_as),
            "measures_tier01": sum(1 for t in self.measure_tiers.values() if t >= 0),
            "measures_parked": sum(1 for t in self.measure_tiers.values() if t < 0),
            "pages": {p.display_name: round(p.score, 4) for p in self.pages},
            "pages_data": {p.display_name: round(p.data_score, 4) for p in self.pages},
        }
        if self.filter_probes:
            tested = [p for p in self.filter_probes if p.status != CheckStatus.SKIPPED]
            out["filter_probes_total"] = len(tested)
            out["filter_probes_passed"] = sum(
                1 for p in tested if p.status == CheckStatus.PASSED
            )
            out["filter_probes_skipped"] = len(self.filter_probes) - len(tested)
        return out


class ParityMismatch(BaseModel):
    row: int
    column: str
    expected: str | None = None
    actual: str | None = None
    detail: str


class VisualParityResult(BaseModel):
    visual: str
    page: str
    status: CheckStatus
    detail: str
    expected_sql: str | None = None
    actual_sql: str | None = None
    mismatches: list[ParityMismatch] = Field(default_factory=list)
    elapsed_ms: int = 0


class DualRunParityReport(BaseModel):
    report_name: str
    results: list[VisualParityResult] = Field(default_factory=list)
    generated_at: float = Field(default_factory=time.time)

    def summary(self) -> dict:
        total = len(self.results)
        passed = sum(1 for r in self.results if r.status == CheckStatus.PASSED)
        failed = sum(1 for r in self.results if r.status == CheckStatus.FAILED)
        skipped = sum(1 for r in self.results if r.status == CheckStatus.SKIPPED)
        return {
            "report": self.report_name,
            "visuals_total": total,
            "visuals_passed": passed,
            "visuals_failed": failed,
            "visuals_skipped": skipped,
            "pass_rate": round((passed / total), 4) if total else 1.0,
        }


def _is_number(v) -> bool:
    if v is None:
        return False
    try:
        float(v)
        return True
    except (TypeError, ValueError):
        return False


def _close(a: float, b: float) -> bool:
    if b == 0:
        return abs(a) < 1e-6
    return math.isclose(a, b, rel_tol=REL_TOL)


# Snowflake errors that mean "the semantic view cannot express this query",
# as opposed to a genuine numeric/authoring defect.
_SV_COVERAGE_ERROR_MARKERS = (
    "are not related",
    "not related to",
    "invalid identifier",
    "does not exist in semantic view",
    "unknown metric",
    "unknown dimension",
)


def _is_semantic_view_coverage_error(exc: Exception) -> bool:
    text = str(exc).lower()
    return any(marker in text for marker in _SV_COVERAGE_ERROR_MARKERS)


class CachingCursor:
    """Serves results by SQL text from a shared dict; anything not cached runs on the real
    cursor and is stored. A cached failure re-raises the same error, so scores are identical to
    sequential execution while repeated SQL (repair rounds, probes) costs nothing."""

    def __init__(self, cursor, cache: dict):
        self._cursor = cursor
        self._cache = cache
        self.description: list = []
        self._rows: list = []
        self.connection = getattr(cursor, "connection", None)

    def execute(self, sql: str, *args, **kwargs):
        hit = self._cache.get(sql)
        if hit is None:
            try:
                self._cursor.execute(sql, *args, **kwargs)
                hit = ("ok", list(self._cursor.description or []), list(self._cursor.fetchall()))
            except Exception as e:  # noqa: BLE001 - connector raises many types
                hit = ("error", e)
            self._cache[sql] = hit
        if hit[0] == "error":
            raise hit[1]
        self.description, self._rows = hit[1], hit[2]
        return self

    def fetchall(self):
        return self._rows

    def fetchone(self):
        return self._rows[0] if self._rows else None

    def close(self):
        self._cursor.close()


class ValidationHarness:
    """Runs checks for one conversion against a live cursor factory."""

    def __init__(self, engine: SemanticEngine, cursor, bundle=None, manual_sql=None):
        self.engine = engine
        self.cursor = cursor
        # hand-edited pane SQL keyed by (page, visual); used instead of the generated SQL
        self.manual_sql: dict = manual_sql or {}
        # raw PBIR visuals keyed by (page, visual) for declared-presentation checks
        self._raw_visuals: dict[tuple[str, str], object] = {}
        if bundle is not None:
            self._raw_visuals = {
                (p.name, v.name): v for p in bundle.report.pages for v in p.visuals
            }

    def validate_visual(
        self, page_name: str, vs: VisualSpec, main_sql: str | None = None
    ) -> VisualScore:
        """`main_sql`: hand-edited SQL for an untranslated pane; it replaces the generated query,
        the compile check is skipped and the result must carry every key the renderer reads."""
        started = time.perf_counter()
        score = VisualScore(
            visual=vs.name,
            page=page_name,
            visual_type=vs.visual_type,
            title=vs.title,
            substituted_as=vs.substituted_as,
            sql_override=bool(main_sql),
        )

        # 1. compile
        if not vs.supported:
            if main_sql and vs.data_status == "untranslated":
                reason = vs.unsupported_reason or "untranslated"
                score.checks.append(
                    Check(
                        name="compile",
                        status=CheckStatus.SKIPPED,
                        detail=f"{reason}; pane uses edited SQL",
                    )
                )
            else:
                score.checks.append(
                    Check(
                        name="compile",
                        status=CheckStatus.FAILED,
                        detail=vs.unsupported_reason or "",
                    )
                )
                return score
        elif vs.query is None:  # textbox etc: static, nothing to validate
            score.checks.append(
                Check(name="compile", status=CheckStatus.PASSED, detail="static visual")
            )
            return score
        else:
            score.checks.append(Check(name="compile", status=CheckStatus.PASSED))

        # 2. parity: did the compiler consume every projection PBI declared?
        if vs.dropped_fields:
            # documented nearest-equivalent substitutions report, exact conversions fail
            status = CheckStatus.SKIPPED if vs.substituted_as else CheckStatus.FAILED
            score.checks.append(
                Check(
                    name="parity",
                    status=status,
                    detail=f"projections not rendered: {'; '.join(vs.dropped_fields)}",
                )
            )
        else:
            score.checks.append(Check(name="parity", status=CheckStatus.PASSED))

        # 2b. presentation: formats/legend/labels declared in PBI must be
        # carried into the spec (caught here, not later by the vision compare)
        presentation = self._presentation_check(vs, page_name=page_name)
        if presentation is not None:
            score.checks.append(presentation)

        # 3. execute
        context = f"visual:{page_name}/{vs.name}:main"
        try:
            if main_sql:
                sql, warnings = main_sql, []
                remember_sql_context(sql, context)
            else:
                sql, warnings = self.engine.build_sql(vs.query, sql_context=context)
            self.cursor.execute(sql)
            cols = [d[0] for d in self.cursor.description]
            rows = self.cursor.fetchall()
            detail = f"{len(rows)} rows"
            if warnings:
                detail += f"; warnings: {'; '.join(warnings)}"
            score.checks.append(Check(name="execute", status=CheckStatus.PASSED, detail=detail))
        except (QueryPlanError, Exception) as e:  # connector raises many types
            score.checks.append(
                Check(name="execute", status=CheckStatus.FAILED, detail=str(e)[:300])
            )
            score.elapsed_ms = round((time.perf_counter() - started) * 1000)
            return score

        # 3b. edited SQL must return every key the renderer reads
        if main_sql:
            wanted = list(
                dict.fromkeys([*vs.dim_keys, *vs.column_keys, *vs.series_keys, *vs.measure_keys])
            )
            missing = [k for k in wanted if k not in cols]
            score.checks.append(
                Check(
                    name="columns",
                    status=CheckStatus.FAILED if missing else CheckStatus.PASSED,
                    detail=(
                        f"edited SQL is missing columns: {', '.join(missing)}"
                        if missing
                        else f"{len(wanted)} columns present"
                    ),
                )
            )

        # 3. sanity
        score.checks.append(self._sanity_check(vs, cols, rows))

        # 4. totals (additive single-leaf measures over a grain)
        if main_sql:
            score.checks.append(
                Check(
                    name="totals",
                    status=CheckStatus.SKIPPED,
                    detail="edited SQL: grand-total reconciliation applies to generated SQL only",
                )
            )
        else:
            totals = self._totals_check(vs, cols, rows, page_name=page_name)
            if totals is not None:
                score.checks.append(totals)

        score.elapsed_ms = round((time.perf_counter() - started) * 1000)
        return score

    def _presentation_check(self, vs: VisualSpec, page_name: str | None = None) -> Check | None:
        """Static presentation parity: every format string declared on the model
        and every presentation property declared in the PBIR payload must survive
        into the compiled spec. Catches metadata loss at conversion time instead
        of leaving it to the vision compare."""
        if vs.visual_type in ("slicer", "textbox"):
            return None
        problems: list[str] = []
        for m in vs.query.measures if vs.query else []:
            if not m.name:
                continue  # implicit column aggregates have no model format
            found = self.engine.model.find_measure(m.name)
            declared = found[1].format_string if found else None
            if declared and vs.measure_formats.get(m.key) != declared:
                got = vs.measure_formats.get(m.key)
                problems.append(
                    f"[{m.name}] format '{declared}' not in spec"
                    + (f" (spec has '{got}')" if got else "")
                )
        raw = self._raw_visuals.get((page_name, vs.name)) if page_name else None
        if raw is not None:
            from app.runtime.dashboard import extract_declared_presentation

            declared_opts = extract_declared_presentation(raw)
            for key, value in declared_opts.items():
                if vs.options.get(key) != value:
                    problems.append(
                        f"option '{key}' declared {value!r} but spec has "
                        f"{vs.options.get(key)!r}"
                    )
        if not vs.measure_keys and not problems:
            return None
        if problems:
            return Check(
                name="presentation",
                status=CheckStatus.FAILED,
                detail="; ".join(problems)[:300],
            )
        return Check(name="presentation", status=CheckStatus.PASSED)

    def _sanity_check(self, vs: VisualSpec, cols: list[str], rows) -> Check:
        problems: list[str] = []
        if vs.visual_type != "slicer" and vs.measure_keys and not rows:
            problems.append("empty result")
        # duplicate grain keys = broken GROUP BY / fanout
        if vs.dim_keys and rows:
            key_idx = [cols.index(k) for k in vs.dim_keys if k in cols]
            seen = set()
            for r in rows:
                key = tuple(r[i] for i in key_idx)
                if key in seen:
                    problems.append(f"duplicate grain key {key!r}")
                    break
                seen.add(key)
        # all-null measure columns
        for mk in vs.measure_keys:
            if mk in cols and rows:
                mi = cols.index(mk)
                if all(r[mi] is None for r in rows):
                    problems.append(f"measure '{mk}' all NULL")
        if problems:
            return Check(name="sanity", status=CheckStatus.FAILED, detail="; ".join(problems))
        return Check(name="sanity", status=CheckStatus.PASSED)

    def _totals_check(
        self, vs: VisualSpec, cols: list[str], rows, page_name: str = ""
    ) -> Check | None:
        """Grouped sums must equal the ungrouped total (additive measures only)."""
        if not vs.dim_keys or not vs.measure_keys or vs.query is None:
            return None
        if vs.query.measure_filters:
            return Check(
                name="totals",
                status=CheckStatus.SKIPPED,
                detail="visual-level measure filter: rows are a subset, no grand total to match",
            )
        from app.dax.compiler import DaxUnsupported

        additive: list[str] = []
        for m in vs.query.measures:
            key = m.alias or m.name or ""
            if m.name:
                try:
                    cm = self.engine.compiler.compile_measure(m.name)
                except DaxUnsupported:
                    continue
                # additive = single plain SUM leaf, no filters/shift, identity combiner
                if (
                    len(cm.leaves) == 1
                    and cm.expr in cm.leaves
                    and next(iter(cm.leaves.values())).sql.startswith("SUM(")
                    and not next(iter(cm.leaves.values())).ctx.filters
                    and next(iter(cm.leaves.values())).ctx.time_shift is None
                ):
                    additive.append(key)
            elif (m.aggregate or "").upper() == "SUM":
                additive.append(key)
        if not additive:
            return Check(
                name="totals", status=CheckStatus.SKIPPED, detail="no additive measures"
            )

        total_spec = QuerySpec(
            measures=[m for m in vs.query.measures if (m.alias or m.name) in additive],
            filters=vs.query.filters,
        )
        try:
            sql, _ = self.engine.build_sql(
                total_spec, sql_context=f"visual:{page_name}/{vs.name}:totals"
            )
            self.cursor.execute(sql)
            tcols = [d[0] for d in self.cursor.description]
            trow = self.cursor.fetchone()
        except Exception as e:
            return Check(name="totals", status=CheckStatus.FAILED, detail=str(e)[:200])

        failures = []
        for key in additive:
            gi = cols.index(key) if key in cols else -1
            ti = tcols.index(key) if key in tcols else -1
            if gi < 0 or ti < 0 or trow is None:
                continue
            grouped_sum = sum(float(r[gi]) for r in rows if _is_number(r[gi]))
            total = float(trow[ti]) if _is_number(trow[ti]) else 0.0
            if not _close(grouped_sum, total):
                failures.append(f"{key}: grouped {grouped_sum:.2f} != total {total:.2f}")
        if failures:
            return Check(name="totals", status=CheckStatus.FAILED, detail="; ".join(failures))
        return Check(
            name="totals", status=CheckStatus.PASSED, detail=f"{len(additive)} measures reconciled"
        )


def with_default_filters(spec: DashboardSpec) -> DashboardSpec:
    """The spec validated and probed by the pipeline: every pane query carries its page's report
    and page default filters (hidden and locked ones included)."""
    from app.runtime.filter_cards import with_default_filters as _with_defaults

    return _with_defaults(spec)


def _prefetch(spec: DashboardSpec, engine: SemanticEngine, cursor, cache: dict, pages, manual_sql):
    """Build every visual's SQL sequentially, then execute the distinct uncached queries up to 8 at
    a time on sibling cursors of the same connection. A no-op when the cursor can't open siblings
    (test fakes)."""
    connection = getattr(cursor, "connection", None)
    if connection is None or not hasattr(connection, "cursor"):
        return
    statements: list[str] = []
    for page in spec.pages:
        if pages and page.name not in pages:
            continue
        for vs in page.visuals:
            if not vs.supported or vs.query is None:
                continue
            try:
                sql = engine.build_sql(
                    vs.query, sql_context=f"visual:{page.name}/{vs.name}:main"
                )[0]
            except Exception:  # noqa: BLE001 - validation reports the failure itself
                continue
            if sql not in cache and sql not in statements:
                statements.append(sql)
    if len(statements) < 2:
        return

    def run(sql: str):
        try:
            cur = connection.cursor()
        except Exception:  # noqa: BLE001
            return sql, None
        try:
            cur.execute(sql)
            return sql, ("ok", list(cur.description or []), list(cur.fetchall()))
        except Exception as e:  # noqa: BLE001
            return sql, ("error", e)
        finally:
            try:
                cur.close()
            except Exception:  # noqa: BLE001, S110
                pass

    for sql, outcome in run_parallel(run, statements, max_workers=8):
        if outcome is not None:
            cache[sql] = outcome


def run_validation(
    spec: DashboardSpec,
    engine: SemanticEngine,
    cursor,
    pages: list[str] | None = None,
    on_page=None,
    bundle=None,
    result_cache: dict | None = None,
    manual_sql: dict | None = None,
) -> FidelityReport:
    """`result_cache` is shared across repair rounds and probes of one run, so only visuals whose
    SQL changed execute again."""
    cache = result_cache if result_cache is not None else {}
    if not isinstance(cursor, CachingCursor):
        cursor = CachingCursor(cursor, cache)
    spec = with_default_filters(spec)
    _prefetch(spec, engine, cursor, cache, pages, None)
    report = FidelityReport(report_name=spec.report_name, measure_tiers=spec.measure_tiers)
    harness = ValidationHarness(engine, cursor, bundle=bundle, manual_sql=manual_sql)
    for page in spec.pages:
        if pages and page.name not in pages:
            continue
        ps = PageScore(page=page.name, display_name=page.display_name)
        for vs in page.visuals:
            # hand-edited SQL only replaces panes the generator could not translate
            edited = (
                (manual_sql or {}).get((page.name, vs.name))
                if vs.data_status == "untranslated"
                else None
            )
            ps.visuals.append(harness.validate_visual(page.name, vs, main_sql=edited))
        report.pages.append(ps)
        if on_page is not None:
            on_page(ps)
    return report


def _first_additive_measure(engine: SemanticEngine, page) -> str | None:
    """Pick a plain-SUM tier-0/1 measure used on the page (probe target)."""
    from app.dax.compiler import DaxUnsupported

    for vs in page.visuals:
        if not vs.supported or vs.query is None:
            continue
        for m in vs.query.measures:
            if not m.name:
                continue
            try:
                cm = engine.compiler.compile_measure(m.name)
            except DaxUnsupported:
                continue
            if (
                len(cm.leaves) == 1
                and cm.expr in cm.leaves
                and next(iter(cm.leaves.values())).sql.startswith("SUM(")
                and not next(iter(cm.leaves.values())).ctx.filters
                and next(iter(cm.leaves.values())).ctx.time_shift is None
            ):
                return m.name
    return None


def _slicer_domains(engine: SemanticEngine, cursor, page, max_values: int = 2) -> list[dict]:
    """Sample values per slicer on the page: [{table, column, values:[..]}]."""
    from app.runtime.engine import DimensionRef

    domains = []
    for vs in page.visuals:
        if vs.visual_type != "slicer" or not vs.slicer_target:
            continue
        t, c = vs.slicer_target["table"], vs.slicer_target["column"]
        try:
            sql, _ = engine.build_sql(
                QuerySpec(dimensions=[DimensionRef(table=t, column=c)], limit=50)
            )
            cursor.execute(sql)
            values = [r[0] for r in cursor.fetchall() if r[0] is not None][:max_values]
        except Exception:  # noqa: S112 - domain sampling is best-effort
            continue
        if values:
            domains.append({"table": t, "column": c, "values": values})
    return domains


def run_filter_probes(
    spec: DashboardSpec,
    engine: SemanticEngine,
    cursor,
    max_probes_per_page: int = 4,
    on_probe=None,
) -> list[FilterProbe]:
    """Slice-invariance proof across filter combinations.

    For each page: take an additive measure, compute the unfiltered total,
    then for single filters and pairwise combinations check that the sum of
    the measure across a filter column's slices equals the total (partition
    property). Catches join fanout / filter propagation bugs that only appear
    under specific slicer states.
    """
    from app.runtime.engine import DimensionRef, FilterClause

    probes: list[FilterProbe] = []
    for page in spec.pages:
        measure = _first_additive_measure(engine, page)
        if measure is None:
            continue
        domains = _slicer_domains(engine, cursor, page)
        if not domains:
            continue

        # tables feeding the measure (for relationship-reachability checks)
        leaf_tables: set[str] = set()
        try:
            cm = engine.compiler.compile_measure(measure)
            for leaf in cm.leaves.values():
                leaf_tables |= set(leaf.tables)
        except Exception:  # noqa: S110 - reachability check is best-effort
            pass

        def _reachable(table: str, _tables=frozenset(leaf_tables)) -> bool:
            return any(
                t == table or engine.join_path(t, table) is not None for t in _tables
            )

        mref = None
        for vs in page.visuals:
            if vs.query is None:
                continue
            for m in vs.query.measures:
                if m.name == measure:
                    mref = m
                    break
            if mref is not None:
                break
        if mref is None:
            continue

        def total_under(filters: list[FilterClause], _m=mref) -> float | None:
            sql, _ = engine.build_sql(QuerySpec(measures=[_m], filters=filters))
            cursor.execute(sql)
            row = cursor.fetchone()
            v = row[0] if row else None
            return float(v) if _is_number(v) else None

        try:
            grand_total = total_under([])
        except Exception:  # noqa: S112 - page without a probeable total is skipped
            continue
        if grand_total is None:
            continue

        # combos: single slicers first, always ending with a pairwise combination
        singles_budget = max_probes_per_page - (1 if len(domains) >= 2 else 0)
        combos: list[list[dict]] = [[d] for d in domains[:singles_budget]]
        if len(domains) >= 2:
            combos.append(domains[:2])

        for combo in combos[:max_probes_per_page]:
            filters = [
                FilterClause(table=d["table"], column=d["column"], values=[d["values"][0]])
                for d in combo
            ]
            probe = FilterProbe(
                page=page.name,
                display_name=page.display_name,
                measure=measure,
                filters=[
                    {"table": d["table"], "column": d["column"], "value": d["values"][0]}
                    for d in combo
                ],
            )
            if leaf_tables and not _reachable(combo[0]["table"]):
                # PBI semantics: unrelated dims repeat the total across slices,
                # so the partition property intentionally does not hold
                probe.status = CheckStatus.SKIPPED
                probe.detail = (
                    f"{combo[0]['table']} has no relationship path to [{measure}]'s "
                    "fact — Power BI repeats the total across these slices"
                )
                probes.append(probe)
                if on_probe is not None:
                    on_probe(probe)
                continue
            try:
                # partition property on the FIRST filter column: sum over its
                # slices (under the remaining filters) must equal the total
                # under the remaining filters alone
                rest = filters[1:]
                d0 = combo[0]
                sql, _ = engine.build_sql(
                    QuerySpec(
                        dimensions=[DimensionRef(table=d0["table"], column=d0["column"])],
                        measures=[mref],
                        filters=rest,
                    )
                )
                cursor.execute(sql)
                cols = [d[0] for d in cursor.description]
                mi = cols.index(measure) if measure in cols else len(cols) - 1
                slice_sum = sum(
                    float(r[mi]) for r in cursor.fetchall() if _is_number(r[mi])
                )
                base = total_under(rest)
                probe.filtered_value = total_under(filters)
                if base is not None and _close(slice_sum, base):
                    probe.status = CheckStatus.PASSED
                    probe.detail = (
                        f"slices sum {slice_sum:,.2f} == total {base:,.2f} "
                        f"under {len(rest)} extra filter(s)"
                    )
                else:
                    probe.status = CheckStatus.FAILED
                    probe.detail = f"slices sum {slice_sum:,.2f} != total {base}"
            except Exception as e:
                probe.status = CheckStatus.FAILED
                probe.detail = str(e)[:200]
            probes.append(probe)
            if on_probe is not None:
                on_probe(probe)
    return probes


def run_dual_run_parity(
    spec: DashboardSpec,
    expected_engine: SemanticEngine,
    actual_engine: SemanticEngine,
    expected_cursor,
    actual_cursor,
    pages: list[str] | None = None,
    max_mismatches_per_visual: int = 25,
) -> DualRunParityReport:
    """Compare two execution engines at cell grain across supported visuals."""
    report = DualRunParityReport(report_name=spec.report_name)

    for page in spec.pages:
        if pages and page.name not in pages:
            continue
        for vs in page.visuals:
            started = time.perf_counter()
            if not vs.supported or vs.query is None:
                report.results.append(
                    VisualParityResult(
                        visual=vs.name,
                        page=page.name,
                        status=CheckStatus.SKIPPED,
                        detail=vs.unsupported_reason or "static or unsupported visual",
                    )
                )
                continue

            try:
                expected_sql, _ = expected_engine.build_sql(vs.query)
                expected_cursor.execute(expected_sql)
                expected_cols = [d[0] for d in expected_cursor.description]
                expected_rows = expected_cursor.fetchall()
            except Exception as e:
                report.results.append(
                    VisualParityResult(
                        visual=vs.name,
                        page=page.name,
                        status=CheckStatus.FAILED,
                        detail=f"expected path failed: {str(e)[:300]}",
                        expected_sql=locals().get("expected_sql"),
                        elapsed_ms=round((time.perf_counter() - started) * 1000),
                    )
                )
                continue

            try:
                actual_sql, _ = actual_engine.build_sql(vs.query)
                actual_cursor.execute(actual_sql)
                actual_cols = [d[0] for d in actual_cursor.description]
                actual_rows = actual_cursor.fetchall()
            except SemanticViewPlanError as e:
                # coverage gap (measure outside semantic-view surface), not a mismatch
                report.results.append(
                    VisualParityResult(
                        visual=vs.name,
                        page=page.name,
                        status=CheckStatus.SKIPPED,
                        detail=f"semantic-view coverage gap: {str(e)[:200]}",
                        expected_sql=expected_sql,
                        elapsed_ms=round((time.perf_counter() - started) * 1000),
                    )
                )
                continue
            except Exception as e:
                # Snowflake rejects some plannable semantic-view queries (e.g. a
                # measure whose fact is unrelated to the visual's dimension). That is
                # the same coverage gap SemanticViewPlanError reports, just surfaced
                # by the server, so classify it alongside — the compatibility path
                # already produced the correct numbers.
                status = (
                    CheckStatus.SKIPPED
                    if _is_semantic_view_coverage_error(e)
                    else CheckStatus.FAILED
                )
                prefix = (
                    "semantic-view coverage gap"
                    if status is CheckStatus.SKIPPED
                    else "actual path failed"
                )
                report.results.append(
                    VisualParityResult(
                        visual=vs.name,
                        page=page.name,
                        status=status,
                        detail=f"{prefix}: {str(e)[:300]}",
                        expected_sql=expected_sql,
                        actual_sql=locals().get("actual_sql"),
                        elapsed_ms=round((time.perf_counter() - started) * 1000),
                    )
                )
                continue

            # the two paths have different implicit ordering guarantees
            # (compat SQL honors sortByColumn; SEMANTIC_VIEW does not), so
            # compare at cell grain under a canonical row order
            def _canon(rows):
                return sorted(
                    [("" if c is None else str(c)) for c in r] for r in rows
                )

            ok, detail, deltas = compare_result_grids(
                expected_columns=expected_cols,
                expected_rows=_canon(expected_rows),
                actual_columns=actual_cols,
                actual_rows=_canon(actual_rows),
                rel_tol=REL_TOL,
                max_deltas=max_mismatches_per_visual,
            )

            report.results.append(
                VisualParityResult(
                    visual=vs.name,
                    page=page.name,
                    status=CheckStatus.PASSED if ok else CheckStatus.FAILED,
                    detail=detail,
                    expected_sql=expected_sql,
                    actual_sql=actual_sql,
                    mismatches=[
                        ParityMismatch(
                            row=d.row,
                            column=d.column,
                            expected=str(d.expected) if d.expected is not None else None,
                            actual=str(d.actual) if d.actual is not None else None,
                            detail=d.detail,
                        )
                        for d in deltas
                    ],
                    elapsed_ms=round((time.perf_counter() - started) * 1000),
                )
            )

    return report
