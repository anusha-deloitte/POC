"""Identifier letter-case check against the live Snowflake catalog.

Quoted Snowflake names are case-sensitive. A report whose Power Query spells a
database/schema/table/column differently from Snowflake would generate SQL that fails, so
each name is looked up and, when exactly one name differs only by case, corrected.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel, Field

from app.binding.resolver import (
    BindingMap,
    TableBinding,
    apply_binding_settings,
    build_binding_map,
    describe_ident,
    quote_ident,
    sql_string,
)
from app.ir.model import SemanticModel
from app.ir.report import ReportBundle, TableCaseFix

_QUOTED_NAME = re.compile(r'"((?:[^"]|"")+)"')


def match_case(name: str, candidates: list[str]) -> tuple[str, str | None, list[str]]:
    """(status, exact, candidates): exact | corrected | ambiguous | missing."""
    if name in candidates:
        return "exact", name, [name]
    folded = [c for c in candidates if c.casefold() == name.casefold()]
    if len(folded) == 1:
        return "corrected", folded[0], folded
    if len(folded) > 1:
        return "ambiguous", None, folded
    return "missing", None, []


class CaseItem(BaseModel):
    kind: str  # database | schema | table | column
    model_table: str
    name: str
    status: str
    exact: str | None = None
    candidates: list[str] = Field(default_factory=list)

    def describe(self) -> str:
        head = f"{self.kind} {describe_ident(self.name)} (table {describe_ident(self.model_table)})"
        if self.status == "corrected":
            return f"{head} -> {describe_ident(self.exact or '')}"
        if self.status == "ambiguous":
            names = ", ".join(describe_ident(c) for c in self.candidates)
            return f"{head}: several Snowflake names differ only by case: {names}"
        if self.status == "missing":
            return f"{head}: not found"
        return head


@dataclass
class CaseCheckReport:
    items: list[CaseItem] = field(default_factory=list)
    fixes: dict[str, TableCaseFix] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    column_errors: list[str] = field(default_factory=list)
    column_failed_tables: set[str] = field(default_factory=set)

    def _by(self, status: str) -> list[CaseItem]:
        return [i for i in self.items if i.status == status]

    def summary(self) -> dict[str, Any]:
        return {
            "checked": len(self.items),
            "exact": len(self._by("exact")),
            "corrected": [i.describe() for i in self._by("corrected")],
            "ambiguous": [i.describe() for i in self._by("ambiguous")],
            "missing": [i.describe() for i in self._by("missing")],
            "errors": list(self.errors),
        }


def case_summary_message(report: CaseCheckReport) -> str:
    s = report.summary()
    msg = f"identifier case: {s['exact']}/{s['checked']} names match Snowflake exactly"
    if s["corrected"]:
        msg += f", {len(s['corrected'])} corrected to Snowflake's spelling"
    if s["ambiguous"]:
        msg += f", {len(s['ambiguous'])} ambiguous (not changed)"
    if s["missing"]:
        msg += f", {len(s['missing'])} not found"
    return msg


def _checkable(b: TableBinding) -> bool:
    return bool(
        not b.is_virtual
        and not b.native_query
        and b.database
        and b.schema_name
        and b.object_name
        and b.status != "needs_migration"
    )


def physical_columns(model: SemanticModel, b: TableBinding) -> list[str]:
    """Source columns the generated SQL names for this binding."""
    table = model.table(b.table)
    cols: set[str] = set()
    if table is not None:
        cols = {c.source_column or c.name for c in table.columns if not c.is_calculated}
    cols -= set(b.column_aliases.values())
    cols -= set(b.computed_columns)
    cols |= set(b.column_aliases)
    for text in [b.where_clause or "", *b.computed_columns.values()]:
        cols |= {m.replace('""', '"') for m in _QUOTED_NAME.findall(text)}
    return sorted(cols)


def _rows(cursor: Any, sql: str) -> list[tuple]:
    cursor.execute(sql)
    return list(cursor.fetchall())


def _name_index(cursor: Any) -> int:
    for i, d in enumerate(getattr(cursor, "description", None) or []):
        if str(d[0]).lower() == "name":
            return i
    return 1


def check_identifier_case(
    binding_map: BindingMap, model: SemanticModel, cursor: Any
) -> CaseCheckReport:
    report = CaseCheckReport()
    bindings = [b for b in binding_map.bindings.values() if _checkable(b)]

    def add(kind: str, b: TableBinding, name: str, status: str, exact, cands) -> CaseItem:
        item = CaseItem(
            kind=kind,
            model_table=b.table,
            name=name,
            status=status,
            exact=exact,
            candidates=list(cands),
        )
        report.items.append(item)
        return item

    def fix_for(b: TableBinding) -> TableCaseFix:
        return report.fixes.setdefault(b.table, TableCaseFix())

    # ---- databases
    db_cache: dict[str, tuple[str, str | None, list[str]] | None] = {}
    for b in bindings:
        db = b.database or ""
        if db not in db_cache:
            try:
                rows = _rows(cursor, f"show databases like {sql_string(db)}")
                idx = _name_index(cursor)
                db_cache[db] = match_case(db, [str(r[idx]) for r in rows])
            except Exception as e:  # noqa: BLE001 - every query error is recorded
                report.errors.append(f"database {describe_ident(db)}: {e}")
                db_cache[db] = None
        result = db_cache[db]
        if result is None:
            continue
        status, exact, cands = result
        add("database", b, db, status, exact, cands)
        if status == "corrected" and exact != db:
            fix_for(b).database = exact

    def resolved_db(b: TableBinding) -> str | None:
        result = db_cache.get(b.database or "")
        if result is None or result[0] in ("missing", "ambiguous"):
            return None
        return result[1]

    # ---- schemas
    schema_cache: dict[tuple[str, str], tuple[str, str | None, list[str]] | None] = {}
    for b in bindings:
        db = resolved_db(b)
        if db is None:
            continue
        key = (db, b.schema_name or "")
        if key not in schema_cache:
            try:
                rows = _rows(
                    cursor,
                    f"select schema_name from {quote_ident(db)}.INFORMATION_SCHEMA.SCHEMATA "  # noqa: S608
                    f"where upper(schema_name) = upper({sql_string(key[1])})",
                )
                schema_cache[key] = match_case(key[1], [str(r[0]) for r in rows])
            except Exception as e:  # noqa: BLE001
                report.errors.append(f"schema {describe_ident(key[1])}: {e}")
                schema_cache[key] = None
        result = schema_cache[key]
        if result is None:
            continue
        status, exact, cands = result
        add("schema", b, key[1], status, exact, cands)
        if status == "corrected" and exact != key[1]:
            fix_for(b).schema_name = exact

    # ---- tables
    table_cache: dict[tuple[str, str], list[str] | None] = {}
    resolved_table: dict[str, tuple[str, str, str]] = {}
    for b in bindings:
        db = resolved_db(b)
        sres = schema_cache.get((db, b.schema_name or "")) if db else None
        if db is None or sres is None or sres[0] in ("missing", "ambiguous"):
            continue
        schema = sres[1] or ""
        tkey = (db, schema)
        if tkey not in table_cache:
            try:
                rows = _rows(
                    cursor,
                    f"select table_name from {quote_ident(db)}.INFORMATION_SCHEMA.TABLES "  # noqa: S608
                    f"where table_schema = {sql_string(schema)}",
                )
                table_cache[tkey] = [str(r[0]) for r in rows]
            except Exception as e:  # noqa: BLE001
                report.errors.append(f"tables of {describe_ident(schema)}: {e}")
                table_cache[tkey] = None
        names = table_cache[tkey]
        if names is None:
            continue
        status, exact, cands = match_case(b.object_name or "", names)
        add("table", b, b.object_name or "", status, exact, cands)
        if status == "corrected" and exact != b.object_name:
            fix_for(b).object_name = exact
        if status in ("exact", "corrected"):
            resolved_table[b.table] = (db, schema, exact or "")

    # ---- columns: one query per table (schema-wide results can be fetched from the
    # result stage, which corporate networks may block)
    for b in bindings:
        loc = resolved_table.get(b.table)
        if loc is None:
            continue
        db, schema, obj = loc
        try:
            rows = _rows(
                cursor,
                f"select column_name from {quote_ident(db)}.INFORMATION_SCHEMA.COLUMNS "  # noqa: S608
                f"where table_schema = {sql_string(schema)} and table_name = {sql_string(obj)}",
            )
        except Exception as e:  # noqa: BLE001
            msg = f"columns of {describe_ident(b.table)}: {e}"
            report.errors.append(msg)
            report.column_errors.append(msg)
            report.column_failed_tables.add(b.table)
            continue
        live = [str(r[0]) for r in rows]
        for col in physical_columns(model, b):
            status, exact, cands = match_case(col, live)
            add("column", b, col, status, exact, cands)
            if status == "corrected" and exact != col:
                fix_for(b).columns[col] = exact
    report.fixes = {
        t: f
        for t, f in report.fixes.items()
        if f.database or f.schema_name or f.object_name or f.columns
    }
    return report


def correct_bundle_case(bundle: ReportBundle, cursor: Any) -> tuple[CaseCheckReport, bool]:
    """Check names as the model + overrides spell them; update `binding_settings.case_fixes`.
    The caller persists the bundle when `changed` is True."""
    settings = bundle.binding_settings.model_copy(update={"case_fixes": {}})
    binding_map = apply_binding_settings(build_binding_map(bundle.model), settings)
    report = check_identifier_case(binding_map, bundle.model, cursor)
    if report.errors and not report.items:
        return report, False  # catalog unreadable: keep the saved fixes
    fixes = dict(report.fixes)
    for table in report.column_failed_tables:
        previous = bundle.binding_settings.case_fixes.get(table)
        if previous and previous.columns:
            fixes.setdefault(table, TableCaseFix()).columns = dict(previous.columns)
    bundle.binding_settings.case_fixes = fixes
    bundle.binding_settings.case_checked_at = time.time()
    return report, True
