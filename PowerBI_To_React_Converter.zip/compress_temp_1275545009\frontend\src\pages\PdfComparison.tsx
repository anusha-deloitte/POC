import { useQuery, useQueryClient } from '@tanstack/react-query'
import { AlertTriangle, Download, FileUp, Loader2, Play, Trash2 } from 'lucide-react'
import { useEffect, useMemo, useRef, useState } from 'react'
import { api, batchApi, parityApi } from '../api/client'
import type {
  Batch,
  BatchConfirmation,
  BatchPdf,
  BatchReportPage,
  BatchReportRow,
} from '../api/types'
import { fmtTime } from '../components/fmtTime'
import { SearchableSelect } from '../components/SearchableSelect'
import { Sparkline } from '../components/Sparkline'
import { ComparisonDetail, SimilarityBadge } from '../dashboard/parity/ComparisonDetail'
import { PageHistory } from '../dashboard/parity/PageHistory'
import { useApplyFixes } from '../dashboard/parity/useApplyFixes'
import { useParityRunner } from '../dashboard/parity/useParityRunner'
import { useWizard } from '../store/wizard'

// ---------------------------------------------------------------------------
// match-table model
// ---------------------------------------------------------------------------

interface PageRow {
  pdf_page: number
  page: string | null
  confident: boolean
  score?: number
}
interface PdfSelection {
  conversionId: string | null
  rows: PageRow[]
}

const NOT_MATCHED = ''

function reportPagesFor(batch: Batch, pdf: BatchPdf, conversionId: string | null): BatchReportPage[] {
  if (!conversionId) return []
  const cand = pdf.candidates.find((c) => c.conversion_id === conversionId)
  if (cand?.report_pages?.length) return cand.report_pages
  return batch.reports.find((r) => r.conversion_id === conversionId)?.pages ?? []
}

/** Rows for a PDF under a chosen job: the candidate's matches, else an ordinal guess. */
function rowsFor(batch: Batch, pdf: BatchPdf, conversionId: string | null): PageRow[] {
  const count = pdf.pages
  const cand = pdf.candidates.find((c) => c.conversion_id === conversionId)
  const out: PageRow[] = []
  for (let n = 1; n <= count; n++) {
    const m = cand?.pages.find((p) => p.pdf_page === n)
    if (cand) {
      out.push({
        pdf_page: n,
        page: m?.page ?? null,
        confident: !!m?.page && m.confident !== false,
        score: m?.score,
      })
    } else {
      const guess = reportPagesFor(batch, pdf, conversionId)[n - 1]
      out.push({ pdf_page: n, page: guess?.page ?? null, confident: false })
    }
  }
  return out
}

function initialSelection(batch: Batch): Record<number, PdfSelection> {
  const out: Record<number, PdfSelection> = {}
  for (const pdf of batch.pdfs) {
    const saved: BatchConfirmation | undefined = (batch.confirmations ?? []).find(
      (c) => c.file_index === pdf.index,
    )
    if (saved) {
      out[pdf.index] = {
        conversionId: saved.conversion_id,
        rows: Array.from({ length: pdf.pages }, (_, i) => {
          const m = saved.pages.find((p) => p.pdf_page === i + 1)
          return { pdf_page: i + 1, page: m?.page ?? null, confident: true }
        }),
      }
      continue
    }
    const top = pdf.candidates[0]?.conversion_id ?? null
    out[pdf.index] = { conversionId: top, rows: top ? rowsFor(batch, pdf, top) : [] }
  }
  return out
}

function jobLabel(report: string, jobName: string | null, ts: number | null): string {
  return `${report} — ${jobName || 'unnamed job'} · ${fmtTime(ts)}`
}

function jobOptions(batch: Batch, pdf: BatchPdf) {
  const cands = pdf.candidates.map((c) => ({
    value: c.conversion_id,
    label: jobLabel(c.report, c.job_name, c.converted_at ?? c.uploaded_at),
  }))
  const seen = new Set(cands.map((c) => c.value))
  const rest = batch.reports
    .filter((r) => !seen.has(r.conversion_id))
    .map((r) => ({ value: r.conversion_id, label: jobLabel(r.report, r.job_name, r.ran_at) }))
  return [...cands, ...rest]
}

// ---------------------------------------------------------------------------
// running one conversion's pages (mounts the offscreen render target)
// ---------------------------------------------------------------------------

interface RunPage {
  page: string
  display_name: string
}
interface RunOutcome {
  page: string
  display_name: string
  error?: string
}
interface QueueItem {
  conversionId: string
  label: string
  pages: RunPage[]
}

function ConversionRun({
  conversionId,
  connectionId,
  batchId,
  pages,
  onProgress,
  onDone,
}: {
  conversionId: string
  connectionId: string
  batchId: string
  pages: RunPage[]
  onProgress: (message: string) => void
  onDone: (outcomes: RunOutcome[]) => void
}) {
  const runner = useParityRunner({ conversionId, connectionId })
  const started = useRef(false)
  useEffect(() => {
    if (started.current) return
    started.current = true
    void (async () => {
      const outcomes: RunOutcome[] = []
      for (const p of pages) {
        try {
          await runner.comparePage(p.page, {
            batchId,
            onStage: (m) => onProgress(`${p.display_name}: ${m}`),
          })
          outcomes.push({ ...p })
        } catch (e) {
          outcomes.push({ ...p, error: (e as Error).message })
        }
      }
      onDone(outcomes)
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  return <>{runner.captureHost}</>
}

// ---------------------------------------------------------------------------
// results helpers
// ---------------------------------------------------------------------------

function trendValues(row: BatchReportRow): (number | null)[] {
  const t = row.trend
  if (!Array.isArray(t)) return []
  return (t as unknown[]).map((x) =>
    typeof x === 'number' ? x : x && typeof x === 'object' ? ((x as { value: number | null }).value ?? null) : null,
  )
}

function filtersText(row: BatchReportRow): string {
  const f = row.filters
  if (!f) return '—'
  if (typeof f === 'string') return f
  return f.map((x) => `${x.slicer}=${x.value}`).join(', ') || '—'
}

function hasProblems(row: BatchReportRow): boolean {
  return (
    (row.findings ?? 0) > 0 ||
    (row.visuals_mismatched ?? 0) > 0 ||
    (row.numbers_printed != null &&
      row.numbers_matched != null &&
      row.numbers_matched < row.numbers_printed)
  )
}

const rowKey = (r: { conversion_id: string; page: string }) => `${r.conversion_id}::${r.page}`

// ---------------------------------------------------------------------------
// page
// ---------------------------------------------------------------------------

export function PdfComparison() {
  const qc = useQueryClient()
  const wizardConnection = useWizard((s) => s.connectionId)
  const [files, setFiles] = useState<File[]>([])
  const [matching, setMatching] = useState(false)
  const [batch, setBatch] = useState<Batch | null>(null)
  const [sel, setSel] = useState<Record<number, PdfSelection>>({})
  const [notice, setNotice] = useState('')
  const [error, setError] = useState('')
  const [confirming, setConfirming] = useState(false)
  const [connectionId, setConnectionId] = useState<string | null>(wizardConnection)
  const [queue, setQueue] = useState<QueueItem[]>([])
  const [qIndex, setQIndex] = useState(-1) // -1 = idle
  const [progress, setProgress] = useState('')
  const [failures, setFailures] = useState<string[]>([])
  const [reportTick, setReportTick] = useState(0)
  const [detailKey, setDetailKey] = useState<string | null>(null)

  const connections = useQuery({ queryKey: ['connections'], queryFn: () => api.listConnections() })
  const effectiveConn = connectionId ?? connections.data?.[0]?.id ?? null
  const batches = useQuery({ queryKey: ['pdf-batches'], queryFn: () => batchApi.list() })
  const running = qIndex >= 0

  const report = useQuery({
    queryKey: ['pdf-batch-report', batch?.id, reportTick],
    queryFn: () => batchApi.report(batch!.id),
    enabled: !!batch?.confirmed,
  })
  const rows = report.data ?? []

  // default detail: the first page with problems (until the user picks one)
  const activeKey =
    detailKey ?? (rows.find(hasProblems) ? rowKey(rows.find(hasProblems)!) : null)
  const activeRow = rows.find((r) => rowKey(r) === activeKey) ?? null

  const detail = useQuery({
    queryKey: ['visual-compare', activeRow?.conversion_id],
    queryFn: () => parityApi.list(activeRow!.conversion_id),
    enabled: !!activeRow,
  })
  const detailPage = detail.data?.pages.find((p) => p.page === activeRow?.page)
  const fixes = useApplyFixes(activeRow?.conversion_id ?? '', activeRow?.page)

  const adopt = (b: Batch) => {
    setBatch(b)
    setSel(initialSelection(b))
    setDetailKey(null)
    setQueue([])
    setQIndex(-1)
    setFailures([])
  }

  const matchPdfs = async () => {
    setMatching(true)
    setError('')
    setNotice('')
    try {
      const b = await batchApi.create(files)
      adopt(b)
      await qc.invalidateQueries({ queryKey: ['pdf-batches'] })
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setMatching(false)
    }
  }

  const chooseJob = (pdf: BatchPdf, conversionId: string) =>
    setSel((s) => ({
      ...s,
      [pdf.index]: { conversionId, rows: rowsFor(batch!, pdf, conversionId) },
    }))

  const choosePage = (pdf: BatchPdf, pdfPage: number, page: string) =>
    setSel((s) => ({
      ...s,
      [pdf.index]: {
        ...s[pdf.index],
        rows: s[pdf.index].rows.map((r) =>
          r.pdf_page === pdfPage ? { ...r, page: page === NOT_MATCHED ? null : page, confident: true } : r,
        ),
      },
    }))

  const confirm = async () => {
    if (!batch) return
    setConfirming(true)
    setError('')
    setNotice('')
    try {
      const pdfs = batch.pdfs
        .map((p) => ({ p, s: sel[p.index] }))
        .filter(({ s }) => s?.conversionId)
        .map(({ p, s }) => ({
          file_index: p.index,
          conversion_id: s.conversionId!,
          pages: s.rows.map((r) => ({ pdf_page: r.pdf_page, page: r.page })),
        }))
      const res = await batchApi.confirm(batch.id, { pdfs })
      setBatch(res.batch)
      setNotice(
        `Stored ${res.stored} reference${res.stored === 1 ? '' : 's'}` +
          (res.superseded_comparisons
            ? `; ${res.superseded_comparisons} earlier comparison${res.superseded_comparisons === 1 ? '' : 's'} superseded`
            : '') +
          '.',
      )
      await qc.invalidateQueries({ queryKey: ['pdf-batches'] })
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setConfirming(false)
    }
  }

  /** confirmed pages grouped per conversion (one conversion is run at a time) */
  const plan = useMemo<QueueItem[]>(() => {
    if (!batch) return []
    const byConv = new Map<string, QueueItem>()
    for (const pdf of batch.pdfs) {
      const s = sel[pdf.index]
      if (!s?.conversionId) continue
      const names = reportPagesFor(batch, pdf, s.conversionId)
      const label = batch.reports.find((r) => r.conversion_id === s.conversionId)?.report ?? s.conversionId
      const item = byConv.get(s.conversionId) ?? { conversionId: s.conversionId, label, pages: [] }
      for (const r of s.rows) {
        if (!r.page || item.pages.some((p) => p.page === r.page)) continue
        item.pages.push({
          page: r.page,
          display_name: names.find((n) => n.page === r.page)?.display_name ?? r.page,
        })
      }
      byConv.set(s.conversionId, item)
    }
    return [...byConv.values()].filter((i) => i.pages.length)
  }, [batch, sel])

  const startRun = () => {
    if (!batch || !effectiveConn || !plan.length) return
    setError('')
    setFailures([])
    setQueue(plan)
    setQIndex(0)
  }

  const onConversionDone = (outcomes: RunOutcome[]) => {
    setFailures((f) => [
      ...f,
      ...outcomes.filter((o) => o.error).map((o) => `${o.display_name}: ${o.error}`),
    ])
    // this closure belongs to the ConversionRun mounted for queue[qIndex]
    if (qIndex + 1 < queue.length) {
      setQIndex(qIndex + 1)
      return
    }
    setProgress('')
    setQIndex(-1)
    setReportTick((t) => t + 1)
    void qc.invalidateQueries({ queryKey: ['visual-compare'] })
  }

  const removeBatch = async (id: string) => {
    setError('')
    try {
      await batchApi.remove(id)
      if (batch?.id === id) {
        setBatch(null)
        setSel({})
        setQueue([])
        setQIndex(-1)
      }
      await qc.invalidateQueries({ queryKey: ['pdf-batches'] })
    } catch (e) {
      setError((e as Error).message)
    }
  }

  const openBatch = async (id: string) => {
    setError('')
    setNotice('')
    try {
      adopt(await batchApi.get(id))
    } catch (e) {
      setError((e as Error).message)
    }
  }

  const current = running ? queue[qIndex] : undefined

  return (
    <div className="space-y-6">
      {/* 1. upload */}
      <section className="card p-0">
        <div className="border-b border-surface-300 px-5 py-4">
          <h2 className="text-sm font-bold">PDF comparison</h2>
          <p className="mt-0.5 text-xs text-surface-600">
            Upload one or more Power BI PDF exports. Each PDF is matched to a converted report and
            its pages are matched by content; correct anything that looks wrong, confirm, then run
            the comparison (printed numbers are checked first, then the page image).
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3 px-5 py-4">
          <label className="btn-secondary flex cursor-pointer items-center gap-2 !text-xs">
            <FileUp size={14} strokeWidth={1.8} />
            {files.length ? `${files.length} PDF${files.length === 1 ? '' : 's'} selected` : 'Choose PDFs…'}
            <input
              type="file"
              multiple
              accept="application/pdf"
              aria-label="PDF files"
              className="hidden"
              onChange={(e) => setFiles(Array.from(e.target.files ?? []))}
            />
          </label>
          <button
            className="btn-primary flex items-center gap-2 !text-xs"
            disabled={!files.length || matching || running}
            onClick={matchPdfs}
          >
            {matching ? <Loader2 size={14} className="animate-spin" /> : null}
            Match PDFs
          </button>
          {error && (
            <span role="alert" className="text-xs text-brand-red">
              {error}
            </span>
          )}
          {notice && <span className="text-xs text-surface-700">{notice}</span>}
        </div>
      </section>

      {/* 2. match table */}
      {batch && (
        <section className="card p-0" data-testid="match-table">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-surface-300 px-5 py-4">
            <h3 className="text-sm font-bold">
              Matches{' '}
              {batch.confirmed && <span className="badge-green ml-2">confirmed {fmtTime(batch.confirmed_at)}</span>}
            </h3>
            <button
              className="btn-primary flex items-center gap-2 !text-xs"
              disabled={confirming || running}
              onClick={confirm}
            >
              {confirming && <Loader2 size={14} className="animate-spin" />}
              Confirm matches
            </button>
          </div>
          <div className="divide-y divide-surface-200">
            {batch.pdfs.map((pdf) => {
              const s = sel[pdf.index]
              const pageOpts = reportPagesFor(batch, pdf, s?.conversionId ?? null)
              return (
                <div key={pdf.index} className="px-5 py-4" data-testid={`pdf-${pdf.index}`}>
                  <div className="mb-2 flex flex-wrap items-center gap-3">
                    <span className="text-sm font-semibold">{pdf.file}</span>
                    <span className="text-xs text-surface-500">{pdf.pages} pages</span>
                    {!pdf.confident && !pdf.error && (
                      <span className="badge-amber flex items-center gap-1">
                        <AlertTriangle size={11} /> low confidence
                      </span>
                    )}
                    {pdf.error && <span className="badge-red">{pdf.error}</span>}
                  </div>
                  {pdf.warnings.length > 0 && (
                    <ul className="mb-2 list-disc pl-5 text-xs text-brand-amber">
                      {pdf.warnings.map((w, i) => (
                        <li key={i}>{w}</li>
                      ))}
                    </ul>
                  )}
                  {!pdf.error && (
                    <>
                      <div className="mb-3 flex items-center gap-2">
                        <span className="text-xs text-surface-600">Job</span>
                        <SearchableSelect
                          ariaLabel={`Job for ${pdf.file}`}
                          itemLabel="jobs"
                          placeholder="Choose a job…"
                          className="!w-[34rem] max-w-full"
                          value={s?.conversionId ?? null}
                          options={jobOptions(batch, pdf)}
                          onChange={(v) => chooseJob(pdf, v)}
                        />
                      </div>
                      {s?.conversionId && (
                        <table className="w-full max-w-3xl text-left text-xs">
                          <thead>
                            <tr className="border-b border-surface-300 text-[10px] tracking-wide text-surface-500 uppercase">
                              <th className="py-1 pr-3">PDF page</th>
                              <th className="py-1 pr-3">Report page</th>
                              <th className="py-1">Confidence</th>
                            </tr>
                          </thead>
                          <tbody>
                            {s.rows.map((r) => {
                              const low = !r.confident || r.page === null
                              return (
                                <tr
                                  key={r.pdf_page}
                                  data-testid={`row-${pdf.index}-${r.pdf_page}`}
                                  data-low={low}
                                  className={`border-b border-surface-200 ${low ? 'bg-brand-amber/5' : ''}`}
                                >
                                  <td className="py-1 pr-3">
                                    <div className="flex items-center gap-2">
                                      <img
                                        src={batchApi.pageImageUrl(batch.id, pdf.index, r.pdf_page)}
                                        alt={`${pdf.file} page ${r.pdf_page}`}
                                        loading="lazy"
                                        className="h-10 rounded border border-surface-300"
                                      />
                                      {r.pdf_page}
                                    </div>
                                  </td>
                                  <td className="py-1 pr-3">
                                    <select
                                      aria-label={`${pdf.file} page ${r.pdf_page} match`}
                                      className="input !w-56 !py-1"
                                      value={r.page ?? NOT_MATCHED}
                                      onChange={(e) => choosePage(pdf, r.pdf_page, e.target.value)}
                                    >
                                      <option value={NOT_MATCHED}>Not matched</option>
                                      {pageOpts.map((p) => (
                                        <option key={p.page} value={p.page}>
                                          {p.display_name}
                                        </option>
                                      ))}
                                    </select>
                                  </td>
                                  <td className="py-1">
                                    {r.page === null ? (
                                      <span className="badge-amber">not matched</span>
                                    ) : r.confident ? (
                                      <span className="badge-green">
                                        {r.score !== undefined ? `${Math.round(r.score * 100)}%` : 'ok'}
                                      </span>
                                    ) : (
                                      <span className="badge-amber">low confidence</span>
                                    )}
                                  </td>
                                </tr>
                              )
                            })}
                          </tbody>
                        </table>
                      )}
                    </>
                  )}
                </div>
              )
            })}
          </div>
        </section>
      )}

      {/* 3. run */}
      {batch?.confirmed && (
        <section className="card p-0">
          <div className="flex flex-wrap items-center gap-3 px-5 py-4">
            <h3 className="mr-2 text-sm font-bold">Run comparison</h3>
            <select
              aria-label="Warehouse connection"
              className="input !w-56 !py-1.5"
              value={effectiveConn ?? ''}
              onChange={(e) => setConnectionId(e.target.value)}
            >
              {(connections.data ?? []).map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
            <button
              className="btn-primary flex items-center gap-2 !text-xs"
              disabled={running || !effectiveConn || !plan.length}
              onClick={startRun}
            >
              {running ? <Loader2 size={14} className="animate-spin" /> : <Play size={14} />}
              Run comparison
            </button>
            {running && (
              <span data-testid="run-progress" className="text-xs text-surface-600">
                Conversion {qIndex + 1} of {queue.length}
                {current ? ` (${current.label})` : ''}
                {progress ? ` — ${progress}` : ''}
              </span>
            )}
          </div>
          {failures.length > 0 && (
            <ul className="border-t border-surface-200 px-5 py-3 text-xs text-brand-red">
              {failures.map((f, i) => (
                <li key={i}>{f}</li>
              ))}
            </ul>
          )}
        </section>
      )}
      {current && effectiveConn && batch && (
        <ConversionRun
          key={current.conversionId}
          conversionId={current.conversionId}
          connectionId={effectiveConn}
          batchId={batch.id}
          pages={current.pages}
          onProgress={setProgress}
          onDone={onConversionDone}
        />
      )}

      {/* 4. results */}
      {batch?.confirmed && (
        <section className="card p-0" data-testid="results">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-surface-300 px-5 py-4">
            <h3 className="text-sm font-bold">Results</h3>
            <div className="flex gap-2">
              {(['json', 'xlsx'] as const).map((fmt) => (
                <a
                  key={fmt}
                  href={batchApi.reportUrl(batch.id, fmt)}
                  download
                  className="btn-secondary flex items-center gap-1.5 !text-xs"
                >
                  <Download size={13} strokeWidth={1.8} /> {fmt.toUpperCase()}
                </a>
              ))}
            </div>
          </div>
          {report.isLoading ? (
            <p className="px-5 py-4 text-xs text-surface-500">Loading results…</p>
          ) : rows.length === 0 ? (
            <p className="px-5 py-4 text-xs text-surface-500">No comparisons have run for this batch yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-surface-300 text-[10px] tracking-wide text-surface-500 uppercase">
                    <th className="px-4 py-2">Report / job</th>
                    <th className="px-4 py-2">Page</th>
                    <th className="px-4 py-2">Similarity</th>
                    <th className="px-4 py-2">Findings</th>
                    <th className="px-4 py-2">Numbers</th>
                    <th className="px-4 py-2">Visuals off</th>
                    <th className="px-4 py-2">Filters</th>
                    <th className="px-4 py-2">Trend</th>
                    <th className="px-4 py-2" />
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr
                      key={rowKey(r)}
                      data-testid={`result-${r.page}`}
                      className={`border-b border-surface-200 ${rowKey(r) === activeKey ? 'bg-brand/5' : ''}`}
                    >
                      <td className="px-4 py-2">
                        <div className="font-semibold">{r.report}</div>
                        <div className="text-surface-500">{r.job_name ?? ''}</div>
                      </td>
                      <td className="px-4 py-2">{r.display_name}</td>
                      <td className="px-4 py-2">
                        {r.similarity === null || r.similarity === undefined ? (
                          <span className="text-surface-400">—</span>
                        ) : (
                          <SimilarityBadge value={r.similarity} />
                        )}
                      </td>
                      <td className="px-4 py-2 tabular-nums">
                        {r.findings ?? '—'}
                        {r.fixable ? <span className="text-surface-500"> ({r.fixable} fixable)</span> : null}
                      </td>
                      <td className="px-4 py-2 tabular-nums">
                        {r.numbers_printed == null ? '—' : `${r.numbers_matched ?? 0} / ${r.numbers_printed}`}
                      </td>
                      <td className="px-4 py-2 tabular-nums">{r.visuals_mismatched ?? '—'}</td>
                      <td className="px-4 py-2">{filtersText(r)}</td>
                      <td className="px-4 py-2">
                        <Sparkline values={trendValues(r)} />
                      </td>
                      <td className="px-4 py-2">
                        <button
                          className="rounded-lg border border-surface-300 px-2 py-1 text-[11px] font-semibold hover:bg-surface-100"
                          aria-label={`Details for ${r.display_name}`}
                          onClick={() => setDetailKey(rowKey(r))}
                        >
                          Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {/* 5. details */}
      {batch?.confirmed && activeRow && (
        <section className="card p-0" data-testid="details">
          <div className="border-b border-surface-300 px-5 py-4">
            <h3 className="text-sm font-bold">
              {activeRow.display_name}{' '}
              <span className="font-normal text-surface-500">· {activeRow.report}</span>
              {hasProblems(activeRow) && <span className="badge-amber ml-2">needs attention</span>}
            </h3>
          </div>
          <div className="px-5 py-4">
            {detail.isLoading && <Loader2 size={16} className="animate-spin" />}
            {detailPage ? (
              <ComparisonDetail
                conversionId={activeRow.conversion_id}
                comparison={detailPage.similarity === null ? null : detailPage}
                values={detailPage.values}
                applying={fixes.applying}
                onApplyFixes={(ids) => void fixes.applyFixes(ids)}
              />
            ) : (
              !detail.isLoading && <p className="text-xs text-surface-500">No stored comparison for this page.</p>
            )}
            {fixes.error && <p className="mt-2 text-xs text-brand-red">{fixes.error}</p>}
            {detailPage && (
              <p className="mt-2 text-[11px] text-surface-500">
                After applying a fix, run the comparison again to refresh this page.
              </p>
            )}
            <h4 className="mt-5 mb-2 text-xs font-bold">Run history</h4>
            <PageHistory
              key={rowKey(activeRow)}
              conversionId={activeRow.conversion_id}
              page={activeRow.page}
            />
          </div>
        </section>
      )}

      {/* 6. history of batches */}
      <section className="card p-0" data-testid="batch-history">
        <div className="border-b border-surface-300 px-5 py-4">
          <h3 className="text-sm font-bold">History</h3>
        </div>
        {(batches.data?.batches ?? []).length === 0 ? (
          <p className="px-5 py-4 text-xs text-surface-500">No earlier batches.</p>
        ) : (
          <ul className="divide-y divide-surface-200">
            {batches.data!.batches.map((b) => (
              <li key={b.id} className="flex flex-wrap items-center gap-3 px-5 py-3 text-xs">
                <span className="w-28 tabular-nums text-surface-600">{fmtTime(b.created_at)}</span>
                <span className="min-w-0 flex-1 truncate font-semibold">{b.files.join(', ')}</span>
                <span className="text-surface-500">
                  {b.pdf_count} PDF{b.pdf_count === 1 ? '' : 's'}
                </span>
                {b.confirmed ? <span className="badge-green">confirmed</span> : <span className="badge-amber">unconfirmed</span>}
                <button
                  className="rounded-lg border border-surface-300 px-2 py-1 text-[11px] font-semibold hover:bg-surface-100"
                  aria-label={`Open batch ${b.files.join(', ')}`}
                  onClick={() => void openBatch(b.id)}
                >
                  Open
                </button>
                <button
                  className="flex items-center gap-1 rounded-lg border border-brand-red/40 px-2 py-1 text-[11px] font-semibold text-brand-red hover:bg-brand-red/5"
                  aria-label={`Delete batch ${b.files.join(', ')}`}
                  disabled={running && batch?.id === b.id}
                  onClick={() => void removeBatch(b.id)}
                >
                  <Trash2 size={12} /> Delete
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  )
}
