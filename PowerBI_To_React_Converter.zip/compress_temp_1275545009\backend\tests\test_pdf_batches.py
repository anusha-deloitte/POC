"""PDF comparison batches: upload, match, correct, confirm, report."""

from __future__ import annotations

import io

import pytest
from openpyxl import load_workbook

from app.api import pdf_batches
from tests.pdf_helpers import make_pdf
from tests.phase08 import CARD, PAGE, World
from tests.test_api import client, zip_folder  # noqa: F401

BASE = "/api/v1/visual-compare"


@pytest.fixture()
def world(client, contoso_pbip, monkeypatch):  # noqa: F811
    w = World(client, contoso_pbip, monkeypatch)
    w.pbip = contoso_pbip
    return w


def sales_pdf(value="$1.5M", title="Sales Report") -> bytes:
    runs = [
        ("Sales Overview", 24, 2, 14),
        ("Total Sales", 30, 30, 12),
        (value, 60, 70, 24),
        ("Sales by Category", 40, 180, 12),
        ("Sales Trend vs Last Year", 660, 180, 12),
    ]
    return make_pdf([{"width": 1280, "height": 720, "runs": runs}], title=title)


def files(*items):
    return [("pdfs", (name, data, "application/pdf")) for name, data in items]


def create(world, *items):
    r = world.client.post(f"{BASE}/batches", files=files(*items))
    assert r.status_code == 200, r.text
    return r.json()


def confirm_body(batch, cid=None, pdf_page=0, page=PAGE, file_index=0):
    return {
        "pdfs": [
            {
                "file_index": file_index,
                "conversion_id": cid or world_cid(batch),
                "pages": [{"pdf_page": pdf_page, "page": page}],
            }
        ]
    }


def world_cid(batch):
    return batch["pdfs"][0]["candidates"][0]["conversion_id"]


def has_reference(world):
    pages = world.get("visual-compare/references").json()["pages"]
    return next(p for p in pages if p["page"] == PAGE)["has_reference"]


def card_result(value=1_500_000.0):
    return {
        "results": [{"visual": CARD, "columns": ["Total Sales"], "rows": [[value]], "totals": None}]
    }


def test_batch_matches_pdfs_to_reports_and_stores_nothing_yet(world):
    batch = create(world, ("sales.pdf", sales_pdf()), ("broken.pdf", b"nope"))
    good, bad = batch["pdfs"]
    assert good["error"] is None and good["pages"] == 1 and good["candidates"]
    top = good["candidates"][0]
    assert top["conversion_id"] == world.cid and top["pages"][0]["page"] == PAGE
    assert top["pages"][0]["confident"] is True and top["report_pages"][0]["page"] == PAGE
    assert bad["error"] and "not a readable PDF" in bad["error"] and bad["candidates"] == []
    assert [r["conversion_id"] for r in batch["reports"]] == [world.cid]
    assert batch["reports"][0]["pages"][0]["display_name"] == "Sales Overview"
    assert batch["confirmed"] is False and has_reference(world) is False


def test_two_runs_of_one_report_tie_and_warn(world):
    second = world.client.post(
        "/api/v1/conversions", files={"file": ("c.zip", zip_folder(world.pbip), "application/zip")}
    ).json()["id"]
    batch = create(world, ("sales.pdf", sales_pdf()))
    entry = batch["pdfs"][0]
    assert {c["conversion_id"] for c in entry["candidates"]} == {world.cid, second}
    assert any("score equally" in w for w in entry["warnings"]) and entry["confident"] is False
    assert {r["conversion_id"] for r in batch["reports"]} == {world.cid, second}


def test_list_get_image_and_delete(world):
    batch = create(world, ("sales.pdf", sales_pdf()))
    bid = batch["id"]
    listing = world.client.get(f"{BASE}/batches").json()["batches"]
    assert (
        listing[0]["id"] == bid
        and listing[0]["files"] == ["sales.pdf"]
        and listing[0]["confirmed"] is False
    )
    assert world.client.get(f"{BASE}/batches/{bid}").json()["pdfs"][0]["file"] == "sales.pdf"
    img = world.client.get(f"{BASE}/batches/{bid}/pdfs/0/pages/0/image")
    assert img.status_code == 200 and img.content[:4] == b"\x89PNG"
    assert world.client.get(f"{BASE}/batches/{bid}/pdfs/0/pages/9/image").status_code == 404
    assert world.client.delete(f"{BASE}/batches/{bid}").status_code == 204
    assert world.client.get(f"{BASE}/batches/{bid}").status_code == 404
    assert world.client.get(f"{BASE}/batches").json()["batches"] == []


@pytest.mark.parametrize("bad", ["nope", "../x", "G" * 32, "a" * 31])
def test_batch_ids_are_validated(world, bad):
    assert world.client.get(f"{BASE}/batches/{bad}").status_code == 404
    assert world.client.delete(f"{BASE}/batches/{bad}").status_code == 404
    assert world.client.get(f"{BASE}/batches/{bad}/report").status_code == 404


def test_size_limits_and_empty_uploads(world, monkeypatch):
    assert world.client.post(f"{BASE}/batches").status_code == 422
    monkeypatch.setattr(pdf_batches, "MAX_PDF_BYTES", 100)
    r = world.client.post(f"{BASE}/batches", files=files(("big.pdf", sales_pdf())))
    assert r.status_code == 413
    monkeypatch.setattr(pdf_batches, "MAX_PDF_BYTES", 10_000_000)
    monkeypatch.setattr(pdf_batches, "MAX_BATCH_BYTES", len(sales_pdf()) + 10)
    r = world.client.post(
        f"{BASE}/batches", files=files(("a.pdf", sales_pdf()), ("b.pdf", sales_pdf()))
    )
    assert r.status_code == 413


def test_confirm_stores_references_after_the_user_corrects_the_matches(world):
    batch = create(world, ("sales.pdf", sales_pdf()))
    r = world.client.post(
        f"{BASE}/batches/{batch['id']}/confirm", json=confirm_body(batch, world.cid)
    )
    assert r.status_code == 200, r.text
    assert r.json()["stored"] == [{"conversion_id": world.cid, "page": PAGE, "file_index": 0}]
    assert has_reference(world) is True
    assert (world.root / "visual_compare" / f"{PAGE}_reference_text.json").is_file()
    after = world.client.get(f"{BASE}/batches/{batch['id']}").json()
    assert (
        after["confirmed"] is True
        and after["confirmed_at"]
        and after["confirmations"][0]["conversion_id"] == world.cid
    )
    assert world.client.get(f"{BASE}/batches").json()["batches"][0]["confirmed"] is True


def test_confirm_validates_everything_before_storing_anything(world):
    batch = create(world, ("sales.pdf", sales_pdf()), ("broken.pdf", b"nope"))
    url = f"{BASE}/batches/{batch['id']}/confirm"
    ok = {"file_index": 0, "conversion_id": world.cid, "pages": [{"pdf_page": 0, "page": PAGE}]}
    cases = [
        (
            {"pdfs": [ok, {"file_index": 1, "conversion_id": world.cid, "pages": []}]},
            422,
        ),  # unreadable PDF
        (
            {"pdfs": [ok, {"file_index": 7, "conversion_id": world.cid, "pages": []}]},
            422,
        ),  # unknown PDF
        ({"pdfs": [ok, {**ok, "pages": [{"pdf_page": 0, "page": "nope"}]}]}, 422),  # unknown page
        ({"pdfs": [ok, {**ok, "pages": [{"pdf_page": 5, "page": PAGE}]}]}, 422),  # out of range
        ({"pdfs": [ok, ok]}, 422),  # the same page assigned twice
        ({"pdfs": [ok, {**ok, "conversion_id": "00000000-0000-0000-0000-000000000000"}]}, 404),
    ]
    for body, status in cases:
        assert world.client.post(url, json=body).status_code == status, body
        assert has_reference(world) is False  # all or nothing
    assert world.client.get(f"{BASE}/batches/{batch['id']}").json()["confirmed"] is False


def test_report_uses_the_batchs_own_runs_in_json_and_xlsx(world):
    batch = create(world, ("sales.pdf", sales_pdf()))
    bid = batch["id"]
    world.client.post(f"{BASE}/batches/{bid}/confirm", json=confirm_body(batch, world.cid))
    world.post(f"visual-compare/{PAGE}/values", {**card_result(), "batch_id": bid})
    world.post(f"visual-compare/{PAGE}/values", {**card_result(9e6), "batch_id": bid})
    world.post(
        f"visual-compare/{PAGE}/values", {**card_result(), "batch_id": "b" * 32}
    )  # another batch

    r = world.client.get(f"{BASE}/batches/{bid}/report", params={"format": "json"})
    assert r.status_code == 200 and "attachment" in r.headers["content-disposition"]
    rows = r.json()["rows"]
    assert len(rows) == 2 and {x["kind"] for x in rows} == {"values"}
    assert [x["visuals_mismatched"] for x in rows] == [
        0,
        1,
    ]  # both snapshots are kept, oldest first
    assert rows[0]["display_name"] == "Sales Overview" and rows[0]["conversion_id"] == world.cid
    assert rows[1]["trend"][-1] is not None

    x = world.client.get(f"{BASE}/batches/{bid}/report", params={"format": "xlsx"})
    assert x.status_code == 200 and x.headers["content-type"].startswith(
        "application/vnd.openxmlformats"
    )
    sheet = load_workbook(io.BytesIO(x.content)).active
    header = [c.value for c in sheet[1]]
    assert header[:5] == ["Report", "Job", "Job run", "Page", "Check"] and sheet.max_row == 3
    assert (
        world.client.get(f"{BASE}/batches/{bid}/report", params={"format": "csv"}).status_code
        == 422
    )


def test_report_of_an_unconfirmed_batch_is_empty(world):
    batch = create(world, ("sales.pdf", sales_pdf()))
    body = world.client.get(f"{BASE}/batches/{batch['id']}/report").json()
    assert body["rows"] == [] and body["batch"]["id"] == batch["id"]


def test_deleting_a_batch_keeps_the_page_history(world):
    batch = create(world, ("sales.pdf", sales_pdf()))
    world.client.post(f"{BASE}/batches/{batch['id']}/confirm", json=confirm_body(batch, world.cid))
    world.post(f"visual-compare/{PAGE}/values", {**card_result(), "batch_id": batch["id"]})
    world.client.delete(f"{BASE}/batches/{batch['id']}")
    assert len(world.get(f"visual-compare/{PAGE}/history").json()["runs"]) == 1
