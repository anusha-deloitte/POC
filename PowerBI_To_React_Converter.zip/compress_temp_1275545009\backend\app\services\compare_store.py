"""Reference storage shared by the single-PDF upload and the PDF batch confirm.

A page's reference is `visual_compare/<page>_reference.png` plus, when it came from a PDF with
text, `<page>_reference_text.json` (positioned runs, for the number checks). Storing a different
reference marks the comparisons made against the old one stale.
"""

from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any

SIDE_SUFFIXES = ("_values.json", "_reference_text.json")  # not image-comparison results


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def compare_dir(conv_dir: Path) -> Path:
    out = Path(conv_dir) / "visual_compare"
    out.mkdir(exist_ok=True)
    return out


def is_result_file(path: Path) -> bool:
    """A `visual_compare/*.json` that is an image-comparison result (not a side file)."""
    return path.suffix == ".json" and not path.name.endswith(SIDE_SUFFIXES)


def _mark_stale(path: Path, new_sha: str, reason: str) -> bool:
    if not path.is_file():
        return False
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except ValueError:
        return False
    if payload.get("reference_sha") == new_sha:
        return False
    payload["stale"] = True
    payload["stale_reason"] = reason
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return True


def store_reference(
    conv_dir: Path, page: str, png: bytes, text: dict[str, Any] | None, source: str
) -> bool:
    """Save a page's reference image (and PDF text); True when it superseded a comparison made
    against a different earlier reference."""
    out = compare_dir(conv_dir)
    new_sha = sha256(png)
    reason = "reference image replaced after this comparison ran"
    superseded = _mark_stale(out / f"{page}.json", new_sha, reason)
    superseded = _mark_stale(out / f"{page}_values.json", new_sha, reason) or superseded
    (out / f"{page}_reference.png").write_bytes(png)
    text_path = out / f"{page}_reference_text.json"
    if text is not None:
        text_path.write_text(
            json.dumps(
                {"reference_sha": new_sha, "source": source, "stored_at": time.time(), **text}
            ),
            encoding="utf-8",
        )
    else:
        text_path.unlink(missing_ok=True)  # an image-only reference has no text to check
    return superseded
