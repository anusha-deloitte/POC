/** Logic of the Filters pane: card state, clauses, summaries, Basic selection, bookmarks.
 * (Named `filtersPaneState.ts`, not `filtersPane.ts`: on Windows that collides with
 * `FiltersPane.tsx` in TypeScript module resolution.) */
import type {
  DashboardSpec,
  FilterCard,
  FilterCardKind,
  FilterClause,
  FilterCondition,
  FilterDefault,
  FilterPaneSettings,
  PageSpec,
} from './types'

export const BLANK_LABEL = '(Blank)'

export type CardValue = FilterDefault | null
export interface CardState {
  kind: FilterCardKind
  value: CardValue
}
export type PaneState = Record<string, CardState>

/** `report:<card>` (kept across pages) / `page:<page>:<card>` (per page), for the session. */
export function cardKey(card: FilterCard, pageName: string): string {
  return card.scope === 'report' ? `report:${card.name}` : `page:${pageName}:${card.name}`
}

// ---------------------------------------------------------------- clauses

/** TS twin of the backend's `card_clauses`. */
export function cardClauses(card: FilterCard, value: CardValue = card.default): FilterClause[] {
  if (!card.supported || !value || !card.table || !card.column) return []
  const source = `${card.scope}_filter`
  const clauses: FilterClause[] = value.conditions.map((c) => ({
    table: card.table!,
    column: card.column!,
    op: c.op,
    values: [...c.values],
    params: { ...c.params },
    source,
  }))
  if (value.join === 'or' && clauses.length > 1)
    return [{ table: card.table, column: card.column, op: 'or', values: [], clauses, source }]
  return clauses
}

export function pageCards(
  spec: Pick<DashboardSpec, 'report_filters'>,
  page: Pick<PageSpec, 'filters'> | undefined,
): { page: FilterCard[]; report: FilterCard[] } {
  return { page: page?.filters ?? [], report: spec.report_filters ?? [] }
}

export function defaultFilterClauses(
  spec: Pick<DashboardSpec, 'report_filters'>,
  page: Pick<PageSpec, 'filters'> | undefined,
): FilterClause[] {
  const cards = pageCards(spec, page)
  return [...cards.report, ...cards.page].flatMap((c) => cardClauses(c))
}

// ---------------------------------------------------------------- card state

const sameValue = (a: CardValue, b: CardValue) => JSON.stringify(a) === JSON.stringify(b)

/** The card as the user currently has it: their value unless the card is unsupported / locked /
 * hidden (those keep their saved default). */
export function currentCard(card: FilterCard, pageName: string, state: PaneState): CardState {
  const saved: CardState = { kind: card.kind, value: card.default }
  if (!card.supported || card.locked || card.hidden) return saved
  return state[cardKey(card, pageName)] ?? saved
}

export const cardValue = (card: FilterCard, pageName: string, state: PaneState): CardValue =>
  currentCard(card, pageName, state).value

export function isModified(card: FilterCard, pageName: string, state: PaneState): boolean {
  const now = currentCard(card, pageName, state)
  return now.kind !== card.kind || !sameValue(now.value, card.default)
}

export function paneModified(
  spec: Pick<DashboardSpec, 'report_filters'>,
  page: Pick<PageSpec, 'name' | 'filters'>,
  state: PaneState,
): boolean {
  const cards = pageCards(spec, page)
  return [...cards.report, ...cards.page].some((c) => isModified(c, page.name, state))
}

/** The pane's clauses for a page: hidden / locked cards keep their saved default. */
export function paneClauses(
  spec: Pick<DashboardSpec, 'report_filters'>,
  page: Pick<PageSpec, 'name' | 'filters'> | undefined,
  state: PaneState,
): FilterClause[] {
  if (!page) return []
  const cards = pageCards(spec, page)
  return [...cards.report, ...cards.page].flatMap((c) =>
    cardClauses(c, cardValue(c, page.name, state)),
  )
}

/** Drops the keys of the cards this page's pane shows. */
export function resetPane(state: PaneState, pageName: string): PaneState {
  return Object.fromEntries(
    Object.entries(state).filter(([k]) => !k.startsWith('report:') && !k.startsWith(`page:${pageName}:`)),
  )
}

export function setCard(state: PaneState, card: FilterCard, pageName: string, next: CardState): PaneState {
  return { ...state, [cardKey(card, pageName)]: next }
}

export const searchCards = (cards: FilterCard[], query: string): FilterCard[] => {
  const q = query.trim().toLowerCase()
  return q ? cards.filter((c) => c.display_name.toLowerCase().includes(q)) : cards
}

export function paneWidth(
  page: { filter_pane?: FilterPaneSettings | null } | undefined,
  report: { filter_pane?: FilterPaneSettings | null } | undefined,
): number {
  return page?.filter_pane?.width ?? report?.filter_pane?.width ?? 260
}

/** Whether the pane starts open: the page setting, else the report's; collapsed when false. */
export function paneExpanded(
  page: { filter_pane?: FilterPaneSettings | null } | undefined,
  report: { filter_pane?: FilterPaneSettings | null } | undefined,
): boolean {
  return page?.filter_pane?.expanded ?? report?.filter_pane?.expanded ?? false
}

export function paneVisible(
  page: { filter_pane?: FilterPaneSettings | null } | undefined,
  report: { filter_pane?: FilterPaneSettings | null } | undefined,
): boolean {
  return (page?.filter_pane?.visible ?? report?.filter_pane?.visible) !== false
}

// ---------------------------------------------------------------- operators and text

export const formatValue = (v: string | number | boolean | null | undefined): string =>
  v === null || v === undefined ? BLANK_LABEL : String(v)

export interface OperatorOption {
  label: string
  op: string
  needsValue: boolean
}

export const TEXT_OPERATORS: OperatorOption[] = [
  { label: 'contains', op: 'contains', needsValue: true },
  { label: 'does not contain', op: 'not_contains', needsValue: true },
  { label: 'starts with', op: 'starts_with', needsValue: true },
  { label: 'does not start with', op: 'not_starts_with', needsValue: true },
  { label: 'is', op: 'eq', needsValue: true },
  { label: 'is not', op: 'neq', needsValue: true },
  { label: 'is blank', op: 'is_blank', needsValue: false },
  { label: 'is not blank', op: 'is_not_blank', needsValue: false },
  { label: 'is empty', op: 'is_empty', needsValue: false },
  { label: 'is not empty', op: 'is_not_empty', needsValue: false },
]

export const NUMBER_OPERATORS: OperatorOption[] = [
  { label: 'is less than', op: 'lt', needsValue: true },
  { label: 'is less than or equal to', op: 'lte', needsValue: true },
  { label: 'is greater than', op: 'gt', needsValue: true },
  { label: 'is greater than or equal to', op: 'gte', needsValue: true },
  { label: 'is', op: 'eq', needsValue: true },
  { label: 'is not', op: 'neq', needsValue: true },
  { label: 'is blank', op: 'is_blank', needsValue: false },
  { label: 'is not blank', op: 'is_not_blank', needsValue: false },
]

const NUMERIC_TYPES = new Set(['int64', 'double', 'decimal', 'currency', 'number', 'integer', 'datetime', 'date', 'time'])

export const isNumericType = (dataType: string | null | undefined): boolean =>
  NUMERIC_TYPES.has((dataType ?? '').toLowerCase())

export const operatorsFor = (dataType: string | null | undefined): OperatorOption[] =>
  isNumericType(dataType) ? NUMBER_OPERATORS : TEXT_OPERATORS

const opLabel = (op: string): string =>
  [...TEXT_OPERATORS, ...NUMBER_OPERATORS].find((o) => o.op === op)?.label ?? op

const LIST_PREFIX: Record<string, string> = { in: 'is', not_in: 'is not' }

export function topnText(params: Record<string, unknown>): string {
  const direction = params.direction === 'bottom' ? 'Bottom' : 'Top'
  const by = params.measure
    ? `[${String(params.measure)}]`
    : `${String(params.aggregate ?? 'Sum')} of ${String(params.column ?? '')}`
  return `${direction} ${String(params.n)} by ${by}`
}

interface RelativeUi {
  direction: 'last' | 'next' | 'this'
  n: number
  unit: string
  calendar: boolean
  include_today: boolean
}

const plural = (unit: string, n: number) => (n === 1 ? unit : `${unit}s`)

export function relativeText(params: Record<string, unknown>): string {
  const ui = params.ui as RelativeUi | undefined
  if (!ui) return 'is in a custom relative range'
  if (ui.direction === 'this') return `is in this ${ui.unit}`
  let text = `is in the ${ui.direction} ${ui.n} ${plural(ui.unit, ui.n)}`
  if (ui.calendar && ui.unit !== 'day' && ui.unit !== 'minute' && ui.unit !== 'hour') text += ' (calendar)'
  else if (ui.include_today && ui.unit !== 'minute' && ui.unit !== 'hour') text += ', including today'
  return text
}

function conditionText(c: FilterCondition): string {
  if (c.op === 'topn') return topnText(c.params)
  if (c.op === 'relative') return relativeText(c.params)
  const prefix = LIST_PREFIX[c.op]
  if (prefix) return `${prefix} ${c.values.map(formatValue).join(', ')}`
  const needs = TEXT_OPERATORS.concat(NUMBER_OPERATORS).find((o) => o.op === c.op)?.needsValue ?? true
  return needs ? `${opLabel(c.op)} ${c.values.map(formatValue).join(', ')}` : opLabel(c.op)
}

/** The one-line summary of a collapsed card. */
export function cardSummary(card: FilterCard, value: CardValue = card.default): string {
  if (!card.supported) return card.reason ?? 'not supported'
  if (!value || value.conditions.length === 0) return 'is (All)'
  return value.conditions.map(conditionText).join(` ${value.join} `)
}

// ---------------------------------------------------------------- relative bounds (twin of 2.7)

type Tree = Record<string, unknown>
const UNIT_CODE: Record<string, number> = { day: 0, week: 1, month: 2, year: 3, minute: 6, hour: 7 }
const NOW: Tree = { Now: {} }
const add = (expr: Tree, amount: number, unit: string): Tree => ({
  DateAdd: { Expression: expr, Amount: amount, TimeUnit: UNIT_CODE[unit] },
})
const span = (expr: Tree, unit: string): Tree => ({
  DateSpan: { Expression: expr, TimeUnit: UNIT_CODE[unit] },
})

/** The PBIR (lower, upper) bound trees of a relative card UI; identical to the backend's. */
export function relativeBounds(ui: Partial<RelativeUi> & Pick<RelativeUi, 'direction' | 'unit'>): [Tree, Tree] {
  const n = Math.trunc(ui.n ?? 1)
  const { direction, unit } = ui
  if (direction === 'this') return [span(NOW, unit), span(NOW, unit)]
  if (unit === 'minute' || unit === 'hour')
    return direction === 'last' ? [add(NOW, -n, unit), NOW] : [NOW, add(NOW, n, unit)]
  if (ui.calendar && unit !== 'day')
    return direction === 'last'
      ? [span(add(NOW, -n, unit), unit), span(add(NOW, -1, unit), unit)]
      : [span(add(NOW, 1, unit), unit), span(add(NOW, n, unit), unit)]
  const include = !!ui.include_today
  if (direction === 'last')
    return include
      ? [span(add(add(NOW, 1, 'day'), -n, unit), 'day'), span(NOW, 'day')]
      : [span(add(NOW, -n, unit), 'day'), span(add(NOW, -1, 'day'), 'day')]
  return include
    ? [span(NOW, 'day'), span(add(add(NOW, -1, 'day'), n, unit), 'day')]
    : [span(add(NOW, 1, 'day'), 'day'), span(add(NOW, n, unit), 'day')]
}

/** A relative condition built from the card UI. */
export function relativeCondition(ui: RelativeUi, time: boolean): FilterCondition {
  const [lower, upper] = relativeBounds(ui)
  return { op: 'relative', values: [], params: { lower, upper, time, ui } }
}

// ---------------------------------------------------------------- Basic selection

export interface BasicSelection {
  /** "Select all" then unchecked items: `values` are the UNCHECKED ones */
  inverted: boolean
  values: (string | number | boolean | null)[]
}

export function basicSelection(value: CardValue): BasicSelection {
  if (!value || value.conditions.length === 0) return { inverted: true, values: [] }
  const c = value.conditions[0]
  if (value.conditions.length === 1 && c.op === 'not_in') return { inverted: true, values: [...c.values] }
  if (value.conditions.length === 1 && (c.op === 'in' || c.op === 'eq')) return { inverted: false, values: [...c.values] }
  return { inverted: false, values: [] }
}

/** (All) when inverted with nothing unchecked. */
export function basicValue(sel: BasicSelection): CardValue {
  if (sel.inverted && sel.values.length === 0) return null
  return {
    join: 'and',
    conditions: [{ op: sel.inverted ? 'not_in' : 'in', values: [...sel.values], params: {} }],
  }
}

const same = (a: unknown, b: unknown) => a === b || (a == null && b == null)

export const isChecked = (sel: BasicSelection, v: string | number | boolean | null): boolean =>
  sel.values.some((x) => same(x, v)) !== sel.inverted

export function toggleValue(
  sel: BasicSelection,
  v: string | number | boolean | null,
  single = false,
): BasicSelection {
  if (single) return { inverted: false, values: [v] } // Require single selection replaces
  const has = sel.values.some((x) => same(x, v))
  const values = has ? sel.values.filter((x) => !same(x, v)) : [...sel.values, v]
  return { inverted: sel.inverted, values }
}

export const selectAll = (): BasicSelection => ({ inverted: true, values: [] })

// ---------------------------------------------------------------- bookmarks

export interface FilterValues {
  report?: Record<string, FilterDefault | null>
  pages?: Record<string, Record<string, FilterDefault | null>>
  slicers?: Record<string, (string | number)[]>
}

export interface PaneRestore {
  pane: PaneState
  slicers: Record<string, (string | number)[]>
  sync: Record<string, (string | number)[]>
}

/** Restores the pane values and slicer / sync state a bookmark captured. Cards it does not
 * mention keep their current values. */
export function applyBookmarkFilters(
  spec: DashboardSpec,
  filterValues: FilterValues | undefined,
  current: PaneRestore,
): PaneRestore {
  if (!filterValues) return current
  const pane = { ...current.pane }
  const slicers = { ...current.slicers }
  const sync = { ...current.sync }
  const visit = (cards: FilterCard[], pageName: string, values: Record<string, FilterDefault | null> | undefined) => {
    for (const card of cards)
      if (values && card.name in values) pane[cardKey(card, pageName)] = { kind: card.kind, value: values[card.name] }
  }
  visit(spec.report_filters ?? [], '', filterValues.report)
  for (const page of spec.pages) visit(page.filters ?? [], page.name, filterValues.pages?.[page.name])
  const groupOf = new Map<string, { name: string; filter_changes?: boolean | null }>()
  for (const page of spec.pages)
    for (const v of page.visuals) if (v.sync_group) groupOf.set(v.name, v.sync_group)
  for (const [visual, values] of Object.entries(filterValues.slicers ?? {})) {
    const group = groupOf.get(visual)
    if (group?.filter_changes) {
      if (values.length) sync[group.name] = values
      else delete sync[group.name]
    } else {
      slicers[visual] = values
    }
  }
  return { pane, slicers, sync }
}
