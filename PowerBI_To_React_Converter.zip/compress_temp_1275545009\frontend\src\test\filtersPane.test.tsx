import { describe, expect, it } from 'vitest'
import { applySlicerChange, withSlicerDefaults } from '../dashboard/canvas'
import {
  applyBookmarkFilters,
  basicSelection,
  basicValue,
  BLANK_LABEL,
  cardClauses,
  cardKey,
  cardSummary,
  cardValue,
  currentCard,
  defaultFilterClauses,
  formatValue,
  isChecked,
  isModified,
  isNumericType,
  NUMBER_OPERATORS,
  operatorsFor,
  paneClauses,
  paneExpanded,
  paneModified,
  paneVisible,
  paneWidth,
  relativeBounds,
  relativeCondition,
  relativeText,
  resetPane,
  searchCards,
  selectAll,
  setCard,
  TEXT_OPERATORS,
  toggleValue,
  topnText,
  type PaneState,
} from '../dashboard/filtersPaneState'
import type { DashboardSpec, FilterCard, FilterDefault, PageSpec } from '../dashboard/types'

const cond = (op: string, ...values: (string | number | null)[]) => ({ op, values, params: {} })
const def = (join: 'and' | 'or', ...conditions: ReturnType<typeof cond>[]): FilterDefault => ({ join, conditions })

function card(name: string, over: Partial<FilterCard> = {}): FilterCard {
  return {
    name, scope: 'page', table: 'Customer', column: 'Country', display_name: name, data_type: 'string',
    kind: 'basic', default: null, require_single: false, hidden: false, locked: false, supported: true,
    ...over,
  }
}

const spec = (report: FilterCard[], pages: PageSpec[]): DashboardSpec =>
  ({
    report_name: 'r', pages, warnings: [], measure_tiers: { Sales: 0 }, theme: { data_colors: [], text_classes: {} },
    interaction_graph: { nodes: [], edges: [], sync_groups: {} }, bookmarks: [], drill_through: [],
    report_filters: report,
  }) as DashboardSpec
const page = (name: string, filters: FilterCard[] = [], visuals: PageSpec['visuals'] = []): PageSpec => ({
  name, display_name: name, width: 1280, height: 720, ordinal: 0, filters, visuals,
})

describe('card summaries', () => {
  it('describes a collapsed card in one line', () => {
    expect(cardSummary(card('c', { default: def('and', cond('in', 'Monthly')) }))).toBe('is Monthly')
    expect(cardSummary(card('c', { default: def('and', cond('not_in', 'UNK')) }))).toBe('is not UNK')
    expect(cardSummary(card('c', { default: def('and', cond('in', 'A', 'B', null)) }))).toBe('is A, B, (Blank)')
    expect(cardSummary(card('c', { default: null }))).toBe('is (All)')
    expect(cardSummary(card('c', { default: def('or', cond('contains', 'x'), cond('eq', 'y')) }))).toBe('contains x or is y')
    expect(cardSummary(card('c', { default: def('and', cond('gt', 5), cond('lte', 9)) }))).toBe('is greater than 5 and is less than or equal to 9')
    expect(cardSummary(card('c', { default: def('and', cond('is_blank')) }))).toBe('is blank')
  })

  it('shows the reason of an unsupported card', () => {
    expect(cardSummary(card('c', { supported: false, reason: 'filter condition shape not supported' }))).toBe(
      'filter condition shape not supported',
    )
  })

  it('Top N and relative cards read like Power BI', () => {
    expect(topnText({ n: 5, direction: 'top', measure: 'Sales' })).toBe('Top 5 by [Sales]')
    expect(topnText({ n: 3, direction: 'bottom', table: 'T', column: 'X', aggregate: 'Sum' })).toBe('Bottom 3 by Sum of X')
    const ui = (over: object) => ({ ui: { direction: 'last', n: 2, unit: 'month', calendar: true, include_today: false, ...over } })
    expect(relativeText(ui({}))).toBe('is in the last 2 months (calendar)')
    expect(relativeText(ui({ direction: 'this', n: 1 }))).toBe('is in this month')
    expect(relativeText(ui({ n: 7, unit: 'day', calendar: false, include_today: true }))).toBe('is in the last 7 days, including today')
    expect(relativeText(ui({ n: 1, calendar: false }))).toBe('is in the last 1 month')
    expect(relativeText({})).toBe('is in a custom relative range')
    expect(
      cardSummary(card('t', { kind: 'topn', default: def('and', { op: 'topn', values: [], params: { n: 5, direction: 'top', measure: 'Sales' } }) })),
    ).toBe('Top 5 by [Sales]')
  })

  it('formats blanks', () => {
    expect(formatValue(null)).toBe(BLANK_LABEL)
    expect(formatValue('x')).toBe('x')
    expect(formatValue(3)).toBe('3')
  })
})

describe('clauses', () => {
  it('turn a saved default into engine filters tagged with their scope', () => {
    const c = card('c', { scope: 'report', default: def('and', cond('in', 'US'), cond('neq', 'DE')) })
    expect(cardClauses(c)).toEqual([
      { table: 'Customer', column: 'Country', op: 'in', values: ['US'], params: {}, source: 'report_filter' },
      { table: 'Customer', column: 'Country', op: 'neq', values: ['DE'], params: {}, source: 'report_filter' },
    ])
  })

  it('an Or card is one or-clause over its conditions', () => {
    const c = card('c', { default: def('or', cond('contains', 'U'), cond('eq', 'DE')) })
    const [clause] = cardClauses(c)
    expect(clause).toMatchObject({ op: 'or', source: 'page_filter' })
    expect(clause.clauses!.map((x) => x.op)).toEqual(['contains', 'eq'])
    expect(cardClauses(card('c', { default: def('or', cond('eq', 'DE')) }))).toHaveLength(1)
    expect(cardClauses(card('c', { default: def('or', cond('eq', 'DE')) }))[0].op).toBe('eq')
  })

  it('unsupported cards and (All) give none', () => {
    expect(cardClauses(card('c', { supported: false, default: def('and', cond('eq', 'x')) }))).toEqual([])
    expect(cardClauses(card('c', { default: null }))).toEqual([])
  })

  it('defaults include report and page cards, hidden and locked ones too', () => {
    const r = card('r', { scope: 'report', column: 'Region', default: def('and', cond('in', 'EU')), hidden: true })
    const p = card('p', { default: def('and', cond('in', 'US')), locked: true })
    const s = spec([r], [page('p1', [p])])
    expect(defaultFilterClauses(s, s.pages[0]).map((c) => c.column)).toEqual(['Region', 'Country'])
  })
})

describe('pane state', () => {
  const r = card('r', { scope: 'report', column: 'Region', default: def('and', cond('in', 'EU')) })
  const p = card('p', { default: def('and', cond('in', 'US')) })
  const hidden = card('h', { default: def('and', cond('in', 'FR')), hidden: true, column: 'City' })
  const locked = card('l', { default: def('and', cond('in', 'DE')), locked: true, column: 'Segment' })
  const s = spec([r], [page('p1', [p, hidden, locked]), page('p2', [card('p', { default: null })])])

  it('keys: report cards are kept across pages, page cards per page', () => {
    expect(cardKey(r, 'p1')).toBe('report:r')
    expect(cardKey(r, 'p2')).toBe('report:r')
    expect(cardKey(p, 'p1')).toBe('page:p1:p')
    expect(cardKey(p, 'p2')).toBe('page:p2:p')
  })

  it('the user value wins unless the card is locked, hidden or unsupported', () => {
    let state: PaneState = {}
    for (const c of [p, hidden, locked]) state = setCard(state, c, 'p1', { kind: 'basic', value: def('and', cond('in', 'XX')) })
    expect(cardValue(p, 'p1', state)).toEqual(def('and', cond('in', 'XX')))
    expect(cardValue(hidden, 'p1', state)).toEqual(hidden.default)
    expect(cardValue(locked, 'p1', state)).toEqual(locked.default)
    const bad = card('b', { supported: false, default: null })
    expect(currentCard(bad, 'p1', setCard({}, bad, 'p1', { kind: 'basic', value: def('and', cond('in', 'x')) })).value).toBeNull()
  })

  it('isModified compares value and kind with the saved default', () => {
    expect(isModified(p, 'p1', {})).toBe(false)
    expect(isModified(p, 'p1', setCard({}, p, 'p1', { kind: 'basic', value: p.default }))).toBe(false)
    expect(isModified(p, 'p1', setCard({}, p, 'p1', { kind: 'basic', value: null }))).toBe(true)
    expect(isModified(p, 'p1', setCard({}, p, 'p1', { kind: 'advanced', value: p.default }))).toBe(true)
    expect(paneModified(s, s.pages[0], {})).toBe(false)
    expect(paneModified(s, s.pages[0], setCard({}, r, 'p1', { kind: 'basic', value: null }))).toBe(true)
  })

  it('pane clauses keep hidden and locked cards at their saved default', () => {
    let state: PaneState = {}
    state = setCard(state, p, 'p1', { kind: 'basic', value: def('and', cond('in', 'CA')) })
    state = setCard(state, hidden, 'p1', { kind: 'basic', value: null })
    state = setCard(state, locked, 'p1', { kind: 'basic', value: null })
    const clauses = paneClauses(s, s.pages[0], state)
    expect(clauses.map((c) => [c.column, c.values[0]])).toEqual([
      ['Region', 'EU'],
      ['Country', 'CA'],
      ['City', 'FR'],
      ['Segment', 'DE'],
    ])
    expect(paneClauses(s, undefined, state)).toEqual([])
  })

  it('reset drops this page\'s keys and the report cards it shows, not other pages', () => {
    let state: PaneState = {}
    state = setCard(state, p, 'p1', { kind: 'basic', value: null })
    state = setCard(state, p, 'p2', { kind: 'basic', value: null })
    state = setCard(state, r, 'p1', { kind: 'basic', value: null })
    expect(Object.keys(resetPane(state, 'p1'))).toEqual(['page:p2:p'])
  })

  it('searches card titles case-insensitively', () => {
    const cards = [card('Country'), card('Product Category'), card('Year')]
    expect(searchCards(cards, 'COUNT').map((c) => c.name)).toEqual(['Country'])
    expect(searchCards(cards, ' ').length).toBe(3)
    expect(searchCards(cards, 'zzz')).toEqual([])
  })
})

describe('pane settings', () => {
  const settings = (over: object) => ({ colours: {}, ...over })
  it('width: page, then report, then 260', () => {
    expect(paneWidth({ filter_pane: settings({ width: 300 }) }, { filter_pane: settings({ width: 200 }) })).toBe(300)
    expect(paneWidth({ filter_pane: null }, { filter_pane: settings({ width: 200 }) })).toBe(200)
    expect(paneWidth(undefined, undefined)).toBe(260)
  })

  it('expanded: the page setting, else the report, collapsed otherwise', () => {
    expect(paneExpanded({ filter_pane: settings({ expanded: true }) }, { filter_pane: settings({ expanded: false }) })).toBe(true)
    expect(paneExpanded({ filter_pane: null }, { filter_pane: settings({ expanded: true }) })).toBe(true)
    expect(paneExpanded({ filter_pane: settings({ expanded: false }) }, undefined)).toBe(false)
    expect(paneExpanded(undefined, undefined)).toBe(false)
  })

  it('visible unless explicitly false', () => {
    expect(paneVisible(undefined, undefined)).toBe(true)
    expect(paneVisible({ filter_pane: settings({ visible: false }) }, undefined)).toBe(false)
    expect(paneVisible({ filter_pane: null }, { filter_pane: settings({ visible: false }) })).toBe(false)
    expect(paneVisible({ filter_pane: settings({ visible: true }) }, { filter_pane: settings({ visible: false }) })).toBe(true)
  })
})

describe('operators', () => {
  it('lists operators per data type', () => {
    expect(TEXT_OPERATORS.map((o) => o.label)).toEqual([
      'contains', 'does not contain', 'starts with', 'does not start with', 'is', 'is not',
      'is blank', 'is not blank', 'is empty', 'is not empty',
    ]) // prettier-ignore
    expect(NUMBER_OPERATORS.map((o) => o.label)).toEqual([
      'is less than', 'is less than or equal to', 'is greater than', 'is greater than or equal to',
      'is', 'is not', 'is blank', 'is not blank',
    ]) // prettier-ignore
    for (const t of ['int64', 'double', 'decimal', 'currency', 'number', 'integer', 'datetime', 'date', 'time'])
      expect(isNumericType(t)).toBe(true)
    expect(isNumericType('string')).toBe(false)
    expect(operatorsFor('double')).toBe(NUMBER_OPERATORS)
    expect(operatorsFor('string')).toBe(TEXT_OPERATORS)
    expect(operatorsFor(null)).toBe(TEXT_OPERATORS)
  })
})

describe('Basic selection', () => {
  it('(All) is inverted with nothing unchecked', () => {
    expect(basicSelection(null)).toEqual({ inverted: true, values: [] })
    expect(basicValue({ inverted: true, values: [] })).toBeNull()
  })

  it('"Select all" then unchecked items becomes not_in', () => {
    const sel = toggleValue(selectAll(), 'DE')
    expect(sel).toEqual({ inverted: true, values: ['DE'] })
    expect(basicValue(sel)).toEqual(def('and', cond('not_in', 'DE')))
    expect(isChecked(sel, 'DE')).toBe(false)
    expect(isChecked(sel, 'US')).toBe(true)
    expect(toggleValue(sel, 'DE').values).toEqual([]) // checked again
  })

  it('an explicit selection becomes in; blanks are values like any other', () => {
    let sel = basicSelection(def('and', cond('in', 'US')))
    expect(sel).toEqual({ inverted: false, values: ['US'] })
    sel = toggleValue(sel, null)
    expect(basicValue(sel)).toEqual(def('and', cond('in', 'US', null)))
    expect(isChecked(sel, null)).toBe(true)
    expect(isChecked(sel, 'DE')).toBe(false)
    expect(basicSelection(def('and', cond('not_in', 'UNK')))).toEqual({ inverted: true, values: ['UNK'] })
  })

  it('Require single selection replaces the choice', () => {
    const one = toggleValue({ inverted: false, values: ['US'] }, 'DE', true)
    expect(one).toEqual({ inverted: false, values: ['DE'] })
    expect(toggleValue(selectAll(), 'DE', true)).toEqual({ inverted: false, values: ['DE'] })
  })
})

describe('relativeBounds (the twin of the backend)', () => {
  const NOW = { Now: {} }
  const add = (e: object, amount: number, unit: number) => ({ DateAdd: { Expression: e, Amount: amount, TimeUnit: unit } })
  const span = (e: object, unit: number) => ({ DateSpan: { Expression: e, TimeUnit: unit } })

  it('produces the same trees as runtime/filter_cards.relative_bounds', () => {
    expect(relativeBounds({ direction: 'this', unit: 'month', n: 1 })).toEqual([span(NOW, 2), span(NOW, 2)])
    expect(relativeBounds({ direction: 'last', n: 90, unit: 'minute' })).toEqual([add(NOW, -90, 6), NOW])
    expect(relativeBounds({ direction: 'next', n: 4, unit: 'hour' })).toEqual([NOW, add(NOW, 4, 7)])
    expect(relativeBounds({ direction: 'last', n: 2, unit: 'month', calendar: true })).toEqual([
      span(add(NOW, -2, 2), 2),
      span(add(NOW, -1, 2), 2),
    ])
    expect(relativeBounds({ direction: 'next', n: 3, unit: 'week', calendar: true })).toEqual([
      span(add(NOW, 1, 1), 1),
      span(add(NOW, 3, 1), 1),
    ])
    expect(relativeBounds({ direction: 'last', n: 3, unit: 'month', calendar: false, include_today: true })).toEqual([
      span(add(add(NOW, 1, 0), -3, 2), 0),
      span(NOW, 0),
    ])
    expect(relativeBounds({ direction: 'last', n: 7, unit: 'day', include_today: false })).toEqual([
      span(add(NOW, -7, 0), 0),
      span(add(NOW, -1, 0), 0),
    ])
    expect(relativeBounds({ direction: 'next', n: 7, unit: 'day', include_today: true })).toEqual([
      span(NOW, 0),
      span(add(add(NOW, -1, 0), 7, 0), 0),
    ])
    expect(relativeBounds({ direction: 'next', n: 7, unit: 'day', include_today: false })).toEqual([
      span(add(NOW, 1, 0), 0),
      span(add(NOW, 7, 0), 0),
    ])
  })

  it('builds a relative condition for a card', () => {
    const ui = { direction: 'last' as const, n: 2, unit: 'month', calendar: true, include_today: false }
    const c = relativeCondition(ui, false)
    expect(c.op).toBe('relative')
    expect(c.params.ui).toEqual(ui)
    expect(c.params.time).toBe(false)
  })
})

describe('bookmarks restore the pane and synced slicers', () => {
  const group = { name: 'G', filter_changes: true, field_changes: true }
  const slicerA = { name: 'sA', visual_type: 'slicer', sync_group: group } as unknown as PageSpec['visuals'][number]
  const slicerB = { name: 'sB', visual_type: 'slicer' } as unknown as PageSpec['visuals'][number]
  const c = card('c', { default: def('and', cond('in', 'US')) })
  const s = spec([card('r', { scope: 'report', default: null })], [page('p1', [c], [slicerA, slicerB])])
  const base = { pane: {}, slicers: { sB: ['old'] }, sync: { G: ['old'] } }

  it('restores report / page card values, slicers and sync groups', () => {
    const out = applyBookmarkFilters(s, {
      report: { r: def('and', cond('in', 'EU')) },
      pages: { p1: { c: null } },
      slicers: { sA: ['DE'], sB: [] },
    }, base)
    expect(cardValue(s.report_filters![0], 'p1', out.pane)).toEqual(def('and', cond('in', 'EU')))
    expect(cardValue(c, 'p1', out.pane)).toBeNull()
    expect(out.sync).toEqual({ G: ['DE'] })
    expect(out.slicers).toEqual({ sB: [] })
  })

  it('a synced slicer cleared in the bookmark clears the group', () => {
    const out = applyBookmarkFilters(s, { slicers: { sA: [] } }, base)
    expect('G' in out.sync).toBe(false)
  })

  it('a Data-off bookmark (no filter values) leaves filters as they are', () => {
    expect(applyBookmarkFilters(s, undefined, base)).toBe(base)
  })

  it('cards the bookmark does not mention keep their values', () => {
    const kept = setCard({}, c, 'p1', { kind: 'basic', value: def('and', cond('in', 'FR')) })
    const out = applyBookmarkFilters(s, { report: {} }, { ...base, pane: kept })
    expect(cardValue(c, 'p1', out.pane)).toEqual(def('and', cond('in', 'FR')))
  })
})

describe('synced slicers', () => {
  const group = { name: 'G', filter_changes: true, field_changes: true }
  const fieldOnly = { name: 'F', filter_changes: false, field_changes: true }
  const mk = (name: string, sync_group: unknown, saved?: string[]) =>
    ({ name, visual_type: 'slicer', sync_group, default_selection: saved }) as unknown as PageSpec['visuals'][number]
  const p1 = page('p1', [], [mk('a', group), mk('solo', null)])
  const p2 = page('p2', [], [mk('b', group), mk('hidden', group), mk('c', fieldOnly)])

  it('a change writes the group; clearing to All clears it', () => {
    const next = applySlicerChange({}, {}, p1.visuals[0], ['US'])
    expect(next.syncState).toEqual({ G: ['US'] })
    expect(next.slicerState).toEqual({})
    expect(applySlicerChange({}, next.syncState, p1.visuals[0], []).syncState).toEqual({ G: [] })
  })

  it('every slicer in a group follows it on any page, hidden or not', () => {
    const sync = { G: ['US'] }
    expect(withSlicerDefaults(p1, {}, sync).a).toEqual(['US'])
    expect(withSlicerDefaults(p2, {}, sync)).toMatchObject({ b: ['US'], hidden: ['US'] })
  })

  it('unsynced slicers keep page-local state; field-only groups share nothing', () => {
    const own = applySlicerChange({}, {}, p1.visuals[1], ['x'])
    expect(own.slicerState).toEqual({ solo: ['x'] })
    expect(own.syncState).toEqual({})
    expect(withSlicerDefaults(p2, { c: ['z'] }, { G: ['US'] }).c).toEqual(['z'])
    expect(withSlicerDefaults(p2, {}, { F: ['x'] }).c).toEqual([])
    const fieldOnlyChange = applySlicerChange({}, {}, p2.visuals[2], ['q'])
    expect(fieldOnlyChange.syncState).toEqual({})
  })

  it('a saved selection applies until changed; All is an explicit choice', () => {
    const saved = page('p', [], [mk('a', group, ['EU']), mk('b', null, ['DE'])])
    expect(withSlicerDefaults(saved, {}, {})).toEqual({ a: ['EU'], b: ['DE'] })
    expect(withSlicerDefaults(saved, { b: [] }, { G: [] })).toEqual({ a: [], b: [] })
  })
})
