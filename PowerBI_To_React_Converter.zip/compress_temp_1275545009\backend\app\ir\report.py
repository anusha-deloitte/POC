"""PBI-IR: canonical report-layer representation (pages, visuals, filters)."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, Field

from app.ir.model import Measure, SemanticModel


class FilterScope(StrEnum):
    REPORT = "report"
    PAGE = "page"
    VISUAL = "visual"


class InteractionMode(StrEnum):
    FILTER = "filter"
    HIGHLIGHT = "highlight"
    NONE = "none"


class AskDataPolicy(StrEnum):
    COVERED_ONLY = "covered_only"
    STITCH_ALLOWED = "stitch_allowed"
    REFUSE_ON_LOW_CONFIDENCE = "refuse_on_low_confidence"


class Filter(BaseModel):
    name: str | None = None
    scope: FilterScope
    field_table: str | None = None
    field_name: str | None = None
    field_is_measure: bool = False
    filter_type: str = "Categorical"  # Categorical | Advanced | TopN | RelativeDate | Range
    # raw PBIR filter object; interpreted by the query engine
    definition: dict = Field(default_factory=dict)
    is_hidden: bool = False
    # Filters pane card state (phase 10)
    is_locked: bool = False  # isLockedInViewMode
    ordinal: int | None = None
    how_created: str | None = None  # User | Drillthrough | ...
    display_name: str | None = None  # the card title
    require_single: bool = False  # objects.general.requireSingleSelection


class VisualField(BaseModel):
    """One projection in a visual query role (e.g. Category, Y, Values)."""

    role: str
    table: str | None = None
    name: str | None = None
    is_measure: bool = False
    is_hierarchy_level: bool = False
    hierarchy: str | None = None
    display_name: str | None = None
    # native/implicit aggregate applied in the visual (Sum, Count, ...)
    aggregate: str | None = None
    query_ref: str | None = None
    # PBIR projection `active`: false = a drill level that is not shown; None = not parsed yet
    active: bool | None = None
    show_as: str | None = None  # "percent_of_grand_total"


class VisualPosition(BaseModel):
    x: float = 0
    y: float = 0
    width: float = 0
    height: float = 0
    z: float = 0
    tab_order: int | None = None


class DrillthroughField(BaseModel):
    """A field a drill-through page receives (`pageBinding.parameters[].fieldExpr`)."""

    table: str | None = None
    name: str | None = None
    is_measure: bool = False
    hierarchy: str | None = None
    bound_filter: str | None = None  # the page's "Drill through" filter entry


class VisualTooltip(BaseModel):
    """`visualTooltip`: type Canvas = a report page (`section` = page name or `___AUTO___`),
    Default = Power BI's field tooltip."""

    show: bool | None = None
    type: str | None = None
    section: str | None = None


class SyncGroup(BaseModel):
    """`visual.syncGroup`: slicers sharing a selection (filter_changes) and/or their field."""

    name: str
    field_changes: bool | None = None
    filter_changes: bool | None = None


class Visual(BaseModel):
    name: str
    visual_type: str
    position: VisualPosition = Field(default_factory=VisualPosition)
    title: str | None = None
    fields: list[VisualField] = Field(default_factory=list)
    filters: list[Filter] = Field(default_factory=list)
    sort: list[dict] = Field(default_factory=list)
    # raw `objects`/formatting payload for the theme compiler
    formatting: dict = Field(default_factory=dict)
    # raw `visualContainerObjects` payload (background/border/title styling)
    container_objects: dict = Field(default_factory=dict)
    is_hidden: bool = False
    # populated when visual_type is unsupported by the renderer
    unsupported_reason: str | None = None
    parent_group: str | None = None
    # the visual's own isHidden (is_hidden also covers hidden ancestor groups)
    self_hidden: bool | None = None
    # {type, bookmark, page, url, tooltip}
    action: dict | None = None
    sync_group: SyncGroup | None = None
    tooltip: VisualTooltip | None = None


class InteractionEdge(BaseModel):
    from_visual: str
    to_visual: str
    mode: InteractionMode = InteractionMode.FILTER


class InteractionGraph(BaseModel):
    nodes: list[str] = Field(default_factory=list)
    edges: list[InteractionEdge] = Field(default_factory=list)
    sync_groups: dict[str, list[str]] = Field(default_factory=dict)


class Bookmark(BaseModel):
    name: str
    display_name: str | None = None
    # page_name (None = keep the current page), visibility {visual-or-group: hidden},
    # targets (visual names), filters (phase 10)
    state: dict = Field(default_factory=dict)


class DrillThroughTarget(BaseModel):
    page: str
    fields: list[str] = Field(default_factory=list)


class AskDataCoverage(BaseModel):
    question_class: str
    domain_view: str | None = None
    policy: AskDataPolicy = AskDataPolicy.REFUSE_ON_LOW_CONFIDENCE
    fallback_allowed: bool = False


class FilterPane(BaseModel):
    """Filters pane settings (`objects.outspacePane` + `objects.filterCard`)."""

    expanded: bool | None = None
    visible: bool | None = None
    width: float | None = None
    # every other literal (colours via {solid:{color}}); "filterCard" -> {Available|Applied: {...}}
    colours: dict = Field(default_factory=dict)


class Page(BaseModel):
    name: str
    display_name: str
    ordinal: int = 0
    width: float = 1280
    height: float = 720
    visuals: list[Visual] = Field(default_factory=list)
    filters: list[Filter] = Field(default_factory=list)
    is_hidden: bool = False
    background: dict = Field(default_factory=dict)
    display_option: str | None = None  # FitToPage | FitToWidth | ActualSize
    filter_pane: FilterPane | None = None
    filter_sort_order: str | None = None  # Custom | Ascending | Descending
    # page.json `type` (Tooltip = a report-page tooltip) and the drill-through binding
    page_type: str | None = None
    drillthrough: list[DrillthroughField] = Field(default_factory=list)


class Report(BaseModel):
    name: str = "Report"
    pages: list[Page] = Field(default_factory=list)
    filters: list[Filter] = Field(default_factory=list)
    theme: dict = Field(default_factory=dict)
    # report-level measures (from reportExtensions.json) keyed by table
    extension_measures: dict[str, list[str]] = Field(default_factory=dict)
    interaction_graph: InteractionGraph = Field(default_factory=InteractionGraph)
    bookmarks: list[Bookmark] = Field(default_factory=list)
    drill_through: list[DrillThroughTarget] = Field(default_factory=list)
    ask_data_coverage: list[AskDataCoverage] = Field(default_factory=list)
    vertical_alignment: str | None = None  # Top | Middle
    filter_pane: FilterPane | None = None
    filter_sort_order: str | None = None
    allow_change_filter_types: bool = True
    # True once a parser that reads the phase 10 fields wrote this report; stored bundles with
    # False are re-read from their source (runtime/dashboard.py::filters_passthrough)
    filters_parsed: bool = False
    pages_parsed: bool = False
    extension_measure_defs: dict[str, list[Measure]] = Field(default_factory=dict)

    def page(self, name: str) -> Page | None:
        return next((p for p in self.pages if p.name == name), None)


class TableCaseFix(BaseModel):
    """Exact-case physical coordinates found by the case check (phase 05)."""

    database: str | None = None
    schema_name: str | None = None
    object_name: str | None = None
    columns: dict[str, str] = Field(default_factory=dict)


class BindingSettings(BaseModel):
    """User-chosen binding overrides, persisted with the bundle (phase 05)."""

    database_override: str | None = None
    schema_override: str | None = None
    case_fixes: dict[str, TableCaseFix] = Field(default_factory=dict)
    case_checked_at: float | None = None


class ReportBundle(BaseModel):
    """Complete parsed .pbip: semantic model + report + provenance."""

    source_path: str
    model: SemanticModel
    report: Report
    warnings: list[str] = Field(default_factory=list)
    binding_settings: BindingSettings = Field(default_factory=BindingSettings)
