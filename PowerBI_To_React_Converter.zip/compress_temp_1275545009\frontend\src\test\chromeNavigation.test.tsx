import { act, render, renderHook, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, expect, it, vi } from 'vitest'
import { BookmarksMenu } from '../dashboard/BookmarksMenu'
import {
  actionCannotRun,
  applyBookmarkOverrides,
  authoredHiddenAncestor,
  bookmarkPage,
  bookmarkVisibility,
  handleMissingBookmark,
  useReportNavigation,
} from '../dashboard/navigation'
import { buildTheme, PbiThemeContext } from '../dashboard/pbi/resolve'
import { ReportActionsContext, ReportContext } from '../dashboard/reportContext'
import type { Bookmark, DashboardSpec, PageSpec, VisualAction, VisualSpec } from '../dashboard/types'
import { ButtonVisual, ImageVisual, ShapeVisual } from '../dashboard/visuals/ChromeVisuals'
import { NavigatorVisual } from '../dashboard/visuals/NavigatorVisual'

const L = (v: string) => ({ expr: { Literal: { Value: v } } })
const solid = (hex: string) => ({ solid: { color: L(`'${hex}'`) } })

function v(name: string, over: Partial<VisualSpec> & { objects?: object; parent?: string; selfHidden?: boolean; hidden?: boolean } = {}): VisualSpec {
  const { objects, parent, selfHidden, hidden, ...rest } = over
  return {
    name, visual_type: 'actionButton', x: 0, y: 0, width: 100, height: 40, z: 1, supported: true,
    dim_keys: [], column_keys: [], series_keys: [], measure_keys: [], measure_roles: {}, measure_formats: {},
    static_content: {}, sort: [], data_status: 'ok', query: null,
    pbir: {
      objects: (objects ?? {}) as Record<string, unknown>, container_objects: {}, fields: [], sort: [],
      is_hidden: hidden ?? selfHidden ?? false, self_hidden: selfHidden ?? false, parent_group: parent ?? null,
    },
    ...rest,
  } as VisualSpec
}

const bookmark = (name: string, state: Record<string, unknown>, display?: string): Bookmark => ({ name, display_name: display ?? null, state })

/** A synthetic multi-level menu: Home -> (Sales | Details hidden) with a bookmark-driven submenu. */
function menuSpec(): DashboardSpec {
  const home: PageSpec = {
    name: 'home', display_name: 'Home', width: 1280, height: 720, ordinal: 0,
    visuals: [
      v('menuBtn', { action: { type: 'Bookmark', bookmark: 'open' } }),
      v('submenu', { visual_type: 'visualGroup', selfHidden: true }),
      v('closeBtn', { parent: 'submenu', hidden: true, action: { type: 'Bookmark', bookmark: 'close' } }),
      v('toSales', { parent: 'submenu', hidden: true, action: { type: 'PageNavigation', page: 'sales' } }),
      v('toDetails', { parent: 'submenu', hidden: true, action: { type: 'PageNavigation', page: 'details' } }),
      v('card', { visual_type: 'card' }),
    ],
  }
  const sales: PageSpec = { name: 'sales', display_name: 'Sales', width: 1280, height: 720, ordinal: 1, visuals: [v('back', { action: { type: 'Back' } })] }
  const details: PageSpec = { name: 'details', display_name: 'Details', width: 1280, height: 720, ordinal: 2, is_hidden: true, visuals: [v('link', { action: { type: 'WebUrl', url: 'https://example.com' } })] }
  return {
    report_name: 'r', pages: [home, sales, details], warnings: [], measure_tiers: {},
    theme: { data_colors: [], text_classes: {} },
    interaction_graph: { nodes: [], edges: [], sync_groups: {} },
    bookmarks: [
      bookmark('open', { page_name: null, visibility: { submenu: 'hidden-no' } }, 'Open menu'),
      bookmark('close', { page_name: null, visibility: { submenu: 'hidden', closeBtn: 'hidden', toSales: 'hidden', toDetails: 'hidden' } }, 'Close menu'),
    ],
    drill_through: [],
  }
}

describe('bookmarks', () => {
  it('reads the hidden names, targets and page of a bookmark', () => {
    const b = bookmark('b', { page_name: 'sales', visibility: { a: 'hidden', b: 'visible' }, targets: ['a'] })
    expect(bookmarkVisibility(b)).toEqual({ hidden: ['a'], targets: ['a'] })
    expect(bookmarkPage(b)).toBe('sales')
    expect(bookmarkPage(bookmark('x', { page_name: null }))).toBeNull()
    expect(bookmarkPage(bookmark('x', { page: 'p' }))).toBe('p')
    expect(bookmarkVisibility(bookmark('x', {}))).toEqual({ hidden: [], targets: [] })
  })

  it('applies hidden / visible to every visual; targets restrict it to their captured visuals', () => {
    const spec = menuSpec()
    const home = spec.pages[0]
    const all = applyBookmarkOverrides({ stale: 'hidden' }, bookmark('b', { visibility: { card: 'hidden' } }), home)
    expect(all.card).toBe('hidden')
    expect(all.menuBtn).toBe('visible')
    expect('stale' in all).toBe(false) // a full bookmark replaces the previous state
    const targeted = applyBookmarkOverrides(
      { card: 'hidden' },
      bookmark('b', { visibility: { submenu: 'hidden' }, targets: ['submenu', 'closeBtn'] }),
      home,
    )
    expect(targeted).toEqual({ card: 'hidden', submenu: 'hidden', closeBtn: 'visible' })
  })

  it('a missing bookmark re-hides the nearest as-authored hidden ancestor group', () => {
    const home = menuSpec().pages[0]
    const btn = home.visuals.find((x) => x.name === 'closeBtn')!
    expect(authoredHiddenAncestor(btn, home)?.name).toBe('submenu')
    expect(authoredHiddenAncestor(home.visuals[0], home)).toBeUndefined()
    expect(handleMissingBookmark(btn, home, { submenu: 'visible' })).toEqual({ submenu: 'hidden' })
    // only when no authored-visible visual on the page is hidden by an override
    const blocked = { submenu: 'visible', card: 'hidden' } as const
    expect(handleMissingBookmark(btn, home, { ...blocked })).toEqual(blocked)
    // no hidden ancestor: no-op
    expect(handleMissingBookmark(home.visuals[0], home, {})).toEqual({})
  })

  it('actions that cannot run: missing page, or a missing bookmark without a hidden ancestor', () => {
    const spec = menuSpec()
    const home = spec.pages[0]
    const lost = v('lost', { action: { type: 'Bookmark', bookmark: 'nope' } })
    expect(actionCannotRun(lost, home, spec)).toBe(true)
    expect(actionCannotRun(home.visuals[0], home, spec)).toBe(false)
    expect(actionCannotRun(v('x', { action: { type: 'PageNavigation', page: 'gone' } }), home, spec)).toBe(true)
    expect(actionCannotRun(v('x', { action: { type: 'PageNavigation', page: 'sales' } }), home, spec)).toBe(false)
    expect(actionCannotRun(v('plain', { action: null }), home, spec)).toBe(false)
    // a missing bookmark inside a hidden group can still re-hide the group
    const inGroup = v('g', { parent: 'submenu', hidden: true, action: { type: 'Bookmark', bookmark: 'nope' } })
    expect(actionCannotRun(inGroup, home, spec)).toBe(false)
  })
})

describe('report navigation (a synthetic multi-level menu)', () => {
  it('hidden pages are not tabs but stay reachable', () => {
    const spec = menuSpec()
    const { result } = renderHook(() => useReportNavigation(spec))
    expect(result.current.tabs.map((p) => p.name)).toEqual(['home', 'sales'])
    expect(result.current.pageName).toBe('home')
    act(() => result.current.goToPage('details'))
    expect(result.current.pageName).toBe('details')
  })

  it('bookmark buttons open and close the submenu; navigation buttons go to pages; Back returns', () => {
    const spec = menuSpec()
    const { result } = renderHook(() => useReportNavigation(spec))
    const run = (name: string) => act(() => result.current.runAction(result.current.page!.visuals.find((x) => x.name === name)!))
    run('menuBtn')
    expect(result.current.overrides.submenu).toBe('visible')
    run('toSales')
    expect(result.current.pageName).toBe('sales')
    expect(result.current.canGoBack).toBe(true)
    run('back')
    expect(result.current.pageName).toBe('home')
    expect(result.current.canGoBack).toBe(false)
    run('menuBtn')
    run('closeBtn')
    expect(result.current.overrides).toMatchObject({ submenu: 'hidden', closeBtn: 'hidden' })
  })

  it('a tab click is a fresh start: overrides, history and filters reset', () => {
    const spec = menuSpec()
    const fresh = vi.fn()
    const { result } = renderHook(() => useReportNavigation(spec, { onFreshStart: fresh }))
    act(() => result.current.applyBookmark(spec.bookmarks[0]))
    act(() => result.current.goToPage('sales'))
    act(() => result.current.goToTab('home'))
    expect(result.current.overrides).toEqual({})
    expect(result.current.canGoBack).toBe(false)
    expect(fresh).toHaveBeenCalled()
  })

  it('WebUrl opens in a new tab and Drillthrough is handed to the report', () => {
    const spec = menuSpec()
    const openUrl = vi.fn()
    const drill = vi.fn()
    const { result } = renderHook(() => useReportNavigation(spec, { openUrl, onDrillthrough: drill }))
    act(() => result.current.goToPage('details'))
    act(() => result.current.runAction(result.current.page!.visuals[0]))
    expect(openUrl).toHaveBeenCalledWith('https://example.com')
    const action: VisualAction = { type: 'Drillthrough', page: 'sales' }
    act(() => result.current.runAction(v('d', { action })))
    expect(drill).toHaveBeenCalledWith(action, expect.objectContaining({ name: 'd' }))
  })

  it('a bookmark can switch pages', () => {
    const spec = menuSpec()
    const { result } = renderHook(() => useReportNavigation(spec))
    act(() => result.current.applyBookmark(bookmark('go', { page_name: 'sales', visibility: {} })))
    expect(result.current.pageName).toBe('sales')
  })
})

describe('bookmarks menu', () => {
  it('lists every bookmark by display name and applies the chosen one', async () => {
    const onApply = vi.fn()
    const bookmarks = [bookmark('b1', {}, 'First view'), bookmark('b2', {})]
    render(<BookmarksMenu bookmarks={bookmarks} onApply={onApply} />)
    await userEvent.click(screen.getByRole('button', { name: 'Bookmarks' }))
    const items = screen.getAllByRole('menuitem')
    expect(items.map((i) => i.textContent)).toEqual(['First view', 'b2'])
    await userEvent.click(items[0])
    expect(onApply).toHaveBeenCalledWith(bookmarks[0])
    expect(screen.queryByTestId('bookmarks-menu')).toBeNull()
  })

  it('renders nothing without bookmarks', () => {
    const { container } = render(<BookmarksMenu bookmarks={[]} onApply={() => {}} />)
    expect(container.textContent).toBe('')
  })
})

describe('chrome visuals', () => {
  const wrap = (ui: React.ReactElement, actions = {}) =>
    render(
      <PbiThemeContext.Provider value={buildTheme(undefined)}>
        <ReportContext.Provider value={{ conversionId: 'c1' }}>
          <ReportActionsContext.Provider value={{ bookmarks: [], pages: [], applyBookmark: () => {}, goToPage: () => {}, ...actions }}>
            {ui}
          </ReportActionsContext.Provider>
        </ReportContext.Provider>
      </PbiThemeContext.Provider>,
    )

  it('a button shows its text, fires its action and darkens on hover', async () => {
    const onClick = vi.fn()
    const spec = v('b', {
      objects: {
        fill: [
          { selector: { id: 'default' }, properties: { fillColor: solid('#112233') } },
          { selector: { id: 'hover' }, properties: { fillColor: solid('#445566') } },
        ],
        text: [{ properties: { show: L('true'), text: L("'Click me'") } }],
      },
    })
    wrap(<ButtonVisual spec={spec} onClick={onClick} />)
    const button = screen.getByTestId('button-b')
    expect(button.textContent).toBe('Click me')
    expect(button.style.background).toMatch(/rgb\(17, 34, 51\)|#112233/i)
    await userEvent.hover(button)
    expect(button.style.background).toMatch(/rgb\(68, 85, 102\)|#445566/i)
    await userEvent.click(button)
    expect(onClick).toHaveBeenCalled()
  })

  it('measure-driven text replaces the static text; a disabled button does nothing', async () => {
    const onClick = vi.fn()
    const spec = v('b', { objects: { text: [{ properties: { text: L("'static'") } }] } })
    wrap(<ButtonVisual spec={spec} text="Revenue 2024" onClick={onClick} disabled />)
    const button = screen.getByTestId('button-b')
    expect(button.textContent).toBe('Revenue 2024')
    await userEvent.click(button)
    expect(onClick).not.toHaveBeenCalled()
  })

  it('draws each shape kind as SVG', () => {
    const kinds: [string, string][] = [['rectangle', 'rect'], ['roundedRectangle', 'rect'], ['oval', 'ellipse'], ['triangle', 'polygon'], ['line', 'line']]
    for (const [kind, tag] of kinds) {
      const { container, unmount } = wrap(
        <ShapeVisual spec={v(`s-${kind}`, { visual_type: 'shape', width: 100, height: 50, objects: { shape: [{ properties: { tileShape: L(`'${kind}'`) } }], outline: [{ properties: {} }] } })} />,
      )
      expect(container.querySelector(tag)).toBeTruthy()
      unmount()
    }
  })

  it('a line rotated a quarter turn spans the box vertically', () => {
    const spec = v('s', {
      visual_type: 'shape', width: 100, height: 50,
      objects: { shape: [{ properties: { tileShape: L("'line'") } }], rotation: [{ properties: { shapeAngle: L('90D') } }], outline: [{ properties: {} }] },
    })
    const { container } = wrap(<ShapeVisual spec={spec} />)
    const line = container.querySelector('line')!
    expect(line.getAttribute('x1')).toBe(line.getAttribute('x2'))
    expect(line.getAttribute('y1')).toBe('0')
    expect(line.getAttribute('y2')).toBe('50')
  })

  it('images use the resource URL or the linked URL and their fit mode', () => {
    const registered = v('i1', {
      visual_type: 'image',
      objects: {
        image: [{ properties: { scaling: L("'Fill'"), imageUrl: { expr: { ResourcePackageItem: { PackageName: 'RegisteredResources', ItemName: 'logo 1.png' } } } } }],
      },
    })
    const { unmount } = wrap(<ImageVisual spec={registered} />)
    const img = screen.getByTestId('image-i1') as HTMLImageElement
    expect(img.getAttribute('src')).toBe('/api/v1/conversions/c1/dashboard/resources/logo%201.png')
    expect(img.style.objectFit).toBe('cover')
    unmount()
    const linked = v('i2', { visual_type: 'image', objects: { image: [{ properties: { imageUrl: L("'https://example.com/a.png'") } }] } })
    wrap(<ImageVisual spec={linked} />)
    expect((screen.getByTestId('image-i2') as HTMLImageElement).getAttribute('src')).toBe('https://example.com/a.png')
  })

  it('navigators list bookmarks or the visible pages', async () => {
    const applyBookmark = vi.fn()
    const goToPage = vi.fn()
    const bookmarks = [bookmark('b', {}, 'Bookmark A')]
    const pages = menuSpec().pages
    wrap(<NavigatorVisual spec={v('nav1', { visual_type: 'bookmarkNavigator' })} />, { bookmarks, applyBookmark })
    await userEvent.click(screen.getByRole('button', { name: 'Bookmark A' }))
    expect(applyBookmark).toHaveBeenCalledWith(bookmarks[0])
    wrap(<NavigatorVisual spec={v('nav2', { visual_type: 'pageNavigator' })} />, { pages, goToPage, currentPage: 'home' })
    const nav = screen.getByTestId('navigator-nav2')
    expect(nav.textContent).toBe('HomeSales') // the hidden page is not listed
    await userEvent.click(screen.getByRole('button', { name: 'Sales' }))
    expect(goToPage).toHaveBeenCalledWith('sales')
  })
})
