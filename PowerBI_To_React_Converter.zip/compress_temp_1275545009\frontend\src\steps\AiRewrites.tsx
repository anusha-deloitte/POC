import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { api } from '../api/client'
import { useWizard } from '../store/wizard'

export function AiRewrites() {
  const conversionId = useWizard((s) => s.conversionId)
  const queryClient = useQueryClient()
  const rewrites = useQuery({
    queryKey: ['dax-rewrites', conversionId],
    queryFn: () => api.daxRewrites(conversionId!),
    enabled: !!conversionId,
  })
  const revert = useMutation({
    mutationFn: (measure: string) => api.revertDaxRewrite(conversionId!, measure),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ['dax-rewrites', conversionId] })
    },
  })

  const entries = Object.entries(rewrites.data?.rewrites ?? {})
  if (entries.length === 0) return null

  return (
    <div data-testid="ai-rewrites" className="card mb-6 p-4">
      <h3 className="text-sm font-bold text-surface-900">AI-rewritten DAX ({entries.length})</h3>
      <p className="mt-1 text-xs text-surface-600">
        These measures were rewritten by AI into DAX the deterministic compiler supports, so they
        follow slicers and the visual&apos;s rows. Each rewrite compiled and ran against Snowflake
        for every visual using it; equality with Power BI&apos;s numbers is not proven. Revert any
        you don&apos;t trust.
      </p>
      {revert.isError && (
        <p role="alert" className="mt-2 text-xs text-brand-red">
          {revert.error.message}
        </p>
      )}
      <div className="mt-3 space-y-4">
        {entries.map(([name, rewrite]) => (
          <div key={name} className="rounded-xl border border-black/[0.08] p-3">
            <div className="flex items-center gap-2">
              <span className="font-semibold">[{name}]</span>
              <span className="badge-blue">AI-rewritten DAX</span>
              <button
                type="button"
                className="btn-secondary ml-auto !px-3 !py-1 !text-xs"
                disabled={revert.isPending}
                onClick={() => revert.mutate(name)}
              >
                Revert
              </button>
            </div>
            <div className="mt-2 grid gap-3 md:grid-cols-2">
              <div>
                <div className="text-[10px] font-bold tracking-wider text-surface-500 uppercase">
                  Original
                </div>
                <pre className="mt-1 max-h-48 overflow-auto rounded-lg bg-surface-50 p-2 text-[11px] whitespace-pre-wrap">
                  {rewrite.original}
                </pre>
              </div>
              <div>
                <div className="text-[10px] font-bold tracking-wider text-surface-500 uppercase">
                  Rewrite
                </div>
                <pre className="mt-1 max-h-48 overflow-auto rounded-lg bg-surface-50 p-2 text-[11px] whitespace-pre-wrap">
                  {rewrite.expression}
                </pre>
              </div>
            </div>
            {rewrite.gates.length > 0 && (
              <ul className="mt-2 ml-4 list-disc text-xs text-surface-700">
                {rewrite.gates.map((g) => (
                  <li key={g}>{g}</li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
