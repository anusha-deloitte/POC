# Master prompt for Claude Code (paste everything below the line into Claude Code, started in the target folder)

Before starting: copy the files `01_*.md` ... `13_*.md` of this folder into the target repository as
`docs/port-spec/` (they are Markdown specifications, not code). Start Claude Code in
`C:\Users\AM79297\Downloads\pib_converter_export_WithLogging_EB_auth_no_docker`.

---

You are working in this repository: a Power BI (PBIP/PBIR) -> Snowflake + React dashboard converter (FastAPI backend in
`backend/`, Vite/React/TypeScript front end in `frontend/`). An enhanced version of this product exists elsewhere, but you
cannot see it. Your job is to bring THIS repository up to that version's features by implementing the specifications in
`docs/port-spec/01_*.md` ... `13_*.md`. The specs are the source of truth: they describe every behaviour, contract, data
format, message text and test the enhanced version has. You re-implement them in this codebase; there is no code to copy.

## Ground rules
1. Work only inside this repository. Never read or write `C:\Users\AM79297\.pbic\storage`, `C:\Users\AM79297\.pbic-v0-9-0`, or any
   other checkout. This app's data goes to `C:\Users\AM79297\.pbic-target` (phase 01 creates `backend/.env` for that - do it before
   running the app or any test that could touch storage).
2. Make targeted edits that follow the existing code style and libraries; don't rewrite working modules wholesale. Keep existing
   behaviour unless a spec replaces it. Don't add comments that only narrate changes. Never log or commit secrets.
3. Do not add dependencies beyond those the specs name (backend: `openpyxl`, `httpx` as main deps; remove `openai` / `langgraph`;
   the standalone export vendors fastapi, uvicorn, snowflake-connector-python[secure-local-storage] from the existing venv). Prefer
   package-manager commands; if `uv` fails behind the corporate TLS proxy, tell me instead of hand-editing lock files.
4. No Snowflake account is available to you. Everything must be verifiable offline: DuckDB for SQL semantics, fakes for Snowflake
   connections/cursors, fake LLM clients, `httpx.MockTransport` for Horizon, mocked `fetch` in vitest.
5. When a spec is ambiguous, contradicts the code you find, or needs a product decision, STOP and ask me with the options you see.
   Never guess Snowflake object names, numbers or message texts that a spec gives explicitly - use them exactly.
6. Use the shell commands below from the right folder (use the command's working directory, no `cd ... &&` chains):
   - backend (from `backend/`): `.venv/Scripts/python.exe -m pytest -q -p no:cacheprovider`,
     `.venv/Scripts/python.exe -m ruff check --output-format concise <files you touched>` (the repo has pre-existing lint findings:
     only lint your files). Do not use `uv run` if it fails with certificate errors; use the venv directly.
   - frontend (from `frontend/`): `npx tsc -b`, `npx vitest run` (run it alone, not in parallel with the backend suite),
     `npm run build:standalone` (from phase 12 on).
   - app: `./start.ps1 -SkipInstall` / `./stop.ps1`.

## Workflow
- Phase 0 (now, before any change): run the backend suite and the frontend suite and record the baseline - the exact list of failing
  tests - in `AGENTS.md` under "Baseline". Report it to me.
- Then do ONE phase per session, in this order (later phases depend on earlier ones):
  01 setup/runtime -> 02 Snowflake sessions -> 03 AI providers -> 04 ingest/parsing -> 05 binding -> 06 DAX engine ->
  07 pipeline/validation -> 08 audits & editing -> 09 Power BI rendering -> 10 global filters -> 11 drill-through & tooltips ->
  12 standalone package -> 13 tests & docs.
  Phase 06 is large: split it into its numbered sub-steps (6.1 ... 6.13) and finish each with its tests green.
- For each phase:
  1. Read the spec file completely and the target files it names. Write a short plan (files, order, tests) and show it to me.
  2. Implement it, including the tests listed in the spec (synthetic, generic fixtures only).
  3. Verify: backend suite (no failures beyond the baseline), ruff on touched files, `npx tsc -b`, `npx vitest run`, and from phase 12
     `npm run build:standalone`. Fix what you broke.
  4. Append a concise section for the phase to `AGENTS.md` (entry points, contracts, invariants, limitations, tests).
  5. Report: what was done, test results (counts), deviations from the spec and why, open questions. Then stop and wait for me.
- Do not commit or push unless I ask. Do not delete files you did not create without asking.

## Cross-cutting invariants (apply in every phase)
- SQL identifiers are always built with `binding/resolver.py::quote_ident` / `sql_name` (phase 05); string literals with `sql_string`/`lit`.
- `runtime/sql_render.py` must not import anything from `app` (it is copied verbatim into the standalone package).
- The front-end Filters pane logic module is `dashboard/filtersPaneState.ts` (a file named `filtersPane.ts` collides with
  `FiltersPane.tsx` on Windows).
- Visual tuning lives in `frontend/src/dashboard/pbi/defaults.ts`, never per report.
- Every query a pane runs carries the page's default report/page filters (dashboard, validation, re-check, edited SQL).
- Logging is best-effort and never breaks a request; SQL text only when `log_sql_text` is on; LLM prompt text only when `log_llm_text` is on.
- Never "guess" in the engine: unsupported constructs raise `DaxUnsupported` / `QueryPlanError` with a message naming the construct.

## Appendix: coverage of the enhanced version (file / endpoint -> spec)
New backend modules
| Enhanced-version file | Spec |
|---|---|
| `app/api/llm.py`, `app/services/{horizon_client,cortex_client,llm_provider,llm_errors}.py` | 03 |
| `app/parsers/tmsl.py` | 04 |
| `app/binding/{case_check,preflight}.py` | 05 |
| `app/core/parallel.py` | 06 (6.2) |
| `app/runtime/sql_render.py` | 10 (3), 12 |
| `app/services/compilation_logger.py`, `app/validation/value_check.py` | 07 |
| `app/services/{query_audit,sql_overrides}.py`, `app/dax/visual_query.py` | 08 |
| `app/services/standalone_export.py`, `app/standalone/{main,manifest,connection_store,snowflake_session}.py`, `app/standalone/{start,stop,install-autostart,uninstall-autostart}.ps1`, `app/standalone/README.md` | 12 |
New frontend modules
| Enhanced-version file | Spec |
|---|---|
| `components/{MfaPasscodePrompt.tsx,snowflakeAuth.ts}` | 02 |
| `steps/AiRewrites.tsx` | 07 |
| `steps/{QueryAudit,SqlEditor,RecheckButton,MeasureSqlFix,CompilationAudit}.tsx` | 08 |
| `dashboard/pbi/{chrome,defaults,fonts,literal,resolve}.ts`, `dashboard/{navigation,drill}.ts`, `dashboard/visuals/{ChromeVisuals.tsx,KpiCardVisual.tsx,mapUtil.ts,scrollbar.ts}` | 09 |
| `dashboard/{FiltersPane.tsx,filtersPaneState.ts}` | 10 |
| `dashboard/{dataPoint.ts,drillthrough.ts,DrillMenu.tsx,TooltipPage.tsx}` | 11 |
| `standalone/main.tsx`, `standalone/standalone.css`, `dashboard/standalone/{ConnectionPanel.tsx,PageTabs.tsx,StandaloneTopBar.tsx,standaloneApi.ts}`, `frontend/standalone.html`, `frontend/vite.standalone.config.ts` | 12 |
| `test/hwbsParity.test.tsx` (customer-report specific in the enhanced version) -> replaced by the generic `test/renderingParity.test.tsx` | 09 |
| tests `auth, ConnectStep(ext)` / `llmProvider` / `queryAudit, sqlEditor, recheck, compilationAudit` / `pbiResolve, pbiCalibration, layoutParity, chromeNavigation, mapVisual, scrollbar, format(ext), interactions(ext), renderingParity` / `filtersPane, filtersPhase3, syncSlicers` / `drillTooltip` / `standalone, standaloneShell` | 02 / 03 / 08 / 09 / 10 / 11 / 12 |
Changed existing modules (heavily): `agents/{pipeline,tier2,visual_compare}.py` (03, 07), `api/{dashboards,connections,conversions,governance,published_dashboards}.py` (02, 03, 05, 07-12), `binding/{m_parser,resolver}.py` (04, 05), `core/{config,logging}.py` (01), `dax/{compiler,parser}.py` (06, 08), `ir/{model,report}.py` (04, 10, 11), `parsers/{bundle,pbir,tmdl}.py` (04, 10, 11), `runtime/{dashboard,engine,semantic_view,accelerate}.py` (05, 06, 09-12), `semantic/yaml_compiler.py` (06), `services/{connections,snowflake_sessions,ingest,export,code_docs}.py` (01, 02, 09), `validation/{harness,drift}.py` (06, 07), `main.py` (01, 03); frontend `AppShell, auth, api/{client,types}, store/wizard, steps/{Connect,Analyze,Convert,Preview,Review,Upload,VisualParity}Step, pages/ReimagineStudio, dashboard/{DashboardApp,PageCanvas,ModeToggle,api,format,interactions,types}, dashboard/visuals/{Card,Chart,Combo,EChart,Map,Scatter,Slicer,Table,Textbox}Visual` (02-12); `start.ps1`, `stop.ps1`, new `start.sh`/`stop.sh`, `.env.example`, `README.md`, `demo.sh`, `pyproject.toml` (01, 03).

New endpoints (prefix `/api/v1/conversions/{id}/dashboard` unless noted)
| Endpoint | Spec |
|---|---|
| `GET /api/v1/llm/providers` | 03 |
| `PATCH /api/v1/connections/{id}`; `POST /connections/{id}/test` body `{passcode, force}`; `GET /connections/{id}/session?verify=` | 02 |
| `GET /api/v1/conversions/{id}/source-hints`; `POST /preflight` | 05 |
| `GET /api/v1/conversions/{id}/compilation-logs`; `GET /dax-rewrites`; `DELETE /dax-rewrites/{measure}` | 07 |
| `GET /query-audit`, `/query-audit/export`; `GET /sql-editor`; `POST /sql-overrides/test`; `GET`/`PUT /sql-overrides`; `DELETE /sql-overrides/{page}/{visual}`; `POST /recheck`; `GET /no-sql-panes`, `/no-sql-panes/{page}/{visual}`; `POST /measure-sql/test`; `GET`/`PUT /measure-sql`; `DELETE /measure-sql/{measure}`; `GET /compilation-audit`, `/compilation-audit/export` | 08 |
| `GET /resources/{name}`; `POST /query/drill`; published `POST /api/v1/published/dashboard/query/drill` | 09 |
| `POST /filter-values`; published `POST /api/v1/published/dashboard/filter-values` | 10 |
| `POST /export-standalone`; standalone service `GET /health` and `/api/v1/published/{session, session/authenticate, session/sign-out, connection, connection/secrets, dashboard/spec, dashboard/accelerate, dashboard/query, dashboard/query/drill, dashboard/filter-values}` | 12 |

Start with Phase 0 (baseline) now.
 