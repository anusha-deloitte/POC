"""Raw PBIR passthroughs the renderer needs, read from the stored upload.

Everything here is idempotent and reads the stored source, so conversions ingested before a parser
addition pick it up without a re-upload: the page/visual/theme/bookmark passthroughs fill what the
stored bundle lacks and never overwrite something the parser already produced.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from app.ir.report import Report, ReportBundle, Visual

_RESOURCE_NAME = re.compile(r"^[A-Za-z0-9 _.()\-]+$")
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".bmp"}
MEDIA_TYPES = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".webp": "image/webp",
    ".bmp": "image/bmp",
}
CHROME_VISUAL_TYPES = frozenset(
    {
        "visualGroup", "shape", "basicShape", "image", "actionButton", "textbox",
        "bookmarkNavigator", "pageNavigator",
    }
)  # fmt: skip


# ------------------------------------------------------------------ report folder


def report_dir(bundle: ReportBundle) -> Path | None:
    """The `X.Report` folder of the stored upload. Uploads are often nested
    (`source/<zip folder>/X.Report`), so it is located, not assumed."""
    root = Path(bundle.source_path)
    if not root.is_dir():
        return None
    for pbip in sorted(root.rglob("*.pbip")):
        try:
            data = json.loads(pbip.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        for artifact in data.get("artifacts", []):
            rel = (artifact.get("report") or {}).get("path")
            if rel:
                candidate = (pbip.parent / rel).resolve()
                if candidate.is_dir():
                    return candidate
    for candidate in sorted(root.rglob("*.Report")):
        if (candidate / "definition").is_dir():
            return candidate
    return None


def _read_json(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


# ------------------------------------------------------------------ themes


def pbi_theme_passthrough(bundle: ReportBundle) -> dict:
    """`{base_name, base, custom}`: the report's base theme JSON (empty when the file is missing)
    and its custom theme."""
    theme = bundle.report.theme or {}
    collection = theme.get("collection", {}) if isinstance(theme, dict) else {}
    base_name = ((collection.get("baseTheme") or {}).get("name")) or None
    base: dict = {}
    rd = report_dir(bundle)
    if base_name and rd is not None and _RESOURCE_NAME.match(base_name):
        path = rd / "StaticResources" / "SharedResources" / "BaseThemes" / f"{base_name}.json"
        if path.is_file():
            base = _read_json(path)
    custom = theme.get("custom", {}) if isinstance(theme, dict) else {}
    return {"base_name": base_name, "base": base, "custom": custom or {}}


# ------------------------------------------------------------------ images and resources


def _walk(node: Any):
    if isinstance(node, dict):
        yield node
        for v in node.values():
            yield from _walk(v)
    elif isinstance(node, list):
        for v in node:
            yield from _walk(v)


def resource_item(node: Any) -> str | None:
    """The RegisteredResources file a `ResourcePackageItem` points to, found anywhere in `node`."""
    for d in _walk(node):
        item = d.get("ResourcePackageItem")
        if isinstance(item, dict) and item.get("ItemName"):
            package = item.get("PackageName", "RegisteredResources")
            if package == "RegisteredResources":
                return str(item["ItemName"])
    return None


def _literal_string(node: Any) -> str | None:
    for d in _walk(node):
        lit = d.get("Literal")
        if isinstance(lit, dict) and isinstance(lit.get("Value"), str):
            raw = lit["Value"]
            if len(raw) >= 2 and raw[0] == "'" and raw[-1] == "'":
                return raw[1:-1].replace("''", "'")
            return raw
    return None


def image_source(visual: Visual) -> dict | None:
    """`{resource: <file>}` for a registered image, `{url}` for a linked one, else None."""
    if visual.visual_type != "image":
        return None
    for entry in (visual.formatting or {}).get("image", []) or []:
        props = (entry or {}).get("properties", {}) if isinstance(entry, dict) else {}
        node = props.get("imageUrl") or props.get("url")
        if node is None:
            continue
        name = resource_item(node)
        if name:
            return {"resource": name}
        url = _literal_string(node)
        if url:
            return {"url": url}
    name = resource_item(visual.formatting or {})
    return {"resource": name} if name else None


def referenced_resources(spec: Any) -> list[str]:
    """Registered images the dashboard draws: image visuals and custom button icons."""
    found: dict[str, None] = {}
    for page in spec.pages:
        for vs in page.visuals:
            if vs.visual_type not in ("image", "actionButton") or not vs.pbir:
                continue
            for name in _resource_names(vs.pbir.get("objects", {})):
                found[name] = None
    return sorted(found)


def _resource_names(node: Any) -> list[str]:
    out: list[str] = []
    for d in _walk(node):
        item = d.get("ResourcePackageItem")
        if isinstance(item, dict) and item.get("ItemName"):
            if item.get("PackageName", "RegisteredResources") == "RegisteredResources":
                out.append(str(item["ItemName"]))
    return out


def resolve_resource(bundle: ReportBundle, name: str) -> Path | None:
    """The file behind `GET /dashboard/resources/{name}`; None unless it is a plain image inside
    RegisteredResources (no traversal, no hidden files)."""
    if not name or name.startswith(".") or not _RESOURCE_NAME.match(name):
        return None
    if Path(name).suffix.lower() not in IMAGE_EXTENSIONS:
        return None
    rd = report_dir(bundle)
    if rd is None:
        return None
    base = (rd / "StaticResources" / "RegisteredResources").resolve()
    path = (base / name).resolve()
    if base not in path.parents or not path.is_file():
        return None
    return path


# ------------------------------------------------------------------ stored-source passthroughs


def _fresh_report(bundle: ReportBundle) -> Report | None:
    rd = report_dir(bundle)
    if rd is None:
        return None
    from app.parsers.pbir import PbirParseError, parse_report_definition

    try:
        return parse_report_definition(rd)[0]
    except (PbirParseError, OSError, ValueError):
        return None


def visual_source_passthrough(bundle: ReportBundle, fresh: Report | None = None) -> None:
    """Group container objects, projection `active`, actions and group geometry from the source,
    only where the stored bundle has none."""
    fresh = fresh or _fresh_report(bundle)
    if fresh is None:
        return
    for page in bundle.report.pages:
        source_page = fresh.page(page.name)
        if source_page is None:
            continue
        source = {v.name: v for v in source_page.visuals}
        for v in page.visuals:
            s = source.get(v.name)
            if s is None:
                continue
            if not v.container_objects and s.container_objects:
                v.container_objects = s.container_objects
            if not v.formatting and s.formatting:
                v.formatting = s.formatting
            if v.action is None and s.action is not None:
                v.action = s.action
            if v.self_hidden is None:
                v.self_hidden = s.self_hidden
                v.is_hidden = s.is_hidden
            if v.parent_group is None and s.parent_group is not None:
                v.parent_group = s.parent_group
                v.position = s.position
                v.is_hidden = s.is_hidden
            for f, sf in zip(v.fields, s.fields, strict=False):
                if f.active is None:
                    f.active = sf.active
                if f.show_as is None:
                    f.show_as = sf.show_as


def page_layout_passthrough(bundle: ReportBundle, fresh: Report | None = None) -> None:
    """displayOption, verticalAlignment and page backgrounds."""
    fresh = fresh or _fresh_report(bundle)
    if fresh is None:
        return
    if bundle.report.vertical_alignment is None and fresh.vertical_alignment:
        bundle.report.vertical_alignment = fresh.vertical_alignment
    for page in bundle.report.pages:
        source = fresh.page(page.name)
        if source is None:
            continue
        if page.display_option is None and source.display_option:
            page.display_option = source.display_option
        if not page.background and source.background:
            page.background = source.background


def interaction_graph_passthrough(bundle: ReportBundle, fresh: Report | None = None) -> None:
    """An empty stored graph is rebuilt from the page files."""
    if bundle.report.interaction_graph.edges:
        return
    fresh = fresh or _fresh_report(bundle)
    if fresh is not None and fresh.interaction_graph.edges:
        bundle.report.interaction_graph = fresh.interaction_graph


def bookmarks_passthrough(bundle: ReportBundle, fresh: Report | None = None) -> None:
    """Bookmarks are always re-read from the source."""
    fresh = fresh or _fresh_report(bundle)
    if fresh is not None:
        bundle.report.bookmarks = fresh.bookmarks


def apply_source_passthroughs(bundle: ReportBundle) -> None:
    fresh = _fresh_report(bundle)
    if fresh is None:
        return
    visual_source_passthrough(bundle, fresh)
    page_layout_passthrough(bundle, fresh)
    interaction_graph_passthrough(bundle, fresh)
    bookmarks_passthrough(bundle, fresh)


# ------------------------------------------------------------------ visual-level readers


def literal_value(node: Any) -> Any:
    from app.parsers.pbir import _literal_value

    return _literal_value(node)


def saved_slicer_selection(visual: Visual) -> list:
    """A slicer's saved selection: `objects.general[0].properties.filter.filter` Version 2 `In`
    with literals. Inverted ("all except") and non-literal shapes mean All (empty)."""
    try:
        flt = visual.formatting["general"][0]["properties"]["filter"]["filter"]
    except (KeyError, IndexError, TypeError):
        return []
    if not isinstance(flt, dict):
        return []
    values: list = []
    for where in flt.get("Where", []) or []:
        cond = where.get("Condition", {}) or {}
        if "Not" in cond:  # inverted
            return []
        in_expr = cond.get("In")
        if not isinstance(in_expr, dict):
            return []
        for tup in in_expr.get("Values", []) or []:
            for lit in tup:
                raw = (lit.get("Literal") or {}).get("Value")
                if raw is None:
                    return []
                values.append(_decode(raw))
    return values


def _decode(raw: Any) -> Any:
    if not isinstance(raw, str):
        return raw
    if len(raw) >= 2 and raw[0] == "'" and raw[-1] == "'":
        return raw[1:-1].replace("''", "'")
    if raw == "null":
        return None
    if raw in ("true", "false"):
        return raw == "true"
    try:
        if raw[-1] in "Ll":
            return int(raw[:-1])
        if raw[-1] in "DdMm":
            return float(raw[:-1])
        return float(raw) if "." in raw else int(raw)
    except ValueError:
        return raw


def filters_passthrough(bundle: ReportBundle) -> None:
    """Filters pane data (report/page filters with card state, sync groups, pane settings, sort
    orders, bookmark filter state) re-read from the stored source while the stored bundle was
    parsed before they existed."""
    report = bundle.report
    if report.filters_parsed and report.pages_parsed:
        return
    fresh = _fresh_report(bundle)
    if fresh is None:
        return
    report.filters = fresh.filters
    report.filter_pane = fresh.filter_pane
    report.filter_sort_order = fresh.filter_sort_order
    report.allow_change_filter_types = fresh.allow_change_filter_types
    report.interaction_graph.sync_groups = fresh.interaction_graph.sync_groups
    report.bookmarks = fresh.bookmarks
    for page in report.pages:
        source = fresh.page(page.name)
        if source is None:
            continue
        page.filters = source.filters
        page.filter_pane = source.filter_pane
        page.filter_sort_order = source.filter_sort_order
        page.page_type = source.page_type
        page.drillthrough = source.drillthrough
        fresh_visuals = {v.name: v for v in source.visuals}
        for v in page.visuals:
            twin = fresh_visuals.get(v.name)
            v.sync_group = twin.sync_group if twin else None
            v.tooltip = twin.tooltip if twin else None
    report.filters_parsed = True
    report.pages_parsed = True
