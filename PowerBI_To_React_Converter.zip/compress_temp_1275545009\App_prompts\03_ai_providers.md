# Phase 03 - AI providers: Horizon gateway + Snowflake Cortex (OpenAI removed)

## Purpose
Replace every direct OpenAI GPT-4o call with two providers:
- **Snowflake Cortex** (default) for tier-2 translations, executed on the conversion's own signed-in
  Snowflake session (no extra credentials);
- **Horizon** (Elevance Health's internal LLM gateway, OAuth2 client credentials) for tier-2 when
  chosen, and always for governance AI assist and AI visual parity.

## Current target state
OpenAI is used in `agents/tier2.py` (`propose_and_validate`), `agents/visual_compare.py`
(vision compare), `api/governance.py` (override drafting + Q&A) and `api/dashboards.py`
(`convert_dashboard` builds `OpenAI(api_key=...)`). `pyproject.toml` has an `llm` extra
(`openai>=1.55`, `langgraph>=0.2.50`, `langgraph-checkpoint-postgres>=2.0`).

## Required behaviour

### 1. Shared error base - `services/llm_errors.py`
`class LlmError(Exception)`: base of every provider failure. The pipeline parks a measure on it
instead of failing the run.

### 2. Horizon client - `services/horizon_client.py`
2.1 `HorizonError(LlmError)`.
2.2 Token: `POST {base_url}/v2/oauth2/token` JSON `{client_id, client_secret, grant_type: "client_credentials"}`;
response `{access_token, expires_in}` (default 300). Cache the token until
`expires_in - 60` seconds (monotonic clock), under a lock; log `horizon_token_refreshed` (never the token).
2.3 `chat(messages, qos=None, reasoning=False, max_retries=3) -> str`:
`POST {base_url}/v2/text/chats?provider=openai&qos=<qos or default>&reasoning=true|false`,
headers `Authorization: Bearer <token>`, JSON body `{"messages": messages, "stream": false}`
(messages are OpenAI-style role/content; content may be a string or a list of content parts).
Reply text = `response.json()["message"]["content"]` (empty string if missing).
- network error (`httpx.HTTPError`): log `horizon_chat_failed`, sleep `1.5*attempt`, retry; last
  attempt -> `HorizonError("Horizon chat request failed: <e>")`.
- 429: `retry_after = Retry-After header or 2*attempt`; tell the rate limiter (2.4); log
  `horizon_rate_limited` (attempt, retry_after, effective rpm, limit_lowered); sleep and retry; last
  -> `HorizonError("Horizon chat failed: rate limited after retries")`.
- 5xx (not last attempt): log `horizon_server_error_retrying`, sleep `1.5*attempt`, retry.
- other 4xx/5xx: log the first 1000 chars of the body; `HorizonError("Horizon chat failed: <e>; body: <detail>")`.
- success: log `horizon_chat` (qos, reasoning, attempt, elapsed_ms).
2.4 `_RateLimiter(max_requests, per_seconds=60)`: rolling window; `acquire()` sleeps until a slot
frees; `on_rate_limited()` sets the cap to `max(1, calls_in_window - 1)` if lower (learns the gateway's
real limit; observed ~12/min) and returns the new cap or None. Thread-safe.
2.5 Content parts: `image_content_part(bytes, mime="image/png") -> {"type":"image","image":{"type":"base64","format":mime,"data":<b64>}}`;
`text_content_part(text) -> {"type":"text","text":text}`.
2.6 Constructor `(base_url, client_id, client_secret, default_qos="accurate", max_requests_per_minute=15, timeout=60, verify=True)`;
`verify=False` logs a `horizon_tls_verification_disabled` warning. One shared `httpx.Client`. `close()`.
2.7 `build_client_from_settings() -> HorizonClient | None`: None when id or secret is empty
(LLM features disabled); else from settings (`horizon_base_url`, `horizon_qos`,
`horizon_max_requests_per_minute`, `horizon_verify_ssl`).
2.8 Never log credentials/tokens (logging redaction covers `client_secret`, phase 01).

### 3. Cortex client - `services/cortex_client.py`
3.1 `CortexError(LlmError)`; `provider = "cortex"`; `label` property `"Cortex (<model>)"`.
3.2 SQL (bind parameters only, messages never formatted into SQL):
`SELECT SNOWFLAKE.CORTEX.COMPLETE(%s, PARSE_JSON(%s), PARSE_JSON(%s))` with
`(model, json.dumps(messages), json.dumps({"temperature": t, "max_tokens": n}))`.
3.3 Reply parsing: the value may be a JSON string or a VARIANT dict:
`{"choices":[{"messages":"<text>"}], "usage":{...}}` (fallback `choices[0].message.content`). Errors:
non-JSON -> `CortexError("Cortex returned a non-JSON response: ...")`; no choices / no text -> CortexError;
no row -> `CortexError("Cortex COMPLETE returned no row")`.
3.4 Each call: new cursor from the `cursor_factory`, run inside `audit_stage(cursor, "ai_llm", context)`
(phase 08 query audit; context defaults to `"ai_llm"`), then close the cursor's connection (or cursor).
Transient errors (`429|too many requests|rate limit|throttl|temporarily unavailable|service unavailable|timed? ?out|50[234]`)
retry with `2*attempt` s sleep up to 3 attempts; others fail immediately with
`CortexError("Cortex COMPLETE failed: <err[:500]><hint>")`. Hints: "unknown function|does not exist or not
authorized|insufficient privileges" -> "The Snowflake role of this connection needs the SNOWFLAKE.CORTEX_USER
database role to call SNOWFLAKE.CORTEX.COMPLETE."; a model-unavailable message -> "Model '<m>' may not be
available in this account's region; enable cross-region inference (CORTEX_ENABLED_CROSS_REGION) or set
PBIC_CORTEX_MODEL." Log `cortex_chat` (model, attempt, context, usage, elapsed_ms) - never prompt text.
3.5 `llm_call_context(label)`: context manager setting a `ContextVar` used as the audit context of calls
inside the block (labels used: `ai_llm_rewrite:<measure>`, `ai_llm_sql:<measure>`, `ai_llm_preflight`).
3.6 `chat(messages, **ignored) -> str` (same contract as Horizon; qos/reasoning ignored).
`preflight()`: one call with "Reply with the single word OK." under context `ai_llm_preflight`.
3.7 `build_cortex_client(cursor_factory)` from settings (`cortex_model`, `cortex_temperature`, `cortex_max_tokens`).

### 4. Provider selection - `services/llm_provider.py` and `api/llm.py`
4.1 `resolve_provider(requested) -> requested or settings.llm_provider`.
4.2 `build_llm_client(provider, cursor_factory)`: cortex -> `build_cortex_client(cursor_factory)`;
horizon -> `build_client_from_settings()` (None = AI off).
4.3 `describe_providers() -> {"default": settings.llm_provider, "cortex": {"model": ...}, "horizon": {"configured": bool}}`
(never a secret). `GET /api/v1/llm/providers` (router prefix `/api/v1/llm`, token-protected like the others)
returns it. Include the router in `main.py`.

### 5. Convert endpoint (`api/dashboards.py::convert_dashboard`)
5.1 `ConvertRequest.llm_provider: Literal["cortex","horizon"] | None = None` (None = server default).
5.2 Two cursor factories: `raw_cursor_factory` (plain; migration only) and `cursor_factory` returning an
audited cursor (phase 08 `AuditedConnection`, kind `validation`). Fail fast before anything else:
connect once and close (an unsigned session returns the same 409 now instead of after compiling).
5.3 If `use_llm`: build the client; for Cortex call `preflight()`; on CortexError respond
`422 {"detail": {"code": "cortex_unavailable", "message": "<error>"}}` and stop.
5.4 Pass `llm_provider` (only when `use_llm`) to `run_conversion` (phase 07).
5.5 Remove all OpenAI code.

### 6. Pipeline provider bookkeeping (phase 07 implements the loop; implement these hooks now)
6.1 `ConversionRun.llm_provider`; persisted in `conversion_run.json`. `run.llm_provider = provider or prior.llm_provider`.
6.2 `_drop_other_provider_ai(run, bundle, root, prior, provider)`: if a provider is given and the previous
run's provider (missing = "horizon") differs: clear `run.tier2_accepted`, remove every
`model.dax_rewrites` entry with `source == "ai"`, save the bundle if any were removed, and emit
`pipeline` event "AI provider changed from X to Y: N AI SQL translation(s) and M AI DAX rewrite(s) dropped,
translating again".
6.3 Horizon chosen without credentials: emit "Horizon credentials are not configured — AI translation is off for this run".
6.4 Tier-2 prompt/response logging: `<conversion>/tier2_llm.jsonl`, event `tier2_llm_attempt` with
measure, attempt, mode/expected_kind, request_messages, response, outcome, sql, error, result_value;
when `log_llm_text` is false drop `request_messages`, `response`, `sql`.

### 7. Tier-2 SQL translation (`agents/tier2.py::propose_and_validate`)
Signature `(model, bindings, measure_name, cursor, client=None, log_path=None, dependency_sql=None)`.
7.1 `client=None` -> `build_client_from_settings()`; None -> result trace `["Horizon credentials not configured"]`.
Calls `client.chat(messages)`.
7.2 Expected result type from the DAX (`expected_result`): walk RETURN branches through VAR/IF/SWITCH;
if every terminal branch is a string literal or BLANK -> `text` with the allowed literals; else `numeric`.
System prompt (`_SYSTEM_TEMPLATE`, keep this wording):
```
You translate Power BI DAX measures into Snowflake SQL.
Rules:
- Output ONLY a JSON object: {"sql": "..."} with a single SELECT returning
  <exactly one numeric column aliased RESULT.> | <exactly one text column aliased RESULT whose value is NULL or one of: "a", "b".>
- Use only the physical tables provided (fully qualified names given).
- Write table and column identifiers exactly as given: keep the double quotes
  where shown (e.g. DB.SCHEMA."lower_table", "COLUMN"), add none where absent
  (plain UPPERCASE names); never put identifiers in single quotes.
- DIVIDE(a,b) must be IFF(b=0 OR b IS NULL, NULL, a/b).
- BLANK() is NULL. No DDL, no DML, no comments, no CTE names beyond t0..t9.
- If the measure is truly impossible with the given schema, return
  {"error": "reason"}.
```
7.3 User context (`_model_context`): the measure's DAX; "Physical tables:" only for tables the measure
and its dependency closure reference plus their direct relationship neighbours (all tables if none),
each `- model table [T] -> <qualified name> (columns: <quote_ident(physical)> (model column: [Name]) | <quote_ident(name)>)`
for non-calculated columns; "Relationships (many side -> one side; filters flow one -> many):" with
`[inactive]` / `both directions` flags; "Other measures it references (DAX, plus validated SQL where available):"
for `dependency_closure` (max 25 measures, 20,000 chars budget, "definition omitted (context size limit)").
7.4 Validation of a proposal: forbid `INSERT|UPDATE|DELETE|MERGE|CREATE|DROP|ALTER|GRANT|TRUNCATE|CALL` and
anything not starting with SELECT/WITH; execute; require exactly one row with one column;
`_check_value`: NULL ok; numeric must `float()`; text must be a str <= 256 chars and one of the allowed
literals. Retries (max 3) append the assistant text plus a corrective user message
('Respond with only {"sql": "..."} JSON.', "Only a single SELECT is allowed.", "That SQL failed: <e>. Fix it.").
Every attempt is logged (6.4) with outcome `unparseable | declared_impossible | rejected_non_select | accepted | execution_failed`.

### 8. Governance and visual parity -> Horizon
8.1 `api/governance.py`: override drafting and the governance Q&A call
`build_client_from_settings()`; None -> the existing offline fallbacks (`_fallback_override`,
`_fallback_answer`); otherwise `client.chat([...same system/user messages...], qos=settings.horizon_governance_qos)`.
8.2 `agents/visual_compare.py`: images become `image_content_part(png_bytes, mime="image/png")`;
the client comes from `build_client_from_settings()`; None -> the skip reason string
"Horizon credentials not configured"; replies via `client.chat(messages)`.
Update `tests/test_visual_compare.py` / governance tests to use a fake object with a `chat(messages, **kw)` method.

### 9. Frontend
9.1 `store/wizard.ts`: `llmProvider: 'cortex'|'horizon'|null` persisted in localStorage key
`pbic.llm_provider` (invalid stored values -> null), `setLlmProvider`.
9.2 `api/client.ts::llmProviders()` -> `GET /llm/providers`; type `LlmProviders`.
9.3 Analyze step `TranslationAiCard`: label "Translation AI", `<select id="llmProvider">` with
"Snowflake Cortex (<model>)" and "Horizon" (+ " (not configured)" when not configured); value =
stored choice ?? server default ?? 'cortex'. Help text: Cortex -> "Runs SNOWFLAKE.CORTEX.COMPLETE on the selected
Snowflake connection; its role needs the SNOWFLAKE.CORTEX_USER database role."; Horizon -> "Uses the Horizon LLM
gateway credentials configured on the server."; both followed by "Switching provider re-translates measures an
earlier run translated with the other one."
9.4 Convert step: send `llm_provider` when chosen; the convert query key includes it; send `resume: true`
(reuse prior accepted tier-2 work); on 422 with `detail.code === 'cortex_unavailable'` show
"Snowflake Cortex can't be used with this connection: <message> Fix the role/model, or pick Horizon under
"Translation AI" in the Analyze step."

### 10. Dependency and doc cleanup
Remove the `llm` optional-dependency group from `backend/pyproject.toml` (openai, langgraph,
langgraph-checkpoint-postgres) and any import of them; add `openpyxl>=3.1` to the main dependencies
(phase 08 xlsx export); ensure `httpx` is a main dependency. Update `README.md` and `demo.sh` to refer
to Horizon/Cortex instead of OpenAI keys. Regenerate `uv.lock` only if `uv` works on the machine; if it
fails behind the proxy, tell the user instead of hand-editing the lock file.

## Files
Create: `backend/app/services/llm_errors.py`, `horizon_client.py`, `cortex_client.py`, `llm_provider.py`,
`backend/app/api/llm.py`.
Modify: `agents/tier2.py`, `agents/visual_compare.py`, `api/governance.py`, `api/dashboards.py`,
`agents/pipeline.py`, `main.py`, `pyproject.toml`, `README.md`, `demo.sh`, `.env.example`,
`frontend/src/store/wizard.ts`, `api/client.ts`, `api/types.ts`, `steps/AnalyzeStep.tsx`, `steps/ConvertStep.tsx`.

## Tests
- `tests/test_horizon_client.py` (httpx MockTransport): token cached/refreshed; 429 retries using
  Retry-After and lowers the limit; 5xx retried; 4xx raises with body; content parts shape;
  `build_client_from_settings` None without credentials.
- `tests/test_cortex_client.py` (fake cursor): bind params and SQL text; JSON-string and dict replies;
  transient retry; privilege error adds the CORTEX_USER hint; preflight; audit kind `ai_llm` with the
  `llm_call_context` label; convert returns 422 `cortex_unavailable`; provider switch drops AI work.
- tier-2: text-valued measures accept only their literals; numeric must parse; logging respects `log_llm_text`.
- `src/test/llmProvider.test.tsx`: select defaults to the server default, choice persisted to
  localStorage, Convert body contains `llm_provider` + `use_llm`, `cortex_unavailable` message shown.

## Done criteria
No `openai` import anywhere; suites green vs baseline; `GET /api/v1/llm/providers` works.