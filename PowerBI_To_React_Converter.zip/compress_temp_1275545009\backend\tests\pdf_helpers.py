"""Tiny dependency-free PDF writer for tests (Helvetica text at given positions)."""

from __future__ import annotations


def _esc(text: str) -> str:
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def make_pdf(pages: list[dict], title: str | None = None) -> bytes:
    """pages: [{"width": pt, "height": pt, "runs": [(text, x, y_from_top, size)]}] -> PDF bytes."""
    objs: list[bytes] = []

    def add(body: str | bytes) -> int:
        objs.append(body.encode("cp1252") if isinstance(body, str) else body)
        return len(objs)

    add("<< /Type /Catalog /Pages 2 0 R >>")  # 1
    add("")  # 2: Pages, filled in below
    font = add(
        "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"
    )  # 3
    info = add(f"<< /Title ({_esc(title)}) >>") if title else 0
    kids = []
    for p in pages:
        w, h = p["width"], p["height"]
        ops = []
        for text, x, y, size in p.get("runs", []):
            ops.append(f"BT /F1 {size} Tf {x} {h - y - size} Td ({_esc(text)}) Tj ET")
        stream = "\n".join(ops)
        content = add(f"<< /Length {len(stream)} >>\nstream\n{stream}\nendstream")
        page = add(
            f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {w} {h}] "
            f"/Resources << /Font << /F1 {font} 0 R >> >> /Contents {content} 0 R >>"
        )
        kids.append(f"{page} 0 R")
    objs[1] = f"<< /Type /Pages /Kids [{' '.join(kids)}] /Count {len(kids)} >>".encode("cp1252")
    out = bytearray(b"%PDF-1.4\n")
    offsets = []
    for i, body in enumerate(objs, 1):
        offsets.append(len(out))
        out += f"{i} 0 obj\n".encode() + body + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objs) + 1}\n0000000000 65535 f \n".encode()
    for off in offsets:
        out += f"{off:010d} 00000 n \n".encode()
    root = f"/Root 1 0 R{f' /Info {info} 0 R' if info else ''}"
    out += f"trailer\n<< /Size {len(objs) + 1} {root} >>\nstartxref\n{xref}\n%%EOF\n".encode()
    return bytes(out)
