# Phase 04 - Ingest and parsing (live-connected reports, TMSL, report measures, M, PBIR)

## Purpose
Accept more real-world uploads and capture the PBIR details later phases need.

## Current target state
- `parsers/bundle.py::load_pbip(root)`: resolves `definition.pbir` byPath only; byConnection raises.
- No TMSL support; report-extension measures only kept as names.
- `binding/m_parser.py`: simple literal handling (`"..."` stripped, no `""` escape, no `#"Param"`).
- `parsers/tmdl.py`: `sortByColumn` keeps surrounding single quotes.
- `parsers/pbir.py`: no groups/absolute positions, no actions, basic bookmarks, no interaction graph.
- `ir/model.py`: name lookups are exact-case.

## Required behaviour

### 1. Case-insensitive model lookups (`ir/model.py`)
1.1 `_lookup(items, name)`: exact name first; else the unique case-insensitive match; ambiguous -> None.
Use it for `Table.column`, `Table.measure`, `SemanticModel.table`.
1.2 `SemanticModel.find_measure(name)`: exact match over all tables first, else the unique
case-insensitive match (None when ambiguous). DAX resolves names case-insensitively.
1.3 Add to `SemanticModel` (used by phases 06-08): `dax_rewrites: dict[str, DaxRewrite]`,
`measure_sql: dict[str, ManualMeasureSql]`, and `effective_dax(measure)` = rewrite expression if present
else `measure.expression`.
- `DaxRewrite {expression, original, source="ai", gates: list[str], created_at: float=0, provider: str|None}`
- `ManualMeasureSql {sql, original="", saved_at: float=0, checked: list[str]}`
1.4 `Measure.is_report_level` already exists in the target; report-extension measures set it to True.

### 2. Report IR additions (`ir/report.py`)
Add (all optional with defaults so stored bundles still load):
- `VisualField.active: bool | None` (PBIR projection `active`; false = a drill level not shown; None = not parsed yet),
  `VisualField.show_as: str | None` ("percent_of_grand_total").
- `VisualPosition.z: float` (was int; grouped visuals get fractional z).
- `Visual.parent_group`, `Visual.self_hidden: bool | None`, `Visual.action: dict | None`
  (`{type, bookmark, page, url, tooltip}`). (`sync_group` / `tooltip` come in phases 10/11.)
- `Bookmark.display_name`; bookmark `state` keys: `page_name` (None = keep current page),
  `visibility {visual-or-group name: hidden}`, `targets` (visual names), `filters` (phase 10).
- `Page.display_option` (FitToPage | FitToWidth | ActualSize).
- `Report.vertical_alignment` (report.json `objects.section[0].properties.verticalAlignment`: Top | Middle).
- `Report.extension_measure_defs: dict[str, list[Measure]]`.
- `ReportBundle.binding_settings: BindingSettings` (phase 05 defines the model; add it here):
  `BindingSettings {database_override, schema_override, case_fixes: dict[str, TableCaseFix], case_checked_at: float|None}`,
  `TableCaseFix {database, schema_name, object_name, columns: dict[str,str]}`.

### 3. Live-connected reports and TMSL (`parsers/bundle.py`, `parsers/tmsl.py`, `parsers/pbir.py`)
3.1 `pbir.read_dataset_reference(report_dir) -> Path | RemoteModelRef`: byPath -> resolved model folder;
byConnection -> `parse_remote_reference(byConnection)`.
`RemoteModelRef {connection_string, workspace, model_name, model_id}` with
`describe()` -> `remote semantic model '<name|id|unknown>'[ in workspace '<ws>']`.
Connection string parsing: `k=v;k="v;with;semicolons"` (quotes toggle, keys lower-cased, values stripped of
quotes). `workspace` = last path segment (URL-decoded) of a `data source` starting with `powerbi://`;
`model_name` = `initial catalog` or `byConnection.name`; `model_id` = `semanticmodelid` or `pbiModelDatabaseName`.
`resolve_dataset_reference` keeps its old contract but raises
"this report references a <describe()> (byConnection); include an export of that model in the upload".
3.2 Model sources in the upload (`_find_model_sources(root)`): every folder holding `model.tmdl` (its
`definition/` parent folder name without `.SemanticModel`/`.Dataset`, plus the `database` name in
`database.tmdl`), and every parseable `*.bim` / `*.xmla` TMSL file (names: file stem, the parent folder name
when the stem is `model`, and the TMSL database `name`). Unparseable files are listed as skipped.
3.3 `_pick_model_source(remote, root)`: none -> PbirParseError "this report is live-connected (byConnection) to the
<describe()> and the upload contains no semantic model definition. <EXPORT_HINT>[ Unreadable model files: ...]";
one -> it; several -> those whose names match `model_name`/`model_id` case-insensitively, preferring TMDL when
both kinds match; still ambiguous -> PbirParseError listing them ("...none could be matched unambiguously. Keep only
the export of that model in the zip."). EXPORT_HINT = "Export it over the workspace XMLA endpoint (Tabular Editor:
File > Save to Folder with TMDL serialization, or SSMS: Script Database as > CREATE To > File) and add the exported
folder or .bim/.xmla file to this zip next to the .pbip."
3.4 TMSL -> TMDL (`parsers/tmsl.py`): `load_tmsl(path)` reads utf-8-sig JSON and returns the database object
(`createOrReplace|create|alter -> database`, a `{model:{...}}` object, or a bare model with `tables`); errors raise
`TmdlParseError`. `write_tmdl_from_tmsl(db, definition_dir)` writes `database.tmdl` (name, compatibilityLevel),
`model.tmdl` (name, culture, annotations), `expressions.tmdl`, `tables/<safe name>.tmdl`, `relationships.tmdl`,
`roles/<safe name>.tmdl`. Names that aren't `^[A-Za-z][A-Za-z0-9_]*$` are written `'quoted'` with `''`. Expressions
(string or list of lines) use fenced blocks (```` = ``` ```` ... ```` ``` ````) to avoid indentation issues. Columns:
skip `rowNumber`; calculated columns fenced; props dataType, formatString, sourceColumn, summarizeBy, lineageTag,
sortByColumn, flags isHidden/isKey, annotations. Measures: fenced expression + formatString, displayFolder,
lineageTag, isHidden. Hierarchies with levels (ordinal, column). Partitions `= <source.type or m>` with mode and a
fenced `source`. Relationships: isActive, crossFilteringBehavior, securityFilteringBehavior, cardinalities,
fromColumn/toColumn `T.C`. Roles: modelPermission, tablePermission with fenced filterExpression. Descriptions as
`///` lines. File names: unsafe chars -> `_`, case-insensitive duplicates get `_2`, `_3`. Calculation groups,
perspectives, cultures and OLS are skipped. One model code path: the TMDL parser reads the generated folder.
3.5 Where converted TMDL goes (`_tmsl_to_definition`): `generated_dir/<stem>.SemanticModel/definition` when given
(ingest passes `<conversion>/generated_model`, phase 01), else next to the TMSL file; an existing non-empty target
-> PbirParseError. A local `X.SemanticModel` without `definition/` but with `model.bim` is converted the same way
(warning "semantic model was TMSL (model.bim); converted to TMDL at <path>").
3.6 `load_pbip(root, generated_dir=None)`: after picking the model, add the warning
"report was live-connected to the <describe()>; rebound to the uploaded model <relpath>[ (TMSL converted to TMDL)]".
3.7 Report-level measures: `pbir` keeps, per reportExtensions entity table, full `Measure(name, expression,
format_string, is_report_level=True)` in `Report.extension_measure_defs`; `merge_report_measures(model, report)`
appends them to their table unless a model measure of that name exists; unknown table -> warning
"report measure [X] targets unknown table 'T'; skipped".

### 4. TMDL fix (`parsers/tmdl.py`)
`sortByColumn` values are unquoted (`'Paid Year Month Nbr'` -> `Paid Year Month Nbr`).

### 5. Power Query (M) parser (`binding/m_parser.py`)
5.1 M text literal `_M_STR = "(?:[^"]|"")*"` (embedded quote is `""`; M has no `\"`), navigation value
`_M_VALUE = <literal> | #<literal> | [\w.]+`. Use it in the `{[Name=...]}` and `{[Schema=..., Item=...]}` patterns.
`m_string(raw)` decodes a literal (`"MEMBER""S"` -> `MEMBER"S`).
5.2 `_m_value(raw, expressions, warnings) -> (text, is_parameter)`: literals decoded; references (bare or
`#"Quoted"`) resolved through shared expressions via `resolve_parameter`.
5.3 `resolve_parameter(value, expressions, warnings=None)`: accepts `#"Name"`; the parameter's literal is decoded
with `m_string`; if the decoded text itself is wrapped in double quotes (source `"""U01_DB"""`) unwrap once and add
warning `parameter «X» is "U01_DB": surrounding double quotes removed, using U01_DB`. Empty -> None.
`MBinding.warnings` carries these; `resolver` copies them into the binding map warnings as `<table>: <warning>`.
Unresolved parameter detail: "parameter(s) not found in the model: «a», «b»".
5.4 `Value.NativeQuery(target, "sql", ...)`: skip the first argument while tracking brackets and string literals,
then decode the second argument literal (`#(lf)` -> newline) -> `native_query`.
5.5 `snowflake_source_args(m_source, expressions) -> (server, warehouse)` from
`Snowflake.Databases(server, warehouse, ...)` (literal or parameter). Used by source hints (phase 05).
5.6 `Table.AddColumn(src, "Col", each <expr>)` -> `computed_columns {Col: sql}` via a best-effort translator:
`[C]` -> `"C"`; integer/float literals; `"txt"` -> `'txt'`; `Number.ToText([C])` -> `CAST("C" AS VARCHAR)`;
`Date.ToText([C], "fmt")` -> `TO_CHAR("C", 'fmt')`; top-level `+ - * / &` (`&` -> `||`) split outside parentheses and
strings; `if <cond> then a else b` -> `CASE WHEN ... THEN ... ELSE ... END` where cond is an `or`/`and` chain of
`[C] = "v"` / `[C] <> "v"` (values with `'` doubled). Anything else -> not translated (column skipped).
`TableBinding.computed_columns` copies them (resolver).

### 6. PBIR parser additions (`parsers/pbir.py`)
6.1 Projection display name: explicit `displayName`; else, for an implicit aggregate or a nameless field,
`nativeQueryRef`; else the field name (nativeQueryRef "Groups1" is an internal unique ref, not a label).
6.2 `active = proj.get("active", True) is not False`.
6.3 "Show value as -> Percent of grand total": an `Arithmetic` field with `Operator == 3` whose `Right.ScopedEval`
has the same `Expression` as `Left` and no `Scope` -> the left field with `show_as="percent_of_grand_total"`.
6.4 Groups: `visual.json` with `visualGroup` instead of `visual` -> `visual_type="visualGroup"`, title from
`visualGroup.displayName`, container objects from `visualGroup.objects`. `parentGroupName` -> `parent_group`.
After all visuals of a page load: positions become canvas-absolute (add every ancestor's x/y), z becomes
`parent_abs_z + child_z / 100000`, `self_hidden = own isHidden`, `is_hidden = own or any ancestor hidden`;
dangling parents -> `parent_group=None`. Cycles are guarded.
6.5 Actions (`visualContainerObjects.visualLink`): first entry whose `show` isn't false and `type` in
Bookmark | PageNavigation | Back | WebUrl | Drillthrough -> `{type, bookmark, page, url, tooltip}` where `page` =
`drillthroughSection` for Drillthrough else `navigationSection`, `url` = `webUrl`; entries missing their required
target (bookmark / page / url) are skipped; None-valued keys dropped. Measure-driven targets are not resolved.
6.6 `_literal_value(prop)`: `{"expr":{"Literal":{"Value": raw}}}` -> `'x'` (with `''` -> `'`), `true/false`,
numbers with `D/L/M` suffix -> float, else the raw string; missing -> None.
6.7 Bookmarks (`parse_bookmarks(definition, pages)`): order from `bookmarks/bookmarks.json` items (children
flattened), then remaining `*.bookmark.json` files sorted. For each: `name`, `display_name`; `page_name` = the
exploration state's `activeSection` if it is a known page and `options.suppressActiveSection` isn't set, else None;
`visibility` (skipped with `options.suppressDisplay`): `visualContainers[v].singleVisual.display.mode == "hidden"`
and `visualContainerGroups[g].isHidden`; `targets` = `options.targetVisualNames` ONLY when
`options.applyOnlyToTargetVisuals` is true, else `[]`; `filters` added in phase 10.
6.8 Interaction graph (`parse_interaction_graph(page_dirs)`): every page.json `visualInteractions` item
`{source, target, type}` with type DataFilter -> FILTER, HighlightFilter -> HIGHLIGHT, NoFilter -> NONE becomes an
edge; nodes = sorted visual names involved. Pairs without an entry keep the default and get no edge.
6.9 Page `display_option = page.json displayOption`; report `vertical_alignment` (2.).
6.10 `parse_report_definition` sets `bookmarks`, `interaction_graph`, `vertical_alignment`,
`extension_measure_defs`.

## Files
Create: `backend/app/parsers/tmsl.py`.
Modify: `ir/model.py`, `ir/report.py`, `parsers/bundle.py`, `parsers/pbir.py`, `parsers/tmdl.py`,
`binding/m_parser.py`, `binding/resolver.py` (warnings + computed columns), `services/ingest.py`.

## Tests
- `tests/test_remote_model.py`: byConnection + TMDL folder; byConnection + `model.bim`; SSMS `.xmla` script;
  several models matched by catalog name; ambiguous -> error text; none -> error with the export hint; generated
  TMDL written under `generated_dir`, never into the upload; connection-string parsing incl. quoted `;`.
  (Fixtures copied from OneDrive are read-only: copy with `shutil.copytree(..., ignore=...)`, don't rely on rmtree.)
- `tests/test_m_rename_and_alias_collision.py` + new M cases: `""` inside literals, `#"Param Name"`, triple-quoted
  parameter warning, NativeQuery second argument with commas/brackets in the first, `Snowflake.Databases` args,
  AddColumn translations (each rule above) and an untranslatable one skipped.
- pbir: display-name rule, `active`, show_as, group absolute positions/z/hidden, actions (incl. Drillthrough), bookmark
  targets only with applyOnlyToTargetVisuals, suppressActiveSection / suppressDisplay, interaction edges.
- model: case-insensitive table/column/measure lookup; ambiguous -> None.

## Done criteria
A byConnection report with a shipped TMDL or TMSL model converts; all tests pass.
 