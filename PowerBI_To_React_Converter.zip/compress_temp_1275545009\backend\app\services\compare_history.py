"""Per-page history of image comparisons and number checks.

Layout: `<conversion>/visual_compare/history/<page>/<run_id>/run.json` (+ `reference.png` /
`rendered.png`). It is a subfolder so the `visual_compare/*.json` globs never see it. Earlier runs
are kept after later ones (the newest `KEEP_RUNS` per page).
"""

from __future__ import annotations

import json
import re
import secrets
import shutil
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

KEEP_RUNS = 25
RUN_ID = re.compile(r"^\d{8}T\d{6}\d{3}-[0-9a-f]{4}$")
PAGE_NAME = re.compile(r'^(?!\.\.?$)[^/\\:*?"<>|\x00-\x1f]{1,200}$')
SIDES = ("reference", "rendered")
KINDS = ("image", "values")


class HistoryError(ValueError):
    pass


def valid_page(page: str) -> str:
    if not PAGE_NAME.match(page or ""):
        raise HistoryError("invalid page name")
    return page


def valid_run_id(run_id: str) -> str:
    if not RUN_ID.match(run_id or ""):
        raise HistoryError("invalid run id")
    return run_id


def _root(conv_dir: Path) -> Path:
    return Path(conv_dir) / "visual_compare" / "history"


def _page_dir(conv_dir: Path, page: str) -> Path:
    return _root(conv_dir) / valid_page(page)


def new_run_id() -> str:
    now = datetime.now(UTC)
    return f"{now:%Y%m%dT%H%M%S}{now.microsecond // 1000:03d}-{secrets.token_hex(2)}"


def summarize(kind: str, payload: dict[str, Any]) -> dict[str, Any]:
    if kind == "image":
        findings = payload.get("findings") or []
        return {
            "similarity": payload.get("similarity"),
            "findings": len(findings),
            "fixable": sum(1 for f in findings if f.get("fixable")),
            "filters_applied": payload.get("filters_applied") or [],
        }
    summary = payload.get("summary") or {}
    return {
        "numbers_printed": summary.get("numbers_printed", 0),
        "numbers_matched": summary.get("numbers_matched", 0),
        "visuals_mismatched": summary.get("mismatch", 0),
        "filters_applied": payload.get("filters_applied") or [],
    }


def record_run(
    conv_dir: Path,
    page: str,
    kind: str,
    payload: dict[str, Any],
    images: dict[str, bytes] | None = None,
    batch_id: str | None = None,
) -> dict[str, Any]:
    """Store one run (and its images); returns the stored record without the payload."""
    if kind not in KINDS:
        raise HistoryError(f"unknown run kind '{kind}'")
    folder = _page_dir(conv_dir, page)
    run_id = new_run_id()
    run_dir = folder / run_id
    run_dir.mkdir(parents=True)
    for side, data in (images or {}).items():
        if side in SIDES and data:
            (run_dir / f"{side}.png").write_bytes(data)
    record = {
        "run_id": run_id,
        "page": page,
        "display_name": payload.get("display_name"),
        "kind": kind,
        "batch_id": batch_id,
        "ts": time.time(),
        "summary": summarize(kind, payload),
        "payload": payload,
    }
    (run_dir / "run.json").write_text(json.dumps(record, indent=2, default=str), encoding="utf-8")
    ids = sorted(d.name for d in folder.iterdir() if d.is_dir() and RUN_ID.match(d.name))
    for old in ids[:-KEEP_RUNS]:
        shutil.rmtree(folder / old, ignore_errors=True)
    return _public(record, run_dir)


def _public(record: dict[str, Any], run_dir: Path) -> dict[str, Any]:
    out = {k: v for k, v in record.items() if k != "payload"}
    out["has_images"] = {side: (run_dir / f"{side}.png").is_file() for side in SIDES}
    return out


def _read(run_dir: Path) -> dict[str, Any] | None:
    try:
        return json.loads((run_dir / "run.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def list_runs(
    conv_dir: Path, page: str, batch_id: str | None = None, limit: int | None = None
) -> list[dict[str, Any]]:
    """Newest first, without payloads; optionally only the runs of one batch."""
    folder = _page_dir(conv_dir, page)
    if not folder.is_dir():
        return []
    out = []
    for run_dir in sorted(folder.iterdir(), key=lambda d: d.name, reverse=True):
        if not (run_dir.is_dir() and RUN_ID.match(run_dir.name)):
            continue
        record = _read(run_dir)
        if record is None or (batch_id is not None and record.get("batch_id") != batch_id):
            continue
        out.append(_public(record, run_dir))
        if limit and len(out) >= limit:
            break
    return out


def load_run(conv_dir: Path, page: str, run_id: str) -> dict[str, Any] | None:
    run_dir = _page_dir(conv_dir, page) / valid_run_id(run_id)
    record = _read(run_dir) if run_dir.is_dir() else None
    if record is None:
        return None
    record["has_images"] = {side: (run_dir / f"{side}.png").is_file() for side in SIDES}
    return record


def run_image(conv_dir: Path, page: str, run_id: str, side: str) -> bytes | None:
    if side not in SIDES:
        raise HistoryError("side must be reference or rendered")
    path = _page_dir(conv_dir, page) / valid_run_id(run_id) / f"{side}.png"
    return path.read_bytes() if path.is_file() else None


def _score(record: dict[str, Any]) -> float | None:
    s = record.get("summary") or {}
    if record.get("kind") == "image":
        value = s.get("similarity")
        return float(value) if isinstance(value, int | float) else None
    printed = s.get("numbers_printed") or 0
    return round((s.get("numbers_matched") or 0) / printed * 100, 1) if printed else None


def trend(conv_dir: Path, page: str, limit: int = 10) -> list[dict[str, Any]]:
    """Oldest first: similarity for image runs, matched-numbers % for number checks."""
    runs = list_runs(conv_dir, page, limit=limit)
    return [
        {"run_id": r["run_id"], "ts": r["ts"], "kind": r["kind"], "value": _score(r)}
        for r in reversed(runs)
    ]


def pages_with_history(conv_dir: Path) -> list[str]:
    root = _root(conv_dir)
    return sorted(d.name for d in root.iterdir() if d.is_dir()) if root.is_dir() else []


def batch_runs(conv_dir: Path, batch_id: str) -> list[dict[str, Any]]:
    """Every run (all pages) recorded under one batch, newest first per page."""
    out: list[dict[str, Any]] = []
    for page in pages_with_history(conv_dir):
        try:
            out.extend(list_runs(conv_dir, page, batch_id=batch_id))
        except HistoryError:
            continue
    return out
