/** Power BI axis bounds: a nice tick just above the data maximum. */

function niceInterval(value: number): number {
  // PBI compact visuals target ~2-3 gridlines
  const rough = value / 2
  const exp = Math.floor(Math.log10(rough))
  const base = Math.pow(10, exp)
  const fraction = rough / base
  const niceFraction = fraction < 1.5 ? 1 : fraction < 3 ? 2 : fraction < 7 ? 5 : 10
  return niceFraction * base
}

/** PBI line/area axes extend to the first nice tick above the data max. */
export function niceCeil(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return value
  const interval = niceInterval(value)
  return Math.ceil(value / interval - 1e-9) * interval
}

/** PBI bar/column axes keep the last full tick when the data only slightly
 * exceeds it (the bar rides past the gridline instead of forcing a new tick). */
export function niceCeilBar(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return value
  const interval = niceInterval(value)
  const floor = Math.floor(value / interval + 1e-9) * interval
  return value - floor <= interval * 0.25 && floor > 0
    ? floor
    : Math.ceil(value / interval - 1e-9) * interval
}
