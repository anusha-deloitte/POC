"""Phase 08: Snowflake query audit (events, reading, exports, live /query logging)."""

from __future__ import annotations

import io
import json
from types import SimpleNamespace

import pytest

from app.core.config import get_settings
from app.runtime.dashboard import DashboardSpec, PageSpec, VisualSpec
from app.services import query_audit as qa
from tests.phase08 import BAR, CARD, PAGE, FakeConn, World, default_responder
from tests.test_api import client  # noqa: F401


def _spec() -> DashboardSpec:
    visual = VisualSpec(
        name="v1", visual_type="clusteredBarChart", x=0, y=0, width=1, height=1, title="Sales by cat"
    )
    untitled = VisualSpec(name="v2", visual_type="card", x=0, y=0, width=1, height=1)
    bare = VisualSpec(name="v3", visual_type="card", x=0, y=0, width=1, height=1)
    page = PageSpec(
        name="p1",
        display_name="Overview",
        width=1,
        height=1,
        ordinal=0,
        visuals=[visual, untitled, bare],
    )
    return DashboardSpec(report_name="r", pages=[page])


def _write(path, **fields):
    qa.write_query_event(path, {"conversion_id": "c1", **fields})


# ------------------------------------------------------------------ events and context


def test_parse_context_labels():
    assert qa.parse_context(None) == (None, None, None)
    assert qa.parse_context("identifier_case_check") == (None, None, "identifier_case_check")
    assert qa.parse_context("visual:p1/v1:main") == ("p1", "v1", "main")
    assert qa.parse_context("visual:p1/v1") == ("p1", "v1", "visual")
    assert qa.parse_context("probe:p1/Total Sales:slicer") == ("p1", "Total Sales", "slicer")
    assert qa.parse_context("ai_rewrite_gate:Total Sales") == (None, "Total Sales", "ai_rewrite_gate")
    assert qa.parse_context("parity_actual:p1/v1") == ("p1", "v1", "parity_actual")
    assert qa.parse_context("something else") == (None, None, "something else")


def test_sql_text_dropped_when_logging_is_off(tmp_path, monkeypatch):
    path = tmp_path / "events.jsonl"
    _write(path, kind="dashboard", page="p1", visual="v1", status="ok", sql="SELECT 1")
    monkeypatch.setattr(get_settings(), "log_sql_text", False)
    _write(path, kind="dashboard", page="p1", visual="v1", status="ok", sql="SELECT 2",
           compat_sql="SELECT 3", totals_sql="SELECT 4")  # fmt: skip
    first, second = [json.loads(line) for line in path.read_text().splitlines()]
    assert first["sql"] == "SELECT 1" and first["sql_logged"] is True
    assert "sql" not in second and "compat_sql" not in second and "totals_sql" not in second
    assert second["sql_logged"] is False


def test_audited_connection_labels_each_execution(tmp_path):
    path = tmp_path / "events.jsonl"
    qa.remember_sql_context("SELECT remembered", "visual:p1/v1:main")
    seen: list[str] = []

    def responder(sql):
        seen.append(sql)
        if "boom" in sql:
            raise RuntimeError("syntax error")
        return ["a"], ([] if "empty" in sql else [(1,)])

    conn = qa.AuditedConnection(
        FakeConn(responder), path, conversion_id="c1", connection_id="k1",
        profile={"warehouse": "WH", "role": "R", "connection_name": "demo"},
    )  # fmt: skip
    cur = conn.cursor()
    cur.execute("SELECT remembered")
    with qa.audit_stage(cur, "probe", "probe:p1/Total Sales:slicer"):
        cur.execute("SELECT empty")
    with conn.stage("setup", "access_preflight"):
        with pytest.raises(RuntimeError):
            cur.execute("SELECT boom")
    events = qa.read_query_events(path)
    assert [e["status"] for e in reversed(events)] == ["ok", "empty", "error"]
    by_sql = {e["sql"]: e for e in events}
    main = by_sql["SELECT remembered"]
    assert (main["kind"], main["page"], main["visual"], main["check"]) == (
        "validation", "p1", "v1", "main"
    )  # fmt: skip
    assert main["warehouse"] == "WH" and main["query_id"] == "qid-1" and main["attempt"] == "primary"
    assert by_sql["SELECT empty"]["kind"] == "probe"
    assert by_sql["SELECT empty"]["check"] == "slicer"
    assert by_sql["SELECT boom"]["error"] == "syntax error"
    assert by_sql["SELECT boom"]["check"] == "access_preflight"
    # outside a stage the plain cursor is untouched
    plain = FakeConn(responder).cursor()
    with qa.audit_stage(plain, "probe", "x"):
        plain.execute("SELECT 1")


# ------------------------------------------------------------------ reading


def test_latest_run_per_pane_with_readable_names(tmp_path):
    path = tmp_path / "events.jsonl"
    _write(path, kind="dashboard", page="p1", visual="v1", status="error", error="old", elapsed_ms=5)
    _write(path, kind="dashboard", page="p1", visual="v1", status="ok", elapsed_ms=30, warehouse="W")
    _write(path, kind="dashboard", page="p1", visual="v2", status="empty", elapsed_ms=10,
           title_value="Revenue 2024")  # fmt: skip
    _write(path, kind="dashboard", page="p1", visual="v1#title", status="ok", elapsed_ms=1)
    _write(path, kind="dashboard", page="p1", visual="v3", status="ok", elapsed_ms=1)
    _write(path, kind="setup", check="identifier_case_check", status="ok", elapsed_ms=2)
    _write(path, kind="probe", page="p1", visual="Total Sales", check="slicer", status="ok")
    _write(path, kind="ai_llm", visual="Margin", check="ai_llm_rewrite", status="ok")
    rows, summary = qa.load_query_audit(path, _spec(), kind="all")
    panes = {(r["kind"], r["pane"]) for r in rows}
    assert ("dashboard", "Sales by cat") in panes
    assert ("dashboard", "Sales by cat (title measure)") in panes
    assert ("dashboard", "Revenue 2024") in panes  # no title: the latest title value
    assert ("dashboard", "card v3") in panes  # nothing else: type + name
    assert ("setup", "Identifier case check") in panes
    assert ("probe", "Filter probe: [Total Sales]") in panes
    assert ("ai_llm", "AI model call (DAX rewrite) [Margin]") in panes
    latest = next(r for r in rows if r["kind"] == "dashboard" and r["visual"] == "v1")
    assert latest["status"] == "ok" and latest["page_name"] == "Overview"
    assert summary["ok"] >= 3 and summary["empty"] == 1 and summary["error"] == 0
    assert summary["slowest_ms"] == 30 and summary["slowest_pane"] == "Sales by cat"
    assert summary["warehouses"] == ["W"]
    assert summary["kinds"]["dashboard"] == 4
    only_dash, _ = qa.load_query_audit(path, _spec())
    assert {r["kind"] for r in only_dash} == {"dashboard"}
    conv, _ = qa.load_query_audit(path, _spec(), kind="conversion")
    assert {r["kind"] for r in conv} == {"probe", "ai_llm"}


def test_history_is_newest_first_and_capped(tmp_path):
    path = tmp_path / "events.jsonl"
    for i in range(60):
        _write(path, kind="dashboard", page="p1", visual="v1", status="ok", elapsed_ms=i)
    rows, _ = qa.load_query_audit(path, _spec(), history_for="p1/v1")
    assert len(rows) == qa.MAX_HISTORY
    assert rows[0]["elapsed_ms"] == 59 and rows[-1]["elapsed_ms"] == 10


def test_legacy_events_without_status(tmp_path):
    path = tmp_path / "events.jsonl"
    from app.core.logging import append_jsonl

    append_jsonl(path, "dashboard_query", page="p1", visual="v1", elapsed_ms=4, error=None)
    append_jsonl(path, "dashboard_query", page="p1", visual="v2", elapsed_ms=4, error="bad")
    append_jsonl(path, "pipeline_stage", stage="validate")  # not a query event
    rows, _ = qa.load_query_audit(path, _spec())
    by = {r["visual"]: r for r in rows}
    assert by["v1"]["legacy"] is True and by["v1"]["status"] == "ok"
    assert by["v2"]["status"] == "error"


def test_events_are_read_newest_first_and_capped(tmp_path):
    path = tmp_path / "events.jsonl"
    for i in range(300):
        _write(path, kind="dashboard", page="p1", visual="v1", status="ok", n=i, pad="x" * 400)
    events = qa.read_query_events(path, limit=250)
    assert len(events) == 250
    assert [e["n"] for e in events[:3]] == [299, 298, 297]
    assert qa.read_query_events(tmp_path / "missing.jsonl") == []


def test_exports(tmp_path, monkeypatch):
    path = tmp_path / "events.jsonl"
    _write(
        path, kind="dashboard", page="p1", visual="v1", status="error", error="boom", sql="SELECT 1",
        request_filters=[{"table": "T", "column": "C", "op": "in", "values": ["a", None],
                          "source": "slicer"}],
        tables=[{"model_table": "Sales", "physical": "DB.PUBLIC.SALES"}],
    )  # fmt: skip
    monkeypatch.setattr(get_settings(), "log_sql_text", False)
    _write(path, kind="dashboard", page="p1", visual="v2", status="ok", sql="SELECT 2")
    rows, summary = qa.load_query_audit(path, _spec())
    payload = qa.build_query_audit_json(rows, summary, "c1")
    assert payload["kind"] == "snowflake_query_audit" and payload["schema_version"] == "1.1"
    assert payload["conversion_id"] == "c1" and len(payload["records"]) == 2
    from openpyxl import load_workbook

    wb = load_workbook(io.BytesIO(qa.build_query_audit_xlsx(rows, summary, "c1")))
    assert wb.sheetnames == ["Summary", "Queries", "Filters"]
    queries = list(wb["Queries"].values)
    header = queries[0]
    err = next(r for r in queries[1:] if r[header.index("Status")] == "error")
    assert err[header.index("Tables")] == "Sales -> DB.PUBLIC.SALES"
    assert err[header.index("Request filters")] == "T.C in a, NULL [slicer]"
    off = next(r for r in queries[1:] if r[header.index("Status")] == "ok")
    assert off[header.index("SQL")] == "SQL logging is off"
    assert list(wb["Filters"].values)[1][7] == "Slicer"
    filtered = qa.filter_records(rows, status="error", search="sales")
    assert [r["visual"] for r in filtered] == ["v1"]


# ------------------------------------------------------------------ live /query logging


@pytest.fixture()
def world(client, contoso_pbip, monkeypatch):  # noqa: F811
    return World(client, contoso_pbip, monkeypatch)


def test_query_writes_audit_records(world):
    r = world.query(CARD, BAR, filters=[{"table": "Customer", "column": "Country",
                                         "values": ["US"], "source": "slicer"}])  # fmt: skip
    assert r.status_code == 200, r.text
    audit = world.get("query-audit", kind="all")
    assert audit.status_code == 200
    body = audit.json()
    by_visual = {x["visual"]: x for x in body["records"]}
    card = by_visual[CARD]
    assert card["status"] == "ok" and card["kind"] == "dashboard" and card["source"] == "editor"
    assert card["warehouse"] == "ANALYTICS_WH" and card["role"] == "ANALYST"
    assert card["connection_name"] == "demo" and card["query_id"].startswith("qid-")
    assert card["row_count"] == 1 and card["execution_path"] == "compatibility"
    assert any(t["model_table"] == "Sales" for t in card["tables"])
    assert card["request_filters"][0]["column"] == "Country"
    assert card["request_filters"][0]["source"] == "slicer"
    assert card["sql"].startswith(("SELECT", "WITH"))
    assert body["summary"]["panes"] == 2 and body["summary"]["ok"] == 2


def test_cache_hits_errors_and_plan_errors_are_recorded(world):
    world.query(CARD)
    again = world.query(CARD)
    assert again.json()["results"][0]["cached"] is True
    good = world.responder
    world.responder = lambda sql: (_ for _ in ()).throw(RuntimeError("SQL compilation error"))
    failed = world.query(CARD, filters=[{"table": "Customer", "column": "Country", "values": ["DE"]}])
    assert failed.json()["results"][0]["error"] == "SQL compilation error"
    world.responder = good
    world.park_measure(dax="FOOBAR(1)")
    world.query(BAR)  # untranslated pane: a plan error
    records = world.get("query-audit", kind="all", source="editor").json()["records"]
    statuses = {r["status"] for r in records}
    assert {"plan_error", "error"} <= statuses  # the latest run per pane; cache hit is in history
    plan = next(r for r in records if r["status"] == "plan_error")
    assert plan["attempt"] == "plan" and plan["visual"] == BAR
    assert "needs tier-2" in plan["error"]
    err = next(r for r in records if r["status"] == "error")
    assert err["error"] == "SQL compilation error" and err["request_filters"]
    history = world.get("query-audit", history_for=f"{PAGE}/{CARD}").json()["records"]
    assert [h["status"] for h in history][:3] == ["error", "cached", "ok"]


def test_totals_and_published_source(world):
    from app.api.dashboards import BatchQueryRequest, run_batch_query
    from app.api.deps import get_connection_store

    def edit(bundle):  # make the bar visual a totals-bearing table
        pass

    req = BatchQueryRequest.model_validate(
        {
            "connection_id": world.conn_id,
            "queries": [{"page": PAGE, "visual": CARD, "filters": []}],
            "execution_tier": "tier_b_compatibility",
        }
    )
    store = world.client.app.dependency_overrides[get_connection_store]()
    run_batch_query(world.cid, req, store, None, source="published")
    published = world.get("query-audit", source="published").json()["records"]
    assert published and all(r["source"] == "published" for r in published)
    assert world.get("query-audit", source="editor").json()["records"] == []


def test_exports_apply_the_screen_filters(world):
    world.query(CARD, BAR)
    xlsx = world.get("query-audit/export", format="xlsx", status="ok")
    assert xlsx.status_code == 200 and "spreadsheetml" in xlsx.headers["content-type"]
    js = world.get("query-audit/export", format="json", search=CARD)
    payload = js.json()
    assert payload["kind"] == "snowflake_query_audit"
    assert [r["visual"] for r in payload["records"]] == [CARD]


def test_unknown_conversion_is_404(client):  # noqa: F811
    r = client.get("/api/v1/conversions/nope/dashboard/query-audit")
    assert r.status_code == 404
    assert client.get("/api/v1/conversions/nope/dashboard/query-audit/export").status_code == 404


def test_default_responder_shape():
    assert default_responder("SELECT 1")[0] == ["Total Sales"]
    assert SimpleNamespace  # keep import used


def test_drill_is_logged(world):
    def edit(bundle):
        pass

    spec = world.get("spec").json()
    bar = next(v for p in spec["pages"] for v in p["visuals"] if v["name"] == BAR)
    assert bar["hierarchy"] is None  # contoso has no hierarchy: drill is rejected, nothing logged
    r = world.post(
        "query/drill",
        {"connection_id": world.conn_id, "page": PAGE, "visual": BAR, "direction": "down"},
    )
    assert r.status_code == 422


def test_drill_record_fields(world, monkeypatch):
    from app.runtime.dashboard import compile_dashboard as real_compile

    def with_hierarchy(*a, **k):
        spec, bm = real_compile(*a, **k)
        for p in spec.pages:
            for v in p.visuals:
                if v.name == BAR:
                    v.hierarchy = {"levels": ["Product.Category"], "current_level": "Product.Category"}
        return spec, bm

    monkeypatch.setattr("app.api.dashboards.compile_dashboard", with_hierarchy)
    r = world.post(
        "query/drill",
        {"connection_id": world.conn_id, "page": PAGE, "visual": BAR, "direction": "down",
         "parent_filters": [{"table": "Customer", "column": "Country", "values": ["US"]}]},
    )  # fmt: skip
    assert r.status_code == 200, r.text
    rec = world.get("query-audit", kind="drill").json()["records"][0]
    assert rec["kind"] == "drill" and rec["drill"]["direction"] == "down"
    assert rec["request_filters"][0]["source"] == "drill" and rec["query_id"]
