"""Shared base for every LLM provider failure.

The pipeline parks a measure on an `LlmError` instead of failing the whole run.
"""


class LlmError(Exception):
    """Base class of every provider failure (Horizon, Cortex)."""
