"""Phase 12: the standalone service's connection store, Snowflake session and connection routes."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi.testclient import TestClient

from app.standalone import snowflake_session as ss
from app.standalone.connection_store import ConnectionStore, SettingsError
from app.standalone.main import create_app
from app.standalone.snowflake_session import AuthenticationRequired, Session

BASE = {
    "account": "acme-xy1", "user": "me", "auth_method": "password", "role": "ANALYST",
    "warehouse": "WH", "database": "DB", "schema": "PUBLIC",
}  # fmt: skip
PEM = (
    rsa.generate_private_key(public_exponent=65537, key_size=2048)
    .private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    )
    .decode()
)


class FakeKeyring:
    def __init__(self):
        self.items: dict[tuple[str, str], str] = {}

    def get_password(self, service, user):
        return self.items.get((service, user))

    def set_password(self, service, user, value):
        self.items[(service, user)] = value

    def delete_password(self, service, user):
        if (service, user) not in self.items:
            raise KeyError("no such entry")
        del self.items[(service, user)]


class FakeConnector:
    """Records every connect() call; `fail` raises once per queued message."""

    def __init__(self):
        self.calls: list[dict] = []
        self.conns: list[FakeConn] = []
        self.errors: list[Exception] = []

    def __call__(self, **kwargs):
        self.calls.append(kwargs)
        if self.errors:
            raise self.errors.pop(0)
        conn = FakeConn()
        self.conns.append(conn)
        return conn


class FakeCursor:
    def __init__(self, conn):
        self.conn = conn
        self.description = [("X",)]
        self.sfqid = "qid"

    def execute(self, sql, *a):
        self.conn.statements.append(sql)

    def fetchall(self):
        return [(1,)]

    def fetchone(self):
        return ("me", "ANALYST", "WH")

    def close(self):
        pass


class FakeConn:
    def __init__(self):
        self.statements: list[str] = []
        self.closed = False

    def cursor(self):
        return FakeCursor(self)

    def is_closed(self):
        return self.closed

    def close(self):
        self.closed = True


@pytest.fixture
def kr():
    return FakeKeyring()


def store_of(tmp_path: Path, kr, **initial) -> ConnectionStore:
    data = tmp_path / "data"
    data.mkdir(exist_ok=True)
    if initial:
        (data / "connection.json").write_text(json.dumps(initial), encoding="utf-8")
    return ConnectionStore(data, "pkg1", keyring_module=kr)


def configured(
    tmp_path, kr, method="password", secrets=None, remember=False, **over
) -> ConnectionStore:
    st = store_of(tmp_path, kr)
    st.update({**BASE, "auth_method": method, **over}, secrets or {}, remember)
    return st


# ---------------------------------------------------------------------------- the store


def test_secrets_never_leave_and_remember_is_opt_in(tmp_path, kr):
    st = configured(tmp_path, kr, secrets={"password": "hunter2"})
    public = st.public()
    assert "hunter2" not in json.dumps(public)
    assert public["saved_secrets"] == ["password"] and public["remember"] is False
    assert "hunter2" not in (tmp_path / "data" / "connection.json").read_text()
    assert not (tmp_path / "data" / "secrets.enc").exists() and kr.items == {}
    st.update({}, {}, True)
    blob = (tmp_path / "data" / "secrets.enc").read_bytes()
    assert b"hunter2" not in blob
    assert ("pbi-standalone-dashboard:pkg1", "secrets-key") in kr.items
    # a new process reads them back through the keyring; the file alone is useless
    again = store_of(tmp_path, kr)
    assert again.secret("password") == "hunter2" and again.load_error is None
    broken = ConnectionStore(tmp_path / "data", "pkg1", keyring_module=FakeKeyring())
    assert broken.secret("password") is None
    assert (
        "saved credentials could not be read" in broken.load_error
        and "enter them again" in broken.load_error
    )


def test_unremember_deletes_the_saved_copy(tmp_path, kr):
    st = configured(tmp_path, kr, secrets={"password": "pw"}, remember=True)
    assert (tmp_path / "data" / "secrets.enc").exists()
    st.update({}, {}, False)
    assert not (tmp_path / "data" / "secrets.enc").exists() and kr.items == {}
    assert st.secret("password") == "pw"  # still held for this run
    st.update({}, {}, True)
    st.forget()
    assert (
        st.secrets() == {} and not (tmp_path / "data" / "secrets.enc").exists() and kr.items == {}
    )
    assert st.public()["saved_secrets"] == [] and st.remember is False


def test_change_classification(tmp_path, kr):
    st = configured(tmp_path, kr, secrets={"password": "pw"})
    assert st.update({}, {}, None) == "none"
    assert st.update({"role": "OTHER"}, {}, None) == "reapply"
    assert st.update({"warehouse": "WH2"}, {}, None) == "reapply"
    assert st.update({"database": "DB2"}, {}, None) == "reconnect"
    assert st.update({"user": "you"}, {}, None) == "reconnect"
    assert st.update({}, {"password": "new"}, None) == "reconnect"
    assert st.update({}, {"password": ""}, None) == "none"  # an empty field keeps the held value
    assert st.secret("password") == "new"
    assert st.update({"auth_method": "external_browser"}, {}, None) == "reconnect"


@pytest.mark.parametrize(
    "settings,secrets,message",
    [
        ({"auth_method": "carrier_pigeon"}, {}, "unknown auth method"),
        ({"account": ""}, {}, "account is required"),
        ({"user": " "}, {}, "user is required"),
        ({"warehouse": ""}, {}, "warehouse is required"),
        ({"warehouse": "bad name!"}, {}, "invalid identifier"),
        ({"role": "bad role"}, {}, "invalid identifier"),
        ({"auth_method": "oauth_client_credentials"}, {}, "client id and a token URL"),
        ({}, {"pat_token": "x"}, "not used by the password method"),
        ({}, {"mystery": "x"}, "unknown secret field"),
    ],
)
def test_validation(tmp_path, kr, settings, secrets, message):
    st = store_of(tmp_path, kr)
    with pytest.raises(SettingsError, match=message):
        st.update({**BASE, **settings}, secrets, None)


def test_quoted_identifiers_are_accepted(tmp_path, kr):
    st = store_of(tmp_path, kr)
    st.update({**BASE, "warehouse": '"My WH"', "role": '"My Role"'}, {"password": "p"}, None)
    assert st.settings()["warehouse"] == '"My WH"'


def test_switching_method_drops_old_secrets(tmp_path, kr):
    st = configured(tmp_path, kr, secrets={"password": "pw"}, remember=True)
    st.update({"auth_method": "pat"}, {"pat_token": "tok"}, None)
    assert st.secrets() == {"pat_token": "tok"}
    assert st.public()["saved_secrets"] == ["pat_token"]
    again = store_of(tmp_path, kr)
    assert again.secrets() == {"pat_token": "tok"}
    st.update({"auth_method": "external_browser"}, {}, None)
    assert st.secrets() == {}


def test_old_packages_default_to_browser_sso(tmp_path, kr):
    st = store_of(
        tmp_path, kr, account="a", user="u", warehouse="W", role="R", database="D", schema="S"
    )
    assert st.settings()["auth_method"] == "external_browser"
    assert st.public()["auth_method"] == "external_browser"


# ---------------------------------------------------------------------------- the session


def session_of(tmp_path, kr, method, secrets=None, connect=None, **over):
    st = configured(tmp_path, kr, method, secrets, **over)
    connector = connect or FakeConnector()
    return Session(st, "tag", connect=connector), connector, st


def test_password_login(tmp_path, kr):
    s, c, _ = session_of(tmp_path, kr, "password", {"password": "pw"})
    s.authenticate()
    kw = c.calls[0]
    assert kw["password"] == "pw" and kw["account"] == "acme-xy1" and kw["user"] == "me"
    assert kw["database"] == "DB" and kw["schema"] == "PUBLIC"
    assert kw["session_parameters"] == {"QUERY_TAG": "tag"} and "authenticator" not in kw
    assert c.conns[0].statements[:2] == ["USE ROLE ANALYST", "USE WAREHOUSE WH"]
    assert s.status()["authenticated"] is True


def test_key_pair_sends_der_bytes(tmp_path, kr):
    s, c, _ = session_of(tmp_path, kr, "key_pair", {"private_key_pem": PEM})
    s.authenticate()
    key = c.calls[0]["private_key"]
    assert isinstance(key, bytes) and key[:1] == b"\x30"  # a DER SEQUENCE, not PEM text
    serialization.load_der_private_key(key, password=None)
    assert "password" not in c.calls[0]


def test_oauth_fetches_a_token_from_the_token_url(tmp_path, kr, monkeypatch):
    seen = {}

    def fetch(url, client_id, secret):
        seen.update(url=url, id=client_id, secret=secret)
        return "tok123"

    monkeypatch.setattr(ss, "_fetch_oauth_token", fetch)
    s, c, _ = session_of(
        tmp_path, kr, "oauth_client_credentials", {"oauth_client_secret": "sec"},
        oauth_client_id="cid", oauth_token_url="https://idp/token",
    )  # fmt: skip
    s.authenticate()
    assert c.calls[0]["authenticator"] == "oauth" and c.calls[0]["token"] == "tok123"
    assert seen == {"url": "https://idp/token", "id": "cid", "secret": "sec"}


def test_pat_login(tmp_path, kr):
    s, c, _ = session_of(tmp_path, kr, "pat", {"pat_token": "pat1"})
    s.authenticate()
    assert (
        c.calls[0]["authenticator"] == "programmatic_access_token" and c.calls[0]["token"] == "pat1"
    )


def test_browser_sso_login_and_url_capture(tmp_path, kr):
    seen: list = []

    def connect(**kwargs):
        import webbrowser

        webbrowser.open("https://sso.example/login")
        seen.append(s.status()["sso_url"])
        return FakeConn()

    s, _, _ = session_of(tmp_path, kr, "external_browser", connect=connect)
    import webbrowser

    real = webbrowser.open
    webbrowser.open = lambda url, *a, **k: True  # never open a real browser
    try:
        s.authenticate()
    finally:
        webbrowser.open = real
    assert seen == ["https://sso.example/login"] and s.status()["sso_url"] is None
    assert s.status()["authenticated"] is True


def test_missing_credentials_point_to_connection_settings(tmp_path, kr):
    s, c, _ = session_of(tmp_path, kr, "password")  # no password held
    with pytest.raises(
        AuthenticationRequired, match="password is not set: open Connection settings"
    ):
        s.authenticate()
    assert c.calls == []
    with pytest.raises(AuthenticationRequired, match="Connection settings"):
        s.run("select 1")
    assert "Connection settings" in s.status()["last_error"]


def test_password_mfa_flow(tmp_path, kr):
    s, c, _ = session_of(tmp_path, kr, "password", {"password": "pw"})
    c.errors.append(Exception("Failed to connect: 394508: MFA with TOTP is required"))
    with pytest.raises(AuthenticationRequired) as e:
        s.authenticate()
    assert e.value.mfa_required is True
    assert s.status()["mfa_required"] is True
    with pytest.raises(AuthenticationRequired, match="6-8 digit"):
        s.authenticate("12ab")
    s.authenticate("123456")
    kw = c.calls[-1]
    assert kw["authenticator"] == "username_password_mfa" and kw["passcode"] == "123456"
    assert s.status()["authenticated"] is True and s.status()["mfa_required"] is False
    # an expired MFA session waits for a new code instead of silently reconnecting
    c.conns[-1].closed = True
    with pytest.raises(AuthenticationRequired) as again:
        s.run("select 1")
    assert again.value.mfa_required is True


def test_silent_methods_reconnect_when_the_session_expires(tmp_path, kr):
    for method, secret in (
        ("password", {"password": "pw"}),
        ("pat", {"pat_token": "t"}),
        ("key_pair", {"private_key_pem": PEM}),
    ):
        s, c, _ = session_of(
            tmp_path / method if (tmp_path / method).mkdir() is None else tmp_path,
            kr,
            method,
            secret,
        )
        s.authenticate()
        c.conns[0].closed = True
        assert s.run("select 1")[1] == [[1]]
        assert len(c.calls) == 2, method


def test_browser_sso_waits_for_the_user(tmp_path, kr):
    s, c, _ = session_of(tmp_path, kr, "external_browser")
    import webbrowser

    real = webbrowser.open
    webbrowser.open = lambda *a, **k: True
    try:
        s.authenticate()
        c.conns[0].closed = True
        with pytest.raises(AuthenticationRequired, match="browser authentication is required"):
            s.run("select 1")
        assert len(c.calls) == 1  # no silent SSO
    finally:
        webbrowser.open = real


def test_role_and_warehouse_change_is_reapplied_without_a_new_sign_in(tmp_path, kr):
    s, c, st = session_of(tmp_path, kr, "password", {"password": "pw"})
    s.authenticate()
    st.update({"role": "OTHER", "warehouse": "WH2"}, {}, None)
    s.apply_settings()
    assert len(c.calls) == 1
    assert c.conns[0].statements[-3:-1] == ["USE ROLE OTHER", "USE WAREHOUSE WH2"]
    assert s.status()["role"] == "OTHER" and s.status()["settings_error"] is None


def test_a_rejected_warehouse_is_reported_but_the_session_stays_open(tmp_path, kr):
    s, c, st = session_of(tmp_path, kr, "password", {"password": "pw"})
    s.authenticate()

    def boom(sql, *a):
        if sql.startswith("USE WAREHOUSE"):
            raise RuntimeError("no usage on WH9")
        FakeCursor.execute(cur, sql)

    st.update({"warehouse": "WH9"}, {}, None)
    conn = c.conns[0]
    cur = conn.cursor()
    conn.cursor = lambda: type("C", (FakeCursor,), {"execute": lambda self, sql, *a: boom(sql)})(
        conn
    )
    s.apply_settings()
    status = s.status()
    assert status["authenticated"] is True and "no usage on WH9" in status["settings_error"]


def test_sign_out_and_reset(tmp_path, kr):
    s, c, _ = session_of(tmp_path, kr, "pat", {"pat_token": "t"})
    s.authenticate()
    s.sign_out()
    assert c.conns[0].closed and s.status()["authenticated"] is False


# ---------------------------------------------------------------------------- the routes


@pytest.fixture
def api(tmp_path, kr, monkeypatch):
    monkeypatch.setenv("PBIS_NO_AUTOSTART", "1")
    root = tmp_path / "pkg"
    (root / "data").mkdir(parents=True)
    (root / "data" / "spec.json").write_text(json.dumps({"report_name": "R", "pages": []}))
    (root / "data" / "manifest.json").write_text(
        json.dumps({"version": 1, "package_id": "p1", "report_name": "R", "queries": {}})
    )
    (root / "data" / "token.txt").write_text("tok")
    (root / "data" / "connection.json").write_text(
        json.dumps({**BASE, "auth_method": "password", "remember": False})
    )
    store = ConnectionStore(root / "data", "p1", keyring_module=kr)
    connector = FakeConnector()
    session = Session(store, connect=connector)
    app = create_app(root, session=session, store=store)
    client = TestClient(app, headers={"Authorization": "Bearer tok"})
    client.connector, client.store, client.kr, client.root = connector, store, kr, root  # type: ignore[attr-defined]
    return client


URL = "/api/v1/published"


def test_connection_endpoints(api):
    got = api.get(f"{URL}/connection").json()
    assert got["account"] == "acme-xy1" and got["saved_secrets"] == [] and got["remember"] is False
    assert got["load_error"] is None and got["schema"] == "PUBLIC"

    put = api.put(
        f"{URL}/connection", json={**BASE, "secrets": {"password": "pw"}, "remember": False}
    ).json()
    assert (
        put["change"] == "reconnect"
        and put["saved_secrets"] == ["password"]
        and "pw" not in json.dumps(put)
    )
    assert put["session"]["authenticated"] is False

    ok = api.post(f"{URL}/session/authenticate", json={}).json()
    assert ok == {"ok": True}
    assert api.get(f"{URL}/session").json()["authenticated"] is True

    again = api.put(f"{URL}/connection", json={**BASE, "role": "OTHER"}).json()
    assert again["change"] == "reapply" and again["session"]["authenticated"] is True
    assert len(api.connector.calls) == 1

    same = api.put(f"{URL}/connection", json=BASE).json()
    assert same["change"] == "reapply" or same["change"] == "none"

    bad = api.put(f"{URL}/connection", json={**BASE, "warehouse": ""})
    assert bad.status_code == 422 and "warehouse is required" in bad.text

    gone = api.delete(f"{URL}/connection/secrets").json()
    assert gone["saved_secrets"] == [] and gone["session"]["authenticated"] is False


def test_authenticate_reports_failures_and_mfa(api):
    api.put(f"{URL}/connection", json={**BASE, "secrets": {"password": "pw"}})
    api.connector.errors.append(Exception("Incorrect username or password was specified."))
    bad = api.post(f"{URL}/session/authenticate", json={}).json()
    assert bad["ok"] is False and "Incorrect username" in bad["error"]
    api.connector.errors.append(Exception("394508: MFA with TOTP"))
    mfa = api.post(f"{URL}/session/authenticate", json={}).json()
    assert mfa["ok"] is False and mfa["mfa_required"] is True
    done = api.post(f"{URL}/session/authenticate", json={"passcode": "123456"}).json()
    assert done == {"ok": True}
    assert api.post(f"{URL}/session/sign-out").json() == {"ok": True}
    assert api.get(f"{URL}/session").json()["authenticated"] is False


def test_connection_routes_need_the_token(api):
    anon = TestClient(api.app)
    for method, path in (
        ("get", "/connection"),
        ("put", "/connection"),
        ("delete", "/connection/secrets"),
        ("post", "/session/sign-out"),
    ):
        assert getattr(anon, method)(f"{URL}{path}").status_code == 401


def test_secret_values_never_appear_in_any_response(api):
    api.put(
        f"{URL}/connection",
        json={**BASE, "secrets": {"password": "s3cret-value"}, "remember": True},
    )
    for path in ("/connection", "/session"):
        assert "s3cret-value" not in api.get(f"{URL}{path}").text
    assert "s3cret-value" not in (api.root / "data" / "connection.json").read_text()
    assert b"s3cret-value" not in (api.root / "data" / "secrets.enc").read_bytes()
