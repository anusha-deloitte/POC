"""Positioned text from a Power BI PDF export (pypdfium2), plus printed-number parsing.

Used by content-based page matching (`pdf_matching`) and by the number checks (`pdf_values`).
Coordinates are PDF points with the origin at the TOP-left of the page.
"""

from __future__ import annotations

import io
import re
from dataclasses import dataclass, field
from typing import Any

_TARGET_WIDTH = 1920  # same raster width as pdf_reference
MAX_PAGES = 50


class PdfTextError(Exception):
    pass


@dataclass
class TextRun:
    text: str
    x0: float
    y0: float
    x1: float
    y1: float
    size: float
    font: str = ""
    truncated: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text, "x0": self.x0, "y0": self.y0, "x1": self.x1, "y1": self.y1,
            "size": self.size, "font": self.font, "truncated": self.truncated,
        }  # fmt: skip

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TextRun:
        return cls(
            text=str(d["text"]), x0=float(d["x0"]), y0=float(d["y0"]), x1=float(d["x1"]),
            y1=float(d["y1"]), size=float(d.get("size", 0)), font=str(d.get("font", "")),
            truncated=bool(d.get("truncated", False)),
        )  # fmt: skip


@dataclass
class PdfPageText:
    index: int
    width_pt: float
    height_pt: float
    runs: list[TextRun] = field(default_factory=list)
    png: bytes | None = None

    @property
    def aspect(self) -> float:
        return self.width_pt / self.height_pt if self.height_pt else 1.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "index": self.index, "width_pt": self.width_pt, "height_pt": self.height_pt,
            "runs": [r.to_dict() for r in self.runs],
        }  # fmt: skip

    @classmethod
    def from_dict(cls, d: dict[str, Any], png: bytes | None = None) -> PdfPageText:
        return cls(
            index=int(d["index"]), width_pt=float(d["width_pt"]), height_pt=float(d["height_pt"]),
            runs=[TextRun.from_dict(r) for r in d.get("runs", [])], png=png,
        )  # fmt: skip


# ------------------------------------------------------------------ extraction

_PRIVATE_USE = re.compile("[-￰-￿]")
_CONTROL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def _clean(text: str) -> str:
    text = _PRIVATE_USE.sub("", text)
    text = _CONTROL.sub("", text)
    return re.sub(r"\s+", " ", text).strip()


def _font_name(pdfium_c: Any, ctypes: Any, textpage: Any, index: int) -> str:
    try:
        flags = ctypes.c_int()
        needed = pdfium_c.FPDFText_GetFontInfo(textpage, index, None, 0, ctypes.byref(flags))
        if needed <= 0:
            return ""
        buf = ctypes.create_string_buffer(needed)
        pdfium_c.FPDFText_GetFontInfo(textpage, index, buf, needed, ctypes.byref(flags))
        return buf.value.decode("utf-8", "ignore")
    except Exception:  # noqa: BLE001 - the font name only helps grouping
        return ""


def _page_runs(page: Any, height: float) -> list[TextRun]:
    import ctypes

    import pypdfium2.raw as pdfium_c

    tp = page.get_textpage()
    try:
        n = tp.count_chars()
        runs: list[TextRun] = []
        cur: dict[str, Any] | None = None
        pending_space = False

        def flush() -> None:
            nonlocal cur, pending_space
            if cur is not None:
                text = _clean("".join(cur["chars"]))
                truncated = text.endswith("…")
                if truncated:
                    text = text[:-1].rstrip()
                if text:
                    runs.append(
                        TextRun(text, cur["x0"], cur["y0"], cur["x1"], cur["y1"], cur["size"],
                                cur["font"], truncated)
                    )  # fmt: skip
            cur = None
            pending_space = False

        for i in range(n):
            ch = tp.get_text_range(i, 1)
            if not ch:
                continue
            if ch in ("\r", "\n"):
                flush()
                continue
            if ch.isspace():
                pending_space = cur is not None
                continue
            left, bottom, right, top = tp.get_charbox(i)
            x0, x1 = left, right
            y0, y1 = height - top, height - bottom
            size = float(pdfium_c.FPDFText_GetFontSize(tp.raw, i)) or (y1 - y0)
            font = _font_name(pdfium_c, ctypes, tp.raw, i)
            if cur is not None:
                gap_now = x0 - cur["x1"]
                if not pending_space and 0.4 * size < gap_now < max(size, 1):
                    pending_space = True  # separate text objects a word-gap apart
                same = (
                    cur["font"] == font
                    and abs(cur["size"] - size) <= 0.05
                    and abs(cur["y1"] - y1) <= max(0.4 * size, 1)
                    and (x0 - cur["x1"]) < max(size, 1)
                    and (x0 - cur["x1"]) > -max(size, 1)
                )
                if not same:
                    flush()
            if cur is None:
                cur = {
                    "chars": [],
                    "x0": x0,
                    "y0": y0,
                    "x1": x1,
                    "y1": y1,
                    "size": size,
                    "font": font,
                }
            else:
                if pending_space:
                    cur["chars"].append(" ")
                cur["x0"], cur["y0"] = min(cur["x0"], x0), min(cur["y0"], y0)
                cur["x1"], cur["y1"] = max(cur["x1"], x1), max(cur["y1"], y1)
            pending_space = False
            cur["chars"].append(ch)
        flush()
        return runs
    finally:
        tp.close()


def extract_pages(pdf_bytes: bytes, with_images: bool = True) -> list[PdfPageText]:
    """Every PDF page with its positioned text runs (and a PNG when `with_images`)."""
    try:
        import pypdfium2 as pdfium
    except ModuleNotFoundError as e:  # pragma: no cover - install-time guard
        raise PdfTextError("PDF support not installed (pip install .[pdf])") from e
    try:
        doc = pdfium.PdfDocument(pdf_bytes)
    except Exception as e:  # noqa: BLE001 - pdfium raises PdfiumError
        raise PdfTextError(f"not a readable PDF: {e}") from e
    try:
        n = len(doc)
        if n == 0:
            raise PdfTextError("PDF has no pages")
        if n > MAX_PAGES:
            raise PdfTextError(f"PDF has {n} pages; limit is {MAX_PAGES}")
        out: list[PdfPageText] = []
        for i in range(n):
            page = doc[i]
            width, height = float(page.get_width() or 1), float(page.get_height() or 1)
            png = None
            if with_images:
                pil = page.render(scale=_TARGET_WIDTH / width).to_pil()
                buf = io.BytesIO()
                pil.save(buf, format="PNG")
                png = buf.getvalue()
            out.append(PdfPageText(i, width, height, _page_runs(page, height), png))
        return out
    finally:
        doc.close()


def pdf_title(pdf_bytes: bytes) -> str | None:
    """The PDF's Title metadata (used as a hint when matching reports), if any."""
    try:
        import pypdfium2 as pdfium

        doc = pdfium.PdfDocument(pdf_bytes)
        try:
            title = (doc.get_metadata_dict() or {}).get("Title")
        finally:
            doc.close()
        title = _clean(title or "")
        return title or None
    except Exception:  # noqa: BLE001
        return None


# ------------------------------------------------------------------ tokens and numbers

_WORD = re.compile(r"[a-z][a-z'&]*[a-z]|[a-z]")


def label_tokens(text: str) -> list[str]:
    """Lower-case letter words of 3+ characters. Numbers are excluded: they change between runs."""
    return [w for w in _WORD.findall(text.lower()) if len(w) >= 3]


_NUMERIC_CHARS = re.compile(r"[0-9$€£()\-+.,%\sKMBT]*")


def is_numeric_text(text: str) -> bool:
    """Only `$€£()-+.,%`, digits and K/M/B/T/bn, with at least one digit."""
    t = text.strip().replace("bn", "")
    return bool(t) and any(c.isdigit() for c in t) and _NUMERIC_CHARS.fullmatch(t) is not None


_UNITS = {"k": 1e3, "m": 1e6, "b": 1e9, "bn": 1e9, "t": 1e12}
_NUMBER = re.compile(
    r"(?P<open>\()?"
    r"(?:(?<![\w.])(?P<sign>[-+]))?"
    r"(?:(?P<cur>[$€£])(?P<sign2>[-+])?)?"
    r"(?P<num>\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?|\.\d+)"
    r"(?P<unit>bn|[kKmMbBtT])?(?![A-Za-z])"
    r"(?P<pct>\s*%)?"
    r"(?P<close>\))?"
)


@dataclass
class PrintedNumber:
    text: str
    value: float  # base units; percents stay in percent units
    decimals: int
    scale: float
    percent: bool
    currency: str | None

    @property
    def tolerance(self) -> float:
        return 0.5 * 10 ** (-self.decimals) * self.scale

    def matches(self, v: float) -> bool:
        return abs(v - self.value) <= self.tolerance + 1e-9 * max(abs(v), 1.0)


def parse_numbers(text: str) -> list[PrintedNumber]:
    """Every printed number in `text`: "$2.14M", "120.20K", "1.19%", "(1,234)" (negative, unless
    it is a percent in brackets: "9.99K (19.06%)" gives two positive numbers). A sign only counts
    when it touches the number ("Package - 200" is not -200)."""
    out: list[PrintedNumber] = []
    for m in _NUMBER.finditer(text):
        raw = m.group("num")
        decimals = len(raw.split(".")[1]) if "." in raw else 0
        unit = (m.group("unit") or "").lower()
        scale = _UNITS.get(unit, 1.0)
        value = float(raw.replace(",", "")) * scale
        negative = "-" in ((m.group("sign") or "") + (m.group("sign2") or ""))
        percent = m.group("pct") is not None
        if m.group("open") and m.group("close") and not percent:
            negative = True
        out.append(
            PrintedNumber(
                text=m.group(0).strip(),
                value=-value if negative else value,
                decimals=decimals,
                scale=scale,
                percent=percent,
                currency=m.group("cur"),
            )
        )
    return out
