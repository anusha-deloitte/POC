# Stops the dashboard's local service (the process recorded in logs\service.pid).
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidFile = "$root\logs\service.pid"
if (-not (Test-Path $pidFile)) {
    Write-Host "No running dashboard service was recorded."
    exit 0
}
$id = [int](Get-Content $pidFile -Raw).Trim()
$proc = Get-Process -Id $id -ErrorAction SilentlyContinue
if ($proc -and $proc.ProcessName -like 'python*') {
    Stop-Process -Id $id -Force
    Write-Host "The dashboard service was stopped."
} else {
    Write-Host "The dashboard service was not running."
}
Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
