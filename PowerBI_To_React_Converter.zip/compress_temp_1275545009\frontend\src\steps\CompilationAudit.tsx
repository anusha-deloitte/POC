import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { auditApi } from '../api/client'
import type { CompilationRecord } from '../api/types'
import { useWizard } from '../store/wizard'
import { MeasureSqlFix } from './MeasureSqlFix'

const STATUS_LABEL: Record<string, string> = {
  working: 'Working',
  degraded: 'Degraded',
  broken: 'Broken',
}
const STATUS_BADGE: Record<string, string> = {
  working: 'badge-green',
  degraded: 'badge-amber',
  broken: 'badge-red',
}

export function tierLabel(type: string): string {
  switch (type) {
    case 'tier0':
      return 'Tier 0'
    case 'tier1':
      return 'Tier 1'
    case 'tier2':
      return 'Tier 2 (AI)'
    case 'parked':
      return 'Parked'
    case 'manual_sql':
      return 'Manual SQL'
    default:
      return type
  }
}

function Card({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl border border-black/[0.06] bg-white p-3">
      <div className="text-[10px] font-bold tracking-wider text-surface-500 uppercase">{label}</div>
      <div className="mt-1 text-lg font-bold">{value}</div>
    </div>
  )
}

function Row({ record, onOpenQueries }: { record: CompilationRecord; onOpenQueries?: (m: string) => void }) {
  const [open, setOpen] = useState(false)
  return (
    <>
      <tr
        className="cursor-pointer border-t border-surface-100 hover:bg-surface-100/60"
        onClick={() => setOpen(!open)}
        data-testid="audit-row"
      >
        <td className="px-3 py-1.5 font-semibold">[{record.measure_name}]</td>
        <td className="px-2 py-1.5 text-surface-600">{record.model_table}</td>
        <td className="px-2 py-1.5">
          <span className={STATUS_BADGE[record.overall_status] ?? 'badge-blue'}>
            {STATUS_LABEL[record.overall_status] ?? record.overall_status}
          </span>
        </td>
        <td className="px-2 py-1.5">
          <span className="badge-blue">{tierLabel(record.compiler_type)}</span>
        </td>
        <td className="px-2 py-1.5 text-surface-500">
          {record.dax_complexity_score != null ? record.dax_complexity_score.toFixed(2) : '—'}
        </td>
        <td className="px-2 py-1.5 text-surface-500">
          {record.sql_complexity != null ? record.sql_complexity.toFixed(2) : '—'}
        </td>
      </tr>
      {open && (
        <tr>
          <td colSpan={6} className="bg-surface-50 px-4 py-3 text-xs" data-testid="audit-detail">
            {record.compilation_error && (
              <p className="text-brand-red">Compile error: {record.compilation_error}</p>
            )}
            {record.sql_error && <p className="text-brand-red">SQL error: {record.sql_error}</p>}
            {record.validation_error && (
              <p className="text-brand-red">Validation error: {record.validation_error}</p>
            )}
            <div className="mt-2 font-semibold">DAX expression</div>
            <pre className="mt-1 max-h-48 overflow-auto rounded-lg bg-white p-2 whitespace-pre-wrap">
              {record.dax_expression}
            </pre>
            {record.generated_sql && (
              <>
                <div className="mt-2 font-semibold">Generated SQL</div>
                <pre className="mt-1 max-h-48 overflow-auto rounded-lg bg-white p-2 whitespace-pre-wrap">
                  {record.generated_sql}
                </pre>
              </>
            )}
            {record.dax_leaves && record.dax_leaves.length > 0 && (
              <>
                <div className="mt-2 font-semibold">Leaf aggregates</div>
                <ul className="mt-1 ml-4 list-disc">
                  {record.dax_leaves.map((leaf) => (
                    <li key={leaf.alias}>
                      <code>{leaf.sql}</code> over {leaf.tables.join(', ')}
                    </li>
                  ))}
                </ul>
              </>
            )}
            <div className="mt-2 flex items-center gap-2">
              {onOpenQueries && (
                <button
                  type="button"
                  className="text-brand-blue underline"
                  onClick={() => onOpenQueries(record.measure_name)}
                >
                  Open the Snowflake query audit on the panes using this measure
                </button>
              )}
            </div>
            <MeasureSqlFix measure={record.measure_name} />
          </td>
        </tr>
      )}
    </>
  )
}

export function CompilationAudit({
  initialSearch = '',
  initialExact = false,
  onOpenQueries,
}: {
  initialSearch?: string
  initialExact?: boolean
  onOpenQueries?: (measure: string) => void
}) {
  const conversionId = useWizard((s) => s.conversionId)!
  const [search, setSearch] = useState(initialSearch)
  const [exact, setExact] = useState(initialExact)
  const [status, setStatus] = useState('all')
  const audit = useQuery({
    queryKey: ['compilation-audit', conversionId],
    queryFn: () => auditApi.compilationAudit(conversionId),
    retry: false,
  })

  const rows = useMemo(() => {
    const needle = search.trim().toLowerCase()
    return (audit.data?.records ?? []).filter((r) => {
      if (status !== 'all' && r.overall_status !== status) return false
      if (!needle) return true
      if (exact) return r.measure_name.toLowerCase() === needle
      return (
        r.measure_name.toLowerCase().includes(needle) || r.model_table.toLowerCase().includes(needle)
      )
    })
  }, [audit.data, search, exact, status])

  if (audit.isLoading) return <p className="text-sm text-surface-500">Loading DAX audit…</p>
  if (audit.isError) {
    return (
      <p data-testid="compilation-audit" className="text-sm text-surface-600">
        {audit.error.message}
      </p>
    )
  }
  const { summary } = audit.data!

  return (
    <div data-testid="compilation-audit" className="mb-6">
      <div className="mb-3 grid grid-cols-2 gap-2 md:grid-cols-4 lg:grid-cols-8">
        <Card label="Success rate" value={`${summary.percentage_working}%`} />
        <Card label="Total measures" value={summary.total} />
        <Card label="Working" value={summary.working} />
        <Card label="Degraded" value={summary.degraded} />
        <Card label="Broken" value={summary.broken} />
        <Card label="Avg DAX complexity" value={summary.avg_dax_complexity.toFixed(2)} />
        <Card label="Avg SQL complexity" value={summary.avg_sql_complexity.toFixed(2)} />
        <Card label="Manual SQL" value={summary.by_compiler_type.manual_sql ?? 0} />
      </div>
      <div data-testid="compilation-breakdown" className="mb-3 flex flex-wrap gap-2 text-xs">
        {Object.entries(summary.by_compiler_type).map(([type, n]) => (
          <span key={type} className="badge-blue">
            {tierLabel(type)}: {n}
          </span>
        ))}
      </div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <input
          className="input !w-64"
          placeholder="Filter by measure or table…"
          aria-label="Filter by measure or table"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <label className="flex items-center gap-1 text-xs">
          <input type="checkbox" checked={exact} onChange={(e) => setExact(e.target.checked)} />
          Exact match
        </label>
        <select
          aria-label="Status"
          className="input !w-36"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option value="all">All statuses</option>
          <option value="working">Working</option>
          <option value="degraded">Degraded</option>
          <option value="broken">Broken</option>
        </select>
        <a
          className="btn-secondary !text-xs"
          href={auditApi.compilationAuditExportUrl(conversionId, 'xlsx')}
        >
          Download Excel
        </a>
        <a
          className="btn-secondary !text-xs"
          href={auditApi.compilationAuditExportUrl(conversionId, 'json')}
        >
          Download JSON
        </a>
      </div>
      <table className="w-full text-xs">
        <thead className="bg-surface-100 text-left">
          <tr>
            <th className="px-3 py-1.5">Measure</th>
            <th className="px-2 py-1.5">Table</th>
            <th className="px-2 py-1.5">Status</th>
            <th className="px-2 py-1.5">Compiler</th>
            <th className="px-2 py-1.5">DAX</th>
            <th className="px-2 py-1.5">SQL</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <Row key={r.measure_name} record={r} onOpenQueries={onOpenQueries} />
          ))}
          {rows.length === 0 && (
            <tr>
              <td colSpan={6} className="px-3 py-3 text-surface-500">
                No measures match.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  )
}
