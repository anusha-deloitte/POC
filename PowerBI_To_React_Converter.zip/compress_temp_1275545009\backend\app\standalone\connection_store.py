"""Snowflake connection settings and secrets of a standalone dashboard package.

Settings live in `data/connection.json` (never secrets). Secrets are held in memory; with
"remember" they are also saved to `data/secrets.enc`, encrypted with a Fernet key kept in the
Windows Credential Manager (via `keyring`), so the file alone is useless.

Shipped verbatim inside the package as `service/connection_store.py`: standard library plus
`cryptography` / `keyring` only.
"""

from __future__ import annotations

import json
import re
import threading
from pathlib import Path
from typing import Any

SETTING_FIELDS = (
    "account", "user", "auth_method", "role", "warehouse", "database", "schema",
    "oauth_client_id", "oauth_token_url",
)  # fmt: skip
AUTH_METHODS = ("password", "key_pair", "oauth_client_credentials", "pat", "external_browser")
SECRET_FIELDS: dict[str, tuple[str, ...]] = {
    "password": ("password",),
    "key_pair": ("private_key_pem", "private_key_passphrase"),
    "oauth_client_credentials": ("oauth_client_secret",),
    "pat": ("pat_token",),
    "external_browser": (),
}
ALL_SECRETS = tuple(s for fields in SECRET_FIELDS.values() for s in fields)
DEFAULT_METHOD = "external_browser"  # packages exported before methods existed
# a change to any of these needs a new sign-in; role / warehouse alone are re-applied
_RECONNECT_FIELDS = (
    "account", "user", "auth_method", "database", "schema", "oauth_client_id", "oauth_token_url",
)  # fmt: skip
_PLAIN_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")
_QUOTED_IDENT = re.compile(r'^"[^"]+"$')
KEYRING_USER = "secrets-key"


class SettingsError(ValueError):
    """Invalid connection settings (HTTP 422)."""


def identifier(name: str) -> str:
    """A warehouse / role usable in USE ...: plain names stay unquoted, quoted ones are exact."""
    value = (name or "").strip()
    if _PLAIN_IDENT.match(value) or _QUOTED_IDENT.match(value):
        return value
    raise ValueError(f"invalid identifier: '{name}'")


def _clean(value: Any) -> str | None:
    value = str(value).strip() if value is not None else ""
    return value or None


class ConnectionStore:
    def __init__(self, data_dir: Path | str, package_id: str, keyring_module: Any = None):
        self.data_dir = Path(data_dir)
        self.package_id = package_id
        self._keyring = keyring_module
        self._lock = threading.RLock()
        self._settings: dict[str, str | None] = dict.fromkeys(SETTING_FIELDS)
        self._secrets: dict[str, str] = {}
        self._remember = False
        self.load_error: str | None = None
        self._load()

    # ------------------------------------------------------------------ files / keyring

    @property
    def _settings_file(self) -> Path:
        return self.data_dir / "connection.json"

    @property
    def _secrets_file(self) -> Path:
        return self.data_dir / "secrets.enc"

    @property
    def _service_name(self) -> str:
        return f"pbi-standalone-dashboard:{self.package_id}"

    def _kr(self) -> Any:
        if self._keyring is None:
            import keyring

            self._keyring = keyring
        return self._keyring

    def _fernet(self, create: bool):
        from cryptography.fernet import Fernet

        keyring = self._kr()
        key = keyring.get_password(self._service_name, KEYRING_USER)
        if key is None:
            if not create:
                raise RuntimeError("the encryption key is not in the Windows Credential Manager")
            key = Fernet.generate_key().decode()
            keyring.set_password(self._service_name, KEYRING_USER, key)
        return Fernet(key.encode())

    def _load(self) -> None:
        try:
            raw = json.loads(self._settings_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            raw = {}
        for field in SETTING_FIELDS:
            self._settings[field] = _clean(raw.get(field))
        if not self._settings["auth_method"]:
            self._settings["auth_method"] = DEFAULT_METHOD
        self._remember = bool(raw.get("remember"))
        if self._remember and self._secrets_file.is_file():
            try:
                blob = self._secrets_file.read_bytes()
                data = json.loads(self._fernet(create=False).decrypt(blob))
                self._secrets = {k: str(v) for k, v in data.items() if k in ALL_SECRETS and v}
            except Exception as e:  # noqa: BLE001 - keyring / crypto raise many types
                self._secrets = {}
                self.load_error = (
                    f"saved credentials could not be read ({type(e).__name__}: {e}); "
                    "enter them again"
                )

    def _write_settings(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        body = {f: self._settings[f] for f in SETTING_FIELDS}
        body["remember"] = self._remember
        self._settings_file.write_text(json.dumps(body, indent=2), encoding="utf-8")

    def _save_secrets(self) -> None:
        self.data_dir.mkdir(parents=True, exist_ok=True)
        token = self._fernet(create=True).encrypt(json.dumps(self._secrets).encode())
        self._secrets_file.write_bytes(token)

    def _delete_saved(self) -> None:
        self._secrets_file.unlink(missing_ok=True)
        try:
            self._kr().delete_password(self._service_name, KEYRING_USER)
        except Exception:  # noqa: BLE001, S110 - nothing saved, or no keyring entry
            pass

    # ------------------------------------------------------------------ views

    @property
    def remember(self) -> bool:
        return self._remember

    def settings(self) -> dict[str, str | None]:
        with self._lock:
            return dict(self._settings)

    def secret(self, name: str) -> str | None:
        with self._lock:
            return self._secrets.get(name)

    def secrets(self) -> dict[str, str]:
        with self._lock:
            return dict(self._secrets)

    def public(self) -> dict[str, Any]:
        """Settings, which secrets are held (names only, never values) and whether they persist."""
        with self._lock:
            return {
                **self._settings,
                "remember": self._remember,
                "saved_secrets": sorted(self._secrets),
                "load_error": self.load_error,
            }

    # ------------------------------------------------------------------ changes

    def update(
        self,
        settings: dict[str, Any],
        secrets: dict[str, Any] | None = None,
        remember: bool | None = None,
    ) -> str:
        """Validate and apply; returns "reconnect", "reapply" or "none"."""
        secrets = secrets or {}
        with self._lock:
            new = dict(self._settings)
            for field in SETTING_FIELDS:
                if field in settings:
                    new[field] = _clean(settings[field])
            method = new["auth_method"] or DEFAULT_METHOD
            new["auth_method"] = method
            if method not in AUTH_METHODS:
                raise SettingsError(f"unknown auth method '{method}'")
            for field, label in (
                ("account", "account"),
                ("user", "user"),
                ("warehouse", "warehouse"),
            ):
                if not new[field]:
                    raise SettingsError(f"{label} is required")
            for field in ("warehouse", "role"):
                if new[field]:
                    try:
                        identifier(new[field])
                    except ValueError as e:
                        raise SettingsError(str(e)) from e
            if method == "oauth_client_credentials" and not (
                new["oauth_client_id"] and new["oauth_token_url"]
            ):
                raise SettingsError("OAuth needs a client id and a token URL")
            allowed = SECRET_FIELDS[method]
            supplied = {k: str(v) for k, v in secrets.items() if v not in (None, "")}
            unknown = [k for k in supplied if k not in ALL_SECRETS]
            if unknown:
                raise SettingsError(f"unknown secret field '{unknown[0]}'")
            unused = [k for k in supplied if k not in allowed]
            if unused:
                raise SettingsError(f"'{unused[0]}' is not used by the {method} method")

            old = self._settings
            held = {k: v for k, v in self._secrets.items() if k in allowed}  # switching drops old
            secrets_changed = any(held.get(k) != v for k, v in supplied.items())
            held.update(supplied)
            want_remember = self._remember if remember is None else bool(remember)

            if method != old["auth_method"] and not secrets_changed and held != self._secrets:
                secrets_changed = (
                    False  # dropping old secrets alone is covered by the method change
                )
            change = "none"
            if any(new[f] != old[f] for f in _RECONNECT_FIELDS) or secrets_changed:
                change = "reconnect"
            elif new["role"] != old["role"] or new["warehouse"] != old["warehouse"]:
                change = "reapply"

            self._settings = new
            dropped = held != self._secrets
            self._secrets = held
            was_remembered = self._remember
            self._remember = want_remember
            self._write_settings()
            if want_remember and self._secrets:
                if dropped or secrets_changed or not was_remembered:
                    self._save_secrets()
            elif was_remembered and not want_remember:
                self._delete_saved()
            elif want_remember and not self._secrets and self._secrets_file.is_file():
                self._secrets_file.unlink(missing_ok=True)
            self.load_error = None
            return change

    def forget(self) -> None:
        """Drop every held and saved secret."""
        with self._lock:
            self._secrets = {}
            self._remember = False
            self._delete_saved()
            self._write_settings()
            self.load_error = None
