import { createContext, useContext } from 'react'
import type { PageSpec, PbirField, PbiThemePayload, VisualSpec } from '../types'
import { PBI_DEFAULTS } from './defaults'
import { font, type FontSpec } from './fonts'
import {
  color,
  decodeLiteral,
  lit,
  litBool,
  litNumber,
  litString,
  withAlpha,
  type ColorTokens,
  type Node,
} from './literal'

type Dict = Record<string, unknown>
const isDict = (v: unknown): v is Dict => typeof v === 'object' && v !== null && !Array.isArray(v)

export interface ResolvedTheme {
  tokens: ColorTokens & { secondaryForeground: string; fontFamily: string }
  customStyles: Dict
}

export const EMPTY_THEME_PAYLOAD: PbiThemePayload = { base_name: null, base: {}, custom: {} }

/** Base-theme colours + the custom theme's colours and `visualStyles` (base `visualStyles` are
 * deliberately not applied: Power BI pins the visual defaults of the authoring version). */
export function buildTheme(payload: PbiThemePayload | undefined | null): ResolvedTheme {
  const base = (payload?.base ?? {}) as Dict
  const custom = (payload?.custom ?? {}) as Dict
  const named: Record<string, string> = {}
  for (const source of [base, custom])
    for (const [k, v] of Object.entries(source)) if (typeof v === 'string' && v.startsWith('#')) named[k] = v
  const colors = (custom.dataColors ?? base.dataColors) as string[] | undefined
  const pick = (key: string, fallback: string) =>
    (typeof custom[key] === 'string' ? (custom[key] as string) : undefined) ??
    (typeof base[key] === 'string' ? (base[key] as string) : undefined) ??
    fallback
  const tokens = {
    dataColors: colors?.length ? colors : [...PBI_DEFAULTS.dataColors],
    foreground: pick('foreground', PBI_DEFAULTS.foreground),
    background: pick('background', PBI_DEFAULTS.background),
    secondaryForeground: pick('foregroundNeutralSecondary', PBI_DEFAULTS.secondaryForeground),
    fontFamily: PBI_DEFAULTS.fontFamily,
    named,
  }
  return {
    tokens,
    customStyles: isDict(custom.visualStyles) ? (custom.visualStyles as Dict) : {},
  }
}

const ThemeContext = createContext<ResolvedTheme>(buildTheme(undefined))
export const PbiThemeContext = ThemeContext
export const usePbiTheme = (): ResolvedTheme => useContext(ThemeContext)

// ---------------------------------------------------------------- property lookup

export const CHROME_TYPES = new Set([
  'textbox', 'shape', 'basicShape', 'image', 'actionButton', 'visualGroup', 'bookmarkNavigator',
  'pageNavigator',
]) // prettier-ignore

/** The first selector-less entry of `objects[name]`. */
export function firstEntry(objects: unknown, name: string): Dict | undefined {
  if (!isDict(objects)) return undefined
  const list = objects[name]
  if (!Array.isArray(list)) return undefined
  const entry = list.find((e) => isDict(e) && !('selector' in e)) as Dict | undefined
  return entry
}

function entryProps(entry: Dict | undefined): Dict {
  return entry && isDict(entry.properties) ? entry.properties : {}
}

/** Every entry of `objects[name]` that carries a selector. */
export function selectorEntries(objects: unknown, name: string): Dict[] {
  if (!isDict(objects)) return []
  const list = objects[name]
  return Array.isArray(list) ? (list.filter((e) => isDict(e) && 'selector' in e) as Dict[]) : []
}

interface Lookup {
  /** visual `objects` > custom theme (`[type]['*']` then `['*']['*']`) */
  obj: (name: string, prop: string) => Node
  /** visualContainerObjects > custom theme */
  cobj: (name: string, prop: string) => Node
  explicit: (name: string, prop: string) => boolean
}

function themeProp(styles: Dict, type: string, name: string, prop: string): Node {
  for (const key of [type, '*']) {
    const bucket = styles[key]
    if (!isDict(bucket)) continue
    const star = bucket['*']
    if (!isDict(star)) continue
    const list = star[name]
    if (Array.isArray(list) && isDict(list[0]) && prop in list[0]) return list[0][prop]
  }
  return undefined
}

function makeLookup(spec: VisualSpec, theme: ResolvedTheme): Lookup {
  const objects = spec.pbir?.objects
  const container = spec.pbir?.container_objects
  const type = spec.visual_type
  const get = (source: unknown, name: string, prop: string): Node => {
    const own = entryProps(firstEntry(source, name))
    if (prop in own) return own[prop]
    return themeProp(theme.customStyles, type, name, prop)
  }
  return {
    obj: (name, prop) => get(objects, name, prop),
    cobj: (name, prop) => get(container, name, prop),
    explicit: (name, prop) => prop in entryProps(firstEntry(objects, name)),
  }
}

// ---------------------------------------------------------------- resolved style

export interface ResolvedStyle {
  hasPbir: boolean
  isChrome: boolean
  container: {
    showBackground: boolean
    background: string
    alpha: number
    border: { show: boolean; color: string; width: number; radius: number }
    padding: { top: number; right: number; bottom: number; left: number }
  }
  title: {
    show: boolean
    showSetting: boolean
    text?: string
    font: FontSpec
    color: string
    align: 'left' | 'center' | 'right'
    background?: string
  }
  palette: string[]
  fill?: string
  fillByValue: { byMeasure: Record<string, string>; byCategory: Record<string, string> }
  categoryAxis: {
    show: boolean
    labelColor: string
    font: FontSpec
    minWidthPx: number
    preferredWidthSet: boolean
    concatenateLabels: boolean
    innerPaddingPct: number
  }
  valueAxis: {
    show: boolean
    labelColor: string
    font: FontSpec
    gridlineColor: string
    gridlineShow: boolean
    labelPrecision?: number
    labelDisplayUnits?: number
  }
  labels: {
    show: boolean
    color: string
    font: FontSpec
    precision?: number
    displayUnits?: number
    percentagePrecision?: number
    contentLayout?: string
    detailPercent: boolean
    detail: { color: string; font: FontSpec; precision?: number }
  }
  legend: { show: boolean; position: string; showTitle: boolean; color: string; font: FontSpec }
  slices: { innerRadiusRatio: number }
  card: {
    valueFont: FontSpec
    valueColor: string
    categoryShow: boolean
    categoryFont: FontSpec
    categoryColor: string
  }
  slicer: {
    headerShow: boolean
    headerText?: string
    headerFont: FontSpec
    itemsFont: FontSpec
    itemsColor: string
  }
  table: {
    headerFont: FontSpec
    headerColor: string
    headerBackground?: string
    valuesFont: FontSpec
    valuesColor: string
    backPrimary?: string
    backSecondary: string
    gridHorizontal: { show: boolean; color: string; weight: number }
    gridVertical: { show: boolean; color: string; weight: number }
    rowPaddingPx: number
    columnWidths: Record<string, number>
    defaultColumnWidth?: number
    alignments: Record<string, string>
    totalsShow: boolean
    totalLabel: string
    rowHeaderFont: FontSpec
    rowHeaderColor: string
    showExpandCollapse: boolean
    valuesOnRow: boolean
  }
  map: {
    defaultFill: string
    borderColor: string
    gradient?: { min: string; mid?: string; max: string; minValue?: number; midValue?: number; maxValue?: number }
    nullAsZero: boolean
    projection?: string
  }
}

function sizeOr(node: Node, defaultPt: number, familyNode?: Node, weight = 400): FontSpec {
  return font(familyNode, node, defaultPt, weight, PBI_DEFAULTS.fontFamily)
}

function fieldKeyNames(f: PbirField): string[] {
  return [f.name, f.display_name, f.query_ref].filter((x): x is string => !!x)
}

/** Data-point colours: measure-keyed (`selector.metadata`) and category-keyed
 * (`selector.data[0].scopeId.Comparison`, only when the selector's entity matches the field). */
function fillByValue(spec: VisualSpec, theme: ResolvedTheme) {
  const byMeasure: Record<string, string> = {}
  const byCategory: Record<string, string> = {}
  const fields = spec.pbir?.fields ?? []
  for (const entry of selectorEntries(spec.pbir?.objects, 'dataPoint')) {
    const fill = color(entryProps(entry).fill, theme.tokens)
    if (!fill) continue
    const selector = entry.selector as Dict
    if (typeof selector.metadata === 'string') {
      const owner = fields.find((f) => f.query_ref === selector.metadata)
      if (owner) for (const name of fieldKeyNames(owner)) byMeasure[name] = fill
      else byMeasure[selector.metadata as string] = fill
      continue
    }
    const data = Array.isArray(selector.data) ? selector.data[0] : undefined
    const cmp = isDict(data) && isDict(data.scopeId) ? (data.scopeId.Comparison as Dict | undefined) : undefined
    if (!cmp) continue
    const left = isDict(cmp.Left) ? (cmp.Left.Column as Dict | undefined) : undefined
    const entity = left && isDict(left.Expression) && isDict(left.Expression.SourceRef)
      ? (left.Expression.SourceRef.Entity as string | undefined)
      : undefined
    const property = left?.Property as string | undefined
    if (!entity || !property) continue
    if (!fields.some((f) => !f.is_measure && f.table === entity && f.name === property)) continue // stale
    const value = lit(cmp.Right)
    if (value !== undefined && value !== null) byCategory[String(value)] = fill
  }
  return { byMeasure, byCategory }
}

export function resolveVisual(spec: VisualSpec, theme: ResolvedTheme): ResolvedStyle {
  const hasPbir = !!spec.pbir
  const type = spec.visual_type
  const isChrome = CHROME_TYPES.has(type) || spec.data_status === 'unsupported_type'
  const t = theme.tokens
  const L = makeLookup(spec, theme)

  // ---- container
  const explicitBackground = color(L.cobj('background', 'color'), t)
  const bgShow = litBool(L.cobj('background', 'show'))
  const showBackground = bgShow ?? (!isChrome || !!explicitBackground)
  const transparency = litNumber(L.cobj('background', 'transparency')) ?? 0
  const pad = (side: string) => litNumber(L.cobj('padding', side)) ?? (isChrome ? 0 : PBI_DEFAULTS.container.padding)
  const border = {
    show: litBool(L.cobj('border', 'show')) ?? false,
    color: color(L.cobj('border', 'color'), t) ?? '#E6E6E6',
    width: litNumber(L.cobj('border', 'width')) ?? 1,
    radius: litNumber(L.cobj('border', 'radius')) ?? 0,
  }

  // ---- title
  const titleOffByDefault =
    isChrome || ['card', 'slicer', 'pivotTable', 'tableEx', 'kpiCard'].includes(type)
  const titleShowSetting = litBool(L.cobj('title', 'show'))
  const titleText = litString(L.cobj('title', 'text'))
  const titleFont = font(
    L.cobj('title', 'fontFamily'),
    L.cobj('title', 'fontSize'),
    PBI_DEFAULTS.title.sizePt,
    PBI_DEFAULTS.title.weight,
    PBI_DEFAULTS.fontFamily,
  )
  const align = litString(L.cobj('title', 'alignment')) ?? 'left'

  // ---- axes / labels / legend
  const axisFont = (name: string) => font(L.obj(name, 'fontFamily'), L.obj(name, 'fontSize'), PBI_DEFAULTS.axis.labelSizePt, 400, PBI_DEFAULTS.fontFamily)
  const labelsFont = font(L.obj('labels', 'fontFamily'), L.obj('labels', 'fontSize'), PBI_DEFAULTS.labels.sizePt, 400, PBI_DEFAULTS.fontFamily)
  const labelColorDefault = type === 'card' || type === 'kpiCard' ? t.foreground : PBI_DEFAULTS.labels.color
  const preferred = litNumber(L.obj('categoryAxis', 'preferredCategoryWidth')) ?? litNumber(L.obj('categoryAxis', 'minCategoryWidth'))
  const detailContent = litString(L.obj('labels', 'detailContentType'))

  // ---- table
  const tableFont = (name: string, defaultPt: number, weightNode?: Node) =>
    font(L.obj(name, 'fontFamily'), L.obj(name, 'fontSize'), defaultPt, litBool(weightNode) ? 700 : 400, PBI_DEFAULTS.fontFamily)
  const headerBold = litBool(L.obj('columnHeaders', 'bold'))
  const columnWidths: Record<string, number> = {}
  let defaultColumnWidth: number | undefined
  for (const e of [...(Array.isArray((spec.pbir?.objects as Dict | undefined)?.columnWidth) ? ((spec.pbir!.objects as Dict).columnWidth as Dict[]) : [])]) {
    const width = litNumber(entryProps(e).value)
    if (width === undefined) continue
    const metadata = isDict(e.selector) ? (e.selector.metadata as string | undefined) : undefined
    if (!metadata) defaultColumnWidth = width
    else columnWidths[metadata] = width
  }
  const alignments: Record<string, string> = {}
  for (const e of selectorEntries(spec.pbir?.objects, 'columnFormatting')) {
    const a = litString(entryProps(e).alignment)
    const metadata = (e.selector as Dict).metadata as string | undefined
    if (a && metadata) alignments[metadata] = a
  }
  const grid = (axis: 'Horizontal' | 'Vertical', defaultShow: boolean) => ({
    show: litBool(L.obj('grid', `grid${axis}`)) ?? defaultShow,
    color: color(L.obj('grid', `grid${axis}Color`), t) ?? PBI_DEFAULTS.table.gridColor,
    weight: litNumber(L.obj('grid', `grid${axis}Weight`)) ?? 1,
  })

  // ---- map
  const gradientNode = (): Dict | undefined => {
    const rule = entryProps(firstEntry(spec.pbir?.objects, 'dataPoint')).fillRule
    if (!isDict(rule)) return undefined
    const fill = (rule.linearGradient3 ?? rule.linearGradient2) as Dict | undefined
    return isDict(fill) ? fill : undefined
  }
  const grad = gradientNode()
  const stop = (key: string) => (grad && isDict(grad[key]) ? (grad[key] as Dict) : undefined)
  const stopColor = (key: string) => color((stop(key) ?? {}).color, t)
  const stopValue = (key: string) => litNumber((stop(key) ?? {}).value)

  return {
    hasPbir,
    isChrome,
    container: {
      showBackground,
      background: explicitBackground ?? t.background,
      alpha: Math.max(0, Math.min(1, 1 - transparency / 100)),
      border,
      padding: { top: pad('top'), right: pad('right'), bottom: pad('bottom'), left: pad('left') },
    },
    title: {
      show: titleShowSetting ?? (hasPbir ? !titleOffByDefault : true),
      showSetting: titleShowSetting ?? !titleOffByDefault,
      text: titleText,
      font: titleFont,
      color: color(L.cobj('title', 'fontColor'), t) ?? PBI_DEFAULTS.title.color,
      align: align === 'center' || align === 'right' ? align : 'left',
      background: color(L.cobj('title', 'background'), t),
    },
    palette: t.dataColors,
    fill: color(L.obj('dataPoint', 'fill'), t),
    fillByValue: fillByValue(spec, theme),
    categoryAxis: {
      show: litBool(L.obj('categoryAxis', 'show')) ?? true,
      labelColor: color(L.obj('categoryAxis', 'labelColor'), t) ?? PBI_DEFAULTS.axis.labelColor,
      font: axisFont('categoryAxis'),
      minWidthPx: preferred ?? PBI_DEFAULTS.category.minWidthPx,
      preferredWidthSet: preferred !== undefined,
      concatenateLabels: litBool(L.obj('categoryAxis', 'concatenateLabels')) ?? true,
      innerPaddingPct: litNumber(L.obj('categoryAxis', 'innerPadding')) ?? PBI_DEFAULTS.category.innerPaddingPct,
    },
    valueAxis: {
      show: litBool(L.obj('valueAxis', 'show')) ?? true,
      labelColor: color(L.obj('valueAxis', 'labelColor'), t) ?? PBI_DEFAULTS.axis.labelColor,
      font: axisFont('valueAxis'),
      gridlineColor: color(L.obj('valueAxis', 'gridlineColor'), t) ?? PBI_DEFAULTS.axis.gridlineColor,
      gridlineShow: litBool(L.obj('valueAxis', 'gridlineShow')) ?? true,
      labelPrecision: litNumber(L.obj('valueAxis', 'labelPrecision')),
      labelDisplayUnits: litNumber(L.obj('valueAxis', 'labelDisplayUnits')),
    },
    labels: {
      show: litBool(L.obj('labels', 'show')) ?? false,
      color: color(L.obj('labels', 'color'), t) ?? labelColorDefault,
      font: labelsFont,
      precision: litNumber(L.obj('labels', 'labelPrecision')),
      displayUnits: litNumber(L.obj('labels', 'labelDisplayUnits')),
      percentagePrecision: litNumber(L.obj('labels', 'percentageLabelPrecision')),
      contentLayout: litString(L.obj('labels', 'labelContentLayout')),
      detailPercent:
        litBool(L.obj('labels', 'enableValueDataLabel')) === false &&
        litBool(L.obj('labels', 'enableDetailDataLabel')) === true &&
        detailContent === 'Percent of total',
      detail: {
        color: color(L.obj('labels', 'detailLabelColor'), t) ?? PBI_DEFAULTS.labels.color,
        font: font(L.obj('labels', 'detailLabelFontFamily'), L.obj('labels', 'detailLabelFontSize'), PBI_DEFAULTS.labels.sizePt, 400, PBI_DEFAULTS.fontFamily),
        precision: litNumber(L.obj('labels', 'detailLabelPrecision')),
      },
    },
    legend: {
      show: litBool(L.obj('legend', 'show')) ?? true,
      position: litString(L.obj('legend', 'position')) ?? 'Top',
      showTitle: litBool(L.obj('legend', 'showTitle')) ?? true,
      color: color(L.obj('legend', 'labelColor'), t) ?? PBI_DEFAULTS.legend.color,
      font: font(L.obj('legend', 'fontFamily'), L.obj('legend', 'fontSize'), PBI_DEFAULTS.legend.sizePt, 400, PBI_DEFAULTS.fontFamily),
    },
    slices: { innerRadiusRatio: (litNumber(L.obj('slices', 'innerRadiusRatio')) ?? 0) / 100 },
    card: {
      valueFont: font(L.obj('labels', 'fontFamily'), L.obj('labels', 'fontSize'), PBI_DEFAULTS.card.valueSizePt, 600, PBI_DEFAULTS.fontFamily),
      valueColor: color(L.obj('labels', 'color'), t) ?? t.foreground,
      categoryShow: litBool(L.obj('categoryLabels', 'show')) ?? true,
      categoryFont: font(L.obj('categoryLabels', 'fontFamily'), L.obj('categoryLabels', 'fontSize'), PBI_DEFAULTS.card.categorySizePt, 400, PBI_DEFAULTS.fontFamily),
      categoryColor: color(L.obj('categoryLabels', 'color'), t) ?? PBI_DEFAULTS.card.categoryColor,
    },
    slicer: {
      headerShow: litBool(L.obj('header', 'show')) ?? true,
      headerText: litString(L.obj('header', 'text')),
      headerFont: sizeOr(L.obj('header', 'textSize'), PBI_DEFAULTS.slicer.sizePt, L.obj('header', 'fontFamily')),
      itemsFont: sizeOr(L.obj('items', 'textSize'), PBI_DEFAULTS.slicer.sizePt, L.obj('items', 'fontFamily')),
      itemsColor: color(L.obj('items', 'fontColor'), t) ?? t.foreground,
    },
    table: {
      headerFont: font(L.obj('columnHeaders', 'fontFamily'), L.obj('columnHeaders', 'fontSize'), PBI_DEFAULTS.table.headerSizePt, headerBold ? 700 : 600, PBI_DEFAULTS.fontFamily),
      headerColor: color(L.obj('columnHeaders', 'fontColor'), t) ?? t.foreground,
      headerBackground: color(L.obj('columnHeaders', 'backColor'), t) ?? PBI_DEFAULTS.table.headerBackground,
      valuesFont: tableFont('values', PBI_DEFAULTS.table.valuesSizePt),
      valuesColor: color(L.obj('values', 'fontColorPrimary'), t) ?? PBI_DEFAULTS.table.valuesColor,
      backPrimary: color(L.obj('values', 'backColorPrimary'), t),
      backSecondary: color(L.obj('values', 'backColorSecondary'), t) ?? PBI_DEFAULTS.table.banding,
      gridHorizontal: grid('Horizontal', true),
      gridVertical: grid('Vertical', false),
      rowPaddingPx: litNumber(L.obj('grid', 'rowPadding')) ?? PBI_DEFAULTS.table.rowPaddingPx,
      columnWidths,
      defaultColumnWidth,
      alignments,
      totalsShow: litBool(L.obj('total', 'totals')) ?? litBool(L.obj('total', 'show')) ?? true,
      totalLabel: litString(L.obj('total', 'label')) ?? 'Total',
      rowHeaderFont: tableFont('rowHeaders', PBI_DEFAULTS.table.valuesSizePt),
      rowHeaderColor: color(L.obj('rowHeaders', 'fontColor'), t) ?? PBI_DEFAULTS.table.valuesColor,
      showExpandCollapse: litBool(L.obj('rowHeaders', 'showExpandCollapseButtons')) ?? true,
      valuesOnRow: litBool(L.obj('values', 'valuesOnRow')) ?? false,
    },
    map: {
      defaultFill: color(L.obj('defaultColors', 'defaultColor'), t) ?? PBI_DEFAULTS.map.defaultFill,
      borderColor: color(L.obj('defaultColors', 'borderColor'), t) ?? PBI_DEFAULTS.map.borderColor,
      gradient: grad
        ? {
            min: stopColor('min') ?? t.dataColors[0],
            mid: stopColor('mid'),
            max: stopColor('max') ?? t.dataColors[0],
            minValue: stopValue('min'),
            midValue: stopValue('mid'),
            maxValue: stopValue('max'),
          }
        : undefined,
      nullAsZero: litString(L.obj('dataPoint', 'nullColoringStrategy')) === 'asZero' ||
        litString(entryProps(firstEntry(spec.pbir?.objects, 'dataPoint')).nullColoringStrategy as Node) === 'asZero',
      projection: litString(L.obj('shape', 'projectionEnum')),
    },
  }
}

// ---------------------------------------------------------------- page background, field keys

export function pageBackground(page: Pick<PageSpec, 'background'>, theme: ResolvedTheme): string {
  const props = entryProps(isDict(page.background) ? (page.background as Dict) : undefined)
  const base = color(props.color, theme.tokens) ?? theme.tokens.background
  const transparency = litNumber(props.transparency) ?? 0
  return transparency ? withAlpha(base, 1 - transparency / 100) : base
}

/** The result column a PBIR field reads: explicit measures by name, aggregated columns by their
 * display-name alias, bare columns by "table.column", falling back across the candidates present
 * in the result. `used` makes two fields never share a column. */
export function fieldColumnKey(
  field: PbirField,
  available: string[],
  used: Set<string> = new Set(),
): string | undefined {
  const candidates: (string | null | undefined)[] = field.is_measure
    ? [field.name, field.display_name, field.query_ref]
    : field.aggregate
      ? [field.display_name, `${field.table}.${field.name}`, field.name]
      : [`${field.table}.${field.name}`, field.display_name, field.name]
  const key = candidates.find((c): c is string => !!c && available.includes(c) && !used.has(c))
  if (key !== undefined) used.add(key)
  return key
}

export { decodeLiteral }
