import { useQuery } from '@tanstack/react-query'
import { Loader2 } from 'lucide-react'
import { useState } from 'react'
import { parityApi } from '../../api/client'
import type { ParityComparison, ParityHistoryRun, ParityValues } from '../../api/types'
import { fmtTime } from '../../components/fmtTime'
import { Sparkline } from '../../components/Sparkline'
import { ComparisonDetail } from './ComparisonDetail'

function summaryText(run: ParityHistoryRun): string {
  return Object.entries(run.summary ?? {})
    .filter(([, v]) => v !== null && v !== undefined)
    .map(([k, v]) => `${k.replace(/_/g, ' ')} ${v}`)
    .join(' · ')
}

/** Per-page run history with a trend; an older run opens read-only. */
export function PageHistory({
  conversionId,
  page,
  batchId,
}: {
  conversionId: string
  page: string
  batchId?: string
}) {
  const [openRun, setOpenRun] = useState<string | null>(null)
  const history = useQuery({
    queryKey: ['parity-history', conversionId, page, batchId ?? null],
    queryFn: () => parityApi.history(conversionId, page, batchId),
  })
  const run = useQuery({
    queryKey: ['parity-history-run', conversionId, page, openRun],
    queryFn: () => parityApi.historyRun(conversionId, page, openRun!),
    enabled: !!openRun,
  })

  if (history.isLoading) return <p className="text-xs text-surface-500">Loading history…</p>
  if (history.isError)
    return <p className="text-xs text-brand-red">{(history.error as Error).message}</p>
  const runs = history.data?.runs ?? []
  const trend = history.data?.trend ?? []
  if (!runs.length) return <p className="text-xs text-surface-500">No earlier runs for this page.</p>

  const imageTrend = trend.filter((t) => t.kind === 'image').map((t) => t.value)
  const valuesTrend = trend.filter((t) => t.kind === 'values').map((t) => t.value)

  return (
    <div data-testid="page-history">
      <div className="mb-2 flex flex-wrap items-center gap-5 text-xs">
        <span className="flex items-center gap-2 text-surface-600">
          Similarity <Sparkline values={imageTrend} label="similarity trend" />
        </span>
        <span className="flex items-center gap-2 text-surface-600">
          Numbers matched <Sparkline values={valuesTrend} label="numbers trend" />
        </span>
      </div>
      <ul className="divide-y divide-surface-200 rounded-lg border border-surface-300 text-xs">
        {[...runs].map((r) => (
          <li key={r.run_id} className="flex flex-wrap items-center gap-3 px-3 py-2">
            <span className="w-28 tabular-nums text-surface-600">{fmtTime(r.ts)}</span>
            <span className={r.kind === 'image' ? 'badge-blue' : 'badge-green'}>
              {r.kind === 'image' ? 'image' : 'numbers'}
            </span>
            <span className="min-w-0 flex-1 truncate text-surface-600">{summaryText(r)}</span>
            <button
              className="rounded-lg border border-surface-300 px-2 py-1 text-[11px] font-semibold hover:bg-surface-100"
              aria-label={`Open run ${r.run_id}`}
              onClick={() => setOpenRun(openRun === r.run_id ? null : r.run_id)}
            >
              {openRun === r.run_id ? 'Close' : 'Open'}
            </button>
          </li>
        ))}
      </ul>

      {openRun && (
        <div className="mt-3 rounded-lg border border-surface-300 p-3">
          {run.isLoading && <Loader2 size={14} className="animate-spin" />}
          {run.isError && <p className="text-xs text-brand-red">{(run.error as Error).message}</p>}
          {run.data &&
            (run.data.kind === 'image' ? (
              <ComparisonDetail
                readOnly
                conversionId={conversionId}
                comparison={run.data.payload as ParityComparison}
                imageUrl={(side) => parityApi.historyImageUrl(conversionId, page, openRun, side)}
              />
            ) : (
              <ComparisonDetail
                readOnly
                conversionId={conversionId}
                values={run.data.payload as ParityValues}
              />
            ))}
        </div>
      )}
    </div>
  )
}
