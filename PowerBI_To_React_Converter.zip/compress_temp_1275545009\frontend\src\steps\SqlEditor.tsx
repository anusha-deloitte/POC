import { useEffect, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { auditApi } from '../api/client'
import type { SqlTestResult } from '../api/types'
import { useWizard } from '../store/wizard'

function TestResult({ result }: { result: SqlTestResult }) {
  return (
    <div data-testid="sql-test-result" className="mt-3 rounded-lg border border-black/[0.08] p-3 text-xs">
      {result.error ? (
        <p role="alert" className="text-brand-red">
          {result.error}
        </p>
      ) : (
        <p className="font-semibold text-brand-dark">
          {result.row_count} row{result.row_count === 1 ? '' : 's'} · {result.columns.length} columns ·{' '}
          {result.elapsed_ms} ms
        </p>
      )}
      {result.columns.length > 0 && (
        <p className="mt-1 text-surface-600">Columns: {result.columns.join(', ')}</p>
      )}
      {result.missing_columns.length > 0 && (
        <p className="mt-1 text-brand-red">Missing columns: {result.missing_columns.join(', ')}</p>
      )}
      {result.unapplied_filter_tables.length > 0 && (
        <p className="mt-1 text-brand-amber">
          Filters not applied (table not in the SQL or no placeholder):{' '}
          {result.unapplied_filter_tables.join(', ')}
        </p>
      )}
      {result.null_comparison_warnings.length > 0 && (
        <ul data-testid="null-comparison-warnings" className="mt-1 ml-4 list-disc text-brand-amber">
          {result.null_comparison_warnings.map((w) => (
            <li key={w}>{w}</li>
          ))}
        </ul>
      )}
      {result.rows.length > 0 && (
        <div className="mt-2 max-h-40 overflow-auto">
          <table className="w-full">
            <thead>
              <tr>
                {result.columns.map((c) => (
                  <th key={c} className="px-1 text-left font-semibold">
                    {c}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {result.rows.slice(0, 10).map((row, i) => (
                <tr key={i}>
                  {row.map((cell, j) => (
                    <td key={j} className="px-1">
                      {cell == null ? 'NULL' : String(cell)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

export function SqlEditor({
  page,
  visual,
  onClose,
}: {
  page: string
  visual: string
  onClose?: () => void
}) {
  const conversionId = useWizard((s) => s.conversionId)!
  const connectionId = useWizard((s) => s.connectionId)
  const queryClient = useQueryClient()
  const info = useQuery({
    queryKey: ['sql-editor', conversionId, page, visual],
    queryFn: () => auditApi.sqlEditor(conversionId, page, visual),
  })
  const [text, setText] = useState('')
  const [loaded, setLoaded] = useState(false)
  const [tested, setTested] = useState<{ text: string; result: SqlTestResult } | null>(null)

  useEffect(() => {
    if (info.data && !loaded) {
      setText(info.data.override?.sql ?? info.data.base_sql ?? '')
      setLoaded(true)
    }
  }, [info.data, loaded])

  const refresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ['sql-editor', conversionId] })
    await queryClient.invalidateQueries({ queryKey: ['dash-spec', conversionId] })
    await queryClient.invalidateQueries({ queryKey: ['no-sql-panes', conversionId] })
  }
  const run = useMutation({
    mutationFn: () =>
      auditApi.testSql(conversionId, { page, visual, connection_id: connectionId!, sql: text }),
    onSuccess: (result) => setTested({ text, result }),
  })
  const save = useMutation({
    mutationFn: () => auditApi.saveSql(conversionId, { page, visual, sql: text }),
    onSuccess: refresh,
  })
  const revert = useMutation({
    mutationFn: () => auditApi.deleteSql(conversionId, page, visual),
    onSuccess: async () => {
      setLoaded(false)
      setTested(null)
      await refresh()
    },
  })

  if (info.isLoading) return <p className="text-xs text-surface-500">Loading SQL editor…</p>
  if (info.isError) {
    return (
      <p role="alert" className="text-xs text-brand-red">
        {info.error.message}
      </p>
    )
  }
  const data = info.data!
  const result = tested && tested.text === text ? tested.result : null
  const canSave = !!result && !result.error && result.missing_columns.length === 0
  const error = run.error ?? save.error ?? revert.error

  return (
    <div data-testid="sql-editor" className="rounded-xl border border-black/[0.08] bg-white p-4">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="kicker">Edit SQL</div>
          <h4 className="text-sm font-bold">{data.pane}</h4>
          <p className="mt-1 text-xs text-surface-600">
            Your SQL replaces this pane’s query. Use <code>{'{{filters}}'}</code> (or{' '}
            <code>{'{{filters:Table}}'}</code>) where slicer and cross filters should apply.
          </p>
        </div>
        {onClose && (
          <button type="button" className="btn-secondary !px-2 !py-0.5 !text-xs" onClick={onClose}>
            Close
          </button>
        )}
      </div>

      <div className="mt-3 text-xs">
        <div className="font-semibold">Generated SQL</div>
        {data.base_sql ? (
          <pre className="mt-1 max-h-40 overflow-auto rounded-lg bg-surface-50 p-2 text-[11px] whitespace-pre-wrap">
            {data.base_sql}
          </pre>
        ) : (
          <p className="mt-1 text-surface-600">
            No SQL was generated{data.base_error ? `: ${data.base_error}` : '.'}
          </p>
        )}
      </div>

      <div className="mt-3 grid gap-3 text-xs md:grid-cols-2">
        <div>
          <div className="font-semibold">Expected columns</div>
          <p className="mt-1 text-surface-700">{data.expected_columns.join(', ') || '—'}</p>
        </div>
        <div>
          <div className="font-semibold">Tables for {'{{filters:Table}}'}</div>
          <p className="mt-1 text-surface-700">
            {data.filter_tables.map((t) => t.table).join(', ') || '—'}
          </p>
        </div>
      </div>

      <label className="mt-3 block text-xs font-semibold" htmlFor={`sql-${page}-${visual}`}>
        SQL
      </label>
      <textarea
        id={`sql-${page}-${visual}`}
        aria-label="Edited SQL"
        className="input mt-1 h-40 font-mono text-xs"
        value={text}
        spellCheck={false}
        onChange={(e) => setText(e.target.value)}
      />

      <div className="mt-2 flex flex-wrap items-center gap-2">
        <button
          type="button"
          className="btn-secondary !text-xs"
          disabled={!connectionId || !text.trim() || run.isPending}
          onClick={() => run.mutate()}
        >
          {run.isPending ? 'Running…' : 'Run'}
        </button>
        <button
          type="button"
          className="btn-primary !text-xs"
          disabled={!canSave || save.isPending}
          onClick={() => save.mutate()}
        >
          Save
        </button>
        {data.override && (
          <button
            type="button"
            className="btn-secondary !text-xs"
            disabled={revert.isPending}
            onClick={() => revert.mutate()}
          >
            Revert to generated SQL
          </button>
        )}
        {!connectionId && (
          <span className="text-[11px] text-surface-500">Select a Snowflake connection first</span>
        )}
        {connectionId && !canSave && (
          <span className="text-[11px] text-surface-500">Run the current SQL successfully first</span>
        )}
        {save.isSuccess && <span className="text-[11px] text-brand-dark">Saved.</span>}
      </div>
      {error && (
        <p role="alert" className="mt-2 text-xs text-brand-red">
          {error.message}
        </p>
      )}
      {result && <TestResult result={result} />}
    </div>
  )
}
