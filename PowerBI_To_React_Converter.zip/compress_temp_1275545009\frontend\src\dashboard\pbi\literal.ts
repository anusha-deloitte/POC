/** Decoding of PBIR literals and theme colours. */

export type Node = unknown

/** `'text'` (with `''` escapes), `12D`, `2L`, `1.5M`, `true`/`false`, `null`. */
export function decodeLiteral(raw: unknown): string | number | boolean | null | undefined {
  if (raw === null || raw === undefined) return raw === null ? null : undefined
  if (typeof raw !== 'string') return raw as number | boolean
  const text = raw.trim()
  if (text.length >= 2 && text.startsWith("'") && text.endsWith("'")) {
    return text.slice(1, -1).replace(/''/g, "'")
  }
  if (text === 'true') return true
  if (text === 'false') return false
  if (text === 'null') return null
  if (/^-?\d+(\.\d+)?[DLMdlm]?$/.test(text)) return Number(text.replace(/[DLMdlm]$/, ''))
  return text
}

type Dict = Record<string, unknown>

const isDict = (v: unknown): v is Dict => typeof v === 'object' && v !== null && !Array.isArray(v)

/** Accepts `{expr:{Literal:{Value}}}`, `{Literal:{Value}}` or a plain theme value. */
export function lit(node: Node): string | number | boolean | null | undefined {
  if (node === undefined) return undefined
  if (isDict(node)) {
    const expr = isDict(node.expr) ? node.expr : node
    if (isDict(expr.Literal)) return decodeLiteral(expr.Literal.Value)
    return undefined
  }
  if (typeof node === 'string' && /^'.*'$/.test(node.trim())) return decodeLiteral(node)
  return node as string | number | boolean | null
}

export function litNumber(node: Node): number | undefined {
  const v = lit(node)
  if (typeof v === 'number') return v
  if (typeof v === 'string' && v.trim() !== '' && !Number.isNaN(Number(v))) return Number(v)
  return undefined
}

export function litBool(node: Node): boolean | undefined {
  const v = lit(node)
  if (typeof v === 'boolean') return v
  if (v === 'true') return true
  if (v === 'false') return false
  return undefined
}

export function litString(node: Node): string | undefined {
  const v = lit(node)
  return v === undefined || v === null ? undefined : String(v)
}

function parseHex(hex: string): [number, number, number] | null {
  const m = /^#?([0-9a-f]{6}|[0-9a-f]{3})$/i.exec(hex.trim())
  if (!m) return null
  let h = m[1]
  if (h.length === 3) h = h.split('').map((c) => c + c).join('')
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)]
}

const toHex = (n: number) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0')

/** pct > 0 blends toward white, pct < 0 toward black (Power BI's theme shading). */
export function shade(hex: string, pct: number): string {
  const rgb = parseHex(hex)
  if (!rgb) return hex
  const target = pct >= 0 ? 255 : 0
  const amount = Math.min(1, Math.abs(pct))
  const out = rgb.map((c) => c + (target - c) * amount)
  return `#${toHex(out[0])}${toHex(out[1])}${toHex(out[2])}`.toUpperCase()
}

export function withAlpha(hex: string, alpha: number): string {
  const rgb = parseHex(hex)
  if (!rgb) return hex
  if (alpha >= 1) return hex
  return `#${toHex(rgb[0])}${toHex(rgb[1])}${toHex(rgb[2])}${toHex(alpha * 255)}`.toUpperCase()
}

export interface ColorTokens {
  dataColors: string[]
  foreground: string
  background: string
  /** named theme colours: foregroundNeutralSecondary, tableAccent, ... */
  named?: Record<string, string>
}

/** ColorId 0 = background, 1 = foreground, n >= 2 = dataColors[n-2], shaded by `pct`. */
export function themeDataColor(id: number, pct: number | undefined, tokens: ColorTokens): string | undefined {
  let base: string | undefined
  if (id === 0) base = tokens.background
  else if (id === 1) base = tokens.foreground
  else base = tokens.dataColors[(id - 2) % Math.max(tokens.dataColors.length, 1)]
  if (!base) return undefined
  return pct ? shade(base, pct) : base
}

/** Resolves `{solid:{color}}`, ThemeDataColor and named theme colours to a CSS colour. */
export function color(node: Node, tokens: ColorTokens): string | undefined {
  if (node === undefined || node === null) return undefined
  if (typeof node === 'string') return node.startsWith('#') ? node : tokens.named?.[node]
  if (!isDict(node)) return undefined
  if (isDict(node.solid)) return color(node.solid.color, tokens)
  const expr = isDict(node.expr) ? node.expr : node
  if (isDict(expr.ThemeDataColor)) {
    const t = expr.ThemeDataColor
    const id = typeof t.ColorId === 'number' ? t.ColorId : Number(t.ColorId)
    const pct = typeof t.Percent === 'number' ? t.Percent : t.Percent === undefined ? 0 : Number(t.Percent)
    return themeDataColor(id, pct, tokens)
  }
  if (isDict(expr.Literal)) {
    const v = decodeLiteral(expr.Literal.Value)
    if (typeof v === 'string') return v.startsWith('#') ? v : tokens.named?.[v]
  }
  return undefined
}
