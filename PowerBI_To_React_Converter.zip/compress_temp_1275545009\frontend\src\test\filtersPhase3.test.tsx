import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { useState } from 'react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { DashboardApp } from '../dashboard/DashboardApp'
import { FiltersPane } from '../dashboard/FiltersPane'
import { paneClauses, resetPane, type PaneState } from '../dashboard/filtersPaneState'
import type { DashboardSpec, FilterCard, FilterDefault, PageSpec } from '../dashboard/types'
import { cardResults, FakeResizeObserver, filterCard, json, standaloneSpec } from './standaloneFixtures'

const cond = (op: string, ...values: (string | number | null)[]) => ({ op, values, params: {} })
const def = (join: 'and' | 'or', ...conditions: ReturnType<typeof cond>[]): FilterDefault => ({ join, conditions })

function card(name: string, over: Partial<FilterCard> = {}): FilterCard {
  return {
    name, scope: 'page', table: 'Customer', column: 'Country', display_name: name, data_type: 'string',
    kind: 'basic', default: null, require_single: false, hidden: false, locked: false, supported: true,
    ...over,
  }
}

function makeSpec(over: Partial<DashboardSpec> = {}, pageOver: Partial<PageSpec> = {}): DashboardSpec {
  const page: PageSpec = {
    name: 'p1', display_name: 'Page 1', width: 1280, height: 720, ordinal: 0, visuals: [],
    filters: [card('Country'), card('Year', { column: 'Year', data_type: 'int64' })], ...pageOver,
  }
  return {
    report_name: 'r', pages: [page], warnings: [], measure_tiers: { 'Total Sales': 0, Parked: -1 },
    theme: { data_colors: [], text_classes: {} }, interaction_graph: { nodes: [], edges: [], sync_groups: {} },
    bookmarks: [], drill_through: [], report_filters: [card('Region', { scope: 'report', column: 'Region' })],
    ...over,
  } as DashboardSpec
}

let valueRequests: { search?: string; table: string; column: string }[] = []

function Harness({ spec, initial = {}, onState }: { spec: DashboardSpec; initial?: PaneState; onState?: (s: PaneState) => void }) {
  const [state, setState] = useState<PaneState>(initial)
  onState?.(state)
  return (
    <FiltersPane
      spec={spec}
      page={spec.pages[0]}
      state={state}
      onChange={setState}
      onReset={() => setState(resetPane(state, spec.pages[0].name))}
      conversionId="c1"
      connectionId="conn"
    />
  )
}

const renderPane = (spec: DashboardSpec, initial?: PaneState, onState?: (s: PaneState) => void) => {
  const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
  return render(
    <QueryClientProvider client={qc}>
      <Harness spec={spec} initial={initial} onState={onState} />
    </QueryClientProvider>,
  )
}

const open = async () => userEvent.click(screen.getByTestId('filters-tab'))
const summaryOf = (card: string) => within(screen.getByTestId(`filter-card-${card}`)).getByTestId('card-summary').textContent

describe('FiltersPane', () => {
  beforeEach(() => {
    valueRequests = []
    vi.stubGlobal(
      'fetch',
      vi.fn(async (_url: string, init?: RequestInit) => {
        const body = JSON.parse(String(init?.body ?? '{}'))
        valueRequests.push(body)
        const all = [null, 'DE', 'FR', 'US']
        const values = body.search ? all.filter((v) => v && v.toLowerCase().includes(body.search.toLowerCase())) : all
        return new Response(JSON.stringify({ values, truncated: false }))
      }),
    )
  })
  afterEach(() => vi.restoreAllMocks())

  it('starts collapsed as a Filters tab and opens at the page width', async () => {
    renderPane(makeSpec({}, { filter_pane: { width: 333, colours: {} } }))
    expect(screen.queryByTestId('filters-pane')).toBeNull()
    await open()
    expect(screen.getByTestId('filters-pane').style.width).toBe('333px')
    await userEvent.click(screen.getByLabelText('Collapse the Filters pane'))
    expect(screen.getByTestId('filters-tab')).toBeTruthy()
  })

  it('opens per the expanded setting and falls back to the report width', () => {
    renderPane(makeSpec({ filter_pane: { expanded: true, width: 410, colours: {} } }))
    expect(screen.getByTestId('filters-pane').style.width).toBe('410px')
  })

  it('is not shown when the pane is hidden', () => {
    renderPane(makeSpec({ filter_pane: { visible: false, colours: {} } }))
    expect(screen.queryByTestId('filters-tab')).toBeNull()
    expect(screen.queryByTestId('filters-pane')).toBeNull()
  })

  it('has collapsible "Filters on this page" and "Filters on all pages" sections', async () => {
    renderPane(makeSpec())
    await open()
    expect(screen.getByRole('button', { name: 'Filters on this page' })).toBeTruthy()
    expect(screen.getByRole('button', { name: 'Filters on all pages' })).toBeTruthy()
    expect(screen.getByRole('button', { name: 'Country' })).toBeTruthy()
    await userEvent.click(screen.getByRole('button', { name: 'Filters on this page' }))
    expect(screen.queryByRole('button', { name: 'Country' })).toBeNull()
    expect(screen.getByRole('button', { name: 'Region' })).toBeTruthy()
  })

  it('hidden cards are not rendered, locked ones are read-only, unsupported ones show why', async () => {
    renderPane(
      makeSpec({}, {
        filters: [
          card('Secret', { hidden: true }),
          card('Fixed', { locked: true, default: def('and', cond('in', 'US')) }),
          card('Broken', { supported: false, reason: 'filter condition shape not supported' }),
        ],
      }),
    )
    await open()
    expect(screen.queryByTestId('filter-card-Secret')).toBeNull()
    const fixed = screen.getByTestId('filter-card-Fixed')
    expect(within(fixed).getByLabelText('Locked')).toBeTruthy()
    expect(within(fixed).queryByLabelText('Clear Fixed')).toBeNull()
    await userEvent.click(within(fixed).getByRole('button', { name: 'Fixed' }))
    expect(within(fixed).queryByTestId('basic-editor')).toBeNull()
    expect(within(screen.getByTestId('filter-card-Broken')).getByTestId('card-summary').textContent).toBe(
      'filter condition shape not supported',
    )
  })

  it('searches card titles', async () => {
    renderPane(makeSpec())
    await open()
    await userEvent.type(screen.getByLabelText('Search filters'), 'yea')
    expect(screen.queryByTestId('filter-card-Country')).toBeNull()
    expect(screen.getByTestId('filter-card-Year')).toBeTruthy()
  })

  it('Basic: loads values lazily when expanded, lists (Blank), searches, selects all', async () => {
    let state: PaneState = {}
    renderPane(makeSpec(), {}, (s) => (state = s))
    await open()
    expect(valueRequests).toEqual([]) // nothing loads until a card is expanded
    await userEvent.click(screen.getByRole('button', { name: 'Country' }))
    const list = await screen.findByTestId('filter-value-list')
    await waitFor(() => expect(within(list).getAllByRole('checkbox')).toHaveLength(4))
    expect(valueRequests[0]).toMatchObject({ table: 'Customer', column: 'Country', limit: 500, page: 'p1' })
    expect(within(list).getByText('(Blank)')).toBeTruthy()
    // uncheck DE: "Select all" then unchecked
    await userEvent.click(within(list).getByLabelText('DE'))
    expect(state['page:p1:Country'].value).toEqual(def('and', cond('not_in', 'DE')))
    expect(summaryOf('Country')).toContain('is not DE')
    await userEvent.click(screen.getByLabelText('Select all'))
    expect(state['page:p1:Country'].value).toBeNull()
    // search reloads with the term
    await userEvent.type(screen.getByLabelText('Search Country values'), 'fr')
    await waitFor(() => expect(valueRequests.some((r) => r.search === 'fr')).toBe(true))
  })

  it('Basic: Require single selection picks one value', async () => {
    let state: PaneState = {}
    renderPane(makeSpec({}, { filters: [card('Country', { require_single: true })] }), {}, (s) => (state = s))
    await open()
    await userEvent.click(screen.getByRole('button', { name: 'Country' }))
    const list = await screen.findByTestId('filter-value-list')
    await waitFor(() => expect(within(list).getAllByRole('radio').length).toBeGreaterThan(0))
    expect(screen.queryByLabelText('Select all')).toBeNull()
    await userEvent.click(within(list).getByLabelText('US'))
    await userEvent.click(within(list).getByLabelText('DE'))
    expect(state['page:p1:Country'].value).toEqual(def('and', cond('in', 'DE')))
  })

  it('shows a dot when anything differs from the default and resets the pane', async () => {
    renderPane(makeSpec({}, { filters: [card('Country', { default: def('and', cond('in', 'US')) })] }))
    await open()
    expect(screen.queryByTestId('pane-dot')).toBeNull()
    expect((screen.getByRole('button', { name: 'Reset to default' }) as HTMLButtonElement).disabled).toBe(true)
    await userEvent.click(screen.getByLabelText('Clear Country'))
    expect(screen.getByTestId('pane-dot')).toBeTruthy()
    expect(summaryOf('Country')).toBe('is (All)')
    await userEvent.click(screen.getByRole('button', { name: 'Reset to default' }))
    expect(screen.queryByTestId('pane-dot')).toBeNull()
    expect(summaryOf('Country')).toBe('is US')
  })

  it('Advanced: two conditions with Or are applied on "Apply filter"', async () => {
    let state: PaneState = {}
    renderPane(makeSpec({}, { filters: [card('Country', { kind: 'advanced' })] }), {}, (s) => (state = s))
    await open()
    await userEvent.click(screen.getByRole('button', { name: 'Country' }))
    const editor = screen.getByTestId('advanced-editor')
    await userEvent.selectOptions(within(editor).getByLabelText('First condition operator'), 'contains')
    await userEvent.type(within(editor).getByLabelText('First condition value'), 'U')
    await userEvent.click(within(editor).getByLabelText('Or'))
    await userEvent.selectOptions(within(editor).getByLabelText('Second condition operator'), 'eq')
    await userEvent.type(within(editor).getByLabelText('Second condition value'), 'DE')
    expect(state['page:p1:Country']).toBeUndefined() // nothing until applied
    await userEvent.click(within(editor).getByRole('button', { name: 'Apply filter' }))
    expect(state['page:p1:Country'].value).toEqual(def('or', cond('contains', 'U'), cond('eq', 'DE')))
    expect(paneClauses(makeSpec({}, { filters: [card('Country', { kind: 'advanced' })] }), makeSpec().pages[0], state)).toBeDefined()
  })

  it('Advanced on a number uses number operators and numeric values', async () => {
    let state: PaneState = {}
    renderPane(makeSpec({}, { filters: [card('Year', { kind: 'advanced', column: 'Year', data_type: 'int64' })] }), {}, (s) => (state = s))
    await open()
    await userEvent.click(screen.getByRole('button', { name: 'Year' }))
    const editor = screen.getByTestId('advanced-editor')
    expect(within(editor).getAllByRole('option', { name: 'is greater than' }).length).toBeGreaterThan(0)
    await userEvent.selectOptions(within(editor).getByLabelText('First condition operator'), 'gt')
    await userEvent.type(within(editor).getByLabelText('First condition value'), '2020')
    await userEvent.click(within(editor).getByRole('button', { name: 'Apply filter' }))
    expect(state['page:p1:Year'].value).toEqual(def('and', cond('gt', 2020)))
  })

  it('Basic <-> Advanced switching only when the report allows it', async () => {
    const allowed = makeSpec({ allow_change_filter_types: true })
    const { unmount } = renderPane(allowed)
    await open()
    await userEvent.click(screen.getByRole('button', { name: 'Country' }))
    expect(screen.getByLabelText('Filter type')).toBeTruthy()
    await userEvent.selectOptions(screen.getByLabelText('Filter type'), 'advanced')
    expect(screen.getByTestId('advanced-editor')).toBeTruthy()
    unmount()
    renderPane(makeSpec({ allow_change_filter_types: false }))
    await open()
    await userEvent.click(screen.getByRole('button', { name: 'Country' }))
    expect(screen.queryByLabelText('Filter type')).toBeNull()
  })

  it('Top N: "Bottom 5" by a measure is applied', async () => {
    let state: PaneState = {}
    const topn = card('Country', { kind: 'topn', default: def('and', { op: 'topn', values: [], params: { n: 3, direction: 'top', measure: 'Total Sales' } }) })
    renderPane(makeSpec({}, { filters: [topn] }), {}, (s) => (state = s))
    await open()
    expect(summaryOf('Country')).toBe('Top 3 by [Total Sales]')
    await userEvent.click(screen.getByRole('button', { name: 'Country' }))
    const editor = screen.getByTestId('topn-editor')
    await userEvent.selectOptions(within(editor).getByLabelText('Show items'), 'bottom')
    const n = within(editor).getByLabelText('N')
    await userEvent.clear(n)
    await userEvent.type(n, '5')
    // parked measures are not offered
    expect(within(editor).queryByRole('option', { name: 'Parked' })).toBeNull()
    await userEvent.click(within(editor).getByRole('button', { name: 'Apply filter' }))
    expect(state['page:p1:Country'].value?.conditions[0].params).toEqual({ n: 5, direction: 'bottom', measure: 'Total Sales' })
    expect(summaryOf('Country')).toBe('Bottom 5 by [Total Sales]')
  })

  it('Relative date: "last 2 calendar months" is applied', async () => {
    let state: PaneState = {}
    const rel = card('Date', { kind: 'relative', column: 'DateKey', data_type: 'datetime', default: null })
    renderPane(makeSpec({}, { filters: [rel] }), {}, (s) => (state = s))
    await open()
    await userEvent.click(screen.getByRole('button', { name: 'Date' }))
    const editor = screen.getByTestId('relative-editor')
    await userEvent.selectOptions(within(editor).getByLabelText('Direction'), 'last')
    const amount = within(editor).getByLabelText('Amount')
    await userEvent.clear(amount)
    await userEvent.type(amount, '2')
    await userEvent.selectOptions(within(editor).getByLabelText('Unit'), 'month')
    await userEvent.click(within(editor).getByLabelText('Calendar'))
    await userEvent.click(within(editor).getByRole('button', { name: 'Apply filter' }))
    const params = state['page:p1:Date'].value!.conditions[0].params
    expect(params.ui).toEqual({ direction: 'last', n: 2, unit: 'month', calendar: true, include_today: false })
    expect(summaryOf('Date')).toBe('is in the last 2 months (calendar)')
    expect(params.lower).toBeDefined()
  })

  it('is styled from the pane colours', async () => {
    renderPane(makeSpec({ filter_pane: { expanded: true, colours: { backgroundColor: '#112233', filterCard: { Available: { backgroundColor: '#445566' } } } } }))
    expect(screen.getByTestId('filters-pane').style.background).toMatch(/#112233|rgb\(17, 34, 51\)/)
    expect(screen.getByTestId('filter-card-Country').style.background).toMatch(/#445566|rgb\(68, 85, 102\)/)
  })
})

describe('standalone dashboard Filters pane', () => {
  afterEach(() => vi.restoreAllMocks())

  it('shows the Filters pane and loads card values from the local service', async () => {
    const calls: { path: string; auth: string | null; body: Record<string, unknown> | null }[] = []
    vi.stubGlobal('ResizeObserver', FakeResizeObserver)
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        const path = String(url).replace('/api/v1/published', '')
        calls.push({
          path,
          auth: (init?.headers as Record<string, string> | undefined)?.Authorization ?? null,
          body: init?.body ? JSON.parse(String(init.body)) : null,
        })
        if (path === '/dashboard/spec')
          return json(standaloneSpec([{ name: 'p1', display_name: 'Overview', filters: [filterCard('Country')] }]))
        if (path === '/dashboard/accelerate') return json({ hydrated: false, available: false })
        if (path === '/dashboard/query') return json(cardResults())
        if (path === '/dashboard/filter-values') return json({ values: ['DE', 'FR'], truncated: false })
        if (path === '/session') return json({ auth_method: 'password', authenticated: true, account: 'a', user: 'u' })
        return json({}, 404)
      }),
    )
    const qc = new QueryClient({ defaultOptions: { queries: { retry: false } } })
    render(
      <QueryClientProvider client={qc}>
        <DashboardApp
          conversionId="standalone"
          connectionId="standalone"
          apiConfig={{ baseUrl: '/api/v1/published', token: 'tok', published: true }}
          variant="standalone"
        />
      </QueryClientProvider>,
    )
    await userEvent.click(await screen.findByTestId('filters-tab'))
    await userEvent.click(await screen.findByRole('button', { name: 'Country' }))
    await waitFor(() => expect(screen.getByText('FR')).toBeTruthy())
    const request = calls.find((c) => c.path === '/dashboard/filter-values')!
    expect(request.auth).toBe('Bearer tok')
    expect(request.body).toMatchObject({ table: 'Customer', column: 'Country' })
    expect(request.body).not.toHaveProperty('connection_id')
  })
})
