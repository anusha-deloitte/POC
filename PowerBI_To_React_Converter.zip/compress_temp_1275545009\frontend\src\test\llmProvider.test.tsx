import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { AnalyzeStep } from '../steps/AnalyzeStep'
import { ConvertStep } from '../steps/ConvertStep'
import { useWizard } from '../store/wizard'

function wrap(ui: React.ReactElement) {
  const qc = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  })
  return render(<QueryClientProvider client={qc}>{ui}</QueryClientProvider>)
}

const summary = {
  id: 'c1',
  report: 'r',
  model: { tables: 1, relationships: 0, measures: 0, roles: 0 },
  pages: [],
  visual_types: {},
  warnings: [],
}

describe('Translation AI provider', () => {
  beforeEach(() => {
    localStorage.clear()
    useWizard.getState().reset()
    useWizard.setState({ conversionId: 'c1', connectionId: 'p1', llmProvider: null })
    Element.prototype.scrollIntoView = vi.fn()
  })
  afterEach(() => vi.restoreAllMocks())

  it('defaults to the server default and persists the choice', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        if (url.endsWith('/llm/providers'))
          return new Response(
            JSON.stringify({
              default: 'cortex',
              cortex: { model: 'claude-3-5-sonnet' },
              horizon: { configured: false },
            }),
          )
        return new Response(JSON.stringify(summary))
      }),
    )
    wrap(<AnalyzeStep />)
    const select = (await screen.findByLabelText('Translation AI')) as HTMLSelectElement
    await waitFor(() => expect(select.value).toBe('cortex'))
    expect(screen.getByRole('option', { name: /Snowflake Cortex \(claude-3-5-sonnet\)/ })).toBeVisible()
    expect(screen.getByRole('option', { name: 'Horizon (not configured)' })).toBeVisible()
    expect(screen.getByTestId('translation-ai')).toHaveTextContent(/SNOWFLAKE.CORTEX_USER/)
    await userEvent.setup().selectOptions(select, 'horizon')
    expect(localStorage.getItem('pbic.llm_provider')).toBe('horizon')
    expect(screen.getByTestId('translation-ai')).toHaveTextContent(/Horizon LLM gateway/)
    expect(screen.getByTestId('translation-ai')).toHaveTextContent(/Switching provider re-translates/)
  })

  it('ignores an invalid stored provider', () => {
    localStorage.setItem('pbic.llm_provider', 'openai')
    vi.resetModules()
    return import('../store/wizard').then((m) => {
      expect(m.useWizard.getState().llmProvider).toBeNull()
    })
  })

  it('sends llm_provider and use_llm with Convert and resume', async () => {
    useWizard.setState({ llmProvider: 'horizon' })
    let body: Record<string, unknown> | null = null
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.endsWith('/dashboard/convert') && init?.method === 'POST') {
          body = JSON.parse(String(init.body))
          return new Response(JSON.stringify({ events: [], summary: {} }))
        }
        return new Response(JSON.stringify({ events: [], done: false }))
      }),
    )
    wrap(<ConvertStep />)
    await waitFor(() => expect(body).not.toBeNull())
    expect(body).toMatchObject({ use_llm: true, llm_provider: 'horizon', resume: true })
  })

  it('explains a cortex_unavailable failure', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.endsWith('/dashboard/convert') && init?.method === 'POST')
          return new Response(
            JSON.stringify({
              detail: { code: 'cortex_unavailable', message: 'needs CORTEX_USER.' },
            }),
            { status: 422, headers: { 'content-type': 'application/json' } },
          )
        return new Response(JSON.stringify({ events: [], done: false }))
      }),
    )
    wrap(<ConvertStep />)
    const msg = await screen.findByText(/Snowflake Cortex can't be used with this connection/)
    expect(msg).toHaveTextContent(/needs CORTEX_USER\./)
    expect(msg).toHaveTextContent(/pick Horizon under "Translation AI" in the Analyze step/)
  })
})
