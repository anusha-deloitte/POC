"""PDF comparison batches: upload several Power BI PDF exports, match them to stored reports and
pages by content, let the user correct the matches, and only then store the references.

Storage: `<storage>/pdf_batches/<id>/` with `match.json` (written atomically), `<i>.pdf` and
`pages/<i>_<p>.png|json`. Nothing becomes a reference until `confirm`.
"""

from __future__ import annotations

import io
import json
import re
import shutil
import time
import uuid
from pathlib import Path
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Response, UploadFile
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from app.api.deps import get_ingest_service, require_token
from app.services import compare_history, compare_store
from app.services.ingest import IngestError, IngestService
from app.services.page_fingerprint import ReportFingerprint, stored_fingerprints
from app.services.pdf_matching import match_pdf
from app.services.pdf_text import PdfTextError, extract_pages, pdf_title

router = APIRouter(
    prefix="/api/v1/visual-compare", tags=["pdf-batches"], dependencies=[Depends(require_token)]
)

MAX_PDF_BYTES = 50_000_000
MAX_BATCH_BYTES = 200_000_000
_ID = re.compile(r"^[0-9a-f]{32}$")
_summary_cache: dict[str, tuple[float, dict]] = {}

Svc = Annotated[IngestService, Depends(get_ingest_service)]


def _root(svc: IngestService) -> Path:
    root = svc.storage_dir / "pdf_batches"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _batch_dir(svc: IngestService, batch_id: str) -> Path:
    if not _ID.match(batch_id or ""):
        raise HTTPException(404, "batch not found")
    folder = _root(svc) / batch_id
    if not folder.is_dir():
        raise HTTPException(404, "batch not found")
    return folder


def _write_match(folder: Path, data: dict[str, Any]) -> None:
    tmp = folder / "match.json.tmp"
    tmp.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
    tmp.replace(folder / "match.json")


def _read_match(folder: Path) -> dict[str, Any]:
    try:
        return json.loads((folder / "match.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise HTTPException(404, "batch not found") from e


def _ran_at(fp: ReportFingerprint) -> float:
    return fp.converted_at or fp.uploaded_at


def _reports_payload(reports: list[ReportFingerprint]) -> list[dict[str, Any]]:
    ordered = sorted(reports, key=_ran_at, reverse=True)
    return [
        {
            "conversion_id": r.conversion_id,
            "report": r.report,
            "job_name": r.job_name,
            "ran_at": _ran_at(r),
            "pages": [
                {"page": p.page, "display_name": p.display_name, "ordinal": p.ordinal}
                for p in r.pages
            ],
        }
        for r in ordered
    ]


def _process_pdf(
    folder: Path, index: int, name: str, data: bytes, reports: list[ReportFingerprint]
) -> dict[str, Any]:
    entry: dict[str, Any] = {
        "index": index, "file": name, "pages": 0, "error": None, "confident": False,
        "warnings": [], "candidates": [],
    }  # fmt: skip
    try:
        pages = extract_pages(data)
    except PdfTextError as e:
        entry["error"] = str(e)
        return entry
    (folder / f"{index}.pdf").write_bytes(data)
    pages_dir = folder / "pages"
    pages_dir.mkdir(exist_ok=True)
    for p in pages:
        (pages_dir / f"{index}_{p.index}.png").write_bytes(p.png or b"")
        (pages_dir / f"{index}_{p.index}.json").write_text(
            json.dumps(p.to_dict()), encoding="utf-8"
        )
    result = match_pdf(name, pages, reports, pdf_title(data))
    entry.update(result.to_dict())
    entry["index"], entry["file"], entry["pages"], entry["error"] = index, name, len(pages), None
    return entry


@router.post("/batches")
async def create_batch(pdfs: list[UploadFile], svc: Svc) -> dict[str, Any]:
    """Upload PDFs; returns match candidates per PDF. Nothing is stored as a reference yet."""
    if not pdfs:
        raise HTTPException(422, "upload at least one PDF")
    blobs: list[tuple[str, bytes]] = []
    total = 0
    for f in pdfs:
        data = await f.read()
        if len(data) > MAX_PDF_BYTES:
            raise HTTPException(413, f"{f.filename or 'PDF'} is larger than 50 MB")
        total += len(data)
        if total > MAX_BATCH_BYTES:
            raise HTTPException(413, "the batch is larger than 200 MB")
        blobs.append((f.filename or "report.pdf", data))

    batch_id = uuid.uuid4().hex
    folder = _root(svc) / batch_id
    folder.mkdir(parents=True)
    try:
        reports = await run_in_threadpool(stored_fingerprints, svc)
        entries = []
        for i, (name, data) in enumerate(blobs):
            entries.append(await run_in_threadpool(_process_pdf, folder, i, name, data, reports))
        record = {
            "id": batch_id,
            "created_at": time.time(),
            "confirmed": False,
            "confirmed_at": None,
            "confirmations": [],
            "pdfs": entries,
            "reports": _reports_payload(reports),
        }
        _write_match(folder, record)
    except Exception:
        shutil.rmtree(folder, ignore_errors=True)
        raise
    return record


def _summary(record: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": record["id"],
        "created_at": record.get("created_at"),
        "files": [p.get("file") for p in record.get("pdfs", [])],
        "pdf_count": len(record.get("pdfs", [])),
        "confirmed": bool(record.get("confirmed")),
        "confirmed_at": record.get("confirmed_at"),
        "conversions": sorted({c["conversion_id"] for c in record.get("confirmations", [])}),
    }


@router.get("/batches")
def list_batches(svc: Svc) -> dict[str, Any]:
    out = []
    for folder in _root(svc).iterdir():
        match = folder / "match.json"
        if not (folder.is_dir() and _ID.match(folder.name) and match.is_file()):
            continue
        mtime = match.stat().st_mtime
        hit = _summary_cache.get(folder.name)
        if hit and hit[0] == mtime:
            out.append(hit[1])
            continue
        try:
            summary = _summary(json.loads(match.read_text(encoding="utf-8")))
        except (OSError, ValueError, KeyError):
            continue
        _summary_cache[folder.name] = (mtime, summary)
        out.append(summary)
    out.sort(key=lambda s: s.get("created_at") or 0, reverse=True)
    return {"batches": out}


@router.get("/batches/{batch_id}")
def get_batch(batch_id: str, svc: Svc) -> dict[str, Any]:
    return _read_match(_batch_dir(svc, batch_id))


@router.get("/batches/{batch_id}/pdfs/{index}/pages/{page}/image")
def batch_page_image(batch_id: str, index: int, page: int, svc: Svc) -> Response:
    path = _batch_dir(svc, batch_id) / "pages" / f"{index}_{page}.png"
    if index < 0 or page < 0 or not path.is_file():
        raise HTTPException(404, "page image not found")
    return Response(content=path.read_bytes(), media_type="image/png")


@router.delete("/batches/{batch_id}", status_code=204)
def delete_batch(batch_id: str, svc: Svc) -> None:
    """Remove the batch; the per-page comparison history stays with its conversions."""
    shutil.rmtree(_batch_dir(svc, batch_id), ignore_errors=True)
    _summary_cache.pop(batch_id, None)


class PageAssignment(BaseModel):
    pdf_page: int
    page: str


class PdfAssignment(BaseModel):
    file_index: int
    conversion_id: str
    pages: list[PageAssignment] = Field(default_factory=list)


class ConfirmRequest(BaseModel):
    pdfs: list[PdfAssignment]


@router.post("/batches/{batch_id}/confirm")
def confirm_batch(batch_id: str, req: ConfirmRequest, svc: Svc) -> dict[str, Any]:
    """Validate every assignment, then store the references. All or nothing."""
    folder = _batch_dir(svc, batch_id)
    record = _read_match(folder)
    by_index = {p["index"]: p for p in record.get("pdfs", [])}
    plan: list[tuple[str, Path, str, int, int]] = []  # (conversion, dir, page, file, pdf_page)
    taken: set[tuple[str, str]] = set()
    names: dict[str, set[str]] = {}
    dirs: dict[str, Path] = {}
    for assignment in req.pdfs:
        entry = by_index.get(assignment.file_index)
        if entry is None or entry.get("error"):
            raise HTTPException(422, f"PDF {assignment.file_index} is unknown or could not be read")
        cid = assignment.conversion_id
        if cid not in names:
            try:
                dirs[cid] = svc.conversion_dir(cid)
                bundle = svc.load_bundle(cid)
            except (ValueError, IngestError) as e:
                raise HTTPException(404, "conversion not found") from e
            names[cid] = {p.name for p in bundle.report.pages}
        for pa in assignment.pages:
            if pa.page not in names[cid]:
                raise HTTPException(422, f"page '{pa.page}' is not in that report")
            if not 0 <= pa.pdf_page < int(entry["pages"]):
                raise HTTPException(422, f"PDF page {pa.pdf_page} is out of range")
            if (cid, pa.page) in taken:
                raise HTTPException(422, f"page '{pa.page}' is assigned more than once")
            taken.add((cid, pa.page))
            plan.append((cid, dirs[cid], pa.page, assignment.file_index, pa.pdf_page))

    stored: list[dict[str, Any]] = []
    superseded: list[str] = []
    for cid, conv_dir, page, file_index, pdf_page in plan:
        png = (folder / "pages" / f"{file_index}_{pdf_page}.png").read_bytes()
        text = json.loads((folder / "pages" / f"{file_index}_{pdf_page}.json").read_text("utf-8"))
        if compare_store.store_reference(conv_dir, page, png, text, "pdf-batch"):
            superseded.append(page)
        stored.append({"conversion_id": cid, "page": page, "file_index": file_index})
    record["confirmed"] = True
    record["confirmed_at"] = time.time()
    record["confirmations"] = [
        {
            "file_index": a.file_index, "conversion_id": a.conversion_id,
            "pages": [pa.model_dump() for pa in a.pages],
        }
        for a in req.pdfs
    ]  # fmt: skip
    _write_match(folder, record)
    _summary_cache.pop(batch_id, None)
    return {"stored": stored, "superseded_comparisons": superseded, "batch": _summary(record)}


# ------------------------------------------------------------------ reports


def _report_rows(svc: IngestService, record: dict[str, Any]) -> list[dict[str, Any]]:
    """One row per run recorded under this batch (its own frozen results, not the latest ones)."""
    rows: list[dict[str, Any]] = []
    jobs = {j["id"]: j for j in svc.list_jobs()}
    for cid in sorted({c["conversion_id"] for c in record.get("confirmations", [])}):
        try:
            conv_dir = svc.conversion_dir(cid)
        except ValueError:
            continue
        job = jobs.get(cid, {})
        for run in compare_history.batch_runs(conv_dir, record["id"]):
            s = run["summary"]
            trend = [
                t["value"]
                for t in compare_history.trend(conv_dir, run["page"], limit=10)
                if t["kind"] == run["kind"]
            ]
            rows.append(
                {
                    "conversion_id": cid,
                    "report": job.get("report"),
                    "job_name": job.get("name"),
                    "ran_at": job.get("converted_at") or job.get("uploaded_at"),
                    "page": run["page"],
                    "display_name": run.get("display_name"),
                    "kind": run["kind"],
                    "run_id": run["run_id"],
                    "run_at": run["ts"],
                    "similarity": s.get("similarity"),
                    "findings": s.get("findings"),
                    "fixable": s.get("fixable"),
                    "numbers_printed": s.get("numbers_printed"),
                    "numbers_matched": s.get("numbers_matched"),
                    "visuals_mismatched": s.get("visuals_mismatched"),
                    "filters": ", ".join(
                        f"{f.get('slicer')}={f.get('value')}" for f in s.get("filters_applied", [])
                    ),
                    "trend": trend,
                }
            )
    return sorted(rows, key=lambda r: (r["job_name"] or "", r["page"], r["run_at"]))


_XLSX_COLUMNS = [
    ("Report", "report"), ("Job", "job_name"), ("Job run", "ran_at"), ("Page", "display_name"),
    ("Check", "kind"), ("Run at", "run_at"), ("Similarity", "similarity"), ("Findings", "findings"),
    ("Fixable", "fixable"), ("Numbers printed", "numbers_printed"),
    ("Numbers matched", "numbers_matched"), ("Visuals mismatched", "visuals_mismatched"),
    ("Filters", "filters"), ("Trend (last 10)", "trend"),
]  # fmt: skip


def build_report_xlsx(rows: list[dict[str, Any]]) -> bytes:
    from datetime import datetime

    from openpyxl import Workbook

    wb = Workbook()
    ws = wb.active
    ws.title = "PDF comparison"
    ws.append([label for label, _ in _XLSX_COLUMNS])
    for row in rows:
        values = []
        for _, key in _XLSX_COLUMNS:
            v = row.get(key)
            if key in ("ran_at", "run_at") and isinstance(v, int | float):
                v = datetime.fromtimestamp(v).strftime("%Y-%m-%d %H:%M:%S")
            elif key == "trend":
                v = " > ".join("-" if t is None else f"{t:g}" for t in (v or []))
            values.append(v)
        ws.append(values)
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


@router.get("/batches/{batch_id}/report")
def batch_report(batch_id: str, svc: Svc, format: str = "json") -> Response:
    if format not in ("json", "xlsx"):
        raise HTTPException(422, "format must be json or xlsx")
    record = _read_match(_batch_dir(svc, batch_id))
    rows = _report_rows(svc, record)
    if format == "xlsx":
        return Response(
            content=build_report_xlsx(rows),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={
                "Content-Disposition": f'attachment; filename="pdf-comparison-{batch_id[:8]}.xlsx"'
            },
        )
    body = {"batch": _summary(record), "rows": rows}
    return Response(
        content=json.dumps(body, default=str),
        media_type="application/json",
        headers={
            "Content-Disposition": f'attachment; filename="pdf-comparison-{batch_id[:8]}.json"'
        },
    )
