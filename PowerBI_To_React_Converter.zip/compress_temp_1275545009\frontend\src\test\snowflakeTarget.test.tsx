import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { AnalyzeStep } from '../steps/AnalyzeStep'
import { ConvertStep } from '../steps/ConvertStep'
import { useWizard } from '../store/wizard'

function wrap(ui: React.ReactElement) {
  const qc = new QueryClient({
    defaultOptions: { queries: { retry: false }, mutations: { retry: false } },
  })
  return render(<QueryClientProvider client={qc}>{ui}</QueryClientProvider>)
}

const summary = {
  id: 'c1',
  report: 'r',
  model: { tables: 1, relationships: 0, measures: 0, roles: 0 },
  pages: [],
  visual_types: {},
  warnings: [],
}

const hints = {
  server: 'srv',
  warehouse: 'WH_X',
  database: 'MYDB',
  schema: 'PUBLIC',
  binding_settings: { database_override: null, schema_override: 'SAVED_SCH' },
}

describe('Snowflake target card', () => {
  beforeEach(() => {
    localStorage.clear()
    useWizard.getState().reset()
    useWizard.setState({ conversionId: 'c1', connectionId: 'p1', llmProvider: null })
    Element.prototype.scrollIntoView = vi.fn()
  })
  afterEach(() => vi.restoreAllMocks())

  it('shows hints, saved override, runs the check and shows case details', async () => {
    let preflightBody: Record<string, unknown> | null = null
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.endsWith('/dashboard/preflight')) {
          preflightBody = JSON.parse(String(init?.body))
          return new Response(
            JSON.stringify({
              role: 'R',
              warehouse: 'W',
              targets: [
                {
                  database: 'MYDB',
                  schema_name: 'PUBLIC',
                  tables: ['A', 'B'],
                  found: ['A'],
                  case_mismatch: ['PUBLIC.b (Snowflake: PUBLIC.B)'],
                  error: null,
                  listed: 2,
                },
              ],
              bound: 2,
              accessible: 1,
              blocking: false,
              message: '1/2 bound tables reachable with role R / warehouse W',
              case: {
                checked: 4,
                exact: 2,
                corrected: ["table «b» (table «T») -> «B»"],
                ambiguous: [],
                missing: ['column «z» (table «T»): not found'],
                errors: [],
              },
              case_saved: true,
            }),
          )
        }
        if (url.endsWith('/source-hints')) return new Response(JSON.stringify(hints))
        if (url.endsWith('/llm/providers'))
          return new Response(
            JSON.stringify({ default: 'cortex', cortex: { model: 'm' }, horizon: { configured: true } }),
          )
        return new Response(JSON.stringify(summary))
      }),
    )
    wrap(<AnalyzeStep />)
    const card = await screen.findByTestId('snowflake-target')
    await waitFor(() =>
      expect(card).toHaveTextContent('The report\'s Power Query reads MYDB.PUBLIC (warehouse WH_X).'),
    )
    const ui = within(card)
    const db = ui.getByLabelText('Database override')
    expect(db).toHaveAttribute('placeholder', 'MYDB')
    expect(ui.getByLabelText('Schema override')).toHaveValue('SAVED_SCH')
    await userEvent.setup().type(db, 'OTHERDB')
    await userEvent.setup().click(ui.getByRole('button', { name: 'Check access' }))
    await waitFor(() => expect(preflightBody).not.toBeNull())
    expect(preflightBody).toMatchObject({
      connection_id: 'p1',
      database_override: 'OTHERDB',
      schema_override: 'SAVED_SCH',
    })
    const status = await ui.findByRole('status')
    expect(status).toHaveTextContent('1/2 bound tables reachable with role R / warehouse W')
    expect(status).toHaveTextContent('MYDB.PUBLIC: 1/2 tables found')
    expect(status).toHaveTextContent('case differs: PUBLIC.b (Snowflake: PUBLIC.B)')
    const caseBox = within(screen.getByTestId('case-check'))
    expect(caseBox.getByText('Letter case: 2/4 names match Snowflake exactly')).toBeVisible()
    expect(caseBox.getByText(/saved with this conversion/)).toBeVisible()
    expect(caseBox.getByText(/not found/)).toBeVisible()
    expect(useWizard.getState().bindingTarget).toEqual({ database: 'OTHERDB', schema: 'SAVED_SCH' })
  })

  it('Convert sends overrides only when a target was chosen', async () => {
    const bodies: Array<Record<string, unknown>> = []
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string, init?: RequestInit) => {
        if (url.endsWith('/dashboard/convert') && init?.method === 'POST') {
          bodies.push(JSON.parse(String(init.body)))
          return new Response(JSON.stringify({ events: [], summary: {} }))
        }
        return new Response(JSON.stringify({ events: [], done: false }))
      }),
    )
    const first = wrap(<ConvertStep />)
    await waitFor(() => expect(bodies.length).toBe(1))
    expect(bodies[0]).not.toHaveProperty('database_override')
    first.unmount()

    useWizard.setState({ bindingTarget: { database: ' D ', schema: '' } })
    wrap(<ConvertStep />)
    await waitFor(() => expect(bodies.length).toBe(2))
    expect(bodies[1]).toMatchObject({ database_override: 'D', schema_override: null })
  })

  it('resets the binding target when a conversion is opened', () => {
    useWizard.setState({ bindingTarget: { database: 'a', schema: 'b' } })
    useWizard.getState().setConversion('c2')
    expect(useWizard.getState().bindingTarget).toBeNull()
    useWizard.setState({ bindingTarget: { database: 'a', schema: 'b' } })
    useWizard.getState().resume('c3', 'analyze')
    expect(useWizard.getState().bindingTarget).toBeNull()
  })

  describe('prefill precedence', () => {
    const profile = { id: 'p1', name: 'n', account: 'a', user: 'u', auth_method: 'password', warehouse: 'W', database: 'CONN_DB', schema_name: 'CONN_SCH' }
    function serve(binding: Record<string, string | null>) {
      vi.stubGlobal(
        'fetch',
        vi.fn(async (url: string) => {
          if (url.endsWith('/source-hints'))
            return new Response(JSON.stringify({ ...hints, binding_settings: binding }))
          if (url.endsWith('/connections')) return new Response(JSON.stringify([profile]))
          if (url.endsWith('/llm/providers'))
            return new Response(JSON.stringify({ default: 'cortex', cortex: { model: 'm' }, horizon: { configured: true } }))
          return new Response(JSON.stringify(summary))
        }),
      )
    }

    it('uses the selected connection when nothing is typed or saved', async () => {
      serve({ database_override: null, schema_override: null })
      wrap(<AnalyzeStep />)
      const card = within(await screen.findByTestId('snowflake-target'))
      await waitFor(() => expect(card.getByLabelText('Database override')).toHaveValue('CONN_DB'))
      expect(card.getByLabelText('Schema override')).toHaveValue('CONN_SCH')
      // the report's Power Query values remain the placeholder fallback
      expect(card.getByLabelText('Database override')).toHaveAttribute('placeholder', 'MYDB')
    })

    it('a saved override beats the connection, and typed beats both', async () => {
      serve({ database_override: 'SAVED_DB', schema_override: null })
      wrap(<AnalyzeStep />)
      const card = within(await screen.findByTestId('snowflake-target'))
      await waitFor(() => expect(card.getByLabelText('Database override')).toHaveValue('SAVED_DB'))
      await waitFor(() => expect(card.getByLabelText('Schema override')).toHaveValue('CONN_SCH'))
      useWizard.setState({ bindingTarget: { database: 'TYPED', schema: '' } })
      await waitFor(() => expect(card.getByLabelText('Database override')).toHaveValue('TYPED'))
      expect(card.getByLabelText('Schema override')).toHaveValue('')
    })
  })
})
