import { useState } from 'react'
import { resourceUrl } from '../api'
import { imageFit, resolveButton, resolveShape, type ButtonState } from '../pbi/chrome'
import { fontCss } from '../pbi/fonts'
import { imageSourceOf } from '../pbi/images'
import { usePbiTheme } from '../pbi/resolve'
import { useReport } from '../reportContext'
import type { VisualSpec } from '../types'

const ICON_PATHS: Record<string, string> = {
  back: 'M15 5 L7 12 L15 19',
  next: 'M9 5 L17 12 L9 19',
  up: 'M5 15 L12 7 L19 15',
  down: 'M5 9 L12 17 L19 9',
  help: 'M9 9 a3 3 0 1 1 4 3 q-1 1 -1 2 M12 18 v1',
  info: 'M12 8 v1 M12 11 v6',
  reset: 'M5 12 a7 7 0 1 1 2 5 M5 18 v-5 h5',
  close: 'M6 6 L18 18 M18 6 L6 18',
}

/** A Power BI action button: per-state fill/outline/text/icon; measure-driven text arrives as
 * `text` (the `<visual>#title` query result). */
export function ButtonVisual({
  spec,
  text,
  onClick,
  disabled,
  textOffsetPx = 0,
}: {
  spec: VisualSpec
  text?: string
  onClick?: () => void
  disabled?: boolean
  textOffsetPx?: number
}) {
  const theme = usePbiTheme()
  const { conversionId, apiConfig } = useReport()
  const [state, setState] = useState<ButtonState>('default')
  const style = resolveButton(spec, theme, disabled ? 'disabled' : state)
  const label = text ?? style.text.value
  const hover = state === 'hover' && !disabled && !!style.fill
  return (
    <button
      type="button"
      data-testid={`button-${spec.name}`}
      aria-label={label || spec.action?.tooltip || spec.name}
      title={spec.action?.tooltip}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setState('hover')}
      onMouseLeave={() => setState('default')}
      onMouseDown={() => setState('pressed')}
      onMouseUp={() => setState('hover')}
      className="flex h-full w-full items-center overflow-hidden"
      style={{
        background: style.fill,
        filter: hover ? 'brightness(0.9)' : undefined,
        border: style.outline ? `${style.outline.weightPx}px solid ${style.outline.color}` : 'none',
        borderRadius: style.roundedPx,
        boxShadow: [style.shadow, style.glow].filter(Boolean).join(', ') || undefined,
        cursor: onClick && !disabled ? 'pointer' : 'default',
        justifyContent:
          style.text.align === 'left' ? 'flex-start' : style.text.align === 'right' ? 'flex-end' : 'center',
        paddingTop: style.text.margins.top,
        paddingRight: style.text.margins.right,
        paddingBottom: style.text.margins.bottom,
        paddingLeft: style.text.margins.left,
      }}
    >
      {style.icon &&
        (style.icon.customResource ? (
          <img
            alt=""
            src={resourceUrl(conversionId, style.icon.customResource, apiConfig)}
            className="mr-1 max-h-full"
            style={{ height: '60%' }}
          />
        ) : (
          <svg
            viewBox="0 0 24 24"
            className="mr-1"
            style={{ height: '60%' }}
            fill="none"
            stroke={style.icon.color ?? style.text.color}
            strokeWidth={2}
          >
            <path d={ICON_PATHS[style.icon.shape] ?? ICON_PATHS.info} />
          </svg>
        ))}
      {style.text.show && label && (
        <span
          className="truncate"
          style={{
            ...fontCss(style.text.font),
            color: style.text.color,
            position: 'relative',
            top: `${style.text.baselineShiftEm + textOffsetPx / 16}em`,
          }}
        >
          {label}
        </span>
      )}
    </button>
  )
}

/** Rectangle, rounded rectangle, oval, line and triangle drawn as SVG. */
export function ShapeVisual({ spec }: { spec: VisualSpec }) {
  const theme = usePbiTheme()
  const s = resolveShape(spec, theme)
  const w = Math.max(spec.width, 1)
  const h = Math.max(spec.height, 1)
  const stroke = s.line?.color ?? 'none'
  const sw = s.line?.weightPx ?? 0
  const fill = s.fill ?? 'none'
  let body: React.ReactNode
  switch (s.kind) {
    case 'oval':
      body = (
        <ellipse
          cx={w / 2}
          cy={h / 2}
          rx={Math.max(w / 2 - sw / 2, 0)}
          ry={Math.max(h / 2 - sw / 2, 0)}
          fill={fill}
          stroke={stroke}
          strokeWidth={sw}
        />
      )
      break
    case 'triangle':
      body = (
        <polygon
          points={`${w / 2},${sw / 2} ${w - sw / 2},${h - sw / 2} ${sw / 2},${h - sw / 2}`}
          fill={fill}
          stroke={stroke}
          strokeWidth={sw}
        />
      )
      break
    case 'line':
      body = s.vertical ? (
        <line x1={w / 2} y1={0} x2={w / 2} y2={h} stroke={stroke} strokeWidth={sw || 1} />
      ) : (
        <line x1={0} y1={h / 2} x2={w} y2={h / 2} stroke={stroke} strokeWidth={sw || 1} />
      )
      break
    default:
      body = (
        <rect
          x={sw / 2}
          y={sw / 2}
          width={Math.max(w - sw, 0)}
          height={Math.max(h - sw, 0)}
          rx={s.kind === 'roundedRectangle' ? s.roundedPx || 8 : 0}
          fill={fill}
          stroke={stroke}
          strokeWidth={sw}
        />
      )
  }
  const rotate = s.kind === 'line' ? 0 : s.rotation
  return (
    <svg
      data-testid={`shape-${spec.name}`}
      width="100%"
      height="100%"
      viewBox={`0 0 ${w} ${h}`}
      preserveAspectRatio="none"
      style={{ overflow: 'visible', transform: rotate ? `rotate(${rotate}deg)` : undefined }}
    >
      {body}
    </svg>
  )
}

/** A registered image (resource file) or a linked one. */
export function ImageVisual({ spec }: { spec: VisualSpec }) {
  const { conversionId, apiConfig } = useReport()
  const source = imageSourceOf(spec)
  if (!source) return <div data-testid={`image-${spec.name}`} className="h-full w-full" />
  const src = source.resource ? resourceUrl(conversionId, source.resource, apiConfig) : source.url
  return (
    <img
      data-testid={`image-${spec.name}`}
      alt={spec.title ?? ''}
      src={src}
      className="h-full w-full"
      style={{ objectFit: imageFit(spec.pbir?.objects) }}
    />
  )
}
