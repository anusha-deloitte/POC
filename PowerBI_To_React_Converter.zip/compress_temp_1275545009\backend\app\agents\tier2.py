"""Tier-2 measure fallback: an LLM (Snowflake Cortex or the Horizon gateway) proposes
Snowflake SQL for DAX the deterministic compiler cannot handle; every proposal is
executed and validated before acceptance (the LLM never ships unverified artifacts).

The accepted artifact is a SQL SELECT returning one scalar column, evaluated
over the physically-bound star schema. It is stored per conversion and the
engine treats it as an opaque native-query leaf.
"""

from __future__ import annotations

import copy
import json
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path

from app.binding.resolver import BindingMap
from app.core.logging import append_jsonl
from app.dax.compiler import DaxUnsupported, MeasureCompiler
from app.dax.parser import (
    BinOp,
    Blank,
    ColumnRef,
    DaxParseError,
    FuncCall,
    MeasureRef,
    Str,
    TableRef,
    UnaryOp,
    VarExpr,
    VarRef,
    parse_dax,
)
from app.ir.model import DaxRewrite, Measure, SemanticModel

try:  # phase 05 introduces the shared identifier quoting
    from app.binding.resolver import quote_ident
except ImportError:  # pragma: no cover - replaced once phase 05 lands

    def quote_ident(name: str) -> str:
        return '"' + name.replace('"', '""') + '"'


_MAX_ATTEMPTS = 3
_MAX_CLOSURE_MEASURES = 25
_CONTEXT_BUDGET_CHARS = 20_000
_MAX_TEXT_LEN = 256

_SYSTEM_TEMPLATE = """You translate Power BI DAX measures into Snowflake SQL.
Rules:
- Output ONLY a JSON object: {{"sql": "..."}} with a single SELECT returning
  {result_spec}
- Use only the physical tables provided (fully qualified names given).
- Write table and column identifiers exactly as given: keep the double quotes
  where shown (e.g. DB.SCHEMA."lower_table", "COLUMN"), add none where absent
  (plain UPPERCASE names); never put identifiers in single quotes.
- DIVIDE(a,b) must be IFF(b=0 OR b IS NULL, NULL, a/b).
- BLANK() is NULL. No DDL, no DML, no comments, no CTE names beyond t0..t9.
- If the measure is truly impossible with the given schema, return
  {{"error": "reason"}}."""

_NUMERIC_SPEC = "exactly one numeric column aliased RESULT."
_TEXT_SPEC = (
    'exactly one text column aliased RESULT whose value is NULL or one of: {literals}.'
)

_FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|MERGE|CREATE|DROP|ALTER|GRANT|TRUNCATE|CALL)\b", re.IGNORECASE
)
_MEASURE_REF = re.compile(r"(?<![\w'\]])\[([^\]]+)\]")


@dataclass
class Tier2Result:
    measure: str
    sql: str | None
    accepted: bool
    attempts: int
    trace: list[str]


@dataclass
class ExpectedResult:
    kind: str  # "numeric" | "text"
    literals: tuple[str, ...] = ()


def expected_result(expression: str) -> ExpectedResult:
    """Text when every RETURN branch (through VAR/IF/SWITCH) is a string literal or BLANK."""
    try:
        node = parse_dax(expression)
    except DaxParseError:
        return ExpectedResult("numeric")

    literals: list[str] = []

    def terminals(n, scope: dict) -> list | None:
        if isinstance(n, VarExpr):
            inner = dict(scope)
            for name, value in n.bindings:
                inner[name] = value
            return terminals(n.body, inner)
        if isinstance(n, VarRef):
            return terminals(scope[n.name], scope) if n.name in scope else None
        if isinstance(n, FuncCall) and n.name == "IF":
            branches = [n.args[1]] if len(n.args) > 1 else []
            branches.append(n.args[2] if len(n.args) > 2 else Blank())
            return _flatten([terminals(b, scope) for b in branches])
        if isinstance(n, FuncCall) and n.name == "SWITCH" and len(n.args) >= 3:
            rest = n.args[1:]
            results = [rest[i] for i in range(1, len(rest), 2)]
            if len(rest) % 2 == 1:
                results.append(rest[-1])
            else:
                results.append(Blank())
            return _flatten([terminals(r, scope) for r in results])
        return [n]

    def _flatten(parts: list) -> list | None:
        out: list = []
        for p in parts:
            if p is None:
                return None
            out.extend(p)
        return out

    leaves = terminals(node, {})
    if not leaves:
        return ExpectedResult("numeric")
    for leaf in leaves:
        if isinstance(leaf, Str):
            if leaf.value not in literals:
                literals.append(leaf.value)
        elif not isinstance(leaf, Blank):
            return ExpectedResult("numeric")
    if not literals:
        return ExpectedResult("numeric")
    return ExpectedResult("text", tuple(literals))


def _system_prompt(expected: ExpectedResult) -> str:
    if expected.kind == "text":
        spec = _TEXT_SPEC.format(literals=", ".join(f'"{x}"' for x in expected.literals))
    else:
        spec = _NUMERIC_SPEC
    return _SYSTEM_TEMPLATE.format(result_spec=spec)


def _all_measures(model: SemanticModel) -> dict[str, Measure]:
    return {m.name: m for t in model.tables for m in t.measures}


def dependency_closure(model: SemanticModel, measure_name: str) -> list[str]:
    """Measures the given measure references, directly or transitively (breadth first)."""
    measures = _all_measures(model)
    root = measures.get(measure_name)
    if root is None:
        return []
    seen: list[str] = []
    queue = [model.effective_dax(root)]
    while queue and len(seen) < _MAX_CLOSURE_MEASURES:
        expr = queue.pop(0)
        for ref in _MEASURE_REF.findall(expr):
            found = model.find_measure(ref)
            name = found[1].name if found else None
            if name and name != measure_name and name not in seen:
                seen.append(name)
                queue.append(model.effective_dax(found[1]))
                if len(seen) >= _MAX_CLOSURE_MEASURES:
                    break
    return seen


def _referenced_tables(model: SemanticModel, expressions: list[str]) -> set[str]:
    names = {t.name for t in model.tables}
    found: set[str] = set()
    for expr in expressions:
        for t in names:
            if re.search(rf"(?<![\w'])'?{re.escape(t)}'?\s*\[", expr) or re.search(
                rf"\b{re.escape(t)}\b", expr
            ):
                found.add(t)
    return found


def _model_context(
    model: SemanticModel,
    bindings: BindingMap,
    measure_name: str,
    dependency_sql: dict[str, str] | None = None,
) -> str:
    measures = _all_measures(model)
    measure = measures[measure_name]
    closure = dependency_closure(model, measure_name)[:_MAX_CLOSURE_MEASURES]
    expressions = [measure.expression] + [measures[c].expression for c in closure]

    relevant = _referenced_tables(model, expressions)
    if relevant:
        for rel in model.relationships:
            if rel.from_table in relevant:
                relevant.add(rel.to_table)
            elif rel.to_table in relevant:
                relevant.add(rel.from_table)
    tables = [t for t in model.tables if not relevant or t.name in relevant]

    lines = [f"DAX measure [{measure_name}]:", measure.expression, "", "Physical tables:"]
    for t in tables:
        b = bindings.get(t.name)
        if b is None or b.status != "resolved":
            continue
        cols = " | ".join(
            f"{quote_ident(c.source_column or c.name)} (model column: [{c.name}])"
            if (c.source_column and c.source_column != c.name)
            else quote_ident(c.name)
            for c in t.columns
            if not c.is_calculated
        )
        lines.append(f"- model table [{t.name}] -> {b.qualified_name} (columns: {cols})")

    in_scope = {t.name for t in tables}
    rels = [r for r in model.relationships if r.from_table in in_scope and r.to_table in in_scope]
    if rels:
        lines += ["", "Relationships (many side -> one side; filters flow one -> many):"]
        for r in rels:
            flags = ""
            if not r.is_active:
                flags += " [inactive]"
            if r.cross_filtering_behavior == "bothDirections":
                flags += " both directions"
            lines.append(
                f"- {r.from_table}[{r.from_column}] -> {r.to_table}[{r.to_column}]{flags}"
            )

    if closure:
        lines += ["", "Other measures it references (DAX, plus validated SQL where available):"]
        budget = _CONTEXT_BUDGET_CHARS
        for name in closure:
            entry = f"- [{name}] = {measures[name].expression}"
            sql = (dependency_sql or {}).get(name)
            if sql:
                entry += f"\n  validated SQL: {sql}"
            if len(entry) > budget:
                entry = f"- [{name}]: definition omitted (context size limit)"
            budget -= len(entry)
            lines.append(entry)
    return "\n".join(lines)


def _extract_json(text: str) -> dict | None:
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if not m:
        return None
    try:
        data = json.loads(m.group(0))
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


def _check_value(value, expected: ExpectedResult) -> None:
    if value is None:
        return
    if expected.kind == "numeric":
        float(value)
        return
    if not isinstance(value, str) or len(value) > _MAX_TEXT_LEN:
        raise ValueError(f"expected a short text value, got {value!r}")
    if value not in expected.literals:
        raise ValueError(f"text value {value!r} is not one of {list(expected.literals)}")


def _log_attempt(
    log_path: Path | None,
    *,
    measure: str,
    attempt: int,
    expected_kind: str,
    messages: list[dict],
    response: str,
    outcome: str,
    sql: str | None = None,
    error: str | None = None,
    result_value=None,
) -> None:
    if log_path is None:
        return
    try:
        from app.core.config import get_settings

        record = {
            "measure": measure,
            "attempt": attempt,
            "expected_kind": expected_kind,
            "outcome": outcome,
            "error": error,
            "result_value": result_value,
            "ts_attempt": round(time.time(), 3),
        }
        if get_settings().log_llm_text:
            record.update(request_messages=messages, response=response, sql=sql)
        append_jsonl(log_path, "tier2_llm_attempt", **record)
    except Exception:  # noqa: BLE001, S110 - logging is best effort
        pass


def propose_and_validate(
    model: SemanticModel,
    bindings: BindingMap,
    measure_name: str,
    cursor,
    client=None,
    log_path: Path | None = None,
    dependency_sql: dict[str, str] | None = None,
) -> Tier2Result:
    """Ask the LLM for SQL, execute to validate, retry with the error, bounded."""
    trace: list[str] = []
    if client is None:
        from app.services.horizon_client import build_client_from_settings

        client = build_client_from_settings()
        if client is None:
            return Tier2Result(measure_name, None, False, 0, ["Horizon credentials not configured"])

    measure = _all_measures(model)[measure_name]
    expected = expected_result(measure.expression)
    context = _model_context(model, bindings, measure_name, dependency_sql)
    messages = [
        {"role": "system", "content": _system_prompt(expected)},
        {"role": "user", "content": context},
    ]

    def log(attempt: int, text: str, outcome: str, **kw) -> None:
        _log_attempt(
            log_path,
            measure=measure_name,
            attempt=attempt,
            expected_kind=expected.kind,
            messages=messages,
            response=text,
            outcome=outcome,
            **kw,
        )

    for attempt in range(1, _MAX_ATTEMPTS + 1):
        text = client.chat(messages) or ""
        payload = _extract_json(text)
        if payload is None or ("sql" not in payload and "error" not in payload):
            trace.append(f"attempt {attempt}: unparseable response")
            log(attempt, text, "unparseable")
            messages.append({"role": "assistant", "content": text})
            messages.append({"role": "user", "content": 'Respond with only {"sql": "..."} JSON.'})
            continue
        if "error" in payload:
            trace.append(f"attempt {attempt}: model declared impossible: {payload['error']}")
            log(attempt, text, "declared_impossible", error=str(payload["error"]))
            return Tier2Result(measure_name, None, False, attempt, trace)

        sql = str(payload["sql"]).strip().rstrip(";")
        if _FORBIDDEN.search(sql) or not sql.upper().startswith(("SELECT", "WITH")):
            trace.append(f"attempt {attempt}: rejected non-SELECT statement")
            log(attempt, text, "rejected_non_select", sql=sql)
            messages.append({"role": "assistant", "content": text})
            messages.append({"role": "user", "content": "Only a single SELECT is allowed."})
            continue

        try:
            cursor.execute(sql)
            row = cursor.fetchone()
            if row is None or len(row) != 1:
                raise ValueError(f"expected 1 scalar, got {row!r}")
            _check_value(row[0], expected)
            trace.append(f"attempt {attempt}: executed OK, result={row[0]}")
            log(attempt, text, "accepted", sql=sql, result_value=row[0])
            return Tier2Result(measure_name, sql, True, attempt, trace)
        except Exception as e:  # noqa: BLE001 - any execution/validation failure is retried
            trace.append(f"attempt {attempt}: execution failed: {str(e)[:200]}")
            log(attempt, text, "execution_failed", sql=sql, error=str(e)[:300])
            messages.append({"role": "assistant", "content": text})
            messages.append(
                {"role": "user", "content": f"That SQL failed: {str(e)[:300]}. Fix it."}
            )

    return Tier2Result(measure_name, None, False, _MAX_ATTEMPTS, trace)


# ----------------------------------------------------------------------------------------------
# Reference analysis (used by the pipeline's repair order and the rewrite gates)
# ----------------------------------------------------------------------------------------------

CONTEXT_FUNCS = frozenset(
    """SELECTEDVALUE ISFILTERED ISCROSSFILTERED HASONEVALUE HASONEFILTER ISINSCOPE ALLSELECTED VALUES
    FILTERS DATESBETWEEN DATESINPERIOD DATESYTD DATESMTD DATESQTD TOTALYTD TOTALMTD TOTALQTD DATEADD
    SAMEPERIODLASTYEAR PARALLELPERIOD PREVIOUSMONTH PREVIOUSYEAR PREVIOUSQUARTER STARTOFYEAR
    STARTOFMONTH ENDOFYEAR ENDOFMONTH FIRSTDATE LASTDATE USERPRINCIPALNAME""".split()
)


def _parse(expression: str):
    try:
        return parse_dax(expression)
    except DaxParseError:
        return None


def _walk(node):
    yield node
    match node:
        case BinOp(left=left, right=right):
            yield from _walk(left)
            yield from _walk(right)
        case UnaryOp(operand=o):
            yield from _walk(o)
        case FuncCall(args=args):
            for a in args:
                yield from _walk(a)
        case VarExpr(bindings=bindings, body=body):
            for _, a in bindings:
                yield from _walk(a)
            yield from _walk(body)


def measure_references(model: SemanticModel, name_or_expression: str) -> list[str]:
    """Measures referenced as [X] by a measure (by name) or by a DAX expression."""
    found = model.find_measure(name_or_expression)
    expr = model.effective_dax(found[1]) if found else name_or_expression
    ast = _parse(expr)
    refs: list[str] = []
    for n in _walk(ast) if ast is not None else ():
        if isinstance(n, MeasureRef):
            hit = model.find_measure(n.name)
            canonical = hit[1].name if hit else n.name
            if canonical not in refs:
                refs.append(canonical)
    return refs


def _string_literals(expr: str) -> set[str]:
    return {m.casefold() for m in re.findall(r'"((?:[^"]|"")*)"', expr)}


def undefined_measures(model: SemanticModel) -> dict[str, list[str]]:
    """{undefined name: [measures using it]}: [X] that is neither a measure, nor a column of any
    table, nor a string literal the expression itself names (case-insensitive)."""
    columns = {c.name.casefold() for t in model.tables for c in t.columns}
    out: dict[str, list[str]] = {}
    for t in model.tables:
        for m in t.measures:
            expr = model.effective_dax(m)
            literals = _string_literals(expr)
            ast = _parse(expr)
            if ast is None:
                continue
            for n in _walk(ast):
                if not isinstance(n, MeasureRef):
                    continue
                if model.find_measure(n.name) is not None:
                    continue
                low = n.name.casefold()
                if low in columns or low in literals:
                    continue
                users = out.setdefault(n.name, [])
                if m.name not in users:
                    users.append(m.name)
    return out


def _variable_names(ast) -> set[str]:
    return {name.casefold() for n in _walk(ast) if isinstance(n, VarExpr) for name, _ in n.bindings}


def reference_closure(model: SemanticModel, measure_name: str) -> dict[str, set]:
    """Tables and columns a measure reads through its whole measure closure."""
    found = model.find_measure(measure_name)
    names = [found[1].name if found else measure_name, *dependency_closure(model, measure_name)]
    tables: set[str] = set()
    columns: set[tuple[str, str]] = set()
    for name in names:
        hit = model.find_measure(name)
        ast = _parse(model.effective_dax(hit[1])) if hit else None
        if ast is None:
            continue
        variables = _variable_names(ast)
        for n in _walk(ast):
            if isinstance(n, ColumnRef):
                t = model.table(n.table)
                c = t.column(n.column) if t else None
                if t:
                    tables.add(t.name)
                    columns.add((t.name, c.name if c else n.column))
            elif isinstance(n, TableRef):
                t = model.table(n.name)
                if t:
                    tables.add(t.name)
            elif isinstance(n, VarRef) and n.name.casefold() not in variables:
                t = model.table(n.name)
                if t:
                    tables.add(t.name)
    return {"tables": tables, "columns": columns}


def context_functions(model: SemanticModel, measure_name: str) -> list[str]:
    """Filter-context functions used by a measure or anything it references."""
    found = model.find_measure(measure_name)
    names = [found[1].name if found else measure_name, *dependency_closure(model, measure_name)]
    used: set[str] = set()
    for name in names:
        hit = model.find_measure(name)
        ast = _parse(model.effective_dax(hit[1])) if hit else None
        for n in _walk(ast) if ast is not None else ():
            if isinstance(n, FuncCall) and n.name in CONTEXT_FUNCS:
                used.add(n.name)
    return sorted(used)


def _unknown_objects(model: SemanticModel, ast) -> list[str]:
    """Tables, columns and measures a DAX body names that the model does not define."""
    variables = _variable_names(ast)
    unknown: list[str] = []

    def add(text: str) -> None:
        if text not in unknown:
            unknown.append(text)

    for n in _walk(ast):
        if isinstance(n, ColumnRef):
            t = model.table(n.table)
            if t is None:
                add(f"table '{n.table}'")
            elif t.column(n.column) is None and t.column(n.column.strip()) is None:
                add(f"column {n.table}[{n.column}]")
        elif isinstance(n, TableRef):
            if model.table(n.name) is None:
                add(f"table '{n.name}'")
        elif isinstance(n, MeasureRef):
            if model.find_measure(n.name) is None:
                add(f"measure [{n.name}]")
        elif isinstance(n, VarRef) and n.name.casefold() not in variables:
            if model.table(n.name) is None and n.name.upper() not in ("ASC", "DESC"):
                add(f"identifier '{n.name}'")
    return unknown


# ----------------------------------------------------------------------------------------------
# AI DAX rewrite into the tier-1 subset
# ----------------------------------------------------------------------------------------------

_TIER1_SUBSET = """Tier-1 subset (everything else is NOT supported):
- Aggregates: SUM, AVERAGE, MIN, MAX, COUNT, COUNTA, DISTINCTCOUNT, DISTINCTCOUNTNOBLANK, COUNTROWS.
- Iterators SUMX/AVERAGEX/MINX/MAXX/COUNTX over a table, ALL(T), or FILTER(T | ALL(T), condition);
  RELATED() inside them; SUMX over ADDCOLUMNS(SUMMARIZE(T, keys), "n", CALCULATE(aggregate)) with [n].
- DIVIDE, IF, SWITCH, VAR/RETURN, IFERROR (only around expressions that cannot raise), ISBLANK, COALESCE,
  `x IN {a, b}`, BLANK() comparisons, text/date/math scalar functions (EDATE, EOMONTH, INT, ROUND, ...).
- CALCULATE filters: T[c] = v and other comparisons, IN, NOT, KEEPFILTERS, FILTER(T | ALL(T) | VALUES(T[c]) |
  DISTINCT(T[c]), condition), ALL, ALL(T[c]), REMOVEFILTERS, ALLEXCEPT, TREATAS({literals}, T[c]), USERELATIONSHIP.
- Time intelligence: SAMEPERIODLASTYEAR, DATEADD(-1 year / -12 months), DATESINPERIOD, TOTALYTD, and
  CALCULATE(m, ALL(D), DATESBETWEEN(D[c], start, end)) whose bounds use MIN/MAX/SELECTEDVALUE/STARTOFYEAR/EDATE.
- SELECTEDVALUE, HASONEVALUE, ISFILTERED, FIRSTNONBLANK/LASTNONBLANK(T[c], constant).
- Only these table shapes: SUMMARIZE -> GROUPBY(..., SUMX(CURRENTGROUP(), x)) counted with DISTINCTCOUNT / COUNTROWS over
  FILTER(grouped VAR, condition); TOPN(n, ADDCOLUMNS(SUMMARIZE(T, D[key]), "x", CALCULATE(agg)), [x], ASC|DESC) as a
  CALCULATE filter on a card.
NOT supported: other uses of TOPN/GROUPBY/CURRENTGROUP, RANKX, CALCULATETABLE with filters outside those shapes,
CONCATENATEX, GENERATE, PATH functions, and `/` inside IFERROR."""

_REWRITE_SYSTEM = (
    "You rewrite one Power BI DAX measure into an equivalent DAX measure that uses only the tier-1 subset "  # noqa: E501
    "below, so a deterministic compiler can translate it to SQL that follows slicers, filters and the "  # noqa: E501
    "visual's rows exactly as Power BI does.\n"
    "Rules:\n"
    '- Output ONLY {"dax": "<body>"} (the measure body, without the name).\n'
    "- The rewrite must return the same value in EVERY filter context, not just for one example.\n"
    "- Use only the tables, columns and measures listed below, with their exact names.\n"
    "- You may inline referenced measures or reference them.\n"
    "- Keep every filter, table and column the original uses.\n"
    '- If no exact rewrite exists return {"error": "reason"}.\n\n' + _TIER1_SUBSET
)


@dataclass
class RewriteResult:
    measure: str
    expression: str | None
    accepted: bool
    attempts: int
    trace: list[str] = field(default_factory=list)
    gates: list[str] = field(default_factory=list)


def _rewrite_context(model: SemanticModel, measure: Measure, table: str, error: str) -> str:
    closure = dependency_closure(model, measure.name)
    refs = reference_closure(model, measure.name)
    relevant = set(refs["tables"])
    for rel in model.relationships:
        if rel.from_table in refs["tables"]:
            relevant.add(rel.to_table)
        elif rel.to_table in refs["tables"]:
            relevant.add(rel.from_table)
    lines = [
        f"Measure [{measure.name}] in table '{table}':",
        model.effective_dax(measure),
        "",
        f"Tier-1 compiler error for it: {error}",
    ]
    if closure:
        lines += ["", "Referenced measures (DAX):"]
        budget = _CONTEXT_BUDGET_CHARS
        for name in closure:
            hit = model.find_measure(name)
            entry = f"- [{name}] = {model.effective_dax(hit[1])}" if hit else f"- [{name}]"
            if len(entry) > budget:
                entry = f"- [{name}]: definition omitted (context size limit)"
            budget -= len(entry)
            lines.append(entry)
    lines += ["", "Tables (exact names and columns):"]
    for t in model.tables:
        if t.name in relevant:
            cols = ", ".join(c.name for c in t.columns)
            lines.append(f"- '{t.name}': {cols}")
    rels = [r for r in model.relationships if r.from_table in relevant and r.to_table in relevant]
    if rels:
        lines += ["", "Relationships (many side -> one side; filters flow one -> many):"]
        for r in rels:
            flags = ("" if r.is_active else " [inactive]") + (
                " both directions" if r.cross_filtering_behavior == "bothDirections" else ""
            )
            lines.append(f"- {r.from_table}[{r.from_column}] -> {r.to_table}[{r.to_column}]{flags}")
    return "\n".join(lines)


def propose_dax_rewrite(
    model: SemanticModel,
    measure: Measure,
    tier1_error: str,
    execute_gate: Callable[[SemanticModel], int],
    client,
    log_path: Path | None = None,
) -> RewriteResult:
    """Ask the LLM for an equivalent tier-1 DAX body; accept only what passes every gate."""
    found = model.find_measure(measure.name)
    table = found[0].name if found else ""
    original = model.effective_dax(measure)
    original_refs = reference_closure(model, measure.name)
    messages = [
        {"role": "system", "content": _REWRITE_SYSTEM},
        {"role": "user", "content": _rewrite_context(model, measure, table, tier1_error)},
    ]
    trace: list[str] = []

    def log(attempt: int, text: str, outcome: str, dax: str | None = None, error: str | None = None):  # noqa: E501
        _log_attempt(
            log_path, measure=measure.name, attempt=attempt, expected_kind="dax_rewrite",
            messages=messages, response=text, outcome=outcome, sql=dax, error=error,
        )  # fmt: skip

    def retry(text: str, message: str) -> None:
        messages.append({"role": "assistant", "content": text})
        messages.append({"role": "user", "content": message})

    for attempt in range(1, _MAX_ATTEMPTS + 1):
        text = client.chat(messages) or ""
        payload = _extract_json(text)
        if payload is None or ("dax" not in payload and "error" not in payload):
            trace.append(f"attempt {attempt}: unparseable response")
            log(attempt, text, "unparseable")
            retry(text, 'Respond with only {"dax": "..."} JSON.')
            continue
        if "error" in payload:
            trace.append(f"attempt {attempt}: model declared impossible: {payload['error']}")
            log(attempt, text, "declared_impossible", error=str(payload["error"]))
            return RewriteResult(measure.name, None, False, attempt, trace)
        dax = str(payload["dax"]).strip()

        ast = _parse(dax)
        if ast is None:
            trace.append(f"attempt {attempt}: does not parse")
            log(attempt, text, "does_not_parse", dax=dax)
            retry(text, "That DAX does not parse. Fix the syntax and answer with only the JSON.")
            continue
        unknown = _unknown_objects(model, ast)
        if unknown:
            trace.append(f"attempt {attempt}: unknown objects: {', '.join(unknown)}")
            log(attempt, text, "unknown_objects", dax=dax, error=", ".join(unknown))
            retry(text, f"It uses objects that do not exist: {', '.join(unknown)}. Use only listed names.")  # noqa: E501
            continue

        candidate = copy.deepcopy(model)
        candidate.dax_rewrites[measure.name] = DaxRewrite(expression=dax, original=original)
        new_refs = _body_references(candidate, dax)
        missing_tables = sorted(original_refs["tables"] - new_refs["tables"])
        missing_columns = sorted(original_refs["columns"] - new_refs["columns"])
        if missing_tables or missing_columns:
            dropped = [f"table '{t}'" for t in missing_tables] + [
                f"column {t}[{c}]" for t, c in missing_columns
            ]
            trace.append(f"attempt {attempt}: dropped {', '.join(dropped)}")
            log(attempt, text, "dropped_objects", dax=dax, error=", ".join(dropped))
            retry(text, f"The original reads {', '.join(dropped)} but the rewrite does not. Keep them.")  # noqa: E501
            continue
        try:
            MeasureCompiler(candidate).compile_measure(measure.name)
        except DaxUnsupported as e:
            trace.append(f"attempt {attempt}: tier-1 compiler rejected it: {str(e)[:200]}")
            log(attempt, text, "tier1_rejected", dax=dax, error=str(e)[:300])
            retry(text, f"The tier-1 compiler rejects that: {str(e)[:300]}. Use only the tier-1 subset.")  # noqa: E501
            continue
        try:
            executed = execute_gate(candidate)
        except Exception as e:  # noqa: BLE001 - connector/planner errors both retry
            trace.append(f"attempt {attempt}: execution gate failed: {str(e)[:200]}")
            log(attempt, text, "gate_failed", dax=dax, error=str(e)[:300])
            retry(text, f"Running it against the data failed: {str(e)[:300]}. Fix it.")
            continue
        n_cols = len(original_refs["columns"])
        n_tables = len(original_refs["tables"])
        gates = [
            "parses; references only model objects",
            f"keeps all {n_cols} columns / {n_tables} tables the original reads",
            "compiles in tier-1 (follows slicers and visual rows)",
            f"executed for {executed} visual and totals queries",
        ]
        trace.append(f"attempt {attempt}: accepted")
        log(attempt, text, "accepted", dax=dax)
        return RewriteResult(measure.name, dax, True, attempt, trace, gates)
    return RewriteResult(measure.name, None, False, _MAX_ATTEMPTS, trace)


def _body_references(candidate: SemanticModel, dax: str) -> dict[str, set]:
    """Tables/columns a DAX body reads directly and through the measures it references."""
    tables: set[str] = set()
    columns: set[tuple[str, str]] = set()
    ast = _parse(dax)
    if ast is None:
        return {"tables": tables, "columns": columns}
    variables = _variable_names(ast)
    pending = [ast]
    seen_measures: set[str] = set()
    while pending:
        node = pending.pop()
        for n in _walk(node):
            if isinstance(n, ColumnRef):
                t = candidate.table(n.table)
                c = t.column(n.column) if t else None
                if t:
                    tables.add(t.name)
                    columns.add((t.name, c.name if c else n.column))
            elif isinstance(n, TableRef):
                t = candidate.table(n.name)
                if t:
                    tables.add(t.name)
            elif isinstance(n, VarRef) and n.name.casefold() not in variables:
                t = candidate.table(n.name)
                if t:
                    tables.add(t.name)
            elif isinstance(n, MeasureRef):
                hit = candidate.find_measure(n.name)
                if hit and hit[1].name not in seen_measures:
                    seen_measures.add(hit[1].name)
                    sub = _parse(candidate.effective_dax(hit[1]))
                    if sub is not None:
                        pending.append(sub)
    return {"tables": tables, "columns": columns}


def rewrite_gate(
    bundle, candidate_model: SemanticModel, binding_map, measure: str, cursor, tier2_sql: dict
) -> int:
    """Run the candidate through the production path: every visual (max 12) projecting the
    measure is compiled with `compile_visual`; its query and totals query execute on Snowflake.
    Raises on the first failure; returns the number of visuals checked."""
    from app.runtime.dashboard import compile_visual
    from app.runtime.engine import MeasureRefSpec, QuerySpec, SemanticEngine
    from app.services.query_audit import audit_stage

    candidate_bundle = bundle.model_copy(update={"model": candidate_model})
    compiler = MeasureCompiler(candidate_model)
    engine = SemanticEngine(candidate_model, binding_map, tier2_sql=tier2_sql)
    queued: list[tuple[str, QuerySpec]] = []
    visuals = 0
    for page in bundle.report.pages:
        for visual in page.visuals:
            if visuals >= 12:
                break
            if not any(f.is_measure and f.name and f.name.casefold() == measure.casefold() for f in visual.fields):  # noqa: E501
                continue
            vs = compile_visual(visual, candidate_bundle, compiler, [], tier2_sql)
            if vs.query is None:
                continue
            visuals += 1
            queued.append((f"visual:{page.name}/{visual.name}:main", vs.query))
            if vs.query.dimensions:
                totals = vs.query.model_copy(update={"dimensions": [], "sort": []})
                queued.append((f"visual:{page.name}/{visual.name}:totals", totals))
    if not queued:
        queued.append((f"ai_rewrite_gate:{measure}", QuerySpec(measures=[MeasureRefSpec(name=measure)])))  # noqa: E501
    with audit_stage(cursor, "ai_check", f"ai_rewrite_gate:{measure}"):
        for context, query in queued:
            sql, _warnings = engine.build_sql(query, sql_context=context)
            cursor.execute(sql)
            cursor.fetchall()
    return visuals or 1
