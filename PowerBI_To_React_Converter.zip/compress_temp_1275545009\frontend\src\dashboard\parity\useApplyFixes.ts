import { useQueryClient } from '@tanstack/react-query'
import { useState } from 'react'
import { parityApi } from '../../api/client'

/** Apply auto-fixes for one page's findings and refresh every cache that depends on the spec.
 *  Resolves with the number of fixes that were applied (0 on error). */
export function useApplyFixes(conversionId: string, pageName: string | undefined) {
  const qc = useQueryClient()
  const [applying, setApplying] = useState<string | null>(null) // finding id or '*'
  const [error, setError] = useState('')

  const applyFixes = async (findingIds: string[]): Promise<number> => {
    if (!pageName) return 0
    setApplying(findingIds.length === 1 ? findingIds[0] : '*')
    setError('')
    let applied = 0
    try {
      const body = await parityApi.applyFixes(conversionId, pageName, findingIds)
      applied = (body.applied ?? []).length
      if (body.skipped?.length) {
        setError('Not applied: ' + body.skipped.map((s) => `${s.id} (${s.reason})`).join('; '))
      }
      // spec changed: refresh comparisons, spec, and every render cache
      // (awaiting invalidation guarantees the offscreen canvas sees the new spec)
      await Promise.all([
        qc.invalidateQueries({ queryKey: ['visual-compare', conversionId] }),
        qc.invalidateQueries({ queryKey: ['dash-spec', conversionId] }),
        qc.invalidateQueries({ queryKey: ['parity-data', conversionId] }),
        qc.invalidateQueries({ queryKey: ['dash-data', conversionId] }),
      ])
    } catch (e) {
      setError((e as Error).message)
      applied = 0
    } finally {
      setApplying(null)
    }
    return applied
  }

  return { applying, error, applyFixes }
}
