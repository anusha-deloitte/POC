import { Check, Filter, Loader2, Wrench } from 'lucide-react'
import { parityApi, type ParitySide } from '../../api/client'
import type {
  ParityComparison,
  ParityFinding,
  ParityNumber,
  ParityValues,
  ParityVisualCheck,
  ParityVisualStatus,
} from '../../api/types'
import { fmtTime } from '../../components/fmtTime'

export { useApplyFixes } from './useApplyFixes'

const SEV_BADGE: Record<ParityFinding['severity'], string> = {
  high: 'badge-red',
  medium: 'badge-amber',
  low: 'badge-blue',
}

const STATUS_BADGE: Record<ParityVisualStatus, { cls: string; label: string }> = {
  match: { cls: 'badge-green', label: 'match' },
  mismatch: { cls: 'badge-red', label: 'mismatch' },
  not_found: { cls: 'badge-amber', label: 'not found' },
  not_checked: { cls: 'badge-blue', label: 'not checked' },
}

export function SimilarityBadge({ value }: { value: number | null | undefined }) {
  if (value === null || value === undefined) return <span className="badge-blue">numbers only</span>
  const cls = value >= 90 ? 'badge-green' : value >= 70 ? 'badge-amber' : 'badge-red'
  return <span className={cls}>{value}% similar</span>
}

export function VisualStatusBadge({ status }: { status: ParityVisualStatus }) {
  const s = STATUS_BADGE[status] ?? STATUS_BADGE.not_checked
  return <span className={s.cls}>{s.label}</span>
}

/** Number check: numbers printed in the reference PDF vs the converted query results. */
export function NumbersPanel({ values }: { values: ParityValues }) {
  const s = values.summary
  type Row = { v: ParityVisualCheck; n: ParityNumber | null; key: string }
  const rows = values.visuals.flatMap((v): Row[] =>
    v.numbers.length
      ? v.numbers.map((n, i) => ({ v, n, key: `${v.visual}-${i}` }))
      : [{ v, n: null, key: `${v.visual}-none` }],
  )
  return (
    <section data-testid="numbers-panel" className="mt-4">
      <div className="mb-2 flex flex-wrap items-center gap-2">
        <h4 className="text-xs font-bold">Numbers</h4>
        <span className="badge-blue">
          {s.numbers_matched} of {s.numbers_printed} printed numbers matched
        </span>
        {s.match > 0 && <span className="badge-green">{s.match} visuals match</span>}
        {s.mismatch > 0 && <span className="badge-red">{s.mismatch} visuals mismatch</span>}
        {s.not_found > 0 && <span className="badge-amber">{s.not_found} not found</span>}
        {s.not_checked > 0 && <span className="badge-blue">{s.not_checked} not checked</span>}
        {values.stale && <span className="badge-red">stale</span>}
        <span className="text-[11px] text-surface-500">{fmtTime(values.checked_at)}</span>
      </div>
      <div className="max-h-72 overflow-auto rounded-lg border border-surface-300">
        <table className="w-full text-left text-xs">
          <thead className="sticky top-0 bg-surface-100">
            <tr className="text-[10px] tracking-wide text-surface-500 uppercase">
              <th className="px-3 py-1.5">Visual</th>
              <th className="px-3 py-1.5">Printed</th>
              <th className="px-3 py-1.5">Status</th>
              <th className="px-3 py-1.5">Nearest value</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(({ v, n, key }) => (
              <tr key={key} className="border-t border-surface-200 align-top">
                <td className="px-3 py-1.5 font-semibold">
                  {v.title || v.visual}
                  {v.type && <span className="ml-1 font-normal text-surface-500">{v.type}</span>}
                  {v.error && <div className="font-normal text-brand-red">{v.error}</div>}
                </td>
                <td className="px-3 py-1.5 tabular-nums">{n ? n.text : '—'}</td>
                <td className="px-3 py-1.5">
                  {n ? (
                    <span className={n.matched ? 'badge-green' : 'badge-red'}>
                      {n.matched ? 'matched' : 'no match'}
                    </span>
                  ) : (
                    <VisualStatusBadge status={v.status} />
                  )}
                </td>
                <td className="px-3 py-1.5 text-surface-600 tabular-nums">
                  {n && !n.matched && n.nearest !== undefined && n.nearest !== null
                    ? String(n.nearest)
                    : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}

export interface ComparisonDetailProps {
  conversionId: string
  /** image comparison (null/undefined when only a number check exists) */
  comparison?: ParityComparison | null
  values?: ParityValues | null
  /** override where the two images come from (older history runs) */
  imageUrl?: (side: ParitySide) => string
  /** older runs: no fixes, no re-run hints */
  readOnly?: boolean
  applying?: string | null
  onApplyFixes?: (findingIds: string[]) => void
}

/** Images, banners, findings and the numbers table of one page comparison. */
export function ComparisonDetail({
  conversionId,
  comparison,
  values,
  imageUrl,
  readOnly = false,
  applying = null,
  onApplyFixes,
}: ComparisonDetailProps) {
  const result = comparison ?? null
  const canFix = !readOnly && !!onApplyFixes && !result?.stale
  const fixableUnapplied = canFix
    ? (result?.findings ?? []).filter((f) => f.fixable && !f.fix_applied)
    : []
  const src = (side: ParitySide) =>
    imageUrl
      ? imageUrl(side)
      : parityApi.imageUrl(conversionId, result!.page, side, result!.compared_at)
  const filters = result?.filters_applied ?? values?.filters_applied ?? []

  return (
    <div data-testid="comparison-detail">
      {readOnly && (
        <div
          data-testid="readonly-banner"
          className="mb-3 rounded-lg border border-surface-300 bg-surface-100 px-3 py-2 text-xs text-surface-700"
        >
          <strong>Older run (read-only).</strong> Fixes can only be applied to the latest comparison.
        </div>
      )}

      {result && (
        <>
          <div className="mb-3 flex flex-wrap items-center gap-3">
            <SimilarityBadge value={result.similarity} />
            <span className="text-xs text-surface-500">
              {result.findings.length} finding{result.findings.length === 1 ? '' : 's'} ·{' '}
              {new Date(result.compared_at * 1000).toLocaleString()}
            </span>
            {filters.length > 0 && (
              <span className="badge-blue flex items-center gap-1">
                <Filter size={10} strokeWidth={2} />
                matched filters: {filters.map((f) => `${f.slicer}=${f.value}`).join(', ')}
              </span>
            )}
          </div>

          <div className="mb-4 grid grid-cols-2 gap-3">
            {(['reference', 'rendered'] as const).map((side) => (
              <figure key={side} className="overflow-hidden rounded-lg border border-surface-300">
                <figcaption className="bg-surface-100 px-2 py-1 text-[10px] font-semibold tracking-wide text-surface-600 uppercase">
                  {side === 'reference' ? 'Power BI original' : 'React conversion'}
                </figcaption>
                <img src={src(side)} alt={side} className="w-full" />
              </figure>
            ))}
          </div>

          {result.stale && (
            <div
              data-testid="stale-banner"
              className="mb-3 rounded-lg border border-brand-red/40 bg-brand-red/5 px-3 py-2 text-xs text-surface-700"
            >
              <strong>Comparison out of date:</strong>{' '}
              {result.stale_reason ?? 'the reference image changed after this comparison ran'}. These
              findings compare against a superseded reference — re-run “Compare this page”. Fixes are
              disabled until then.
            </div>
          )}
          {!result.stale && result.reference_suspect && (
            <div
              data-testid="reference-suspect-banner"
              className="mb-3 rounded-lg border border-brand-amber/40 bg-brand-amber/5 px-3 py-2 text-xs text-surface-700"
            >
              <strong>Data verified — review differences with care:</strong> most findings below are
              on visuals whose numbers the deterministic validation already proved against the live
              warehouse. If values differ, the PDF export is stale or was taken under different
              filters (re-export and re-compare); axis/format drift is presentational and safe to fix
              via overrides.
            </div>
          )}

          {result.findings.length === 0 ? (
            <p className="text-sm text-surface-600">No meaningful differences found.</p>
          ) : (
            <>
              {/* results saved before the remediation engine existed have no ids/fix payloads */}
              {!readOnly && result.findings.some((f) => !f.id) && (
                <div className="mb-3 rounded-lg border border-brand-amber/30 bg-brand-amber/5 px-3 py-2 text-xs text-surface-700">
                  This comparison predates the remediation engine — re-run “Compare this page” to get
                  actionable fixes for these findings.
                </div>
              )}
              {fixableUnapplied.length > 0 && (
                <div className="mb-3 flex items-center justify-between rounded-lg border border-brand/25 bg-brand/5 px-3 py-2">
                  <span className="text-xs text-surface-700">
                    <strong>{fixableUnapplied.length}</strong> of {result.findings.length} finding
                    {result.findings.length === 1 ? '' : 's'} can be fixed automatically
                  </span>
                  <button
                    className="btn-primary flex items-center gap-1.5 !px-3 !py-1.5 !text-xs"
                    disabled={applying !== null}
                    onClick={() => onApplyFixes!(fixableUnapplied.map((f) => f.id))}
                  >
                    {applying === '*' ? (
                      <Loader2 size={13} className="animate-spin" />
                    ) : (
                      <Wrench size={13} strokeWidth={1.8} />
                    )}
                    Apply all fixes
                  </button>
                </div>
              )}
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-surface-300 text-[10px] tracking-wide text-surface-500 uppercase">
                    <th className="py-1.5 pr-3">Visual / region</th>
                    <th className="py-1.5 pr-3">Severity</th>
                    <th className="py-1.5 pr-3">Kind</th>
                    <th className="py-1.5 pr-3">Difference</th>
                    <th className="py-1.5 pr-3">Recommendation</th>
                    {!readOnly && <th className="py-1.5">Action</th>}
                  </tr>
                </thead>
                <tbody>
                  {result.findings.map((f, idx) => (
                    <tr key={f.id || idx} className="border-b border-surface-200 align-top">
                      <td className="py-2 pr-3 font-semibold">{f.region}</td>
                      <td className="py-2 pr-3">
                        <span className={SEV_BADGE[f.severity]}>{f.severity}</span>
                      </td>
                      <td className="py-2 pr-3 text-surface-600">{f.kind}</td>
                      <td className="py-2 pr-3">
                        {f.difference}
                        {f.contradicts_harness && (
                          <span className="badge-blue mt-1 block w-fit" title={f.harness_note}>
                            data proven correct — not a conversion error
                          </span>
                        )}
                      </td>
                      <td className="py-2 pr-3 text-surface-600">{f.recommendation}</td>
                      {!readOnly && (
                        <td className="py-2">
                          {f.fix_applied ? (
                            <span className="badge-green flex w-fit items-center gap-1">
                              <Check size={11} strokeWidth={2.5} /> Applied
                            </span>
                          ) : f.fixable && canFix ? (
                            <button
                              className="flex items-center gap-1 rounded-lg border border-brand px-2 py-1 text-[11px] font-semibold text-brand-dark hover:bg-brand/10 disabled:opacity-50"
                              disabled={applying !== null}
                              title={`Applies: ${f.fix?.op} on ${f.fix?.visual}`}
                              onClick={() => onApplyFixes!([f.id])}
                            >
                              {applying === f.id ? (
                                <Loader2 size={12} className="animate-spin" />
                              ) : (
                                <Wrench size={12} strokeWidth={1.8} />
                              )}
                              Apply fix
                            </button>
                          ) : (
                            <button
                              className="flex cursor-not-allowed items-center gap-1 rounded-lg border border-surface-300 px-2 py-1 text-[11px] font-semibold text-surface-400"
                              disabled
                              title={
                                f.fix_rejected
                                  ? `Proposed fix rejected: ${f.fix_rejected}`
                                  : 'Not automatable — needs human review (data/color/missing-visual differences)'
                              }
                            >
                              <Wrench size={12} strokeWidth={1.8} />
                              Apply fix
                            </button>
                          )}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
              {!readOnly && result.findings.some((f) => f.fix_applied) && (
                <p className="mt-2 text-[11px] text-surface-500">
                  Applied fixes are saved as spec overrides; the page re-renders and re-compares
                  automatically so the result reflects the corrected visual.
                </p>
              )}
            </>
          )}
        </>
      )}

      {values && <NumbersPanel values={values} />}
    </div>
  )
}
