import type { ParityComparison, ParityValues } from '../api/types'

export const comparison: ParityComparison = {
  page: 'p1',
  display_name: 'Overview',
  similarity: 82,
  compared_at: 1_700_000_000,
  filters_applied: [{ slicer: 'Year', value: 2024 }],
  findings: [
    {
      id: 'f1',
      region: 'Revenue chart',
      severity: 'high',
      kind: 'axis',
      difference: 'Axis starts at 0',
      recommendation: 'Set min to 100',
      fixable: true,
      fix_applied: false,
      fix: { op: 'axis_min', visual: 'v1' },
    },
    {
      id: 'f2',
      region: 'Map',
      severity: 'low',
      kind: 'color',
      difference: 'Different palette',
      recommendation: 'Review',
      fixable: false,
      fix_applied: false,
      fix_rejected: 'unsafe',
    },
    {
      id: 'f3',
      region: 'Card',
      severity: 'medium',
      kind: 'format',
      difference: 'Decimals',
      recommendation: 'Set 2 decimals',
      fixable: true,
      fix_applied: true,
    },
  ],
}

export const values: ParityValues = {
  page: 'p1',
  display_name: 'Overview',
  checked_at: 1_700_000_100,
  summary: { match: 1, mismatch: 1, not_found: 0, not_checked: 0, numbers_printed: 3, numbers_matched: 2 },
  visuals: [
    {
      visual: 'v1',
      title: 'Revenue',
      type: 'card',
      status: 'match',
      numbers: [
        { text: '$1.2M', value: 1200000, matched: true },
        { text: '45%', value: 45, matched: true },
      ],
    },
    {
      visual: 'v2',
      title: 'Orders',
      type: 'card',
      status: 'mismatch',
      numbers: [{ text: '9,999', value: 9999, matched: false, nearest: 10020 }],
    },
  ],
}
