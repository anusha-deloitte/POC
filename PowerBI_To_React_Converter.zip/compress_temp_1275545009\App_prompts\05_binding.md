# Phase 05 - Binding: identifier quoting, Snowflake target override, case check, pre-flight, source hints

## Purpose
Generate SQL that Snowflake accepts for any object name, let the user point the report at another
database/schema, fix names that differ only in letter case, and detect an unreachable target in
seconds before a long conversion.

## Current target state
`binding/resolver.py`: `safe_ident` whitelists `[A-Za-z0-9_$. -]` and rejects `"`; `qualified_name`
quotes every part; `build_binding_map(model)` only; `mark_unresolved_against_live` compares
upper-cased names. No overrides, no case check, no pre-flight, no source hints.

## Required behaviour

### 1. Identifiers (`binding/resolver.py`) - the only way SQL identifiers are built
1.1 `describe_ident(name) -> «name»` (for messages).
1.2 `safe_ident(name, origin="identifier")`: body of a double-quoted identifier with `"` doubled; reject only
empty names and control characters (`[\x00-\x1f\x7f]`) with
`ValueError("invalid SQL identifier «x» from <origin>: empty or contains control characters")`.
1.3 `quote_ident(name, origin) -> '"' + safe_ident(...) + '"'` (`Sales (2024)` -> `"Sales (2024)"`, `a"b` -> `"a""b"`).
1.4 `sql_name(name, origin)`: plain UPPERCASE names matching `[A-Z_][A-Z0-9_$]*` that are not Snowflake reserved
words are emitted unquoted (same object as the quoted form); everything else is `quote_ident`. Reserved list:
ACCOUNT ALL ALTER AND ANY AS BETWEEN BY CASE CAST CHECK COLUMN CONNECT CONNECTION CONSTRAINT CREATE CROSS CURRENT
CURRENT_DATE CURRENT_TIME CURRENT_TIMESTAMP CURRENT_USER DATABASE DELETE DISTINCT DROP ELSE EXISTS FALSE FOLLOWING
FOR FROM FULL GRANT GROUP GSCLUSTER HAVING ILIKE IN INCREMENT INNER INSERT INTERSECT INTO IS ISSUE JOIN LATERAL LEFT
LIKE LOCALTIME LOCALTIMESTAMP MINUS NATURAL NOT NULL OF ON OR ORDER ORGANIZATION QUALIFY REGEXP REVOKE RIGHT RLIKE ROW
ROWS SAMPLE SCHEMA SELECT SET SOME START TABLE TABLESAMPLE THEN TO TRIGGER TRUE TRY_CAST UNION UNIQUE UPDATE USING
VALUES VIEW WHEN WHENEVER WHERE WITH.
1.5 `sql_string(value)` -> `'...'` with `'` doubled.
1.6 `TableBinding.qualified_name` joins database/schema/object with `sql_name(part, "the <database|schema|object>
name bound to table «T»")`.
1.7 Replace every hand-written `f'"{name}"'` in the backend with `quote_ident`/`sql_name`. M literals use `""`
(phase 04), DAX quoted table names use `''`.
1.8 `TableBinding` gains `computed_columns` (phase 04) and `column_case: dict[str,str]` (model physical column ->
Snowflake's exact-case name).

### 2. Snowflake target override and persisted settings
2.1 `apply_binding_settings(binding_map, settings)`: for every binding that is not virtual, not a native query, has an
object name and status `resolved|materialization_required`: replace database with `database_override` and schema with
`schema_override` when set; then apply `case_fixes[table]` via `apply_case_fix`.
2.2 `apply_case_fix(b, fix)`: change database/schema/object only when the current name equals the fix ignoring case
(so a later override to another database never inherits a stale correction); `column_case` = fix columns where
`src != exact` and they are equal ignoring case.
2.3 `build_bundle_binding_map(bundle) = apply_binding_settings(build_binding_map(bundle.model), bundle.binding_settings)`.
Every compile path (pipeline, `compile_dashboard`, export, deploy, dashboard queries) must use it; grep for
`build_binding_map(` and switch callers that have a bundle.
2.4 Engine (`runtime/engine.py::_physical`): every physical column reference goes through `column_case`
(WHERE clauses and computed expressions re-quoted with the exact names; a case-corrected source column is projected
`"EXACT" AS "<model name>"`, EXCLUDE-ing the physical name when it isn't also a model column).
2.5 `mark_unresolved_against_live` (existing): compare exact names; a name that exists only with different case gets
detail "letter case differs from Snowflake: bound as S.T, Snowflake has S2.T2 (quoted names are case-sensitive)".
2.6 DuckDB test helper (`runtime/accelerate.py::to_duckdb_sql`): replace both the `qualified_name` spelling and the
fully quoted spelling of each binding, longest first, only at name boundaries
(`(?<![\w$".])<name>(?![\w$"])`), so `DB.S.T` never matches inside `DB.S.T2`.

### 3. Case check (`binding/case_check.py`)
3.1 Statuses: `exact` (as written), `corrected` (exactly one case-insensitive match -> use Snowflake's spelling),
`ambiguous` (several names differ only by case; reported, not changed), `missing` (reported).
`match_case(name, candidates) -> (status, exact, candidates)`.
3.2 `CaseItem {kind: database|schema|table|column, model_table, name, status, exact, candidates}` with
`describe()`: corrected -> `table «x» (table «T») -> «X»`; ambiguous -> `...: several Snowflake names differ only by
case: «a», «A»`; missing -> `...: not found`.
3.3 `check_identifier_case(binding_map, model, cursor)` over bound, non-virtual, non-native bindings with database,
schema and object:
- databases: `show databases like '<db>'` (name column located via `cursor.description`, default index 1);
- schemas: `select schema_name from <db>.INFORMATION_SCHEMA.SCHEMATA where upper(schema_name) = upper('<s>')`;
- tables: `select table_name from <db>.INFORMATION_SCHEMA.TABLES where table_schema = '<exact schema>'`;
- columns: one query per table (`... COLUMNS where table_schema = ... and table_name = ...`; a schema-wide result is
  large enough to be fetched from Snowflake's result stage, which corporate networks may block), for
  `physical_columns(model, b)` = non-calculated model source columns minus names produced by M renames/added columns,
  plus rename sources, plus quoted names inside the M WHERE clause and computed expressions.
- every query error is recorded in `errors` (and `column_errors` for column failures) and checking continues.
- `fixes[table] = TableCaseFix(...)` only for names that differ.
3.4 `CaseCheckReport.summary() -> {checked, exact, corrected[], ambiguous[], missing[], errors[]}`;
`case_summary_message(report)` -> "identifier case: E/C names match Snowflake exactly[, N corrected to Snowflake's
spelling][, N ambiguous (not changed)][, N not found]".
3.5 `correct_bundle_case(bundle, cursor) -> (report, changed)`: check the names as model + overrides spell them
(case_fixes cleared for the check); if there are errors and no items, return `(report, False)` (catalog unreadable:
keep saved fixes); else keep previously saved column fixes for tables whose column query failed, set
`binding_settings.case_fixes` and `case_checked_at = time.time()`, return `True` (caller persists the bundle).
3.6 Where it runs (implemented in phases 07/08 call sites, listed here for completeness): on the pipeline's validation
cursor (audited as `setup`/`identifier_case_check`), in Analyze "Check access" (`POST /dashboard/preflight`, saved),
and once on the first live dashboard `/query` of a conversion whose `case_checked_at` is None (`_ensure_case_checked`
with a module lock and an in-memory set of checked conversions; failures are logged, never block the dashboard; on a
change the bundle is saved and the query result cache is cleared). The dashboard spec cache must be keyed on a
model+report content hash so saving case fixes never forces a recompile; bindings are rebuilt per request.

### 4. Pre-flight (`binding/preflight.py`)
4.1 `PreflightTarget {database, schema_name, tables[], found[], case_mismatch[], error, listed}`;
`unreachable = error or (listed > 0 and tables and not found)`.
4.2 `PreflightReport {role, warehouse, session_error, targets}`; `bound`, `accessible`, `blocking` (targets exist and
all unreachable); `message()`: blocking -> "no bound Snowflake object is reachable with role R / warehouse W (<db.s>:
<error or 'none of the N bound tables exists with this exact spelling (M differ only in letter case)'>; ...). Pick a role
with access or set a database/schema override, then convert again"; else "A/B bound tables reachable with role R /
warehouse W". `summary()` = model dump + bound/accessible/blocking.
4.3 `run_preflight(binding_map, cursor)`: `select current_role(), current_warehouse()` (errors -> `session_error`);
group bindings (same filter as 3.3) by (database, schema); per group
`select table_schema, table_name from <db>.INFORMATION_SCHEMA.TABLES where upper(table_schema) = upper('<schema>')`;
exact matches -> found; case-only matches -> `case_mismatch` "S.T (Snowflake: S2.T2)"; errors -> last line of the
message (max 300). Never raises.
4.4 `POST /api/v1/conversions/{id}/dashboard/preflight {connection_id, database_override?, schema_override?}`:
apply the requested overrides to a copy of the bundle; on an audited connection (kind `setup`) run the case check
(context `identifier_case_check`) then the pre-flight (`access_preflight`); persist only case fixes/time when changed
(the overrides themselves are saved by Convert); clear the result cache; return
`{...summary, message, case: case.summary(), case_saved}`.

### 5. Convert persists the target
`ConvertRequest.database_override / schema_override` (optional). Only when either field is explicitly sent
(`model_fields_set`), store them (cleaned: blank -> None) in `bundle.binding_settings` (keeping case fixes) and save the
bundle before running. The pipeline emits "Snowflake target overridden: database=X|(from model), schema=Y|(from model)".

### 6. Source hints
6.1 `source_hints(model) -> {server, warehouse, database, schema}`: the most common values across M partitions
(`snowflake_source_args` + parsed Snowflake database/schema); used only to pre-fill forms.
6.2 `GET /api/v1/conversions/{id}/source-hints` -> hints + `binding_settings` (model dump). 404 for unknown ids.

### 7. Frontend
7.1 `store/wizard.ts`: `bindingTarget: {database, schema} | null` (null = not chosen this session),
`setBindingTarget`; reset to null whenever a conversion is opened/started.
7.2 Analyze step `SnowflakeTargetCard` (`data-testid="snowflake-target"`): "Snowflake target"; text "The report's Power
Query reads <db>.<schema> (warehouse W). Leave the overrides empty to keep that, or point every table at another
database/schema."; inputs "Database override" / "Schema override" (placeholders = hints; values = session choice ??
saved override); button "Check access" ("Checking…") calling preflight; result box (`role="status"`, amber when
blocking or accessible < bound, else green) with the message, one line per target
`db.schema: <error | n/m tables found>[ · case differs: ...]`, and `CaseCheckDetails` (`data-testid="case-check"`):
"Letter case: E/C names match Snowflake exactly", lists (max 50 + "…and N more") for corrected ("... corrected to
Snowflake's spelling (saved with this conversion)"), ambiguous ("(not changed)"), not found, could not check.
7.3 Convert step sends `database_override`/`schema_override` (blank -> null) only when `bindingTarget` is set; the
convert query key includes it.
7.4 Connect step pre-fills the warehouse from source hints (phase 02).
7.5 Types: `SourceHints`, `PreflightTarget`, `PreflightResult`, `IdentifierCaseSummary`; client `sourceHints`, `preflight`.

## Files
Create: `backend/app/binding/case_check.py`, `backend/app/binding/preflight.py`.
Modify: `binding/resolver.py`, `ir/report.py` (BindingSettings from phase 04), `runtime/engine.py`, `runtime/accelerate.py`,
`runtime/dashboard.py` (`compile_dashboard` uses `build_bundle_binding_map`), `api/dashboards.py`, `api/conversions.py`,
`agents/pipeline.py`, frontend `store/wizard.ts`, `steps/AnalyzeStep.tsx`, `steps/ConvertStep.tsx`, `api/client.ts`, `api/types.ts`.

## Tests
- `tests/test_identifier_quoting.py`: names with spaces, `(`, `'`, `"`, unicode quote fine; control chars rejected with
  origin text; `sql_name` unquoted for `SALES`, quoted for `Sales`, `ORDER`, `MY TABLE`.
- `tests/test_identifier_case.py` (fake cursor answering SHOW/INFORMATION_SCHEMA): exact / corrected / ambiguous /
  missing at every level; column fixes; errors recorded; generated SQL text uses the exact names (DuckDB is
  case-insensitive for quoted names, so assert the SQL text).
- `tests/test_case_apply.py`: fixes applied only to case-equal names; override to another database ignores stale fixes;
  unreadable catalog keeps saved fixes; first dashboard query runs the check once.
- pre-flight: blocking when all schemas fail or no exact names; message texts; endpoint saves case fixes only.
- source hints: most common values; parameter-driven `Snowflake.Databases` args.
- frontend: Analyze target card renders hints, sends overrides, shows case details.

## Done criteria
All SQL identifiers go through `quote_ident`/`sql_name`; overrides survive a reload and apply to dashboard, export
and deploy; tests pass.
 