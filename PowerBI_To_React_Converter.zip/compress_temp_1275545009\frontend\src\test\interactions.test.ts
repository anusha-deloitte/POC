import { describe, expect, it } from 'vitest'
import {
  buildVisualQueryFilters,
  emptyInteractionState,
  resolveVisualInteractions,
  toggleSelection,
} from '../dashboard/interactions'
import type { InteractionGraph, PageSpec, VisualSpec } from '../dashboard/types'

const visual: VisualSpec = {
  name: 'chart-1',
  visual_type: 'columnChart',
  x: 0,
  y: 0,
  width: 300,
  height: 200,
  z: 0,
  supported: true,
  dim_keys: ['sales.region'],
  column_keys: [],
  series_keys: [],
  measure_keys: ['sales.amount'],
  measure_roles: {},
  measure_formats: {},
  static_content: {},
  sort: [],
}

const page: PageSpec = {
  name: 'page-1',
  display_name: 'Page 1',
  width: 800,
  height: 600,
  ordinal: 0,
  visuals: [
    visual,
    {
      ...visual,
      name: 'chart-2',
    },
    {
      ...visual,
      name: 'chart-3',
    },
  ],
}

const graph: InteractionGraph = {
  nodes: ['chart-1', 'chart-2', 'chart-3'],
  edges: [
    { from_visual: 'chart-1', to_visual: 'chart-2', mode: 'filter' },
    { from_visual: 'chart-1', to_visual: 'chart-3', mode: 'highlight' },
  ],
  sync_groups: {},
}

describe('interaction helpers', () => {
  it('toggles a visual selection on repeat click', () => {
    const selected = toggleSelection(emptyInteractionState(), page.visuals[0], ['West'])
    expect(selected.selections['chart-1']).toEqual(['West'])

    const cleared = toggleSelection(selected, page.visuals[0], ['West'])
    expect(cleared.selections['chart-1']).toBeUndefined()
  })

  it('turns selection into page filters', () => {
    const state = toggleSelection(emptyInteractionState(), page.visuals[0], ['West'])
    const views = resolveVisualInteractions(page, graph, state)
    expect(views['chart-2'].filtered).toBe(true)
    expect(views['chart-3'].highlighted).toBe(true)

    const filters = buildVisualQueryFilters(page, graph, state, [
      { table: 'sales', column: 'year', values: [2025] },
    ])
    expect(filters['chart-1']).toEqual([{ table: 'sales', column: 'year', values: [2025] }])
    expect(filters['chart-2']).toEqual([
      { table: 'sales', column: 'year', values: [2025] },
      { table: 'sales', column: 'region', values: ['West'], source: 'cross_filter' },
    ])
    expect(filters['chart-3']).toEqual([{ table: 'sales', column: 'year', values: [2025] }])
  })
})
describe('slicer filters and edit interactions (phase 09)', () => {
  const slicerFilter = {
    table: 'sales',
    column: 'region',
    values: ['EU'],
    source: 'slicer',
    params: { slicer: 'slicer-1' },
  }
  const pageWithSlicer: PageSpec = {
    ...page,
    visuals: [...page.visuals, { ...visual, name: 'slicer-1', visual_type: 'slicer' }],
  }
  const graph: InteractionGraph = {
    nodes: [],
    sync_groups: {},
    edges: [{ from_visual: 'slicer-1', to_visual: 'chart-2', mode: 'none' }],
  }

  it('skips visuals whose interaction from the slicer is NoFilter', () => {
    const out = buildVisualQueryFilters(pageWithSlicer, graph, emptyInteractionState(), [slicerFilter])
    expect(out['chart-1']).toEqual([slicerFilter])
    expect(out['chart-2']).toEqual([])
  })

  it('a slicer never filters its own domain', () => {
    const out = buildVisualQueryFilters(pageWithSlicer, { nodes: [], edges: [], sync_groups: {} }, emptyInteractionState(), [slicerFilter])
    expect(out['slicer-1']).toEqual([])
    expect(out['chart-1']).toEqual([slicerFilter])
  })

  it('repeat click toggles a selection off', () => {
    const once = toggleSelection(emptyInteractionState(), visual, ['EU'])
    expect(once.selections['chart-1']).toEqual(['EU'])
    expect(toggleSelection(once, visual, ['EU']).selections['chart-1']).toBeUndefined()
  })
})

describe('Filters pane clauses reach every visual (phase 10)', () => {
  const pane = { table: 'sales', column: 'country', op: 'in', values: ['US'], source: 'page_filter' }
  const withSlicer: PageSpec = {
    ...page,
    visuals: [...page.visuals, { ...visual, name: 'slicer-1', visual_type: 'slicer' }],
  }

  it('are added to every visual, slicers included, and never dropped by NoFilter', () => {
    const graph: InteractionGraph = {
      nodes: [],
      sync_groups: {},
      edges: [
        { from_visual: 'slicer-1', to_visual: 'chart-2', mode: 'none' },
        { from_visual: 'chart-1', to_visual: 'chart-2', mode: 'none' },
      ],
    }
    const out = buildVisualQueryFilters(withSlicer, graph, emptyInteractionState(), [], [pane])
    for (const name of ['chart-1', 'chart-2', 'slicer-1']) expect(out[name]).toContain(pane)
  })

  it('come first, then slicers, then cross filters', () => {
    const slicer = { table: 'sales', column: 'year', values: [2024], source: 'slicer' }
    const state = toggleSelection(emptyInteractionState(), withSlicer.visuals[0], ['West'])
    const graph: InteractionGraph = {
      nodes: [],
      sync_groups: {},
      edges: [{ from_visual: 'chart-1', to_visual: 'chart-2', mode: 'filter' }],
    }
    const out = buildVisualQueryFilters(withSlicer, graph, state, [slicer], [pane])
    expect(out['chart-2'].map((f) => f.source)).toEqual(['page_filter', 'slicer', 'cross_filter'])
  })
})
