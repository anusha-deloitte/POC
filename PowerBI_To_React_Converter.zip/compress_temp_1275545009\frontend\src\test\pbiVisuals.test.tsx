import { render, screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, expect, it, vi } from 'vitest'
import { MatrixDrillContext, type MatrixDrill } from '../dashboard/drill'
import { PBI_DEFAULTS } from '../dashboard/pbi/defaults'
import { buildTheme, PbiThemeContext, resolveVisual } from '../dashboard/pbi/resolve'
import type { VisualResult, VisualSpec } from '../dashboard/types'
import { CardVisual } from '../dashboard/visuals/CardVisual'
import { KpiCardVisual, kpiActualFormat } from '../dashboard/visuals/KpiCardVisual'
import { pbiTableColumns, valuesOnRowRows } from '../dashboard/visuals/PbiTable'
import { SlicerVisual, slicerOptions } from '../dashboard/visuals/SlicerVisual'
import { TableVisual } from '../dashboard/visuals/TableVisual'
import { TextboxVisual } from '../dashboard/visuals/TextboxVisual'

const L = (v: string) => ({ expr: { Literal: { Value: v } } })
const theme = buildTheme(undefined)

function v(over: Partial<VisualSpec> & { objects?: object } = {}): VisualSpec {
  const { objects, ...rest } = over
  return {
    name: 'v', visual_type: 'card', x: 0, y: 0, width: 300, height: 200, z: 1, supported: true,
    dim_keys: [], column_keys: [], series_keys: [], measure_keys: ['M'], measure_roles: {}, measure_formats: {},
    static_content: {}, sort: [], data_status: 'ok',
    pbir: { objects: (objects ?? {}) as Record<string, unknown>, container_objects: {}, fields: [], sort: [], is_hidden: false },
    ...rest,
  } as VisualSpec
}
const res = (columns: string[], rows: (string | number | null)[][], over: Partial<VisualResult> = {}): VisualResult => ({
  visual: 'v', columns, rows, warnings: [], elapsed_ms: 0, cached: false, ...over,
})
const wrap = (ui: React.ReactElement) => render(<PbiThemeContext.Provider value={theme}>{ui}</PbiThemeContext.Provider>)

describe('calibration against Power BI defaults', () => {
  it('a card draws the value at 27 pt (36 px), weight 600, with a 12 pt category label', () => {
    const style = resolveVisual(v(), theme)
    expect(style.card.valueFont.sizePx).toBeCloseTo((PBI_DEFAULTS.card.valueSizePt * 4) / 3)
    expect(style.card.valueFont.weight).toBe(600)
    expect(style.card.categoryFont.sizePx).toBeCloseTo(16)
    expect(style.title.font.sizePx).toBe(16)
  })

  it('table text is 10 pt with 3 px row padding and #F3F2F1 banding', () => {
    const t = resolveVisual(v({ visual_type: 'tableEx' }), theme).table
    expect(t.valuesFont.sizePx).toBeCloseTo(13.333, 2)
    expect(t.rowPaddingPx).toBe(3)
    expect(t.backSecondary).toBe('#F3F2F1')
  })
})

describe('card and KPI card', () => {
  it('a card centres its value with an optional category label', () => {
    wrap(<CardVisual spec={v({ measure_formats: { M: '#,0' } })} data={res(['M'], [[1234567]])} />)
    expect(screen.getByTestId('card-value').textContent).toBe('1,234,567')
    expect(screen.getByTestId('card-category').textContent).toBe('M')
  })

  it('category labels can be switched off', () => {
    wrap(<CardVisual spec={v({ objects: { categoryLabels: [{ properties: { show: L('false') } }] } })} data={res(['M'], [[5]])} />)
    expect(screen.queryByTestId('card-category')).toBeNull()
  })

  it('an overlay card whose measure is blank text draws nothing', () => {
    wrap(<CardVisual spec={v()} data={res(['M'], [['   ']])} />)
    expect(screen.getByTestId('card-empty')).toBeTruthy()
    expect(screen.queryByTestId('card-value')).toBeNull()
  })

  it('a KPI card shows name, actual and a comparison with an arrow', () => {
    const spec = v({
      visual_type: 'kpiCard', measure_keys: ['Actual', 'Target'], measure_formats: { Actual: '#,0' },
      objects: { kpiName: [{ properties: { text: L("'Revenue'") } }], target1: [{ properties: { prefix: L("'vs target'"), decimalPlaces: L('2D') } }] },
    })
    wrap(<KpiCardVisual spec={spec} data={res(['Actual', 'Target'], [[110, 100]])} />)
    expect(screen.getByTestId('kpi-name').textContent).toBe('Revenue')
    expect(screen.getByTestId('kpi-actual').textContent).toBe('110')
    expect(screen.getByTestId('kpi-comparison').textContent).toContain('vs target 10.00%')
    expect(screen.getByLabelText('above target').textContent).toBe('▲')
  })

  it('a KPI card below target uses the down arrow and defaults to one decimal', () => {
    const spec = v({ visual_type: 'kpiCard', measure_keys: ['A', 'T'] })
    wrap(<KpiCardVisual spec={spec} data={res(['A', 'T'], [[90, 100]])} />)
    expect(screen.getByTestId('kpi-comparison').textContent).toContain('10.0%')
    expect(screen.getByLabelText('below target').textContent).toBe('▼')
  })

  it('a KPI card without data renders the name and an em dash', () => {
    const spec = v({ visual_type: 'kpiCard', measure_keys: ['A', 'T'], title: 'Orders' })
    wrap(<KpiCardVisual spec={spec} data={res(['A', 'T'], [])} />)
    expect(screen.getByTestId('kpi-name').textContent).toBe('Orders')
    expect(screen.getByTestId('kpi-actual').textContent).toBe('—')
    expect(screen.getByTestId('kpi-comparison').textContent).toBe('—')
  })
})

describe('slicer', () => {
  const spec = (objects: object = {}) =>
    v({ visual_type: 'slicer', dim_keys: ['Customer.Country'], slicer_target: { table: 'Customer', column: 'Country' }, objects })

  it('always lists the saved / current selection, even when the data cannot', () => {
    expect(slicerOptions(res(['c'], [['US'], ['DE'], ['US']]), ['FR'])).toEqual(['US', 'DE', 'FR'])
    expect(slicerOptions(undefined, ['FR'])).toEqual(['FR'])
  })

  it('with a query error it still shows its All dropdown', () => {
    wrap(<SlicerVisual spec={spec()} data={res([], [], { error: 'boom' })} selected={[]} onChange={() => {}} />)
    const select = screen.getByRole('combobox') as HTMLSelectElement
    expect(within(select).getByRole('option', { name: 'All' })).toBeTruthy()
  })

  it('draws the Power BI dropdown geometry and reports a changed selection', async () => {
    const onChange = vi.fn()
    wrap(<SlicerVisual spec={spec()} data={res(['c'], [['US'], ['DE']])} selected={[]} onChange={onChange} />)
    expect(screen.getByTestId('pbi-slicer')).toBeTruthy()
    const svg = screen.getByTestId('pbi-slicer').querySelector('svg')!
    expect(svg.getAttribute('width')).toBe(String(PBI_DEFAULTS.slicer.dropdown.chevron.w))
    await userEvent.selectOptions(screen.getByRole('combobox'), 'DE')
    expect(onChange).toHaveBeenCalledWith(['DE'])
    await userEvent.selectOptions(screen.getByRole('combobox'), 'All')
    expect(onChange).toHaveBeenCalledWith([])
  })

  it('shows its header unless the container title already names it', () => {
    const { unmount } = wrap(<SlicerVisual spec={spec()} data={res(['c'], [['US']])} selected={[]} onChange={() => {}} />)
    expect(screen.getByTestId('slicer-header').textContent).toBe('Country')
    unmount()
    const named = v({
      visual_type: 'slicer', slicer_target: { table: 'Customer', column: 'Country' },
      pbir: { objects: {}, container_objects: { title: [{ properties: { show: L('true'), text: L("'Country'") } }] }, fields: [], sort: [], is_hidden: false },
    })
    wrap(<SlicerVisual spec={named} data={res(['c'], [['US']])} selected={[]} onChange={() => {}} />)
    expect(screen.queryByTestId('slicer-header')).toBeNull()
  })

  it('without PBIR it keeps the legacy select', () => {
    wrap(<SlicerVisual spec={{ ...spec(), pbir: null }} data={res(['c'], [['US']])} selected={[]} onChange={() => {}} />)
    expect(screen.queryByTestId('pbi-slicer')).toBeNull()
    expect(screen.getByRole('combobox')).toBeTruthy()
  })
})

describe('textbox', () => {
  const content = { paragraphs: [{ textRuns: [{ value: 'plain' }, { value: 'sized', textStyle: { fontSize: '18pt', color: '#FF0000' } }] }] }

  it('runs without a size use the Power BI default (12 pt); explicit sizes convert from points', () => {
    wrap(<TextboxVisual spec={v({ visual_type: 'textbox', static_content: content })} />)
    const runs = screen.getByTestId('textbox').querySelectorAll('span')
    expect((runs[0] as HTMLElement).style.fontSize).toBe('16px')
    expect((runs[1] as HTMLElement).style.fontSize).toBe('24px')
    expect((runs[1] as HTMLElement).style.color).toBe('rgb(255, 0, 0)')
  })

  it('without PBIR it keeps the legacy sizing', () => {
    wrap(<TextboxVisual spec={{ ...v({ visual_type: 'textbox', static_content: content }), pbir: null }} />)
    const runs = screen.getByTestId('textbox').querySelectorAll('span')
    expect((runs[0] as HTMLElement).style.fontSize).toBe('')
  })
})

describe('tables and matrices', () => {
  const fields = [
    { role: 'Values', table: 'Sales', name: 'Total Sales', display_name: 'Revenue', is_measure: true, query_ref: 'Sales.Total Sales' },
    { role: 'Values', table: 'Product', name: 'Category', is_measure: false, query_ref: 'Product.Category' },
  ]
  const spec = (objects: object = {}, over: Partial<VisualSpec> = {}) =>
    v({ visual_type: 'tableEx', dim_keys: ['Product.Category'], measure_keys: ['Total Sales'], measure_formats: { 'Total Sales': '#,0' }, objects, ...over, pbir: { objects: objects as Record<string, unknown>, container_objects: {}, fields, sort: [], is_hidden: false } })
  const data = res(['Total Sales', 'Product.Category'], [[1500, 'Bikes'], [800, 'Cars']])

  it('columns follow the projection order with display names; unlisted columns keep query order', () => {
    const s = spec()
    const cols = pbiTableColumns(s, ['Extra', 'Product.Category', 'Total Sales'], resolveVisual(s, theme))
    expect(cols.map((c) => c.header)).toEqual(['Revenue', 'Category', 'Extra'])
    expect(cols.map((c) => c.key)).toEqual(['Total Sales', 'Product.Category', 'Extra'])
    expect(cols[0].align).toBe('right')
    expect(cols[1].align).toBe('left')
  })

  it('explicit widths and alignment come from selectors; a selector-less width is the default', () => {
    const s = spec({
      columnWidth: [{ properties: { value: L('90D') } }, { selector: { metadata: 'Sales.Total Sales' }, properties: { value: L('150D') } }],
      columnFormatting: [{ selector: { metadata: 'Product.Category' }, properties: { alignment: L("'Center'") } }],
    })
    const cols = pbiTableColumns(s, ['Total Sales', 'Product.Category'], resolveVisual(s, theme))
    expect(cols.map((c) => c.widthPx)).toEqual([150, 90])
    expect(cols[1].align).toBe('center')
  })

  it('renders banded rows in projection order with a server-computed totals row', () => {
    wrap(<TableVisual spec={spec()} data={{ ...data, totals: { columns: ['Total Sales'], row: [2300] } }} />)
    const headers = screen.getAllByRole('columnheader').map((h) => h.textContent)
    expect(headers).toEqual(['Revenue', 'Category'])
    const rows = screen.getAllByTestId('table-row')
    expect(within(rows[0]).getAllByRole('cell').map((c) => c.textContent)).toEqual(['1,500', 'Bikes'])
    expect(rows[1].style.background).not.toBe(rows[0].style.background) // banding
    const totals = screen.getByTestId('totals-row')
    expect(within(totals).getAllByRole('cell')[0].textContent).toBe('Total')
  })

  it('totals can be switched off or relabelled', () => {
    const { unmount } = wrap(
      <TableVisual spec={spec({ total: [{ properties: { label: L("'Grand total'") } }] })} data={{ ...data, totals: { columns: ['Total Sales'], row: [2300] } }} />,
    )
    expect(within(screen.getByTestId('totals-row')).getAllByRole('cell')[0].textContent).toBe('Grand total')
    unmount()
    wrap(<TableVisual spec={spec({ total: [{ properties: { totals: L('false') } }] })} data={{ ...data, totals: { columns: ['Total Sales'], row: [2300] } }} />)
    expect(screen.queryByTestId('totals-row')).toBeNull()
  })

  it('wraps text in sized columns and never stretches to the container', () => {
    const s = spec({ columnWidth: [{ properties: { value: L('80D') } }] })
    wrap(<TableVisual spec={s} data={data} />)
    const table = screen.getByTestId('pbi-table').querySelector('table')!
    expect(table.style.width).toBe('160px')
    expect(table.style.tableLayout).toBe('fixed')
    expect(screen.getAllByRole('cell')[0].style.whiteSpace).toBe('normal')
  })

  it('values on rows: one row per measure under each row group', () => {
    const s = spec({}, { measure_keys: ['A', 'B'], dim_keys: ['Product.Category'] })
    const out = valuesOnRowRows(s, res(['Product.Category', 'A', 'B'], [['Bikes', 1, 2], ['Cars', 3, 4]]))
    expect(out.rows).toEqual([['Bikes', 'A', 1], ['Bikes', 'B', 2], ['Cars', 'A', 3], ['Cars', 'B', 4]])
    expect(out.columns).toEqual(['Product.Category', 'Values', 'Value'])
  })

  it('a collapsed matrix expands child rows through the drill context', async () => {
    const toggle = vi.fn()
    const drill: MatrixDrill = {
      isExpanded: (k) => k === JSON.stringify(['Bikes']),
      children: (k) => k === JSON.stringify(['Bikes'])
        ? { page: 'p', visual: 'v', level_key: 'Product.Name', level_index: 1, total_levels: 2, columns: ['Product.Name', 'Total Sales'], rows: [['Mountain', 900], ['Road', 600]], sql: '', warnings: [] }
        : undefined,
      isLoading: () => false,
      error: () => undefined,
      toggle,
    }
    const s = spec({}, { visual_type: 'pivotTable', hierarchy: { levels: ['Product.Category', 'Product.Name'], current_level: 'Product.Category', expand_rows: true } })
    wrap(
      <MatrixDrillContext.Provider value={drill}>
        <TableVisual spec={s} data={{ ...data, columns: ['Total Sales', 'Product.Category'] }} />
      </MatrixDrillContext.Provider>,
    )
    const rows = screen.getAllByTestId('table-row')
    expect(rows).toHaveLength(4) // Bikes, its 2 children, Cars
    const child = within(rows[1]).getAllByRole('cell')
    expect(child.map((c) => c.textContent)).toEqual(['900', 'Mountain'])
    expect(child[1].style.paddingLeft).toBe('20px') // indented under its parent
    await userEvent.click(screen.getAllByRole('button', { name: /Expand row|Collapse row/ })[1])
    expect(toggle).toHaveBeenCalledWith(JSON.stringify(['Cars']), [{ table: 'Product', column: 'Category', values: ['Cars'], source: 'drill' }], 'Product.Category')
  })
})

describe('KPI actual-value format', () => {
  it('drops optional "auto" decimals but keeps required ones', () => {
    expect(kpiActualFormat('\$#,0.###############')).toBe('\$#,0')
    expect(kpiActualFormat('#,0.00')).toBe('#,0.00')
    expect(kpiActualFormat('#,0.0##')).toBe('#,0.0##')
    expect(kpiActualFormat('0.0%')).toBe('0.0%')
  })

  it('explicit decimal places rewrite every decimal placeholder (max 6)', () => {
    expect(kpiActualFormat('#,0.###', 2)).toBe('#,0.00')
    expect(kpiActualFormat('#,0.00', 0)).toBe('#,0')
    expect(kpiActualFormat('#,0.00', 9)).toBe('#,0.000000')
    expect(kpiActualFormat(undefined, 1)).toBe('#,0.0')
    expect(kpiActualFormat(undefined, '3')).toBe('#,0.000')
    expect(kpiActualFormat(undefined)).toBeUndefined()
  })

  it('leaves quoted literals and escapes untouched', () => {
    expect(kpiActualFormat('"v1.###" #,0.###')).toBe('"v1.###" #,0')
    expect(kpiActualFormat(String.raw`\.#,0.###`)).toBe(String.raw`\.#,0`)
  })

  it('shows $332,398,742 for a long-precision currency value', () => {
    const spec = v({
      visual_type: 'kpiCard', measure_keys: ['A', 'T'], measure_formats: { A: '\$#,0.###############' },
    })
    wrap(<KpiCardVisual spec={spec} data={res(['A', 'T'], [[332398742.4567, 300000000]])} />)
    expect(screen.getByTestId('kpi-actual').textContent).toBe('$332,398,742')
  })

  it('uses actual.actualDecimalPlaces, falling back to actual.decimalPlaces', () => {
    const base = { visual_type: 'kpiCard', measure_keys: ['A', 'T'], measure_formats: { A: '#,0.###' } }
    const a = v({ ...base, objects: { actual: [{ properties: { actualDecimalPlaces: L('1D'), decimalPlaces: L('3D') } }] } })
    const { unmount } = wrap(<KpiCardVisual spec={a} data={res(['A', 'T'], [[1234.5678, 1]])} />)
    expect(screen.getByTestId('kpi-actual').textContent).toBe('1,234.6')
    unmount()
    const b = v({ ...base, objects: { actual: [{ properties: { decimalPlaces: L('2D') } }] } })
    wrap(<KpiCardVisual spec={b} data={res(['A', 'T'], [[1234.5678, 1]])} />)
    expect(screen.getByTestId('kpi-actual').textContent).toBe('1,234.57')
  })
})
