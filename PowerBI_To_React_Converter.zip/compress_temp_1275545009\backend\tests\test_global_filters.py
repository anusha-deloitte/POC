"""Phase 10: Filters-pane cards, sync groups, pane settings, defaults and bookmark filter state."""

from __future__ import annotations

import pytest

from app.runtime import pbir_passthrough as pt
from app.runtime.dashboard import (
    bookmark_filter_values,
    card_clauses,
    compile_dashboard,
    default_filter_clauses,
    filters_passthrough,
    with_default_filters,
)
from app.runtime.filter_cards import FilterCondition, FilterDefault
from tests.pbir_world import PAGE, Report, column, lit, measure, projection, visual_json


def in_filter(table, col, *values, source="s"):
    return {
        "Version": 2,
        "From": [{"Name": source, "Entity": table, "Type": 0}],
        "Where": [
            {
                "Condition": {
                    "In": {
                        "Expressions": [
                            {"Column": {"Expression": {"SourceRef": {"Source": source}}, "Property": col}}
                        ],
                        "Values": [[{"Literal": {"Value": f"'{v}'"}}] for v in values],
                    }
                }
            }
        ],
    }


def card(name, table, col, flt=None, type_="Categorical", **extra):
    out = {"name": name, "field": column(table, col), "type": type_, **extra}
    if flt is not None:
        out["filter"] = flt
    return out


@pytest.fixture()
def rep(tmp_path):
    return Report(tmp_path)


def set_filters(rep, report=None, page=None, report_extra=None, page_extra=None):
    if report is not None:
        rep.patch_report(filterConfig={"filters": report, **(report_extra or {})})
    if page is not None:
        rep.patch_page(filterConfig={"filters": page, **(page_extra or {})})


# ------------------------------------------------------------------ parser


class TestParser:
    def test_card_fields(self, rep):
        set_filters(
            rep,
            report=[
                card("a", "Customer", "Country", in_filter("Customer", "Country", "US"),
                     displayName="Country", ordinal=2, howCreated="User", isLockedInViewMode=True,
                     isHiddenInViewMode=True,
                     objects={"general": [{"properties": {"requireSingleSelection": lit("true")}}]}),
                card("b", "Product", "Category", ordinal="x"),
            ],
        )  # fmt: skip
        a, b = rep.bundle().report.filters
        assert (a.is_locked, a.is_hidden, a.ordinal, a.how_created, a.display_name) == (True, True, 2, "User", "Country")
        assert a.require_single is True
        assert (b.is_locked, b.ordinal, b.display_name, b.require_single) == (False, None, None, False)

    def test_sync_groups(self, rep):
        qs = {"Values": {"projections": [projection(column("Customer", "Country"), "Customer.Country")]}}
        for name, group in (("s1", "G"), ("s2", "G"), ("s3", "H"), ("s4", None)):
            data = visual_json(name, "slicer", query_state=qs)
            if group:
                data["visual"]["syncGroup"] = {"groupName": group, "fieldChanges": True, "filterChanges": name != "s2"}
            rep.add_visual(data)
        report = rep.bundle().report
        assert report.interaction_graph.sync_groups == {"G": ["s1", "s2"], "H": ["s3"]}
        slicers = {v.name: v for v in report.pages[0].visuals}
        assert slicers["s1"].sync_group.model_dump() == {"name": "G", "field_changes": True, "filter_changes": True}
        assert slicers["s2"].sync_group.filter_changes is False
        assert slicers["s4"].sync_group is None

    def test_filter_pane_settings_and_colours(self, rep):
        color = lambda hex_: {"solid": {"color": lit(f"'{hex_}'")}}  # noqa: E731
        rep.patch_report(objects={"outspacePane": [{"properties": {
            "expanded": lit("false"), "visible": lit("true"), "width": lit("300D"),
            "backgroundColor": color("#111111"), "titleSize": lit("14D")}}],
            "filterCard": [{"properties": {"backgroundColor": color("#222222")}},
                           {"selector": {"id": "Applied"}, "properties": {"backgroundColor": color("#333333")}}]})  # fmt: skip
        pane = rep.bundle().report.filter_pane
        assert (pane.expanded, pane.visible, pane.width) == (False, True, 300.0)
        assert pane.colours["backgroundColor"] == "#111111" and pane.colours["titleSize"] == 14.0
        assert pane.colours["filterCard"] == {
            "Available": {"backgroundColor": "#222222"},
            "Applied": {"backgroundColor": "#333333"},
        }

    def test_no_pane_objects_means_none(self, rep):
        report = rep.bundle().report
        assert report.filter_pane is None and report.pages[0].filter_pane is None

    def test_page_pane_and_sort_orders_and_settings(self, rep):
        rep.patch_page(objects={"outspacePane": [{"properties": {"expanded": lit("true")}}]},
                       filterConfig={"filterSortOrder": "Descending", "filters": []})  # fmt: skip
        rep.patch_report(filterConfig={"filterSortOrder": "Ascending"}, settings={"allowChangeFilterTypes": False})
        report = rep.bundle().report
        assert report.pages[0].filter_pane.expanded is True
        assert (report.filter_sort_order, report.pages[0].filter_sort_order) == ("Ascending", "Descending")
        assert report.allow_change_filter_types is False
        assert Report(rep.root.parent / "again").bundle().report.allow_change_filter_types is True

    def test_new_parses_are_marked_parsed(self, rep):
        report = rep.bundle().report
        assert report.filters_parsed and report.pages_parsed

    def test_bookmark_filter_state(self, rep):
        rep.write_bookmark("b1", {
            "activeSection": PAGE,
            "filters": {"byName": {"cardA": {"type": "Categorical", "filter": in_filter("Customer", "Country", "DE")}},
                        "byExpr": [{"expression": column("Product", "Category"), "type": "Categorical",
                                    "filter": in_filter("Product", "Category", "Bikes")}]},
            "sections": {PAGE: {
                "filters": {"byName": {"pageCard": {"type": "Categorical", "filter": in_filter("Date", "Year", "2024")}}},
                "visualContainers": {
                    "slicer01aaaabbbbcccc": {"singleVisual": {"visualType": "slicer", "objects": {"merge": {"general": [
                        {"properties": {"filter": {"filter": in_filter("Customer", "Country", "US")}}}]}}}},
                    "other": {"singleVisual": {"visualType": "slicer"}},
                    "chart": {"singleVisual": {"visualType": "columnChart"}},
                },
            }},
        })  # fmt: skip
        rep.write_bookmark("b2", {"activeSection": PAGE}, suppressData=True)
        bookmarks = {b.name: b for b in rep.bundle().report.bookmarks}
        filters = bookmarks["b1"].state["filters"]
        assert set(filters["report"]) == {"cardA", "Product.Category"}
        assert filters["report"]["cardA"]["type"] == "Categorical"
        assert set(filters["pages"][PAGE]) == {"pageCard"}
        assert filters["slicers"]["slicer01aaaabbbbcccc"] is not None
        assert filters["slicers"]["other"] is None and "chart" not in filters["slicers"]
        assert "filters" not in bookmarks["b2"].state  # Data off


# ------------------------------------------------------------------ cards and defaults


class TestCards:
    def compile(self, rep):
        return rep.compile()[1]

    def test_cards_ordered_by_ordinal_hidden_and_locked_kept_drillthrough_excluded(self, rep):
        set_filters(
            rep,
            report=[
                card("late", "Customer", "Country", ordinal=5),
                card("none", "Customer", "City"),
                card("first", "Product", "Category", ordinal=1, isHiddenInViewMode=True),
                card("lock", "Date", "Year", ordinal=3, isLockedInViewMode=True),
                card("drill", "Product", "Name", howCreated="Drillthrough", ordinal=0),
            ],
        )
        spec = self.compile(rep)
        assert [c.name for c in spec.report_filters] == ["first", "lock", "late", "none"]
        flags = {c.name: (c.hidden, c.locked) for c in spec.report_filters}
        assert flags["first"] == (True, False) and flags["lock"] == (False, True)

    def test_sort_orders_by_title(self, rep):
        set_filters(
            rep,
            page=[card("x", "Customer", "Country", displayName="beta"),
                  card("y", "Product", "Category", displayName="Alpha"),
                  card("z", "Date", "Year", displayName="gamma")],
            page_extra={"filterSortOrder": "Ascending"},
        )  # fmt: skip
        assert [c.display_name for c in self.compile(rep).pages[0].filters] == ["Alpha", "beta", "gamma"]
        rep.patch_page(filterConfig={"filterSortOrder": "Descending", "filters": [
            card("x", "Customer", "Country", displayName="beta"), card("y", "Product", "Category", displayName="Alpha")]})  # fmt: skip
        assert [c.display_name for c in self.compile(rep).pages[0].filters] == ["beta", "Alpha"]

    def test_basic_card_default_and_all(self, rep):
        set_filters(rep, report=[card("c", "Customer", "Country", in_filter("Customer", "Country", "US", "DE")),
                                 card("all", "Product", "Category")])  # fmt: skip
        spec = self.compile(rep)
        c, all_ = spec.report_filters
        assert c.kind == "basic" and c.supported and c.data_type == "string"
        assert c.default.model_dump() == {"join": "and", "conditions": [{"op": "in", "values": ["US", "DE"], "params": {}}]}
        assert all_.default is None  # (All)
        assert card_clauses(all_) == []

    def test_advanced_or_card_becomes_one_or_clause(self, rep):
        cond = {"Or": {
            "Left": {"Contains": {"Left": column("Customer", "Country"), "Right": {"Literal": {"Value": "'U'"}}}},
            "Right": {"Comparison": {"ComparisonKind": 0, "Left": column("Customer", "Country"), "Right": {"Literal": {"Value": "'DE'"}}}},
        }}  # fmt: skip
        set_filters(rep, page=[card("adv", "Customer", "Country", {"Where": [{"Condition": cond}]}, type_="Advanced")])
        c = self.compile(rep).pages[0].filters[0]
        assert c.kind == "advanced" and c.default.join == "or"
        assert [x.op for x in c.default.conditions] == ["contains", "eq"]
        (clause,) = card_clauses(c)
        assert clause.op == "or" and [x.op for x in clause.clauses] == ["contains", "eq"]
        assert clause.source == "page_filter"
        and_ = FilterDefault(join="and", conditions=[FilterCondition(op="gt", values=[1]), FilterCondition(op="lt", values=[9])])
        c2 = c.model_copy(update={"default": and_})
        assert [x.op for x in card_clauses(c2)] == ["gt", "lt"]

    def test_not_conditions_negate(self, rep):
        neg = {"Not": {"Expression": {"In": {"Expressions": [column("Customer", "Country")], "Values": [[{"Literal": {"Value": "'US'"}}]]}}}}
        set_filters(rep, page=[card("n", "Customer", "Country", {"Where": [{"Condition": neg}]})])
        assert self.compile(rep).pages[0].filters[0].default.conditions[0].op == "not_in"

    def test_unsupported_cards_carry_their_reason(self, rep):
        set_filters(
            rep,
            report=[
                {"name": "nofield", "type": "Categorical"},
                card("measure", "Sales", "Total Sales"),
                card("unknown", "Customer", "Nope", in_filter("Customer", "Nope", "x")),
                card("shape", "Customer", "Country", {"Where": [{"Condition": {"Wibble": {}}}]}),
            ],
        )
        rep_ = rep.bundle().report.filters
        rep_[1].field_is_measure = True
        reasons = {}
        from app.runtime.filter_cards import filter_card

        bundle = rep.bundle()
        bundle.report.filters[1].field_is_measure = True
        for f in bundle.report.filters:
            c = filter_card(f, bundle)
            reasons[c.name] = c.reason
        assert reasons == {
            "nofield": "filter field not recognised",
            "measure": "filters on a measure are not supported in the Filters pane",
            "unknown": "column Customer[Nope] not found in the model",
            "shape": "filter condition shape not supported",
        }

    def test_unsupported_saved_filter_is_reported_not_silently_dropped(self, rep):
        set_filters(rep, page=[card("shape", "Customer", "Country", {"Where": [{"Condition": {"Wibble": {}}}]}, displayName="Country")])
        spec = self.compile(rep)
        assert any("page filter 'Country' not applied: filter condition shape not supported" in w for w in spec.warnings)
        assert card_clauses(spec.pages[0].filters[0]) == []

    def test_unknown_operator_is_unsupported(self, rep):
        from app.ir.report import Filter, FilterScope
        from app.runtime.filter_cards import _card_default, _Refused

        bundle = rep.bundle()
        flt = Filter(name="x", scope=FilterScope.PAGE, field_table="Customer", field_name="Country",
                     definition={"Where": [{"Condition": {"Comparison": {"ComparisonKind": 9, "Left": column("Customer", "Country"), "Right": {"Literal": {"Value": "1L"}}}}}]})  # fmt: skip
        with pytest.raises(_Refused):
            _card_default(flt)
        assert bundle


class TestDefaults:
    def filtered_report(self, rep):
        set_filters(
            rep,
            report=[card("r", "Product", "Category", in_filter("Product", "Category", "Bikes"), isHiddenInViewMode=True)],
            page=[card("p", "Customer", "Country", in_filter("Customer", "Country", "US"), isLockedInViewMode=True)],
        )
        return self.spec(rep)

    def spec(self, rep):
        return rep.compile()[1]

    def test_clauses_include_hidden_and_locked_and_tag_their_source(self, rep):
        spec = self.filtered_report(rep)
        clauses = default_filter_clauses(spec, spec.pages[0])
        assert [(c.column, c.source) for c in clauses] == [("Category", "report_filter"), ("Country", "page_filter")]

    def test_every_visual_query_carries_the_defaults_including_draft_and_title(self, rep):
        from app.runtime.engine import MeasureRefSpec, QuerySpec

        spec = self.filtered_report(rep)
        for v in spec.pages[0].visuals:
            v.draft_query = QuerySpec(measures=[MeasureRefSpec(name="Total Sales")])
            v.title_query = QuerySpec(measures=[MeasureRefSpec(name="Total Sales")])
        out = with_default_filters(spec)
        assert out is not spec
        for v in out.pages[0].visuals:
            for attr in ("query", "draft_query", "title_query"):
                q = getattr(v, attr)
                if q is None:
                    continue
                assert {f.column for f in q.filters} >= {"Category", "Country"}, (v.name, attr)
        # the original is untouched
        assert all(not (v.draft_query.filters) for v in spec.pages[0].visuals)

    def test_a_spec_without_defaults_is_returned_as_is(self, rep):
        spec = self.spec(rep)
        assert with_default_filters(spec) is spec

    def test_passthrough_fills_a_stored_bundle(self, rep):
        set_filters(rep, report=[card("a", "Customer", "Country", in_filter("Customer", "Country", "US"), isLockedInViewMode=True)])
        rep.patch_report(objects={"outspacePane": [{"properties": {"expanded": lit("true")}}]})
        bundle = rep.bundle()
        # an old stored bundle: none of the phase 10 fields
        bundle.report.filters_parsed = bundle.report.pages_parsed = False
        bundle.report.filters = []
        bundle.report.filter_pane = None
        bundle.report.bookmarks = []
        filters_passthrough(bundle)
        assert [f.name for f in bundle.report.filters] == ["a"] and bundle.report.filters[0].is_locked
        assert bundle.report.filter_pane.expanded is True
        assert bundle.report.filters_parsed and bundle.report.pages_parsed
        bundle.report.filters = []
        filters_passthrough(bundle)  # idempotent: parsed bundles are left alone
        assert bundle.report.filters == []
        assert pt.filters_passthrough is filters_passthrough


class TestBookmarkFilterValues:
    def test_filter_state_becomes_filter_values(self, rep):
        set_filters(
            rep,
            report=[card("cardA", "Customer", "Country", in_filter("Customer", "Country", "US")),
                    card("locked", "Product", "Category", in_filter("Product", "Category", "Bikes"), isLockedInViewMode=True)],
            page=[card("pageCard", "Date", "Year", in_filter("Date", "Year", "2023"))],
        )  # fmt: skip
        rep.write_bookmark("b1", {
            "activeSection": PAGE,
            "filters": {"byName": {
                "cardA": {"type": "Categorical", "filter": in_filter("Customer", "Country", "DE", "FR")},
                "locked": {"type": "Categorical", "filter": in_filter("Product", "Category", "Cars")},
                "ghost": {"type": "Categorical", "filter": in_filter("Product", "Name", "x")}}},
            "sections": {PAGE: {
                "filters": {"byName": {"pageCard": {"type": "Categorical", "filter": {"Version": 2, "Where": []}}}},
                "visualContainers": {"slicer01aaaabbbbcccc": {"singleVisual": {"visualType": "slicer", "objects": {"merge": {"general": [
                    {"properties": {"filter": {"filter": in_filter("Customer", "Country", "US")}}}]}}}}},
            }},
        })  # fmt: skip
        spec = rep.compile()[1]
        (b,) = spec.bookmarks
        assert "filters" not in b.state
        values = b.state["filter_values"]
        assert values["report"] == {
            "cardA": {"join": "and", "conditions": [{"op": "in", "values": ["DE", "FR"], "params": {}}]}
        }  # locked and unknown cards are not restored
        assert values["pages"][PAGE] == {"pageCard": None}  # an emptied card is (All)
        assert values["slicers"] == {"slicer01aaaabbbbcccc": ["US"]}

    def test_bookmarks_without_filters_are_unchanged(self, rep):
        rep.write_bookmark("plain", {"activeSection": PAGE}, suppressData=True)
        spec = rep.compile()[1]
        (b,) = spec.bookmarks
        assert "filter_values" not in b.state and "filters" not in b.state
        assert bookmark_filter_values(b, spec) is b

    def test_a_slicer_filter_that_is_not_an_in_clears_the_selection(self, rep):
        neg = {"Where": [{"Condition": {"Not": {"Expression": {"In": {"Expressions": [column("Customer", "Country")], "Values": [[{"Literal": {"Value": "'US'"}}]]}}}}}]}
        rep.write_bookmark("b", {"activeSection": PAGE, "sections": {PAGE: {"visualContainers": {"slicer01aaaabbbbcccc": {
            "singleVisual": {"visualType": "slicer", "objects": {"merge": {"general": [{"properties": {"filter": {"filter": neg}}}]}}}}}}}})  # fmt: skip
        spec = rep.compile()[1]
        assert spec.bookmarks[0].state["filter_values"]["slicers"] == {"slicer01aaaabbbbcccc": []}


def test_pane_and_flags_reach_the_spec(rep):
    rep.patch_report(settings={"allowChangeFilterTypes": False},
                     objects={"outspacePane": [{"properties": {"visible": lit("false")}}]})  # fmt: skip
    spec = rep.compile()[1]
    assert spec.allow_change_filter_types is False
    assert spec.filter_pane.visible is False
    assert spec.pages[0].filter_pane is None
    assert measure and compile_dashboard  # keep imports used


# ------------------------------------------------------------------ phase 11: drill-through and tooltips


def drill_page(rep, name, fields, **extra):
    params = [
        {"name": f"p{i}", "boundFilter": f"f{i}", "fieldExpr": expr} for i, expr in enumerate(fields)
    ]
    rep.add_page(
        name,
        name.upper(),
        type="Drillthrough",
        pageBinding={"name": "b", "type": "Drillthrough", "parameters": params},
        visibility="HiddenInViewMode",
        **extra,
    )


def tooltip_visual(name, section, show=True, type_="Canvas", container=True):
    props = {
        "show": lit("true" if show else "false"),
        "type": lit(f"'{type_}'"),
        "section": lit(f"'{section}'"),
    }
    return visual_json(
        name,
        "card",
        query_state={"Values": {"projections": [projection(measure("Sales", "Total Sales"), "Sales.Total Sales")]}},
        **({"container": {"visualTooltip": [{"properties": props}]}} if container else {"objects": {"visualTooltip": [{"properties": props}]}}),
    )


class TestDrillthroughAndTooltips:
    def test_drillthrough_binding_is_parsed(self, rep):
        hierarchy = {"HierarchyLevel": {"Expression": {"Hierarchy": {"Expression": {"SourceRef": {"Entity": "Date"}}, "Hierarchy": "Calendar"}}, "Level": "Year"}}
        drill_page(rep, "dt", [column("Customer", "Country"), measure("Sales", "Total Sales"), hierarchy])
        page = next(p for p in rep.bundle().report.pages if p.name == "dt")
        assert page.page_type == "Drillthrough" or page.page_type is None
        assert [(f.table, f.name, f.is_measure, f.hierarchy, f.bound_filter) for f in page.drillthrough] == [
            ("Customer", "Country", False, None, "f0"),
            ("Sales", "Total Sales", True, None, "f1"),
            ("Date", "Year", False, "Calendar", "f2"),
        ]

    def test_a_non_drillthrough_binding_has_no_fields(self, rep):
        rep.add_page("plain", "Plain", pageBinding={"type": "Tooltip", "parameters": []})
        assert next(p for p in rep.bundle().report.pages if p.name == "plain").drillthrough == []

    def test_spec_resolves_fields_and_warns_about_unknown_ones(self, rep):
        drill_page(rep, "dt", [column("Customer", "country"), column("Customer", "Nope"), measure("Sales", "Total Sales"), measure("Sales", "Ghost")])
        spec = rep.compile()[1]
        page = next(p for p in spec.pages if p.name == "dt")
        assert [f.key for f in page.drillthrough] == ["Customer.Country", "Total Sales"]  # the exact model name
        assert any("drill-through page 'DT': field Customer[Nope] is not in the model; ignored" in w for w in spec.warnings)
        assert any("field Sales[Ghost] is not in the model; ignored" in w for w in spec.warnings)
        assert [(t.page, t.fields) for t in spec.drill_through] == [("dt", ["Customer.Country", "Total Sales"])]

    def test_pages_without_fields_are_not_drill_targets(self, rep):
        assert rep.compile()[1].drill_through == []

    def test_tooltip_page_only_for_exported_tooltip_pages(self, rep):
        rep.add_page("tip", "Tip", type="Tooltip", width=320, height=240)
        rep.add_page("ordinary", "Ordinary")
        rep.add_visual(tooltip_visual("v1", "tip"))
        rep.add_visual(tooltip_visual("v2", "ordinary"))  # exists, but is not a Tooltip page
        rep.add_visual(tooltip_visual("v3", "tip", show=False))
        rep.add_visual(tooltip_visual("v4", "tip", type_="Default"))
        rep.add_visual(tooltip_visual("v5", "___AUTO___"))
        rep.add_visual(tooltip_visual("v6", "tip", container=False))  # from `objects`
        spec = rep.compile()[1]
        pages = {p.name: p.page_type for p in spec.pages}
        assert pages["tip"] == "Tooltip"
        got = {n: rep.visual(spec, n).tooltip_page for n in ("v1", "v2", "v3", "v4", "v5", "v6")}
        assert got == {"v1": "tip", "v2": None, "v3": None, "v4": None, "v5": None, "v6": "tip"}
        assert any("page 'Sales Overview': 1 visual(s) use tooltip page 'ordinary'" in w for w in spec.warnings)

    def test_a_missing_section_is_reported_once_per_page_with_its_count(self, rep):
        for n in ("a", "b", "c"):
            rep.add_visual(tooltip_visual(n, "ghost"))
        spec = rep.compile()[1]
        warnings = [w for w in spec.warnings if "tooltip page 'ghost'" in w]
        assert len(warnings) == 1 and "3 visual(s)" in warnings[0]

    def test_tooltips_without_sections_default(self, rep):
        data = tooltip_visual("t", "x")
        data["visual"]["visualContainerObjects"]["visualTooltip"][0]["properties"].pop("section")
        rep.add_visual(data)
        spec = rep.compile()[1]
        assert rep.visual(spec, "t").tooltip_page is None
        assert not any("tooltip page" in w for w in spec.warnings)

    def test_drill_and_tooltip_fields_reach_stored_bundles_via_passthrough(self, rep):
        drill_page(rep, "dt", [column("Customer", "Country")])
        rep.add_page("tip", "Tip", type="Tooltip")
        rep.add_visual(tooltip_visual("v1", "tip"))
        bundle = rep.bundle()
        # an old stored bundle: nothing of phases 10 / 11
        bundle.report.pages_parsed = bundle.report.filters_parsed = False
        for p in bundle.report.pages:
            p.page_type, p.drillthrough = None, []
            for v in p.visuals:
                v.tooltip = None
        filters_passthrough(bundle)
        pages = {p.name: p for p in bundle.report.pages}
        assert pages["tip"].page_type == "Tooltip"
        assert [f.name for f in pages["dt"].drillthrough] == ["Country"]
        assert next(v for v in pages[PAGE].visuals if v.name == "v1").tooltip.section == "tip"
        spec, _ = compile_dashboard(bundle)
        assert rep.visual(spec, "v1").tooltip_page == "tip"
