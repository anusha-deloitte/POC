import { describe, expect, it } from 'vitest'
import { imageFit, resolveButton, resolveShape, resourceItem, stateProp } from '../dashboard/pbi/chrome'
import { PBI_DEFAULTS } from '../dashboard/pbi/defaults'
import { font, fontSizePx, parseFontFamily, ptToPx } from '../dashboard/pbi/fonts'
import {
  color,
  decodeLiteral,
  lit,
  litBool,
  litNumber,
  litString,
  shade,
  themeDataColor,
  withAlpha,
} from '../dashboard/pbi/literal'
import { buildTheme, fieldColumnKey, pageBackground, resolveVisual } from '../dashboard/pbi/resolve'
import type { PbirField, VisualSpec } from '../dashboard/types'

const L = (v: string) => ({ expr: { Literal: { Value: v } } })
const solid = (hex: string) => ({ solid: { color: L(`'${hex}'`) } })

function visual(over: Partial<VisualSpec> & { objects?: object; container?: object; fields?: PbirField[] } = {}): VisualSpec {
  const { objects, container, fields, ...rest } = over
  return {
    name: 'v',
    visual_type: 'clusteredColumnChart',
    x: 0, y: 0, width: 100, height: 100, z: 1, supported: true,
    dim_keys: [], column_keys: [], series_keys: [], measure_keys: [], measure_roles: {}, measure_formats: {},
    static_content: {}, sort: [],
    pbir: {
      objects: (objects ?? {}) as Record<string, unknown>,
      container_objects: (container ?? {}) as Record<string, unknown>,
      fields: fields ?? [],
      sort: [], is_hidden: false,
    },
    ...rest,
  } as VisualSpec
}

describe('literals', () => {
  it('decodes PBIR literals', () => {
    expect(decodeLiteral("'text'")).toBe('text')
    expect(decodeLiteral("'it''s'")).toBe("it's")
    expect(decodeLiteral('12D')).toBe(12)
    expect(decodeLiteral('2L')).toBe(2)
    expect(decodeLiteral('1.5M')).toBe(1.5)
    expect(decodeLiteral('true')).toBe(true)
    expect(decodeLiteral('false')).toBe(false)
    expect(decodeLiteral('null')).toBeNull()
  })

  it('lit accepts expr, bare Literal and plain theme values', () => {
    expect(lit(L("'a'"))).toBe('a')
    expect(lit({ Literal: { Value: '3L' } })).toBe(3)
    expect(lit(14)).toBe(14)
    expect(lit(true)).toBe(true)
    expect(lit('#FFFFFF')).toBe('#FFFFFF')
    expect(litNumber(L('9D'))).toBe(9)
    expect(litBool(L('false'))).toBe(false)
    expect(litString(L("'x'"))).toBe('x')
    expect(litNumber(undefined)).toBeUndefined()
  })

  it('shades toward white (positive) and black (negative)', () => {
    expect(shade('#000000', 0.5)).toBe('#808080')
    expect(shade('#FFFFFF', -0.5)).toBe('#808080')
    expect(shade('#118DFF', 0)).toBe('#118DFF')
    expect(shade('#118DFF', 1)).toBe('#FFFFFF')
    expect(withAlpha('#FF0000', 0.5)).toBe('#FF000080')
  })

  it('resolves theme data colours by ColorId', () => {
    const tokens = { dataColors: ['#111111', '#222222', '#333333'], foreground: '#AAAAAA', background: '#BBBBBB' }
    expect(themeDataColor(0, 0, tokens)).toBe('#BBBBBB')
    expect(themeDataColor(1, 0, tokens)).toBe('#AAAAAA')
    expect(themeDataColor(2, 0, tokens)).toBe('#111111')
    expect(themeDataColor(4, 0, tokens)).toBe('#333333')
    expect(themeDataColor(2, 0.5, tokens)).toBe(shade('#111111', 0.5))
    const themed = { solid: { color: { expr: { ThemeDataColor: { ColorId: 3, Percent: -0.25 } } } } }
    expect(color(themed, tokens)).toBe(shade('#222222', -0.25))
  })

  it('resolves solid colours and named theme colours', () => {
    const tokens = {
      dataColors: ['#111111'], foreground: '#000000', background: '#FFFFFF',
      named: { foregroundNeutralSecondary: '#605E5C', tableAccent: '#0000FF' },
    }
    expect(color(solid('#123456'), tokens)).toBe('#123456')
    expect(color('tableAccent', tokens)).toBe('#0000FF')
    expect(color('#ABCDEF', tokens)).toBe('#ABCDEF')
    expect(color(undefined, tokens)).toBeUndefined()
  })
})

describe('fonts', () => {
  it('converts points to pixels', () => {
    expect(ptToPx(12)).toBe(16)
    expect(fontSizePx('12')).toBe(16)
    expect(fontSizePx(12)).toBe(16)
    expect(fontSizePx('24pt')).toBe(32)
    expect(fontSizePx('16px')).toBe(16)
    expect(fontSizePx('abc')).toBeUndefined()
  })

  it('parses font families and weights', () => {
    expect(parseFontFamily("'Segoe UI Bold', wf_segoe-ui_bold, helvetica")).toEqual({ family: 'Segoe UI', weight: 700 })
    expect(parseFontFamily('Segoe (Bold)')).toEqual({ family: 'Segoe', weight: 700 })
    expect(parseFontFamily('Calibri')).toEqual({ family: 'Calibri' })
  })

  it('builds a FontSpec with defaults', () => {
    expect(font(undefined, undefined, 9)).toEqual({ family: 'Segoe UI', sizePx: 12, weight: 400 })
    expect(font(L("'Calibri'"), L('24D'), 9, 600)).toEqual({ family: 'Calibri', sizePx: 32, weight: 600 })
  })
})

describe('defaults', () => {
  it('keeps the calibrated values', () => {
    expect(PBI_DEFAULTS.dataColors).toHaveLength(16)
    expect(PBI_DEFAULTS.dataColors[0]).toBe('#118DFF')
    expect(PBI_DEFAULTS.card.valueSizePt).toBe(27)
    expect(PBI_DEFAULTS.category.tallestBarShare).toBe(0.885)
    expect(PBI_DEFAULTS.slicer.dropdown.chevron).toEqual({ w: 15, h: 7, rightPx: 6, topPx: 12, color: '#777777', strokePx: 1.2 })
    expect(PBI_DEFAULTS.button.shadow).toBe('2px 3px 6px rgba(0, 0, 0, 0.35)')
  })
})

describe('resolveVisual precedence and mapping', () => {
  const plain = buildTheme(undefined)

  it('uses PBI defaults when nothing is set', () => {
    const r = resolveVisual(visual(), plain)
    expect(r.palette).toEqual([...PBI_DEFAULTS.dataColors])
    expect(r.container.padding).toEqual({ top: 5, right: 5, bottom: 5, left: 5 })
    expect(r.container.showBackground).toBe(true)
    expect(r.container.background).toBe('#FFFFFF')
    expect(r.container.border).toEqual({ show: false, color: '#E6E6E6', width: 1, radius: 0 })
    expect(r.title.font).toEqual({ family: 'Segoe UI', sizePx: 16, weight: 400 })
    expect(r.categoryAxis.minWidthPx).toBe(20)
    expect(r.categoryAxis.preferredWidthSet).toBe(false)
    expect(r.categoryAxis.concatenateLabels).toBe(true)
    expect(r.categoryAxis.innerPaddingPct).toBe(20)
  })

  it('visual objects beat the custom theme, which beats the defaults', () => {
    const theme = buildTheme({
      base_name: null,
      base: {},
      custom: {
        visualStyles: {
          '*': { '*': { title: [{ fontSize: 20 }] } },
          clusteredColumnChart: { '*': { title: [{ fontSize: 14, fontColor: solid('#333333') }] } },
        },
      },
    })
    const base = resolveVisual(visual(), theme)
    expect(base.title.font.sizePx).toBe(ptToPx(14)) // [type]['*'] before ['*']['*']
    expect(base.title.color).toBe('#333333')
    const own = resolveVisual(visual({ container: { title: [{ properties: { fontSize: L('10D') } }] } }), theme)
    expect(own.title.font.sizePx).toBe(ptToPx(10))
    expect(own.title.color).toBe('#333333') // other props still come from the theme
    const star = resolveVisual(visual({ visual_type: 'lineChart' }), theme)
    expect(star.title.font.sizePx).toBe(ptToPx(20))
  })

  it('only selector-less entries count as the visual-level setting', () => {
    const objects = {
      legend: [
        { selector: { metadata: 'x' }, properties: { show: L('false') } },
        { properties: { show: L('true'), position: L("'Bottom'") } },
      ],
    }
    const r = resolveVisual(visual({ objects }), plain)
    expect(r.legend.show).toBe(true)
    expect(r.legend.position).toBe('Bottom')
  })

  it('container: background defaults on for data visuals and off for chrome', () => {
    for (const type of ['textbox', 'shape', 'basicShape', 'image', 'actionButton', 'visualGroup', 'someCustom']) {
      const spec = visual({ visual_type: type, data_status: type === 'someCustom' ? 'unsupported_type' : 'ok' })
      expect(resolveVisual(spec, plain).container.showBackground).toBe(false)
      expect(resolveVisual(spec, plain).container.padding.top).toBe(0)
    }
    const filled = visual({
      visual_type: 'textbox',
      container: { background: [{ properties: { color: solid('#FF0000') } }] },
    })
    expect(resolveVisual(filled, plain).container.showBackground).toBe(true)
    expect(resolveVisual(filled, plain).container.background).toBe('#FF0000')
  })

  it('container: transparency, border and padding', () => {
    const r = resolveVisual(
      visual({
        container: {
          background: [{ properties: { show: L('true'), color: solid('#00FF00'), transparency: L('25D') } }],
          border: [{ properties: { show: L('true'), color: solid('#0000FF'), width: L('2D'), radius: L('6D') } }],
          padding: [{ properties: { top: L('1D'), left: L('2D') } }],
        },
      }),
      plain,
    )
    expect(r.container.alpha).toBeCloseTo(0.75)
    expect(r.container.border).toEqual({ show: true, color: '#0000FF', width: 2, radius: 6 })
    expect(r.container.padding).toEqual({ top: 1, right: 5, bottom: 5, left: 2 })
  })

  it('title: show defaults, text, alignment, and the switch alone', () => {
    for (const type of ['textbox', 'card', 'slicer', 'shape', 'pivotTable', 'tableEx', 'visualGroup'])
      expect(resolveVisual(visual({ visual_type: type }), plain).title.show).toBe(false)
    expect(resolveVisual(visual(), plain).title.show).toBe(true)
    expect(resolveVisual({ ...visual(), pbir: null }, plain).title.show).toBe(true)
    expect(resolveVisual({ ...visual({ visual_type: 'card' }), pbir: null }, plain).title.show).toBe(true)
    const r = resolveVisual(
      visual({
        container: { title: [{ properties: { show: L('true'), text: L("'Hello'"), alignment: L("'center'") } }] },
      }),
      plain,
    )
    expect(r.title).toMatchObject({ show: true, text: 'Hello', align: 'center' })
    const measureTitle = resolveVisual(
      visual({ container: { title: [{ properties: { show: L('true'), text: { expr: { Measure: {} } } } }] } }),
      plain,
    )
    expect(measureTitle.title.text).toBeUndefined()
    expect(measureTitle.title.showSetting).toBe(true)
  })

  it('palette follows the theme data colours; dataPoint.fill is the single fill', () => {
    const theme = buildTheme({ base_name: null, base: { dataColors: ['#AAAAAA', '#BBBBBB'] }, custom: {} })
    const r = resolveVisual(visual({ objects: { dataPoint: [{ properties: { fill: solid('#CC0000') } }] } }), theme)
    expect(r.palette).toEqual(['#AAAAAA', '#BBBBBB'])
    expect(r.fill).toBe('#CC0000')
    expect(buildTheme({ base_name: null, base: { dataColors: ['#1'] }, custom: { dataColors: ['#2'] } }).tokens.dataColors).toEqual(['#2'])
  })

  const fields: PbirField[] = [
    { role: 'Category', table: 'Product', name: 'Category', is_measure: false, query_ref: 'Product.Category' },
    { role: 'Y', table: 'Sales', name: 'Total Sales', display_name: 'Revenue', is_measure: true, query_ref: 'Sales.Total Sales' },
  ]

  it('fillByValue: measure selectors by name and display name', () => {
    const objects = {
      dataPoint: [{ selector: { metadata: 'Sales.Total Sales' }, properties: { fill: solid('#112233') } }],
    }
    const r = resolveVisual(visual({ objects, fields }), plain)
    expect(r.fillByValue.byMeasure['Total Sales']).toBe('#112233')
    expect(r.fillByValue.byMeasure.Revenue).toBe('#112233')
  })

  it('fillByValue: category selectors only when the entity matches the field table', () => {
    const scope = (entity: string, value: string) => ({
      data: [{ scopeId: { Comparison: { ComparisonKind: 0,
        Left: { Column: { Expression: { SourceRef: { Entity: entity } }, Property: 'Category' } },
        Right: { Literal: { Value: value } } } } }],
    })
    const objects = {
      dataPoint: [
        { selector: scope('Product', "'Bikes'"), properties: { fill: solid('#FF0000') } },
        { selector: scope('Gone', "'Cars'"), properties: { fill: solid('#00FF00') } },
      ],
    }
    const r = resolveVisual(visual({ objects, fields }), plain)
    expect(r.fillByValue.byCategory).toEqual({ Bikes: '#FF0000' })
  })

  it('category axis: min category width, concatenation and padding', () => {
    const r = resolveVisual(
      visual({
        objects: {
          categoryAxis: [{ properties: { show: L('false'), preferredCategoryWidth: L('60D'), concatenateLabels: L('false'), innerPadding: L('40D') } }],
        },
      }),
      plain,
    )
    expect(r.categoryAxis).toMatchObject({ show: false, minWidthPx: 60, preferredWidthSet: true, concatenateLabels: false, innerPaddingPct: 40 })
    const legacy = resolveVisual(visual({ objects: { categoryAxis: [{ properties: { minCategoryWidth: L('33D') } }] } }), plain)
    expect(legacy.categoryAxis.minWidthPx).toBe(33)
  })

  it('value axis, labels, legend and slices', () => {
    const r = resolveVisual(
      visual({
        objects: {
          valueAxis: [{ properties: { gridlineShow: L('false'), labelPrecision: L('1D'), labelDisplayUnits: L('1000D') } }],
          labels: [{ properties: { show: L('true'), labelPrecision: L('2D'), labelDisplayUnits: L('0D'),
            enableValueDataLabel: L('false'), enableDetailDataLabel: L('true'),
            detailContentType: L("'Percent of total'"), labelContentLayout: L("'OneLine'") } }],
          legend: [{ properties: { show: L('true'), showTitle: L('false'), position: L("'Right'") } }],
          slices: [{ properties: { innerRadiusRatio: L('60D') } }],
        },
      }),
      plain,
    )
    expect(r.valueAxis).toMatchObject({ gridlineShow: false, labelPrecision: 1, labelDisplayUnits: 1000 })
    expect(r.labels).toMatchObject({ show: true, precision: 2, displayUnits: 0, detailPercent: true, contentLayout: 'OneLine' })
    expect(r.legend).toMatchObject({ show: true, showTitle: false, position: 'Right' })
    expect(r.slices.innerRadiusRatio).toBeCloseTo(0.6)
  })

  it('card: value and category label styling', () => {
    const r = resolveVisual(visual({ visual_type: 'card' }), plain)
    expect(r.card.valueFont).toEqual({ family: 'Segoe UI', sizePx: 36, weight: 600 })
    expect(r.card.valueColor).toBe(plain.tokens.foreground)
    expect(r.card.categoryShow).toBe(true)
    expect(r.card.categoryFont.sizePx).toBe(16)
    expect(r.card.categoryColor).toBe('#605E5C')
  })

  it('slicer: header and items', () => {
    const r = resolveVisual(
      visual({
        visual_type: 'slicer',
        objects: { header: [{ properties: { show: L('false'), text: L("'Pick'") } }], items: [{ properties: { textSize: L('12D'), fontColor: solid('#111111') } }] },
      }),
      plain,
    )
    expect(r.slicer.headerShow).toBe(false)
    expect(r.slicer.headerText).toBe('Pick')
    expect(r.slicer.itemsFont.sizePx).toBe(16)
    expect(r.slicer.itemsColor).toBe('#111111')
    expect(resolveVisual(visual({ visual_type: 'slicer' }), plain).slicer.headerShow).toBe(true)
  })

  it('table: headers, banding, grid, widths, alignment, totals', () => {
    const r = resolveVisual(
      visual({
        visual_type: 'pivotTable',
        objects: {
          columnHeaders: [{ properties: { bold: L('true'), fontColor: solid('#222222'), backColor: solid('#EEEEEE') } }],
          values: [{ properties: { fontColorPrimary: solid('#333333'), backColorPrimary: solid('#FFFFFF'), valuesOnRow: L('true') } }],
          grid: [{ properties: { gridHorizontal: L('false'), gridVerticalColor: solid('#FF0000'), gridVertical: L('true'), rowPadding: L('8D') } }],
          columnWidth: [
            { properties: { value: L('120D') } },
            { selector: { metadata: 'Sales.Total Sales' }, properties: { value: L('200D') } },
          ],
          columnFormatting: [{ selector: { metadata: 'Sales.Total Sales' }, properties: { alignment: L("'Right'") } }],
          total: [{ properties: { totals: L('false'), label: L("'Grand'") } }],
          rowHeaders: [{ properties: { showExpandCollapseButtons: L('false') } }],
        },
      }),
      plain,
    )
    expect(r.table.headerFont.weight).toBe(700)
    expect(r.table.headerColor).toBe('#222222')
    expect(r.table.headerBackground).toBe('#EEEEEE')
    expect(r.table.valuesColor).toBe('#333333')
    expect(r.table.backSecondary).toBe('#F3F2F1')
    expect(r.table.gridHorizontal.show).toBe(false)
    expect(r.table.gridVertical).toEqual({ show: true, color: '#FF0000', weight: 1 })
    expect(r.table.rowPaddingPx).toBe(8)
    expect(r.table.defaultColumnWidth).toBe(120)
    expect(r.table.columnWidths['Sales.Total Sales']).toBe(200)
    expect(r.table.alignments['Sales.Total Sales']).toBe('Right')
    expect(r.table).toMatchObject({ totalsShow: false, totalLabel: 'Grand', showExpandCollapse: false, valuesOnRow: true })
    const dflt = resolveVisual(visual({ visual_type: 'pivotTable' }), plain)
    expect(dflt.table).toMatchObject({ totalsShow: true, totalLabel: 'Total', rowPaddingPx: 3, valuesOnRow: false })
    expect(dflt.table.headerFont.weight).toBe(600)
  })

  it('map: gradient stops, defaults and null colouring', () => {
    const r = resolveVisual(
      visual({
        visual_type: 'filledMap',
        objects: {
          dataPoint: [{ properties: { nullColoringStrategy: L("'asZero'"), fillRule: { linearGradient3: {
            min: { color: solid('#0000FF'), value: L('0D') }, mid: { color: solid('#FFFFFF') }, max: { color: solid('#FF0000'), value: L('100D') } } } } }],
          defaultColors: [{ properties: { defaultColor: solid('#DDDDDD'), borderColor: solid('#000000') } }],
          shape: [{ properties: { projectionEnum: L("'albersUsa'") } }],
        },
      }),
      plain,
    )
    expect(r.map.gradient).toMatchObject({ min: '#0000FF', mid: '#FFFFFF', max: '#FF0000', minValue: 0, maxValue: 100 })
    expect(r.map).toMatchObject({ defaultFill: '#DDDDDD', borderColor: '#000000', nullAsZero: true, projection: 'albersUsa' })
    expect(resolveVisual(visual({ visual_type: 'filledMap' }), plain).map).toMatchObject({ defaultFill: '#E6E6E6', borderColor: '#FFFFFF', nullAsZero: false })
  })

  it('page background and alpha', () => {
    expect(pageBackground({ background: {} }, plain)).toBe('#FFFFFF')
    expect(pageBackground({ background: { properties: { color: solid('#EEEEEE') } } }, plain)).toBe('#EEEEEE')
    expect(pageBackground({ background: { properties: { color: solid('#000000'), transparency: L('50D') } } }, plain)).toBe('#00000080')
  })

  it('fieldColumnKey picks the right result column', () => {
    const avail = ['Product.Category', 'Total Sales', 'Sum of Amount']
    const used = new Set<string>()
    expect(fieldColumnKey({ role: 'Y', name: 'Total Sales', is_measure: true }, avail, used)).toBe('Total Sales')
    expect(fieldColumnKey({ role: 'Y', table: 'S', name: 'Amount', display_name: 'Sum of Amount', is_measure: false, aggregate: 'Sum' }, avail, used)).toBe('Sum of Amount')
    expect(fieldColumnKey({ role: 'Category', table: 'Product', name: 'Category', is_measure: false }, avail, used)).toBe('Product.Category')
    expect(fieldColumnKey({ role: 'Y', name: 'Total Sales', is_measure: true }, avail, used)).toBeUndefined() // used
    expect(fieldColumnKey({ role: 'Category', table: 'X', name: 'Y', display_name: 'Product.Category', is_measure: false }, avail)).toBe('Product.Category')
  })
})

describe('chrome', () => {
  const plain = buildTheme(undefined)

  it('state properties: state > default selector > unselected entry', () => {
    const objects = {
      fill: [
        { properties: { fillColor: solid('#111111') } },
        { selector: { id: 'default' }, properties: { fillColor: solid('#222222') } },
        { selector: { id: 'hover' }, properties: { fillColor: solid('#333333') } },
      ],
      outline: [{ properties: { weight: L('4D') } }],
    }
    expect(color(stateProp(objects, 'fill', 'fillColor', 'hover'), plain.tokens)).toBe('#333333')
    expect(color(stateProp(objects, 'fill', 'fillColor', 'default'), plain.tokens)).toBe('#222222')
    expect(color(stateProp(objects, 'fill', 'fillColor', 'pressed'), plain.tokens)).toBe('#222222')
    expect(litNumber(stateProp(objects, 'outline', 'weight', 'hover'))).toBe(4)
    expect(stateProp(objects, 'icon', 'x')).toBeUndefined()
  })

  it('button style: fill, outline, text margins, icons, shadow and glow', () => {
    const spec = visual({
      visual_type: 'actionButton',
      objects: {
        fill: [{ properties: { fillColor: solid('#101010'), transparency: L('50D') } }],
        outline: [{ properties: { lineColor: solid('#202020'), weight: L('3D') } }],
        text: [{ properties: { show: L('true'), text: L("'Go'"), leftMargin: L('10D'), horizontalAlignment: L("'left'") } }],
        shadow: [{ properties: { show: L('true') } }],
        glow: [{ properties: { show: L('true'), color: solid('#00FF00') } }],
        shape: [{ properties: { roundEdge: L('8D') } }],
      },
    })
    const b = resolveButton(spec, plain)
    expect(b.fill).toBe('#10101080')
    expect(b.outline).toEqual({ color: '#202020', weightPx: 3 })
    expect(b.text.value).toBe('Go')
    expect(b.text.margins).toEqual({ top: 2, right: 2, bottom: 2, left: 10 })
    expect(b.text.align).toBe('left')
    expect(b.text.baselineShiftEm).toBe(0.09)
    expect(b.shadow).toBe('2px 3px 6px rgba(0, 0, 0, 0.35)')
    expect(b.glow).toBe('0 0 8px #00FF00')
    expect(b.roundedPx).toBe(8)
    const bare = resolveButton(visual({ visual_type: 'actionButton' }), plain)
    expect(bare.fill).toBeUndefined()
    expect(bare.outline).toEqual({ color: '#B3B0AD', weightPx: 1 })
    expect(bare.icon).toBeUndefined()
  })

  it('button icons: built-in shapes and custom images', () => {
    const custom = resolveButton(
      visual({
        visual_type: 'actionButton',
        objects: { icon: [{ properties: { shapeType: L("'custom'"), image: { expr: { ResourcePackageItem: { PackageName: 'RegisteredResources', ItemName: 'icon.svg' } } } } }] },
      }),
      plain,
    )
    expect(custom.icon).toMatchObject({ shape: 'custom', customResource: 'icon.svg' })
    const builtin = resolveButton(visual({ visual_type: 'actionButton', objects: { icon: [{ properties: { shapeType: L("'back'") } }] } }), plain)
    expect(builtin.icon?.shape).toBe('back')
  })

  it('per-state button fills', () => {
    const spec = visual({
      visual_type: 'actionButton',
      objects: {
        fill: [
          { selector: { id: 'default' }, properties: { fillColor: solid('#AAAAAA') } },
          { selector: { id: 'hover' }, properties: { fillColor: solid('#BBBBBB') } },
        ],
      },
    })
    expect(resolveButton(spec, plain, 'hover').fill).toBe('#BBBBBB')
    expect(resolveButton(spec, plain, 'default').fill).toBe('#AAAAAA')
  })

  it('shapes: kinds, fill, outlines, legacy outline and rotation', () => {
    const rect = resolveShape(
      visual({
        visual_type: 'shape',
        objects: {
          shape: [{ properties: { tileShape: L("'roundedRectangle'"), roundEdge: L('12D') } }],
          fill: [{ properties: { fillColor: solid('#445566') } }],
          outline: [{ properties: { lineColor: solid('#778899'), weight: L('2D') } }],
        },
      }),
      plain,
    )
    expect(rect).toMatchObject({ kind: 'roundedRectangle', fill: '#445566', roundedPx: 12 })
    expect(rect.line).toEqual({ color: '#778899', weightPx: 2 })
    const legacy = resolveShape(visual({ visual_type: 'shape', objects: { fill: [{ properties: {} }] } }), plain)
    expect(legacy.line).toEqual({ color: shade('#118DFF', -0.25), weightPx: 1 })
    expect(legacy.fill).toBe('#118DFF')
    const noFill = resolveShape(visual({ visual_type: 'shape', objects: { fill: [{ properties: { show: L('false') } }], outline: [{ properties: {} }] } }), plain)
    expect(noFill.fill).toBeUndefined()
    const line = resolveShape(visual({ visual_type: 'shape', objects: { shape: [{ properties: { tileShape: L("'line'") } }], rotation: [{ properties: { shapeAngle: L('90D') } }], outline: [{ properties: {} }] } }), plain)
    expect(line).toMatchObject({ kind: 'line', rotation: 90, vertical: true })
    const flat = resolveShape(visual({ visual_type: 'shape', objects: { shape: [{ properties: { tileShape: L("'line'") } }], outline: [{ properties: {} }] } }), plain)
    expect(flat.vertical).toBe(false)
    expect(resolveShape(visual({ visual_type: 'shape', objects: { shape: [{ properties: { tileShape: L("'oval'") } }] } }), plain).kind).toBe('oval')
    expect(resolveShape(visual({ visual_type: 'shape', objects: { shape: [{ properties: { tileShape: L("'triangle'") } }] } }), plain).kind).toBe('triangle')
  })

  it('image fit and resource items', () => {
    const fit = (v: string) => imageFit({ image: [{ properties: { scaling: L(`'${v}'`) } }] })
    expect(fit('Fit')).toBe('fill')
    expect(fit('Fill')).toBe('cover')
    expect(fit('Normal')).toBe('none')
    expect(imageFit({})).toBe('none')
    expect(resourceItem({ a: [{ ResourcePackageItem: { ItemName: 'x.png' } }] })).toBe('x.png')
    expect(resourceItem({})).toBeUndefined()
  })
})
