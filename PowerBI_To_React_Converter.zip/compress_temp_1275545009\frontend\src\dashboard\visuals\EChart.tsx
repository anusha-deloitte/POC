import type { EChartsOption } from 'echarts'
import * as echarts from 'echarts'
import { useEffect, useRef } from 'react'

type AxisLike = { data?: unknown[] } | undefined

function categoriesOf(option: EChartsOption): string {
  const x = (Array.isArray(option.xAxis) ? option.xAxis[0] : option.xAxis) as AxisLike
  const y = (Array.isArray(option.yAxis) ? option.yAxis[0] : option.yAxis) as AxisLike
  return JSON.stringify(x?.data ?? y?.data ?? null)
}

export interface HoverItem {
  name: string
  seriesName: string
  dataIndex: number
}

/** ECharts' own tooltip off (a visual that has a report-page tooltip shows that instead). */
export function withoutTooltip(option: EChartsOption): EChartsOption {
  return { ...option, tooltip: { ...(option.tooltip as object), show: false } as EChartsOption['tooltip'] }
}

/** An ECharts instance. Clicks reach `onItemClick` only for series items (axis labels and
 * legends don't select); hovering a (possibly shortened) axis label sets the element's `title`
 * to the full label; `keepScrollWindow` keeps the current dataZoom window when the same
 * categories are re-applied. */
export function EChart({
  option,
  onItemClick,
  onItemHover,
  keepScrollWindow = false,
}: {
  option: EChartsOption
  onItemClick?: (name: string) => void
  /** the series item under the pointer, null when it leaves (axis labels never count) */
  onItemHover?: (item: HoverItem | null) => void
  keepScrollWindow?: boolean
}) {
  const ref = useRef<HTMLDivElement>(null)
  const chart = useRef<echarts.ECharts | null>(null)
  const clickRef = useRef(onItemClick)
  clickRef.current = onItemClick
  const hoverRef = useRef(onItemHover)
  hoverRef.current = onItemHover
  const lastCategories = useRef<string | null>(null)

  useEffect(() => {
    if (!ref.current) return
    const el = ref.current
    chart.current = echarts.init(el)
    chart.current.on('click', (p) => {
      if (p.componentType === 'series') clickRef.current?.(String(p.name))
    })
    chart.current.on('mouseover', (p) => {
      if (p.componentType === 'xAxis' || p.componentType === 'yAxis')
        el.title = String((p as { value?: unknown }).value ?? '')
      else if (p.componentType === 'series')
        hoverRef.current?.({
          name: String(p.name ?? ''),
          seriesName: String(p.seriesName ?? ''),
          dataIndex: p.dataIndex,
        })
    })
    chart.current.on('mouseout', (p) => {
      if (p.componentType === 'xAxis' || p.componentType === 'yAxis') el.title = ''
      else if (p.componentType === 'series') hoverRef.current?.(null)
    })
    const ro = new ResizeObserver(() => chart.current?.resize())
    ro.observe(el)
    return () => {
      ro.disconnect()
      chart.current?.dispose()
      chart.current = null
    }
  }, [])

  useEffect(() => {
    const c = chart.current
    if (!c) return
    let next = option
    const categories = categoriesOf(option)
    if (keepScrollWindow && lastCategories.current === categories && option.dataZoom) {
      const current = (c.getOption() as { dataZoom?: { startValue?: number; endValue?: number }[] }).dataZoom
      if (current?.length) {
        const zooms = (Array.isArray(option.dataZoom) ? option.dataZoom : [option.dataZoom]) as Record<string, unknown>[]
        next = {
          ...option,
          dataZoom: zooms.map((z, i) => ({
            ...z,
            startValue: current[i]?.startValue ?? z.startValue,
            endValue: current[i]?.endValue ?? z.endValue,
          })) as EChartsOption['dataZoom'],
        }
      }
    }
    lastCategories.current = categories
    c.setOption(next, { notMerge: true })
  }, [option, keepScrollWindow])

  return <div ref={ref} className="h-full w-full" data-testid="echart" />
}
