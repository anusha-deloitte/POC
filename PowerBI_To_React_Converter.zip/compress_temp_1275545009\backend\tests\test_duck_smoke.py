from datetime import date

from app.runtime.engine import DimensionRef, MeasureRefSpec, QuerySpec
from tests.duck import DuckWorld


def _world():
    return DuckWorld(
        {
            "Sales": (["Id", "Key", "Amount"], [(1, 1, 10.0), (2, 1, 5.0), (3, 2, 7.0), (4, 3, 1.0)]),
            "Dim": (["Id", "Name"], [(1, "a"), (2, "b"), (3, "c")]),
        },
        rels=[("Sales", "Key", "Dim", "Id")],
        measures={"Total": "SUM(Sales[Amount])"},
    )


def test_card_and_grouped():
    w = _world()
    assert w.value("Total") == 23.0
    rows = w.run(
        QuerySpec(
            dimensions=[DimensionRef(table="Dim", column="Name")],
            measures=[MeasureRefSpec(name="Total")],
        )
    )
    assert rows == [("a", 15.0), ("b", 7.0), ("c", 1.0)]
    assert date(2024, 1, 1).year == 2024
