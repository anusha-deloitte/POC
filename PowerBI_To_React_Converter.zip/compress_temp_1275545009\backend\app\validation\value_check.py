"""Slicer value check for IFERROR(VALUE(<slicer text>)) measures (phase 06.8 assumption).

Power BI's VALUE() fails for selections that are neither numbers nor one of the literals the
measure compares the selection with; IFERROR then returns its fallback. The translation relies on
that, so the pipeline lists the slicer values that would trigger it (informational, never a
failure).
"""

from __future__ import annotations

from typing import Any

from app.binding.resolver import quote_ident, sql_string
from app.dax.compiler import DaxUnsupported, MeasureCompiler, qcol
from app.ir.model import SemanticModel
from app.services.query_audit import audit_stage

_MAX_OFFENDING = 20


def value_assumptions(model: SemanticModel) -> dict[tuple[str, str], tuple[str, ...]]:
    """(table, column) -> compared literals, for every IFERROR measure relying on VALUE of a
    slicer selection."""
    compiler = MeasureCompiler(model)
    out: dict[tuple[str, str], list[str]] = {}
    for table in model.tables:
        for measure in table.measures:
            try:
                compiled = compiler.compile_measure(measure.name)
            except DaxUnsupported:
                continue
            for tbl, col, literals in compiled.value_assumptions:
                merged = out.setdefault((tbl, col), [])
                for lit in literals:
                    if lit not in merged:
                        merged.append(lit)
    return {key: tuple(vals) for key, vals in out.items()}


def value_check_sql(physical: str, table: str, column: str, literals: tuple[str, ...]) -> str:
    """Distinct non-blank values of T[c] that are neither numbers nor a compared literal
    (case-insensitive)."""
    col = qcol(table, column)
    cond = f"{col} IS NOT NULL AND TRY_CAST(TRIM({col}) AS NUMBER) IS NULL"
    if literals:
        listed = ", ".join(f"UPPER({sql_string(x)})" for x in literals)
        cond += f" AND UPPER(TRIM({col})) NOT IN ({listed})"
    return (
        f"SELECT DISTINCT {col} AS {quote_ident('value')}\n"  # noqa: S608
        f"FROM {physical} AS {quote_ident(table)}\nWHERE {cond}\n"
        f"ORDER BY 1 LIMIT {_MAX_OFFENDING}"
    )


def run_value_check(engine: Any, model: SemanticModel, cursor: Any) -> list[dict]:
    """[{table, column, literals, offending, error}] for every slicer text assumption."""
    results: list[dict] = []
    for (table, column), literals in sorted(value_assumptions(model).items()):
        entry: dict = {
            "table": table, "column": column, "literals": list(literals),
            "offending": [], "error": None,
        }  # fmt: skip
        try:
            sql = value_check_sql(engine._physical(table), table, column, literals)
            with audit_stage(cursor, "validation", "slicer_value_check"):
                cursor.execute(sql)
                entry["offending"] = [str(r[0]) for r in cursor.fetchall()]
        except Exception as e:  # noqa: BLE001 - informational, never a failure
            entry["error"] = str(e)[:300]
        results.append(entry)
    return results
