import type { AuthMethod } from '../api/types'

export const AUTH_LABELS: Record<AuthMethod, string> = {
  key_pair: 'Key pair (JWT) — recommended',
  external_browser: 'External browser (SSO)',
  password: 'Username & password',
  oauth_client_credentials: 'OAuth client credentials',
  pat: 'Programmatic access token',
}
