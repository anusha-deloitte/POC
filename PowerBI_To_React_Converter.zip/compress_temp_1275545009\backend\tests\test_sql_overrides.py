"""Phase 08: hand-edited pane SQL (validation, placeholders, live use, endpoints)."""

from __future__ import annotations

import pytest

from app.runtime.engine import FilterClause
from app.services import sql_overrides as so
from tests.duck import DuckWorld
from tests.phase08 import BAR, CARD, PAGE, World
from tests.test_api import client  # noqa: F401

# ------------------------------------------------------------------ validation


@pytest.mark.parametrize(
    "sql",
    [
        "SELECT 1",
        "  -- comment\nselect 1;",
        "/* c */ WITH a AS (SELECT 1) SELECT * FROM a",
        "SELECT ';' AS semi, \"a;b\" FROM t",
        "SELECT {{filters}} FROM t WHERE {{filters:Sales}}",
    ],
)
def test_valid_sql(sql):
    assert so.validate_sql(sql).rstrip().endswith(sql.rstrip().rstrip(";").rstrip()[-5:])


@pytest.mark.parametrize(
    ("sql", "message"),
    [
        ("", "empty"),
        ("DELETE FROM t", "only a SELECT or WITH query can replace a pane's SQL"),
        ("-- only a comment\nUPDATE t SET a = 1", "only a SELECT or WITH query"),
        ("SELECT 1; SELECT 2", "only one SQL statement is allowed"),
        ("SELECT {{nope}} FROM t", "unknown placeholder {{nope}}"),
        ("SELECT 1 WHERE {{filters:}}", "{{filters:<table>}} needs a model table name"),
    ],
)
def test_invalid_sql(sql, message):
    with pytest.raises(so.SqlOverrideError, match=message.replace("{", r"\{").replace("}", r"\}")):
        so.validate_sql(sql)


def test_trailing_semicolon_is_removed_and_text_is_trimmed():
    assert so.validate_sql("  SELECT 1 ;;  ") == "SELECT 1"


@pytest.mark.parametrize(
    ("sql", "fragment"),
    [
        ("SELECT 1 WHERE a NOT IN (NULL)", "NOT IN (NULL)"),
        ("SELECT 1 WHERE a NOT IN (NULL, 1)", "NOT IN (NULL, ...)"),
        ("SELECT 1 WHERE a IN (NULL, 1)", "IN (NULL, ...)"),
        ("SELECT 1 WHERE a <> NULL", "`col <> NULL` is never true: use `col IS NOT NULL`"),
        ("SELECT 1 WHERE a != NULL", "`col <> NULL` is never true"),
        ("SELECT 1 WHERE a = NULL", "`col = NULL` is never true: use `col IS NULL`"),
    ],
)
def test_null_comparison_warnings(sql, fragment):
    warnings = so.null_comparison_warnings(sql)
    assert any(fragment in w for w in warnings), warnings


def test_null_warnings_ignore_strings_comments_and_correct_sql():
    clean = "SELECT 'a = NULL' AS x -- b <> NULL\nFROM t WHERE c IS NULL AND d IS NOT NULL"
    assert so.null_comparison_warnings(clean) == []


# ------------------------------------------------------------------ rendering


@pytest.fixture()
def duck():
    return DuckWorld(
        {
            "Sales": (["k", "amount", "d"], [(1, 10.0, 1), (2, 20.0, 2)]),
            "Dim": (["d", "name"], [(1, "a"), (2, "b")]),
        },
        rels=[("Sales", "d", "Dim", "d")],
    )


def test_filters_without_any_filter_is_one_equals_one(duck):
    sql, unapplied = so.render('SELECT * FROM x WHERE {{filters}}', [], duck.engine())
    assert sql == "SELECT * FROM x WHERE 1=1" and unapplied == []


def test_render_uses_the_engine_predicates(duck):
    f = FilterClause(table="Sales", column="k", values=[1, 2])
    alias, predicate = duck.engine().filter_predicate(f)
    assert alias == '"Sales"'
    sql, unapplied = so.render(
        'SELECT * FROM t AS "Sales" WHERE {{filters}}', [f], duck.engine()
    )
    assert sql == f'SELECT * FROM t AS "Sales" WHERE {predicate}' and unapplied == []
    assert '"Sales"."k"' in predicate


def test_table_placeholder_and_unreferenced_tables(duck):
    fs = [
        FilterClause(table="Sales", column="k", values=[1]),
        FilterClause(table="Dim", column="name", values=["a"]),
        FilterClause(table="Gone", column="x", values=["z"]),
    ]
    sql, unapplied = so.render(
        'SELECT * FROM s AS "Sales" JOIN d AS "Dim" WHERE {{filters:dim}} AND {{filters:Gone}}',
        fs,
        _TolerantEngine(duck.engine()),
    )
    assert '"Dim"."name"' in sql and '"Sales"."k"' not in sql
    assert sql.endswith("AND 1=1")  # Gone is not in the SQL: nothing is guessed
    assert unapplied == ["Gone", "Sales"]  # reported, never guessed


class _TolerantEngine:
    """Engine whose unknown tables still spell a predicate (so absence is reported)."""

    def __init__(self, engine):
        self.engine = engine

    def filter_predicate(self, f):
        if self.engine.model.table(f.table) is None:
            return f'"{f.table}"', f'"{f.table}"."{f.column}" IN (\'{f.values[0]}\')'
        return self.engine.filter_predicate(f)


def test_placeholders_inside_strings_are_plain_text(duck):
    sql, _ = so.render("SELECT '{{filters}}' AS s", [], duck.engine())
    assert sql == "SELECT '{{filters}}' AS s"


def test_filter_predicate_matches_generated_sql_spelling(duck):
    from app.runtime.engine import MeasureRefSpec, QuerySpec

    f = FilterClause(table="Dim", column="name", values=["a"])
    _, predicate = duck.engine().filter_predicate(f)
    generated, _ = duck.engine().build_sql(
        QuerySpec(measures=[MeasureRefSpec(table="Sales", column="amount", aggregate="sum")],
                  filters=[f])  # fmt: skip
    )
    assert predicate in generated


def test_storage_roundtrip(tmp_path):
    rec = so.save_override(tmp_path, "p", "v", "SELECT 1;", "SELECT 0")
    assert rec["sql"] == "SELECT 1" and rec["base_sql"] == "SELECT 0" and rec["saved_at"]
    assert so.load_overrides(tmp_path)["p/v"]["sql"] == "SELECT 1"
    assert so.overrides_mtime(tmp_path) > 0
    assert so.delete_override(tmp_path, "p", "v") is True
    assert so.delete_override(tmp_path, "p", "v") is False
    with pytest.raises(so.SqlOverrideError):
        so.save_override(tmp_path, "p", "v", "DROP TABLE x", None)


# ------------------------------------------------------------------ endpoints


@pytest.fixture()
def world(client, contoso_pbip, monkeypatch):  # noqa: F811
    return World(client, contoso_pbip, monkeypatch)


def test_editor_payload(world):
    r = world.get("sql-editor", page=PAGE, visual=BAR)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["expected_columns"] == ["Product.Category", "Total Sales"]
    assert body["base_sql"].lstrip().startswith(("SELECT", "WITH")) and body["base_error"] is None
    tables = {t["table"]: t["alias"] for t in body["filter_tables"]}
    assert tables["Product"] == '"Product"'
    assert "Customer" in tables  # a slicer target on the page
    assert body["override"] is None and body["pane"]
    assert world.get("sql-editor", page=PAGE, visual="nope").status_code == 404


def test_test_endpoint_runs_and_reports_missing_columns(world):
    world.responder = lambda sql: (["Total Sales"], [(5.0,), (6.0,)])
    sql = 'SELECT 1 AS "Total Sales" FROM CONTOSO.SALES.FACT_SALES AS "Sales" WHERE {{filters}}'
    body = {
        "page": PAGE, "visual": BAR, "connection_id": world.conn_id, "sql": sql,
        "filters": [{"table": "Sales", "column": "Quantity", "values": [3]}],
    }  # fmt: skip
    r = world.post("sql-overrides/test", body)
    assert r.status_code == 200, r.text
    out = r.json()
    assert out["missing_columns"] == ["Product.Category"] and out["row_count"] == 2
    assert out["columns"] == ["Total Sales"] and out["error"] is None
    assert out["has_filters_placeholder"] is True and out["unapplied_filter_tables"] == []
    assert '"Sales"."Quantity"' in out["rendered_sql"] and out["query_id"]
    assert out["expected_columns"] == ["Product.Category", "Total Sales"]
    # the run is audited as a setup query labelled "sql edit test"
    setup = world.get("query-audit", kind="setup").json()["records"]
    assert setup and setup[0]["check"] == "sql edit test"


def test_test_endpoint_surfaces_errors_warnings_and_rejections(world):
    world.responder = lambda sql: (_ for _ in ()).throw(RuntimeError("invalid identifier"))
    sql = "SELECT 1 WHERE x <> NULL"
    out = world.post(
        "sql-overrides/test",
        {"page": PAGE, "visual": CARD, "connection_id": world.conn_id, "sql": sql},
    ).json()
    assert out["error"] == "invalid identifier"
    assert any("<> NULL" in w for w in out["null_comparison_warnings"])
    assert out["has_filters_placeholder"] is False
    bad = world.post(
        "sql-overrides/test",
        {"page": PAGE, "visual": CARD, "connection_id": world.conn_id, "sql": "DROP TABLE x"},
    )
    assert bad.status_code == 422


def test_save_list_delete(world):
    ok = {"page": PAGE, "visual": CARD, "sql": 'SELECT 1 AS "Total Sales"'}
    assert world.client.put(world.url("sql-overrides"), json={**ok, "sql": "DROP x"}).status_code == 422
    saved = world.client.put(world.url("sql-overrides"), json=ok)
    assert saved.status_code == 200, saved.text
    override = saved.json()["override"]
    assert override["sql"] == ok["sql"] and "SUM" in override["base_sql"]
    assert [o["visual"] for o in world.get("sql-overrides").json()["overrides"]] == [CARD]
    assert world.get("sql-editor", page=PAGE, visual=CARD).json()["override"]["sql"] == ok["sql"]
    gone = world.client.delete(world.url(f"sql-overrides/{PAGE}/{CARD}"))
    assert gone.json() == {"deleted": True}
    again = world.client.delete(world.url(f"sql-overrides/{PAGE}/{CARD}"))
    assert again.status_code == 404 and "no edited SQL for this pane" in again.text


def test_edited_sql_replaces_generated_and_follows_slicers(world):
    sql = 'SELECT SUM("Sales"."SalesAmount") AS "Total Sales" FROM CONTOSO.SALES.FACT_SALES AS "Sales" WHERE {{filters}}'  # noqa: E501
    world.client.put(world.url("sql-overrides"), json={"page": PAGE, "visual": CARD, "sql": sql})
    slicer = [{"table": "Sales", "column": "Quantity", "values": [3], "source": "slicer"}]
    r = world.query(CARD, filters=slicer)
    result = r.json()["results"][0]
    assert result["execution_path"] == "manual_sql" and result["error"] is None
    assert result["sql"].startswith('SELECT SUM("Sales"."SalesAmount")')
    assert '"Sales"."Quantity"' in result["sql"] and "{{" not in result["sql"]
    record = world.get("query-audit", kind="all").json()["records"][0]
    assert record["sql_override"] is True and record["execution_path"] == "manual_sql"
    assert record["unapplied_filters"] == []
    # no placeholder: the slicer's table is reported, nothing is guessed
    world.client.put(
        world.url("sql-overrides"),
        json={"page": PAGE, "visual": CARD, "sql": 'SELECT 1 AS "Total Sales" FROM x AS "Sales"'},
    )
    r2 = world.query(CARD, filters=slicer).json()["results"][0]
    assert "Quantity" not in r2["sql"]
    rec = world.get("query-audit", kind="all").json()["records"][0]
    assert rec["unapplied_filters"] == ["Sales"]


def test_other_panes_keep_generated_sql(world):
    world.client.put(
        world.url("sql-overrides"),
        json={"page": PAGE, "visual": CARD, "sql": 'SELECT 1 AS "Total Sales"'},
    )
    results = {x["visual"]: x for x in world.query(CARD, BAR).json()["results"]}
    assert results[CARD]["execution_path"] == "manual_sql"
    assert results[BAR]["execution_path"] != "manual_sql"


def test_edit_rescues_untranslated_panes_and_sets_manual_sql(world):
    world.park_measure(dax="FOOBAR(1)")
    spec = world.get("spec").json()
    card = next(v for p in spec["pages"] for v in p["visuals"] if v["name"] == CARD)
    assert card["data_status"] == "untranslated" and card["manual_sql"] is None
    editor = world.get("sql-editor", page=PAGE, visual=CARD).json()
    assert editor["base_sql"] is None and "FOOBAR" in editor["base_error"]
    assert editor["expected_columns"] == ["Total Sales"]
    world.client.put(
        world.url("sql-overrides"),
        json={"page": PAGE, "visual": CARD, "sql": 'SELECT 7 AS "Total Sales"'},
    )
    spec = world.get("spec").json()
    card = next(v for p in spec["pages"] for v in p["visuals"] if v["name"] == CARD)
    assert card["manual_sql"] == 'SELECT 7 AS "Total Sales"'
    result = world.query(CARD).json()["results"][0]
    assert result["error"] is None and result["execution_path"] == "manual_sql"
