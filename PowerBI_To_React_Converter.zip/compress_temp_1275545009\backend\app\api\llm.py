from fastapi import APIRouter, Depends

from app.api.deps import require_token
from app.services.llm_provider import describe_providers

router = APIRouter(prefix="/api/v1/llm", tags=["llm"], dependencies=[Depends(require_token)])


@router.get("/providers")
def llm_providers() -> dict:
    return describe_providers()
