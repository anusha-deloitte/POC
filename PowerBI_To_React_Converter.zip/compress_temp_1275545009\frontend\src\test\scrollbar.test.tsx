import { describe, expect, it } from 'vitest'
import { scrollThickness, scrollZoom } from '../dashboard/visuals/scrollbar'

describe('scrollbars', () => {
  it('measure ~10 screen px at any page scale (min 8 canvas px)', () => {
    expect(scrollThickness(1)).toBe(10)
    expect(scrollThickness(0.5)).toBe(20)
    expect(scrollThickness(2)).toBe(8)
    expect(scrollThickness(10)).toBe(8)
  })

  it('a horizontal scroll window is a locked slider plus a wheel-driven inside zoom', () => {
    const [slider, inside] = scrollZoom({ axis: 'x', axisIndex: 0, endValue: 11, scale: 0.5, position: 2 })
    expect(slider).toMatchObject({
      type: 'slider',
      xAxisIndex: 0,
      startValue: 0,
      endValue: 11,
      zoomLock: true,
      height: 20,
      bottom: 2,
      brushSelect: false,
      showDetail: false,
    })
    expect(inside).toMatchObject({
      type: 'inside',
      xAxisIndex: 0,
      zoomLock: true,
      zoomOnMouseWheel: false,
      moveOnMouseWheel: true,
    })
  })

  it('a vertical scroll window targets the y axis and is as wide as the thickness', () => {
    const [slider, inside] = scrollZoom({ axis: 'y', axisIndex: 1, endValue: 5, scale: 1 })
    expect(slider).toMatchObject({ yAxisIndex: 1, width: 10, right: 0, endValue: 5 })
    expect(inside).toMatchObject({ yAxisIndex: 1 })
    expect('height' in slider).toBe(false)
  })
})
