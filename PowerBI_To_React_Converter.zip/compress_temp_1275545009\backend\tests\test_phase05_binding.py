from __future__ import annotations

import io
import zipfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.binding.case_check import (
    CaseItem,
    case_summary_message,
    check_identifier_case,
    correct_bundle_case,
    match_case,
    physical_columns,
)
from app.binding.preflight import PreflightReport, PreflightTarget, run_preflight
from app.binding.resolver import (
    BindingMap,
    TableBinding,
    apply_binding_settings,
    apply_case_fix,
    describe_ident,
    quote_ident,
    safe_ident,
    source_hints,
    sql_name,
    sql_string,
    verify_against_information_schema,
)
from app.ir.model import Column, Measure, Partition, SemanticModel, Table
from app.ir.report import BindingSettings, Report, ReportBundle, TableCaseFix
from app.runtime.accelerate import to_duckdb_sql
from app.runtime.engine import MeasureRefSpec, QuerySpec, SemanticEngine

# ------------------------------------------------------------------ identifier quoting


def test_quote_ident_and_describe():
    assert quote_ident("Sales (2024)") == '"Sales (2024)"'
    assert quote_ident('a"b') == '"a""b"'
    assert quote_ident("it's") == '"it\'s"'
    assert quote_ident("café “x”") == '"café “x”"'
    assert describe_ident("x") == "«x»"


@pytest.mark.parametrize("bad", ["", "a\x00b", "a\nb", "\x7f"])
def test_control_characters_rejected_with_origin(bad):
    with pytest.raises(ValueError, match="from the schema name of T: empty or contains control"):
        safe_ident(bad, "the schema name of T")


def test_sql_name_and_string():
    assert sql_name("SALES") == "SALES"
    assert sql_name("MY_T$1") == "MY_T$1"
    for quoted in ("Sales", "ORDER", "MY TABLE", "1ABC", "SELECT", "TABLE"):
        assert sql_name(quoted) == quote_ident(quoted)
    assert sql_string("O'Brien") == "'O''Brien'"


def test_qualified_name_uses_sql_name_and_origin():
    b = TableBinding(table="T", database="DB", schema_name="Sch ema", object_name="ORDER")
    assert b.qualified_name == 'DB."Sch ema"."ORDER"'
    bad = TableBinding(table="Tbl", database="DB", schema_name="S\x01", object_name="T")
    with pytest.raises(ValueError, match="the schema name bound to table «Tbl»"):
        bad.qualified_name  # noqa: B018


# ------------------------------------------------------------------ case matching


def test_match_case():
    assert match_case("A", ["A", "a"]) == ("exact", "A", ["A"])
    assert match_case("sales", ["SALES", "x"]) == ("corrected", "SALES", ["SALES"])
    assert match_case("sales", ["Sales", "SALES"])[0] == "ambiguous"
    assert match_case("zzz", ["a"]) == ("missing", None, [])


def test_case_item_descriptions():
    c = CaseItem(kind="table", model_table="T", name="x", status="corrected", exact="X")
    assert c.describe() == "table «x» (table «T») -> «X»"
    a = CaseItem(kind="table", model_table="T", name="x", status="ambiguous", candidates=["a", "A"])
    assert a.describe().endswith("several Snowflake names differ only by case: «a», «A»")
    m = CaseItem(kind="column", model_table="T", name="c", status="missing")
    assert m.describe().endswith(": not found")


# ------------------------------------------------------------------ fake catalog


class Catalog:
    """Answers SHOW DATABASES / INFORMATION_SCHEMA queries from a dict."""

    def __init__(self, dbs, schemas, tables, columns, fail=()):
        self.dbs, self.schemas, self.tables, self.columns = dbs, schemas, tables, columns
        self.fail = fail
        self.queries: list[str] = []
        self.description = [("created_on",), ("name",)]
        self._rows: list[tuple] = []

    def execute(self, sql, *a):
        self.queries.append(sql)
        for needle in self.fail:
            if needle in sql.lower():
                raise RuntimeError("catalog denied")
        low = sql.lower()
        if low.startswith("show databases"):
            self.description = [("created_on",), ("name",)]
            self._rows = [("2024", d) for d in self.dbs if d.lower() in low]
        elif "schemata" in low:
            self._rows = [(s,) for s in self.schemas if f"UPPER('{s.upper()}')" in sql.upper()]
        elif "information_schema.tables" in low and "table_schema =" in low:
            sch = sql.split("table_schema = ")[1].strip().strip("'")
            self._rows = [(t,) for t in self.tables.get(sch, [])]
        elif "information_schema.tables" in low:
            sch = sql.upper().split("UPPER('")[1].split("'")[0]
            self._rows = [(s, t) for s, ts in self.tables.items() if s.upper() == sch for t in ts]
        elif "information_schema.columns" in low:
            tbl = sql.split("table_name = ")[1].strip().strip("'")
            self._rows = [(c,) for c in self.columns.get(tbl, [])]
        elif "current_role" in low:
            self._rows = [("ANALYST", "WH")]
        else:
            self._rows = []

    def fetchall(self):
        return self._rows

    def fetchone(self):
        return self._rows[0] if self._rows else None

    def close(self):
        pass


def _model(db="mydb", schema="Public", obj="Sales", extra=""):
    expr = (
        'let Source = Snowflake.Databases("srv","WH"),\n'
        f' D = Source{{[Name="{db}",Kind="Database"]}}[Data],\n'
        f' S = D{{[Name="{schema}",Kind="Schema"]}}[Data],\n'
        f' T = S{{[Name="{obj}",Kind="Table"]}}[Data]{extra}\nin T'
    )
    return SemanticModel(
        tables=[
            Table(
                name="Sales",
                columns=[Column(name="amount"), Column(name="Region")],
                measures=[Measure(name="Total", expression="SUM(Sales[amount])")],
                partitions=[Partition(name="p", source_type="m", expression=expr)],
            )
        ]
    )


def _bundle(model=None):
    return ReportBundle(source_path="x", model=model or _model(), report=Report())


CATALOG = dict(
    dbs=["MYDB"],
    schemas=["PUBLIC"],
    tables={"PUBLIC": ["SALES", "OTHER"]},
    columns={"SALES": ["AMOUNT", "Region"]},
)


def test_check_corrects_every_level_and_builds_fixes():
    bundle = _bundle()
    from app.binding.resolver import build_binding_map

    bm = build_binding_map(bundle.model)
    report = check_identifier_case(bm, bundle.model, Catalog(**CATALOG))
    by = {(i.kind, i.name): i for i in report.items}
    assert (
        by[("database", "mydb")].status == "corrected" and by[("database", "mydb")].exact == "MYDB"
    )
    assert by[("schema", "Public")].exact == "PUBLIC"
    assert by[("table", "Sales")].exact == "SALES"
    assert by[("column", "amount")].exact == "AMOUNT"
    assert by[("column", "Region")].status == "exact"
    fix = report.fixes["Sales"]
    assert (fix.database, fix.schema_name, fix.object_name) == ("MYDB", "PUBLIC", "SALES")
    assert fix.columns == {"amount": "AMOUNT"}
    s = report.summary()
    assert s["checked"] == 5 and s["exact"] == 1 and len(s["corrected"]) == 4
    assert case_summary_message(report) == (
        "identifier case: 1/5 names match Snowflake exactly, 4 corrected to Snowflake's spelling"
    )


def test_ambiguous_and_missing_are_reported_not_changed():
    bundle = _bundle(_model(obj="orders"))
    from app.binding.resolver import build_binding_map

    cat = Catalog(**{**CATALOG, "tables": {"PUBLIC": ["Orders", "ORDERS"]}})
    report = check_identifier_case(build_binding_map(bundle.model), bundle.model, cat)
    tbl = next(i for i in report.items if i.kind == "table")
    assert tbl.status == "ambiguous"
    assert "Sales" not in report.fixes or not report.fixes["Sales"].object_name
    cat2 = Catalog(**{**CATALOG, "dbs": []})
    report2 = check_identifier_case(build_binding_map(bundle.model), bundle.model, cat2)
    assert [i.status for i in report2.items] == ["missing"]
    assert "1 not found" in case_summary_message(report2)


def test_query_errors_are_recorded_and_checking_continues():
    bundle = _bundle()
    from app.binding.resolver import build_binding_map

    cat = Catalog(**CATALOG, fail=("information_schema.columns",))
    report = check_identifier_case(build_binding_map(bundle.model), bundle.model, cat)
    assert report.column_errors and report.errors and "Sales" in report.column_failed_tables
    assert any(i.kind == "table" for i in report.items)


def test_columns_are_queried_per_table():
    bundle = _bundle()
    from app.binding.resolver import build_binding_map

    cat = Catalog(**CATALOG)
    check_identifier_case(build_binding_map(bundle.model), bundle.model, cat)
    col_queries = [q for q in cat.queries if "information_schema.columns" in q.lower()]
    assert len(col_queries) == 1 and "table_name = 'SALES'" in col_queries[0]


def test_physical_columns_account_for_renames_where_and_computed():
    extra = (
        ',\n R = Table.RenameColumns(T, {{"old", "new"}}),\n'
        ' F = Table.SelectRows(R, each [flt] = "x"),\n'
        ' A = Table.AddColumn(F, "calc", each [base] & "-")'
    )
    model = _model(extra=extra)
    model.tables[0].columns = [Column(name="new"), Column(name="calc"), Column(name="keep")]
    from app.binding.resolver import build_binding_map

    b = build_binding_map(model).bindings["Sales"]
    cols = physical_columns(model, b)
    assert "old" in cols and "keep" in cols and "flt" in cols and "base" in cols
    assert "new" not in cols and "calc" not in cols


# ------------------------------------------------------------------ applying fixes


def test_apply_case_fix_only_for_case_equal_names():
    b = TableBinding(table="T", database="mydb", schema_name="Public", object_name="Sales")
    apply_case_fix(
        b,
        TableCaseFix(
            database="MYDB",
            schema_name="PUBLIC",
            object_name="SALES",
            columns={"amount": "AMOUNT", "same": "same", "other": "UNRELATED"},
        ),
    )
    assert (b.database, b.schema_name, b.object_name) == ("MYDB", "PUBLIC", "SALES")
    assert b.column_case == {"amount": "AMOUNT"}
    # override to another database: the stale correction must not leak in
    moved = TableBinding(table="T", database="OTHERDB", schema_name="Public", object_name="Sales")
    apply_case_fix(moved, TableCaseFix(database="MYDB", schema_name="PUBLIC"))
    assert moved.database == "OTHERDB" and moved.schema_name == "PUBLIC"


def test_apply_binding_settings_override_then_fix():
    bm = BindingMap(
        bindings={
            "A": TableBinding(table="A", database="d", schema_name="s", object_name="o"),
            "V": TableBinding(table="V", is_virtual=True, status="virtual"),
            "N": TableBinding(table="N", native_query="select 1"),
            "U": TableBinding(
                table="U", database="d", schema_name="s", object_name="o", status="unresolved"
            ),
        }
    )
    settings = BindingSettings(
        database_override="NEWDB",
        schema_override="NEWSCH",
        case_fixes={"A": TableCaseFix(database="NEWDB", object_name="O")},
    )
    apply_binding_settings(bm, settings)
    a = bm.bindings["A"]
    assert (a.database, a.schema_name, a.object_name) == ("NEWDB", "NEWSCH", "O")
    assert bm.bindings["U"].database == "d" and bm.bindings["N"].database is None


def test_correct_bundle_case_persists_and_keeps_fixes_when_catalog_unreadable():
    bundle = _bundle()
    report, changed = correct_bundle_case(bundle, Catalog(**CATALOG))
    assert changed and bundle.binding_settings.case_checked_at
    assert bundle.binding_settings.case_fixes["Sales"].object_name == "SALES"
    saved = dict(bundle.binding_settings.case_fixes)
    report2, changed2 = correct_bundle_case(bundle, Catalog(**CATALOG, fail=("show databases",)))
    assert report2.errors and changed2 is False
    assert bundle.binding_settings.case_fixes == saved
    # column query failure keeps previously saved column fixes
    report3, changed3 = correct_bundle_case(
        bundle, Catalog(**CATALOG, fail=("information_schema.columns",))
    )
    assert changed3 and bundle.binding_settings.case_fixes["Sales"].columns == {"amount": "AMOUNT"}
    assert report3.column_errors


def test_engine_uses_exact_names_and_projects_model_names():
    bundle = _bundle()
    bundle.binding_settings.case_fixes["Sales"] = TableCaseFix(
        database="MYDB", schema_name="PUBLIC", object_name="SALES", columns={"amount": "AMOUNT"}
    )
    from app.binding.resolver import build_bundle_binding_map

    bm = build_bundle_binding_map(bundle)
    sql, _ = SemanticEngine(bundle.model, bm).build_sql(
        QuerySpec(measures=[MeasureRefSpec(name="Total")])
    )
    assert "MYDB.PUBLIC.SALES" in sql
    assert '"AMOUNT" AS "amount"' in sql and 'EXCLUDE ("AMOUNT")' in sql
    assert '"mydb"' not in sql


def test_unresolved_against_live_case_detail():
    bm = BindingMap(
        bindings={"T": TableBinding(table="T", database="D", schema_name="S", object_name="T")}
    )

    class Cur:
        def execute(self, sql):
            pass

        def fetchall(self):
            return [("S", "t")]

    verify_against_information_schema(bm, Cur(), "D")
    b = bm.bindings["T"]
    assert b.status == "unresolved"
    assert b.detail == (
        "letter case differs from Snowflake: bound as S.T, Snowflake has S.t "
        "(quoted names are case-sensitive)"
    )


def test_to_duckdb_sql_replaces_both_spellings_at_boundaries():
    bm = BindingMap(
        bindings={
            "T": TableBinding(table="T", database="DB", schema_name="S", object_name="T"),
            "T2": TableBinding(table="T2", database="DB", schema_name="S", object_name="T2"),
            "M": TableBinding(table="M", database="db", schema_name="S", object_name="Mixed"),
        }
    )
    sql = 'SELECT * FROM DB.S.T JOIN DB.S.T2 ON 1=1 JOIN "db".S."Mixed" ON 1=1'
    out = to_duckdb_sql(sql, bm)
    assert '"x_t2"' in out and '"x_t"' in out and '"x_m"' in out
    assert "DB.S" not in out
    quoted = to_duckdb_sql('SELECT * FROM "DB"."S"."T"', bm)
    assert "x_t" in quoted and "DB" not in quoted


# ------------------------------------------------------------------ preflight


def test_preflight_reachable_and_case_mismatch():
    bundle = _bundle(_model(db="MYDB", schema="PUBLIC", obj="SALES"))
    from app.binding.resolver import build_binding_map

    report = run_preflight(build_binding_map(bundle.model), Catalog(**CATALOG))
    assert (report.role, report.warehouse) == ("ANALYST", "WH")
    assert report.bound == 1 and report.accessible == 1 and not report.blocking
    assert report.message() == "1/1 bound tables reachable with role ANALYST / warehouse WH"

    mismatch = _bundle(_model(db="MYDB", schema="PUBLIC", obj="sales"))
    r2 = run_preflight(build_binding_map(mismatch.model), Catalog(**CATALOG))
    assert r2.blocking and r2.targets[0].case_mismatch == ["PUBLIC.sales (Snowflake: PUBLIC.SALES)"]
    assert (
        "none of the 1 bound tables exists with this exact spelling (1 differ only in letter case)"
        in r2.message()
    )
    assert r2.message().endswith(
        "Pick a role with access or set a database/schema override, then convert again"
    )


def test_preflight_errors_never_raise():
    bundle = _bundle(_model(db="MYDB", schema="PUBLIC", obj="SALES"))
    from app.binding.resolver import build_binding_map

    cat = Catalog(**CATALOG, fail=("information_schema.tables", "current_role"))
    report = run_preflight(build_binding_map(bundle.model), cat)
    assert report.session_error and report.targets[0].error == "catalog denied"
    assert report.blocking and "catalog denied" in report.message()
    summary = report.summary()
    assert summary["blocking"] is True and summary["targets"][0]["unreachable"] is True
    assert PreflightReport().blocking is False
    assert PreflightTarget(database="d", schema_name="s", tables=["t"], listed=3).unreachable


# ------------------------------------------------------------------ source hints


def test_source_hints_most_common_values():
    base = _model(db="DB1", schema="S1")
    t2 = _model(db="DB1", schema="S1").tables[0].model_copy(update={"name": "B"})
    t3 = _model(db="DB2", schema="S2").tables[0].model_copy(update={"name": "C"})
    base.tables += [t2, t3]
    assert source_hints(base) == {
        "server": "srv",
        "warehouse": "WH",
        "database": "DB1",
        "schema": "S1",
    }
    param = SemanticModel(
        tables=[
            Table(
                name="T",
                partitions=[
                    Partition(
                        name="p",
                        source_type="m",
                        expression='Snowflake.Databases(Srv, #"Wh P"){[Name=Db,Kind="Database"]}[Data]',
                    )
                ],
            )
        ],
        expressions={
            "Srv": '"s.example" meta [IsParameterQuery=true]',
            "Wh P": '"WH9" meta [IsParameterQuery=true]',
            "Db": '"PDB" meta [IsParameterQuery=true]',
        },
    )
    h = source_hints(param)
    assert (h["server"], h["warehouse"], h["database"]) == ("s.example", "WH9", "PDB")
    assert source_hints(SemanticModel()) == {
        "server": None,
        "warehouse": None,
        "database": None,
        "schema": None,
    }


# ------------------------------------------------------------------ endpoints


def _zip(folder: Path) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, f.relative_to(folder))
    return buf.getvalue()


@pytest.fixture()
def api(tmp_path, monkeypatch, contoso_pbip):
    from app.api.deps import (
        get_connection_store,
        get_dashboard_token_store,
        get_ingest_service,
        get_snowflake_session_manager,
    )
    from app.main import app
    from app.services.connections import ConnectionStore
    from app.services.dashboard_tokens import DashboardTokenStore
    from app.services.ingest import IngestService
    from app.services.snowflake_sessions import SnowflakeSessionManager

    svc = IngestService(tmp_path / "storage")
    store = ConnectionStore(tmp_path / "storage", tmp_path / "storage" / ".key")
    state = {"catalog": None}

    class Conn:
        closed = False

        def cursor(self):
            return state["catalog"]

        def is_closed(self):
            return self.closed

        def close(self):
            self.closed = True

    mgr = SnowflakeSessionManager(store, connect=lambda **kw: Conn())
    store._session_manager = mgr
    tokens = DashboardTokenStore(tmp_path / "storage", default_ttl_seconds=300)
    monkeypatch.setattr("app.api.dashboards.get_ingest_service", lambda: svc)
    app.dependency_overrides[get_ingest_service] = lambda: svc
    app.dependency_overrides[get_connection_store] = lambda: store
    app.dependency_overrides[get_snowflake_session_manager] = lambda: mgr
    app.dependency_overrides[get_dashboard_token_store] = lambda: tokens
    with TestClient(app) as c:
        cid = c.post(
            "/api/v1/conversions", files={"file": ("c.zip", _zip(contoso_pbip), "application/zip")}
        ).json()["id"]
        conn = c.post(
            "/api/v1/connections",
            json={
                "name": "n",
                "account": "a",
                "user": "u",
                "warehouse": "WH",
                "auth_method": "password",
                "password": "pw",
            },
        ).json()
        yield c, cid, conn["id"], state, svc
    mgr.close_all()
    app.dependency_overrides.clear()


def test_source_hints_endpoint(api):
    c, cid, _conn, _state, _svc = api
    body = c.get(f"/api/v1/conversions/{cid}/source-hints").json()
    assert set(body) >= {"server", "warehouse", "database", "schema", "binding_settings"}
    assert body["binding_settings"]["database_override"] is None
    missing = "00000000-0000-0000-0000-000000000000"
    assert c.get(f"/api/v1/conversions/{missing}/source-hints").status_code == 404


def _prepare_catalog(api):
    c, cid, conn, state, svc = api
    bundle = svc.load_bundle(cid)
    t = next(t for t in bundle.model.tables if t.partitions and t.partitions[0].source_type == "m")
    from app.binding.resolver import build_binding_map

    b = build_binding_map(bundle.model).bindings[t.name]
    if not (b.database and b.schema_name and b.object_name):
        pytest.skip("fixture has no fully-qualified Snowflake binding")
    state["catalog"] = Catalog(
        dbs=[b.database.upper()],
        schemas=[b.schema_name.upper()],
        tables={b.schema_name.upper(): [b.object_name.upper()]},
        columns={},
    )


def _preflight(c, cid, conn, **body):
    r = c.post(
        f"/api/v1/conversions/{cid}/dashboard/preflight", json={"connection_id": conn, **body}
    )
    assert r.status_code == 200, r.text
    return r.json()


def test_preflight_saves_overrides_even_without_a_case_correction(api, monkeypatch):
    c, cid, conn, _state, svc = api
    _prepare_catalog(api)
    from app.binding import case_check

    class NoChange:
        def summary(self):
            return {
                "checked": 0,
                "exact": 0,
                "corrected": [],
                "ambiguous": [],
                "missing": [],
                "errors": [],
            }

    monkeypatch.setattr(case_check, "correct_bundle_case", lambda trial, cur: (NoChange(), False))
    body = _preflight(c, cid, conn, database_override=" ZZ_NEW ", schema_override="S1")
    assert {"message", "case", "case_saved", "blocking", "bound", "accessible"} <= set(body)
    assert body["case_saved"] is False and body["settings_saved"] is True
    saved = svc.load_bundle(cid).binding_settings
    assert (saved.database_override, saved.schema_override) == ("ZZ_NEW", "S1")
    # unchanged values are not rewritten
    assert (
        _preflight(c, cid, conn, database_override="ZZ_NEW", schema_override="S1")["settings_saved"]
        is False
    )


def test_preflight_blank_values_clear_saved_overrides(api, monkeypatch):
    c, cid, conn, _state, svc = api
    _prepare_catalog(api)
    bundle = svc.load_bundle(cid)
    bundle.binding_settings.database_override = "OLD_DB"
    bundle.binding_settings.schema_override = "OLD_SCH"
    svc.save_bundle(cid, bundle)
    body = _preflight(c, cid, conn, database_override="   ", schema_override=None)
    assert body["settings_saved"] is True
    saved = svc.load_bundle(cid).binding_settings
    assert saved.database_override is None and saved.schema_override is None


def test_preflight_still_saves_case_fixes(api, monkeypatch):
    c, cid, conn, _state, svc = api
    _prepare_catalog(api)
    from app.binding import case_check

    class Changed:
        def summary(self):
            return {
                "checked": 1,
                "exact": 0,
                "corrected": ["x"],
                "ambiguous": [],
                "missing": [],
                "errors": [],
            }

    def fake(trial, cur):
        trial.binding_settings.case_fixes = {}
        trial.binding_settings.case_checked_at = 1700000000.0
        return Changed(), True

    monkeypatch.setattr(case_check, "correct_bundle_case", fake)
    body = _preflight(c, cid, conn)
    assert body["case_saved"] is True
    assert svc.load_bundle(cid).binding_settings.case_checked_at == 1700000000.0
