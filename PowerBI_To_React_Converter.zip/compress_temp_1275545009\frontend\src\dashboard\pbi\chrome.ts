/** Buttons, shapes and images: resolved from the raw PBIR payload. */
import type { VisualSpec } from '../types'
import { PBI_DEFAULTS } from './defaults'
import { font, type FontSpec } from './fonts'
import { color, litBool, litNumber, litString, shade, withAlpha, type Node } from './literal'
import type { ResolvedTheme } from './resolve'

type Dict = Record<string, unknown>
const isDict = (v: unknown): v is Dict => typeof v === 'object' && v !== null && !Array.isArray(v)

export type ButtonState = 'default' | 'hover' | 'pressed' | 'disabled'

const STATE_ID: Record<ButtonState, string> = {
  default: 'default',
  hover: 'hover',
  pressed: 'press',
  disabled: 'disabled',
}

/** Property of a state-aware object: the state's own selector > the `default` selector > the
 * unselected (selector-less) entry. */
export function stateProp(objects: unknown, obj: string, prop: string, state: ButtonState = 'default'): Node {
  if (!isDict(objects)) return undefined
  const list = objects[obj]
  if (!Array.isArray(list)) return undefined
  const entries = list.filter(isDict)
  const withId = (id: string) =>
    entries.find((e) => isDict(e.selector) && e.selector.id === id && isDict(e.properties) && prop in e.properties)
  const order: (Dict | undefined)[] = []
  if (state !== 'default') order.push(withId(STATE_ID[state]))
  order.push(withId('default'))
  order.push(entries.find((e) => !('selector' in e) && isDict(e.properties) && prop in e.properties))
  const found = order.find((e) => e !== undefined)
  return found ? (found.properties as Dict)[prop] : undefined
}

/** The registered resource file a node points to. */
export function resourceItem(node: unknown): string | undefined {
  if (Array.isArray(node)) {
    for (const n of node) {
      const r = resourceItem(n)
      if (r) return r
    }
    return undefined
  }
  if (!isDict(node)) return undefined
  const item = node.ResourcePackageItem
  if (isDict(item) && typeof item.ItemName === 'string') return item.ItemName
  for (const v of Object.values(node)) {
    const r = resourceItem(v)
    if (r) return r
  }
  return undefined
}

export interface ButtonStyle {
  fill?: string
  outline?: { color: string; weightPx: number }
  text: {
    show: boolean
    value?: string
    font: FontSpec
    color: string
    align: 'left' | 'center' | 'right'
    margins: { top: number; right: number; bottom: number; left: number }
    baselineShiftEm: number
  }
  icon?: { shape: string; customResource?: string; color?: string; size?: number }
  shadow?: string
  glow?: string
  roundedPx: number
}

export function resolveButton(spec: VisualSpec, theme: ResolvedTheme, state: ButtonState = 'default'): ButtonStyle {
  const o = spec.pbir?.objects
  const t = theme.tokens
  const B = PBI_DEFAULTS.button
  const sp = (obj: string, prop: string) => stateProp(o, obj, prop, state)

  const fillShow = litBool(sp('fill', 'show'))
  const fillColor = color(sp('fill', 'fillColor'), t)
  let fill: string | undefined = fillShow === false ? undefined : (fillColor ?? B.fill)
  if (fill) {
    const transparency = litNumber(sp('fill', 'transparency')) ?? 0
    if (transparency) fill = withAlpha(fill, 1 - transparency / 100)
  }
  const outlineShow = litBool(sp('outline', 'show'))
  const outline =
    outlineShow === false
      ? undefined
      : {
          color: color(sp('outline', 'lineColor'), t) ?? B.outlineColor,
          weightPx: litNumber(sp('outline', 'weight')) ?? B.outlineWeightPx,
        }
  const margin = (side: string) => litNumber(sp('text', `${side}Margin`)) ?? B.textMarginPx
  const align = litString(sp('text', 'horizontalAlignment')) ?? 'center'
  const iconShow = litBool(sp('icon', 'show'))
  const shapeType = litString(sp('icon', 'shapeType'))
  const customResource = resourceItem(isDict(o) ? o.icon : undefined)
  const icon =
    iconShow === true || (iconShow === undefined && (shapeType || customResource))
      ? {
          shape: customResource ? 'custom' : (shapeType ?? 'custom'),
          customResource,
          color: color(sp('icon', 'lineColor'), t),
          size: litNumber(sp('icon', 'lineWeight')),
        }
      : undefined
  const shadow = litBool(sp('shadow', 'show')) ? B.shadow : undefined
  const glow = litBool(sp('glow', 'show'))
    ? `0 0 ${B.glowBlurPx}px ${color(sp('glow', 'color'), t) ?? B.glowColor}`
    : undefined
  return {
    fill,
    outline,
    text: {
      show: litBool(sp('text', 'show')) ?? true,
      value: litString(sp('text', 'text')),
      font: font(sp('text', 'fontFamily'), sp('text', 'fontSize'), B.textSizePt, litBool(sp('text', 'bold')) ? 700 : 400),
      color: color(sp('text', 'fontColor'), t) ?? B.textColor,
      align: align === 'left' || align === 'right' ? align : 'center',
      margins: { top: margin('top'), right: margin('right'), bottom: margin('bottom'), left: margin('left') },
      baselineShiftEm: B.textBaselineShiftEm,
    },
    icon,
    shadow,
    glow,
    roundedPx: litNumber(sp('shape', 'roundEdge')) ?? B.roundedCurvePx,
  }
}

export type ShapeKind = 'rectangle' | 'roundedRectangle' | 'oval' | 'line' | 'triangle'

export interface ShapeStyle {
  kind: ShapeKind
  fill?: string
  line?: { color: string; weightPx: number }
  roundedPx: number
  rotation: number
  /** a line rotated a quarter turn spans the box vertically */
  vertical: boolean
}

const SHAPE_KINDS: Record<string, ShapeKind> = {
  rectangle: 'rectangle',
  roundedrectangle: 'roundedRectangle',
  oval: 'oval',
  ellipse: 'oval',
  line: 'line',
  triangle: 'triangle',
}

export function resolveShape(spec: VisualSpec, theme: ResolvedTheme): ShapeStyle {
  const o = spec.pbir?.objects
  const t = theme.tokens
  const S = PBI_DEFAULTS.shape
  const first = (obj: string, prop: string) => stateProp(o, obj, prop, 'default')
  const kindRaw = (litString(first('shape', 'tileShape')) ?? 'rectangle').toLowerCase()
  const kind = SHAPE_KINDS[kindRaw] ?? 'rectangle'
  const fillShow = litBool(first('fill', 'show'))
  const fill = fillShow === false ? undefined : (color(first('fill', 'fillColor'), t) ?? t.dataColors[0] ?? S.fill)
  const hasOutline = isDict(o) && Array.isArray(o.outline)
  let line: { color: string; weightPx: number } | undefined
  if (hasOutline) {
    if (litBool(first('outline', 'show')) !== false) {
      line = {
        color: color(first('outline', 'lineColor'), t) ?? S.lineColor,
        weightPx: litNumber(first('outline', 'weight')) ?? S.lineWeightPx,
      }
    }
  } else {
    // legacy shapes without an outline object draw 1 px in dataColors[0] shaded -25%
    line = { color: shade(t.dataColors[0] ?? S.lineColor, S.lineShade), weightPx: S.lineWeightPx }
  }
  const rotation = litNumber(first('rotation', 'shapeAngle')) ?? litNumber(first('rotation', 'angle')) ?? 0
  const quarter = Math.abs(((rotation % 180) + 180) % 180 - 90) < 1
  return {
    kind,
    fill,
    line,
    roundedPx: litNumber(first('shape', 'roundEdge')) ?? S.roundedCurvePx,
    rotation,
    vertical: kind === 'line' && quarter,
  }
}

/** Image scaling -> CSS `object-fit`: Fit stretches, Fill covers, Normal keeps the pixel size. */
export function imageFit(objects: unknown): 'fill' | 'cover' | 'none' {
  const v = (litString(stateProp(objects, 'image', 'scaling')) ?? 'Normal').toLowerCase()
  if (v === 'fit') return 'fill'
  if (v === 'fill') return 'cover'
  return 'none'
}
