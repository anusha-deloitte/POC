"""Extract physical Snowflake objects from Power Query (M) partition sources.

Handles the navigation patterns Power BI Desktop emits for Snowflake:

    Source = Snowflake.Databases(Server, Warehouse, [Role = R]),
    Db  = Source{[Name = "DB" | Param, Kind = "Database"]}[Data],
    Sch = Db{[Name = "SCHEMA", Kind = "Schema"]}[Data],
    Obj = Sch{[Name = "TABLE", Kind = "Table" | "View"]}[Data]

plus Value.NativeQuery(...) passthrough SQL. Name values may be string
literals or references to shared expressions (parameters), which are
resolved via the model's expression map. Trailing transform steps
(Table.RemoveColumns etc.) are captured for the view-compiler to inspect.

Phase-5 extension: Table.SelectRows and Table.RenameColumns predicates are
parsed and stored in MBinding so the resolver can inject WHERE clauses and
column aliases into the physical binding.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# M text literal: an embedded quote is `""` (M has no backslash escapes)
_M_STR = r'"(?:[^"]|"")*"'
# navigation value: literal, #"quoted identifier", or bare reference
_M_VALUE = rf"(?:{_M_STR}|#{_M_STR}|[\w.]+)"

_STEP_RE = re.compile(
    rf"\{{\[\s*Name\s*=\s*(?P<name>{_M_VALUE})\s*"
    r"(?:,\s*Kind\s*=\s*\"(?P<kind>[^\"]+)\")?\s*\]\}",
)
_NATIVE_RE = re.compile(r"Value\.NativeQuery\s*\(", re.IGNORECASE)
_SNOWFLAKE_SRC_RE = re.compile(r"Snowflake\.Databases\s*\(", re.IGNORECASE)
# foreign sources the migration mover can lift into Snowflake
_FOREIGN_SRC_RES: list[tuple[str, "re.Pattern[str]"]] = [
    # lookbehind: bare Sql.* must not match inside PostgreSQL.*/MySQL.*
    ("sqlserver", re.compile(r"(?<![A-Za-z])Sql\.Databases?\s*\(", re.IGNORECASE)),
    ("postgres", re.compile(r"PostgreSQL\.Database\s*\(", re.IGNORECASE)),
    ("mysql", re.compile(r"MySQL\.Database\s*\(", re.IGNORECASE)),
    ("oracle", re.compile(r"Oracle\.Database\s*\(", re.IGNORECASE)),
]
# SQL Server / PostgreSQL navigation: Source{[Schema="dbo", Item="FactSales"]}[Data]
_SCHEMA_ITEM_RE = re.compile(
    rf"\{{\[\s*Schema\s*=\s*(?P<schema>{_M_VALUE})\s*,\s*"
    rf"Item\s*=\s*(?P<item>{_M_VALUE})\s*\]\}}",
)
# steps beyond pure navigation, e.g. Table.RemoveColumns(...), Table.SelectRows(...)
_TRANSFORM_RE = re.compile(r"\b(Table\.[A-Za-z]+)\s*\(")
_PARAM_STRIP_RE = re.compile(r"\s+meta\s+\[.*$", re.DOTALL)

# Table.SelectRows(src, each [col] = "value") -- simple equality filter
_SELECT_ROWS_EQ_RE = re.compile(
    r'Table\.SelectRows\s*\([^,]+,\s*each\s+\[(?P<col>[^\]]+)\]\s*=\s*"(?P<val>[^"]+)"',
    re.IGNORECASE,
)
# Table.RenameColumns(src, {{"OldName", "NewName"}, ...})
_RENAME_PAIR_RE = re.compile(r'\{"([^"]+)",\s*"([^"]+)"\}')

# Table.Group(src, {"A"}, {{"B", each List.Count(List.Distinct([C])), Int64.Type}})
_GROUP_RE = re.compile(
    r"Table\.Group\s*\(\s*(?P<src>[A-Za-z_][A-Za-z0-9_]*)\s*,\s*"
    r"\{(?P<group_cols>.*?)\}\s*,\s*\{(?P<aggs>.*?)\}\s*\)",
    re.IGNORECASE | re.DOTALL,
)
_GROUP_AGG_RE = re.compile(
    r'\{"([^"]+)",\s*each\s*(.+?),\s*(?:type\s+)?[A-Za-z0-9_.]+\}',
    re.IGNORECASE | re.DOTALL,
)


@dataclass
class MBinding:
    """Physical object a model table is bound to."""

    database: str | None = None
    schema: str | None = None
    object_name: str | None = None
    object_kind: str | None = None  # Table | View
    is_snowflake: bool = False
    # non-Snowflake connector detected in the M source (sqlserver | postgres)
    foreign_source: str | None = None
    native_query: str | None = None
    transform_steps: list[str] = field(default_factory=list)
    unresolved_params: list[str] = field(default_factory=list)
    # Phase-5: extracted WHERE predicates from Table.SelectRows
    where_predicates: list[str] = field(default_factory=list)  # SQL fragments
    # Phase-5: column renames from Table.RenameColumns {old → new}
    column_renames: dict[str, str] = field(default_factory=dict)
    # Table.Group metadata for best-effort materialization plans
    group_source: str | None = None
    group_by_columns: list[str] = field(default_factory=list)
    group_aggregations: list[tuple[str, str, str]] = field(default_factory=list)
    # Table.AddColumn(src, "Col", each <expr>) translated to Snowflake SQL {Col: sql}
    computed_columns: dict[str, str] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)

    @property
    def is_resolved(self) -> bool:
        return bool(
            self.is_snowflake
            and self.schema
            and self.object_name
            and not self.unresolved_params
        ) or bool(self.native_query)

    @property
    def is_foreign_resolved(self) -> bool:
        """Foreign source with full coordinates — migratable to Snowflake."""
        return bool(
            self.foreign_source
            and self.schema
            and self.object_name
            and not self.unresolved_params
        )


def m_string(raw: str) -> str:
    """Decode an M text literal: `"MEMBER""S"` -> `MEMBER"S`."""
    text = raw.strip()
    if text.startswith("#"):
        text = text[1:]
    if len(text) >= 2 and text[0] == '"' and text[-1] == '"':
        text = text[1:-1]
    return text.replace('""', '"')


def _reference_name(raw: str) -> str:
    raw = raw.strip()
    return m_string(raw) if raw.startswith("#") else raw


def resolve_parameter(
    value: str, expressions: dict[str, str], warnings: list[str] | None = None
) -> str | None:
    """Shared expressions look like: `"LITERAL" meta [IsParameterQuery=true...]`."""
    name = _reference_name(value)
    raw = expressions.get(name)
    if raw is None:
        return None
    stripped = _PARAM_STRIP_RE.sub("", raw).strip()
    if len(stripped) >= 2 and stripped.startswith('"') and stripped.endswith('"'):
        decoded = m_string(stripped)
        if len(decoded) >= 2 and decoded.startswith('"') and decoded.endswith('"'):
            unwrapped = decoded[1:-1]
            if warnings is not None:
                warnings.append(
                    f'parameter \u00ab{name}\u00bb is "{unwrapped}": surrounding double quotes '
                    f"removed, using {unwrapped}"
                )
            decoded = unwrapped
        return decoded or None
    return stripped or None


def _m_value(
    raw: str, expressions: dict[str, str], warnings: list[str]
) -> tuple[str | None, bool]:
    """(text, is_parameter): literals are decoded, references go through shared expressions."""
    raw = raw.strip()
    if raw.startswith('"'):
        return m_string(raw), False
    return resolve_parameter(raw, expressions, warnings), True


def _skip_string(text: str, i: int) -> int:
    """`i` is on an opening quote; returns the index after the closing quote."""
    i += 1
    while i < len(text):
        if text[i] == '"':
            if i + 1 < len(text) and text[i + 1] == '"':
                i += 2
                continue
            return i + 1
        i += 1
    return i


_OPEN, _CLOSE = "([{", ")]}"


def _split_call_args(text: str, start: int) -> list[str]:
    """Top-level arguments of the call whose `(` is at text[start - 1]."""
    args: list[str] = []
    depth = 0
    buf_start = start
    i = start
    while i < len(text):
        ch = text[i]
        if ch == '"':
            i = _skip_string(text, i)
            continue
        if ch in _OPEN:
            depth += 1
        elif ch in _CLOSE:
            if depth == 0:
                args.append(text[buf_start:i].strip())
                return args
            depth -= 1
        elif ch == "," and depth == 0:
            args.append(text[buf_start:i].strip())
            buf_start = i + 1
        i += 1
    args.append(text[buf_start:].strip())
    return args


def _native_query_sql(m_source: str) -> str | None:
    """Second argument of Value.NativeQuery(target, "sql", ...), decoded."""
    m = _NATIVE_RE.search(m_source)
    if not m:
        return None
    args = _split_call_args(m_source, m.end())
    if len(args) < 2 or not args[1].startswith('"'):
        return None
    sql = m_string(args[1])
    return (
        sql.replace("#(lf)", "\n").replace("#(tab)", "\t").replace("#(cr)", "")
    )


def snowflake_source_args(
    m_source: str, expressions: dict[str, str] | None = None
) -> tuple[str | None, str | None]:
    """(server, warehouse) from Snowflake.Databases(server, warehouse, ...)."""
    expressions = expressions or {}
    m = _SNOWFLAKE_SRC_RE.search(m_source)
    if not m:
        return None, None
    args = _split_call_args(m_source, m.end())
    sink: list[str] = []
    values = [
        _m_value(a, expressions, sink)[0] if i < len(args) and a else None
        for i, a in enumerate(args[:2])
    ]
    values += [None] * (2 - len(values))
    return values[0], values[1]


# ---- Table.AddColumn(..., each <expr>) -> Snowflake SQL (best effort) ----

_COL_REF = re.compile(r"^\[([^\]]+)\]$")
_NUM = re.compile(r"^-?\d+(\.\d+)?$")


def _qcol(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def _sql_text(raw: str) -> str:
    return "'" + m_string(raw).replace("'", "''") + "'"


def _strip_outer_parens(e: str) -> str:
    while e.startswith("(") and e.endswith(")"):
        depth = 0
        wrapped = True
        i = 0
        while i < len(e):
            ch = e[i]
            if ch == '"':
                i = _skip_string(e, i)
                continue
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0 and i != len(e) - 1:
                    wrapped = False
                    break
            i += 1
        if not wrapped:
            break
        e = e[1:-1].strip()
    return e


def _top_level_split(e: str, ops: str) -> tuple[list[str], list[str]]:
    """Split on single-character operators found outside strings/brackets."""
    parts: list[str] = []
    found: list[str] = []
    depth = 0
    last = 0
    i = 0
    while i < len(e):
        ch = e[i]
        if ch == '"':
            i = _skip_string(e, i)
            continue
        if ch in _OPEN:
            depth += 1
        elif ch in _CLOSE:
            depth -= 1
        elif ch in ops and depth == 0:
            prev = e[:i].rstrip()
            unary = not prev or prev[-1] in "+-*/&(,="
            if not (ch == "-" and unary):
                parts.append(e[last:i].strip())
                found.append(ch)
                last = i + 1
        i += 1
    parts.append(e[last:].strip())
    return parts, found


def _top_level_words(e: str, words: tuple[str, ...]) -> list[tuple[int, str]]:
    """Positions of keywords delimited by whitespace, outside strings and brackets."""
    out: list[tuple[int, str]] = []
    depth = 0
    i = 0
    while i < len(e):
        ch = e[i]
        if ch == '"':
            i = _skip_string(e, i)
            continue
        if ch in _OPEN:
            depth += 1
        elif ch in _CLOSE:
            depth -= 1
        elif depth == 0 and (i == 0 or e[i - 1].isspace()):
            for w in words:
                if e.startswith(w, i) and (i + len(w) == len(e) or e[i + len(w)].isspace()):
                    out.append((i, w))
                    break
        i += 1
    return out


def _translate_condition(cond: str) -> str | None:
    cond = _strip_outer_parens(cond.strip())
    tokens = _top_level_words(cond, ("or", "and"))
    if tokens:
        pieces: list[str] = []
        last = 0
        for pos, word in tokens:
            pieces.append(cond[last:pos])
            pieces.append(word.upper())
            last = pos + len(word)
        pieces.append(cond[last:])
        out: list[str] = []
        for piece in pieces:
            if piece in ("OR", "AND"):
                out.append(piece)
                continue
            translated = _translate_condition(piece)
            if translated is None:
                return None
            out.append(translated)
        return " ".join(out)
    m = re.match(r"^\[([^\]]+)\]\s*(=|<>)\s*(.+)$", cond, re.DOTALL)
    if not m:
        return None
    rhs = m.group(3).strip()
    if rhs.startswith('"') and _skip_string(rhs, 0) == len(rhs):
        value = _sql_text(rhs)
    elif _NUM.match(rhs):
        value = rhs
    else:
        return None
    return f"{_qcol(m.group(1))} {m.group(2)} {value}"


def translate_m_expression(expr: str) -> str | None:
    e = _strip_outer_parens(expr.strip())
    if not e:
        return None
    if e.startswith("if ") or e.startswith("if("):
        words = _top_level_words(e, ("if", "then", "else"))
        depth = 0
        then_pos = else_pos = None
        for pos, word in words:
            if word == "if":
                depth += 1
            elif word == "then" and depth == 1 and then_pos is None:
                then_pos = pos
            elif word == "else":
                depth -= 1
                if depth == 0:
                    else_pos = pos
                    break
        if then_pos is None or else_pos is None:
            return None
        cond = _translate_condition(e[2:then_pos])
        a = translate_m_expression(e[then_pos + 4 : else_pos])
        b = translate_m_expression(e[else_pos + 4 :])
        if cond is None or a is None or b is None:
            return None
        return f"CASE WHEN {cond} THEN {a} ELSE {b} END"
    parts, ops = _top_level_split(e, "+-*/&")
    if ops:
        translated = [translate_m_expression(p) for p in parts]
        if any(t is None for t in translated):
            return None
        out = translated[0]
        for op, t in zip(ops, translated[1:], strict=True):
            out += f" {'||' if op == '&' else op} {t}"
        return out
    m = _COL_REF.match(e)
    if m:
        return _qcol(m.group(1))
    if _NUM.match(e):
        return e
    if e.startswith('"') and _skip_string(e, 0) == len(e):
        return _sql_text(e)
    m = re.match(r"^Number\.ToText\s*\((.*)\)$", e, re.DOTALL)
    if m:
        inner = translate_m_expression(m.group(1))
        return None if inner is None else f"CAST({inner} AS VARCHAR)"
    m = re.match(r"^Date\.ToText\s*\((.*)\)$", e, re.DOTALL)
    if m:
        args = _split_call_args(m.group(1) + ")", 0)
        if len(args) == 2 and args[1].startswith('"'):
            inner = translate_m_expression(args[0])
            if inner is not None:
                return f"TO_CHAR({inner}, {_sql_text(args[1])})"
    return None


_ADD_COLUMN_RE = re.compile(r"Table\.AddColumn\s*\(", re.IGNORECASE)


def _computed_columns(m_source: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for m in _ADD_COLUMN_RE.finditer(m_source):
        args = _split_call_args(m_source, m.end())
        if len(args) < 3 or not args[1].startswith('"') or not args[2].startswith("each"):
            continue
        sql = translate_m_expression(args[2][4:])
        if sql is not None:
            out[m_string(args[1])] = sql
    return out


def parse_m_binding(m_source: str, expressions: dict[str, str] | None = None) -> MBinding:
    expressions = expressions or {}
    b = MBinding(is_snowflake=bool(_SNOWFLAKE_SRC_RE.search(m_source)))
    if not b.is_snowflake:
        for kind, pattern in _FOREIGN_SRC_RES:
            if pattern.search(m_source):
                b.foreign_source = kind
                break
        if b.foreign_source:
            # Connector.Database("server","db") — second literal is the database
            m_db = re.search(
                r'(?:Sql|PostgreSQL|MySQL|Oracle)\.Databases?\s*\(\s*"[^"]*"\s*,\s*"(?P<db>[^"]+)"',
                m_source,
                re.IGNORECASE,
            )
            if m_db:
                b.database = m_db.group("db")

    if _NATIVE_RE.search(m_source):
        b.native_query = _native_query_sql(m_source)
        return b

    # foreign navigation: {[Schema="dbo", Item="FactSales"]}[Data]
    for nav in _SCHEMA_ITEM_RE.finditer(m_source):
        for group_name, attr in (("schema", "schema"), ("item", "object_name")):
            raw = nav.group(group_name)
            value, is_param = _m_value(raw, expressions, b.warnings)
            if value is None:
                b.unresolved_params.append(_reference_name(raw))
            else:
                setattr(b, attr, value)
        if b.object_name:
            b.object_kind = "Table"

    for step in _STEP_RE.finditer(m_source):
        raw_name, kind = step.group("name"), step.group("kind")
        name, _is_param = _m_value(raw_name, expressions, b.warnings)
        if name is None:
            b.unresolved_params.append(_reference_name(raw_name))
            continue
        match (kind or "").lower():
            case "database":
                b.database = name
            case "schema":
                b.schema = name
            case "table" | "view":
                b.object_name = name
                b.object_kind = kind
            case _:
                # legacy pattern without Kind: DB{[Name=...]}[Data] order is db->schema->object
                if b.database is None:
                    b.database = name
                elif b.schema is None:
                    b.schema = name
                else:
                    b.object_name = name

    for t in _TRANSFORM_RE.finditer(m_source):
        b.transform_steps.append(t.group(1))

    b.computed_columns = _computed_columns(m_source)

    # Phase-5: extract simple SelectRows predicates → WHERE clauses
    for m_eq in _SELECT_ROWS_EQ_RE.finditer(m_source):
        col = m_eq.group("col").strip()
        val = m_eq.group("val").replace("'", "''")
        # Use safe identifier pattern (letters, digits, spaces, underscore)
        if re.match(r"^[A-Za-z0-9_$. -]+$", col) and '"' not in col:
            b.where_predicates.append(f'"{col}" = \'{val}\'')

    # Phase-5: extract RenameColumns mappings
    for rename_block_m in re.finditer(r"Table\.RenameColumns\s*\([^,]+,\s*\{(.+?)\}\s*\)", m_source, re.DOTALL):
        block = rename_block_m.group(1)
        for old, new in _RENAME_PAIR_RE.findall(block):
            b.column_renames[old] = new

    # Best-effort extraction of common Table.Group materialization shapes.
    group_match = _GROUP_RE.search(m_source)
    if group_match:
        b.group_source = group_match.group("src").strip()
        b.group_by_columns = [c for c in re.findall(r'"([^"]+)"', group_match.group("group_cols"))]
        for out_name, expr in _GROUP_AGG_RE.findall(group_match.group("aggs")):
            expr_norm = " ".join(expr.split())
            src_col_m = re.search(r"\[([A-Za-z0-9_$. -]+)\]", expr_norm)
            src_col = src_col_m.group(1).strip() if src_col_m else out_name
            agg_kind = "passthrough"
            if re.search(r"List\.Count\s*\(\s*List\.Distinct\s*\(", expr_norm, re.IGNORECASE):
                agg_kind = "count_distinct"
            elif re.search(r"List\.First\s*\(\s*List\.Sort\s*\(\s*List\.Distinct\s*\(", expr_norm, re.IGNORECASE):
                agg_kind = "min"
            elif re.search(r"List\.Count\s*\(", expr_norm, re.IGNORECASE):
                agg_kind = "count"
            b.group_aggregations.append((out_name, agg_kind, src_col))

    return b
