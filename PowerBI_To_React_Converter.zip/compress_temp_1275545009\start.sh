#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
if ! command -v powershell.exe >/dev/null 2>&1; then
  echo "powershell.exe not found on PATH" >&2
  exit 1
fi
exec powershell.exe -NoProfile -ExecutionPolicy Bypass -File start.ps1 "$@"
