# Phase 01 - Setup, configuration and runtime scripts

## Purpose
Give the target its own data folder, the enhanced settings, safer logging and the robust Windows
start/stop scripts, so every later phase runs in a stable environment.

## Current target state
- No `backend/.env`: the app writes to `~/.pbic/storage` (another installation's data). MUST change first.
- `backend/app/core/config.py`: `max_upload_bytes = 300 MB`, `openai_api_key`, no Horizon/Cortex/limits.
- `backend/app/services/ingest.py`: hard-coded `_MAX_MEMBERS = 5000`, `_MAX_UNCOMPRESSED = 500 MB`.
- `backend/app/core/logging.py`: JSONL append without a lock; redaction list contains `openai_api_key`.
- `start.ps1` / `stop.ps1`: basic versions (Start-Process with redirects, pidfile-only stop).
- `frontend/vite.config.ts`: proxies `/api` to `http://localhost:8000`.
- `frontend/src/test/setup.ts`: one line (jest-dom import).

## Required behaviour

### 1. Isolated data folder (do this before running anything)
1.1 Create `backend/.env` containing:
```
PBIC_STORAGE_DIR=C:/Users/AM79297/.pbic-target/storage
PBIC_SECRETS_KEY_FILE=C:/Users/AM79297/.pbic-target/storage/.secrets.key
```
1.2 Never read or write `~/.pbic/storage`, `~/.pbic-v0-9-0`, or any other checkout.
1.3 `backend/tests/conftest.py` must point `PBIC_STORAGE_DIR` at a pytest temp dir for the whole
session (autouse fixture / env set before `get_settings()` is first called, and `get_settings.cache_clear()`),
so tests never write to the real storage. Keep any existing conftest content.

### 2. Settings (`app/core/config.py`, env prefix `PBIC_`, `.env` file)
Add / change exactly these fields (keep all others):
| field | type / default | meaning |
|---|---|---|
| `max_upload_bytes` | int, `1024*1024*1024` (1 GB) | raw .zip upload cap |
| `max_uncompressed_bytes` | int, `4*1024*1024*1024` (4 GB) | zip-bomb guard: total unpacked size |
| `max_zip_members` | int, `20_000` | zip-bomb guard: number of entries |
| `horizon_base_url` | str, `https://api.horizon.elevancehealth.com` | Horizon gateway (phase 03) |
| `horizon_client_id` / `horizon_client_secret` | str, `""` | empty = Horizon features disabled |
| `horizon_qos` | str, `accurate` | `accurate` or `cheap` |
| `horizon_governance_qos` | str, `cheap` | qos used by governance Q&A |
| `horizon_max_requests_per_minute` | int, `15` | client-side rate limit |
| `horizon_verify_ssl` | bool, `True` | false disables TLS verification for Horizon only; log a loud warning when false |
| `llm_provider` | `Literal["cortex","horizon"]`, `cortex` | tier-2 AI provider (phase 03) |
| `cortex_model` | str, `claude-3-5-sonnet` | |
| `cortex_temperature` | float, `0.0` | |
| `cortex_max_tokens` | int, `4096` | |
| `log_llm_text` | bool, `True` | write tier-2 prompts/responses/SQL to `<conversion>/tier2_llm.jsonl`; false = metadata only |
Not a settings field: the parallel-query bound is read once at import by `app/core/parallel.py`
from the env var `PBIC_MAX_PARALLEL_QUERIES` (default 8, minimum 1) - see phase 06.
Remove `openai_api_key` (phase 03 removes its uses).

### 3. Zip limits (`services/ingest.py`)
3.1 `safe_extract_zip(archive, dest, max_members=None, max_uncompressed=None)`: when an argument is
None it comes from settings (`max_zip_members`, `max_uncompressed_bytes`). Keep the existing
compression-ratio guard (200) and the zip-slip protection unchanged.
3.2 The upload endpoint enforces `max_upload_bytes`. The Upload step's helper text reads
"Up to 1 GB · zip-slip & zip-bomb protected".
3.3 Add `IngestService.save_bundle(conversion_id, bundle)`: rewrites `<conversion>/bundle.json`
(`model_dump_json(indent=2)`, utf-8); raises `IngestError("unknown conversion: <id>")` if the file
doesn't exist. (Used by later phases to persist rewrites, case fixes, measure SQL.)
3.4 When loading a PBIP folder, pass `generated_dir=<conversion root>/generated_model` to
`load_pbip` (phase 04) so converted TMSL is never written into the uploaded folder.

### 4. Logging (`app/core/logging.py`)
4.1 Redaction key list: add `passcode`, `client_secret`, `horizon_client_secret`; remove `openai_api_key`.
Keep all existing keys (password, token, private key, ...).
4.2 The JSONL append helper serialises the line first, then writes under a module-level
`threading.Lock` (queries run in parallel threads; lines must never interleave).

### 5. App entry (`app/main.py`)
5.1 Register an exception handler for `SnowflakeWarehouseError` (phase 02) returning
HTTP 422 `{"detail": str(exc)}`.
5.2 Include the new routers as later phases add them (`llm` router in phase 03).
5.3 Keep `/healthz` -> `{"status": "ok"}`.

### 6. Frontend dev config
6.1 `vite.config.ts`: `/api` proxy default `http://127.0.0.1:8000` (Node 17+ may resolve
`localhost` to `::1` where uvicorn doesn't listen; the proxy then returns an empty 500). `PBIC_API_URL`
still overrides.
6.2 `package.json` script `"build:standalone": "tsc -b && vite build --config vite.standalone.config.ts"`
(the config itself is created in phase 12).
6.3 `src/test/setup.ts`: keep the jest-dom import; if `globalThis.localStorage?.getItem` is not a
function, install an in-memory `Storage` (Map-backed: length, clear, getItem, key, removeItem,
setItem) via `Object.defineProperty(globalThis, 'localStorage', {value, configurable: true})`.
(Node 26's experimental localStorage global is undefined without a file and shadows jsdom's.)

### 7. `start.ps1` (Windows PowerShell 5.1 compatible)
Parameters: `-SkipInstall`, `-InstallOnly`, `-Reload`, `-ApiPort 8000`, `-WebPort 5173`.
7.1 Check `uv`, `node`, `npm` are on PATH, with install hints.
7.2 Without `-SkipInstall`: first run `stop.ps1 -ApiPort -WebPort` (warn, don't fail); create
`backend/.venv` with `uv venv` if missing; `uv sync --all-extras --all-groups --system-certs`, retried
up to 3 times with a growing sleep, failing with a message suggesting tools scanning `.venv` may hold
files; then `npm install` in `frontend`. `-InstallOnly` exits here.
7.3 The API runs as `backend\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port <ApiPort>`
- never `uv run` (re-syncs; fails behind a TLS-inspecting proxy) and never `.venv\Scripts\uvicorn.exe`
(uv trampoline fails under OneDrive paths). Verify `import uvicorn` works first. `--reload` only with
`-Reload` (Snowflake sessions live in the API process: a reload signs everyone out).
7.4 Ports: if either port is in use, run `stop.ps1` once; if still held, print the owning pid and exit 1.
7.5 `Start-Detached`: start each server via
`cmd.exe /d /s /c "<quoted command> 1>"<out>" 2>"<err>" <NUL"` with `Start-Process -WindowStyle Hidden -PassThru`
(own hidden console, stdin from NUL). Never `Start-Process -Redirect*` (the child shares the terminal,
Vite takes raw-mode stdin and the prompt freezes). Quote arguments containing spaces/special chars.
7.6 Health: `Test-Http` uses `[System.Net.HttpWebRequest]` with `Proxy = $null`, 2 s timeout; any HTTP
status (including error responses) counts as up. `Wait-ForHttp -Urls[] -TimeoutSec -Process`: the
first URL answering wins; stops early if the process exited. API: wait for `/healthz` up to 120 s;
on failure print the last 25 lines of `logs/api.err.log` (`Show-LogTail`), run stop.ps1 and exit 1
(don't start the web app against a dead API).
7.7 Web: `$env:PBIC_API_URL = http://127.0.0.1:<ApiPort>`, start `npm.cmd run dev -- --port <WebPort>`
detached, wait on `http://127.0.0.1:<port>` and `http://[::1]:<port>`; on timeout warn + log tail.
7.8 Write `.dev-pids.json` `{api, web}`; print Studio / API docs / logs / stop hints. Logs go to `<root>/logs`.

### 8. `stop.ps1`
Parameters `-ApiPort 8000`, `-WebPort 5173`. Collect a kill set from:
(1) pids in `.dev-pids.json` that still exist; (2) owners of the two listening ports;
(3) every process whose name is in `uv.exe, uvicorn.exe, python.exe, node.exe, cmd.exe, npm.cmd` and
whose command line contains this checkout's `backend` or `frontend` path. For each, add its
ancestors (max 8 levels, only while the parent's name is in that list) and descendants (walk only
into children in that list; the root itself is always included). `Stop-Process -Force` each,
remove the pidfile, then wait up to 10 s for both ports to be free; if still held, warn with pid,
name and command line and exit 1; else print "Ports X and Y are free."

### 9. Git Bash wrappers
`start.sh` / `stop.sh`: `cd` to the script dir and run
`powershell.exe -NoProfile -ExecutionPolicy Bypass -File start.ps1 "$@"` (resp. stop.ps1); error if
powershell.exe isn't on PATH.

### 10. Docs
`.env.example`: replace the OpenAI block with Horizon (`PBIC_HORIZON_CLIENT_ID`,
`PBIC_HORIZON_CLIENT_SECRET`) and `PBIC_LLM_PROVIDER=cortex`, `PBIC_CORTEX_MODEL=claude-3-5-sonnet`
with one-line comments (Cortex role needs `SNOWFLAKE.CORTEX_USER`; Analyze can override per conversion).

## Files
Create: `backend/.env`, `start.sh`, `stop.sh`, `AGENTS.md` (start it here; see phase 13).
Modify: `backend/app/core/config.py`, `backend/app/core/logging.py`, `backend/app/services/ingest.py`,
`backend/app/main.py`, `backend/tests/conftest.py`, `start.ps1`, `stop.ps1`, `.env.example`,
`frontend/vite.config.ts`, `frontend/package.json`, `frontend/src/test/setup.ts`,
`frontend/src/steps/UploadStep.tsx`.

## Tests
- `safe_extract_zip` honours explicit and settings-driven member/size limits (tiny limits in test).
- `save_bundle` round-trips and raises for an unknown id.
- Logging: a dict with `passcode` / `client_secret` is redacted; parallel appends from 8 threads
  produce only whole JSON lines.
- conftest storage isolation: `get_settings().storage_dir` is under the pytest temp dir.

## Done criteria
- `backend/.env` exists and the app writes only under `~/.pbic-target`.
- `./start.ps1 -SkipInstall` starts both servers detached, `./stop.ps1` frees both ports.
- Backend suite: no new failures vs the baseline; `npx tsc -b` clean; vitest passes.
 