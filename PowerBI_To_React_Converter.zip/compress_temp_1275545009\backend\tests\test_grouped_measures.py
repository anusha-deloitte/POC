"""Grouped "cap" measures: SUMMARIZE -> GROUPBY levels -> count over a filter (phase 06.6)."""

from __future__ import annotations

import pytest

from app.dax.compiler import DaxUnsupported
from app.runtime.engine import DimensionRef, FilterClause, MeasureRefSpec, QueryPlanError, QuerySpec
from tests.duck import DuckWorld

# Member, ClaimId, Paid, Year, Region, Grp
CLAIMS = [
    (1, "c1", 100.0, 2024, "N", "g1"),
    (1, "c2", 200.0, 2024, "N", "g1"),
    (1, "c2", 200.0, 2024, "N", "g1"),  # duplicate line: SUMMARIZE collapses it
    (2, "c3", 150.0, 2024, "S", "g2"),
    (3, "c4", 300.0, 2024, "N", "g2"),
    (4, "c5", 900.0, 2023, "N", "g1"),
]

SUMMARIZE = "SUMMARIZE(Claims, Claims[Member], Claims[ClaimId], Claims[Paid], Claims[Grp])"


def at_cap(cap: int) -> str:
    return (
        f"VAR g0 = CALCULATETABLE({SUMMARIZE}, Claims[Year] = 2024) "
        'VAR g1 = GROUPBY(g0, Claims[Member], "tot", SUMX(CURRENTGROUP(), Claims[Paid])) '
        f"RETURN CALCULATE(DISTINCTCOUNT(Claims[Member]), FILTER(g1, [tot] >= {cap}))"
    )


def groups_at(cap: int) -> str:
    return (
        f"VAR g0 = CALCULATETABLE({SUMMARIZE}, Claims[Year] = 2024) "
        'VAR g1 = GROUPBY(g0, Claims[Grp], "tot", SUMX(CURRENTGROUP(), Claims[Paid])) '
        f"RETURN COUNTROWS(FILTER(g1, [tot] > {cap}))"
    )


def world(extra: dict[str, str] | None = None) -> DuckWorld:
    return DuckWorld(
        {"Claims": (["Member", "ClaimId", "Paid", "Year", "Region", "Grp"], CLAIMS)},
        measures={
            "Total": "SUM(Claims[Paid])",
            "Members At 250": at_cap(250),
            "Members At 450": at_cap(450),
            "Groups Over 400": groups_at(400),
            **(extra or {}),
        },
    )


def test_members_at_cap_card_dedupes_summarized_rows():
    w = world()
    assert w.value("Members At 250") == 2  # members 1 (300 after dedupe) and 3 (300)
    # raw sums would make member 1 reach 500; after SUMMARIZE collapses the duplicate it is 300
    assert w.value("Members At 450") == 0


def test_groups_at_cap_card_counts_rows_of_the_grouped_table():
    w = world()
    # group g1 = 300 (members 1), g2 = 450 (members 2 + 3): only g2 > 400
    assert w.value("Groups Over 400") == 1


def test_per_visual_row_and_outer_context_filters_the_summarized_rows():
    w = world()
    rows = w.run(
        QuerySpec(
            dimensions=[DimensionRef(table="Claims", column="Region")],
            measures=[MeasureRefSpec(name="Members At 250")],
        )
    )
    assert rows == [("N", 2)]  # S has member 2 at 150: no members at cap -> all-blank row dropped
    filtered = w.value(
        "Members At 250", filters=[FilterClause(table="Claims", column="Region", values=["S"])]
    )
    assert filtered == 0
    only_n = w.value(
        "Members At 250", filters=[FilterClause(table="Claims", column="Member", values=[1])]
    )
    assert only_n == 1


def test_combines_with_other_measures():
    w = world()
    rows = w.run(
        QuerySpec(
            dimensions=[DimensionRef(table="Claims", column="Region")],
            measures=[MeasureRefSpec(name="Members At 250"), MeasureRefSpec(name="Total")],
        )
    )
    assert rows == [("N", 2, 1700.0), ("S", None, 150.0)]


def test_countrows_over_the_summarized_table_without_a_filter():
    w = world(
        {
            "Rows": f"VAR g0 = CALCULATETABLE({SUMMARIZE}, Claims[Year] = 2024) RETURN COUNTROWS(g0)"
        }
    )
    assert w.value("Rows") == 4  # c1, c2 (deduplicated), c3, c4


def test_two_groupby_levels():
    w = world(
        {
            "Lvl": f"VAR g0 = CALCULATETABLE({SUMMARIZE}, Claims[Year] = 2024) "
            'VAR g1 = GROUPBY(g0, Claims[Member], Claims[Grp], "tot", SUMX(CURRENTGROUP(), Claims[Paid])) '
            'VAR g2 = GROUPBY(g1, Claims[Grp], "gt", SUMX(CURRENTGROUP(), [tot])) '
            "RETURN COUNTROWS(FILTER(g2, [gt] > 400))"
        }
    )
    assert w.value("Lvl") == 1


def test_unsupported_shapes_name_the_shape():
    bad_summarize = world(
        {"B1": 'COUNTROWS(FILTER(SUMMARIZE(Claims, Claims[Member], "x", SUM(Claims[Paid])), [x] > 1))'}
    )
    with pytest.raises((DaxUnsupported, QueryPlanError), match="SUMMARIZE"):
        bad_summarize.value("B1")
    bad_groupby = world(
        {
            "B2": f"VAR g0 = {SUMMARIZE} VAR g1 = GROUPBY(g0, Claims[Member], \"t\", SUM(Claims[Paid])) "
            "RETURN COUNTROWS(g1)"
        }
    )
    with pytest.raises((DaxUnsupported, QueryPlanError), match="CURRENTGROUP"):
        bad_groupby.value("B2")
    ctx_dependent = world(
        {
            "B3": f"VAR g0 = {SUMMARIZE} "
            'VAR g1 = GROUPBY(g0, Claims[Member], "t", SUMX(CURRENTGROUP(), Claims[Paid])) '
            "RETURN COUNTROWS(FILTER(g1, [t] > [Total]))"
        }
    )
    with pytest.raises((DaxUnsupported, QueryPlanError), match="context dependent"):
        ctx_dependent.value("B3")
    other_col = world(
        {
            "B4": f"VAR g0 = {SUMMARIZE} "
            'VAR g1 = GROUPBY(g0, Claims[Member], "t", SUMX(CURRENTGROUP(), Claims[Year])) '
            "RETURN COUNTROWS(g1)"
        }
    )
    with pytest.raises((DaxUnsupported, QueryPlanError), match="not one of the grouped table"):
        other_col.value("B4")  # Year is not one of the SUMMARIZE columns
