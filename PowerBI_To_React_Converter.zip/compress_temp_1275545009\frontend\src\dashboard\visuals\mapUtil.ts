/** US-states choropleth helpers: state matching, an albersUsa projection (Alaska / Hawaii insets)
 * and the gradient colour rule. */

export const US_STATES: Record<string, string> = {
  Alabama: 'AL', Alaska: 'AK', Arizona: 'AZ', Arkansas: 'AR', California: 'CA', Colorado: 'CO',
  Connecticut: 'CT', Delaware: 'DE', 'District of Columbia': 'DC', Florida: 'FL', Georgia: 'GA',
  Hawaii: 'HI', Idaho: 'ID', Illinois: 'IL', Indiana: 'IN', Iowa: 'IA', Kansas: 'KS',
  Kentucky: 'KY', Louisiana: 'LA', Maine: 'ME', Maryland: 'MD', Massachusetts: 'MA',
  Michigan: 'MI', Minnesota: 'MN', Mississippi: 'MS', Missouri: 'MO', Montana: 'MT',
  Nebraska: 'NE', Nevada: 'NV', 'New Hampshire': 'NH', 'New Jersey': 'NJ', 'New Mexico': 'NM',
  'New York': 'NY', 'North Carolina': 'NC', 'North Dakota': 'ND', Ohio: 'OH', Oklahoma: 'OK',
  Oregon: 'OR', Pennsylvania: 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC',
  'South Dakota': 'SD', Tennessee: 'TN', Texas: 'TX', Utah: 'UT', Vermont: 'VT', Virginia: 'VA',
  Washington: 'WA', 'West Virginia': 'WV', Wisconsin: 'WI', Wyoming: 'WY',
} // prettier-ignore

const BY_FULL = new Map(Object.keys(US_STATES).map((n) => [n.toLowerCase(), n]))
const BY_CODE = new Map(Object.entries(US_STATES).map(([n, c]) => [c.toLowerCase(), n]))

/** Full state name for a value (case-insensitive, full name or USPS code), else null so values
 * like "Not Mapped" are never drawn. */
export function stateName(value: unknown): string | null {
  if (value === null || value === undefined) return null
  const key = String(value).trim().toLowerCase()
  return BY_FULL.get(key) ?? BY_CODE.get(key) ?? null
}

const rad = (d: number) => (d * Math.PI) / 180
const deg = (r: number) => (r * 180) / Math.PI

interface AlbersParams {
  rotate: number
  center: [number, number]
  parallels: [number, number]
  scale: number
  translate: [number, number]
}

function albersRaw(lon: number, lat: number, [p1, p2]: [number, number]) {
  const n = (Math.sin(rad(p1)) + Math.sin(rad(p2))) / 2
  const c = Math.cos(rad(p1)) ** 2 + 2 * n * Math.sin(rad(p1))
  const rho0 = Math.sqrt(c) / n
  const rho = Math.sqrt(c - 2 * n * Math.sin(rad(lat))) / n
  const theta = n * rad(lon)
  return { x: rho * Math.sin(theta), y: rho0 - rho * Math.cos(theta), n, c, rho0 }
}

function albers(lon: number, lat: number, p: AlbersParams): [number, number] {
  const pt = albersRaw(lon + p.rotate, lat, p.parallels)
  const centre = albersRaw(p.center[0], p.center[1], p.parallels)
  return [
    p.translate[0] + p.scale * (pt.x - centre.x),
    p.translate[1] - p.scale * (pt.y - centre.y),
  ]
}

const K = 1070
export const LOWER48: AlbersParams = { rotate: 96, center: [-0.6, 38.7], parallels: [29.5, 45.5], scale: K, translate: [480, 250] }
export const ALASKA: AlbersParams = { rotate: 154, center: [-2, 58.5], parallels: [55, 65], scale: K * 0.35, translate: [480 - 0.307 * K, 250 + 0.201 * K] }
export const HAWAII: AlbersParams = { rotate: 157, center: [-3, 19.9], parallels: [8, 18], scale: K, translate: [480 - 0.205 * K, 250 + 0.212 * K] }

/** albersUsa: the lower 48 plus insets for Alaska and Hawaii, in a 960 x 500 box. */
export function albersUsa(lon: number, lat: number): [number, number] {
  if (lat >= 50 && lat <= 72 && lon >= -180 && lon <= -129) return albers(lon, lat, ALASKA)
  if (lat >= 18 && lat <= 23 && lon >= -161 && lon <= -154) return albers(lon, lat, HAWAII)
  return albers(lon, lat, LOWER48)
}

/** Best-effort inverse for the lower 48 (ECharts only uses it for hit tests). */
export function albersUsaInverse(x: number, y: number): [number, number] {
  const p = LOWER48
  const centre = albersRaw(p.center[0], p.center[1], p.parallels)
  const { n, c, rho0 } = albersRaw(0, 0, p.parallels)
  const px = (x - p.translate[0]) / p.scale + centre.x
  const py = -(y - p.translate[1]) / p.scale + centre.y
  const rho = Math.sign(n) * Math.hypot(px, rho0 - py)
  const theta = Math.atan2(px, rho0 - py) / n
  const lat = deg(Math.asin((c - (rho * n) ** 2) / (2 * n)))
  return [deg(theta) - p.rotate, lat]
}

export interface Gradient {
  min: string
  mid?: string
  max: string
  minValue?: number
  midValue?: number
  maxValue?: number
}

function hexToRgb(hex: string): [number, number, number] {
  const h = hex.replace('#', '')
  const full = h.length === 3 ? h.split('').map((c) => c + c).join('') : h
  return [parseInt(full.slice(0, 2), 16), parseInt(full.slice(2, 4), 16), parseInt(full.slice(4, 6), 16)]
}

const mix = (a: string, b: string, t: number): string => {
  const [r1, g1, b1] = hexToRgb(a)
  const [r2, g2, b2] = hexToRgb(b)
  const f = (x: number, y: number) => Math.round(x + (y - x) * t).toString(16).padStart(2, '0')
  return `#${f(r1, r2)}${f(g1, g2)}${f(b1, b2)}`.toUpperCase()
}

/** min/max default to the data extremes and the mid stop sits halfway. */
export function gradientStops(g: Gradient, values: number[]): { min: number; mid: number; max: number } {
  const lo = g.minValue ?? Math.min(...values)
  const hi = g.maxValue ?? Math.max(...values)
  return { min: lo, mid: g.midValue ?? (lo + hi) / 2, max: hi }
}

export function gradientColor(g: Gradient, stops: { min: number; mid: number; max: number }, value: number): string {
  if (stops.max === stops.min) return g.mid ?? g.max
  if (g.mid) {
    if (value <= stops.min) return g.min
    if (value >= stops.max) return g.max
    return value <= stops.mid
      ? mix(g.min, g.mid, (value - stops.min) / ((stops.mid - stops.min) || 1))
      : mix(g.mid, g.max, (value - stops.mid) / ((stops.max - stops.mid) || 1))
  }
  const t = Math.max(0, Math.min(1, (value - stops.min) / (stops.max - stops.min)))
  return mix(g.min, g.max, t)
}
