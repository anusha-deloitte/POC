# Phase 11 - Drill-through pages and report-page tooltips

## Purpose
Right-clicking a data point offers "Drill through ›" to the pages that can receive it; the target page opens filtered by the point and
everything filtering the source visual (Power BI's default "Keep all filters"). Hovering a data point of a visual that has a tooltip page
shows that page at its own size next to the pointer. Requires phases 09 and 10.

## 1. Parser (`parsers/pbir.py`, `ir/report.py`)
1.1 `Page.page_type` = page.json `type` (`Tooltip` = report-page tooltip; others e.g. ReportSection).
1.2 `Page.drillthrough: list[DrillthroughField {table, name, is_measure, hierarchy, bound_filter}]` from `page.json pageBinding` when
`type == "Drillthrough"`: each `parameters[].fieldExpr` (Column, Measure or HierarchyLevel - hierarchy levels resolve to their level column
by name), `boundFilter` names the page's "Drill through" filter entry.
1.3 `Visual.tooltip = {show, type, section}` from `visualTooltip` in `objects` and `visualContainerObjects` (literal values): type `Canvas` =
a report page (`section` = page name or `___AUTO___`), `Default` = Power BI's field tooltip.
1.4 Action type `Drillthrough` (phase 04 6.5): `page = drillthroughSection`.
1.5 Stored bundles get these from `filters_passthrough` while `Report.pages_parsed` is False (phase 10).

## 2. Spec (`runtime/dashboard.py`)
2.1 `DrillthroughFieldSpec {table, column, measure}` with `key = "Table.Column"` for columns. `PageSpec.page_type`, `PageSpec.drillthrough`
(`_drillthrough_fields`: columns by their exact model name, measures when the model or a report-extension measure has them; anything else
-> warning "drill-through page 'X': field T[c] is not in the model; ignored").
2.2 `VisualSpec.tooltip_page` (`_tooltip_page`): None when `show` is false, type is Default or there is no section; the section when it
names an exported Tooltip page; `___AUTO___` -> None (default tooltip); a missing section is counted and reported once per page as a spec
warning (with the number of visuals referencing it).
2.3 `DashboardSpec.drill_through = [DrillThroughTarget(page, fields=[key or measure])]` for pages with drill-through fields.
2.4 Page tabs show only non-hidden pages (Power BI tooltip and drill-through pages are normally hidden pages; no extra rule). Drill-through entries (`howCreated == Drillthrough`) are not Filters pane cards (phase 10).

## 3. Frontend
3.1 `dashboard/dataPoint.ts`: `DataPoint = Record<"Table.Column", string|number|null>`; `DataPointContext` (set by PageCanvas around each
visual; visuals report the point under the pointer, null when it leaves); `chartPoint(spec, name, seriesName)`: category = the first dim key
that isn't a series key (empty names skipped), series = `series_keys[0]`; nested category axes report their first level only;
`rowPoint(spec, columns, row)`: every dim key present in the result (NULL kept).
3.2 Visuals report points: ECharts charts via `EChart.onItemHover` (series items only; axis-label events never count, phase 09),
Combo/Scatter likewise, tables/matrices via row `mouseenter`/`mouseleave`. Heatmap and map visuals don't report points.
3.3 `PageCanvas` props `onDrillMenu(visual, point, at)` (contextmenu; prevents the browser menu only when a menu opens) and
`onTooltip(visual, point|null, at)` (hover); visuals without categories (cards, gauges) use the whole container as the data point (empty point).
3.4 `dashboard/drillthrough.ts`:
- `drillTargets(spec, visual, fromPage)`: every other page with at least ONE drill-through field the visual uses (a column in `dim_keys`, a
  measure in `measure_keys`). ("Any", not "all": with "all", reports commonly have unreachable drill pages.)
- `pointClauses(point)`: each `Table.Column` -> `{table, column, values: [value]}` (BLANK stays NULL).
- `contextClauses(visual, point, requestFilters, source)`: point clauses, then the source visual's request filters except
  `source === 'report_filter'` (every page applies report filters already), then the visual's own query filters (visual-level filters);
  all tagged `source: 'drillthrough' | 'tooltip'`.
- `clauseText(f)`: "Country is France", "is not ...", "(Blank)" for null/empty, other ops as words.
3.5 `DrillMenu.tsx`: Power BI's context menu at the pointer: `role="menu"` with a "Drill through ›" `menuitem` opening a submenu
(`role="menu" aria-label="Drill through"`) listing target page display names; Escape / outside click closes; choosing a page drills.
3.6 `DashboardApp.tsx`:
- `drillState {page, clauses}`; `drillTo(target, clauses)`: close the menu, navigate (which resets page-local state), then set
  drillState; the target page adds `drillState.clauses` to every visual's request filters; ANY page change (Back, tabs, navigation) clears it.
- `onDrillMenu`: open the menu only when `drillTargets` is non-empty.
- Drill-through buttons (action type Drillthrough with a page): drill with `contextClauses(visual, {}, filtersOf(visual), 'drillthrough')`.
- Tooltips: `onTooltip` clears a pending timer; no point, no `tooltip_page`, or an open drill menu -> hide; else show after 350 ms.
- `TooltipPage.tsx` (`role="tooltip"`, `data-testid="tooltip-page"`): renders the Tooltip page with `PageCanvas` at its own page size
  (actual size) next to the pointer (kept inside the viewport), queried with the report cards + the tooltip page's own cards
  (`paneClauses`) + the context clauses, cached by react-query (same point = instant), using the same theme/resources.
- ECharts' own tooltip is turned off (`withoutTooltip`) for visuals that have a tooltip page.
- The old header "Drill:" buttons (navigating without filters) are removed.
- Filters pane: a read-only "Drill through" section listing `clauseText` of the drill clauses on the target page.
3.7 Types: `PageSpec.page_type`, `PageSpec.drillthrough: DrillthroughField[]`, `VisualSpec.tooltip_page`.

## 4. Standalone (implemented in phase 12, specified here)
Drill-through and tooltip pages get template slots for every source visual's dims, visual filters and source-page slots
(`standalone_export.drill_sources(spec)` mirrors `drillTargets`; `source_slot_columns`), so their queries accept the context filters.

## Files
Create: `frontend/src/dashboard/{dataPoint.ts, drillthrough.ts, DrillMenu.tsx, TooltipPage.tsx}`.
Modify: `ir/report.py`, `parsers/pbir.py`, `runtime/dashboard.py`, frontend `dashboard/{types.ts, PageCanvas.tsx, DashboardApp.tsx,
FiltersPane.tsx}`, `visuals/{EChart,ChartVisual,ComboVisual,ScatterVisual,TableVisual}.tsx`.

## Tests
Backend (`test_global_filters.py`): drill-through pages and tooltips parsed and in the spec (fields resolved, unknown fields warned, tooltip
page only for exported Tooltip pages, `___AUTO___` default, missing sections warned, `drill_through` list); drill/tooltip fields reach stored
bundles via passthrough; standalone slots for drill and tooltip pages.
Frontend (`src/test/drillTooltip.test.tsx`): a page is offered when the visual uses any of its fields; data points and the filters they pass
("Keep all filters", report filters excluded, tagged sources); right-click a table row -> Drill through -> the target page queried with the
row and its context; no menu for a visual that drills nowhere; hovering a card shows its tooltip page queried with the card context.

## Done criteria
Right-click drill-through and hover tooltips work on a synthetic report with one drill page and one tooltip page; tests pass.
 