"""Number checks: PDF printed values vs the converted visuals' query results."""

from __future__ import annotations

from app.runtime.dashboard import PageSpec, VisualSpec
from app.services import pdf_values as pv
from app.services.pdf_text import PdfPageText, TextRun

PAGE_W, PAGE_H = 1280.0, 720.0


def vspec(name, vtype, x, y, w, h, dims=(), measures=("Total",), formats=None, **kw) -> VisualSpec:
    return VisualSpec(
        name=name, visual_type=vtype, x=x, y=y, width=w, height=h, dim_keys=list(dims),
        measure_keys=list(measures), measure_formats=formats or {}, **kw,
    )  # fmt: skip


def page_of(*visuals) -> PageSpec:
    return PageSpec(
        name="p", display_name="P", width=PAGE_W, height=PAGE_H, ordinal=0, visuals=list(visuals)
    )


def run(text, cx, cy, size=12, scale=1.0) -> TextRun:
    """A run centred at canvas pixel (cx, cy); `scale` = PDF points per canvas px."""
    w = max(len(text) * size * 0.5, 4) * scale
    return TextRun(
        text, cx * scale - w / 2, cy * scale - 6, cx * scale + w / 2, cy * scale + 6, size
    )


def pdf_of(*runs, scale=1.0) -> PdfPageText:
    return PdfPageText(0, PAGE_W * scale, PAGE_H * scale, list(runs))


def res(visual, columns, rows, totals=None, error=None) -> dict:
    return {"visual": visual, "columns": columns, "rows": rows, "totals": totals, "error": error}


def only(report, name):
    return next(v for v in report["visuals"] if v["visual"] == name)


def test_card_values_match_with_abbreviations_and_rounding():
    card = vspec("card", "card", 0, 0, 300, 200)
    page = page_of(card)
    pdf = pdf_of(run("$2.14M", 150, 100))
    ok = pv.check_values(page, pdf, [res("card", ["Total"], [[2_143_000.0]])])
    assert only(ok, "card")["status"] == "match" and ok["summary"]["numbers_matched"] == 1
    bad = pv.check_values(page, pdf, [res("card", ["Total"], [[2_300_000.0]])])
    v = only(bad, "card")
    assert v["status"] == "mismatch" and v["numbers"][0]["nearest"] == 2_300_000.0
    assert bad["summary"]["mismatch"] == 1 and bad["summary"]["numbers_matched"] == 0


def test_runs_belong_to_the_smallest_containing_visual():
    big = vspec("panel", "tableEx", 0, 0, 1000, 600, dims=("T.Name",))
    card = vspec("card", "card", 100, 100, 200, 100)
    page = page_of(big, card)
    pdf = pdf_of(run("1,000", 200, 150))
    report = pv.check_values(
        page,
        pdf,
        [res("card", ["Total"], [[1000.0]]), res("panel", ["T.Name", "Total"], [["a", 5.0]])],
    )
    assert only(report, "card")["status"] == "match"
    assert only(report, "panel")["status"] == "not_checked"


def test_percent_checks_use_shares_and_percent_formatted_measures():
    bar = vspec("bar", "barChart", 0, 0, 600, 400, dims=("T.Name",), formats={"Total": "0.0%"})
    page = page_of(bar)
    cols, rows = ["T.Name", "Total"], [["a", 0.25], ["b", 0.75]]
    share = pv.check_values(page, pdf_of(run("25.0%", 100, 100)), [res("bar", cols, rows)])
    assert only(share, "bar")["status"] == "match"  # the value 0.25 in a 0.0% format
    plain = vspec("bar", "barChart", 0, 0, 600, 400, dims=("T.Name",))
    shares = pv.check_values(
        page_of(plain), pdf_of(run("30%", 100, 100)), [res("bar", cols, [["a", 30.0], ["b", 70.0]])]
    )
    assert only(shares, "bar")["status"] == "match"  # 30 of 100 total = 30 %


def test_totals_are_candidates_too():
    table = vspec("t", "tableEx", 0, 0, 600, 400, dims=("T.Name",))
    result = res(
        "t", ["T.Name", "Total"], [["a", 4.0], ["b", 6.0]], {"columns": ["Total"], "row": [10.0]}
    )
    report = pv.check_values(page_of(table), pdf_of(run("10", 100, 100)), [result])
    assert only(report, "t")["status"] == "match"


def test_category_labels_are_not_checked_as_numbers():
    bar = vspec("bar", "barChart", 0, 0, 600, 400, dims=("D.Year",))
    result = res("bar", ["D.Year", "Total"], [[2023, 10.0], [2024, 20.0]])
    pdf = pdf_of(run("2023", 100, 380), run("2024", 300, 380), run("10", 100, 100))
    report = pv.check_values(page_of(bar), pdf, [result])
    v = only(report, "bar")
    assert [n["text"] for n in v["numbers"]] == ["10"] and v["status"] == "match"


def test_evenly_spaced_axis_ticks_are_skipped_but_not_on_cards():
    bar = vspec("bar", "barChart", 0, 0, 600, 400, dims=("T.Name",))
    # right-aligned labels share their right edge, like a real value axis
    ticks = [
        TextRun(str(v), 60 - len(str(v)) * 6, 344 - i * 60, 60, 356 - i * 60, 12)
        for i, v in enumerate((0, 50, 100, 150))
    ]
    pdf = pdf_of(*ticks, run("37", 300, 100))
    result = res("bar", ["T.Name", "Total"], [["a", 37.0]])
    report = pv.check_values(page_of(bar), pdf, [result])
    assert [n["text"] for n in only(report, "bar")["numbers"]] == ["37"]
    # the same four numbers inside a card are real values, not axis ticks
    card = vspec("card", "card", 0, 0, 600, 400)
    cr = pv.check_values(
        page_of(card), pdf_of(*ticks), [res("card", ["Total"], [[0.0], [50.0], [100.0], [150.0]])]
    )
    assert len(only(cr, "card")["numbers"]) == 4


def test_unevenly_spaced_numbers_are_kept():
    bar = vspec("bar", "barChart", 0, 0, 600, 400, dims=("T.Name",))
    runs = [run(v, 300, 60 + i * 80) for i, v in enumerate(("5", "9", "30"))]
    report = pv.check_values(
        page_of(bar),
        pdf_of(*runs),
        [res("bar", ["T.Name", "Total"], [["a", 5.0], ["b", 9.0], ["c", 30.0]])],
    )
    assert len(only(report, "bar")["numbers"]) == 3 and only(report, "bar")["status"] == "match"


def test_statuses_not_found_and_not_checked_and_static_visuals_skipped():
    card = vspec("card", "card", 0, 0, 300, 200)
    text = vspec("tb", "textbox", 400, 0, 300, 200, measures=())
    slicer = vspec("sl", "slicer", 800, 0, 300, 200, measures=())
    page = page_of(card, text, slicer)
    pdf = pdf_of(run("42", 150, 100), run("99", 500, 100), run("2024", 900, 100))
    nothing = pv.check_values(page, pdf, [res("card", ["Total"], [], error="boom")])
    names = [v["visual"] for v in nothing["visuals"]]
    assert names == ["card"]
    v = only(nothing, "card")
    assert v["status"] == "not_found" and v["error"] == "boom"
    quiet = pv.check_values(page, pdf_of(), [res("card", ["Total"], [[1.0]])])
    assert only(quiet, "card")["status"] == "not_checked"
    assert quiet["summary"] == {
        "match": 0, "mismatch": 0, "not_found": 0, "not_checked": 1, "numbers_printed": 0, "numbers_matched": 0,
    }  # fmt: skip


def test_hidden_and_empty_boxes_are_skipped():
    hidden = vspec("h", "card", 0, 0, 300, 200, pbir={"is_hidden": True})
    zero = vspec("z", "card", 0, 0, 0, 0)
    report = pv.check_values(page_of(hidden, zero), pdf_of(run("5", 100, 100)), [])
    assert report["visuals"] == []


def test_scaled_and_letterboxed_pdfs_map_to_canvas_pixels():
    card = vspec("card", "card", 0, 600, 300, 100)
    page = page_of(card)
    # the PDF is 0.75 pt/px and 50 pt taller than the canvas: 25 pt of padding above and below
    pdf = PdfPageText(0, PAGE_W * 0.75, PAGE_H * 0.75 + 50, [run("7", 150, 650, scale=0.75)])
    pdf.runs[0].y0 += 25
    pdf.runs[0].y1 += 25
    report = pv.check_values(page, pdf, {"card": res("card", ["Total"], [[7.0]])})
    assert only(report, "card")["status"] == "match"


def test_results_may_be_a_dict_by_visual():
    card = vspec("card", "card", 0, 0, 300, 200)
    report = pv.check_values(
        page_of(card), pdf_of(run("5", 100, 100)), {"card": res("card", ["Total"], [[5.0]])}
    )
    assert only(report, "card")["status"] == "match"
