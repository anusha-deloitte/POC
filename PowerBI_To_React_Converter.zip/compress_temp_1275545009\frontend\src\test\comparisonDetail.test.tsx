import { render, screen, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { describe, expect, it, vi } from 'vitest'
import { ComparisonDetail } from '../dashboard/parity/ComparisonDetail'
import { comparison, values } from './parityFixtures'

describe('ComparisonDetail', () => {
  it('shows both images, similarity, finding count and matched filters', () => {
    render(<ComparisonDetail conversionId="c1" comparison={comparison} />)
    expect(screen.getByText('82% similar')).toBeInTheDocument()
    expect(screen.getByText('3 findings', { exact: false })).toBeInTheDocument()
    expect(screen.getByText(/Year=2024/)).toBeInTheDocument()
    expect(screen.getByAltText('reference')).toHaveAttribute(
      'src',
      '/api/v1/conversions/c1/dashboard/visual-compare/p1/image/reference?t=1700000000',
    )
    expect(screen.getByAltText('rendered')).toHaveAttribute(
      'src',
      '/api/v1/conversions/c1/dashboard/visual-compare/p1/image/rendered?t=1700000000',
    )
  })

  it('shows the stale banner and disables fixes', () => {
    render(
      <ComparisonDetail
        conversionId="c1"
        comparison={{ ...comparison, stale: true, stale_reason: 'reference replaced' }}
        onApplyFixes={vi.fn()}
      />,
    )
    expect(screen.getByTestId('stale-banner')).toHaveTextContent('reference replaced')
    expect(screen.queryByText(/Apply all fixes/)).toBeNull()
    for (const b of screen.getAllByRole('button', { name: /Apply fix/ })) expect(b).toBeDisabled()
  })

  it('shows the reference-suspect banner only when not stale', () => {
    const { rerender } = render(
      <ComparisonDetail conversionId="c1" comparison={{ ...comparison, reference_suspect: true }} />,
    )
    expect(screen.getByTestId('reference-suspect-banner')).toBeInTheDocument()
    rerender(
      <ComparisonDetail
        conversionId="c1"
        comparison={{ ...comparison, reference_suspect: true, stale: true }}
      />,
    )
    expect(screen.queryByTestId('reference-suspect-banner')).toBeNull()
  })

  it('applies one fix or all fixable findings', async () => {
    const user = userEvent.setup()
    const onApply = vi.fn()
    render(<ComparisonDetail conversionId="c1" comparison={comparison} onApplyFixes={onApply} />)
    expect(screen.getByText('Applied')).toBeInTheDocument()
    const rows = screen.getAllByRole('row')
    const enabled = within(rows[1]).getByRole('button', { name: /Apply fix/ })
    await user.click(enabled)
    expect(onApply).toHaveBeenLastCalledWith(['f1'])
    // the non-automatable finding keeps a disabled button with the rejection reason
    expect(within(rows[2]).getByRole('button', { name: /Apply fix/ })).toBeDisabled()
    expect(within(rows[2]).getByRole('button', { name: /Apply fix/ })).toHaveAttribute(
      'title',
      'Proposed fix rejected: unsafe',
    )
    await user.click(screen.getByRole('button', { name: /Apply all fixes/ }))
    expect(onApply).toHaveBeenLastCalledWith(['f1'])
  })

  it('renders the numbers table with status badges and the nearest value', () => {
    render(<ComparisonDetail conversionId="c1" comparison={null} values={values} />)
    const panel = screen.getByTestId('numbers-panel')
    expect(within(panel).getByText('2 of 3 printed numbers matched')).toBeInTheDocument()
    expect(within(panel).getByText('$1.2M')).toBeInTheDocument()
    expect(within(panel).getAllByText('matched')).toHaveLength(2)
    const bad = within(panel).getByText('9,999').closest('tr')!
    expect(within(bad).getByText('no match')).toBeInTheDocument()
    expect(within(bad).getByText('10020')).toBeInTheDocument()
    // number-only page: no images
    expect(screen.queryByAltText('reference')).toBeNull()
  })

  it('readOnly hides the fix controls and uses the imageUrl override', () => {
    render(
      <ComparisonDetail
        conversionId="c1"
        comparison={comparison}
        readOnly
        onApplyFixes={vi.fn()}
        imageUrl={(side) => `/hist/run1/${side}`}
      />,
    )
    expect(screen.getByTestId('readonly-banner')).toBeInTheDocument()
    expect(screen.getByAltText('reference')).toHaveAttribute('src', '/hist/run1/reference')
    expect(screen.getByAltText('rendered')).toHaveAttribute('src', '/hist/run1/rendered')
    expect(screen.queryByRole('button', { name: /Apply/ })).toBeNull()
    expect(screen.queryByRole('columnheader', { name: 'Action' })).toBeNull()
  })

  it('says so when there are no findings', () => {
    render(<ComparisonDetail conversionId="c1" comparison={{ ...comparison, findings: [] }} />)
    expect(screen.getByText('No meaningful differences found.')).toBeInTheDocument()
  })
})
