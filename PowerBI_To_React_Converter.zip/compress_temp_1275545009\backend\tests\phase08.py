"""Shared helpers for the phase 08 API tests: an uploaded Contoso conversion, a fake Snowflake
connection whose answers a test scripts, and the common pane names."""

from __future__ import annotations

import json
from pathlib import Path

from app.api.deps import get_ingest_service
from app.main import app
from tests.test_api import zip_folder

PAGE = "overview01aa2bcc3dd4"
CARD = "card0001aaaabbbbcccc"
BAR = "bar00001aaaabbbbcccc"
LINE = "line0001aaaabbbbcccc"
SLICER = "slicer01aaaabbbbcccc"


class FakeCursor:
    def __init__(self, conn: FakeConn):
        self.conn = conn
        self.description: list = []
        self._rows: list = []
        self.sfqid = None
        self.rowcount = -1

    def execute(self, sql, *args, **kwargs):
        self.conn.executed.append(sql)
        self.conn.counter += 1
        self.sfqid = f"qid-{self.conn.counter}"
        cols, rows = self.conn.responder(sql)
        self.description = [(c,) for c in cols]
        self._rows = rows
        self.rowcount = len(rows)
        return self

    def fetchall(self):
        return self._rows

    def fetchone(self):
        return self._rows[0] if self._rows else None

    def close(self):
        pass


class FakeConn:
    def __init__(self, responder, executed: list | None = None):
        self.responder = responder
        self.executed = executed if executed is not None else []
        self.counter = 0

    def cursor(self):
        return FakeCursor(self)

    def close(self):
        pass


def default_responder(sql: str):
    if "COUNT" in sql.upper() and "DISTINCT" in sql.upper():
        return ["n"], [(1,)]
    return ["Total Sales"], [(10.0,)]


class World:
    """An uploaded conversion + patched connection for one test."""

    def __init__(self, client, contoso_pbip: Path, monkeypatch, responder=default_responder):
        self.client = client
        self.monkeypatch = monkeypatch
        upload = client.post(
            "/api/v1/conversions",
            files={"file": ("contoso.zip", zip_folder(contoso_pbip), "application/zip")},
        )
        assert upload.status_code == 201, upload.text
        self.cid = upload.json()["id"]
        profile = client.post(
            "/api/v1/connections",
            json={
                "name": "demo",
                "account": "acct",
                "user": "user",
                "warehouse": "ANALYTICS_WH",
                "role": "ANALYST",
                "auth_method": "password",
                "password": "pw",
            },
        )
        assert profile.status_code == 201, profile.text
        self.conn_id = profile.json()["id"]
        self.svc = app.dependency_overrides[get_ingest_service]()
        monkeypatch.setattr("app.api.dashboards.get_ingest_service", lambda: self.svc)
        self.executed: list[str] = []
        self.responder = responder
        monkeypatch.setattr(
            "app.api.dashboards._connect",
            lambda *_a, **_k: FakeConn(lambda sql: self.responder(sql), self.executed),
        )

    # -- urls / calls
    def url(self, path: str) -> str:
        return f"/api/v1/conversions/{self.cid}/dashboard/{path}"

    def get(self, path: str, **params):
        return self.client.get(self.url(path), params=params)

    def post(self, path: str, body: dict):
        return self.client.post(self.url(path), json=body)

    def query(self, *visuals: str, filters=None, **extra):
        return self.post(
            "query",
            {
                "connection_id": self.conn_id,
                "queries": [
                    {"page": PAGE, "visual": v, "filters": filters or []} for v in visuals
                ],
                "execution_tier": "tier_b_compatibility",
                **extra,
            },
        )

    # -- model edits
    @property
    def root(self) -> Path:
        return self.svc.conversion_dir(self.cid)

    def edit_bundle(self, fn) -> None:
        bundle = self.svc.load_bundle(self.cid)
        fn(bundle)
        self.svc.save_bundle(self.cid, bundle)

    def park_measure(self, name: str = "Total Sales", dax: str = "RANKX(ALL('Product'), [Total Quantity])"):
        def edit(bundle):
            found = bundle.model.find_measure(name)
            found[1].expression = dax

        self.edit_bundle(edit)

    def write_run(self, visuals: list[dict] | None = None) -> None:
        pages = [{"page": PAGE, "display_name": "Overview", "visuals": visuals or []}]
        fidelity = {"report_name": "Contoso", "pages": pages, "measure_tiers": {}}
        (self.root / "conversion_run.json").write_text(
            json.dumps(
                {
                    "events": [],
                    "fidelity": fidelity,
                    "summary": {"overall_score": 0.5, "visuals_total": 0, "visuals_passed": 0},
                }
            ),
            encoding="utf-8",
        )

    def events(self) -> list[dict]:
        path = self.root / "events.jsonl"
        if not path.is_file():
            return []
        return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]
