/** Matrix drill: a collapsed pivot expands (+/-) rows through the hierarchy drill endpoint. */
import { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react'
import { fetchDrillStep, type DashboardApiConfig, type DrillStepResult } from './api'
import type { FilterClause } from './types'

export interface MatrixDrill {
  isExpanded: (rowKey: string) => boolean
  children: (rowKey: string) => DrillStepResult | undefined
  isLoading: (rowKey: string) => boolean
  error: (rowKey: string) => string | undefined
  /** expand (loading the child rows) or collapse a row; `parentFilters` pin the row's path */
  toggle: (rowKey: string, parentFilters: FilterClause[], levelKey?: string | null) => void
}

export const MatrixDrillContext = createContext<MatrixDrill | null>(null)
export const useMatrixDrill = (): MatrixDrill | null => useContext(MatrixDrillContext)

/** The row key of a path of dimension values. */
export const rowPathKey = (path: (string | number | null)[]): string => JSON.stringify(path)

export function useMatrixDrillState(opts: {
  conversionId: string
  connectionId: string
  page: string
  visual: string
  filters: FilterClause[]
  apiConfig?: DashboardApiConfig
}): MatrixDrill {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({})
  const [results, setResults] = useState<Record<string, DrillStepResult>>({})
  const [loading, setLoading] = useState<Record<string, boolean>>({})
  const [errors, setErrors] = useState<Record<string, string>>({})
  const latest = useRef(opts)
  latest.current = opts

  const toggle = useCallback(
    (rowKey: string, parentFilters: FilterClause[], levelKey?: string | null) => {
      setExpanded((prev) => ({ ...prev, [rowKey]: !prev[rowKey] }))
      setResults((prev) => {
        if (prev[rowKey]) return prev
        const o = latest.current
        setLoading((l) => ({ ...l, [rowKey]: true }))
        fetchDrillStep(
          o.conversionId,
          o.connectionId,
          {
            page: o.page,
            visual: o.visual,
            direction: 'down',
            level_key: levelKey,
            parent_filters: parentFilters,
            filters: o.filters,
          },
          o.apiConfig,
        )
          .then((r) => setResults((cur) => ({ ...cur, [rowKey]: r })))
          .catch((e: Error) => setErrors((cur) => ({ ...cur, [rowKey]: e.message })))
          .finally(() => setLoading((l) => ({ ...l, [rowKey]: false })))
        return prev
      })
    },
    [],
  )

  return useMemo(
    () => ({
      isExpanded: (k) => !!expanded[k],
      children: (k) => results[k],
      isLoading: (k) => !!loading[k],
      error: (k) => errors[k],
      toggle,
    }),
    [expanded, results, loading, errors, toggle],
  )
}
