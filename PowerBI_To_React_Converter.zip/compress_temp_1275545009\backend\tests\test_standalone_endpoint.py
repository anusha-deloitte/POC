"""Phase 12: POST /dashboard/export-standalone on the converter."""

from __future__ import annotations

import io
import json
import zipfile

import pytest

from app.services import standalone_export as se
from tests.phase08 import World
from tests.test_api import client  # noqa: F401


@pytest.fixture()
def world(client, contoso_pbip, monkeypatch, tmp_path):  # noqa: F811
    build = tmp_path / "dist-standalone"
    build.mkdir()
    (build / "standalone.html").write_text("<html></html>", encoding="utf-8")
    monkeypatch.setattr(se, "vendor_distributions", lambda *a, **k: [])
    monkeypatch.setenv("PBIC_STANDALONE_BUILD", str(build))
    w = World(client, contoso_pbip, monkeypatch)
    w.build = build
    return w


def test_downloads_the_package(world):
    r = world.client.post(world.url("export-standalone"), json={"connection_id": world.conn_id})
    assert r.status_code == 200, r.text
    assert r.headers["content-type"] == "application/zip"
    assert r.headers["content-disposition"].endswith('-standalone.zip"')
    with zipfile.ZipFile(io.BytesIO(r.content)) as z:
        names = z.namelist()
        assert any(n.endswith("/data/spec.json") for n in names)
        assert any(n.endswith("/service/main.py") for n in names)
        conn = json.loads(z.read(next(n for n in names if n.endswith("/data/connection.json"))))
    assert conn["warehouse"] == "ANALYTICS_WH" and conn["auth_method"] == "password"
    assert "pw" not in json.dumps(conn) and "password" not in conn


def test_unknown_connection_is_404(world):
    r = world.client.post(world.url("export-standalone"), json={"connection_id": "nope"})
    assert r.status_code == 404


def test_unbuilt_front_end_is_503(world, monkeypatch):
    monkeypatch.setenv("PBIC_STANDALONE_BUILD", str(world.build / "absent"))
    r = world.client.post(world.url("export-standalone"), json={"connection_id": world.conn_id})
    assert r.status_code == 503 and "npm run build:standalone" in r.text
