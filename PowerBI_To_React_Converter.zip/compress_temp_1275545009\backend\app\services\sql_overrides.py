"""Hand-edited pane SQL: validation, `{{filters}}` rendering and persistence.

An edit replaces the generated MAIN query of one pane. Placeholders `{{filters}}` and
`{{filters:<Model Table>}}` are replaced with the request's slicer/cross-filter predicates, spelled
exactly like the generated SQL; edited SQL is never rewritten otherwise.
"""

from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Any

FILENAME = "sql_overrides.json"
_PLACEHOLDER = re.compile(r"\{\{\s*([^{}]*?)\s*\}\}")


class SqlOverrideError(ValueError):
    pass


# ------------------------------------------------------------------ lexical helpers


def mask_sql(sql: str, keep_identifiers: bool = False) -> str:
    """`sql` with comments and the contents of string literals / quoted identifiers blanked
    (same length), so structure checks never see their text. `keep_identifiers` leaves
    "quoted identifiers" readable."""
    out: list[str] = []
    i, n = 0, len(sql)
    while i < n:
        c = sql[i]
        if c == "-" and sql.startswith("--", i):
            j = sql.find("\n", i)
            j = n if j < 0 else j
            out.append(" " * (j - i))
            i = j
        elif c == "/" and sql.startswith("/*", i):
            j = sql.find("*/", i + 2)
            j = n if j < 0 else j + 2
            out.append(" " * (j - i))
            i = j
        elif c == '"' and keep_identifiers:
            j = sql.find('"', i + 1)
            j = n if j < 0 else j + 1
            out.append(sql[i:j])
            i = j
        elif c in "'\"":
            j = i + 1
            while j < n:
                if sql[j] == c:
                    if j + 1 < n and sql[j + 1] == c:
                        j += 2
                        continue
                    break
                j += 1
            end = min(j + 1, n)
            out.append(c + " " * max(end - i - 2, 0) + (c if end - i >= 2 else ""))
            i = end
        else:
            out.append(c)
            i += 1
    return "".join(out)


def _clean(sql: str) -> str:
    text = (sql or "").strip()
    while text.endswith(";"):
        text = text[:-1].rstrip()
    return text


def validate_sql(sql: str) -> str:
    """Return the trimmed SQL (trailing `;` removed) or raise SqlOverrideError."""
    text = _clean(sql)
    if not text:
        raise SqlOverrideError("SQL is empty")
    masked = mask_sql(text)
    body = masked.strip()
    if not re.match(r"(?is)(select|with)\b", body):
        raise SqlOverrideError("only a SELECT or WITH query can replace a pane's SQL")
    if ";" in masked:
        raise SqlOverrideError("only one SQL statement is allowed")
    for m in _PLACEHOLDER.finditer(text):
        # placeholders inside strings/comments are plain text
        if masked[m.start()] != "{":
            continue
        body = m.group(1)
        if body == "filters":
            continue
        if body.startswith("filters:"):
            if not body[len("filters:") :].strip():
                raise SqlOverrideError("{{filters:<table>}} needs a model table name")
            continue
        raise SqlOverrideError(f"unknown placeholder {{{{{body}}}}}")
    return text


def _placeholders(text: str) -> list[re.Match]:
    masked = mask_sql(text)
    return [m for m in _PLACEHOLDER.finditer(text) if masked[m.start()] == "{"]


def has_filters_placeholder(sql: str) -> bool:
    return bool(_placeholders(sql))


# ------------------------------------------------------------------ rendering


def render(sql: str, filters: list, engine: Any) -> tuple[str, list[str]]:
    """Replace the placeholders; returns (sql, tables whose filters could not be applied)."""
    text = _clean(sql)
    masked = mask_sql(text, keep_identifiers=True)
    placeholders = _placeholders(text)
    # aliases are looked up outside the placeholders
    chars = list(masked)
    for m in placeholders:
        for k in range(m.start(), m.end()):
            chars[k] = " "
    visible = "".join(chars).lower()

    predicates: list[tuple[str, str, str]] = []  # (table, quoted alias, predicate)
    for f in filters:
        alias, predicate = engine.filter_predicate(f)
        predicates.append((f.table, alias, predicate))

    applied_all = [p for p in predicates if p[1].lower() in visible]
    used: set[int] = set()

    def replacement(m: re.Match) -> str:
        body = m.group(1)
        if body == "filters":
            chosen = applied_all
        else:
            table = body[len("filters:") :].strip().lower()
            chosen = [p for p in applied_all if p[0].lower() == table]
        used.update(id(p) for p in chosen)
        return " AND ".join(p[2] for p in chosen) if chosen else "1=1"

    out: list[str] = []
    pos = 0
    for m in placeholders:
        out.append(text[pos : m.start()])
        out.append(replacement(m))
        pos = m.end()
    out.append(text[pos:])
    unapplied = sorted({p[0] for p in predicates if id(p) not in used})
    return "".join(out), unapplied


# ------------------------------------------------------------------ NULL comparison traps

_NULL_PATTERNS: list[tuple[re.Pattern, str]] = [
    (
        re.compile(r"(?is)\bnot\s+in\s*\(\s*null\s*\)"),
        "`NOT IN (NULL)` is never true: use `IS NOT NULL`",
    ),
    (
        re.compile(r"(?is)\bnot\s+in\s*\(\s*null\s*,"),
        "`NOT IN (NULL, ...)` is never true when the list contains NULL: drop the NULL and add "
        "`AND col IS NOT NULL`",
    ),
    (
        re.compile(r"(?is)(?<!\bnot)\s+in\s*\(\s*null\s*,"),
        "`IN (NULL, ...)` never matches NULL rows: use `col IS NULL OR col IN (...)`",
    ),
    (
        re.compile(r"(?is)(<>|!=)\s*null\b"),
        "`col <> NULL` is never true: use `col IS NOT NULL`",
    ),
    (
        re.compile(r"(?is)(?<![<>!])=\s*null\b"),
        "`col = NULL` is never true: use `col IS NULL`",
    ),
]


def null_comparison_warnings(sql: str) -> list[str]:
    masked = mask_sql(sql or "")
    found: list[str] = []
    for pattern, message in _NULL_PATTERNS:
        if pattern.search(masked) and message not in found:
            found.append(message)
    return found


# ------------------------------------------------------------------ persistence


def _path(root: Path) -> Path:
    return Path(root) / FILENAME


def overrides_mtime(root: Path) -> float:
    p = _path(root)
    return p.stat().st_mtime if p.is_file() else 0.0


def key_for(page: str, visual: str) -> str:
    return f"{page}/{visual}"


def load_overrides(root: Path) -> dict[str, dict]:
    p = _path(root)
    if not p.is_file():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _write(root: Path, data: dict[str, dict]) -> None:
    p = _path(root)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    os.replace(tmp, p)


def save_override(
    root: Path, page: str, visual: str, sql: str, base_sql: str | None, saved_by: str | None = None
) -> dict:
    text = validate_sql(sql)
    data = load_overrides(root)
    record = {
        "page": page,
        "visual": visual,
        "sql": text,
        "base_sql": base_sql,
        "saved_at": time.time(),
        "saved_by": saved_by,
    }
    data[key_for(page, visual)] = record
    _write(root, data)
    return record


def delete_override(root: Path, page: str, visual: str) -> bool:
    data = load_overrides(root)
    if data.pop(key_for(page, visual), None) is None:
        return False
    _write(root, data)
    return True
