"""Performance-Analyzer-style DAX query of a visual (what Power BI would run for its data).

Used for panes that could not be translated to SQL, so a reviewer can see exactly what the visual
asks for. Slicer selections are not part of it.
"""

from __future__ import annotations

from app.runtime.engine import FilterClause, MeasureFilter, MeasureRefSpec, QuerySpec

_AGGREGATES = {
    "sum": "SUM",
    "avg": "AVERAGE",
    "average": "AVERAGE",
    "min": "MIN",
    "max": "MAX",
    "distinctcount": "DISTINCTCOUNT",
    "count": "COUNTA",
    "countnonnull": "COUNTA",
}
_OPS = {"eq": "=", "neq": "<>", "gt": ">", "gte": ">=", "lt": "<", "lte": "<="}


def dax_table(name: str) -> str:
    return "'" + name.replace("'", "''") + "'"


def dax_column(table: str, column: str) -> str:
    return f"{dax_table(table)}[{column.replace(']', ']]')}]"


def dax_measure(name: str) -> str:
    return f"[{name.replace(']', ']]')}]"


def dax_string(value: str) -> str:
    return '"' + value.replace('"', '""') + '"'


def dax_literal(value) -> str:
    if value is None:
        return "BLANK()"
    if isinstance(value, bool):
        return "TRUE()" if value else "FALSE()"
    if isinstance(value, (int, float)):
        return repr(value)
    return dax_string(str(value))


def _filter_expr(f: FilterClause) -> str:
    col = dax_column(f.table, f.column)
    if f.op == "topn":
        p = f.params
        by = dax_measure(p["measure"]) if p.get("measure") else (
            f"{_AGGREGATES.get(str(p.get('aggregate') or 'sum').lower(), 'SUM')}"
            f"({dax_column(p.get('table', ''), p.get('column', ''))})"
        )
        order = "DESC" if p.get("direction", "top") == "top" else "ASC"
        return f"TOPN({p.get('n')}, ALL({col}), {by}, {order})"
    if f.op == "relative":
        return f"ALL({col}) /* relative date filter */"
    if f.op == "or":
        parts = " || ".join(_condition(c) for c in f.clauses)
        return f"FILTER(ALL({col}), {parts})"
    if f.op == "in":
        return f"TREATAS({{{', '.join(dax_literal(v) for v in f.values)}}}, {col})"
    return f"FILTER(ALL({col}), {_condition(f)})"


def _condition(f: FilterClause) -> str:
    col = dax_column(f.table, f.column)
    first = dax_literal(f.values[0]) if f.values else "BLANK()"
    if f.op == "contains":
        return f"CONTAINSSTRING({col}, {first})"
    if f.op == "not_contains":
        return f"NOT(CONTAINSSTRING({col}, {first}))"
    if f.op == "starts_with":
        return f"LEFT({col}, LEN({first})) = {first}"
    if f.op == "not_starts_with":
        return f"NOT(LEFT({col}, LEN({first})) = {first})"
    if f.op == "is_blank":
        return f"ISBLANK({col})"
    if f.op == "is_not_blank":
        return f"NOT(ISBLANK({col}))"
    if f.op == "is_empty":
        return f'{col} = ""'
    if f.op == "is_not_empty":
        return f'{col} <> ""'
    if f.op == "in":
        return f"{col} IN {{{', '.join(dax_literal(v) for v in f.values)}}}"
    if f.op == "not_in":
        return f"NOT({col} IN {{{', '.join(dax_literal(v) for v in f.values)}}})"
    if f.op == "or":
        return "(" + " || ".join(_condition(c) for c in f.clauses) + ")"
    sign = _OPS.get(f.op, "=")
    value = f.values[0] if f.values else None
    return f"{col} {sign} {dax_literal(value)}"


def _measure_value(m: MeasureRefSpec) -> str:
    if m.name:
        return dax_measure(m.name)
    agg = _AGGREGATES.get((m.aggregate or "sum").lower(), "SUM")
    return f"{agg}({dax_column(m.table or '', m.column or '')})"


def _measure_filter(mf: MeasureFilter, alias: str) -> str:
    target = dax_measure(alias)
    if mf.op in ("in", "not_in"):
        body = f"{target} IN {{{', '.join(dax_literal(v) for v in mf.values)}}}"
        return body if mf.op == "in" else f"NOT({body})"
    sign = _OPS.get(mf.op, "=")
    return f"{target} {sign} {dax_literal(mf.values[0] if mf.values else None)}"


def visual_dax_query(query: QuerySpec, title: str | None = None) -> str:
    lines: list[str] = []
    if title:
        lines.append("// " + " ".join(title.split()))
    filter_vars: list[str] = []
    defines: list[str] = []
    for i, f in enumerate(query.filters):
        name = f"__DS0FilterTable{'' if i == 0 else i + 1}"
        defines.append(f"    VAR {name} = {_filter_expr(f)}")
        filter_vars.append(name)
    if defines:
        lines.append("DEFINE")
        lines.extend(defines)

    columns = [dax_column(d.table, d.column) for d in query.dimensions]
    pairs: list[str] = []
    names: dict[str, str] = {}
    for m in query.measures:
        label = m.alias or m.name or f"{(m.aggregate or 'sum').capitalize()} of {m.column}"
        names[m.key] = label
        pairs.append(f"{dax_string(label)}, {_measure_value(m)}")
    hidden: list[tuple[MeasureFilter, str]] = []
    for i, mf in enumerate(query.measure_filters):
        label = f"__mf{i}"
        pairs.append(f"{dax_string(label)}, {dax_measure(mf.measure)}")
        hidden.append((mf, label))
    body = ", ".join([*columns, *filter_vars, *pairs])
    summarize = f"SUMMARIZECOLUMNS({body})"
    if hidden:
        cond = " && ".join(_measure_filter(mf, label) for mf, label in hidden)
        summarize = f"FILTER({summarize}, {cond})"
    lines.append("EVALUATE")
    lines.append(f"    {summarize}")

    order: list[str] = []
    dims = {f"{d.table}.{d.column}": dax_column(d.table, d.column) for d in query.dimensions}
    for s in query.sort:
        key = str(s.get("key", ""))
        ref = dims.get(key) or (dax_measure(names[key]) if key in names else None)
        if ref is None:
            continue
        direction = "DESC" if str(s.get("direction", "")).lower().startswith("desc") else "ASC"
        order.append(f"{ref} {direction}")
    if order:
        lines.append("ORDER BY")
        lines.append("    " + ", ".join(order))
    return "\n".join(lines)
