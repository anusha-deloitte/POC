"""Label fingerprints of report pages, built from the stored bundle without compiling the report.

A page's words come from its display name, its visible visuals' titles, text-box text and
formatting labels, and the field names it shows. They are matched against the labels printed on
a PDF export page (`pdf_matching`). Tooltip pages are never exported to PDF and are skipped;
hidden pages are included (button-navigated reports keep most pages hidden).
"""

from __future__ import annotations

import re
import threading
from dataclasses import dataclass, field
from typing import Any

from app.ir.report import ReportBundle
from app.services.pdf_text import label_tokens

_TEXT_KEYS = frozenset({"text", "titleText", "headerText", "label", "subtitleText"})
_MAX_DEPTH = 30
_ZERO_WIDTH = re.compile("[​‌‍⁠﻿]")


@dataclass
class PageFingerprint:
    page: str
    display_name: str
    ordinal: int
    width: float
    height: float
    words: list[str] = field(default_factory=list)
    title_tokens: list[str] = field(default_factory=list)

    @property
    def aspect(self) -> float:
        return self.width / self.height if self.height else 1.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "page": self.page, "display_name": self.display_name, "ordinal": self.ordinal,
            "width": self.width, "height": self.height,
        }  # fmt: skip


@dataclass
class ReportFingerprint:
    conversion_id: str
    report: str
    job_name: str | None
    uploaded_at: float
    converted_at: float | None
    pages: list[PageFingerprint] = field(default_factory=list)


def _literal(node: Any) -> str | None:
    """The string of a Power BI literal `{"expr": {"Literal": {"Value": "'text'"}}}`."""
    if not isinstance(node, dict):
        return None
    value = None
    expr = node.get("expr")
    if isinstance(expr, dict) and isinstance(expr.get("Literal"), dict):
        value = expr["Literal"].get("Value")
    elif isinstance(node.get("Literal"), dict):
        value = node["Literal"].get("Value")
    if isinstance(value, str) and len(value) >= 2 and value[0] == value[-1] == "'":
        return value[1:-1].replace("''", "'")
    return None


def _collect(node: Any, out: list[str], depth: int = 0) -> None:
    if depth > _MAX_DEPTH:
        return
    if isinstance(node, dict):
        runs = node.get("textRuns")
        if isinstance(runs, list):
            out.extend(str(r["value"]) for r in runs if isinstance(r, dict) and r.get("value"))
        for key, value in node.items():
            if key in _TEXT_KEYS:
                text = _literal(value)
                if text:
                    out.append(text)
                    continue
                if isinstance(value, str):
                    out.append(value)
                    continue
            _collect(value, out, depth + 1)
    elif isinstance(node, list):
        for item in node:
            _collect(item, out, depth + 1)


def _clean(text: str) -> str:
    return re.sub(r"\s+", " ", _ZERO_WIDTH.sub("", text)).strip()


def fingerprint_page(page: Any) -> PageFingerprint:
    display = _clean(page.display_name or page.name)
    texts: list[str] = [display]
    title_texts: list[str] = [display]
    for v in page.visuals:
        if v.is_hidden:
            continue
        if v.title:
            texts.append(v.title)
        found: list[str] = []
        _collect(v.formatting, found)
        _collect(v.container_objects, found)
        texts.extend(found)
        if v.visual_type == "textbox":
            title_texts.extend(found)
        texts.extend(f.display_name or f.name or "" for f in v.fields)
    words = label_tokens(" ".join(_clean(t) for t in texts if t))
    title_tokens = sorted(set(label_tokens(" ".join(_clean(t) for t in title_texts if t))))
    return PageFingerprint(
        page=page.name, display_name=display, ordinal=page.ordinal, width=page.width,
        height=page.height, words=words, title_tokens=title_tokens,
    )  # fmt: skip


def fingerprint_bundle(bundle: ReportBundle) -> list[PageFingerprint]:
    """Every non-tooltip page (hidden ones included), in ordinal order."""
    try:  # bundles stored before page types existed: re-read them from the stored source
        from app.runtime.pbir_passthrough import filters_passthrough

        filters_passthrough(bundle)
    except Exception:  # noqa: BLE001, S110 - best effort; without it tooltip pages can't be excluded
        pass
    pages = [p for p in bundle.report.pages if p.page_type != "Tooltip"]
    return [fingerprint_page(p) for p in sorted(pages, key=lambda p: p.ordinal)]


# ------------------------------------------------------------------ stored conversions

_cache: dict[str, tuple[float, ReportFingerprint]] = {}
_lock = threading.Lock()


def stored_fingerprints(svc: Any) -> list[ReportFingerprint]:
    """A fingerprint per stored conversion, cached on the bundle file's modification time."""

    out: list[ReportFingerprint] = []
    for job in svc.list_jobs():
        cid = job["id"]
        try:
            bundle_file = svc.conversion_dir(cid) / "bundle.json"
            mtime = bundle_file.stat().st_mtime
            with _lock:
                hit = _cache.get(cid)
            if hit and hit[0] == mtime:
                fp = hit[1]
            else:
                bundle = svc.load_bundle(cid)
                fp = ReportFingerprint(
                    conversion_id=cid,
                    report=bundle.report.name,
                    job_name=job.get("name"),
                    uploaded_at=job.get("uploaded_at") or mtime,
                    converted_at=job.get("converted_at"),
                    pages=fingerprint_bundle(bundle),
                )
                with _lock:
                    _cache[cid] = (mtime, fp)
            # names and run times change without touching the bundle
            fp.job_name = job.get("name")
            fp.converted_at = job.get("converted_at")
            out.append(fp)
        except Exception:  # noqa: BLE001, S112
            continue  # unreadable conversions are skipped
    return out
