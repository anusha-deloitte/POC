import { readErrorDetail } from '../api/client'
import { reportClientError } from '../api/errorReporting'
import type { DashboardRecommendation, DashboardSpec, FilterClause, VisualResult } from './types'

const BASE = '/api/v1'

export interface DashboardApiConfig {
  baseUrl?: string
  token?: string
  published?: boolean
}

export class DashboardApiError extends Error {
  constructor(
    message: string,
    readonly code?: string,
  ) {
    super(message)
  }
}

function apiUrl(config: DashboardApiConfig | undefined, conversionId: string, path: string) {
  const base = config?.baseUrl ?? BASE
  return config?.published
    ? `${base}/dashboard/${path}`
    : `${base}/conversions/${conversionId}/dashboard/${path}`
}

function apiHeaders(config?: DashboardApiConfig, json = false): HeadersInit {
  return {
    ...(json ? { 'Content-Type': 'application/json' } : {}),
    ...(config?.token ? { Authorization: `Bearer ${config.token}` } : {}),
  }
}

async function throwDashboardError(response: Response): Promise<never> {
  const contentType = response.headers.get('content-type') ?? ''
  if (contentType.includes('application/json')) {
    const body = await response.json()
    if (body?.detail && typeof body.detail === 'object') {
      const message = body.detail.message ?? 'Dashboard request failed'
      reportClientError({ message, path: response.url, status: response.status, context: 'dashboard' })
      throw new DashboardApiError(message, body.detail.code)
    }
  }
  const message = await readErrorDetail(response)
  reportClientError({ message, path: response.url, status: response.status, context: 'dashboard' })
  throw new DashboardApiError(message)
}

export async function fetchDashboardSpec(
  conversionId: string,
  variant?: 'reimagined',
  config?: DashboardApiConfig,
): Promise<DashboardSpec> {
  const qs = variant ? `?variant=${variant}` : ''
  const res = await fetch(apiUrl(config, conversionId, `spec${qs}`), {
    headers: apiHeaders(config),
  })
  if (!res.ok) await throwDashboardError(res)
  return res.json()
}

export async function fetchVisualData(
  conversionId: string,
  connectionId: string,
  page: string,
  visuals: string[],
  filtersByVisual: Record<string, FilterClause[]>,
  mode: 'live' | 'accelerated' = 'live',
  variant?: 'reimagined',
  config?: DashboardApiConfig,
): Promise<Record<string, VisualResult>> {
  const qs = variant ? `?variant=${variant}` : ''
  const res = await fetch(apiUrl(config, conversionId, `query${qs}`), {
    method: 'POST',
    headers: apiHeaders(config, true),
    body: JSON.stringify({
      ...(config?.published ? {} : { connection_id: connectionId }),
      mode,
      queries: visuals.map((v) => ({
        page,
        visual: v,
        // a measure-driven title is queried under its visual's own filters
        filters: filtersByVisual[v] ?? filtersByVisual[v.replace(/#title$/, '')] ?? [],
      })),
    }),
  })
  if (!res.ok) await throwDashboardError(res)
  const body = await res.json()
  const out: Record<string, VisualResult> = {}
  for (const r of body.results as VisualResult[]) out[r.visual] = r
  return out
}

export interface DrillStepResult {
  page: string
  visual: string
  level_key: string
  level_index: number
  total_levels: number
  columns: string[]
  rows: (string | number | null)[][]
  sql: string
  warnings: string[]
}

/** One hierarchy drill step (`POST /dashboard/query/drill`, logged as kind `drill`). */
export async function fetchDrillStep(
  conversionId: string,
  connectionId: string,
  body: {
    page: string
    visual: string
    direction: 'down' | 'up'
    level_key?: string | null
    parent_filters?: FilterClause[]
    filters?: FilterClause[]
  },
  config?: DashboardApiConfig,
): Promise<DrillStepResult> {
  const res = await fetch(apiUrl(config, conversionId, 'query/drill'), {
    method: 'POST',
    headers: apiHeaders(config, true),
    body: JSON.stringify({
      ...(config?.published ? {} : { connection_id: connectionId }),
      parent_filters: [],
      filters: [],
      ...body,
    }),
  })
  if (!res.ok) await throwDashboardError(res)
  return res.json()
}

/** URL of a registered report image: the converter API in the studio, `resources/<name>` (bundled
 * into the exported project) for published dashboards. */
export function resourceUrl(conversionId: string, name: string, config?: DashboardApiConfig): string {
  if (config?.published) return `${(import.meta as { env?: { BASE_URL?: string } }).env?.BASE_URL ?? '/'}resources/${encodeURIComponent(name)}`
  return `${config?.baseUrl ?? BASE}/conversions/${conversionId}/dashboard/resources/${encodeURIComponent(name)}`
}

/** Distinct values of a column for a Filters-pane card (`POST /dashboard/filter-values`). */
export async function fetchFilterValues(
  conversionId: string,
  connectionId: string,
  body: { page?: string | null; table: string; column: string; search?: string; limit?: number },
  config?: DashboardApiConfig,
): Promise<{ values: (string | number | boolean | null)[]; truncated: boolean }> {
  const res = await fetch(apiUrl(config, conversionId, 'filter-values'), {
    method: 'POST',
    headers: apiHeaders(config, true),
    body: JSON.stringify({
      ...(config?.published ? {} : { connection_id: connectionId }),
      limit: 500,
      ...body,
    }),
  })
  if (!res.ok) await throwDashboardError(res)
  return res.json()
}

export interface MappingEntry {
  original: {
    page: string
    visual: string
    type: string
    title: string | null
    dims: string[]
    measures: string[]
    slicer_target: { table: string; column: string } | null
    region: string
  }
  reimagined: {
    visual: string
    type: string
    title: string | null
    dims: string[]
    measures: string[]
    region: string
  }
  change_kind: 'restyle' | 're-encode' | 'relocate' | 'dedupe'
  rationale: string
  information_delta: { missing: string[]; relocated: string[]; added: string[] }
}

export interface ZeroLoss {
  passed: boolean
  coverage: Record<string, string>
  gaps: string[]
}

export interface PageArchitecture {
  profiles: {
    name: string
    display_name: string
    data_visuals: number
    measures: string[]
    dims: string[]
    exclusive_dims: string[]
  }[]
  conformed_dims: string[]
  pairs: {
    pages: string[]
    measure_jaccard: number
    shared_measures: string[]
    exclusive_dim_jaccard: number
    combined_data_visuals: number
    verdict: string
    reason: string
  }[]
  merges: { into: string; absorbed: string; reason: string }[]
  splits: { page: string; reason: string }[]
  pages_before: number
  pages_after: number
  verdict: string
}

export interface ReimagineBuilt {
  spec: DashboardSpec
  mapping: {
    conversion_id: string
    pages: string[]
    entries: MappingEntry[]
    page_map?: Record<string, string>
    architecture?: PageArchitecture
  }
  zero_loss: ZeroLoss
}

export async function buildReimagineVariant(
  conversionId: string,
  recommendationId = 'latest',
): Promise<{ built: boolean; zero_loss: ZeroLoss; mappings: number }> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/build`,
    { method: 'POST' },
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function fetchReimagineBuilt(
  conversionId: string,
  recommendationId = 'latest',
): Promise<ReimagineBuilt> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/built`,
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function acceptReimagineVariant(
  conversionId: string,
  recommendationId = 'latest',
  note = '',
): Promise<{ accepted: boolean }> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/accept`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note }),
    },
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function hydrateExtract(
  conversionId: string,
  connectionId: string,
  config?: DashboardApiConfig,
): Promise<{ total_rows: number; elapsed_s: number }> {
  const res = await fetch(apiUrl(config, conversionId, 'accelerate'), {
    method: 'POST',
    headers: apiHeaders(config, true),
    body: JSON.stringify(config?.published ? {} : { connection_id: connectionId }),
  })
  if (!res.ok) await throwDashboardError(res)
  return res.json()
}

export async function accelerationStatus(
  conversionId: string,
  config?: DashboardApiConfig,
): Promise<{ hydrated: boolean; available?: boolean }> {
  const res = await fetch(apiUrl(config, conversionId, 'accelerate'), {
    headers: apiHeaders(config),
  })
  if (!res.ok) return { hydrated: false }
  return res.json()
}

export async function authenticatePublishedSession(config: DashboardApiConfig) {
  const res = await fetch(`${config.baseUrl ?? BASE}/session/authenticate`, {
    method: 'POST',
    headers: apiHeaders(config),
  })
  if (!res.ok) await throwDashboardError(res)
  return res.json() as Promise<{ ok: boolean; error?: string }>
}

export async function generateReimagineRecommendation(
  conversionId: string,
  connectionId: string,
  mode: 'live' | 'accelerated' = 'live',
  useLlm = false,
): Promise<DashboardRecommendation> {
  const res = await fetch(`${BASE}/conversions/${conversionId}/dashboard/reimagine`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ connection_id: connectionId, mode, use_llm: useLlm }),
  })
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function fetchReimagineLatest(
  conversionId: string,
): Promise<DashboardRecommendation | null> {
  const res = await fetch(`${BASE}/conversions/${conversionId}/dashboard/reimagine/latest`)
  if (res.status === 404) return null
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function fetchReimagineHistory(
  conversionId: string,
): Promise<{ recommendations: { id: string; created_at: number; status: string; summary: string; page_count: number }[] }> {
  const res = await fetch(`${BASE}/conversions/${conversionId}/dashboard/reimagine/history`)
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function fetchReimagineMockups(
  conversionId: string,
  recommendationId: string,
): Promise<{
  id: string
  snapshot: DashboardRecommendation['snapshot']
  quality: DashboardRecommendation['quality']
  scenes: DashboardRecommendation['mockup_scenes']
  pages: DashboardRecommendation['pages']
  visual_decisions: DashboardRecommendation['visual_decisions']
}> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/mockups`,
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function approveReimagineRecommendation(
  conversionId: string,
  recommendationId: string,
  note = '',
): Promise<DashboardRecommendation> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/approve`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note }),
    },
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}

export async function rejectReimagineRecommendation(
  conversionId: string,
  recommendationId: string,
  note = '',
): Promise<DashboardRecommendation> {
  const res = await fetch(
    `${BASE}/conversions/${conversionId}/dashboard/reimagine/${recommendationId}/reject`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ note }),
    },
  )
  if (!res.ok) throw new Error(await readErrorDetail(res))
  return res.json()
}
