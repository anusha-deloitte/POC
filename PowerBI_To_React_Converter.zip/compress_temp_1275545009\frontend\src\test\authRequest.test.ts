import { afterEach, describe, expect, it, vi } from 'vitest'
import { API_UNREACHABLE, login, signup } from '../auth'

afterEach(() => vi.restoreAllMocks())

describe('auth requests', () => {
  it('reports an unreachable API on network failure', async () => {
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('failed')))
    await expect(login('a@b.c', 'x')).rejects.toThrow(API_UNREACHABLE)
  })

  it('reports an unreachable API on an empty 5xx body', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 500 })))
    await expect(signup('a@b.c', 'x', 'n')).rejects.toThrow(API_UNREACHABLE)
  })

  it('shows the API detail when present', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(JSON.stringify({ detail: 'bad credentials' }), { status: 401 })),
    )
    await expect(login('a@b.c', 'x')).rejects.toThrow('bad credentials')
  })

  it('treats a 2xx without token/user as unreachable', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('{}', { status: 200 })))
    await expect(login('a@b.c', 'x')).rejects.toThrow(API_UNREACHABLE)
  })

  it('stores the session on success', async () => {
    const user = { id: '1', email: 'a@b.c', name: 'n', is_admin: false }
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(JSON.stringify({ token: 't', user }), { status: 200 })),
    )
    await expect(login('a@b.c', 'x')).resolves.toEqual(user)
    expect(localStorage.getItem('pbic.token')).toBe('t')
  })
})
