import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { api } from '../api/client'
import { ModeToggle } from '../dashboard/ModeToggle'
import { PreviewStep } from '../steps/PreviewStep'
import { useWizard } from '../store/wizard'
import { json } from './standaloneFixtures'

vi.mock('../dashboard/DashboardApp', () => ({ DashboardApp: () => <div data-testid="dash" /> }))

const renderToggle = (config?: { baseUrl: string; token: string; published: boolean }) =>
  render(
    <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
      <ModeToggle conversionId="c1" connectionId="conn" mode="live" onChange={() => undefined} apiConfig={config} />
    </QueryClientProvider>,
  )

afterEach(() => vi.restoreAllMocks())

describe('mode toggle', () => {
  it('is hidden when the service has no extract', async () => {
    const fetchMock = vi.fn(async () => json({ hydrated: false, available: false }))
    vi.stubGlobal('fetch', fetchMock)
    renderToggle({ baseUrl: '/api/v1/published', token: 't', published: true })
    await waitFor(() => expect(fetchMock).toHaveBeenCalled())
    await waitFor(() => expect(screen.queryByRole('button', { name: 'Live' })).toBeNull())
  })

  it('is kept in the converter', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => json({ hydrated: false })))
    renderToggle()
    expect(await screen.findByRole('button', { name: 'Live' })).toBeTruthy()
    expect(screen.getByRole('button', { name: 'Enable Accelerated' })).toBeTruthy()
  })
})

describe('standalone download', () => {
  beforeEach(() => {
    vi.stubGlobal('URL', Object.assign(URL, { createObjectURL: vi.fn(() => 'blob:x'), revokeObjectURL: vi.fn() }))
  })

  it('api.exportDashboard uses its own endpoint and returns the file name', async () => {
    const fetchMock = vi.fn(
      async (_url: string, _init?: RequestInit) => new Response('zip', { headers: { 'content-disposition': 'attachment; filename="sales-standalone.zip"' } }),
    )
    vi.stubGlobal('fetch', fetchMock)
    const out = await api.exportDashboard('c1', 'conn', 'standalone')
    expect(out.filename).toBe('sales-standalone.zip')
    expect(out.blob.size).toBe(3)
    expect(fetchMock).toHaveBeenCalledWith(
      '/api/v1/conversions/c1/dashboard/export-standalone',
      expect.objectContaining({ method: 'POST', body: JSON.stringify({ connection_id: 'conn' }) }),
    )
    await api.exportDashboard('c1', 'conn')
    expect(fetchMock.mock.calls[1][0]).toBe('/api/v1/conversions/c1/dashboard/export')
  })

  it('the Preview step button downloads the standalone package', async () => {
    useWizard.setState({ conversionId: 'c1', connectionId: 'conn' })
    const urls: string[] = []
    vi.stubGlobal(
      'fetch',
      vi.fn(async (url: string) => {
        urls.push(String(url))
        if (url.endsWith('/dashboard/spec')) return json({ report_name: 'Sales', pages: [] })
        if (url.endsWith('/dashboard-publications')) return json([])
        return new Response('zip', { headers: { 'content-disposition': 'attachment; filename="sales-standalone.zip"' } })
      }),
    )
    const click = vi.spyOn(HTMLAnchorElement.prototype, 'click').mockImplementation(() => undefined)
    render(
      <QueryClientProvider client={new QueryClient({ defaultOptions: { queries: { retry: false } } })}>
        <PreviewStep />
      </QueryClientProvider>,
    )
    await userEvent.click(await screen.findByRole('button', { name: 'Download standalone dashboard ⬇' }))
    await waitFor(() => expect(click).toHaveBeenCalled())
    expect(urls).toContain('/api/v1/conversions/c1/dashboard/export-standalone')
    expect(urls).not.toContain('/api/v1/conversions/c1/dashboard/export')
  })
})
