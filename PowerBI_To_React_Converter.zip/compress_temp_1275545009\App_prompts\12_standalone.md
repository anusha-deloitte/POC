# Phase 12 - Standalone dashboard package ("Download standalone dashboard")

## Purpose
A zip the user runs on their own Windows machine without the converter: the pre-built React app, a small local FastAPI query service,
the compiled spec, and one SQL template per data query. The service fills the templates with the request's filters and runs them on
Snowflake with the user's own sign-in (five methods). Live data; logic fixed at export time. Requires phases 05-11.

## 1. Engine templates (`runtime/engine.py::build_template(spec, slots) -> (sql, meta, warnings)`)
- `slots`: `(table, column)` pairs; each becomes `FilterClause(op="slot")` placed wherever a real filter on that column would go. Template
  mode is a flag (`engine._tpl`, a `_TemplateMeta` collector) that never affects live queries.
- Markers (rendered by `sql_render.render_template`, phase 10 file):
  `{{p:N}}` predicate occurrence N, `meta.preds[N] = {slot, col}` -> the AND of the request clauses on that slot's column, `1=1` when inactive;
  `{{#k:K}}...{{/k:K}}` conditional block K (semi-joins, filter-only joins, optional DISTINCT dimension columns) kept when any of
  `meta.blocks[K].slots` is active, else `blocks[K].else` ("" or "1=1"); blocks may nest;
  `{{isf:K}}` ISFILTERED/ISCROSSFILTERED -> TRUE when `isf[K].static` or any of its slots is active;
  `meta.slots = {sid: {table, column}}`, `guards = [{slots, message}]` (a plan error when any guarded slot is active - e.g. a slot that would
  cross-filter date-window bounds, phase 06 6.5), `slot_errors = {sid: message}` (a slot the engine can't apply to this query: the same error
  live returns when selected).
- `render_template(sql, meta, filters)` (phase 10 code): filters by `(table, column)` -> slot; unmatched -> `unapplied` (returned, reported
  as `[OVERLAY:UNREACHABLE_FILTER] filter on T cannot reach this visual; ignored`); Top N refused; `in_query` refused; ops needing a value
  refuse empty lists; empty `in` -> `1=0`. Rendering with filters must equal live `build_sql(spec + those filters)` semantics.
- Top N cards and `in_query` are refused in template mode; relative dates and every other op work.

## 2. Export (`services/standalone_export.py`)
2.1 Slots per page (`page_slots(page, extra)`), exactly as the front end builds request filters: each slicer's target column (synced slicers
included - a hidden synced slicer is still a page visual), the first category column of every visual (cross-filter/map/bookmark selections),
plus `extra` = `filter_card_columns(spec, page)` (supported report + page card columns) and, for drill-through or Tooltip pages,
`source_slot_columns(spec, page)` (source visuals' dim keys, their visual filters and every slot of the source pages; sources from
`drill_sources(spec, target)`: drill pages = visuals using any of their fields; tooltip pages = visuals showing them).
`visual_slots(page_slots, vs, keep=card_cols)`: a slicer never filters its own list, except by a card on the same column.
2.2 `build_templates(spec, engine, sql_overrides) -> _Package {files, queries, drill, filter_values, coverage}`; for each visual the page
queries (supported with a query, untranslated with an edit, or with a title query): key `<page>/<visual>`;
- no query and no edit -> `{"kind": "static"}` for static visual types, else `{"kind": "error", "error": reason}`;
- hand-edited SQL -> `edited_template(sql, slots, engine)`: each `{{filters}}` / `{{filters:T}}` becomes `{{p:N}}` predicates for the slots
  whose table alias the edited text references, file `<base>.edited.sql`, entry `edited: true`;
- else `add(...)` -> `{"kind": "sql", "file": "data/templates/<page>/<visual>.sql", "meta", "warnings"}` (`QueryPlanError` -> error entry);
  `_check_parse`: rendering with no selection and with every (non-guarded, non-error) slot set must parse with sqlglot (Snowflake dialect);
  failures are stored as `parse_warning`;
- title queries -> key `<visual>#title`, file `.title.sql`;
- totals (tables/matrices with show_totals, or show-as visuals; not with measure filters) -> `.totals.sql` attached as `entry.totals`;
- drill (hierarchy levels) -> `pkg.drill[key] = {levels, current_level, by_target: {idx: entry}}`, one template per target level as
  `drill_query` builds it, with the hierarchy columns as extra slots for parent-row filters;
- Filters pane value lists: one template per card column (`filter_values_query(table, column, None, 500)` with its own column as the slot),
  key `Table.Column`, file `data/templates/_filter_values/<safe>.sql`.
File/path names are sanitised (`_safe`).
2.3 `build_standalone_zip(spec, engine, conv_dir, profile, resources, frontend_build=None, vendor=True) -> bytes`, root folder
`<slug>-standalone/` (slug = lower-case report name, non `[a-z0-9-]` -> `-`):
- requires `frontend/dist-standalone/standalone.html`, else `StandaloneExportError("standalone front end not built (<path>): run
  `npm run build:standalone` in frontend/")` -> HTTP 503;
- `app/` = the built files (`standalone.html` renamed `index.html`), `app/dashboard-config.json` = `{api_base: "/api/v1/published", token}`
  (random `secrets.token_urlsafe(32)`), `app/resources/<name>` = report images;
- `service/` = `main.py`, `snowflake_session.py`, `manifest.py`, `connection_store.py` copied verbatim from `app/standalone/`, plus
  `service/render.py` = a verbatim copy of `runtime/sql_render.py` (which therefore must not import `app`);
- `data/spec.json`, `data/manifest.json` (`{version: 1, package_id (random hex, names the saved-credentials entry), report_name, queries,
  drill, filter_values, filter_values_limit: 500}`), `data/connection.json` (`connection_settings(profile)`: account, user, auth_method,
  role, warehouse, database, schema, oauth_client_id, oauth_token_url, remember=false - NEVER secrets), `data/token.txt`,
  `data/templates/**`;
- `COVERAGE.md` (per pane: the slicers/cross-filters it honours and any limits), `README.md` (template with the report title: requirements
  Windows 64-bit + Python 3.12 64-bit, start/stop, signing in, auto-start, contents table, how queries work, security), scripts
  `start.ps1`, `stop.ps1`, `install-autostart.ps1`, `uninstall-autostart.ps1`;
- `vendor/` = the dependency closure (`vendor_distributions`, via `importlib.metadata` + `packaging` markers/extras) of `fastapi`, `uvicorn`,
  `snowflake-connector-python[secure-local-storage]` (brings `keyring`, `cryptography`) installed in the converter's venv, excluding
  `__pycache__`/`.pyc` and paths outside the distribution; refuse to vendor the converter itself; a missing package ->
  `StandaloneExportError("Python package 'X' is not installed in the converter's environment")`.
2.4 `POST /dashboard/export-standalone {connection_id}` -> the zip (`Content-Disposition: attachment; filename="<slug>-standalone.zip"`);
404 unknown connection; 503 on `StandaloneExportError`. Preview step button "Download standalone dashboard ⬇" calls
`api.exportDashboard(conversionId, connectionId, 'standalone')`.

## 3. Local service (`backend/app/standalone/`, shipped as `service/`)
3.1 `main.py`: `create_app(root=PBIS_ROOT, session=None, store=None)`; listens on 127.0.0.1 (port 8765 by default); `PBIS_MAX_PARALLEL_QUERIES`
(8); 300 s in-memory result cache keyed on SQL (cleared on sign-in/out and connection changes); writes `logs/service.pid` unless
`PBIS_NO_AUTOSTART=1`. Every API route requires `Authorization: Bearer <token>` (401 "missing or invalid dashboard token"). Authentication
needed -> 409 `{"detail": {"code": "snowflake_authentication_required", "message", "mfa_required"}}`. Routes (prefix `/api/v1/published`):
`GET /health` (no token) `{ok, report}`; `GET /session`; `POST /session/authenticate {passcode?}` -> `{ok, error?, mfa_required?}`;
`POST /session/sign-out`; `GET /connection` (public settings, `saved_secrets` names only, `load_error`); `PUT /connection` (settings +
`secrets` + `remember`; 422 on invalid; returns `{...public, change: reconnect|reapply|none, session}`); `DELETE /connection/secrets`;
`GET /dashboard/spec`; `GET /dashboard/accelerate` -> `{hydrated: false, available: false}`; `POST /dashboard/accelerate` -> 501;
`POST /dashboard/query {queries: [{visual, page, filters}], mode}` (adds `<visual>#title` queries when the manifest has them; runs in a thread
pool; result shape identical to the converter's `VisualResult`: visual, columns, rows, sql, warnings, error, elapsed_ms, cached,
execution_tier, trace_codes, execution_path (static/error/compatibility), fallback_reason, totals `{columns, row}` best effort);
`POST /dashboard/query/drill {page, visual, direction: down|up, level_key, parent_filters, filters}` -> `{page, visual, level_key, level_index,
total_levels, columns, rows, sql, warnings}` (422 for no hierarchy / bad direction / template errors);
`POST /dashboard/filter-values {page?, table, column, search?, limit}` -> `{values, truncated}` (search = a `contains` filter on the column's
slot; 404 "no value list for T[c]"). Static files: `app/` mounted at `/` with `html=True`.
3.2 `manifest.py::Package(root)`: loads spec/manifest/token; `entry(page, visual)`; `render(entry, filters)` caches template text and calls
`render.render_template`.
3.3 `connection_store.py::ConnectionStore(data_dir, package_id, keyring_module=None)`: settings `account, user, auth_method, role, warehouse,
database, schema, oauth_client_id, oauth_token_url` in `data/connection.json` (old packages without a method default to external_browser);
secret fields per method: password `password`; key_pair `private_key_pem`, `private_key_passphrase`; oauth `oauth_client_secret`; pat `pat_token`;
held in memory; with `remember` saved to `data/secrets.enc` encrypted with Fernet whose key lives in Windows Credential Manager via `keyring`
(service `pbi-standalone-dashboard:<package_id>`, user `secrets-key`; the encrypted file alone is useless). `public()` never returns values.
`update(settings, secrets, remember)`: validates (method known; account, user, warehouse required; warehouse/role identifiers plain or quoted;
OAuth needs client id + token URL; secrets not used by the method rejected), empty secret fields keep held values, switching method drops old
secrets, un-remembering deletes the saved copy; returns `reconnect` (account/user/method/database/schema/oauth fields or new secrets changed),
`reapply` (role/warehouse only) or `none`. `forget()`. Unreadable saved secrets -> `load_error` ("saved credentials could not be read (...);
enter them again").
3.4 `snowflake_session.py::Session(store, query_tag)`: the converter's five methods (password + MFA passcode with `username_password_mfa`,
key pair with the PEM converted to unencrypted PKCS#8 DER bytes, OAuth client credentials by fetching a token with urllib from the token URL,
PAT `programmatic_access_token`, external browser with the SSO URL captured for `status()`); `AuthenticationRequired(mfa_required)` and
`SettingsError`; key pair / PAT / OAuth / plain password reconnect silently when the session expires; SSO and MFA wait for the user
(`POST /session/authenticate`); `apply_settings()` re-applies role/warehouse on the open session (`USE ROLE` / `USE WAREHOUSE`, errors kept in
`settings_error`); `reset()`, `sign_out()`; `status()` -> `{auth_method, account, user, role, warehouse, [who fields], authenticated, signing_in,
sso_url, mfa_required, settings_error, last_error}`; `run(sql)` -> `(columns, rows, query_id)` with one cursor per query (thread-safe). Missing
credentials -> an AuthenticationRequired pointing to Connection settings.
3.5 Scripts: `start.ps1 [-Port 8765] [-NoBrowser]`: if `/health` answers, open the browser and exit; find Python 3.12 (`py -3.12`,
`%ProgramFiles%\Python312`, `%LOCALAPPDATA%\Programs\Python\Python312`, `python` on PATH, version checked) else fail with "Python 3.12 was not
found..."; `PYTHONPATH=<root>\vendor;<root>\service`, `PBIS_ROOT`, `PYTHONDONTWRITEBYTECODE=1`; start `python -m uvicorn main:app --host
127.0.0.1 --port <p> --app-dir <root>\service` in its own hidden console via `cmd /d /s /c "... 1>logs\service.out.log 2>logs\service.err.log
<NUL"`; wait up to 60 s for `/health`, then open the browser; on failure print the last 25 lines of the error log. `stop.ps1`: stop the python
process in `logs\service.pid`. `install-autostart.ps1 [-Port]`: per-user Task Scheduler task "PBI Standalone Dashboard - <folder>" at logon,
interactive, running `start.ps1 -NoBrowser` hidden (SSO needs the desktop session); `uninstall-autostart.ps1` removes it.

## 4. Standalone front end
- `frontend/standalone.html` -> `src/standalone/main.tsx` (top-level await of `/dashboard-config.json`, renders
  `<DashboardApp conversionId="standalone" connectionId="standalone" apiConfig={{baseUrl: api_base, token, published: true}} variant="standalone"/>`),
  `src/standalone/standalone.css` (brand colour overrides); `vite.standalone.config.ts` (react + tailwind plugins, outDir `dist-standalone`,
  `emptyOutDir`, target es2022, input `standalone.html`). `npm run build:standalone` must be re-run after front-end changes.
- `DashboardApp variant="standalone"`: no converter header, ModeToggle (hidden when the service reports `available: false`) or shortcuts;
  `h-screen` layout; `dashboard/standalone/StandaloneTopBar` (`data-testid="standalone-topbar"`: report name, Snowflake status - connected
  (user, role, warehouse) green, "Signing in to Snowflake…", "Snowflake session expired", "Snowflake sign-in required", "Not connected to
  Snowflake" amber; "Sign in again"; "Connection settings"; the Bookmarks menu), `PageTabs` (Power BI Service-style tabs at the bottom,
  `aria-label="Report pages"`: the non-hidden pages plus the current page when it is hidden; nothing when <= 1 tab) and `ConnectionPanel` (opened on any 409 or from the bar: account, user, method (`AUTH_LABELS`), role,
  warehouse, database, schema, per-method secret fields that show "saved" but never values, "Remember on this computer", "Forget saved
  credentials", MFA code up front for password logins and the shared `MfaPasscodePrompt` when required, "Save & sign in" / "Save &
  authenticate", "Complete sign-in in the browser…" with the SSO link; reloads data after a successful sign-in).
- `dashboard/standalone/standaloneApi.ts`: typed client for the session/connection routes with the bearer token.
- The Filters pane, drill-through and tooltips work against the service (`filter-values`, context filters as slots).

## Files
Create: `backend/app/services/standalone_export.py`, `backend/app/standalone/{main.py, manifest.py, connection_store.py,
snowflake_session.py, start.ps1, stop.ps1, install-autostart.ps1, uninstall-autostart.ps1, README.md}`,
`frontend/{standalone.html, vite.standalone.config.ts}`, `frontend/src/standalone/{main.tsx, standalone.css}`,
`frontend/src/dashboard/standalone/{StandaloneTopBar.tsx, PageTabs.tsx, ConnectionPanel.tsx, standaloneApi.ts}`.
Modify: `runtime/engine.py` (template mode), `api/dashboards.py`, `api/client.ts` (`exportDashboard(..., kind)`), `steps/PreviewStep.tsx`,
`dashboard/{DashboardApp.tsx, ModeToggle.tsx, api.ts}`.

## Tests
- `tests/test_standalone_templates.py` (DuckDB; fact table by month with groups + a date dimension): template == live for no selection, every
  slot alone and all slots; two clauses on one column and a NULL selection; guard rule mirrors the live refusal; unplaceable slots reported, not
  guessed; inactive template has no markers left and no extra join; pane operators template == live; relative and date-range template == live.
- `tests/test_standalone_export.py` (FastAPI TestClient, queries on DuckDB, fake session): package contents; edited SQL replaces the generated
  template; missing front-end build fails clearly; vendored packages are the service closure; service requires the local token; serves spec, app
  and live-only mode; query results match the converter; drill down with a parent filter; asks for Snowflake sign-in (409 shape); slots and value
  lists for filter cards; pane filters applied like the converter; filter-values.
- `tests/test_standalone_connection.py` (fake keyring + fake connector): secrets never leave and remember is opt-in; un-remember deletes the saved
  copy; change classification and validation; switching method drops old secrets; old packages default to browser SSO; each method signs in with
  the right kwargs; key pair sends DER bytes; missing credentials point to settings; password MFA flow; silent methods reconnect, browser SSO
  waits; role/warehouse change re-applied without a new sign-in; connection endpoints.
- Frontend: `standalone.test.tsx` (toggle hidden when the service has no extract, kept in the converter, download uses its own endpoint),
  `standaloneShell.test.tsx` (report with status bar and page tabs, no converter chrome; sign-in panel opens on 409 and reloads after sign-in;
  every method, saved secrets never shown, MFA prompt; password logins take the MFA code up front; a held secret shows as saved),
  `filtersPhase3.test.tsx` "shows the Filters pane and loads card values from the local service".

## Done criteria
`npm run build:standalone` succeeds; an exported package's service answers spec/query/drill/filter-values on DuckDB in tests; tests pass.
 