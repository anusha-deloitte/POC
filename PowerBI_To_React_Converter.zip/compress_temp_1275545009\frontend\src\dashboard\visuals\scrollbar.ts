/** Power BI style scrollbars for charts: a fixed window slider plus mouse-wheel scrolling. */

/** Scrollbar thickness in canvas px so it measures ~10 screen px at any page scale (min 8). */
export const scrollThickness = (scale: number): number => Math.max(10 / (scale || 1), 8)

export interface ScrollZoomOptions {
  axis: 'x' | 'y'
  axisIndex: number
  /** last visible axis value of the initial window */
  endValue: number
  scale: number
  /** where the slider sits, in canvas px from the edge */
  position?: number
}

/** `dataZoom` entries: a `zoomLock`ed slider (the window can't be resized) and an `inside`
 * zoom that scrolls the window with the mouse wheel. */
export function scrollZoom({ axis, axisIndex, endValue, scale, position = 0 }: ScrollZoomOptions) {
  const thickness = scrollThickness(scale)
  const target = axis === 'x' ? { xAxisIndex: axisIndex } : { yAxisIndex: axisIndex }
  const slider = {
    type: 'slider' as const,
    ...target,
    startValue: 0,
    endValue,
    zoomLock: true,
    brushSelect: false,
    showDetail: false,
    showDataShadow: false,
    filterMode: 'none' as const,
    realtime: true,
    ...(axis === 'x'
      ? { height: thickness, bottom: position }
      : { width: thickness, right: position }),
  }
  const inside = {
    type: 'inside' as const,
    ...target,
    startValue: 0,
    endValue,
    zoomLock: true,
    zoomOnMouseWheel: false,
    moveOnMouseWheel: true,
    moveOnMouseMove: false,
    filterMode: 'none' as const,
  }
  return [slider, inside]
}
