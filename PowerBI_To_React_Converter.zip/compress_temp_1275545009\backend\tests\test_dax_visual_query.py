"""Phase 08: Performance-Analyzer-style DAX of a visual."""

from __future__ import annotations

from app.dax.visual_query import visual_dax_query
from app.runtime.engine import DimensionRef, FilterClause, MeasureFilter, MeasureRefSpec, QuerySpec


def test_columns_filters_measures_and_sort():
    q = QuerySpec(
        dimensions=[DimensionRef(table="Product", column="Category")],
        measures=[
            MeasureRefSpec(name="Total Sales"),
            MeasureRefSpec(table="Sales", column="Quantity", aggregate="avg", alias="Avg qty"),
        ],
        filters=[
            FilterClause(table="Customer", column="Country", values=["US", "DE"]),
            FilterClause(table="Sales", column="Quantity", op="gte", values=[3]),
        ],
        sort=[{"key": "Total Sales", "direction": "Descending"},
              {"key": "Product.Category", "direction": "Ascending"}],
    )  # fmt: skip
    dax = visual_dax_query(q, "Sales by category")
    assert dax.splitlines()[0] == "// Sales by category"
    assert 'VAR __DS0FilterTable = TREATAS({"US", "DE"}, \'Customer\'[Country])' in dax
    assert "VAR __DS0FilterTable2 = FILTER(ALL('Sales'[Quantity]), 'Sales'[Quantity] >= 3)" in dax
    assert (
        "SUMMARIZECOLUMNS('Product'[Category], __DS0FilterTable, __DS0FilterTable2, "
        '"Total Sales", [Total Sales], "Avg qty", AVERAGE(\'Sales\'[Quantity]))'
    ) in dax
    assert dax.rstrip().endswith("ORDER BY\n    [Total Sales] DESC, 'Product'[Category] ASC")


def test_card_has_no_columns_or_order():
    dax = visual_dax_query(QuerySpec(measures=[MeasureRefSpec(name="Total Sales")]), None)
    assert dax == 'EVALUATE\n    SUMMARIZECOLUMNS("Total Sales", [Total Sales])'


def test_quoting():
    q = QuerySpec(
        dimensions=[DimensionRef(table="Bob's Table", column="a]b")],
        measures=[MeasureRefSpec(name='We"ird]')],
        filters=[FilterClause(table="T", column="C", values=['he said "hi"', None, True, 2.5])],
    )
    dax = visual_dax_query(q, "Multi\nline  title")
    assert dax.startswith("// Multi line title")
    assert "'Bob''s Table'[a]]b]" in dax
    assert '"We""ird]", [We"ird]]]' in dax
    assert '{"he said ""hi""", BLANK(), TRUE(), 2.5}' in dax


def test_other_filter_operators():
    q = QuerySpec(
        measures=[MeasureRefSpec(name="M")],
        filters=[
            FilterClause(table="T", column="C", op="not_in", values=["a"]),
            FilterClause(
                table="T",
                column="D",
                op="or",
                clauses=[
                    FilterClause(table="T", column="D", op="eq", values=["x"]),
                    FilterClause(table="T", column="D", op="lt", values=[1]),
                ],
            ),
        ],
    )
    dax = visual_dax_query(q)
    assert "FILTER(ALL('T'[C]), NOT('T'[C] IN {\"a\"}))" in dax
    assert "'T'[D] = \"x\" || 'T'[D] < 1" in dax


def test_measure_value_filters_wrap_the_table_in_an_outer_filter():
    q = QuerySpec(
        dimensions=[DimensionRef(table="P", column="Name")],
        measures=[MeasureRefSpec(name="Total Sales")],
        measure_filters=[MeasureFilter(measure="Total Sales", op="gt", values=[1000])],
    )
    dax = visual_dax_query(q)
    assert "FILTER(SUMMARIZECOLUMNS(" in dax
    assert '"__mf0", [Total Sales]' in dax
    assert dax.rstrip().endswith("[__mf0] > 1000)")


def test_aggregates_map_to_dax():
    for agg, fn in [("sum", "SUM"), ("min", "MIN"), ("max", "MAX"),
                    ("distinctcount", "DISTINCTCOUNT"), ("count", "COUNTA"),
                    ("countnonnull", "COUNTA"), ("average", "AVERAGE")]:  # fmt: skip
        q = QuerySpec(measures=[MeasureRefSpec(table="T", column="c", aggregate=agg)])
        assert f"{fn}('T'[c])" in visual_dax_query(q)
