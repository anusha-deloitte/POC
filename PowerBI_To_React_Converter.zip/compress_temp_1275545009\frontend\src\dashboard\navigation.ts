/** Page tabs, button actions, bookmarks and history of a rendered report. */
import { useCallback, useMemo, useRef, useState } from 'react'
import type { VisibilityOverrides } from './canvas'
import type { Bookmark, DashboardSpec, PageSpec, VisualAction, VisualSpec } from './types'

/** Hidden names a bookmark captured, and the visuals it is restricted to (empty = every one). */
export function bookmarkVisibility(bookmark: Bookmark): { hidden: string[]; targets: string[] } {
  const state = (bookmark.state ?? {}) as Record<string, unknown>
  const visibility = (state.visibility ?? {}) as Record<string, string>
  const targets = Array.isArray(state.targets) ? (state.targets as string[]) : []
  return {
    hidden: Object.entries(visibility)
      .filter(([, mode]) => mode === 'hidden')
      .map(([name]) => name),
    targets,
  }
}

/** The page a bookmark switches to (null = stay on the current page). */
export function bookmarkPage(bookmark: Bookmark): string | null {
  const state = (bookmark.state ?? {}) as Record<string, unknown>
  const name = state.page_name ?? state.page
  return typeof name === 'string' && name ? name : null
}

/** Overrides after applying a bookmark to a page. `targets` restrict it to its captured visuals
 * only when present. */
export function applyBookmarkOverrides(
  prev: VisibilityOverrides,
  bookmark: Bookmark,
  page: PageSpec,
): VisibilityOverrides {
  const { hidden, targets } = bookmarkVisibility(bookmark)
  const names = page.visuals.map((v) => v.name)
  const scope = targets.length ? names.filter((n) => targets.includes(n)) : names
  const next: VisibilityOverrides = targets.length ? { ...prev } : {}
  for (const name of scope) next[name] = hidden.includes(name) ? 'hidden' : 'visible'
  return next
}

export function findBookmark(bookmarks: Bookmark[], name: string): Bookmark | undefined {
  return bookmarks.find((b) => b.name === name)
}

/** The nearest ancestor group that was hidden as authored. */
export function authoredHiddenAncestor(visual: VisualSpec, page: PageSpec): VisualSpec | undefined {
  const byName = new Map(page.visuals.map((v) => [v.name, v]))
  const seen = new Set<string>([visual.name])
  let parent = visual.pbir?.parent_group
  while (parent && !seen.has(parent)) {
    seen.add(parent)
    const node = byName.get(parent)
    if (!node) return undefined
    if (node.pbir?.self_hidden) return node
    parent = node.pbir?.parent_group
  }
  return undefined
}

/** A button whose bookmark is not in the export: re-hide the nearest as-authored hidden ancestor
 * group, but only when no authored-visible visual on the page is hidden by an override. */
export function handleMissingBookmark(
  button: VisualSpec,
  page: PageSpec,
  overrides: VisibilityOverrides,
): VisibilityOverrides {
  const ancestor = authoredHiddenAncestor(button, page)
  if (!ancestor) return overrides
  const authoredVisibleHidden = page.visuals.some(
    (v) => !v.pbir?.is_hidden && overrides[v.name] === 'hidden',
  )
  if (authoredVisibleHidden) return overrides
  return { ...overrides, [ancestor.name]: 'hidden' }
}

/** Buttons whose action can't run get `pointer-events: none`. */
export function actionCannotRun(
  visual: VisualSpec,
  page: PageSpec,
  spec: Pick<DashboardSpec, 'pages' | 'bookmarks'>,
): boolean {
  const action = visual.action
  if (!action) return false
  if (action.type === 'Bookmark')
    return !findBookmark(spec.bookmarks, action.bookmark ?? '') && !authoredHiddenAncestor(visual, page)
  if (action.type === 'PageNavigation') return !spec.pages.some((p) => p.name === action.page)
  return false
}

export interface ReportNavigation {
  pageName: string
  page: PageSpec | undefined
  /** tabs: hidden pages are excluded */
  tabs: PageSpec[]
  overrides: VisibilityOverrides
  canGoBack: boolean
  goToTab: (name: string) => void
  goToPage: (name: string) => void
  applyBookmark: (bookmark: Bookmark) => void
  runAction: (visual: VisualSpec) => void
  back: () => void
}

/** Navigation of a report: tabs (a tab click is a fresh start), actions and history. */
export function useReportNavigation(
  spec: DashboardSpec | undefined,
  options: {
    onFreshStart?: () => void
    onDrillthrough?: (action: VisualAction, visual: VisualSpec) => void
    onBookmark?: (bookmark: Bookmark) => void
    openUrl?: (url: string) => void
  } = {},
): ReportNavigation {
  const [pageName, setPageName] = useState<string | null>(null)
  const [overrides, setOverrides] = useState<VisibilityOverrides>({})
  const [history, setHistory] = useState<string[]>([])
  const opts = useRef(options)
  opts.current = options

  const tabs = useMemo(() => (spec?.pages ?? []).filter((p) => !p.is_hidden), [spec])
  const current = pageName ?? tabs[0]?.name ?? spec?.pages[0]?.name ?? ''
  const page = spec?.pages.find((p) => p.name === current)

  const goTo = useCallback(
    (name: string, remember: boolean) => {
      if (!spec?.pages.some((p) => p.name === name)) return
      if (remember && current && current !== name) setHistory((h) => [...h, current])
      setPageName(name)
    },
    [spec, current],
  )

  const goToTab = useCallback(
    (name: string) => {
      setOverrides({})
      setHistory([])
      setPageName(name)
      opts.current.onFreshStart?.()
    },
    [],
  )

  const applyBookmark = useCallback(
    (bookmark: Bookmark) => {
      if (!spec) return
      const target = bookmarkPage(bookmark)
      const targetPage = spec.pages.find((p) => p.name === (target ?? current))
      if (target && target !== current) goTo(target, true)
      if (targetPage) setOverrides((prev) => applyBookmarkOverrides(target ? {} : prev, bookmark, targetPage))
      opts.current.onBookmark?.(bookmark)
    },
    [spec, current, goTo],
  )

  const back = useCallback(() => {
    setHistory((h) => {
      if (!h.length) return h
      setPageName(h[h.length - 1])
      setOverrides({})
      return h.slice(0, -1)
    })
  }, [])

  const runAction = useCallback(
    (visual: VisualSpec) => {
      const action = visual.action
      if (!action || !spec) return
      switch (action.type) {
        case 'Bookmark': {
          const bookmark = findBookmark(spec.bookmarks, action.bookmark ?? '')
          if (bookmark) applyBookmark(bookmark)
          else if (page) setOverrides((prev) => handleMissingBookmark(visual, page, prev))
          break
        }
        case 'PageNavigation':
          if (action.page) {
            setOverrides({})
            goTo(action.page, true)
          }
          break
        case 'Back':
          back()
          break
        case 'WebUrl':
          if (action.url) (opts.current.openUrl ?? ((u) => window.open(u, '_blank', 'noopener')))(action.url)
          break
        case 'Drillthrough':
          opts.current.onDrillthrough?.(action, visual)
          break
      }
    },
    [spec, page, applyBookmark, back, goTo],
  )

  return {
    pageName: current,
    page,
    tabs,
    overrides,
    canGoBack: history.length > 0,
    goToTab,
    goToPage: (name) => goTo(name, true),
    applyBookmark,
    runAction,
    back,
  }
}
