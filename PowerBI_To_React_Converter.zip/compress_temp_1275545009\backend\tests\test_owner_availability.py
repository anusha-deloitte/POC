"""ALL + keep idiom, VAR in row filter, context-dependent VAR refused (phase 06.4)."""

from __future__ import annotations

import pytest

from app.dax.compiler import DaxUnsupported
from app.runtime.engine import FilterClause, QueryPlanError
from tests.duck import DuckWorld


def world(measures: dict[str, str]) -> DuckWorld:
    return DuckWorld(
        {
            "Sales": (
                ["Id", "Key", "Region", "Amount"],
                [(1, 1, "N", 10.0), (2, 1, "S", 5.0), (3, 2, "N", 7.0), (4, 3, "E", 1.0)],
            ),
            "Dim": (["Id", "Name"], [(1, "a"), (2, "b"), (3, "c")]),
        },
        rels=[("Sales", "Key", "Dim", "Id")],
        measures={"Total": "SUM(Sales[Amount])", **measures},
    )


REGION_N = [FilterClause(table="Sales", column="Region", values=["N"])]
MONTHISH = [FilterClause(table="Sales", column="Key", values=[1])]


def test_all_with_keep_idiom_keeps_the_current_filter_on_that_column():
    w = world(
        {
            "Keep": "CALCULATE([Total], FILTER(ALL(Sales), "
            "Sales[Region] = MAX(Sales[Region]) && Sales[Amount] > 4))"
        }
    )
    # slicer Region = N, slicer Key = 1: ALL clears Key, the idiom keeps Region
    assert w.value("Keep", filters=REGION_N + MONTHISH) == 17.0
    assert w.value("Keep") == 10.0 + 5.0 + 7.0  # no slicers: amounts > 4 in every region


def test_var_whole_table_scalar_in_row_filter():
    w = world(
        {
            "AtMax": "VAR m = CALCULATE(MAX(Sales[Amount]), ALL(Sales)) "
            "RETURN CALCULATE([Total], FILTER(ALL(Sales), Sales[Amount] = m))"
        }
    )
    assert w.value("AtMax") == 10.0
    assert w.value("AtMax", filters=[FilterClause(table="Sales", column="Region", values=["S"])]) == 10.0


def test_context_dependent_var_in_row_filter_is_unsupported():
    w = world(
        {
            "Bad": "VAR m = [Total] RETURN CALCULATE([Total], FILTER(ALL(Sales), Sales[Amount] = m))"
        }
    )
    with pytest.raises((DaxUnsupported, QueryPlanError), match="VAR"):
        w.value("Bad")


def test_all_ignores_slicer_but_keeps_listed_owner():
    w = world({"Owner": "CALCULATE([Total], ALLEXCEPT(Sales, Sales[Region]))"})
    assert w.value("Owner", filters=REGION_N + MONTHISH) == 17.0


def test_cross_table_aggregate_in_row_filter_becomes_scalar_subquery():
    from app.runtime.engine import MeasureRefSpec, QuerySpec

    w = world({"Big": "CALCULATE([Total], FILTER(Sales, Sales[Amount] >= MAX(Dim[Id]) * 3))"})
    sql, _ = w.sql(QuerySpec(measures=[MeasureRefSpec(name="Big")]))
    assert "SELECT MAX(" in sql and "__T" not in sql
    assert w.value("Big") == 10.0  # amount >= 9
