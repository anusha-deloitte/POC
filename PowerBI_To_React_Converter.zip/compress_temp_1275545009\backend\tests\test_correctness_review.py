"""Phase 13 / group 7: focused regression tests where the correctness review found gaps.

Existing coverage that was reviewed and left alone: blank comparisons (`test_null_filters`),
TOPN ties and NULL keys (`test_topn_filter`), case fixes and quoting (`test_phase05_binding`),
M renames / alias collisions (`test_phase05_binding`, `test_combine_groups`) and dimension-only
tables (`test_combine_groups`).
"""

from __future__ import annotations

from app.binding.resolver import quote_ident
from app.runtime.engine import (
    DimensionRef,
    FilterClause,
    MeasureFilter,
    MeasureRefSpec,
    QuerySpec,
)
from tests.duck import DuckWorld
from tests.test_combine_groups import calc_world

TOTAL = MeasureRefSpec(name="Total")


def by(world: DuckWorld, dims: list[str], filters=None, measure_filters=None, table="Sales"):
    q = QuerySpec(
        dimensions=[DimensionRef(table=table, column=d) for d in dims],
        measures=[TOTAL],
        filters=filters or [],
        measure_filters=measure_filters or [],
    )
    return dict(world.run(q))


def test_calc_column_filter_combined_with_visual_filters_on_other_columns():
    w = calc_world()
    # Big = "big" for Amount > 6: rows 1 (N, 10) and 3 (n, 7)
    assert by(w, ["Big"], [FilterClause(table="Sales", column="Region", values=["N"])]) == {
        "big": 10.0
    }
    both = [
        FilterClause(table="Sales", column="Big", values=["big"]),
        FilterClause(table="Sales", column="Region", op="neq", values=["N"]),
    ]
    assert w.value("Total", filters=both) == 7.0
    # not_in on a calc column keeps NULL-free rows only through the null-safe rule
    assert (
        w.value(
            "Total",
            filters=[FilterClause(table="Sales", column="Big", op="not_in", values=["big"])],
        )
        == 6.0
    )


def test_or_clause_over_a_calc_column_and_a_visual_filter():
    """An `or` clause ORs its operands on its own column (a Filters-pane card); it still ANDs
    with the visual's other filters."""
    w = calc_world()
    big_or_small = FilterClause(
        table="Sales",
        column="Big",
        op="or",
        clauses=[
            FilterClause(table="Sales", column="Big", values=["big"]),
            FilterClause(table="Sales", column="Big", values=["small"]),
        ],
    )
    assert w.value("Total", filters=[big_or_small]) == 23.0
    north = FilterClause(table="Sales", column="Region", values=["N"])
    assert w.value("Total", filters=[big_or_small, north]) == 10.0


def test_calc_column_dimension_with_a_measure_filter_and_a_visual_filter():
    w = calc_world()
    rows = by(
        w,
        ["Big"],
        [FilterClause(table="Sales", column="Region", op="not_in", values=["S"])],
        [MeasureFilter(measure="Total", op="gt", values=[1.0])],
    )
    assert rows == {"big": 17.0}


def test_in_filter_with_null_and_calc_column_grouping():
    w = calc_world()
    assert (
        w.value("Total", filters=[FilterClause(table="Sales", column="Region", values=["N", None])])
        == 10.0
    )
    assert by(w, ["Inv2"], [FilterClause(table="Sales", column="Region", op="is_not_blank")]) == {
        1: 18.0,
        0: 5.0,
    }


def test_identifiers_with_spaces_parens_and_quotes_are_quoted_by_quote_ident():
    w = DuckWorld(
        {
            "Sales (2024)": (
                ["Net Amount", "Region Name", "Key"],
                [(10.0, "a'b", 1), (5.0, "c", 2)],
            ),
            "Dim Tbl": (["Key", "Label (x)"], [(1, "one"), (2, "two")]),
        },
        rels=[("Sales (2024)", "Key", "Dim Tbl", "Key")],
        measures={"Total": "SUM('Sales (2024)'[Net Amount])"},
        measure_table="Sales (2024)",
    )
    q = QuerySpec(
        dimensions=[DimensionRef(table="Dim Tbl", column="Label (x)")],
        measures=[TOTAL],
        filters=[FilterClause(table="Sales (2024)", column="Region Name", values=["a'b"])],
    )
    sql, _ = w.engine().build_sql(q)
    for name in ("Sales (2024)", "Dim Tbl", "Label (x)", "Net Amount", "Region Name"):
        assert quote_ident(name) in sql
    assert "'a''b'" in sql  # the literal's quote is doubled
    assert dict(w.run(q)) == {"one": 10.0}
    assert quote_ident('a"b') == '"a""b"'
