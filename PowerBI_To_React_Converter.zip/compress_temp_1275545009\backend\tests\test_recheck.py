"""Phase 08: re-check one pane without a full Convert."""

from __future__ import annotations

import json

import pytest

from tests.phase08 import BAR, CARD, PAGE, World
from tests.test_api import client  # noqa: F401

_FAILED_CARD = {
    "visual": CARD,
    "page": PAGE,
    "visual_type": "card",
    "checks": [{"name": "execute", "status": "failed", "detail": "old failure"}],
}


@pytest.fixture()
def world(client, contoso_pbip, monkeypatch):  # noqa: F811
    w = World(client, contoso_pbip, monkeypatch)
    w.responder = lambda sql: (["Total Sales"], [(42.0,)])
    return w


def _recheck(world, visual=CARD):
    return world.post(
        "recheck", {"page": PAGE, "visual": visual, "connection_id": world.conn_id}
    )


def test_404_without_a_conversion_run(world):
    r = _recheck(world)
    assert r.status_code == 404 and "no conversion run yet; POST /convert first" in r.text


def test_generated_sql_updates_the_scorecard(world):
    world.write_run([_FAILED_CARD])
    r = _recheck(world)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["previous_status"] == "failed"
    assert body["visual"]["status"] == "passed" and body["visual"]["score"] == 1.0
    assert body["visual"]["rechecked_at"] and body["used_edited_sql"] is False
    assert body["summary"]["previous_overall_score"] == 0.5
    assert body["summary"]["visuals_total"] == 1 and body["summary"]["visuals_passed"] == 1
    run = json.loads((world.root / "conversion_run.json").read_text())
    saved = run["fidelity"]["pages"][0]["visuals"][0]
    assert saved["rechecked_at"] and run["summary"]["overall_score"] == 1.0
    audit = world.get("query-audit", kind="validation").json()["records"]
    assert audit and audit[0]["check"] == "main" and audit[0]["recheck"] is True


def test_a_new_pane_is_appended(world):
    world.write_run([])
    body = _recheck(world, BAR).json()
    assert body["previous_status"] is None
    run = json.loads((world.root / "conversion_run.json").read_text())
    assert [v["visual"] for v in run["fidelity"]["pages"][0]["visuals"]] == [BAR]


def test_failing_query_keeps_the_pane_failed(world):
    world.write_run([])
    world.responder = lambda sql: (_ for _ in ()).throw(RuntimeError("no such table"))
    body = _recheck(world).json()
    assert body["visual"]["status"] == "failed"
    assert any("no such table" in c["detail"] for c in body["visual"]["checks"])


def test_edited_sql_is_used(world):
    world.write_run([_FAILED_CARD])
    world.client.put(
        world.url("sql-overrides"),
        json={"page": PAGE, "visual": CARD, "sql": 'SELECT 3 AS "Total Sales"'},
    )
    body = _recheck(world).json()
    assert body["used_edited_sql"] is True and body["visual"]["sql_override"] is True
    assert world.executed[-1] == 'SELECT 3 AS "Total Sales"'
    # the edit must return every column the pane reads
    world.client.put(
        world.url("sql-overrides"),
        json={"page": PAGE, "visual": CARD, "sql": 'SELECT 3 AS "Other"'},
    )
    world.responder = lambda sql: (["Other"], [(3.0,)])
    bad = _recheck(world).json()
    assert bad["visual"]["status"] == "failed"
    assert any(c["name"] == "columns" and c["status"] == "failed" for c in bad["visual"]["checks"])


def test_invalid_edit_fails_execute_with_the_reason(world, monkeypatch):
    world.write_run([_FAILED_CARD])
    world.client.put(
        world.url("sql-overrides"),
        json={"page": PAGE, "visual": CARD, "sql": 'SELECT 3 AS "Total Sales"'},
    )

    def boom(*_a, **_k):
        raise ValueError("bad placeholder")

    monkeypatch.setattr("app.api.dashboards._sqlo.render", boom)
    body = _recheck(world).json()
    execute = next(c for c in body["visual"]["checks"] if c["name"] == "execute")
    assert execute["status"] == "failed" and execute["detail"] == "edited SQL: bad placeholder"
    assert body["used_edited_sql"] is False


def test_unknown_pane_is_404(world):
    world.write_run([])
    assert _recheck(world, "nope").status_code == 404
