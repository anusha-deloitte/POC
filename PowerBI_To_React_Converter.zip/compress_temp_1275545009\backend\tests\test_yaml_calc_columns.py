"""Calculated columns compiled for semantic views: iterators, lookups, scalars (phase 06.12)."""

from __future__ import annotations

from datetime import date

import pytest

from app.dax.compiler import MeasureCompiler
from app.runtime.accelerate import to_duckdb_sql
from app.runtime.engine import FilterClause
from app.runtime.semantic_view import SemanticViewAdapter
from app.semantic.yaml_compiler import _CalcColCompiler, semantic_metric_plan
from tests.duck import DuckWorld


def make_world() -> DuckWorld:
    return DuckWorld(
        {
            "Base": (["Id", "Name"], [(1, "alpha"), (2, "beta"), (3, "gamma")]),
            "Mid": (["Id", "BaseId"], [(10, 1), (11, 1), (12, 2)]),
            "Leaf": (["MidId", "V"], [(10, 1.0), (10, 2.0), (11, 4.0), (12, 8.0)]),
            "Line": (
                ["BaseId", "Amt", "Tag"],
                [(1, 3.0, "x"), (1, 7.0, "y"), (2, 5.0, "z")],
            ),
            "Dts": (["D"], [(date(2024, 1, 31),)]),
        },
        rels=[
            ("Mid", "BaseId", "Base", "Id"),
            ("Leaf", "MidId", "Mid", "Id"),
            ("Line", "BaseId", "Base", "Id"),
        ],
    )


def evaluate(w: DuckWorld, table: str, dax: str):
    sql = _CalcColCompiler(table, w.model, w.bindings).compile(dax)
    assert sql is not None, f"not translated: {dax}"
    order = w.model.table(table).columns[0].name
    query = (
        f'SELECT {sql} AS v FROM {w.bindings.get(table).qualified_name} AS "{table}" '
        f'ORDER BY "{table}"."{order}"'
    )
    return [r[0] for r in w.con.execute(to_duckdb_sql(query, w.bindings)).fetchall()], sql


def test_relatedtable_iterator_is_a_correlated_aggregate():
    w = make_world()
    values, sql = evaluate(w, "Base", "SUMX(RELATEDTABLE(Line), Line[Amt])")
    assert values == [10.0, 5.0, None]  # gamma has no lines
    assert 'WHERE ("Line"."BaseId" = "Base"."Id")' in sql or '"Line"."BaseId" = "Base"."Id"' in sql


def test_filter_over_relatedtable_and_other_iterators():
    w = make_world()
    assert evaluate(w, "Base", "SUMX(FILTER(RELATEDTABLE(Line), Line[Amt] > 4), Line[Amt])")[0] == [
        7.0, 5.0, None,
    ]
    assert evaluate(w, "Base", "COUNTX(RELATEDTABLE(Line), Line[Amt])")[0] == [2, 1, 0]
    assert evaluate(w, "Base", "MAXX(RELATEDTABLE(Line), Line[Amt])")[0] == [7.0, 5.0, None]
    assert evaluate(w, "Base", "MINX(RELATEDTABLE(Line), Line[Amt])")[0] == [3.0, 5.0, None]
    assert evaluate(w, "Base", "AVERAGEX(RELATEDTABLE(Line), Line[Amt])")[0] == [5.0, 5.0, None]


def test_uncorrelated_sources_read_the_whole_table():
    w = make_world()
    assert evaluate(w, "Base", "MAXX(Line, Line[Amt])")[0] == [7.0, 7.0, 7.0]
    assert evaluate(w, "Base", "SUMX(ALL(Line), Line[Amt])")[0] == [15.0, 15.0, 15.0]
    assert evaluate(w, "Base", "SUMX(FILTER(Line, Line[Amt] > 4), Line[Amt])")[0] == [12.0] * 3


def test_two_hop_path_joins_intermediate_tables():
    w = make_world()
    values, sql = evaluate(w, "Base", "SUMX(RELATEDTABLE(Leaf), Leaf[V])")
    assert values == [7.0, 8.0, None]  # alpha: 1 + 2 + 4, beta: 8
    assert "JOIN" in sql and sql.count("WHERE") == 1  # only the outermost WHERE correlates


def test_nested_iterators():
    w = make_world()
    nested = "SUMX(RELATEDTABLE(Mid), SUMX(RELATEDTABLE(Leaf), Leaf[V]))"
    assert evaluate(w, "Base", nested)[0] == [7.0, 8.0, None]


def test_related_is_many_to_one_only():
    w = make_world()
    values, _ = evaluate(w, "Line", "RELATED(Base[Name])")
    assert sorted(values) == ["alpha", "alpha", "beta"]
    assert _CalcColCompiler("Base", w.model, w.bindings).compile("RELATED(Line[Amt])") is None


def test_lookupvalue_and_concatenatex():
    w = make_world()
    values, _ = evaluate(w, "Line", "LOOKUPVALUE(Base[Name], Base[Id], Line[BaseId])")
    assert sorted(values) == ["alpha", "alpha", "beta"]
    only_one, _ = evaluate(w, "Base", 'CONCATENATEX(FILTER(RELATEDTABLE(Line), Line[Tag] = "z"), Line[Tag], ",")')
    assert only_one == [None, "z", None]


@pytest.mark.parametrize(
    ("dax", "expected"),
    [
        ('CONTAINSSTRING("Hello World", "WORLD")', True),
        ("DAYS(DATE(2024, 3, 10), DATE(2024, 3, 1))", 9),
        ("EDATE(DATE(2024, 1, 31), 1)", date(2024, 2, 29)),
        ("EOMONTH(DATE(2024, 2, 10), 0)", date(2024, 2, 29)),
        ('EXACT("a", "a")', True),
        ('FIND("lo", "Hello")', 4),
        ("INT(7.9)", 7),
        ("MOD(10, 3)", 1),
        ("POWER(2, 5)", 32),
        ("QUOTIENT(17, 5)", 3),
        ('REPLACE("abcdef", 2, 3, "XY")', "aXYef"),
        ('REPT("ab", 3)', "ababab"),
        ("ROUNDDOWN(2.789, 1)", 2.7),
        ("ROUNDUP(2.711, 1)", 2.8),
        ('SEARCH("L", "hello")', 3),
        ("SIGN(-4)", -1),
        ("TRUNC(8.9)", 8),
        ("UNICHAR(65)", "A"),
        ("XOR(TRUE(), FALSE())", True),
        ("IFF(1 = 1, 5, 6)", 5),
        ("1 IN {1, 2}", True),
        ("NOT (3 IN {BLANK(), 1})", True),
        ("BLANK() = BLANK()", True),
    ],
)
def test_scalar_functions(dax, expected):
    w = make_world()
    values, _ = evaluate(w, "Dts", dax)
    got = values[0]
    if got.__class__.__name__ == "Decimal":
        got = float(got)
    if isinstance(expected, date) and hasattr(got, "date"):
        got = got.date()
    assert got == (pytest.approx(expected) if isinstance(expected, float) else expected)


def test_blank_comparison_rewrite_has_no_equals_null():
    w = make_world()
    sql = _CalcColCompiler("Line", w.model, w.bindings).compile("IF(Line[Tag] <> BLANK(), 1, 0)")
    assert sql is not None and "<> NULL" not in sql and "IS NULL" in sql


def test_unsupported_functions_return_none():
    w = make_world()
    assert _CalcColCompiler("Base", w.model, w.bindings).compile("RANKX(ALL(Line), 1)") is None


def test_grouped_and_related_leaves_are_never_semantic_view_metrics():
    w = make_world()
    w.model.tables[0].measures.extend(
        __import__("app.ir.model", fromlist=["Measure"]).Measure(name=n, expression=e)
        for n, e in [
            ("Grouped", 'SUMX(ADDCOLUMNS(SUMMARIZE(Line, Line[BaseId]), "n", CALCULATE(SUM(Line[Amt]))), [n])'),
            ("Related", "SUMX(Line, Line[Amt] * RELATED(Base[Id]))"),
            ("Plain", "SUM(Line[Amt])"),
        ]
    )
    comp = MeasureCompiler(w.model)
    assert semantic_metric_plan(w.model, comp, "Grouped") is None
    assert semantic_metric_plan(w.model, comp, "Related") is None
    assert semantic_metric_plan(w.model, comp, "Plain") is not None


def test_semantic_view_filters_are_null_safe():
    adapter = SemanticViewAdapter(make_world().model)
    f = lambda **kw: adapter._filter_sql(FilterClause(table="T", column="c", **kw))  # noqa: E731
    assert f(op="not_in", values=[None]) == '"c" IS NOT NULL'
    assert f(op="not_in", values=[None, "x"]) == "(\"c\" IS NOT NULL AND \"c\" != 'x')"
    assert f(op="in", values=[None, "x", "y"]) == "(\"c\" IS NULL OR \"c\" IN ('x', 'y'))"
    assert f(op="eq", values=[None]) == '"c" IS NULL'
    assert f(op="neq", values=[None]) == '"c" IS NOT NULL'
    assert f(op="eq", values=["x"]) == "\"c\" = 'x'"
    assert f(op="gt", values=[3]) == '"c" > 3'
