/** Pure helpers of the page canvas: scaling, stacking, visibility, empty states, notices. */
import { createContext } from 'react'
import { CHROME_TYPES } from './pbi/resolve'
import type { PageSpec, VisualResult, VisualSpec } from './types'

export type FitMode = 'FitToPage' | 'FitToWidth' | 'ActualSize'

type Values = (string | number)[]

/** The selection of every slicer on a page: a slicer whose sync group shares filters shows the
 * group's selection (any page, hidden or not); others their own page-local state; a saved
 * selection applies until changed. */
export function withSlicerDefaults(
  page: Pick<PageSpec, 'visuals'>,
  slicerState: Record<string, Values>,
  syncState: Record<string, Values>,
): Record<string, Values> {
  const out: Record<string, Values> = {}
  for (const v of page.visuals) {
    if (v.visual_type !== 'slicer') continue
    const group = v.sync_group
    if (group?.filter_changes)
      out[v.name] = group.name in syncState ? syncState[group.name] : (v.default_selection ?? [])
    else out[v.name] = v.name in slicerState ? slicerState[v.name] : (v.default_selection ?? [])
  }
  return out
}

/** A slicer change: a slicer whose group has `filter_changes` writes the group (clearing to All
 * clears the group); others write only their own state. `fieldChanges`-only groups share no
 * selections. */
export function applySlicerChange(
  slicerState: Record<string, Values>,
  syncState: Record<string, Values>,
  visual: Pick<VisualSpec, 'name' | 'sync_group'>,
  values: Values,
): { slicerState: Record<string, Values>; syncState: Record<string, Values> } {
  const group = visual.sync_group
  if (group?.filter_changes)
    return { slicerState, syncState: { ...syncState, [group.name]: values } }
  return { slicerState: { ...slicerState, [visual.name]: values }, syncState }
}

export const CanvasScaleContext = createContext<number>(1)

/** FitToPage uses the limiting dimension, FitToWidth ignores height, ActualSize is 1. */
export function canvasScale(
  mode: FitMode,
  containerWidth: number,
  containerHeight: number,
  pageWidth: number,
  pageHeight: number,
): number {
  if (mode === 'ActualSize' || pageWidth <= 0 || pageHeight <= 0) return 1
  const byWidth = containerWidth / pageWidth
  if (mode === 'FitToWidth' || containerHeight <= 0) return byWidth
  return Math.min(byWidth, containerHeight / pageHeight)
}

/** `fit="auto"` honours the page's display option (default FitToPage). */
export function resolveFit(fit: FitMode | 'auto', displayOption?: string | null): FitMode {
  if (fit !== 'auto') return fit
  return displayOption === 'FitToWidth' || displayOption === 'ActualSize' ? displayOption : 'FitToPage'
}

/** CSS z-index is the integer RANK of each visual's (possibly fractional) z. */
export function zRanks(visuals: Pick<VisualSpec, 'name' | 'z'>[]): Map<string, number> {
  const ordered = [...visuals].sort((a, b) => a.z - b.z)
  return new Map(ordered.map((v, i) => [v.name, i + 1]))
}

export type VisibilityOverrides = Record<string, 'hidden' | 'visible'>

function ownHidden(spec: VisualSpec, overrides: VisibilityOverrides): boolean {
  const override = overrides[spec.name]
  if (override !== undefined) return override === 'hidden'
  return Boolean(spec.pbir?.self_hidden ?? spec.pbir?.is_hidden)
}

/** Own flag or bookmark override, including hidden ancestor groups. A child of a hidden group is
 * hidden until a bookmark shows the group. */
export function isEffectivelyHidden(
  spec: VisualSpec,
  overrides: VisibilityOverrides,
  visuals: Map<string, VisualSpec> | VisualSpec[],
): boolean {
  const byName = Array.isArray(visuals) ? new Map(visuals.map((v) => [v.name, v])) : visuals
  const seen = new Set<string>()
  let node: VisualSpec | undefined = spec
  while (node && !seen.has(node.name)) {
    seen.add(node.name)
    if (ownHidden(node, overrides)) return true
    const parent: string | null | undefined = node.pbir?.parent_group
    node = parent ? byName.get(parent) : undefined
  }
  return false
}

export const hasData = (spec: VisualSpec): boolean =>
  !CHROME_TYPES.has(spec.visual_type) && spec.data_status !== 'unsupported_type'

/** Visual names a page asks the backend for: data visuals, panes with hand-edited SQL, and the
 * `<visual>#title` queries of measure-driven titles. */
export function queryVisualNames(page: PageSpec): string[] {
  const names: string[] = []
  for (const v of page.visuals) {
    if (v.supported && v.query) names.push(v.name)
    else if (v.manual_sql && v.data_status === 'untranslated') names.push(v.name)
    if (v.title_query) names.push(`${v.name}#title`)
  }
  return [...new Set(names)]
}

/** The text of a `<visual>#title` result (first cell of the first row). */
export function titleFromResult(result?: VisualResult | null): string | undefined {
  const cell = result?.rows?.[0]?.[0]
  if (cell === null || cell === undefined || result?.error) return undefined
  const text = String(cell).trim()
  return text === '' ? undefined : text
}

export function emptyResult(spec: VisualSpec): VisualResult {
  const q = spec.query ?? spec.draft_query
  const columns = [
    ...spec.dim_keys,
    ...spec.measure_keys,
    ...(q ? q.measures.map((m) => m.alias ?? m.name ?? '') : []),
  ].filter((c, i, all) => c && all.indexOf(c) === i)
  return { visual: spec.name, columns, rows: [], warnings: [], elapsed_ms: 0, cached: false }
}

/** Why a visual shows no data, or null (a pane with hand-edited SQL has no notice). */
export function unavailableReason(spec: VisualSpec, result?: VisualResult): string | null {
  if (spec.data_status === 'unsupported_type')
    return `${spec.visual_type} is not supported yet, so its data isn't drawn.`
  if (spec.data_status === 'untranslated' && !spec.manual_sql)
    return 'This visual could not be translated to Snowflake SQL yet.'
  if (result?.error) return `Query failed: ${result.error.split('\n')[0]}`
  if (!spec.supported && !spec.manual_sql) return spec.unsupported_reason ?? 'Not supported yet.'
  return null
}

export function noDataLabel(spec: VisualSpec, result?: VisualResult): string {
  if (spec.data_status === 'unsupported_type') return 'Unsupported visual'
  if (spec.data_status === 'untranslated' && !spec.manual_sql) return 'No SQL generated'
  if (result?.error) return 'Query failed'
  return 'No data'
}

export interface Notice {
  visuals: string[]
  reason: string
  x: number
  y: number
  width: number
  compact: boolean
}

const overlaps = (a: VisualSpec, b: VisualSpec) =>
  a.x < b.x + b.width && b.x < a.x + a.width && a.y < b.y + b.height && b.y < a.y + a.height

/** One notice per stack of overlapping visuals that lack data. Chrome and tiny decoration
 * visuals never get one. */
export function groupNotices(
  visuals: VisualSpec[],
  results: Record<string, VisualResult>,
): { visuals: VisualSpec[]; reason: string }[] {
  const candidates = visuals.filter(
    (v) =>
      !CHROME_TYPES.has(v.visual_type) &&
      v.width > 24 &&
      v.height > 24 &&
      unavailableReason(v, results[v.name]) !== null,
  )
  const groups: VisualSpec[][] = []
  for (const v of candidates) {
    const hit = groups.filter((g) => g.some((o) => overlaps(o, v)))
    if (hit.length === 0) groups.push([v])
    else {
      const merged = hit.flat()
      for (const h of hit) groups.splice(groups.indexOf(h), 1)
      groups.push([...merged, v])
    }
  }
  return groups.map((g) => {
    const top = [...g].sort((a, b) => b.z - a.z)[0]
    return { visuals: g, reason: unavailableReason(top, results[top.name]) ?? '' }
  })
}

/** Places each notice at the top-right of its stack, shifting left so none overlap; narrow ones
 * show only the symbol. */
export function placeNotices(
  groups: { visuals: VisualSpec[]; reason: string }[],
  full = 150,
  symbol = 18,
): Notice[] {
  const placed: Notice[] = []
  for (const g of groups) {
    const right = Math.max(...g.visuals.map((v) => v.x + v.width))
    const top = Math.min(...g.visuals.map((v) => v.y))
    const left = Math.min(...g.visuals.map((v) => v.x))
    const compact = right - left < full + symbol
    const width = compact ? symbol : full
    let x = right - width - 4
    const y = top + 4
    for (let guard = 0; guard < 50; guard++) {
      const clash = placed.find((p) => x < p.x + p.width + 2 && p.x < x + width + 2 && Math.abs(p.y - y) < symbol)
      if (!clash) break
      x = clash.x - width - 2
    }
    placed.push({ visuals: g.visuals.map((v) => v.name), reason: g.reason, x, y, width, compact })
  }
  return placed
}

/** A row of label buttons shares one text line: the vertical offset that centres each button's
 * text on the row's median centre. */
export function alignButtonRows(visuals: VisualSpec[], tolerance = 2): Record<string, number> {
  const buttons = visuals.filter((v) => v.visual_type === 'actionButton')
  const offsets: Record<string, number> = {}
  const rows: VisualSpec[][] = []
  for (const b of buttons) {
    const row = rows.find((r) => Math.abs(r[0].y - b.y) <= tolerance)
    if (row) row.push(b)
    else rows.push([b])
  }
  for (const row of rows) {
    const centres = row.map((b) => b.y + b.height / 2).sort((a, b) => a - b)
    const median = centres[Math.floor(centres.length / 2)]
    for (const b of row) offsets[b.name] = row.length > 1 ? median - (b.y + b.height / 2) : 0
  }
  return offsets
}
