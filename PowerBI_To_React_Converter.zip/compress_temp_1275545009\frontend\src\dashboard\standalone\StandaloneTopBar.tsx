import type { ReactNode } from 'react'
import type { SessionStatus } from './standaloneApi'

export type SnowflakeState = 'connected' | 'signing_in' | 'expired' | 'required' | 'not_connected'

export function snowflakeState(session: SessionStatus | undefined, authRequired: boolean): SnowflakeState {
  if (!session) return authRequired ? 'required' : 'not_connected'
  if (session.signing_in) return 'signing_in'
  if (session.authenticated && !authRequired) return 'connected'
  if (!session.account || !session.user) return 'not_connected'
  if (/expired/i.test(session.last_error ?? '')) return 'expired'
  return 'required'
}

const TEXT: Record<Exclude<SnowflakeState, 'connected'>, string> = {
  signing_in: 'Signing in to Snowflake…',
  expired: 'Snowflake session expired',
  required: 'Snowflake sign-in required',
  not_connected: 'Not connected to Snowflake',
}

export function StandaloneTopBar({
  reportName,
  session,
  authRequired = false,
  fetching = false,
  onSignInAgain,
  onSettings,
  children,
}: {
  reportName: string
  session?: SessionStatus
  authRequired?: boolean
  fetching?: boolean
  onSignInAgain: () => void
  onSettings: () => void
  children?: ReactNode
}) {
  const state = snowflakeState(session, authRequired)
  const connected = state === 'connected'
  const detail = [session?.user, session?.role, session?.warehouse].filter(Boolean).join(' · ')
  return (
    <header
      data-testid="standalone-topbar"
      className="flex shrink-0 items-center justify-between gap-3 border-b border-surface-300 bg-white px-4 py-2"
    >
      <h1 className="truncate text-sm font-bold text-surface-900">
        {reportName}
        {fetching && <span className="ml-2 text-[10px] font-normal text-surface-500">refreshing…</span>}
      </h1>
      <div className="flex items-center gap-2">
        <span
          data-testid="snowflake-status"
          data-state={state}
          className={`rounded-full px-3 py-1 text-xs font-semibold ${
            connected ? 'bg-brand/15 text-brand-dark' : 'bg-brand-amber/15 text-brand-amber'
          }`}
        >
          {connected ? `Connected${detail ? ` · ${detail}` : ''}` : TEXT[state as Exclude<SnowflakeState, 'connected'>]}
        </span>
        {(state === 'expired' || state === 'required') && (
          <button
            type="button"
            onClick={onSignInAgain}
            className="rounded-[10px] bg-brand px-3 py-1.5 text-xs font-semibold text-white hover:bg-brand-dark"
          >
            Sign in again
          </button>
        )}
        <button
          type="button"
          onClick={onSettings}
          className="rounded-[10px] border border-surface-300 px-3 py-1.5 text-xs font-semibold text-surface-700 hover:bg-surface-100"
        >
          Connection settings
        </button>
        {children}
      </div>
    </header>
  )
}
