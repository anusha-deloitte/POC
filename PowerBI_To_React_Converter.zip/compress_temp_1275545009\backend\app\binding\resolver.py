"""Bind PBI-IR model tables to physical Snowflake objects.

Produces a BindingMap consumed by the SQL emitter; anything unresolved is
reported (never guessed) so the UI can escalate to a human.
"""

from __future__ import annotations

import re
from collections import Counter

from pydantic import BaseModel, Field

from app.binding.m_parser import parse_m_binding, snowflake_source_args
from app.ir.model import SemanticModel
from app.ir.report import BindingSettings, ReportBundle, TableCaseFix

_CONTROL_CHARS = re.compile(r"[\x00-\x1f\x7f]")
_PLAIN_UPPER = re.compile(r"^[A-Z_][A-Z0-9_$]*$")

# Snowflake reserved words: unquoted they would be parsed as keywords
_RESERVED = frozenset(
    """ACCOUNT ALL ALTER AND ANY AS BETWEEN BY CASE CAST CHECK COLUMN CONNECT CONNECTION CONSTRAINT
    CREATE CROSS CURRENT CURRENT_DATE CURRENT_TIME CURRENT_TIMESTAMP CURRENT_USER DATABASE DELETE
    DISTINCT DROP ELSE EXISTS FALSE FOLLOWING FOR FROM FULL GRANT GROUP GSCLUSTER HAVING ILIKE IN
    INCREMENT INNER INSERT INTERSECT INTO IS ISSUE JOIN LATERAL LEFT LIKE LOCALTIME LOCALTIMESTAMP
    MINUS NATURAL NOT NULL OF ON OR ORDER ORGANIZATION QUALIFY REGEXP REVOKE RIGHT RLIKE ROW ROWS
    SAMPLE SCHEMA SELECT SET SOME START TABLE TABLESAMPLE THEN TO TRIGGER TRUE TRY_CAST UNION UNIQUE
    UPDATE USING VALUES VIEW WHEN WHENEVER WHERE WITH""".split()
)


def describe_ident(name: str) -> str:
    """How an identifier is shown in messages: \u00abname\u00bb."""
    return f"\u00ab{name}\u00bb"


def safe_ident(name: str, origin: str = "identifier") -> str:
    """Body of a double-quoted identifier (`"` doubled). Only empty names and control
    characters cannot be quoted."""
    if not name or _CONTROL_CHARS.search(name):
        raise ValueError(
            f"invalid SQL identifier {describe_ident(name)} from {origin}: "
            "empty or contains control characters"
        )
    return name.replace('"', '""')


def quote_ident(name: str, origin: str = "identifier") -> str:
    return '"' + safe_ident(name, origin) + '"'


def sql_name(name: str, origin: str = "identifier") -> str:
    """Plain UPPERCASE non-reserved names stay unquoted (same object as the quoted form)."""
    if _PLAIN_UPPER.match(name) and name not in _RESERVED:
        return name
    return quote_ident(name, origin)


def sql_string(value: object) -> str:
    return "'" + str(value).replace("'", "''") + "'"


class TableBinding(BaseModel):
    table: str
    database: str | None = None
    schema_name: str | None = None
    object_name: str | None = None
    object_kind: str | None = None
    native_query: str | None = None
    transform_steps: list[str] = Field(default_factory=list)
    # M query SelectRows predicates → WHERE clause injected at query time
    where_clause: str | None = None
    # M query RenameColumns → source column name → display name
    column_aliases: dict[str, str] = Field(default_factory=dict)
    # M Table.AddColumn(...) translated to SQL: new column -> expression
    computed_columns: dict[str, str] = Field(default_factory=dict)
    # model physical column -> Snowflake's exact-case name (phase 05 case check)
    column_case: dict[str, str] = Field(default_factory=dict)
    # calculated / measure-only tables have no physical source
    is_virtual: bool = False
    # resolved | virtual | materialization_required | unresolved | needs_migration
    status: str = "resolved"
    materialization_strategy: str | None = None  # view | dynamic_table | table | None
    materialization_sql: str | None = None
    detail: str | None = None
    # foreign (non-Snowflake) source coordinates — filled when status=needs_migration
    source_kind: str | None = None  # sqlserver | postgres
    source_schema: str | None = None
    source_object: str | None = None

    @property
    def qualified_name(self) -> str | None:
        if not self.object_name:
            return None
        labelled = (
            ("database", self.database),
            ("schema", self.schema_name),
            ("object", self.object_name),
        )
        return ".".join(
            sql_name(part, f"the {label} name bound to table {describe_ident(self.table)}")
            for label, part in labelled
            if part
        )


class BindingMap(BaseModel):
    bindings: dict[str, TableBinding] = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)

    def get(self, table: str) -> TableBinding | None:
        return self.bindings.get(table)

    @property
    def unresolved(self) -> list[TableBinding]:
        return [b for b in self.bindings.values() if b.status == "unresolved"]

    @property
    def materialization_required(self) -> list[TableBinding]:
        return [b for b in self.bindings.values() if b.status == "materialization_required"]

    @property
    def needs_migration(self) -> list[TableBinding]:
        return [b for b in self.bindings.values() if b.status == "needs_migration"]


def build_binding_map(model: SemanticModel) -> BindingMap:
    out = BindingMap()
    query_time_transform_steps = {"Table.SelectRows", "Table.RenameColumns"}
    materialization_required_steps = {"Table.Group"}

    def _qident(value: str) -> str:
        return quote_ident(value, "the Table.Group materialization")

    def _materialization_sql(binding: TableBinding, mb) -> str | None:
        if not (binding.qualified_name and mb.group_by_columns and mb.group_aggregations):
            return None
        select_parts = [
            f"{_qident(col)}" for col in mb.group_by_columns
        ]
        for out_name, agg_kind, src_col in mb.group_aggregations:
            src = _qident(src_col)
            if agg_kind == "count_distinct":
                expr = f"COUNT(DISTINCT {src})"
            elif agg_kind == "count":
                expr = f"COUNT({src})"
            else:
                expr = f"MIN({src})"
            select_parts.append(f"{expr} AS {_qident(out_name)}")
        group_by = ", ".join(_qident(col) for col in mb.group_by_columns)
        return (
            "SELECT "
            + ", ".join(select_parts)
            + f"\nFROM {binding.qualified_name}\nGROUP BY {group_by}"
        )
    for table in model.tables:
        if table.is_auto_date_table:
            out.bindings[table.name] = TableBinding(
                table=table.name, is_virtual=True, status="virtual", detail="auto date table"
            )
            continue
        if not table.partitions:
            # measure-table pattern (_Measures) or calculated table
            out.bindings[table.name] = TableBinding(
                table=table.name,
                is_virtual=True,
                status="virtual",
                detail="no partition (measure table or calculated)",
            )
            continue
        part = table.partitions[0]
        if part.source_type == "calculated":
            # measure-table pattern: `_Measures = Row("Placeholder", BLANK())`
            out.bindings[table.name] = TableBinding(
                table=table.name,
                is_virtual=True,
                status="virtual",
                detail="calculated table",
            )
            continue
        if part.source_type != "m":
            out.bindings[table.name] = TableBinding(
                table=table.name,
                status="unresolved",
                detail=f"unsupported partition type: {part.source_type}",
            )
            continue
        mb = parse_m_binding(part.expression, model.expressions)
        out.warnings.extend(f"{table.name}: {w}" for w in mb.warnings)
        if mb.native_query:
            out.bindings[table.name] = TableBinding(
                table=table.name, native_query=mb.native_query, status="resolved"
            )
        elif mb.is_resolved:
            where_clause = " AND ".join(mb.where_predicates) if mb.where_predicates else None
            out.bindings[table.name] = TableBinding(
                table=table.name,
                database=mb.database,
                schema_name=mb.schema,
                object_name=mb.object_name,
                object_kind=mb.object_kind,
                transform_steps=mb.transform_steps,
                where_clause=where_clause,
                column_aliases=dict(mb.column_renames),
                computed_columns=dict(mb.computed_columns),
            )
            if mb.transform_steps:
                applied = []
                blocking = []
                non_applied = []
                for step in mb.transform_steps:
                    if step in query_time_transform_steps:
                        applied.append(step)
                    elif step in materialization_required_steps:
                        blocking.append(step)
                    else:
                        non_applied.append(step)
                if blocking:
                    out.bindings[table.name].status = "materialization_required"
                    out.bindings[table.name].materialization_strategy = "dynamic_table"
                    out.bindings[table.name].materialization_sql = _materialization_sql(
                        out.bindings[table.name], mb
                    )
                    out.bindings[table.name].detail = (
                        "materialization required for M transforms: " + ", ".join(blocking)
                    )
                if blocking or non_applied:
                    out.warnings.append(
                        f"{table.name}: complex M transforms not auto-applied: "
                        + ", ".join(blocking + non_applied)
                    )
                if applied:
                    out.warnings.append(
                        f"{table.name}: M transforms applied: " + ", ".join(applied)
                    )
        elif mb.is_foreign_resolved:
            # source database table — the migration mover lifts it into Snowflake
            out.bindings[table.name] = TableBinding(
                table=table.name,
                status="needs_migration",
                source_kind=mb.foreign_source,
                source_schema=mb.schema,
                source_object=mb.object_name,
                detail=(
                    f"bound to {mb.foreign_source} source "
                    f"{mb.schema}.{mb.object_name}; will migrate to Snowflake"
                ),
            )
        else:
            missing = (
                "parameter(s) not found in the model: "
                + ", ".join(f"«{p}»" for p in mb.unresolved_params)
                if mb.unresolved_params
                else "no schema/object found"
            )
            out.bindings[table.name] = TableBinding(
                table=table.name,
                status="unresolved",
                detail=f"could not resolve M source ({missing})",
            )
    return out


def verify_against_information_schema(
    binding_map: BindingMap, cursor, database: str
) -> BindingMap:
    """Mark resolved bindings missing from the live INFORMATION_SCHEMA (exact names)."""
    cursor.execute(
        f"select table_schema, table_name from {quote_ident(database, 'the database name')}"  # noqa: S608
        ".INFORMATION_SCHEMA.TABLES"
    )
    live = {(r[0], r[1]) for r in cursor.fetchall()}
    live_folded = {(a.upper(), b.upper()): (a, b) for a, b in live}
    for b in binding_map.bindings.values():
        if b.status == "resolved" and b.object_name and not b.native_query:
            key = (b.schema_name or "", b.object_name)
            if key in live:
                continue
            b.status = "unresolved"
            twin = live_folded.get(((b.schema_name or "").upper(), b.object_name.upper()))
            if twin:
                b.detail = (
                    f"letter case differs from Snowflake: bound as {key[0]}.{key[1]}, "
                    f"Snowflake has {twin[0]}.{twin[1]} (quoted names are case-sensitive)"
                )
            else:
                b.detail = f"not found in live {database}.INFORMATION_SCHEMA"
    return binding_map


mark_unresolved_against_live = verify_against_information_schema


# ---------------------------------------------------------------- overrides / case fixes


def _ci_equal(a: str | None, b: str | None) -> bool:
    return a is not None and b is not None and a.casefold() == b.casefold()


def source_hints(model: SemanticModel) -> dict[str, str | None]:
    """Most common Snowflake server/warehouse/database/schema across the M partitions;
    only used to pre-fill forms."""
    seen: dict[str, Counter] = {k: Counter() for k in ("server", "warehouse", "database", "schema")}
    for table in model.tables:
        for part in table.partitions:
            if part.source_type != "m":
                continue
            mb = parse_m_binding(part.expression, model.expressions)
            if not mb.is_snowflake:
                continue
            server, warehouse = snowflake_source_args(part.expression, model.expressions)
            for key, value in (
                ("server", server),
                ("warehouse", warehouse),
                ("database", mb.database),
                ("schema", mb.schema),
            ):
                if value:
                    seen[key][value] += 1
    return {k: (c.most_common(1)[0][0] if c else None) for k, c in seen.items()}


def requote_columns(sql: str, column_case: dict[str, str]) -> str:
    """Re-quote `"src"` column references in a WHERE/computed expression with Snowflake's
    exact-case names."""
    for src, exact in column_case.items():
        sql = sql.replace(quote_ident(src), quote_ident(exact))
    return sql


def apply_case_fix(b: TableBinding, fix: TableCaseFix) -> None:
    """Apply a saved case correction. Names change only when they equal the fix ignoring
    case, so a later override to another database never inherits a stale correction."""
    if fix.database and _ci_equal(b.database, fix.database):
        b.database = fix.database
    if fix.schema_name and _ci_equal(b.schema_name, fix.schema_name):
        b.schema_name = fix.schema_name
    if fix.object_name and _ci_equal(b.object_name, fix.object_name):
        b.object_name = fix.object_name
    b.column_case = {
        src: exact
        for src, exact in fix.columns.items()
        if src != exact and _ci_equal(src, exact)
    }


def apply_binding_settings(binding_map: BindingMap, settings: BindingSettings) -> BindingMap:
    for b in binding_map.bindings.values():
        if b.is_virtual or b.native_query or not b.object_name:
            continue
        if b.status not in ("resolved", "materialization_required"):
            continue
        if settings.database_override:
            b.database = settings.database_override
        if settings.schema_override:
            b.schema_name = settings.schema_override
        fix = settings.case_fixes.get(b.table)
        if fix:
            apply_case_fix(b, fix)
    return binding_map


def build_bundle_binding_map(bundle: ReportBundle) -> BindingMap:
    """The binding map every compile path uses: model bindings + saved overrides/case fixes."""
    return apply_binding_settings(build_binding_map(bundle.model), bundle.binding_settings)
